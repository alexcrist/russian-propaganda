Grailbird.data.tweets_2014_10 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528344952053325824\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/du3FES9OVc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1UO7xpCEAAauh0.jpg",
      "id_str" : "528344951386411008",
      "id" : 528344951386411008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1UO7xpCEAAauh0.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/du3FES9OVc"
    } ],
    "hashtags" : [ {
      "text" : "HappyHalloween",
      "indices" : [ 16, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528344952053325824",
  "text" : "Trick-or-Treat! #HappyHalloween http:\/\/t.co\/du3FES9OVc",
  "id" : 528344952053325824,
  "created_at" : "2014-11-01 00:37:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/528320607427903489\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/5shWdJXZcd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1T3OPHCQAA57xJ.jpg",
      "id_str" : "528318880255459328",
      "id" : 528318880255459328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1T3OPHCQAA57xJ.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5shWdJXZcd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528320607427903489",
  "text" : "Happy Halloween! http:\/\/t.co\/5shWdJXZcd",
  "id" : 528320607427903489,
  "created_at" : "2014-10-31 23:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 26, 33 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/zkpwEAoVVY",
      "expanded_url" : "http:\/\/go.wh.gov\/pet5Kv",
      "display_url" : "go.wh.gov\/pet5Kv"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/XyEEmUKROT",
      "expanded_url" : "https:\/\/vine.co\/v\/OO7DtLO5tIL",
      "display_url" : "vine.co\/v\/OO7DtLO5tIL"
    } ]
  },
  "geo" : { },
  "id_str" : "528294402792255488",
  "text" : "Watch President Obama and @FLOTUS welcome kids to Trick-or-Treat at the White House \u2192 http:\/\/t.co\/zkpwEAoVVY https:\/\/t.co\/XyEEmUKROT",
  "id" : 528294402792255488,
  "created_at" : "2014-10-31 21:16:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/528276211102134272\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/DzpBNJ7awy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1TQadiCEAA2qRj.jpg",
      "id_str" : "528276209331736576",
      "id" : 528276209331736576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1TQadiCEAA2qRj.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DzpBNJ7awy"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528276211102134272",
  "text" : "Let's help millions of Americans lift themselves out of poverty by raising the minimum wage. #RaiseTheWage http:\/\/t.co\/DzpBNJ7awy",
  "id" : 528276211102134272,
  "created_at" : "2014-10-31 20:03:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528258105432637442\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/1tHdL8MPzs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1S_8mECMAEb47r.jpg",
      "id_str" : "528258104039714817",
      "id" : 528258104039714817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1S_8mECMAEb47r.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1tHdL8MPzs"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/urCzpg4xJT",
      "expanded_url" : "http:\/\/bloom.bg\/1wMdsrT",
      "display_url" : "bloom.bg\/1wMdsrT"
    } ]
  },
  "geo" : { },
  "id_str" : "528258105432637442",
  "text" : "Here's how the Affordable Care Act is saving consumers $ on health care premiums \u2192 http:\/\/t.co\/urCzpg4xJT #ACAWorks http:\/\/t.co\/1tHdL8MPzs",
  "id" : 528258105432637442,
  "created_at" : "2014-10-31 18:52:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528240384975986688",
  "text" : "RT @vj44: A great @BloombergNews article showing the #ACA is keeping premiums low for consumers like you: http:\/\/t.co\/TvP4MMxI43 #GetCovered",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 43, 47 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 119, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/TvP4MMxI43",
        "expanded_url" : "http:\/\/bloom.bg\/1wMdsrT",
        "display_url" : "bloom.bg\/1wMdsrT"
      } ]
    },
    "geo" : { },
    "id_str" : "528226241640681474",
    "text" : "A great @BloombergNews article showing the #ACA is keeping premiums low for consumers like you: http:\/\/t.co\/TvP4MMxI43 #GetCovered",
    "id" : 528226241640681474,
    "created_at" : "2014-10-31 16:45:24 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 528240384975986688,
  "created_at" : "2014-10-31 17:41:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/528224899551461376\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/Z9ernipM0a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1ShvvxCMAIr8cl.jpg",
      "id_str" : "528224897957244930",
      "id" : 528224897957244930,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1ShvvxCMAIr8cl.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Z9ernipM0a"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528224899551461376",
  "text" : "Our\ndaughters\nshould\nbe\ntreated\nthe\nsame\nas\nour\nsons.\n#EqualPay http:\/\/t.co\/Z9ernipM0a",
  "id" : 528224899551461376,
  "created_at" : "2014-10-31 16:40:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/528214621468241920\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/R1DwRDJiR7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SYZZVIIAAOrBL.jpg",
      "id_str" : "528214618372841472",
      "id" : 528214618372841472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SYZZVIIAAOrBL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/R1DwRDJiR7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528221314121990144",
  "text" : "RT @VP: Let's face the facts \u2192 Republicans in Congress continue to block raising the minimum wage. http:\/\/t.co\/R1DwRDJiR7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/528214621468241920\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/R1DwRDJiR7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SYZZVIIAAOrBL.jpg",
        "id_str" : "528214618372841472",
        "id" : 528214618372841472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SYZZVIIAAOrBL.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/R1DwRDJiR7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "528214621468241920",
    "text" : "Let's face the facts \u2192 Republicans in Congress continue to block raising the minimum wage. http:\/\/t.co\/R1DwRDJiR7",
    "id" : 528214621468241920,
    "created_at" : "2014-10-31 15:59:14 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 528221314121990144,
  "created_at" : "2014-10-31 16:25:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhode Island College",
      "screen_name" : "RICNews",
      "indices" : [ 111, 119 ],
      "id_str" : "108657550",
      "id" : 108657550
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528212635289124865",
  "text" : "\"No matter who you are or what you look like\u2026here in America, you can make it if you try.\" \u2014President Obama at @RICNews #OpportunityForAll",
  "id" : 528212635289124865,
  "created_at" : "2014-10-31 15:51:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhode Island College",
      "screen_name" : "RICNews",
      "indices" : [ 60, 68 ],
      "id_str" : "108657550",
      "id" : 108657550
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 6, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528212338252709888",
  "text" : "\"When #WomenSucceed, America succeeds.\" \u2014President Obama at @RICNews",
  "id" : 528212338252709888,
  "created_at" : "2014-10-31 15:50:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528212110417723393",
  "text" : "\"We have to raise our voices and choose to do away with policies and politicians that belong in a \u201CMad Men\u201D episode.\" \u2014Obama #EqualPay",
  "id" : 528212110417723393,
  "created_at" : "2014-10-31 15:49:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528211027012235264\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/fknmDJwGdL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SVIKKIgAAQ8Mf.jpg",
      "id_str" : "528211023707537408",
      "id" : 528211023707537408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SVIKKIgAAQ8Mf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fknmDJwGdL"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528211027012235264",
  "text" : "\"Let\u2019s pass a fair pay law, and make our economy stronger.\" \u2014President Obama #EqualPay http:\/\/t.co\/fknmDJwGdL",
  "id" : 528211027012235264,
  "created_at" : "2014-10-31 15:44:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528210783604207617\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/hDnp35VGZg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SU5iBIUAEMGB7.jpg",
      "id_str" : "528210772414189569",
      "id" : 528210772414189569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SU5iBIUAEMGB7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hDnp35VGZg"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528210783604207617",
  "text" : "\"There are women still earning less than men for doing the same work.\" \u2014President Obama #EqualPay http:\/\/t.co\/hDnp35VGZg",
  "id" : 528210783604207617,
  "created_at" : "2014-10-31 15:43:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528210451721498624\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/QxY64P3Rv6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SUmOwIMAIVk8G.jpg",
      "id_str" : "528210440825090050",
      "id" : 528210440825090050,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SUmOwIMAIVk8G.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QxY64P3Rv6"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528210451721498624",
  "text" : "\"No one who works full-time in America should be below the poverty line.\" \u2014President Obama #RaiseTheWage http:\/\/t.co\/QxY64P3Rv6",
  "id" : 528210451721498624,
  "created_at" : "2014-10-31 15:42:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528209902167023616\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/jHO50DpjO3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SUGvBIMAAUCP9.jpg",
      "id_str" : "528209899730513920",
      "id" : 528209899730513920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SUGvBIMAAUCP9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jHO50DpjO3"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528209902167023616",
  "text" : "\"About 28 million Americans would benefit if we raised the minimum wage to $10.10 an hour.\" \u2014Obama #RaiseTheWage http:\/\/t.co\/jHO50DpjO3",
  "id" : 528209902167023616,
  "created_at" : "2014-10-31 15:40:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528209560905842689",
  "text" : "RT @WHLive: \"By the end of this decade, let\u2019s enroll six million children in high-quality preschool, and make America stronger.\" \u2014Obama #Pr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PreK4All",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "528209419767537665",
    "text" : "\"By the end of this decade, let\u2019s enroll six million children in high-quality preschool, and make America stronger.\" \u2014Obama #PreK4All",
    "id" : 528209419767537665,
    "created_at" : "2014-10-31 15:38:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 528209560905842689,
  "created_at" : "2014-10-31 15:39:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528209062433800193",
  "text" : "\"Moms and dads deserve a great place to drop their kids off every day that doesn\u2019t cost them an arm &amp; a leg.\" \u2014President Obama #WomenSucceed",
  "id" : 528209062433800193,
  "created_at" : "2014-10-31 15:37:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528208703988584448\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/VPUFc7m1Rk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1STA_vCMAI7aES.jpg",
      "id_str" : "528208701627183106",
      "id" : 528208701627183106,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1STA_vCMAI7aES.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VPUFc7m1Rk"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 52, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528208703988584448",
  "text" : "\"We all have a stake in choosing policies that help #WomenSucceed.\" \u2014President Obama http:\/\/t.co\/VPUFc7m1Rk",
  "id" : 528208703988584448,
  "created_at" : "2014-10-31 15:35:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 114, 127 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528208481438818304",
  "text" : "\"The idea that my daughters wouldn\u2019t have the same opportunities as somebody\u2019s sons: That\u2019s unacceptable.\" \u2014Obama #WomenSucceed #EqualPay",
  "id" : 528208481438818304,
  "created_at" : "2014-10-31 15:34:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528207806835351552",
  "text" : "\"I was raised by a single mom and know what it was like for her to raise two kids and go to work at the same time.\" \u2014Obama #WomenSucceed",
  "id" : 528207806835351552,
  "created_at" : "2014-10-31 15:32:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528207121246978048\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/A0qtV0ISuo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SRk7rCAAIGuv5.jpg",
      "id_str" : "528207119988686850",
      "id" : 528207119988686850,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SRk7rCAAIGuv5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/A0qtV0ISuo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528207121246978048",
  "text" : "\"In education, dropout rates are down, the national graduation rate is the highest on record.\" \u2014President Obama http:\/\/t.co\/A0qtV0ISuo",
  "id" : 528207121246978048,
  "created_at" : "2014-10-31 15:29:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528206821014515712\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/CnYjS9jEta",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SRTfgCQAEXyHf.jpg",
      "id_str" : "528206820368596993",
      "id" : 528206820368596993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SRTfgCQAEXyHf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CnYjS9jEta"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528206821014515712",
  "text" : "\"For the first time in more than six years, the unemployment rate is below 6%.\" \u2014President Obama http:\/\/t.co\/CnYjS9jEta",
  "id" : 528206821014515712,
  "created_at" : "2014-10-31 15:28:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528206595436445696\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/EOtuNelym1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SRGWtCYAA45aM.jpg",
      "id_str" : "528206594668912640",
      "id" : 528206594668912640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SRGWtCYAA45aM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EOtuNelym1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528206595436445696",
  "text" : "\"Over the past 55 months, our businesses have now added 10.3 million new jobs.\" \u2014President Obama http:\/\/t.co\/EOtuNelym1",
  "id" : 528206595436445696,
  "created_at" : "2014-10-31 15:27:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhode Island College",
      "screen_name" : "RICNews",
      "indices" : [ 124, 132 ],
      "id_str" : "108657550",
      "id" : 108657550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528205939166310400",
  "text" : "\"Happy Halloween...I am not going to be too long. I\u2019ve got to get back and Trick-or-Treat with Michelle tonight.\" \u2014Obama at @RICNews",
  "id" : 528205939166310400,
  "created_at" : "2014-10-31 15:24:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhode Island College",
      "screen_name" : "RICNews",
      "indices" : [ 38, 46 ],
      "id_str" : "108657550",
      "id" : 108657550
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/LZcHqUo6oD",
      "expanded_url" : "http:\/\/go.wh.gov\/xQPWCk",
      "display_url" : "go.wh.gov\/xQPWCk"
    } ]
  },
  "geo" : { },
  "id_str" : "528205738489806849",
  "text" : "Watch live: President Obama speaks at @RICNews on pursuing policies that help #WomenSucceed \u2192 http:\/\/t.co\/LZcHqUo6oD",
  "id" : 528205738489806849,
  "created_at" : "2014-10-31 15:23:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528200698442182656\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/jsTeZuZJUe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SLvGICcAA7C4O.jpg",
      "id_str" : "528200697523630080",
      "id" : 528200697523630080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SLvGICcAA7C4O.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jsTeZuZJUe"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528200698442182656",
  "text" : "FACT: The Paycheck Fairness Act would help women fight for #EqualPay.\nRepublicans in Congress continue to block it. http:\/\/t.co\/jsTeZuZJUe",
  "id" : 528200698442182656,
  "created_at" : "2014-10-31 15:03:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528197643101421568\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Ip9aGyoDtd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SI9Q1CQAAtnxu.jpg",
      "id_str" : "528197642380001280",
      "id" : 528197642380001280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SI9Q1CQAAtnxu.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ip9aGyoDtd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528197643101421568",
  "text" : "On average, women who work full-time still earn just $0.78 for every $1 men earn.\nIt's time to change that. http:\/\/t.co\/Ip9aGyoDtd",
  "id" : 528197643101421568,
  "created_at" : "2014-10-31 14:51:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhode Island College",
      "screen_name" : "RICNews",
      "indices" : [ 36, 44 ],
      "id_str" : "108657550",
      "id" : 108657550
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 76, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/LZcHqUo6oD",
      "expanded_url" : "http:\/\/go.wh.gov\/xQPWCk",
      "display_url" : "go.wh.gov\/xQPWCk"
    } ]
  },
  "geo" : { },
  "id_str" : "528191298939797505",
  "text" : "Don\u2019t miss President Obama speak at @RICNews on pursuing policies that help #WomenSucceed at 11:10am ET \u2192 http:\/\/t.co\/LZcHqUo6oD",
  "id" : 528191298939797505,
  "created_at" : "2014-10-31 14:26:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/xcgf6AY17D",
      "expanded_url" : "http:\/\/youtu.be\/2viA92y2eXw",
      "display_url" : "youtu.be\/2viA92y2eXw"
    } ]
  },
  "geo" : { },
  "id_str" : "527969495273336832",
  "text" : "\"America has never been defined by fear. We are defined by courage and passion and hope and selflessness.\" \u2014Obama: http:\/\/t.co\/xcgf6AY17D",
  "id" : 527969495273336832,
  "created_at" : "2014-10-30 23:45:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527939084661317632",
  "text" : "RT @VP: \"He was, to his core, the very definition of Boston Strong. Unyielding. Absolutely committed.\" -VP on Tom Menino http:\/\/t.co\/jpUFbq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/527901698317357058\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/jpUFbqfg9f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1N7yrkCUAIWQtP.png",
        "id_str" : "527901691950026754",
        "id" : 527901691950026754,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1N7yrkCUAIWQtP.png",
        "sizes" : [ {
          "h" : 251,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 875,
          "resize" : "fit",
          "w" : 1187
        }, {
          "h" : 442,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 755,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jpUFbqfg9f"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "527901698317357058",
    "text" : "\"He was, to his core, the very definition of Boston Strong. Unyielding. Absolutely committed.\" -VP on Tom Menino http:\/\/t.co\/jpUFbqfg9f",
    "id" : 527901698317357058,
    "created_at" : "2014-10-30 19:15:47 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 527939084661317632,
  "created_at" : "2014-10-30 21:44:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/527910365414170625\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/CcAyNIOHaG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1ODrfeCMAAN_4Y.jpg",
      "id_str" : "527910364537565184",
      "id" : 527910364537565184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1ODrfeCMAAN_4Y.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CcAyNIOHaG"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527910365414170625",
  "text" : "It's time for Republicans in Congress to help close the pay gap between men and women. #EqualPay http:\/\/t.co\/CcAyNIOHaG",
  "id" : 527910365414170625,
  "created_at" : "2014-10-30 19:50:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 96, 111 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationofMakers",
      "indices" : [ 112, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/hyrSx3YL7t",
      "expanded_url" : "http:\/\/wapo.st\/13lsQ3R",
      "display_url" : "wapo.st\/13lsQ3R"
    } ]
  },
  "geo" : { },
  "id_str" : "527897209715441664",
  "text" : "RT @ks44: The @WhiteHouse is getting a 3D-printed Christmas ornament http:\/\/t.co\/hyrSx3YL7t via @washingtonpost #NationofMakers",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 86, 101 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationofMakers",
        "indices" : [ 102, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/hyrSx3YL7t",
        "expanded_url" : "http:\/\/wapo.st\/13lsQ3R",
        "display_url" : "wapo.st\/13lsQ3R"
      } ]
    },
    "geo" : { },
    "id_str" : "527896185445822464",
    "text" : "The @WhiteHouse is getting a 3D-printed Christmas ornament http:\/\/t.co\/hyrSx3YL7t via @washingtonpost #NationofMakers",
    "id" : 527896185445822464,
    "created_at" : "2014-10-30 18:53:53 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 527897209715441664,
  "created_at" : "2014-10-30 18:57:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/527893350469234688\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/nEEacBRXmB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1N0NGQCEAA7B6Z.jpg",
      "id_str" : "527893349697458176",
      "id" : 527893349697458176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1N0NGQCEAA7B6Z.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nEEacBRXmB"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527893350469234688",
  "text" : "President Obama's taken steps to help ensure #EqualPay, but Republicans in Congress are blocking further action. http:\/\/t.co\/nEEacBRXmB",
  "id" : 527893350469234688,
  "created_at" : "2014-10-30 18:42:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/527884015273930752\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/t824EpiGRN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1NrttACcAAr6eK.jpg",
      "id_str" : "527884014250520576",
      "id" : 527884014250520576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1NrttACcAAr6eK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/t824EpiGRN"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/bRyqywyiiU",
      "expanded_url" : "http:\/\/go.wh.gov\/WL5tNU",
      "display_url" : "go.wh.gov\/WL5tNU"
    } ]
  },
  "geo" : { },
  "id_str" : "527884015273930752",
  "text" : "Women entering the workforce after college earn less than men in almost every field: http:\/\/t.co\/bRyqywyiiU #EqualPay http:\/\/t.co\/t824EpiGRN",
  "id" : 527884015273930752,
  "created_at" : "2014-10-30 18:05:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/527866542009376769\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/oanPkvmHe2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1Nb0pcCMAAInht.png",
      "id_str" : "527866541367242752",
      "id" : 527866541367242752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1Nb0pcCMAAInht.png",
      "sizes" : [ {
        "h" : 80,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 1213
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 141,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oanPkvmHe2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527866542009376769",
  "text" : "\"Bold, big-hearted, and Boston strong, Tom was the embodiment of the city he loved and led.\" \u2014Obama on Tom Menino http:\/\/t.co\/oanPkvmHe2",
  "id" : 527866542009376769,
  "created_at" : "2014-10-30 16:56:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Z0xSrABmQ2",
      "expanded_url" : "http:\/\/whitehouse.tumblr.com\/submit",
      "display_url" : "whitehouse.tumblr.com\/submit"
    } ]
  },
  "geo" : { },
  "id_str" : "527861355546566656",
  "text" : "RT @FLOTUS: FLOTUS used to be like many of you: Working on her college apps.\nAsk her your Q's by Fri: http:\/\/t.co\/Z0xSrABmQ2 http:\/\/t.co\/cB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/527860182223572992\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/cBcpWhExlU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1NWCcaCAAAFY-l.jpg",
        "id_str" : "527860181317582848",
        "id" : 527860181317582848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1NWCcaCAAAFY-l.jpg",
        "sizes" : [ {
          "h" : 524,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 350
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 509,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 350
        } ],
        "display_url" : "pic.twitter.com\/cBcpWhExlU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/Z0xSrABmQ2",
        "expanded_url" : "http:\/\/whitehouse.tumblr.com\/submit",
        "display_url" : "whitehouse.tumblr.com\/submit"
      } ]
    },
    "geo" : { },
    "id_str" : "527860182223572992",
    "text" : "FLOTUS used to be like many of you: Working on her college apps.\nAsk her your Q's by Fri: http:\/\/t.co\/Z0xSrABmQ2 http:\/\/t.co\/cBcpWhExlU",
    "id" : 527860182223572992,
    "created_at" : "2014-10-30 16:30:49 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 527861355546566656,
  "created_at" : "2014-10-30 16:35:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/527824771153924096\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/hhMbXlbK2y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1M10-DCEAATRbD.jpg",
      "id_str" : "527824765457666048",
      "id" : 527824765457666048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1M10-DCEAATRbD.jpg",
      "sizes" : [ {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 659,
        "resize" : "fit",
        "w" : 910
      }, {
        "h" : 659,
        "resize" : "fit",
        "w" : 910
      } ],
      "display_url" : "pic.twitter.com\/hhMbXlbK2y"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/6rqG4FZG0C",
      "expanded_url" : "http:\/\/go.wh.gov\/EHJGrj",
      "display_url" : "go.wh.gov\/EHJGrj"
    } ]
  },
  "geo" : { },
  "id_str" : "527851704675336192",
  "text" : "FACT: Growth in manufacturing and overall exports picked up last quarter \u2192 http:\/\/t.co\/6rqG4FZG0C http:\/\/t.co\/hhMbXlbK2y",
  "id" : 527851704675336192,
  "created_at" : "2014-10-30 15:57:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/527839856899010562\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ShEl0mDzHH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1NDjRhCUAAbLpM.png",
      "id_str" : "527839854608928768",
      "id" : 527839854608928768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1NDjRhCUAAbLpM.png",
      "sizes" : [ {
        "h" : 387,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/ShEl0mDzHH"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/tpV3zGbXtJ",
      "expanded_url" : "http:\/\/go.wh.gov\/EHJGrj",
      "display_url" : "go.wh.gov\/EHJGrj"
    } ]
  },
  "geo" : { },
  "id_str" : "527844429801861121",
  "text" : "RT @VP: FACT: American exports have grown by 4.6% over the last year \u2192 http:\/\/t.co\/tpV3zGbXtJ #MadeInAmerica http:\/\/t.co\/ShEl0mDzHH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/527839856899010562\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/ShEl0mDzHH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1NDjRhCUAAbLpM.png",
        "id_str" : "527839854608928768",
        "id" : 527839854608928768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1NDjRhCUAAbLpM.png",
        "sizes" : [ {
          "h" : 387,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 387,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/ShEl0mDzHH"
      } ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 86, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/tpV3zGbXtJ",
        "expanded_url" : "http:\/\/go.wh.gov\/EHJGrj",
        "display_url" : "go.wh.gov\/EHJGrj"
      } ]
    },
    "geo" : { },
    "id_str" : "527839856899010562",
    "text" : "FACT: American exports have grown by 4.6% over the last year \u2192 http:\/\/t.co\/tpV3zGbXtJ #MadeInAmerica http:\/\/t.co\/ShEl0mDzHH",
    "id" : 527839856899010562,
    "created_at" : "2014-10-30 15:10:03 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 527844429801861121,
  "created_at" : "2014-10-30 15:28:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/527837237912666112\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/MzeadNJtoB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1NBK2zCcAAX7yn.jpg",
      "id_str" : "527837236096561152",
      "id" : 527837236096561152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1NBK2zCcAAX7yn.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/MzeadNJtoB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/6rqG4FZG0C",
      "expanded_url" : "http:\/\/go.wh.gov\/EHJGrj",
      "display_url" : "go.wh.gov\/EHJGrj"
    } ]
  },
  "geo" : { },
  "id_str" : "527837237912666112",
  "text" : "Our economy grew at a 3.5% rate last quarter\u2014but there's more work to do \u2192 http:\/\/t.co\/6rqG4FZG0C http:\/\/t.co\/MzeadNJtoB",
  "id" : 527837237912666112,
  "created_at" : "2014-10-30 14:59:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/6rqG4FZG0C",
      "expanded_url" : "http:\/\/go.wh.gov\/EHJGrj",
      "display_url" : "go.wh.gov\/EHJGrj"
    } ]
  },
  "geo" : { },
  "id_str" : "527832806219468800",
  "text" : "Good news: Our economy continues to grow.\n3rd-quarter GDP = \u2191 3.5%\nExport growth = \u2191\nManufacturing = \u2191\nhttp:\/\/t.co\/6rqG4FZG0C",
  "id" : 527832806219468800,
  "created_at" : "2014-10-30 14:42:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527595458936725504",
  "text" : "RT @SecretaryJewell: Fun selfie w\/ Mississippi Choctaw youth today; We owe all Native kids a chance for a bright future like this -SJ http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/527501478068760577\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/2vpcR9vNId",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1IPzIOCMAEt4ju.jpg",
        "id_str" : "527501477409861633",
        "id" : 527501477409861633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1IPzIOCMAEt4ju.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/2vpcR9vNId"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "527501478068760577",
    "text" : "Fun selfie w\/ Mississippi Choctaw youth today; We owe all Native kids a chance for a bright future like this -SJ http:\/\/t.co\/2vpcR9vNId",
    "id" : 527501478068760577,
    "created_at" : "2014-10-29 16:45:27 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 527595458936725504,
  "created_at" : "2014-10-29 22:58:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Leonhardt",
      "screen_name" : "DLeonhardt",
      "indices" : [ 3, 14 ],
      "id_str" : "168295477",
      "id" : 168295477
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DLeonhardt\/status\/527497523691548672\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/yaG2RjlQ64",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1IMM8VCIAAIwOI.png",
      "id_str" : "527497522848079872",
      "id" : 527497522848079872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1IMM8VCIAAIwOI.png",
      "sizes" : [ {
        "h" : 282,
        "resize" : "fit",
        "w" : 649
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 649
      } ],
      "display_url" : "pic.twitter.com\/yaG2RjlQ64"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/nHsbo0g22T",
      "expanded_url" : "http:\/\/nyti.ms\/1DvHnEX",
      "display_url" : "nyti.ms\/1DvHnEX"
    } ]
  },
  "geo" : { },
  "id_str" : "527568748061138944",
  "text" : "RT @DLeonhardt: Above all, Obamacare is an attack on inequality. http:\/\/t.co\/nHsbo0g22T http:\/\/t.co\/yaG2RjlQ64",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DLeonhardt\/status\/527497523691548672\/photo\/1",
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/yaG2RjlQ64",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1IMM8VCIAAIwOI.png",
        "id_str" : "527497522848079872",
        "id" : 527497522848079872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1IMM8VCIAAIwOI.png",
        "sizes" : [ {
          "h" : 282,
          "resize" : "fit",
          "w" : 649
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 148,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 649
        } ],
        "display_url" : "pic.twitter.com\/yaG2RjlQ64"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/nHsbo0g22T",
        "expanded_url" : "http:\/\/nyti.ms\/1DvHnEX",
        "display_url" : "nyti.ms\/1DvHnEX"
      } ]
    },
    "geo" : { },
    "id_str" : "527497523691548672",
    "text" : "Above all, Obamacare is an attack on inequality. http:\/\/t.co\/nHsbo0g22T http:\/\/t.co\/yaG2RjlQ64",
    "id" : 527497523691548672,
    "created_at" : "2014-10-29 16:29:44 +0000",
    "user" : {
      "name" : "David Leonhardt",
      "screen_name" : "DLeonhardt",
      "protected" : false,
      "id_str" : "168295477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461893183866040320\/xMponje2_normal.jpeg",
      "id" : 168295477,
      "verified" : true
    }
  },
  "id" : 527568748061138944,
  "created_at" : "2014-10-29 21:12:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "indices" : [ 3, 17 ],
      "id_str" : "308573576",
      "id" : 308573576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manufacturing",
      "indices" : [ 104, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527556776313356290",
  "text" : "RT @PennyPritzker: NEC Director Jeff Zients and I wrote how the Administration is accelerating advanced #manufacturing in America http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "manufacturing",
        "indices" : [ 85, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/FKXeef6acs",
        "expanded_url" : "http:\/\/1.usa.gov\/102sfBK",
        "display_url" : "1.usa.gov\/102sfBK"
      } ]
    },
    "geo" : { },
    "id_str" : "527536944935620609",
    "text" : "NEC Director Jeff Zients and I wrote how the Administration is accelerating advanced #manufacturing in America http:\/\/t.co\/FKXeef6acs",
    "id" : 527536944935620609,
    "created_at" : "2014-10-29 19:06:23 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 527556776313356290,
  "created_at" : "2014-10-29 20:25:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527551573207957504",
  "text" : "RT @WHLive: \"We are defined by the ordinary Americans who risk their own safety to help those in need.\" \u2014President Obama #Ebola",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 109, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "527551535157616642",
    "text" : "\"We are defined by the ordinary Americans who risk their own safety to help those in need.\" \u2014President Obama #Ebola",
    "id" : 527551535157616642,
    "created_at" : "2014-10-29 20:04:22 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 527551573207957504,
  "created_at" : "2014-10-29 20:04:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527551342143754240",
  "text" : "\"America has never been defined by fear. We are defined by courage and passion and hope and selflessness and sacrifice.\" \u2014Obama #Ebola",
  "id" : 527551342143754240,
  "created_at" : "2014-10-29 20:03:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527550760410550272",
  "text" : "\"That's what we do. No other nation is doing as much to help in West Africa as the United States of America.\" \u2014Obama on #Ebola",
  "id" : 527550760410550272,
  "created_at" : "2014-10-29 20:01:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 103, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/ibwxdQROQK",
      "expanded_url" : "http:\/\/go.wh.gov\/QJw3e1",
      "display_url" : "go.wh.gov\/QJw3e1"
    } ]
  },
  "geo" : { },
  "id_str" : "527550220100714496",
  "text" : "\"We know that this disease can be contained and defeated if we stay vigilant and committed.\" \u2014Obama on #Ebola: http:\/\/t.co\/ibwxdQROQK",
  "id" : 527550220100714496,
  "created_at" : "2014-10-29 19:59:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/ibwxdQROQK",
      "expanded_url" : "http:\/\/go.wh.gov\/QJw3e1",
      "display_url" : "go.wh.gov\/QJw3e1"
    } ]
  },
  "geo" : { },
  "id_str" : "527549983416139777",
  "text" : "\"It\u2019s critical that we remain focused on the facts and on the science.\" \u2014President Obama on #Ebola: http:\/\/t.co\/ibwxdQROQK",
  "id" : 527549983416139777,
  "created_at" : "2014-10-29 19:58:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527549327905148928",
  "text" : "RT @WHLive: \u201CUntil we stop their outbreak in West Africa, we may continue to see individual cases in America.\u201D \u2014President Obama #Ebola",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 116, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "527549291196203008",
    "text" : "\u201CUntil we stop their outbreak in West Africa, we may continue to see individual cases in America.\u201D \u2014President Obama #Ebola",
    "id" : 527549291196203008,
    "created_at" : "2014-10-29 19:55:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 527549327905148928,
  "created_at" : "2014-10-29 19:55:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 131, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527547453302513664",
  "text" : "\"Each of you studied medicine because you wanted to save lives. The world needs you more than ever.\" \u2014Obama to health care workers #Ebola",
  "id" : 527547453302513664,
  "created_at" : "2014-10-29 19:48:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527547376764862465",
  "text" : "\"They deserve our gratitude\u2014and they deserve to be treated with dignity and with respect.\" \u2014Obama on health care workers fighting #Ebola",
  "id" : 527547376764862465,
  "created_at" : "2014-10-29 19:47:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527547169734017024",
  "text" : "\"We need to call them what they are\u2014American heroes.\" \u2014President Obama on health care workers who are fighting #Ebola",
  "id" : 527547169734017024,
  "created_at" : "2014-10-29 19:47:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/ibwxdQROQK",
      "expanded_url" : "http:\/\/go.wh.gov\/QJw3e1",
      "display_url" : "go.wh.gov\/QJw3e1"
    } ]
  },
  "geo" : { },
  "id_str" : "527546865311821824",
  "text" : "\"The best way to protect Americans from #Ebola is to stop the outbreak at its source.\" \u2014President Obama: http:\/\/t.co\/ibwxdQROQK",
  "id" : 527546865311821824,
  "created_at" : "2014-10-29 19:45:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 84, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ibwxdQROQK",
      "expanded_url" : "http:\/\/go.wh.gov\/QJw3e1",
      "display_url" : "go.wh.gov\/QJw3e1"
    } ]
  },
  "geo" : { },
  "id_str" : "527546599090978816",
  "text" : "Watch live: President Obama speaks to American health care workers who are fighting #Ebola \u2192 http:\/\/t.co\/ibwxdQROQK",
  "id" : 527546599090978816,
  "created_at" : "2014-10-29 19:44:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/GWqAgc8Yj5",
      "expanded_url" : "http:\/\/go.wh.gov\/QJw3e1",
      "display_url" : "go.wh.gov\/QJw3e1"
    } ]
  },
  "geo" : { },
  "id_str" : "527543585596383232",
  "text" : "At 3:40pm ET, President Obama speaks to American health care workers who are fighting #Ebola \u2192 http:\/\/t.co\/GWqAgc8Yj5",
  "id" : 527543585596383232,
  "created_at" : "2014-10-29 19:32:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/527508997360738305\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/a3idofGYbM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1IWopjCIAACU_i.jpg",
      "id_str" : "527508993959141376",
      "id" : 527508993959141376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1IWopjCIAACU_i.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/a3idofGYbM"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527508997360738305",
  "text" : "Our daughters should be treated the same as our sons.\nIt's time to ensure #EqualPay for women. http:\/\/t.co\/a3idofGYbM",
  "id" : 527508997360738305,
  "created_at" : "2014-10-29 17:15:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/527495090676056064\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/Kx4QiDVvxN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1IFeMNCYAAC6PA.jpg",
      "id_str" : "527490122585890816",
      "id" : 527490122585890816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1IFeMNCYAAC6PA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Kx4QiDVvxN"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/6XbOMCf9j4",
      "expanded_url" : "http:\/\/nyti.ms\/1tL5fVt",
      "display_url" : "nyti.ms\/1tL5fVt"
    } ]
  },
  "geo" : { },
  "id_str" : "527495090676056064",
  "text" : "We've \u2193 the uninsured rate by 26%.\nSee how your county benefitted \u2192 http:\/\/t.co\/6XbOMCf9j4\n#ACAWorks http:\/\/t.co\/Kx4QiDVvxN",
  "id" : 527495090676056064,
  "created_at" : "2014-10-29 16:20:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/527487565818241024\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/RNbOmYRN2J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1IDI-rCEAAHsg0.jpg",
      "id_str" : "527487559153094656",
      "id" : 527487559153094656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1IDI-rCEAAHsg0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RNbOmYRN2J"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/JIrJEjkWZT",
      "expanded_url" : "http:\/\/go.wh.gov\/WL5tNU",
      "display_url" : "go.wh.gov\/WL5tNU"
    } ]
  },
  "geo" : { },
  "id_str" : "527487565818241024",
  "text" : "When #WomenSucceed, America succeeds. It's long-past time to ensure #EqualPay for women \u2192 http:\/\/t.co\/JIrJEjkWZT http:\/\/t.co\/RNbOmYRN2J",
  "id" : 527487565818241024,
  "created_at" : "2014-10-29 15:50:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/527478777589145602\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Gj4eti5Al8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1H3Qn6CcAAiUNs.jpg",
      "id_str" : "527474496341438464",
      "id" : 527474496341438464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1H3Qn6CcAAiUNs.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Gj4eti5Al8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527478777589145602",
  "text" : "President Obama greets the 2014 Broadcom MASTERS\u2014rising stars in math, applied science, technology, and engineering. http:\/\/t.co\/Gj4eti5Al8",
  "id" : 527478777589145602,
  "created_at" : "2014-10-29 15:15:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/527471019531841536\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/eBbBuGrNyh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1H0GKuCEAE0BHs.jpg",
      "id_str" : "527471018172878849",
      "id" : 527471018172878849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1H0GKuCEAE0BHs.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/eBbBuGrNyh"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 86, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/MeXmYoBEim",
      "expanded_url" : "http:\/\/go.wh.gov\/j2FFoy",
      "display_url" : "go.wh.gov\/j2FFoy"
    } ]
  },
  "geo" : { },
  "id_str" : "527471019531841536",
  "text" : "\"This disease can be contained. It will be defeated. Progress is possible.\" \u2014Obama on #Ebola: http:\/\/t.co\/MeXmYoBEim http:\/\/t.co\/eBbBuGrNyh",
  "id" : 527471019531841536,
  "created_at" : "2014-10-29 14:44:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 84, 95 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527238833189175296",
  "text" : "RT @FLOTUS: Got questions on how you're going to pay for college? Ask FLOTUS on the @WhiteHouse Tumblr before next Monday's Q&amp;A \u2192 http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 72, 83 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/nwre5KEPxh",
        "expanded_url" : "http:\/\/go.wh.gov\/QLswhu",
        "display_url" : "go.wh.gov\/QLswhu"
      } ]
    },
    "geo" : { },
    "id_str" : "527233790611968000",
    "text" : "Got questions on how you're going to pay for college? Ask FLOTUS on the @WhiteHouse Tumblr before next Monday's Q&amp;A \u2192 http:\/\/t.co\/nwre5KEPxh",
    "id" : 527233790611968000,
    "created_at" : "2014-10-28 23:01:45 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 527238833189175296,
  "created_at" : "2014-10-28 23:21:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527176005811585025",
  "text" : "\"America in the end is not defined by fear. That's not who we are.\" \u2014President Obama on stopping #Ebola and keeping the American people safe",
  "id" : 527176005811585025,
  "created_at" : "2014-10-28 19:12:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 83, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "527175359847223296",
  "text" : "\"This disease can be contained. It will be defeated.\" \u2014President Obama on stopping #Ebola: http:\/\/t.co\/b4tqL36eMn",
  "id" : 527175359847223296,
  "created_at" : "2014-10-28 19:09:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 33, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527175019743690753",
  "text" : "\"Only two people have contracted #Ebola on American soil...today, both of them are disease-free.\" \u2014President Obama",
  "id" : 527175019743690753,
  "created_at" : "2014-10-28 19:08:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527174369366532096",
  "text" : "\"We\u2019re going to have to stay vigilant here at home until we stop this epidemic at its source.\" \u2014President Obama on #Ebola",
  "id" : 527174369366532096,
  "created_at" : "2014-10-28 19:05:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527173961365585920",
  "text" : "RT @WHLive: \"When others are in trouble, when disease or disaster strikes, Americans help.\" \u2014President Obama on responding to #Ebola in Wes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 114, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "527173933205053440",
    "text" : "\"When others are in trouble, when disease or disaster strikes, Americans help.\" \u2014President Obama on responding to #Ebola in West Africa",
    "id" : 527173933205053440,
    "created_at" : "2014-10-28 19:03:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 527173961365585920,
  "created_at" : "2014-10-28 19:04:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527173783015014400",
  "text" : "\"The best way to protect Americans is to stop the outbreak at its source.\" \u2014President Obama on stopping #Ebola in West Africa",
  "id" : 527173783015014400,
  "created_at" : "2014-10-28 19:03:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 1, 7 ],
      "id_str" : "36683668",
      "id" : 36683668
    }, {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 10, 18 ],
      "id_str" : "232193350",
      "id" : 232193350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 39, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/exfbpYwbjx",
      "expanded_url" : "http:\/\/usat.ly\/1wyIUZP",
      "display_url" : "usat.ly\/1wyIUZP"
    } ]
  },
  "geo" : { },
  "id_str" : "527168178045337600",
  "text" : ".@USAID's @RajShah on why we will stop #Ebola in West Africa \u2192 http:\/\/t.co\/exfbpYwbjx",
  "id" : 527168178045337600,
  "created_at" : "2014-10-28 18:41:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/BuazdicI1i",
      "expanded_url" : "http:\/\/go.wh.gov\/B1mKPj",
      "display_url" : "go.wh.gov\/B1mKPj"
    } ]
  },
  "geo" : { },
  "id_str" : "527159582905225217",
  "text" : "At 2:55pm ET, President Obama delivers a statement from the White House. Watch \u2192 http:\/\/t.co\/BuazdicI1i",
  "id" : 527159582905225217,
  "created_at" : "2014-10-28 18:06:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 18, 22 ],
      "id_str" : "14615871",
      "id" : 14615871
    }, {
      "name" : "ENERGY STAR",
      "screen_name" : "ENERGYSTAR",
      "indices" : [ 24, 35 ],
      "id_str" : "24881081",
      "id" : 24881081
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/YQkKlVxLRc",
      "expanded_url" : "http:\/\/go.wh.gov\/rCSdz3",
      "display_url" : "go.wh.gov\/rCSdz3"
    } ]
  },
  "geo" : { },
  "id_str" : "527152116477870080",
  "text" : "Big news from the @EPA.\n@EnergyStar has:\nSaved Americans $300 billion \u2713\n\u2704 carbon pollution \u2713\nhttp:\/\/t.co\/YQkKlVxLRc\n#ActOnClimate",
  "id" : 527152116477870080,
  "created_at" : "2014-10-28 17:37:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Sam Champion",
      "screen_name" : "SamChampion",
      "indices" : [ 72, 84 ],
      "id_str" : "21232507",
      "id" : 21232507
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527125768732540931",
  "text" : "RT @whitehouseostp: Today, Science Advisor Dr. John Holdren talked with @SamChampion about why we need to #ActOnClimate. WATCH \u2192 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sam Champion",
        "screen_name" : "SamChampion",
        "indices" : [ 52, 64 ],
        "id_str" : "21232507",
        "id" : 21232507
      }, {
        "name" : "AMHQ",
        "screen_name" : "AMHQ",
        "indices" : [ 132, 137 ],
        "id_str" : "2325690444",
        "id" : 2325690444
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 86, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/Eby4uUlaff",
        "expanded_url" : "http:\/\/www.weather.com\/video\/climate-change-is-here-now-54946?collid=\/tv\/shows\/amhq",
        "display_url" : "weather.com\/video\/climate-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "527121448037404672",
    "text" : "Today, Science Advisor Dr. John Holdren talked with @SamChampion about why we need to #ActOnClimate. WATCH \u2192 http:\/\/t.co\/Eby4uUlaff @AMHQ",
    "id" : 527121448037404672,
    "created_at" : "2014-10-28 15:35:21 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 527125768732540931,
  "created_at" : "2014-10-28 15:52:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "StatueLibrtyNPS",
      "screen_name" : "statuelibrtynps",
      "indices" : [ 20, 36 ],
      "id_str" : "3087968373",
      "id" : 3087968373
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/527104550982123520\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/uadEnaKv2R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1Cmy7fCQAIBiNR.jpg",
      "id_str" : "527104550293880834",
      "id" : 527104550293880834,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1Cmy7fCQAIBiNR.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/uadEnaKv2R"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527121412008312832",
  "text" : "RT @Interior: Today @StatueLibrtyNPS turns 128 years old! RT to wish Lady Liberty happy birthday http:\/\/t.co\/uadEnaKv2R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "StatueLibrtyNPS",
        "screen_name" : "statuelibrtynps",
        "indices" : [ 6, 22 ],
        "id_str" : "3087968373",
        "id" : 3087968373
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/527104550982123520\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/uadEnaKv2R",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1Cmy7fCQAIBiNR.jpg",
        "id_str" : "527104550293880834",
        "id" : 527104550293880834,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1Cmy7fCQAIBiNR.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/uadEnaKv2R"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "527104550982123520",
    "text" : "Today @StatueLibrtyNPS turns 128 years old! RT to wish Lady Liberty happy birthday http:\/\/t.co\/uadEnaKv2R",
    "id" : 527104550982123520,
    "created_at" : "2014-10-28 14:28:12 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 527121412008312832,
  "created_at" : "2014-10-28 15:35:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/527117623868137472\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/p32rRGoKHe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1Cuo7wCIAEBUVZ.jpg",
      "id_str" : "527113174659506177",
      "id" : 527113174659506177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1Cuo7wCIAEBUVZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/p32rRGoKHe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/qg35bkwmD3",
      "expanded_url" : "http:\/\/theverge.com\/e\/6843072",
      "display_url" : "theverge.com\/e\/6843072"
    } ]
  },
  "geo" : { },
  "id_str" : "527117623868137472",
  "text" : "RT if you agree: Every student in America should have access to high-speed internet \u2192 http:\/\/t.co\/qg35bkwmD3 http:\/\/t.co\/p32rRGoKHe",
  "id" : 527117623868137472,
  "created_at" : "2014-10-28 15:20:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 76, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/qg35bkwmD3",
      "expanded_url" : "http:\/\/theverge.com\/e\/6843072",
      "display_url" : "theverge.com\/e\/6843072"
    } ]
  },
  "geo" : { },
  "id_str" : "527111398711521281",
  "text" : "Worth a read: Apple shares how its $100 million pledge to President Obama's #ConnectED initiative will help schools \u2192 http:\/\/t.co\/qg35bkwmD3",
  "id" : 527111398711521281,
  "created_at" : "2014-10-28 14:55:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jillian Hiscock",
      "screen_name" : "JillianHiscock",
      "indices" : [ 3, 18 ],
      "id_str" : "731650394",
      "id" : 731650394
    }, {
      "name" : "SJU Senate",
      "screen_name" : "sju_senate",
      "indices" : [ 51, 62 ],
      "id_str" : "189258807",
      "id" : 189258807
    }, {
      "name" : "CSB\/SJU",
      "screen_name" : "CSBSJU",
      "indices" : [ 96, 103 ],
      "id_str" : "87770695",
      "id" : 87770695
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 78, 86 ]
    }, {
      "text" : "sexualassault",
      "indices" : [ 105, 119 ]
    }, {
      "text" : "prevention",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526868443891789824",
  "text" : "RT @JillianHiscock: Very, very cool chalk art from @sju_senate supporting the #ItsOnUs campaign @csbsju! #sexualassault #prevention http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SJU Senate",
        "screen_name" : "sju_senate",
        "indices" : [ 31, 42 ],
        "id_str" : "189258807",
        "id" : 189258807
      }, {
        "name" : "CSB\/SJU",
        "screen_name" : "CSBSJU",
        "indices" : [ 76, 83 ],
        "id_str" : "87770695",
        "id" : 87770695
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JillianHiscock\/status\/526769009358684160\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/cE0g4CDJY6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B091nAnCUAEEZve.jpg",
        "id_str" : "526768994464714753",
        "id" : 526768994464714753,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B091nAnCUAEEZve.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cE0g4CDJY6"
      } ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 58, 66 ]
      }, {
        "text" : "sexualassault",
        "indices" : [ 85, 99 ]
      }, {
        "text" : "prevention",
        "indices" : [ 100, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526769009358684160",
    "text" : "Very, very cool chalk art from @sju_senate supporting the #ItsOnUs campaign @csbsju! #sexualassault #prevention http:\/\/t.co\/cE0g4CDJY6",
    "id" : 526769009358684160,
    "created_at" : "2014-10-27 16:14:53 +0000",
    "user" : {
      "name" : "Jillian Hiscock",
      "screen_name" : "JillianHiscock",
      "protected" : false,
      "id_str" : "731650394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/621738485276241920\/JgaGHo51_normal.jpg",
      "id" : 731650394,
      "verified" : false
    }
  },
  "id" : 526868443891789824,
  "created_at" : "2014-10-27 22:50:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/526852834734534656\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/XcDtS6IasU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0_B3EHCMAIbn0w.jpg",
      "id_str" : "526852833165848578",
      "id" : 526852833165848578,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0_B3EHCMAIbn0w.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1071,
        "resize" : "fit",
        "w" : 1608
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XcDtS6IasU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526854458081542144",
  "text" : "RT @vj44: Such an honor to meet Alyce Dixon, who at 107 is the oldest, female, African American WWII veteran. http:\/\/t.co\/XcDtS6IasU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/526852834734534656\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/XcDtS6IasU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0_B3EHCMAIbn0w.jpg",
        "id_str" : "526852833165848578",
        "id" : 526852833165848578,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0_B3EHCMAIbn0w.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1071,
          "resize" : "fit",
          "w" : 1608
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/XcDtS6IasU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526852834734534656",
    "text" : "Such an honor to meet Alyce Dixon, who at 107 is the oldest, female, African American WWII veteran. http:\/\/t.co\/XcDtS6IasU",
    "id" : 526852834734534656,
    "created_at" : "2014-10-27 21:47:58 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 526854458081542144,
  "created_at" : "2014-10-27 21:54:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/dHIICYUJP5",
      "expanded_url" : "http:\/\/go.wh.gov\/NBx7KZ",
      "display_url" : "go.wh.gov\/NBx7KZ"
    } ]
  },
  "geo" : { },
  "id_str" : "526838860458643456",
  "text" : "Get the latest on how President Obama's taking action to strengthen American advanced manufacturing: http:\/\/t.co\/dHIICYUJP5 #MadeInAmerica",
  "id" : 526838860458643456,
  "created_at" : "2014-10-27 20:52:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/526821965512732672\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/xLeuHDfDoy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0-lyLtCQAEfWl7.jpg",
      "id_str" : "526821962979360769",
      "id" : 526821962979360769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0-lyLtCQAEfWl7.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xLeuHDfDoy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526821965512732672",
  "text" : "Morning commute. http:\/\/t.co\/xLeuHDfDoy",
  "id" : 526821965512732672,
  "created_at" : "2014-10-27 19:45:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 98, 109 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526815044882153472",
  "text" : "RT @FLOTUS: Got questions on helping students #ReachHigher for college? FLOTUS will answer on the @WhiteHouse Tumblr next Monday: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 86, 97 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 34, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/nwre5KEPxh",
        "expanded_url" : "http:\/\/go.wh.gov\/QLswhu",
        "display_url" : "go.wh.gov\/QLswhu"
      } ]
    },
    "geo" : { },
    "id_str" : "526814344462352384",
    "text" : "Got questions on helping students #ReachHigher for college? FLOTUS will answer on the @WhiteHouse Tumblr next Monday: http:\/\/t.co\/nwre5KEPxh",
    "id" : 526814344462352384,
    "created_at" : "2014-10-27 19:15:02 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 526815044882153472,
  "created_at" : "2014-10-27 19:17:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/526758174880452608\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/Kl2Zn07i8O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B09rxG8IAAAuXrb.jpg",
      "id_str" : "526758172846194688",
      "id" : 526758172846194688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B09rxG8IAAAuXrb.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/Kl2Zn07i8O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526798413808283648",
  "text" : "RT @lacasablanca: Aprende m\u00E1s sobre \u00C9bola \u2192 http:\/\/t.co\/Kl2Zn07i8O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/526758174880452608\/photo\/1",
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/Kl2Zn07i8O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B09rxG8IAAAuXrb.jpg",
        "id_str" : "526758172846194688",
        "id" : 526758172846194688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B09rxG8IAAAuXrb.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/Kl2Zn07i8O"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526758174880452608",
    "text" : "Aprende m\u00E1s sobre \u00C9bola \u2192 http:\/\/t.co\/Kl2Zn07i8O",
    "id" : 526758174880452608,
    "created_at" : "2014-10-27 15:31:50 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 526798413808283648,
  "created_at" : "2014-10-27 18:11:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/526779098136207360\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/bdhzFLfRCJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B09-zB9CEAA8lGD.jpg",
      "id_str" : "526779096588488704",
      "id" : 526779096588488704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B09-zB9CEAA8lGD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bdhzFLfRCJ"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526779098136207360",
  "text" : "Share the news: Our manufacturers are adding jobs at the fastest pace since the 1990s. #MadeInAmerica http:\/\/t.co\/bdhzFLfRCJ",
  "id" : 526779098136207360,
  "created_at" : "2014-10-27 16:54:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526774915672707072",
  "text" : "RT @Cecilia44: FACT: Hispanic dropout rate, 14%, is lowest in three decades and has been cut in half since 2000. More here: http:\/\/t.co\/CTT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/CTTxu6sdzs",
        "expanded_url" : "http:\/\/www.nbcnews.com\/news\/latino\/whats-behind-falling-latino-dropout-rates-n232986",
        "display_url" : "nbcnews.com\/news\/latino\/wh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "526774451484897280",
    "text" : "FACT: Hispanic dropout rate, 14%, is lowest in three decades and has been cut in half since 2000. More here: http:\/\/t.co\/CTTxu6sdzs",
    "id" : 526774451484897280,
    "created_at" : "2014-10-27 16:36:30 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 526774915672707072,
  "created_at" : "2014-10-27 16:38:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/dHIICYUJP5",
      "expanded_url" : "http:\/\/go.wh.gov\/NBx7KZ",
      "display_url" : "go.wh.gov\/NBx7KZ"
    } ]
  },
  "geo" : { },
  "id_str" : "526765576002080768",
  "text" : "We're providing manufacturers access to new and expanded state-of-the-art facilities like those at our national labs: http:\/\/t.co\/dHIICYUJP5",
  "id" : 526765576002080768,
  "created_at" : "2014-10-27 16:01:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/dHIICYUJP5",
      "expanded_url" : "http:\/\/go.wh.gov\/NBx7KZ",
      "display_url" : "go.wh.gov\/NBx7KZ"
    } ]
  },
  "geo" : { },
  "id_str" : "526755753718071297",
  "text" : "FACT: We're investing more than $300 million in emerging manufacturing technologies to boost U.S. competitiveness: http:\/\/t.co\/dHIICYUJP5",
  "id" : 526755753718071297,
  "created_at" : "2014-10-27 15:22:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/526748204767801344\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/b6QQ6wGNEr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B09is2FCIAAhjvh.jpg",
      "id_str" : "526748203996028928",
      "id" : 526748203996028928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B09is2FCIAAhjvh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/b6QQ6wGNEr"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/dHIICYUJP5",
      "expanded_url" : "http:\/\/go.wh.gov\/NBx7KZ",
      "display_url" : "go.wh.gov\/NBx7KZ"
    } ]
  },
  "geo" : { },
  "id_str" : "526748204767801344",
  "text" : "President Obama's announcing new actions to strengthen American manufacturing: http:\/\/t.co\/dHIICYUJP5 #MadeInAmerica http:\/\/t.co\/b6QQ6wGNEr",
  "id" : 526748204767801344,
  "created_at" : "2014-10-27 14:52:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 102, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/TeRHtxNr8B",
      "expanded_url" : "http:\/\/go.wh.gov\/9KZL5a",
      "display_url" : "go.wh.gov\/9KZL5a"
    } ]
  },
  "geo" : { },
  "id_str" : "526418053274157056",
  "text" : "\"The best way to stop this disease...is to stop it at its source in West Africa.\" \u2014President Obama on #Ebola: http:\/\/t.co\/TeRHtxNr8B",
  "id" : 526418053274157056,
  "created_at" : "2014-10-26 17:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/TeRHtxNr8B",
      "expanded_url" : "http:\/\/go.wh.gov\/9KZL5a",
      "display_url" : "go.wh.gov\/9KZL5a"
    } ]
  },
  "geo" : { },
  "id_str" : "526395365281374208",
  "text" : "\"Patients can beat this disease. We can beat this disease. But we have to stay vigilant.\" \u2014President Obama on #Ebola: http:\/\/t.co\/TeRHtxNr8B",
  "id" : 526395365281374208,
  "created_at" : "2014-10-26 15:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 75, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/TeRHtxNr8B",
      "expanded_url" : "http:\/\/go.wh.gov\/9KZL5a",
      "display_url" : "go.wh.gov\/9KZL5a"
    } ]
  },
  "geo" : { },
  "id_str" : "526372744166776832",
  "text" : "\"It\u2019s important to remember that of the seven Americans treated so far for #Ebola...all seven have survived.\" \u2014Obama: http:\/\/t.co\/TeRHtxNr8B",
  "id" : 526372744166776832,
  "created_at" : "2014-10-26 14:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/TeRHtxNr8B",
      "expanded_url" : "http:\/\/go.wh.gov\/9KZL5a",
      "display_url" : "go.wh.gov\/9KZL5a"
    } ]
  },
  "geo" : { },
  "id_str" : "526055686644330496",
  "text" : "\"The only way you can get this disease is...direct contact with the bodily fluids of someone with symptoms.\" \u2014Obama: http:\/\/t.co\/TeRHtxNr8B",
  "id" : 526055686644330496,
  "created_at" : "2014-10-25 17:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/TeRHtxNr8B",
      "expanded_url" : "http:\/\/go.wh.gov\/9KZL5a",
      "display_url" : "go.wh.gov\/9KZL5a"
    } ]
  },
  "geo" : { },
  "id_str" : "526033041043374081",
  "text" : "\"I\u2019ve assured Governor Cuomo and Mayor de Blasio that they\u2019ll have all the federal support they need.\" \u2014Obama: http:\/\/t.co\/TeRHtxNr8B #Ebola",
  "id" : 526033041043374081,
  "created_at" : "2014-10-25 15:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 81, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/TeRHtxNr8B",
      "expanded_url" : "http:\/\/go.wh.gov\/9KZL5a",
      "display_url" : "go.wh.gov\/9KZL5a"
    } ]
  },
  "geo" : { },
  "id_str" : "526011190309183488",
  "text" : "Watch President Obama's weekly address on our comprehensive effort to respond to #Ebola and keep Americans safe \u2192 http:\/\/t.co\/TeRHtxNr8B",
  "id" : 526011190309183488,
  "created_at" : "2014-10-25 14:03:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NIH",
      "screen_name" : "NIH",
      "indices" : [ 95, 99 ],
      "id_str" : "15134240",
      "id" : 15134240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 1, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/0i9rcXR242",
      "expanded_url" : "http:\/\/go.wh.gov\/sZ1c8g",
      "display_url" : "go.wh.gov\/sZ1c8g"
    } ]
  },
  "geo" : { },
  "id_str" : "525806515186171904",
  "text" : "\"#Ebola spreads by direct contact with the bodily fluids of an ill patient.\" \u2014Dr. Fauci at the @NIH: http:\/\/t.co\/0i9rcXR242",
  "id" : 525806515186171904,
  "created_at" : "2014-10-25 00:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NIH",
      "screen_name" : "NIH",
      "indices" : [ 109, 113 ],
      "id_str" : "15134240",
      "id" : 15134240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 13, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/0i9rcXR242",
      "expanded_url" : "http:\/\/go.wh.gov\/sZ1c8g",
      "display_url" : "go.wh.gov\/sZ1c8g"
    } ]
  },
  "geo" : { },
  "id_str" : "525795147078828032",
  "text" : "\"The risk of #Ebola for the everyday citizen in the United States is extraordinarily low.\" \u2014Dr. Fauci at the @NIH: http:\/\/t.co\/0i9rcXR242",
  "id" : 525795147078828032,
  "created_at" : "2014-10-24 23:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 3, 9 ],
      "id_str" : "25928253",
      "id" : 25928253
    }, {
      "name" : "NIH",
      "screen_name" : "NIH",
      "indices" : [ 12, 16 ],
      "id_str" : "15134240",
      "id" : 15134240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 69, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525788748014157824",
  "text" : "RT @WebMD: .@NIH official Anthony Fauci, MD, answers questions about #Ebola; explains how the virus spreads and can be stopped. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NIH",
        "screen_name" : "NIH",
        "indices" : [ 1, 5 ],
        "id_str" : "15134240",
        "id" : 15134240
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 58, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/mhRlMN6Mdf",
        "expanded_url" : "http:\/\/wb.md\/1uQQlIc",
        "display_url" : "wb.md\/1uQQlIc"
      } ]
    },
    "geo" : { },
    "id_str" : "525762801386549248",
    "text" : ".@NIH official Anthony Fauci, MD, answers questions about #Ebola; explains how the virus spreads and can be stopped. http:\/\/t.co\/mhRlMN6Mdf",
    "id" : 525762801386549248,
    "created_at" : "2014-10-24 21:36:34 +0000",
    "user" : {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "protected" : false,
      "id_str" : "25928253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771386734760386562\/-cRW6ixT_normal.jpg",
      "id" : 25928253,
      "verified" : true
    }
  },
  "id" : 525788748014157824,
  "created_at" : "2014-10-24 23:19:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NIH",
      "screen_name" : "NIH",
      "indices" : [ 15, 19 ],
      "id_str" : "15134240",
      "id" : 15134240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 60, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/0i9rcXR242",
      "expanded_url" : "http:\/\/go.wh.gov\/sZ1c8g",
      "display_url" : "go.wh.gov\/sZ1c8g"
    } ]
  },
  "geo" : { },
  "id_str" : "525784495287320576",
  "text" : "Worth sharing: @NIH's Dr. Fauci gives a digital briefing on #Ebola and the U.S. response \u2192 http:\/\/t.co\/0i9rcXR242",
  "id" : 525784495287320576,
  "created_at" : "2014-10-24 23:02:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/525753831226081281\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/yZClBGqUEM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0vaUsRCAAAmZEd.jpg",
      "id_str" : "525753830533627904",
      "id" : 525753830533627904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0vaUsRCAAAmZEd.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/yZClBGqUEM"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 35, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/14gr41Qdtc",
      "expanded_url" : "http:\/\/go.wh.gov\/JQcf9x",
      "display_url" : "go.wh.gov\/JQcf9x"
    } ]
  },
  "geo" : { },
  "id_str" : "525753831226081281",
  "text" : "Nurse Nina Pham, who recently beat #Ebola, met with President Obama today before heading home. http:\/\/t.co\/14gr41Qdtc http:\/\/t.co\/yZClBGqUEM",
  "id" : 525753831226081281,
  "created_at" : "2014-10-24 21:00:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/525711298546634752\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/IJYNF2Uyp1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0uzo9bCEAAdx_g.jpg",
      "id_str" : "525711297782878208",
      "id" : 525711297782878208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0uzo9bCEAAdx_g.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IJYNF2Uyp1"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 25, 31 ]
    }, {
      "text" : "EbolaInNYC",
      "indices" : [ 56, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/RMFwal2IB8",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "525711298546634752",
  "text" : "RT to share the facts on #Ebola: http:\/\/t.co\/RMFwal2IB8 #EbolaInNYC http:\/\/t.co\/IJYNF2Uyp1",
  "id" : 525711298546634752,
  "created_at" : "2014-10-24 18:11:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    }, {
      "name" : "The Baltimore Sun",
      "screen_name" : "baltimoresun",
      "indices" : [ 87, 100 ],
      "id_str" : "8861752",
      "id" : 8861752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/m9SymVQfcI",
      "expanded_url" : "http:\/\/bsun.md\/1vYhIVk",
      "display_url" : "bsun.md\/1vYhIVk"
    } ]
  },
  "geo" : { },
  "id_str" : "525673157647024132",
  "text" : "RT @DeptVetAffairs: VA is critical to medicine and Veterans http:\/\/t.co\/m9SymVQfcI via @baltimoresun",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Baltimore Sun",
        "screen_name" : "baltimoresun",
        "indices" : [ 67, 80 ],
        "id_str" : "8861752",
        "id" : 8861752
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/m9SymVQfcI",
        "expanded_url" : "http:\/\/bsun.md\/1vYhIVk",
        "display_url" : "bsun.md\/1vYhIVk"
      } ]
    },
    "geo" : { },
    "id_str" : "525640855453839362",
    "text" : "VA is critical to medicine and Veterans http:\/\/t.co\/m9SymVQfcI via @baltimoresun",
    "id" : 525640855453839362,
    "created_at" : "2014-10-24 13:32:00 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 525673157647024132,
  "created_at" : "2014-10-24 15:40:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/525660312641757185\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/t2Em0uE9fi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0uFRMKCcAAg9Qp.png",
      "id_str" : "525660311886393344",
      "id" : 525660311886393344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0uFRMKCcAAg9Qp.png",
      "sizes" : [ {
        "h" : 262,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 149,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 1163
      } ],
      "display_url" : "pic.twitter.com\/t2Em0uE9fi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525660312641757185",
  "text" : "Readout of the President's calls with New York officials regarding the diagnosis of an Ebola case in New York City: http:\/\/t.co\/t2Em0uE9fi",
  "id" : 525660312641757185,
  "created_at" : "2014-10-24 14:49:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/525385543635705857\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/8oStnKkxal",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0qLXerIEAIBklF.png",
      "id_str" : "525385542029283330",
      "id" : 525385542029283330,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0qLXerIEAIBklF.png",
      "sizes" : [ {
        "h" : 449,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/8oStnKkxal"
    } ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/FRL2YYm4rF",
      "expanded_url" : "http:\/\/WhiteHouse.gov",
      "display_url" : "WhiteHouse.gov"
    }, {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/K2AjfpRK4v",
      "expanded_url" : "http:\/\/go.wh.gov\/EmaenF",
      "display_url" : "go.wh.gov\/EmaenF"
    } ]
  },
  "geo" : { },
  "id_str" : "525385543635705857",
  "text" : "20 years ago this week, the White House launched http:\/\/t.co\/FRL2YYm4rF.\nCheck it out \u2192 http:\/\/t.co\/K2AjfpRK4v\n#TBT http:\/\/t.co\/8oStnKkxal",
  "id" : 525385543635705857,
  "created_at" : "2014-10-23 20:37:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/525380544558030848\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/uXuqj2EMjN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0qG0fVIIAAkgIL.png",
      "id_str" : "525380542863515648",
      "id" : 525380542863515648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0qG0fVIIAAkgIL.png",
      "sizes" : [ {
        "h" : 956,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 956,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/uXuqj2EMjN"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525381339093422082",
  "text" : "RT @USDOL: Compared to other countries, our minimum wage is low \u2014 really low. #RaiseTheWage http:\/\/t.co\/uXuqj2EMjN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/525380544558030848\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/uXuqj2EMjN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0qG0fVIIAAkgIL.png",
        "id_str" : "525380542863515648",
        "id" : 525380542863515648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0qG0fVIIAAkgIL.png",
        "sizes" : [ {
          "h" : 956,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 598,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 956,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/uXuqj2EMjN"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 67, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "525380544558030848",
    "text" : "Compared to other countries, our minimum wage is low \u2014 really low. #RaiseTheWage http:\/\/t.co\/uXuqj2EMjN",
    "id" : 525380544558030848,
    "created_at" : "2014-10-23 20:17:37 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 525381339093422082,
  "created_at" : "2014-10-23 20:20:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/525372523874373632\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/0SMNvZD9PV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0p_hsDIEAAw1CH.jpg",
      "id_str" : "525372523278766080",
      "id" : 525372523278766080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0p_hsDIEAAw1CH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0SMNvZD9PV"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525372523874373632",
  "text" : "Women make less than men in almost every field 4 years after graduation. It's time to change that. #EqualPay http:\/\/t.co\/0SMNvZD9PV",
  "id" : 525372523874373632,
  "created_at" : "2014-10-23 19:45:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 121, 129 ]
    }, {
      "text" : "VAWA",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/WjsZbXOObI",
      "expanded_url" : "http:\/\/itsonus.org",
      "display_url" : "itsonus.org"
    } ]
  },
  "geo" : { },
  "id_str" : "525360259725295616",
  "text" : "RT @VP: VP Biden: \"It's on us to stop other men\" from taking advantage of women across the world. http:\/\/t.co\/WjsZbXOObI #ItsOnUs #VAWA #1i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 113, 121 ]
      }, {
        "text" : "VAWA",
        "indices" : [ 122, 127 ]
      }, {
        "text" : "1is2many",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/WjsZbXOObI",
        "expanded_url" : "http:\/\/itsonus.org",
        "display_url" : "itsonus.org"
      } ]
    },
    "geo" : { },
    "id_str" : "525352602176065538",
    "text" : "VP Biden: \"It's on us to stop other men\" from taking advantage of women across the world. http:\/\/t.co\/WjsZbXOObI #ItsOnUs #VAWA #1is2many",
    "id" : 525352602176065538,
    "created_at" : "2014-10-23 18:26:35 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 525360259725295616,
  "created_at" : "2014-10-23 18:57:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/525350033516810240\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/uPbAxruxY0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0prEfsIcAAwxbP.jpg",
      "id_str" : "525350031512334336",
      "id" : 525350031512334336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0prEfsIcAAwxbP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uPbAxruxY0"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/bRyqywyiiU",
      "expanded_url" : "http:\/\/go.wh.gov\/WL5tNU",
      "display_url" : "go.wh.gov\/WL5tNU"
    } ]
  },
  "geo" : { },
  "id_str" : "525350033516810240",
  "text" : "When #WomenSucceed, America succeeds. It's long-past time to ensure #EqualPay for women \u2192 http:\/\/t.co\/bRyqywyiiU http:\/\/t.co\/uPbAxruxY0",
  "id" : 525350033516810240,
  "created_at" : "2014-10-23 18:16:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Paul",
      "screen_name" : "CP3",
      "indices" : [ 1, 5 ],
      "id_str" : "53853197",
      "id" : 53853197
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/91XjkrVWXP",
      "expanded_url" : "http:\/\/huff.to\/1FIHhxP",
      "display_url" : "huff.to\/1FIHhxP"
    } ]
  },
  "geo" : { },
  "id_str" : "525334040426328064",
  "text" : ".@CP3 shares how important mentors were to him, and why we should all help young people succeed \u2192 http:\/\/t.co\/91XjkrVWXP #MyBrothersKeeper",
  "id" : 525334040426328064,
  "created_at" : "2014-10-23 17:12:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/525323855762845697\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/BW7IyBAhpp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0pTQ1DIgAAcASq.jpg",
      "id_str" : "525323855125315584",
      "id" : 525323855125315584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0pTQ1DIgAAcASq.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/BW7IyBAhpp"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/N5eLL6FK9u",
      "expanded_url" : "http:\/\/go.wh.gov\/7ET6KW",
      "display_url" : "go.wh.gov\/7ET6KW"
    } ]
  },
  "geo" : { },
  "id_str" : "525323855762845697",
  "text" : "Here's how America is leading a comprehensive effort to respond to #Ebola \u2192 http:\/\/t.co\/N5eLL6FK9u http:\/\/t.co\/BW7IyBAhpp",
  "id" : 525323855762845697,
  "created_at" : "2014-10-23 16:32:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/525306809850945536\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/OHGCzSTPKH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0pDwmJIEAAoOCI.jpg",
      "id_str" : "525306808693690368",
      "id" : 525306808693690368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0pDwmJIEAAoOCI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/OHGCzSTPKH"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/vQXwwWaoj1",
      "expanded_url" : "http:\/\/go.wh.gov\/7ET6KW",
      "display_url" : "go.wh.gov\/7ET6KW"
    } ]
  },
  "geo" : { },
  "id_str" : "525306809850945536",
  "text" : "Get the latest on our comprehensive effort to respond to #Ebola and keep Americans safe \u2192 http:\/\/t.co\/vQXwwWaoj1 http:\/\/t.co\/OHGCzSTPKH",
  "id" : 525306809850945536,
  "created_at" : "2014-10-23 15:24:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/B2fscJyi2K",
      "expanded_url" : "http:\/\/youtu.be\/9MO1kywF6mc",
      "display_url" : "youtu.be\/9MO1kywF6mc"
    } ]
  },
  "geo" : { },
  "id_str" : "525038317826740224",
  "text" : "\"I want to wish a Happy Diwali to all those who are celebrating the Festival of Lights.\" \u2014President Obama: http:\/\/t.co\/B2fscJyi2K",
  "id" : 525038317826740224,
  "created_at" : "2014-10-22 21:37:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NIH",
      "screen_name" : "NIH",
      "indices" : [ 40, 44 ],
      "id_str" : "15134240",
      "id" : 15134240
    }, {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 77, 83 ],
      "id_str" : "25928253",
      "id" : 25928253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 28, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/z70WZGYGWj",
      "expanded_url" : "http:\/\/go.wh.gov\/GZ4AfC",
      "display_url" : "go.wh.gov\/GZ4AfC"
    } ]
  },
  "geo" : { },
  "id_str" : "525014098283880448",
  "text" : "If you have questions about #Ebola, ask @NIH's Dr. Fauci and he'll answer on @WebMD \u2192 http:\/\/t.co\/z70WZGYGWj",
  "id" : 525014098283880448,
  "created_at" : "2014-10-22 20:01:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/525000264164462592\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/94OdZQ4LAF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0ks9HpCAAAANjK.jpg",
      "id_str" : "525000260100161536",
      "id" : 525000260100161536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0ks9HpCAAAANjK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/94OdZQ4LAF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/MbPF8HqxyZ",
      "expanded_url" : "http:\/\/go.wh.gov\/hK3gPi",
      "display_url" : "go.wh.gov\/hK3gPi"
    } ]
  },
  "geo" : { },
  "id_str" : "525000264164462592",
  "text" : "Here's how we're taking action to protect Americans from identity theft &amp; credit card fraud: http:\/\/t.co\/MbPF8HqxyZ http:\/\/t.co\/94OdZQ4LAF",
  "id" : 525000264164462592,
  "created_at" : "2014-10-22 19:06:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/0DPzuAc3mU",
      "expanded_url" : "http:\/\/go.wh.gov\/UwtxAK",
      "display_url" : "go.wh.gov\/UwtxAK"
    } ]
  },
  "geo" : { },
  "id_str" : "524972290694332416",
  "text" : "We salute Ben Bradlee for reminding us that our freedom as a nation rests on freedom of the press: http:\/\/t.co\/0DPzuAc3mU",
  "id" : 524972290694332416,
  "created_at" : "2014-10-22 17:15:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/524733844268646402\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/yIDIuB1Jqx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0g6pnsCQAAlMLH.png",
      "id_str" : "524733843291389952",
      "id" : 524733843291389952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0g6pnsCQAAlMLH.png",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 526
      } ],
      "display_url" : "pic.twitter.com\/yIDIuB1Jqx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524733844268646402",
  "text" : "\"For Benjamin Bradlee, journalism was more than a profession \u2013 it was a public good vital to our democracy.\" \u2014Obama http:\/\/t.co\/yIDIuB1Jqx",
  "id" : 524733844268646402,
  "created_at" : "2014-10-22 01:27:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/524646416816144384\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/QijhDzvROC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0frIILCIAAJrag.jpg",
      "id_str" : "524646406477193216",
      "id" : 524646406477193216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0frIILCIAAJrag.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/QijhDzvROC"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/OVPnMpobFA",
      "expanded_url" : "http:\/\/go.wh.gov\/Cue7fT",
      "display_url" : "go.wh.gov\/Cue7fT"
    } ]
  },
  "geo" : { },
  "id_str" : "524646416816144384",
  "text" : "Here are three ways you can help with the effort to stop the spread of #Ebola \u2192 http:\/\/t.co\/OVPnMpobFA http:\/\/t.co\/QijhDzvROC",
  "id" : 524646416816144384,
  "created_at" : "2014-10-21 19:40:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/8Jzr1lWjJc",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/wonkblog\/wp\/2014\/10\/21\/temperatures-have-been-above-average-for-355-straight-months\/",
      "display_url" : "washingtonpost.com\/blogs\/wonkblog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "524640718329888768",
  "text" : "RT @Podesta44: February 1985: The last time global average temperatures were, well, average: http:\/\/t.co\/8Jzr1lWjJc #ActOnClimate http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Podesta44\/status\/524639729141051395\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/0PirBKzKlM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0flDZKCcAA7713.png",
        "id_str" : "524639728067309568",
        "id" : 524639728067309568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0flDZKCcAA7713.png",
        "sizes" : [ {
          "h" : 765,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/0PirBKzKlM"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/8Jzr1lWjJc",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/wonkblog\/wp\/2014\/10\/21\/temperatures-have-been-above-average-for-355-straight-months\/",
        "display_url" : "washingtonpost.com\/blogs\/wonkblog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "524639729141051395",
    "text" : "February 1985: The last time global average temperatures were, well, average: http:\/\/t.co\/8Jzr1lWjJc #ActOnClimate http:\/\/t.co\/0PirBKzKlM",
    "id" : 524639729141051395,
    "created_at" : "2014-10-21 19:13:53 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 524640718329888768,
  "created_at" : "2014-10-21 19:17:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaAnswers",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524637862872883200",
  "text" : "RT @VP: \"We need better roads and we need deeper ports...this all means jobs and it means more exports.\" -VP Biden at #AmericaAnswers forum",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AmericaAnswers",
        "indices" : [ 110, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "524631337471598592",
    "text" : "\"We need better roads and we need deeper ports...this all means jobs and it means more exports.\" -VP Biden at #AmericaAnswers forum",
    "id" : 524631337471598592,
    "created_at" : "2014-10-21 18:40:32 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 524637862872883200,
  "created_at" : "2014-10-21 19:06:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 9, 23 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "NORAD & USNORTHCOM",
      "screen_name" : "NoradNorthcom",
      "indices" : [ 34, 48 ],
      "id_str" : "18144581",
      "id" : 18144581
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 76, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/IyBNowX5WZ",
      "expanded_url" : "http:\/\/go.wh.gov\/cyS8bu",
      "display_url" : "go.wh.gov\/cyS8bu"
    } ]
  },
  "geo" : { },
  "id_str" : "524632189082677248",
  "text" : "Meet the @DeptOfDefense team from @NoradNorthcom that's ready to respond to #Ebola cases in the U.S. \u2192 http:\/\/t.co\/IyBNowX5WZ",
  "id" : 524632189082677248,
  "created_at" : "2014-10-21 18:43:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 93, 108 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/puGk5sHTFR",
      "expanded_url" : "http:\/\/go.wh.gov\/HLKiKR",
      "display_url" : "go.wh.gov\/HLKiKR"
    } ]
  },
  "geo" : { },
  "id_str" : "524616732997337089",
  "text" : "RT @VP: At 2pm ET, VP Biden will speak on the importance of investing in infrastructure at a @WashingtonPost forum: http:\/\/t.co\/puGk5sHTFR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 85, 100 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/puGk5sHTFR",
        "expanded_url" : "http:\/\/go.wh.gov\/HLKiKR",
        "display_url" : "go.wh.gov\/HLKiKR"
      } ]
    },
    "geo" : { },
    "id_str" : "524616341412909056",
    "text" : "At 2pm ET, VP Biden will speak on the importance of investing in infrastructure at a @WashingtonPost forum: http:\/\/t.co\/puGk5sHTFR",
    "id" : 524616341412909056,
    "created_at" : "2014-10-21 17:40:57 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 524616732997337089,
  "created_at" : "2014-10-21 17:42:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/524569483264806912\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/388AwtDwFd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0elKhNCQAAkn1R.jpg",
      "id_str" : "524569481742270464",
      "id" : 524569481742270464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0elKhNCQAAkn1R.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/388AwtDwFd"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 46, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/kICO4R7GpX",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "524569483264806912",
  "text" : "RT to get the word out: Here are the facts on #Ebola \u2192 http:\/\/t.co\/kICO4R7GpX http:\/\/t.co\/388AwtDwFd",
  "id" : 524569483264806912,
  "created_at" : "2014-10-21 14:34:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 51, 62 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreastCancerAwareness",
      "indices" : [ 16, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/62lsIPCMBl",
      "expanded_url" : "http:\/\/go.wh.gov\/89pmXF",
      "display_url" : "go.wh.gov\/89pmXF"
    } ]
  },
  "geo" : { },
  "id_str" : "524323019422838784",
  "text" : "RT @FLOTUS: For #BreastCancerAwareness, we lit the @WhiteHouse pink. See how you can raise awareness \u2192 http:\/\/t.co\/62lsIPCMBl http:\/\/t.co\/R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 39, 50 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/524321280296640514\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Rhz103nzaK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0bDbO-CAAELFX8.jpg",
        "id_str" : "524321279277400065",
        "id" : 524321279277400065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0bDbO-CAAELFX8.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        } ],
        "display_url" : "pic.twitter.com\/Rhz103nzaK"
      } ],
      "hashtags" : [ {
        "text" : "BreastCancerAwareness",
        "indices" : [ 4, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/62lsIPCMBl",
        "expanded_url" : "http:\/\/go.wh.gov\/89pmXF",
        "display_url" : "go.wh.gov\/89pmXF"
      } ]
    },
    "geo" : { },
    "id_str" : "524321280296640514",
    "text" : "For #BreastCancerAwareness, we lit the @WhiteHouse pink. See how you can raise awareness \u2192 http:\/\/t.co\/62lsIPCMBl http:\/\/t.co\/Rhz103nzaK",
    "id" : 524321280296640514,
    "created_at" : "2014-10-20 22:08:29 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 524323019422838784,
  "created_at" : "2014-10-20 22:15:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/524316321631068161\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/fHHxRLlREj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0a-6m5CYAAiERn.jpg",
      "id_str" : "524316320716709888",
      "id" : 524316320716709888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0a-6m5CYAAiERn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fHHxRLlREj"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 17, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/zmJXkPedWp",
      "expanded_url" : "http:\/\/go.wh.gov\/rh5Jgn",
      "display_url" : "go.wh.gov\/rh5Jgn"
    } ]
  },
  "geo" : { },
  "id_str" : "524316321631068161",
  "text" : "Get the facts on #Ebola, and what we're doing to respond \u2192 http:\/\/t.co\/zmJXkPedWp http:\/\/t.co\/fHHxRLlREj",
  "id" : 524316321631068161,
  "created_at" : "2014-10-20 21:48:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/524277258970607617\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/YTE4qDCfRM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0abY0bCIAA2FPr.jpg",
      "id_str" : "524277257326436352",
      "id" : 524277257326436352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0abY0bCIAA2FPr.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YTE4qDCfRM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524277258970607617",
  "text" : "President Obama just cast his ballot for this year's midterm elections on the first day of early voting in Illinois. http:\/\/t.co\/YTE4qDCfRM",
  "id" : 524277258970607617,
  "created_at" : "2014-10-20 19:13:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/524264961418072064\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/rt8AuTxP1m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0aQNCVCUAE61Vh.jpg",
      "id_str" : "524264960273043457",
      "id" : 524264960273043457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0aQNCVCUAE61Vh.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/rt8AuTxP1m"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/W5SdaoF1wW",
      "expanded_url" : "http:\/\/go.wh.gov\/6TncJ7",
      "display_url" : "go.wh.gov\/6TncJ7"
    } ]
  },
  "geo" : { },
  "id_str" : "524264961418072064",
  "text" : "#Ebola is NOT transmitted through the air &amp; it's a difficult disease to catch. Get the facts: http:\/\/t.co\/W5SdaoF1wW http:\/\/t.co\/rt8AuTxP1m",
  "id" : 524264961418072064,
  "created_at" : "2014-10-20 18:24:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 99, 108 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/524253719991713794\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/6AbCs9CXV2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0aF-wYIYAEo57b.png",
      "id_str" : "524253719819739137",
      "id" : 524253719819739137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0aF-wYIYAEo57b.png",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6AbCs9CXV2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524260668438876161",
  "text" : "RT @USDOL: \"Since Gap announced its pay hike, applications are up 24%. That\u2019s not a coincidence.\" -@LaborSec Perez http:\/\/t.co\/6AbCs9CXV2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 88, 97 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/524253719991713794\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/6AbCs9CXV2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0aF-wYIYAEo57b.png",
        "id_str" : "524253719819739137",
        "id" : 524253719819739137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0aF-wYIYAEo57b.png",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6AbCs9CXV2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "524253719991713794",
    "text" : "\"Since Gap announced its pay hike, applications are up 24%. That\u2019s not a coincidence.\" -@LaborSec Perez http:\/\/t.co\/6AbCs9CXV2",
    "id" : 524253719991713794,
    "created_at" : "2014-10-20 17:40:01 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 524260668438876161,
  "created_at" : "2014-10-20 18:07:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/USDOL\/status\/524248063935016962\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/KXi3h8y5Pd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0aA1iDIAAAbG2h.jpg",
      "id_str" : "524248063796576256",
      "id" : 524248063796576256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0aA1iDIAAAbG2h.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KXi3h8y5Pd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524258755140403200",
  "text" : "RT @USDOL: Perez: \"A majority of small businesses \u2013 support an increase in the minimum wage to $10.10.\" http:\/\/t.co\/KXi3h8y5Pd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USDOL\/status\/524248063935016962\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/KXi3h8y5Pd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B0aA1iDIAAAbG2h.jpg",
        "id_str" : "524248063796576256",
        "id" : 524248063796576256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0aA1iDIAAAbG2h.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KXi3h8y5Pd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "524248063935016962",
    "text" : "Perez: \"A majority of small businesses \u2013 support an increase in the minimum wage to $10.10.\" http:\/\/t.co\/KXi3h8y5Pd",
    "id" : 524248063935016962,
    "created_at" : "2014-10-20 17:17:33 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 524258755140403200,
  "created_at" : "2014-10-20 18:00:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/MyZH2w4tLr",
      "expanded_url" : "http:\/\/vine.co\/v\/Obu7igxO7AQ",
      "display_url" : "vine.co\/v\/Obu7igxO7AQ"
    } ]
  },
  "geo" : { },
  "id_str" : "524217280586981376",
  "text" : "#Ebola is not spread through:\nAir\nWater\nFood in the U.S.\nCasual contact with someone who has no symptoms.\nhttp:\/\/t.co\/MyZH2w4tLr",
  "id" : 524217280586981376,
  "created_at" : "2014-10-20 15:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/524210356269232128\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/61poEPfNC7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0ZeimcIUAAxWPi.jpg",
      "id_str" : "524210355162337280",
      "id" : 524210355162337280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0ZeimcIUAAxWPi.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/61poEPfNC7"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 30, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/zmJXkPedWp",
      "expanded_url" : "http:\/\/go.wh.gov\/rh5Jgn",
      "display_url" : "go.wh.gov\/rh5Jgn"
    } ]
  },
  "geo" : { },
  "id_str" : "524210356269232128",
  "text" : "If you've got questions about #Ebola, read what we're doing to respond &amp; keep Americans safe: http:\/\/t.co\/zmJXkPedWp http:\/\/t.co\/61poEPfNC7",
  "id" : 524210356269232128,
  "created_at" : "2014-10-20 14:47:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 38, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/sbnrch3Zxg",
      "expanded_url" : "http:\/\/go.wh.gov\/iFZ6DN",
      "display_url" : "go.wh.gov\/iFZ6DN"
    } ]
  },
  "geo" : { },
  "id_str" : "523931854995345411",
  "text" : "\"If we want to protect Americans from #Ebola here at home, we have to end it over there.\" \u2014President Obama: http:\/\/t.co\/sbnrch3Zxg",
  "id" : 523931854995345411,
  "created_at" : "2014-10-19 20:21:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/sbnrch3Zxg",
      "expanded_url" : "http:\/\/go.wh.gov\/iFZ6DN",
      "display_url" : "go.wh.gov\/iFZ6DN"
    } ]
  },
  "geo" : { },
  "id_str" : "523901433544859651",
  "text" : "\"Our medical experts tell us that the best way to stop this disease is to stop it at its source.\" \u2014Obama on #Ebola: http:\/\/t.co\/sbnrch3Zxg",
  "id" : 523901433544859651,
  "created_at" : "2014-10-19 18:20:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 103, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/sbnrch3Zxg",
      "expanded_url" : "http:\/\/go.wh.gov\/iFZ6DN",
      "display_url" : "go.wh.gov\/iFZ6DN"
    } ]
  },
  "geo" : { },
  "id_str" : "523871322779045888",
  "text" : "\"The United States will continue to help lead the global response in West Africa.\" \u2014President Obama on #Ebola: http:\/\/t.co\/sbnrch3Zxg",
  "id" : 523871322779045888,
  "created_at" : "2014-10-19 16:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/3YQz0xhv1J",
      "expanded_url" : "http:\/\/go.wh.gov\/jaDYgU",
      "display_url" : "go.wh.gov\/jaDYgU"
    } ]
  },
  "geo" : { },
  "id_str" : "523494909970354176",
  "text" : "\"We know how to fight this disease.\" \u2014President Obama on the U.S. response to #Ebola: http:\/\/t.co\/3YQz0xhv1J",
  "id" : 523494909970354176,
  "created_at" : "2014-10-18 15:24:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 1, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/sbnrch3Zxg",
      "expanded_url" : "http:\/\/go.wh.gov\/iFZ6DN",
      "display_url" : "go.wh.gov\/iFZ6DN"
    } ]
  },
  "geo" : { },
  "id_str" : "523488754892156929",
  "text" : "\"#Ebola is actually a difficult disease to catch. It\u2019s not transmitted through the air like the flu.\" \u2014Obama: http:\/\/t.co\/sbnrch3Zxg",
  "id" : 523488754892156929,
  "created_at" : "2014-10-18 15:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 62, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/sbnrch3Zxg",
      "expanded_url" : "http:\/\/go.wh.gov\/iFZ6DN",
      "display_url" : "go.wh.gov\/iFZ6DN"
    } ]
  },
  "geo" : { },
  "id_str" : "523473633977458688",
  "text" : "President Obama's weekly address: What you need to know about #Ebola \u2192 http:\/\/t.co\/sbnrch3Zxg",
  "id" : 523473633977458688,
  "created_at" : "2014-10-18 14:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 68, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/VNkOfqVc2A",
      "expanded_url" : "http:\/\/go.wh.gov\/CFGitE",
      "display_url" : "go.wh.gov\/CFGitE"
    } ]
  },
  "geo" : { },
  "id_str" : "523278585700696064",
  "text" : "Here's a readout of President Obama\u2019s meeting today on the domestic #Ebola response: http:\/\/t.co\/VNkOfqVc2A",
  "id" : 523278585700696064,
  "created_at" : "2014-10-18 01:05:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/kICO4R7GpX",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    }, {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/p0smNK7JMw",
      "expanded_url" : "https:\/\/vine.co\/v\/Obu7igxO7AQ",
      "display_url" : "vine.co\/v\/Obu7igxO7AQ"
    } ]
  },
  "geo" : { },
  "id_str" : "523258011234488321",
  "text" : "Worth sharing: Here are the facts on #Ebola, and what we're doing to respond \u2192 http:\/\/t.co\/kICO4R7GpX https:\/\/t.co\/p0smNK7JMw",
  "id" : 523258011234488321,
  "created_at" : "2014-10-17 23:43:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/523207203864313856\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/GOFRZxOoB7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0LOLchCAAEZYKQ.jpg",
      "id_str" : "523207202757017601",
      "id" : 523207202757017601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0LOLchCAAEZYKQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GOFRZxOoB7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/riFJ4nS7Wq",
      "expanded_url" : "http:\/\/go.wh.gov\/5qyY1S",
      "display_url" : "go.wh.gov\/5qyY1S"
    } ]
  },
  "geo" : { },
  "id_str" : "523207203864313856",
  "text" : "Here's how President Obama's acting to protect Americans from fraud and identify theft \u2192 http:\/\/t.co\/riFJ4nS7Wq http:\/\/t.co\/GOFRZxOoB7",
  "id" : 523207203864313856,
  "created_at" : "2014-10-17 20:21:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523200199188287489",
  "text" : "RT @VP: There's no one better at getting govt to work at its best than Ron Klain. He's a tested manager &amp; problem-solver, and a trusted adv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "523194431760269312",
    "text" : "There's no one better at getting govt to work at its best than Ron Klain. He's a tested manager &amp; problem-solver, and a trusted advisor. -vp",
    "id" : 523194431760269312,
    "created_at" : "2014-10-17 19:30:47 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 523200199188287489,
  "created_at" : "2014-10-17 19:53:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/523187948141821952\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/XGGRp0vkVE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0K8qnaIAAAxSw6.jpg",
      "id_str" : "523187947047485440",
      "id" : 523187947047485440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0K8qnaIAAAxSw6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XGGRp0vkVE"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 17, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/W5SdaoF1wW",
      "expanded_url" : "http:\/\/go.wh.gov\/6TncJ7",
      "display_url" : "go.wh.gov\/6TncJ7"
    } ]
  },
  "geo" : { },
  "id_str" : "523187948141821952",
  "text" : "Get the facts on #Ebola, and what we're doing to respond \u2192 http:\/\/t.co\/W5SdaoF1wW http:\/\/t.co\/XGGRp0vkVE",
  "id" : 523187948141821952,
  "created_at" : "2014-10-17 19:05:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 67, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/PThM8d5EYF",
      "expanded_url" : "http:\/\/go.wh.gov\/sDoA7G",
      "display_url" : "go.wh.gov\/sDoA7G"
    } ]
  },
  "geo" : { },
  "id_str" : "523158196005773312",
  "text" : "President Obama names Ron Klain to coordinate the U.S. response to #Ebola. Get the latest \u2192 http:\/\/t.co\/PThM8d5EYF",
  "id" : 523158196005773312,
  "created_at" : "2014-10-17 17:06:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523144468749234176",
  "text" : "\"We know this technology works\u2014when Britain switched to a chip-and-pin system, they cut fraud in stores by 70%.\" \u2014President Obama",
  "id" : 523144468749234176,
  "created_at" : "2014-10-17 16:12:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 131, 136 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523143993857564672",
  "text" : "\"We believe that this is a country where hard work should pay off, and responsibility should be rewarded.\" \u2014President Obama at the @CFPB",
  "id" : 523143993857564672,
  "created_at" : "2014-10-17 16:10:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523143616252739585",
  "text" : "RT @WHLive: \"We\u2019re going to make sure that credit cards and...readers issued by the...government come equipped with 2 new layers of protect\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "523143581632970752",
    "text" : "\"We\u2019re going to make sure that credit cards and...readers issued by the...government come equipped with 2 new layers of protection.\" \u2014Obama",
    "id" : 523143581632970752,
    "created_at" : "2014-10-17 16:08:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 523143616252739585,
  "created_at" : "2014-10-17 16:08:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523142885944741888",
  "text" : "\"You should be able to buy the things you need without risking your identity, your credit score, or your savings.\" \u2014Obama on \"Buy Secure\"",
  "id" : 523142885944741888,
  "created_at" : "2014-10-17 16:05:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523142724728287232",
  "text" : "RT @WHLive: \"We\u2019re building on the progress that\u2019s already been made by announcing new measures to protect America from identity theft &amp; fr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "523142699163996160",
    "text" : "\"We\u2019re building on the progress that\u2019s already been made by announcing new measures to protect America from identity theft &amp; fraud.\" \u2014Obama",
    "id" : 523142699163996160,
    "created_at" : "2014-10-17 16:05:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 523142724728287232,
  "created_at" : "2014-10-17 16:05:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523141983900942337",
  "text" : "\u201CWe\u2019ve got an all-hands-on-deck approach across government to keep the American people safe.\u201D \u2014President Obama on #Ebola",
  "id" : 523141983900942337,
  "created_at" : "2014-10-17 16:02:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/DPNJBqrSZ3",
      "expanded_url" : "http:\/\/go.wh.gov\/7aeRgU",
      "display_url" : "go.wh.gov\/7aeRgU"
    } ]
  },
  "geo" : { },
  "id_str" : "523141520950427648",
  "text" : "Watch live: President Obama announces new steps to protect Americans from identity theft and credit card fraud \u2192 http:\/\/t.co\/DPNJBqrSZ3",
  "id" : 523141520950427648,
  "created_at" : "2014-10-17 16:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/DPNJBqrSZ3",
      "expanded_url" : "http:\/\/go.wh.gov\/7aeRgU",
      "display_url" : "go.wh.gov\/7aeRgU"
    } ]
  },
  "geo" : { },
  "id_str" : "523134369037168640",
  "text" : "At 11:50am ET, President Obama announces new steps to protect Americans from identity theft and credit card fraud \u2192 http:\/\/t.co\/DPNJBqrSZ3",
  "id" : 523134369037168640,
  "created_at" : "2014-10-17 15:32:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/0nvjFMBLiu",
      "expanded_url" : "http:\/\/go.wh.gov\/Xva5eD",
      "display_url" : "go.wh.gov\/Xva5eD"
    } ]
  },
  "geo" : { },
  "id_str" : "523119774373392385",
  "text" : "Worth sharing: President Obama on #Ebola, and how we're responding \u2192 http:\/\/t.co\/0nvjFMBLiu",
  "id" : 523119774373392385,
  "created_at" : "2014-10-17 14:34:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522837302330929153\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ibp8Zau97X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0F9wXoCEAAABRQ.jpg",
      "id_str" : "522837301680803840",
      "id" : 522837301680803840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0F9wXoCEAAABRQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ibp8Zau97X"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/T6b7NnZu0k",
      "expanded_url" : "http:\/\/youtu.be\/5ZxrE6orp2A",
      "display_url" : "youtu.be\/5ZxrE6orp2A"
    } ]
  },
  "geo" : { },
  "id_str" : "522837302330929153",
  "text" : "\"It is not like the flu. It is not airborne.\" \u2014President Obama on #Ebola: http:\/\/t.co\/T6b7NnZu0k http:\/\/t.co\/ibp8Zau97X",
  "id" : 522837302330929153,
  "created_at" : "2014-10-16 19:51:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/inASV38E7u",
      "expanded_url" : "http:\/\/youtu.be\/5ZxrE6orp2A",
      "display_url" : "youtu.be\/5ZxrE6orp2A"
    } ]
  },
  "geo" : { },
  "id_str" : "522820733987487746",
  "text" : "Watch President Obama give an update on #Ebola and what we're doing to respond \u2192 http:\/\/t.co\/inASV38E7u",
  "id" : 522820733987487746,
  "created_at" : "2014-10-16 18:45:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522786515471319040\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Xg0PKQVO0S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0FPkLKCQAEjKNW.jpg",
      "id_str" : "522786514640453633",
      "id" : 522786514640453633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0FPkLKCQAEjKNW.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Xg0PKQVO0S"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 36, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/RMFwal2IB8",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "522786515471319040",
  "text" : "See why the chances of a widespread #Ebola outbreak in the U.S. are extraordinarily low \u2192 http:\/\/t.co\/RMFwal2IB8 http:\/\/t.co\/Xg0PKQVO0S",
  "id" : 522786515471319040,
  "created_at" : "2014-10-16 16:29:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522771622181494785\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/UJLnOsP7RV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0FCBR3CEAACAAw.jpg",
      "id_str" : "522771621493215232",
      "id" : 522771621493215232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0FCBR3CEAACAAw.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/UJLnOsP7RV"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/RMFwal2IB8",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "522771622181494785",
  "text" : "Worth sharing: Here are the facts on #Ebola, and what we're doing to respond \u2192 http:\/\/t.co\/RMFwal2IB8 http:\/\/t.co\/UJLnOsP7RV",
  "id" : 522771622181494785,
  "created_at" : "2014-10-16 15:30:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522760140920213504\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/KR25pBZvaR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0E3k9zCMAAilok.jpg",
      "id_str" : "522760139955122176",
      "id" : 522760139955122176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0E3k9zCMAAilok.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KR25pBZvaR"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 46, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/RMFwal2IB8",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "522760140920213504",
  "text" : "RT to get the word out: Here are the facts on #Ebola: http:\/\/t.co\/RMFwal2IB8 http:\/\/t.co\/KR25pBZvaR",
  "id" : 522760140920213504,
  "created_at" : "2014-10-16 14:45:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522541670769131520\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/O8wQVvNnDF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0Bw4UXCIAAb6Yz.jpg",
      "id_str" : "522541669615280128",
      "id" : 522541669615280128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0Bw4UXCIAAb6Yz.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/O8wQVvNnDF"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/xboYB3vX1A",
      "expanded_url" : "http:\/\/go.wh.gov\/BobSQm",
      "display_url" : "go.wh.gov\/BobSQm"
    } ]
  },
  "geo" : { },
  "id_str" : "522541670769131520",
  "text" : "\"The dangers of a serious outbreak are extraordinarily low.\" \u2014Obama on #Ebola in the U.S.: http:\/\/t.co\/xboYB3vX1A http:\/\/t.co\/O8wQVvNnDF",
  "id" : 522541670769131520,
  "created_at" : "2014-10-16 00:16:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522517314520895489\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/qb1i3qb5uF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0BSyFXCQAAqy_-.jpg",
      "id_str" : "522508577160708096",
      "id" : 522508577160708096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0BSyFXCQAAqy_-.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qb1i3qb5uF"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 6, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/kICO4R7GpX",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "522517314520895489",
  "text" : "FACT: #Ebola ONLY spreads when people are showing symptoms. Learn more \u2192 http:\/\/t.co\/kICO4R7GpX http:\/\/t.co\/qb1i3qb5uF",
  "id" : 522517314520895489,
  "created_at" : "2014-10-15 22:40:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebola",
      "indices" : [ 36, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522514380672360448",
  "text" : "RT @SecBurwell: We know how to stop #ebola. We are learning from our experiences &amp; redoubling our efforts to improve procedures addressing \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ebola",
        "indices" : [ 20, 26 ]
      }, {
        "text" : "ebola",
        "indices" : [ 127, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "522504885518864384",
    "text" : "We know how to stop #ebola. We are learning from our experiences &amp; redoubling our efforts to improve procedures addressing #ebola in U.S.",
    "id" : 522504885518864384,
    "created_at" : "2014-10-15 21:50:47 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 522514380672360448,
  "created_at" : "2014-10-15 22:28:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/522512250305662976\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/3QkxgUI9Ic",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0BS-_RCYAEPPc5.jpg",
      "id_str" : "522508798863237121",
      "id" : 522508798863237121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0BS-_RCYAEPPc5.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/3QkxgUI9Ic"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/kICO4R7GpX",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "522512250305662976",
  "text" : "#Ebola is NOT spread through:\n1. Casual contact\n2. Air\n3. Water\n4. Food in the U.S.\nhttp:\/\/t.co\/kICO4R7GpX http:\/\/t.co\/3QkxgUI9Ic",
  "id" : 522512250305662976,
  "created_at" : "2014-10-15 22:20:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522507657874526208\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/oDBVA1SG2N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0BR8h9CIAImuy3.jpg",
      "id_str" : "522507657123340290",
      "id" : 522507657123340290,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0BR8h9CIAImuy3.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oDBVA1SG2N"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 17, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/RMFwal2IB8",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "522507657874526208",
  "text" : "Get the facts on #Ebola, and what we're doing to respond \u2192 http:\/\/t.co\/RMFwal2IB8 http:\/\/t.co\/oDBVA1SG2N",
  "id" : 522507657874526208,
  "created_at" : "2014-10-15 22:01:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522427997039915008",
  "text" : "RT @pfeiffer44: Later this afternoon,POTUS will convene a meeting at the White House of cabinet agencies coordinating the government\u2019s Ebol\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "522418436614672385",
    "text" : "Later this afternoon,POTUS will convene a meeting at the White House of cabinet agencies coordinating the government\u2019s Ebola response",
    "id" : 522418436614672385,
    "created_at" : "2014-10-15 16:07:16 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 522427997039915008,
  "created_at" : "2014-10-15 16:45:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522409350300979200\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/QgIWD1Aafd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz_4iRlCIAAQ5sB.jpg",
      "id_str" : "522409349516238848",
      "id" : 522409349516238848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz_4iRlCIAAQ5sB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QgIWD1Aafd"
    } ],
    "hashtags" : [ {
      "text" : "Progress",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/oakiNwd9Ib",
      "expanded_url" : "http:\/\/go.wh.gov\/ndbCaz",
      "display_url" : "go.wh.gov\/ndbCaz"
    } ]
  },
  "geo" : { },
  "id_str" : "522409350300979200",
  "text" : "FACT: Since December, the number of long-term unemployed has dropped by 900,000 \u2192 http:\/\/t.co\/oakiNwd9Ib #Progress http:\/\/t.co\/QgIWD1Aafd",
  "id" : 522409350300979200,
  "created_at" : "2014-10-15 15:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 79, 88 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 112, 119 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskTheFirstLady",
      "indices" : [ 46, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/PoJuNOQBLt",
      "expanded_url" : "https:\/\/vine.co\/v\/Oqi0w22OeDX",
      "display_url" : "vine.co\/v\/Oqi0w22OeDX"
    } ]
  },
  "geo" : { },
  "id_str" : "522152279844335616",
  "text" : "RT @FLOTUS: The First Lady just answered your #AskTheFirstLady questions about @LetsMove! Follow the Q&amp;A on @FLOTUS. https:\/\/t.co\/PoJuNOQBLt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 67, 76 ],
        "id_str" : "36719281",
        "id" : 36719281
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 100, 107 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskTheFirstLady",
        "indices" : [ 34, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/PoJuNOQBLt",
        "expanded_url" : "https:\/\/vine.co\/v\/Oqi0w22OeDX",
        "display_url" : "vine.co\/v\/Oqi0w22OeDX"
      } ]
    },
    "geo" : { },
    "id_str" : "522152193785597952",
    "text" : "The First Lady just answered your #AskTheFirstLady questions about @LetsMove! Follow the Q&amp;A on @FLOTUS. https:\/\/t.co\/PoJuNOQBLt",
    "id" : 522152193785597952,
    "created_at" : "2014-10-14 22:29:18 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 522152279844335616,
  "created_at" : "2014-10-14 22:29:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522126364313681920\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/2Fz7pcGcnb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz73KQGCQAEqvA6.jpg",
      "id_str" : "522126362312589313",
      "id" : 522126362312589313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz73KQGCQAEqvA6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2Fz7pcGcnb"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522126364313681920",
  "text" : "RT if you agree: Women should earn the same pay as men for doing the same work.\nPeriod.\n#EqualPay http:\/\/t.co\/2Fz7pcGcnb",
  "id" : 522126364313681920,
  "created_at" : "2014-10-14 20:46:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522114699413180416\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/dKKVafx5NX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz7sjQ0CIAAi26F.jpg",
      "id_str" : "522114697374343168",
      "id" : 522114697374343168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz7sjQ0CIAAi26F.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dKKVafx5NX"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522114699413180416",
  "text" : "Women make less than men in almost every field 4 years after graduation. It's time to change that. #EqualPay http:\/\/t.co\/dKKVafx5NX",
  "id" : 522114699413180416,
  "created_at" : "2014-10-14 20:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522091806000156672\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/cG3Pi9b5Ry",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz7XuxJCEAAsfZD.jpg",
      "id_str" : "522091805286731776",
      "id" : 522091805286731776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz7XuxJCEAAsfZD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cG3Pi9b5Ry"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522091806000156672",
  "text" : "President Obama's taken steps to help ensure #EqualPay, but Republicans in Congress are blocking further action. http:\/\/t.co\/cG3Pi9b5Ry",
  "id" : 522091806000156672,
  "created_at" : "2014-10-14 18:29:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522081767596240897\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/lqItXmfx31",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz7OmZuCcAAHNTo.jpg",
      "id_str" : "522081765955891200",
      "id" : 522081765955891200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz7OmZuCcAAHNTo.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lqItXmfx31"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522081767596240897",
  "text" : "Our daughters should be treated the same as our sons.\nIt's time to ensure #EqualPay for women. http:\/\/t.co\/lqItXmfx31",
  "id" : 522081767596240897,
  "created_at" : "2014-10-14 17:49:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rhode Island College",
      "screen_name" : "RICNews",
      "indices" : [ 43, 51 ],
      "id_str" : "108657550",
      "id" : 108657550
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522075706222981121\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KiZL6XeCL9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz7JFo-CIAAbKYK.jpg",
      "id_str" : "522075705555689472",
      "id" : 522075705555689472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz7JFo-CIAAbKYK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KiZL6XeCL9"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 92, 105 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522075706222981121",
  "text" : "On Thursday, President Obama will speak at @RICNews on the importance of policies that help #WomenSucceed. #EqualPay http:\/\/t.co\/KiZL6XeCL9",
  "id" : 522075706222981121,
  "created_at" : "2014-10-14 17:25:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/522058553524490240\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/uy5awRcQuk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz65fNzCQAE3qEx.jpg",
      "id_str" : "522058552752357377",
      "id" : 522058552752357377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz65fNzCQAE3qEx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uy5awRcQuk"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/8C1DNtjqxY",
      "expanded_url" : "http:\/\/go.wh.gov\/XDJUkX",
      "display_url" : "go.wh.gov\/XDJUkX"
    } ]
  },
  "geo" : { },
  "id_str" : "522058553524490240",
  "text" : "Raising the minimum wage would help millions of Americans. Read their stories \u2192 http:\/\/t.co\/8C1DNtjqxY #RaiseTheWage http:\/\/t.co\/uy5awRcQuk",
  "id" : 522058553524490240,
  "created_at" : "2014-10-14 16:17:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Yhze6FCj6K",
      "expanded_url" : "http:\/\/youtu.be\/PqtLQgkcUFM",
      "display_url" : "youtu.be\/PqtLQgkcUFM"
    } ]
  },
  "geo" : { },
  "id_str" : "522049484340363264",
  "text" : "\"Today, the minimum wage buys you about 20% less than it did in 1981.\"\nWatch \u2192 http:\/\/t.co\/Yhze6FCj6K #RaiseTheWage",
  "id" : 522049484340363264,
  "created_at" : "2014-10-14 15:41:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Yhze6FCj6K",
      "expanded_url" : "http:\/\/youtu.be\/PqtLQgkcUFM",
      "display_url" : "youtu.be\/PqtLQgkcUFM"
    } ]
  },
  "geo" : { },
  "id_str" : "522038613715222528",
  "text" : "Why we need to raise the minimum wage, in less than 2 minutes.\nWatch \u2192 http:\/\/t.co\/Yhze6FCj6K #RaiseTheWage",
  "id" : 522038613715222528,
  "created_at" : "2014-10-14 14:57:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 57, 66 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 75, 86 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Vine",
      "screen_name" : "vine",
      "indices" : [ 97, 102 ],
      "id_str" : "586671909",
      "id" : 586671909
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskTheFirstLady",
      "indices" : [ 34, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521798083370569729",
  "text" : "RT @FLOTUS: There\u2019s still time to #AskTheFirstLady about @LetsMove and the @WhiteHouse garden on @Vine. She\u2019ll answer tomorrow! https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 45, 54 ],
        "id_str" : "36719281",
        "id" : 36719281
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 63, 74 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Vine",
        "screen_name" : "vine",
        "indices" : [ 85, 90 ],
        "id_str" : "586671909",
        "id" : 586671909
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskTheFirstLady",
        "indices" : [ 22, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/wJ8OXBG9NR",
        "expanded_url" : "https:\/\/vine.co\/v\/OAYd7dWtH3u",
        "display_url" : "vine.co\/v\/OAYd7dWtH3u"
      } ]
    },
    "geo" : { },
    "id_str" : "521770530048065538",
    "text" : "There\u2019s still time to #AskTheFirstLady about @LetsMove and the @WhiteHouse garden on @Vine. She\u2019ll answer tomorrow! https:\/\/t.co\/wJ8OXBG9NR",
    "id" : 521770530048065538,
    "created_at" : "2014-10-13 21:12:43 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 521798083370569729,
  "created_at" : "2014-10-13 23:02:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 32, 39 ],
      "id_str" : "146569971",
      "id" : 146569971
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 41, 48 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/521790482431873024\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ztXWQ4IBkk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz3FrbKIEAAUavu.jpg",
      "id_str" : "521790481660121088",
      "id" : 521790481660121088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz3FrbKIEAAUavu.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ztXWQ4IBkk"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521790482431873024",
  "text" : "Today, President Obama met with @CDCGov, @HHSGov, and his national security team to receive an update on #Ebola. http:\/\/t.co\/ztXWQ4IBkk",
  "id" : 521790482431873024,
  "created_at" : "2014-10-13 22:32:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/521752631552012288\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/VFQcyL4eAF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz2jQNrIIAEhbq8.jpg",
      "id_str" : "521752630788628481",
      "id" : 521752630788628481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz2jQNrIIAEhbq8.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 430
      } ],
      "display_url" : "pic.twitter.com\/VFQcyL4eAF"
    } ],
    "hashtags" : [ {
      "text" : "239NavyBday",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521787714912665601",
  "text" : "RT @DrBiden: Happy #239NavyBday! Thank you to all those who serve. -Jill http:\/\/t.co\/VFQcyL4eAF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/521752631552012288\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/VFQcyL4eAF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz2jQNrIIAEhbq8.jpg",
        "id_str" : "521752630788628481",
        "id" : 521752630788628481,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz2jQNrIIAEhbq8.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 430
        } ],
        "display_url" : "pic.twitter.com\/VFQcyL4eAF"
      } ],
      "hashtags" : [ {
        "text" : "239NavyBday",
        "indices" : [ 6, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "521752631552012288",
    "text" : "Happy #239NavyBday! Thank you to all those who serve. -Jill http:\/\/t.co\/VFQcyL4eAF",
    "id" : 521752631552012288,
    "created_at" : "2014-10-13 20:01:35 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 521787714912665601,
  "created_at" : "2014-10-13 22:21:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ih5xpIyRNt",
      "expanded_url" : "http:\/\/go.wh.gov\/cGmU9P",
      "display_url" : "go.wh.gov\/cGmU9P"
    } ]
  },
  "geo" : { },
  "id_str" : "521752320392966144",
  "text" : "\u201CA changing climate will have real impacts on our military &amp; the way it executes its missions.\u201D \u2014Hagel: http:\/\/t.co\/ih5xpIyRNt #ActOnClimate",
  "id" : 521752320392966144,
  "created_at" : "2014-10-13 20:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 41, 55 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ih5xpIyRNt",
      "expanded_url" : "http:\/\/go.wh.gov\/cGmU9P",
      "display_url" : "go.wh.gov\/cGmU9P"
    } ]
  },
  "geo" : { },
  "id_str" : "521726845721399297",
  "text" : "Worth a read: Secretary Hagel on why the @DeptOfDefense is planning for the security implications of climate change \u2192 http:\/\/t.co\/ih5xpIyRNt",
  "id" : 521726845721399297,
  "created_at" : "2014-10-13 18:19:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/521457838187507712\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/51tVNH0ghl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzyCwcZCMAA2u9B.jpg",
      "id_str" : "521435425634660352",
      "id" : 521435425634660352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzyCwcZCMAA2u9B.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/51tVNH0ghl"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 17, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/855MF8bD8y",
      "expanded_url" : "http:\/\/go.wh.gov\/mXqr91",
      "display_url" : "go.wh.gov\/mXqr91"
    } ]
  },
  "geo" : { },
  "id_str" : "521457838187507712",
  "text" : "Get the facts on #Ebola, and our response to the epidemic in West Africa \u2192 http:\/\/t.co\/855MF8bD8y http:\/\/t.co\/51tVNH0ghl",
  "id" : 521457838187507712,
  "created_at" : "2014-10-13 00:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520334467014356992\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/5t2vMf9WpE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BziZcLyCQAIN108.jpg",
      "id_str" : "520334466439331842",
      "id" : 520334466439331842,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BziZcLyCQAIN108.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5t2vMf9WpE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/j3jcbdixgF",
      "expanded_url" : "http:\/\/go.wh.gov\/xFix6C",
      "display_url" : "go.wh.gov\/xFix6C"
    } ]
  },
  "geo" : { },
  "id_str" : "521435227848065026",
  "text" : "\"For the first time in more than 6 years, the unemployment rate is below 6%.\" \u2014Obama: http:\/\/t.co\/j3jcbdixgF http:\/\/t.co\/5t2vMf9WpE",
  "id" : 521435227848065026,
  "created_at" : "2014-10-12 23:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520702110208622592\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/95wcf32XE1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bznnz1KCcAATZwa.jpg",
      "id_str" : "520702109566529536",
      "id" : 520702109566529536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bznnz1KCcAATZwa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/95wcf32XE1"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/j3jcbdixgF",
      "expanded_url" : "http:\/\/go.wh.gov\/xFix6C",
      "display_url" : "go.wh.gov\/xFix6C"
    } ]
  },
  "geo" : { },
  "id_str" : "521382352614735872",
  "text" : "\"America should forever be a place where your hard work is rewarded.\" \u2014Obama: http:\/\/t.co\/j3jcbdixgF #RaiseTheWage http:\/\/t.co\/95wcf32XE1",
  "id" : 521382352614735872,
  "created_at" : "2014-10-12 19:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 40, 47 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/521366801012510720\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/TBTrTFPpl5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzxEV62CEAE73RP.jpg",
      "id_str" : "521366800231960577",
      "id" : 521366800231960577,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzxEV62CEAE73RP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TBTrTFPpl5"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521366801012510720",
  "text" : "President Obama talks on the phone with @HHSGov Secretary Burwell concerning the latest update on #Ebola. http:\/\/t.co\/TBTrTFPpl5",
  "id" : 521366801012510720,
  "created_at" : "2014-10-12 18:28:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/nT4QCYQnY9",
      "expanded_url" : "http:\/\/go.wh.gov\/xFix6C",
      "display_url" : "go.wh.gov\/xFix6C"
    } ]
  },
  "geo" : { },
  "id_str" : "521344499558408192",
  "text" : "\"Raising the federal minimum wage to $10.10 an hour, or ten-ten, would benefit 28 million American workers.\" \u2014Obama: http:\/\/t.co\/nT4QCYQnY9",
  "id" : 521344499558408192,
  "created_at" : "2014-10-12 16:59:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayOfTheGirl",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/abDUcJox75",
      "expanded_url" : "http:\/\/go.wh.gov\/Q1h3Mx",
      "display_url" : "go.wh.gov\/Q1h3Mx"
    } ]
  },
  "geo" : { },
  "id_str" : "521095420257112064",
  "text" : "\"We cannot allow violence to snuff out the aspirations of young women.\" \u2014President Obama: http:\/\/t.co\/abDUcJox75 #DayOfTheGirl",
  "id" : 521095420257112064,
  "created_at" : "2014-10-12 00:30:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/j3jcbdixgF",
      "expanded_url" : "http:\/\/go.wh.gov\/xFix6C",
      "display_url" : "go.wh.gov\/xFix6C"
    } ]
  },
  "geo" : { },
  "id_str" : "521072807485009920",
  "text" : "\"A worker on the federal minimum wage earns $7.25\/hour. It\u2019s time to raise that to $10.10\/hour\" \u2014Obama: http:\/\/t.co\/j3jcbdixgF #RaiseTheWage",
  "id" : 521072807485009920,
  "created_at" : "2014-10-11 23:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayOfTheGirl",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/abDUcJox75",
      "expanded_url" : "http:\/\/go.wh.gov\/Q1h3Mx",
      "display_url" : "go.wh.gov\/Q1h3Mx"
    } ]
  },
  "geo" : { },
  "id_str" : "521035049638973440",
  "text" : "\"When girls and women are fully valued as equal...societies are more likely to succeed.\" \u2014Obama: http:\/\/t.co\/abDUcJox75 #DayOfTheGirl",
  "id" : 521035049638973440,
  "created_at" : "2014-10-11 20:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/j3jcbdixgF",
      "expanded_url" : "http:\/\/go.wh.gov\/xFix6C",
      "display_url" : "go.wh.gov\/xFix6C"
    } ]
  },
  "geo" : { },
  "id_str" : "521012406818856961",
  "text" : "\"Nobody who works full-time should ever have to raise a family in poverty.\" \u2014President Obama: http:\/\/t.co\/j3jcbdixgF #RaiseTheWage",
  "id" : 521012406818856961,
  "created_at" : "2014-10-11 19:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayOfTheGirl",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/PfHxz2fvh2",
      "expanded_url" : "http:\/\/go.wh.gov\/Q1h3Mx",
      "display_url" : "go.wh.gov\/Q1h3Mx"
    } ]
  },
  "geo" : { },
  "id_str" : "520993914304880640",
  "text" : "\"Girls and women should have the opportunity to learn, grow, and achieve their full potential.\" \u2014Obama: http:\/\/t.co\/PfHxz2fvh2 #DayOfTheGirl",
  "id" : 520993914304880640,
  "created_at" : "2014-10-11 17:46:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/519151412857425920\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/FjCsB0bysb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzRhVkpCAAA5tbv.jpg",
      "id_str" : "519146880295370752",
      "id" : 519146880295370752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzRhVkpCAAA5tbv.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FjCsB0bysb"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/nT4QCYQnY9",
      "expanded_url" : "http:\/\/go.wh.gov\/xFix6C",
      "display_url" : "go.wh.gov\/xFix6C"
    } ]
  },
  "geo" : { },
  "id_str" : "520943835980242944",
  "text" : "\"America deserves a raise right now.\" \u2014President Obama: http:\/\/t.co\/nT4QCYQnY9 #RaiseTheWage http:\/\/t.co\/FjCsB0bysb",
  "id" : 520943835980242944,
  "created_at" : "2014-10-11 14:27:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/520702110208622592\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/95wcf32XE1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bznnz1KCcAATZwa.jpg",
      "id_str" : "520702109566529536",
      "id" : 520702109566529536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bznnz1KCcAATZwa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/95wcf32XE1"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520702110208622592",
  "text" : "Raising the minimum wage would benefit millions of Americans.\nRT if you agree it's time to #RaiseTheWage. http:\/\/t.co\/95wcf32XE1",
  "id" : 520702110208622592,
  "created_at" : "2014-10-10 22:27:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MonumentsMatter",
      "indices" : [ 111, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520675855102922752",
  "text" : "RT @WhiteHouseCEQ: President Obama just signed the proclamation designating the San Gabriels National Monument #MonumentsMatter http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouseCEQ\/status\/520674387356549120\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/JgqJtT7rHB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BznOmJOCEAA3PEC.jpg",
        "id_str" : "520674386643128320",
        "id" : 520674386643128320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BznOmJOCEAA3PEC.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JgqJtT7rHB"
      } ],
      "hashtags" : [ {
        "text" : "MonumentsMatter",
        "indices" : [ 92, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520674387356549120",
    "text" : "President Obama just signed the proclamation designating the San Gabriels National Monument #MonumentsMatter http:\/\/t.co\/JgqJtT7rHB",
    "id" : 520674387356549120,
    "created_at" : "2014-10-10 20:37:02 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 520675855102922752,
  "created_at" : "2014-10-10 20:42:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520673707497623552",
  "text" : "\"We are blessed to have the most beautiful landscapes in the world. We have a responsibility to be good stewards of them.\" \u2014President Obama",
  "id" : 520673707497623552,
  "created_at" : "2014-10-10 20:34:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520672978611494912\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/zuGFFfWUKL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BznNUJGCEAAXp-Z.jpg",
      "id_str" : "520672977860300800",
      "id" : 520672977860300800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BznNUJGCEAAXp-Z.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zuGFFfWUKL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520672978611494912",
  "text" : "\"As President, I\u2019ve now preserved more than 3 million acres of public lands for future generations.\" \u2014President Obama http:\/\/t.co\/zuGFFfWUKL",
  "id" : 520672978611494912,
  "created_at" : "2014-10-10 20:31:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520672605062594560\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/lLzZHl3llp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BznM-ZsCQAAuhDi.jpg",
      "id_str" : "520672604357541888",
      "id" : 520672604357541888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BznM-ZsCQAAuhDi.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lLzZHl3llp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520672605062594560",
  "text" : "\"These mountains provide residents with roughly 30% of their water and 70% of their open space.\" \u2014President Obama http:\/\/t.co\/lLzZHl3llp",
  "id" : 520672605062594560,
  "created_at" : "2014-10-10 20:29:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520671701265575937\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/VfNYR4DaBr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BznMJyeCYAAyOwo.jpg",
      "id_str" : "520671700476649472",
      "id" : 520671700476649472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BznMJyeCYAAyOwo.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VfNYR4DaBr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520671701265575937",
  "text" : "\"Today, I\u2019m using my executive authority to designate the San Gabriel Mountains as a National Monument.\" \u2014Obama http:\/\/t.co\/VfNYR4DaBr",
  "id" : 520671701265575937,
  "created_at" : "2014-10-10 20:26:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520671081674604545\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/J7FzcoCBsX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BznLluNCMAACnZI.jpg",
      "id_str" : "520671080856301568",
      "id" : 520671080856301568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BznLluNCMAACnZI.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1125,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/J7FzcoCBsX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/cEZi4IdGwe",
      "expanded_url" : "http:\/\/go.wh.gov\/G7iQMj",
      "display_url" : "go.wh.gov\/G7iQMj"
    } ]
  },
  "geo" : { },
  "id_str" : "520671081674604545",
  "text" : "Watch live: President Obama designates the San Gabriel Mountains a National Monument \u2192 http:\/\/t.co\/cEZi4IdGwe http:\/\/t.co\/J7FzcoCBsX",
  "id" : 520671081674604545,
  "created_at" : "2014-10-10 20:23:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Jack Reed",
      "screen_name" : "SenJackReed",
      "indices" : [ 3, 15 ],
      "id_str" : "486694111",
      "id" : 486694111
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 23, 36 ]
    }, {
      "text" : "With1010",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520669637105971200",
  "text" : "RT @SenJackReed: If we #RaiseTheWage for working families it grows our economy. Hard work deserves fair pay. It's time to go #With1010 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenJackReed\/status\/520668391305379841\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/CdhFGpxm7H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BznJJIDCUAA-RoO.jpg",
        "id_str" : "520668390554226688",
        "id" : 520668390554226688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BznJJIDCUAA-RoO.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CdhFGpxm7H"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 6, 19 ]
      }, {
        "text" : "With1010",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520668391305379841",
    "text" : "If we #RaiseTheWage for working families it grows our economy. Hard work deserves fair pay. It's time to go #With1010 http:\/\/t.co\/CdhFGpxm7H",
    "id" : 520668391305379841,
    "created_at" : "2014-10-10 20:13:12 +0000",
    "user" : {
      "name" : "Senator Jack Reed",
      "screen_name" : "SenJackReed",
      "protected" : false,
      "id_str" : "486694111",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/611042380846907393\/L-JV9zuJ_normal.jpg",
      "id" : 486694111,
      "verified" : true
    }
  },
  "id" : 520669637105971200,
  "created_at" : "2014-10-10 20:18:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520658799620030464\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/oFzYk27Zxq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BznAa0mCYAA8Tuv.jpg",
      "id_str" : "520658798965317632",
      "id" : 520658798965317632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BznAa0mCYAA8Tuv.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oFzYk27Zxq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/cEZi4IdGwe",
      "expanded_url" : "http:\/\/go.wh.gov\/G7iQMj",
      "display_url" : "go.wh.gov\/G7iQMj"
    } ]
  },
  "geo" : { },
  "id_str" : "520658799620030464",
  "text" : "At 3:40pm ET, President Obama designates the San Gabriel Mountains National Monument \u2192 http:\/\/t.co\/cEZi4IdGwe http:\/\/t.co\/oFzYk27Zxq",
  "id" : 520658799620030464,
  "created_at" : "2014-10-10 19:35:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/520650122800422913\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/78JGcWlIbF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzm4hwICYAECQDJ.jpg",
      "id_str" : "520650121931808769",
      "id" : 520650121931808769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzm4hwICYAECQDJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/78JGcWlIbF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/UzTFiqOiEd",
      "expanded_url" : "http:\/\/go.wh.gov\/fnDVDh",
      "display_url" : "go.wh.gov\/fnDVDh"
    } ]
  },
  "geo" : { },
  "id_str" : "520650122800422913",
  "text" : "President Obama's acting to protect drinking water and open spaces for millions of Americans. http:\/\/t.co\/UzTFiqOiEd http:\/\/t.co\/78JGcWlIbF",
  "id" : 520650122800422913,
  "created_at" : "2014-10-10 19:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NobelPeacePrize",
      "indices" : [ 117, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/M8cl2NkmPC",
      "expanded_url" : "http:\/\/cnn.it\/1C0Xj1o",
      "display_url" : "cnn.it\/1C0Xj1o"
    } ]
  },
  "geo" : { },
  "id_str" : "520647848367775744",
  "text" : "RT @DrBiden: One courageous girl can change the world \u2192 http:\/\/t.co\/M8cl2NkmPC Congratulations Malala on winning the #NobelPeacePrize! -Jill",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NobelPeacePrize",
        "indices" : [ 104, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/M8cl2NkmPC",
        "expanded_url" : "http:\/\/cnn.it\/1C0Xj1o",
        "display_url" : "cnn.it\/1C0Xj1o"
      } ]
    },
    "geo" : { },
    "id_str" : "520642848707063809",
    "text" : "One courageous girl can change the world \u2192 http:\/\/t.co\/M8cl2NkmPC Congratulations Malala on winning the #NobelPeacePrize! -Jill",
    "id" : 520642848707063809,
    "created_at" : "2014-10-10 18:31:42 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 520647848367775744,
  "created_at" : "2014-10-10 18:51:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "indices" : [ 3, 14 ],
      "id_str" : "17494010",
      "id" : 17494010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "With1010",
      "indices" : [ 16, 25 ]
    }, {
      "text" : "MinimumWage",
      "indices" : [ 45, 57 ]
    }, {
      "text" : "WomenSucceed",
      "indices" : [ 81, 94 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520644274002886656",
  "text" : "RT @SenSchumer: #With1010 we can pass a fair #MinimumWage &amp; help millions of #WomenSucceed RT if you're ready to #RaiseTheWage http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenSchumer\/status\/520641805474611200\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/SGhCGfljuC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzmw9lmCYAA1UoK.jpg",
        "id_str" : "520641804048162816",
        "id" : 520641804048162816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzmw9lmCYAA1UoK.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/SGhCGfljuC"
      } ],
      "hashtags" : [ {
        "text" : "With1010",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "MinimumWage",
        "indices" : [ 29, 41 ]
      }, {
        "text" : "WomenSucceed",
        "indices" : [ 65, 78 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520641805474611200",
    "text" : "#With1010 we can pass a fair #MinimumWage &amp; help millions of #WomenSucceed RT if you're ready to #RaiseTheWage http:\/\/t.co\/SGhCGfljuC",
    "id" : 520641805474611200,
    "created_at" : "2014-10-10 18:27:34 +0000",
    "user" : {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "protected" : false,
      "id_str" : "17494010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623955176131575808\/zWzgRP4C_normal.jpg",
      "id" : 17494010,
      "verified" : true
    }
  },
  "id" : 520644274002886656,
  "created_at" : "2014-10-10 18:37:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 3, 8 ],
      "id_str" : "61853389",
      "id" : 61853389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/uiQRJdcHcB",
      "expanded_url" : "http:\/\/ow.ly\/CzPY1",
      "display_url" : "ow.ly\/CzPY1"
    } ]
  },
  "geo" : { },
  "id_str" : "520641759974809600",
  "text" : "RT @USDA: A $10.10 minimum wage saves $46B in SNAP spending over 10 yrs, cutting taxpayer costs in every state http:\/\/t.co\/uiQRJdcHcB #Rais\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 124, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/uiQRJdcHcB",
        "expanded_url" : "http:\/\/ow.ly\/CzPY1",
        "display_url" : "ow.ly\/CzPY1"
      } ]
    },
    "geo" : { },
    "id_str" : "520636520085323777",
    "text" : "A $10.10 minimum wage saves $46B in SNAP spending over 10 yrs, cutting taxpayer costs in every state http:\/\/t.co\/uiQRJdcHcB #RaiseTheWage",
    "id" : 520636520085323777,
    "created_at" : "2014-10-10 18:06:34 +0000",
    "user" : {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "protected" : false,
      "id_str" : "61853389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475696751\/bf524afc612e7aa534d6c543a3d3e144_normal.jpeg",
      "id" : 61853389,
      "verified" : true
    }
  },
  "id" : 520641759974809600,
  "created_at" : "2014-10-10 18:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520634727142023168\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/98aVGOPRj1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzmqhnACcAA2bJj.png",
      "id_str" : "520634726319550464",
      "id" : 520634726319550464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzmqhnACcAA2bJj.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 138,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 461,
        "resize" : "fit",
        "w" : 1134
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/98aVGOPRj1"
    } ],
    "hashtags" : [ {
      "text" : "NobelPeacePrize",
      "indices" : [ 78, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520634727142023168",
  "text" : "\"I want to congratulate Malala Yousafzai and Kailash Satyarthi on winning the #NobelPeacePrize.\" \u2014President Obama http:\/\/t.co\/98aVGOPRj1",
  "id" : 520634727142023168,
  "created_at" : "2014-10-10 17:59:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520624423544823810\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/UlecuqBJQs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzmhJ0bCIAAGJtM.jpg",
      "id_str" : "520624422000926720",
      "id" : 520624422000926720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzmhJ0bCIAAGJtM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UlecuqBJQs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/UzTFiqOiEd",
      "expanded_url" : "http:\/\/go.wh.gov\/fnDVDh",
      "display_url" : "go.wh.gov\/fnDVDh"
    } ]
  },
  "geo" : { },
  "id_str" : "520624423544823810",
  "text" : "Today, President Obama will designate the San Gabriel Mountains National Monument: http:\/\/t.co\/UzTFiqOiEd http:\/\/t.co\/UlecuqBJQs",
  "id" : 520624423544823810,
  "created_at" : "2014-10-10 17:18:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "With1010",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Yhze6FCj6K",
      "expanded_url" : "http:\/\/youtu.be\/PqtLQgkcUFM",
      "display_url" : "youtu.be\/PqtLQgkcUFM"
    } ]
  },
  "geo" : { },
  "id_str" : "520619567769739264",
  "text" : "#With1010, 28 million Americans from all types of households would see their wages go up. Watch \u2192 http:\/\/t.co\/Yhze6FCj6K #RaiseTheWage",
  "id" : 520619567769739264,
  "created_at" : "2014-10-10 16:59:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrod Brown",
      "screen_name" : "SenSherrodBrown",
      "indices" : [ 3, 19 ],
      "id_str" : "43910797",
      "id" : 43910797
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MinimumWage",
      "indices" : [ 76, 88 ]
    }, {
      "text" : "With1010",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/cVDgvgo2Vy",
      "expanded_url" : "http:\/\/ow.ly\/CyHqk",
      "display_url" : "ow.ly\/CyHqk"
    } ]
  },
  "geo" : { },
  "id_str" : "520615249469521920",
  "text" : "RT @SenSherrodBrown: RT if you agree: Hard working Americans deserve a fair #MinimumWage #With1010. http:\/\/t.co\/cVDgvgo2Vy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MinimumWage",
        "indices" : [ 55, 67 ]
      }, {
        "text" : "With1010",
        "indices" : [ 68, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/cVDgvgo2Vy",
        "expanded_url" : "http:\/\/ow.ly\/CyHqk",
        "display_url" : "ow.ly\/CyHqk"
      } ]
    },
    "geo" : { },
    "id_str" : "520570753486688256",
    "text" : "RT if you agree: Hard working Americans deserve a fair #MinimumWage #With1010. http:\/\/t.co\/cVDgvgo2Vy",
    "id" : 520570753486688256,
    "created_at" : "2014-10-10 13:45:14 +0000",
    "user" : {
      "name" : "Sherrod Brown",
      "screen_name" : "SenSherrodBrown",
      "protected" : false,
      "id_str" : "43910797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523158370333638657\/cLmYIfYa_normal.jpeg",
      "id" : 43910797,
      "verified" : true
    }
  },
  "id" : 520615249469521920,
  "created_at" : "2014-10-10 16:42:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519865663188660225\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3K4F6RcPy2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzbvENKCYAA-y14.jpg",
      "id_str" : "519865662538145792",
      "id" : 519865662538145792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzbvENKCYAA-y14.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/3K4F6RcPy2"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520602529701580800",
  "text" : "When #WomenSucceed, America succeeds. It's time to help millions of women by raising the minimum wage. #RaiseTheWage http:\/\/t.co\/3K4F6RcPy2",
  "id" : 520602529701580800,
  "created_at" : "2014-10-10 15:51:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 52, 65 ]
    }, {
      "text" : "With1010",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Yhze6FCj6K",
      "expanded_url" : "http:\/\/youtu.be\/PqtLQgkcUFM",
      "display_url" : "youtu.be\/PqtLQgkcUFM"
    } ]
  },
  "geo" : { },
  "id_str" : "520597936108236802",
  "text" : "Here's what you need to know about why it's time to #RaiseTheWage.\nIn less than 2 minutes.\nWatch \u2192 http:\/\/t.co\/Yhze6FCj6K #With1010",
  "id" : 520597936108236802,
  "created_at" : "2014-10-10 15:33:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520587876921520128\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/6SbPwtJuTb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzl_6kpCcAAy4it.jpg",
      "id_str" : "520587876182945792",
      "id" : 520587876182945792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzl_6kpCcAAy4it.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6SbPwtJuTb"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 83, 96 ]
    }, {
      "text" : "With1010",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/fMEhvXwRjy",
      "expanded_url" : "http:\/\/wh.gov\/raise-the-wage",
      "display_url" : "wh.gov\/raise-the-wage"
    } ]
  },
  "geo" : { },
  "id_str" : "520587876921520128",
  "text" : "Nobody who works full-time should have to live in poverty \u2192 http:\/\/t.co\/fMEhvXwRjy #RaiseTheWage #With1010 http:\/\/t.co\/6SbPwtJuTb",
  "id" : 520587876921520128,
  "created_at" : "2014-10-10 14:53:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadyToWork",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/RZRrXqHdOp",
      "expanded_url" : "http:\/\/wh.gov\/ready-to-work",
      "display_url" : "wh.gov\/ready-to-work"
    } ]
  },
  "geo" : { },
  "id_str" : "520346696107433984",
  "text" : "\"If you want to work at an auto plant today, you\u2019ve got to have some familiarity with computers\" \u2014Obama: http:\/\/t.co\/RZRrXqHdOp #ReadyToWork",
  "id" : 520346696107433984,
  "created_at" : "2014-10-09 22:54:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cross Campus",
      "screen_name" : "CrossCampus",
      "indices" : [ 70, 82 ],
      "id_str" : "2732941045",
      "id" : 2732941045
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520342029789061120\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/6xtQSPteRQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzigUYoCIAEyVWf.png",
      "id_str" : "520342029029482497",
      "id" : 520342029029482497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzigUYoCIAEyVWf.png",
      "sizes" : [ {
        "h" : 324,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 893
      }, {
        "h" : 482,
        "resize" : "fit",
        "w" : 893
      } ],
      "display_url" : "pic.twitter.com\/6xtQSPteRQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/b4tqL3X2az",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "520342029789061120",
  "text" : "\"I am unequivocally committed to net neutrality.\" \u2014President Obama at @CrossCampus: http:\/\/t.co\/b4tqL3X2az http:\/\/t.co\/6xtQSPteRQ",
  "id" : 520342029789061120,
  "created_at" : "2014-10-09 22:36:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520336080093323264\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/OQr6ex9rzi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzia6EgCUAA5yQD.jpg",
      "id_str" : "520336079392493568",
      "id" : 520336079392493568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzia6EgCUAA5yQD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OQr6ex9rzi"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520336080093323264",
  "text" : "\"When I took office, the deficit was nearly 10% of our economy. Today, it\u2019s under 3%.\" \u2014President Obama #AmericaLeads http:\/\/t.co\/OQr6ex9rzi",
  "id" : 520336080093323264,
  "created_at" : "2014-10-09 22:12:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/520335839734534144\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/JmvO6pLMWq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BziasFnCUAEfIgx.jpg",
      "id_str" : "520335839172120577",
      "id" : 520335839172120577,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BziasFnCUAEfIgx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JmvO6pLMWq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520335839734534144",
  "text" : "\"We\u2019ve acted to give nearly 5 million Americans the chance to cap...student loan payments at 10% of...income.\" \u2014Obama http:\/\/t.co\/JmvO6pLMWq",
  "id" : 520335839734534144,
  "created_at" : "2014-10-09 22:11:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Cross Campus",
      "screen_name" : "CrossCampus",
      "indices" : [ 102, 114 ],
      "id_str" : "2732941045",
      "id" : 2732941045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520334711210909696",
  "text" : "RT @WHLive: \"We\u2019re on pace for the strongest year of job growth since the 1990s.\" \u2014President Obama at @CrossCampus",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cross Campus",
        "screen_name" : "CrossCampus",
        "indices" : [ 90, 102 ],
        "id_str" : "2732941045",
        "id" : 2732941045
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520334681167118336",
    "text" : "\"We\u2019re on pace for the strongest year of job growth since the 1990s.\" \u2014President Obama at @CrossCampus",
    "id" : 520334681167118336,
    "created_at" : "2014-10-09 22:07:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 520334711210909696,
  "created_at" : "2014-10-09 22:07:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/520334467014356992\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/5t2vMf9WpE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BziZcLyCQAIN108.jpg",
      "id_str" : "520334466439331842",
      "id" : 520334466439331842,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BziZcLyCQAIN108.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5t2vMf9WpE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520334467014356992",
  "text" : "\"For the first time in more than 6 years, the unemployment rate has now dropped below 6%.\" \u2014President Obama http:\/\/t.co\/5t2vMf9WpE",
  "id" : 520334467014356992,
  "created_at" : "2014-10-09 22:06:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/520334265968787456\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/IGi3b0DVme",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BziZQdoCUAAAuRj.jpg",
      "id_str" : "520334265070800896",
      "id" : 520334265070800896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BziZQdoCUAAAuRj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IGi3b0DVme"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520334265968787456",
  "text" : "\"Last month, our businesses added 236,000 new jobs. Over the past 55 months, we've added...10.3 million.\" \u2014Obama http:\/\/t.co\/IGi3b0DVme",
  "id" : 520334265968787456,
  "created_at" : "2014-10-09 22:05:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cross Campus",
      "screen_name" : "CrossCampus",
      "indices" : [ 68, 80 ],
      "id_str" : "2732941045",
      "id" : 2732941045
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520333196974911489\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/hS6AGD8d9X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BziYSPvCQAAM1Ca.png",
      "id_str" : "520333196190171136",
      "id" : 520333196190171136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BziYSPvCQAAM1Ca.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 920
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 920
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hS6AGD8d9X"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/b4tqL3X2az",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "520333196974911489",
  "text" : "Watch President Obama discuss new tech projects with members of the @CrossCampus community \u2192 http:\/\/t.co\/b4tqL3X2az http:\/\/t.co\/hS6AGD8d9X",
  "id" : 520333196974911489,
  "created_at" : "2014-10-09 22:01:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cross Campus",
      "screen_name" : "CrossCampus",
      "indices" : [ 49, 61 ],
      "id_str" : "2732941045",
      "id" : 2732941045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/b4tqL3X2az",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "520331639105544193",
  "text" : "Watch live: President Obama holds a town hall at @CrossCampus in LA on how Millennials will shape our economy \u2192 http:\/\/t.co\/b4tqL3X2az",
  "id" : 520331639105544193,
  "created_at" : "2014-10-09 21:55:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/519513449060368384\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/lmpUGNDxqV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzWuupNCIAEgLZW.jpg",
      "id_str" : "519513448388894721",
      "id" : 519513448388894721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzWuupNCIAEgLZW.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lmpUGNDxqV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/8KYB7jLAZ5",
      "expanded_url" : "http:\/\/medium.com\/p\/e80a775b44ee\/",
      "display_url" : "medium.com\/p\/e80a775b44ee\/"
    } ]
  },
  "geo" : { },
  "id_str" : "520322898859671552",
  "text" : "\"For the 1st time in more than 6 years, the unemployment rate is below 6%.\" \u2014President Obama: http:\/\/t.co\/8KYB7jLAZ5 http:\/\/t.co\/lmpUGNDxqV",
  "id" : 520322898859671552,
  "created_at" : "2014-10-09 21:20:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 100, 107 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/adyHhClSlO",
      "expanded_url" : "https:\/\/medium.com\/p\/e80a775b44ee\/",
      "display_url" : "medium.com\/p\/e80a775b44ee\/"
    } ]
  },
  "geo" : { },
  "id_str" : "520307701365346304",
  "text" : "\"Why I'm betting on you to help shape the American economy.\" \u2014President Obama to young Americans on @Medium: https:\/\/t.co\/adyHhClSlO",
  "id" : 520307701365346304,
  "created_at" : "2014-10-09 20:19:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Tammy Baldwin",
      "screen_name" : "SenatorBaldwin",
      "indices" : [ 3, 18 ],
      "id_str" : "1074518754",
      "id" : 1074518754
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 28, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520297098462642176",
  "text" : "RT @SenatorBaldwin: When we #RaiseTheWage, it'll benefit women, families, full-time working adults and the entire state of Wisconsin. http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenatorBaldwin\/status\/520280106741145600\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/lTd3umQK78",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzhQxjbCcAMZtzs.png",
        "id_str" : "520254569213751299",
        "id" : 520254569213751299,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzhQxjbCcAMZtzs.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lTd3umQK78"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 8, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520280106741145600",
    "text" : "When we #RaiseTheWage, it'll benefit women, families, full-time working adults and the entire state of Wisconsin. http:\/\/t.co\/lTd3umQK78",
    "id" : 520280106741145600,
    "created_at" : "2014-10-09 18:30:18 +0000",
    "user" : {
      "name" : "Sen. Tammy Baldwin",
      "screen_name" : "SenatorBaldwin",
      "protected" : false,
      "id_str" : "1074518754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656152457756692481\/jq9YvUuw_normal.jpg",
      "id" : 1074518754,
      "verified" : true
    }
  },
  "id" : 520297098462642176,
  "created_at" : "2014-10-09 19:37:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rolling Stone",
      "screen_name" : "RollingStone",
      "indices" : [ 3, 16 ],
      "id_str" : "14780915",
      "id" : 14780915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/HPtxRyAOnO",
      "expanded_url" : "http:\/\/rol.st\/1ne7Jcw",
      "display_url" : "rol.st\/1ne7Jcw"
    } ]
  },
  "geo" : { },
  "id_str" : "520294119563083777",
  "text" : "RT @RollingStone: 55 numbers that prove President Obama has accomplished more than you may realize: http:\/\/t.co\/HPtxRyAOnO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/HPtxRyAOnO",
        "expanded_url" : "http:\/\/rol.st\/1ne7Jcw",
        "display_url" : "rol.st\/1ne7Jcw"
      } ]
    },
    "geo" : { },
    "id_str" : "520199773178298368",
    "text" : "55 numbers that prove President Obama has accomplished more than you may realize: http:\/\/t.co\/HPtxRyAOnO",
    "id" : 520199773178298368,
    "created_at" : "2014-10-09 13:11:05 +0000",
    "user" : {
      "name" : "Rolling Stone",
      "screen_name" : "RollingStone",
      "protected" : false,
      "id_str" : "14780915",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458998630175617024\/MIwtW6L0_normal.png",
      "id" : 14780915,
      "verified" : true
    }
  },
  "id" : 520294119563083777,
  "created_at" : "2014-10-09 19:25:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Brian Deese",
      "screen_name" : "DeeseOMB",
      "indices" : [ 17, 26 ],
      "id_str" : "2814258183",
      "id" : 2814258183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Millennials",
      "indices" : [ 62, 74 ]
    }, {
      "text" : "WHEconChat",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520291674409668608",
  "text" : "RT @WHLive: Join @DeeseOMB for a Twitter Q&amp;A at 4pm ET on #Millennials and the economy. Ask him your questions with #WHEconChat. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Deese",
        "screen_name" : "DeeseOMB",
        "indices" : [ 5, 14 ],
        "id_str" : "2814258183",
        "id" : 2814258183
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/520291390216220673\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/GiHU7NCFxe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzhyQvtCQAAfT03.jpg",
        "id_str" : "520291388970123264",
        "id" : 520291388970123264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzhyQvtCQAAfT03.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/GiHU7NCFxe"
      } ],
      "hashtags" : [ {
        "text" : "Millennials",
        "indices" : [ 50, 62 ]
      }, {
        "text" : "WHEconChat",
        "indices" : [ 108, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520291390216220673",
    "text" : "Join @DeeseOMB for a Twitter Q&amp;A at 4pm ET on #Millennials and the economy. Ask him your questions with #WHEconChat. http:\/\/t.co\/GiHU7NCFxe",
    "id" : 520291390216220673,
    "created_at" : "2014-10-09 19:15:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 520291674409668608,
  "created_at" : "2014-10-09 19:16:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520279049709842432\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/8iPrma75xH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzhnCWTCIAAUGPy.jpg",
      "id_str" : "520279047004102656",
      "id" : 520279047004102656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzhnCWTCIAAUGPy.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8iPrma75xH"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 77, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/ayzVqvw674",
      "expanded_url" : "http:\/\/go.wh.gov\/UZwcW6",
      "display_url" : "go.wh.gov\/UZwcW6"
    } ]
  },
  "geo" : { },
  "id_str" : "520279049709842432",
  "text" : "President Obama's fighting to make \uD83C\uDF93 more affordable: http:\/\/t.co\/ayzVqvw674 #CollegeOpportunity http:\/\/t.co\/8iPrma75xH",
  "id" : 520279049709842432,
  "created_at" : "2014-10-09 18:26:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520267479495344128\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/tQY6T3zRTc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzhY1oYCMAAMhha.jpg",
      "id_str" : "520263435355828224",
      "id" : 520263435355828224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzhY1oYCMAAMhha.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tQY6T3zRTc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520267479495344128",
  "text" : "Worth sharing: More young Americans are earning college degrees than ever before, and the largest \u2191 is among women. http:\/\/t.co\/tQY6T3zRTc",
  "id" : 520267479495344128,
  "created_at" : "2014-10-09 17:40:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CEABetsey\/status\/520243124434927616\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/fsYcqFUVNl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzhGXNgIAAAmf5Q.jpg",
      "id_str" : "520243121536630784",
      "id" : 520243121536630784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzhGXNgIAAAmf5Q.jpg",
      "sizes" : [ {
        "h" : 451,
        "resize" : "fit",
        "w" : 601
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 601
      } ],
      "display_url" : "pic.twitter.com\/fsYcqFUVNl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520262515780255746",
  "text" : "RT @CEABetsey: Millennials are poised to benefit from the striking slowdown in the growth of health care costs. http:\/\/t.co\/fsYcqFUVNl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEABetsey\/status\/520243124434927616\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/fsYcqFUVNl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzhGXNgIAAAmf5Q.jpg",
        "id_str" : "520243121536630784",
        "id" : 520243121536630784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzhGXNgIAAAmf5Q.jpg",
        "sizes" : [ {
          "h" : 451,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 601
        } ],
        "display_url" : "pic.twitter.com\/fsYcqFUVNl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520243124434927616",
    "text" : "Millennials are poised to benefit from the striking slowdown in the growth of health care costs. http:\/\/t.co\/fsYcqFUVNl",
    "id" : 520243124434927616,
    "created_at" : "2014-10-09 16:03:21 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 520262515780255746,
  "created_at" : "2014-10-09 17:20:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "DeeseOMB",
      "indices" : [ 3, 12 ],
      "id_str" : "2814258183",
      "id" : 2814258183
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 42, 50 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Millennials",
      "indices" : [ 72, 84 ]
    }, {
      "text" : "Economy",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/oLl8UrjQqI",
      "expanded_url" : "http:\/\/go.wh.gov\/UZwcW6",
      "display_url" : "go.wh.gov\/UZwcW6"
    } ]
  },
  "geo" : { },
  "id_str" : "520260523078975488",
  "text" : "RT @DeeseOMB: Jumping right in! Hosting a @Twitter Q&amp;A at 4pm ET on #Millennials and the #Economy \u2192 http:\/\/t.co\/oLl8UrjQqI. Ask your Q's wi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 28, 36 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Millennials",
        "indices" : [ 58, 70 ]
      }, {
        "text" : "Economy",
        "indices" : [ 79, 87 ]
      }, {
        "text" : "WHEconChat",
        "indices" : [ 132, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/oLl8UrjQqI",
        "expanded_url" : "http:\/\/go.wh.gov\/UZwcW6",
        "display_url" : "go.wh.gov\/UZwcW6"
      } ]
    },
    "geo" : { },
    "id_str" : "520234385787084800",
    "text" : "Jumping right in! Hosting a @Twitter Q&amp;A at 4pm ET on #Millennials and the #Economy \u2192 http:\/\/t.co\/oLl8UrjQqI. Ask your Q's with #WHEconChat.",
    "id" : 520234385787084800,
    "created_at" : "2014-10-09 15:28:37 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "DeeseOMB",
      "protected" : false,
      "id_str" : "2814258183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519502071150563328\/hBrEA5ZX_normal.jpeg",
      "id" : 2814258183,
      "verified" : true
    }
  },
  "id" : 520260523078975488,
  "created_at" : "2014-10-09 17:12:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/520255975216119808\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/SFEGOrZeVq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzhSDVpCMAEvg8E.jpg",
      "id_str" : "520255974263631873",
      "id" : 520255974263631873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzhSDVpCMAEvg8E.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SFEGOrZeVq"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ayzVqvw674",
      "expanded_url" : "http:\/\/go.wh.gov\/UZwcW6",
      "display_url" : "go.wh.gov\/UZwcW6"
    } ]
  },
  "geo" : { },
  "id_str" : "520255975216119808",
  "text" : "Here's how the Affordable Care Act is benefiting millions of young Americans \u2192 http:\/\/t.co\/ayzVqvw674 #ACAWorks http:\/\/t.co\/SFEGOrZeVq",
  "id" : 520255975216119808,
  "created_at" : "2014-10-09 16:54:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/520242213411127296\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/FKmWaCjpNj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzhFiKzCAAA80gV.jpg",
      "id_str" : "520242210277556224",
      "id" : 520242210277556224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzhFiKzCAAA80gV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FKmWaCjpNj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/ayzVqvw674",
      "expanded_url" : "http:\/\/go.wh.gov\/UZwcW6",
      "display_url" : "go.wh.gov\/UZwcW6"
    } ]
  },
  "geo" : { },
  "id_str" : "520242213411127296",
  "text" : "RT to share how President Obama's fighting to make college more affordable: http:\/\/t.co\/ayzVqvw674 http:\/\/t.co\/FKmWaCjpNj",
  "id" : 520242213411127296,
  "created_at" : "2014-10-09 15:59:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/520234933361864704\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/eg1H9MOiVA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzg-6jECYAEqajZ.jpg",
      "id_str" : "520234932526800897",
      "id" : 520234932526800897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzg-6jECYAEqajZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eg1H9MOiVA"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520234933361864704",
  "text" : "FACT: The number of uninsured young Americans has dropped by nearly 40% over the past 4 years. #ACAWorks http:\/\/t.co\/eg1H9MOiVA",
  "id" : 520234933361864704,
  "created_at" : "2014-10-09 15:30:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/ayzVqvw674",
      "expanded_url" : "http:\/\/go.wh.gov\/UZwcW6",
      "display_url" : "go.wh.gov\/UZwcW6"
    } ]
  },
  "geo" : { },
  "id_str" : "520224491587506176",
  "text" : "Millennials: Here's where they are, where they're going &amp; what President Obama's doing to help ensure their success \u2192 http:\/\/t.co\/ayzVqvw674",
  "id" : 520224491587506176,
  "created_at" : "2014-10-09 14:49:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed News",
      "screen_name" : "BuzzFeedNews",
      "indices" : [ 3, 16 ],
      "id_str" : "1020058453",
      "id" : 1020058453
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BuzzFeedNews\/status\/520042100680065024\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/VtWtq1kdfQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzePiN_CMAAOXBM.jpg",
      "id_str" : "520042100016951296",
      "id" : 520042100016951296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzePiN_CMAAOXBM.jpg",
      "sizes" : [ {
        "h" : 313,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 313,
        "resize" : "fit",
        "w" : 625
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VtWtq1kdfQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/jmiTtZugdz",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/evanmcsan\/white-house-emojis",
      "display_url" : "buzzfeed.com\/evanmcsan\/whit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "520210605840809985",
  "text" : "RT @BuzzFeedNews: .@WhiteHouse Uses Emojis To Make Its Economic Case To The Youth http:\/\/t.co\/jmiTtZugdz http:\/\/t.co\/VtWtq1kdfQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BuzzFeedNews\/status\/520042100680065024\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/VtWtq1kdfQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzePiN_CMAAOXBM.jpg",
        "id_str" : "520042100016951296",
        "id" : 520042100016951296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzePiN_CMAAOXBM.jpg",
        "sizes" : [ {
          "h" : 313,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 313,
          "resize" : "fit",
          "w" : 625
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VtWtq1kdfQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/jmiTtZugdz",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/evanmcsan\/white-house-emojis",
        "display_url" : "buzzfeed.com\/evanmcsan\/whit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "520042100680065024",
    "text" : ".@WhiteHouse Uses Emojis To Make Its Economic Case To The Youth http:\/\/t.co\/jmiTtZugdz http:\/\/t.co\/VtWtq1kdfQ",
    "id" : 520042100680065024,
    "created_at" : "2014-10-09 02:44:33 +0000",
    "user" : {
      "name" : "BuzzFeed News",
      "screen_name" : "BuzzFeedNews",
      "protected" : false,
      "id_str" : "1020058453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796353157576138752\/H2xr-NkC_normal.jpg",
      "id" : 1020058453,
      "verified" : true
    }
  },
  "id" : 520210605840809985,
  "created_at" : "2014-10-09 13:54:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 3, 11 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FuelEconomy",
      "indices" : [ 38, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/f9EwqZwI9q",
      "expanded_url" : "http:\/\/1.usa.gov\/ZeyZMB",
      "display_url" : "1.usa.gov\/ZeyZMB"
    } ]
  },
  "geo" : { },
  "id_str" : "519970283017756672",
  "text" : "RT @Utech44: We\u2019re on track to double #FuelEconomy by 2025, saving Americans $1.7 TRILLION in fuel costs \u2192 http:\/\/t.co\/f9EwqZwI9q http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Utech44\/status\/519970127992074240\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/W7gyh4AyYq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzdOEx4CYAAkALP.jpg",
        "id_str" : "519970125999398912",
        "id" : 519970125999398912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzdOEx4CYAAkALP.jpg",
        "sizes" : [ {
          "h" : 276,
          "resize" : "fit",
          "w" : 276
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 276
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 276
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 276
        } ],
        "display_url" : "pic.twitter.com\/W7gyh4AyYq"
      } ],
      "hashtags" : [ {
        "text" : "FuelEconomy",
        "indices" : [ 25, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/f9EwqZwI9q",
        "expanded_url" : "http:\/\/1.usa.gov\/ZeyZMB",
        "display_url" : "1.usa.gov\/ZeyZMB"
      } ]
    },
    "geo" : { },
    "id_str" : "519970127992074240",
    "text" : "We\u2019re on track to double #FuelEconomy by 2025, saving Americans $1.7 TRILLION in fuel costs \u2192 http:\/\/t.co\/f9EwqZwI9q http:\/\/t.co\/W7gyh4AyYq",
    "id" : 519970127992074240,
    "created_at" : "2014-10-08 21:58:33 +0000",
    "user" : {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "protected" : false,
      "id_str" : "2283772130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705138779221135360\/UcDKamCq_normal.jpg",
      "id" : 2283772130,
      "verified" : true
    }
  },
  "id" : 519970283017756672,
  "created_at" : "2014-10-08 21:59:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/vYzY4L4m2O",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/politics\/obama-to-designate-san-gabriel-mountains-as-a-national-monument\/2014\/10\/08\/d1abdb74-4e2b-11e4-babe-e91da079cb8a_story.html",
      "display_url" : "washingtonpost.com\/politics\/obama\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "519965541734563840",
  "text" : "RT @Podesta44: CA condors are flying high: POTUS to designate San Gabriel Mountains as a national monument: http:\/\/t.co\/vYzY4L4m2O http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Podesta44\/status\/519964577514414080\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/eyUVPOuCwk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzdJBwQCAAAIBzj.jpg",
        "id_str" : "519964576465420288",
        "id" : 519964576465420288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzdJBwQCAAAIBzj.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/eyUVPOuCwk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/vYzY4L4m2O",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/politics\/obama-to-designate-san-gabriel-mountains-as-a-national-monument\/2014\/10\/08\/d1abdb74-4e2b-11e4-babe-e91da079cb8a_story.html",
        "display_url" : "washingtonpost.com\/politics\/obama\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "519964577514414080",
    "text" : "CA condors are flying high: POTUS to designate San Gabriel Mountains as a national monument: http:\/\/t.co\/vYzY4L4m2O http:\/\/t.co\/eyUVPOuCwk",
    "id" : 519964577514414080,
    "created_at" : "2014-10-08 21:36:30 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 519965541734563840,
  "created_at" : "2014-10-08 21:40:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "P. Krugman",
      "screen_name" : "nytimeskrugman",
      "indices" : [ 62, 77 ],
      "id_str" : "4886807543",
      "id" : 4886807543
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519960996128231426",
  "text" : "RT @vj44: \"He has\u2014when all is said and done\u2014achieved a lot.\" \u2014@NYTimesKrugman on the progress we've made under President Obama: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "P. Krugman",
        "screen_name" : "nytimeskrugman",
        "indices" : [ 52, 67 ],
        "id_str" : "4886807543",
        "id" : 4886807543
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/geou4drFCE",
        "expanded_url" : "http:\/\/rol.st\/1rWI9aV",
        "display_url" : "rol.st\/1rWI9aV"
      } ]
    },
    "geo" : { },
    "id_str" : "519955140753629184",
    "text" : "\"He has\u2014when all is said and done\u2014achieved a lot.\" \u2014@NYTimesKrugman on the progress we've made under President Obama: http:\/\/t.co\/geou4drFCE",
    "id" : 519955140753629184,
    "created_at" : "2014-10-08 20:59:00 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 519960996128231426,
  "created_at" : "2014-10-08 21:22:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "DeeseOMB",
      "indices" : [ 3, 12 ],
      "id_str" : "2814258183",
      "id" : 2814258183
    }, {
      "name" : "U.S. CBO",
      "screen_name" : "USCBO",
      "indices" : [ 50, 56 ],
      "id_str" : "1531265618",
      "id" : 1531265618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/UoiVrNp3dI",
      "expanded_url" : "http:\/\/1.usa.gov\/1EuuJcO",
      "display_url" : "1.usa.gov\/1EuuJcO"
    } ]
  },
  "geo" : { },
  "id_str" : "519955029210701825",
  "text" : "RT @DeeseOMB: Good news today on the deficit from @USCBO http:\/\/t.co\/UoiVrNp3dI, so I thought I'd join Twitter. Follow along for more OMB a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. CBO",
        "screen_name" : "USCBO",
        "indices" : [ 36, 42 ],
        "id_str" : "1531265618",
        "id" : 1531265618
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/UoiVrNp3dI",
        "expanded_url" : "http:\/\/1.usa.gov\/1EuuJcO",
        "display_url" : "1.usa.gov\/1EuuJcO"
      } ]
    },
    "geo" : { },
    "id_str" : "519954608538398721",
    "text" : "Good news today on the deficit from @USCBO http:\/\/t.co\/UoiVrNp3dI, so I thought I'd join Twitter. Follow along for more OMB and budget news.",
    "id" : 519954608538398721,
    "created_at" : "2014-10-08 20:56:53 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "DeeseOMB",
      "protected" : false,
      "id_str" : "2814258183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519502071150563328\/hBrEA5ZX_normal.jpeg",
      "id" : 2814258183,
      "verified" : true
    }
  },
  "id" : 519955029210701825,
  "created_at" : "2014-10-08 20:58:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "indices" : [ 3, 16 ],
      "id_str" : "15442036",
      "id" : 15442036
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519938594585444352",
  "text" : "RT @SenatorBoxer: Nearly 3 million Californians would see their wages go up if we raised the minimum wage. #RaiseTheWage http:\/\/t.co\/5Agyqt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenatorBoxer\/status\/519933284147806209\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/5AgyqtJ1vT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzcskPfCUAALw4j.jpg",
        "id_str" : "519933283128201216",
        "id" : 519933283128201216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzcskPfCUAALw4j.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5AgyqtJ1vT"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 89, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519933284147806209",
    "text" : "Nearly 3 million Californians would see their wages go up if we raised the minimum wage. #RaiseTheWage http:\/\/t.co\/5AgyqtJ1vT",
    "id" : 519933284147806209,
    "created_at" : "2014-10-08 19:32:09 +0000",
    "user" : {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "protected" : false,
      "id_str" : "15442036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464147946934517760\/EZ8huLG8_normal.png",
      "id" : 15442036,
      "verified" : true
    }
  },
  "id" : 519938594585444352,
  "created_at" : "2014-10-08 19:53:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "indices" : [ 3, 15 ],
      "id_str" : "293131808",
      "id" : 293131808
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "minimumwage",
      "indices" : [ 19, 31 ]
    }, {
      "text" : "WEmatter",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519934281465233408",
  "text" : "RT @PattyMurray: A #minimumwage worker who puts in 40 hrs\/wk w\/ no time off earns ~$3k below the poverty line for a family of 3. #WEmatter \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "minimumwage",
        "indices" : [ 2, 14 ]
      }, {
        "text" : "WEmatter",
        "indices" : [ 112, 121 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519929810123227136",
    "text" : "A #minimumwage worker who puts in 40 hrs\/wk w\/ no time off earns ~$3k below the poverty line for a family of 3. #WEmatter #RaiseTheWage",
    "id" : 519929810123227136,
    "created_at" : "2014-10-08 19:18:21 +0000",
    "user" : {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "protected" : false,
      "id_str" : "293131808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430384292917555200\/ULj2LMsW_normal.jpeg",
      "id" : 293131808,
      "verified" : true
    }
  },
  "id" : 519934281465233408,
  "created_at" : "2014-10-08 19:36:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519927861634150400\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/e3W8ZgPWVp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzcnomhCEAAwuCh.jpg",
      "id_str" : "519927860471926784",
      "id" : 519927860471926784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzcnomhCEAAwuCh.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/e3W8ZgPWVp"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 23, 36 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/fMEhvXwRjy",
      "expanded_url" : "http:\/\/wh.gov\/raise-the-wage",
      "display_url" : "wh.gov\/raise-the-wage"
    } ]
  },
  "geo" : { },
  "id_str" : "519927861634150400",
  "text" : "Let's help millions of #WomenSucceed by raising the minimum wage to $10.10 \u2192 http:\/\/t.co\/fMEhvXwRjy #RaiseTheWage http:\/\/t.co\/e3W8ZgPWVp",
  "id" : 519927861634150400,
  "created_at" : "2014-10-08 19:10:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519917160299503617\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/NRlIbdPGus",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzcd5vNCEAANvJd.jpg",
      "id_str" : "519917159745458176",
      "id" : 519917159745458176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzcd5vNCEAANvJd.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NRlIbdPGus"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/SHfoevWHpI",
      "expanded_url" : "http:\/\/go.wh.gov\/PnEAkD",
      "display_url" : "go.wh.gov\/PnEAkD"
    } ]
  },
  "geo" : { },
  "id_str" : "519917160299503617",
  "text" : ".@VP Biden: No one who works 40 hours a week should live in poverty \u2192 http:\/\/t.co\/SHfoevWHpI #RaiseTheWage http:\/\/t.co\/NRlIbdPGus",
  "id" : 519917160299503617,
  "created_at" : "2014-10-08 18:28:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519898967442984960\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/B6nv2oZgWw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzcNWxUCMAAe4G8.jpg",
      "id_str" : "519898966830231552",
      "id" : 519898966830231552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzcNWxUCMAAe4G8.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/B6nv2oZgWw"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/fMEhvXwRjy",
      "expanded_url" : "http:\/\/wh.gov\/raise-the-wage",
      "display_url" : "wh.gov\/raise-the-wage"
    } ]
  },
  "geo" : { },
  "id_str" : "519898967442984960",
  "text" : "Nobody who works full-time should have to live in poverty. It's time to #RaiseTheWage \u2192 http:\/\/t.co\/fMEhvXwRjy http:\/\/t.co\/B6nv2oZgWw",
  "id" : 519898967442984960,
  "created_at" : "2014-10-08 17:15:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519886280369647617\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/XhmA7LkM6r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzcB0RDCQAAKLIS.png",
      "id_str" : "519886279425540096",
      "id" : 519886279425540096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzcB0RDCQAAKLIS.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XhmA7LkM6r"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519886280369647617",
  "text" : "The current minimum wage isn't enough for workers &amp; their families to get out of poverty. It's time to #RaiseTheWage. http:\/\/t.co\/XhmA7LkM6r",
  "id" : 519886280369647617,
  "created_at" : "2014-10-08 16:25:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/519865663188660225\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3K4F6RcPy2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzbvENKCYAA-y14.jpg",
      "id_str" : "519865662538145792",
      "id" : 519865662538145792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzbvENKCYAA-y14.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/3K4F6RcPy2"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519865663188660225",
  "text" : "When #WomenSucceed, America succeeds. It's time to help millions of women by raising the minimum wage. #RaiseTheWage http:\/\/t.co\/3K4F6RcPy2",
  "id" : 519865663188660225,
  "created_at" : "2014-10-08 15:03:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Canada",
      "indices" : [ 66, 73 ]
    }, {
      "text" : "ISIL",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Zt9dvcR9em",
      "expanded_url" : "http:\/\/wh.gov\/i3K6K",
      "display_url" : "wh.gov\/i3K6K"
    } ]
  },
  "geo" : { },
  "id_str" : "519861406884442113",
  "text" : "RT @NSCPress: Statement by the Press Secretary on the Decision by #Canada to Authorize Military Force Against #ISIL: http:\/\/t.co\/Zt9dvcR9em",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Canada",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "ISIL",
        "indices" : [ 96, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/Zt9dvcR9em",
        "expanded_url" : "http:\/\/wh.gov\/i3K6K",
        "display_url" : "wh.gov\/i3K6K"
      } ]
    },
    "geo" : { },
    "id_str" : "519856823856156672",
    "text" : "Statement by the Press Secretary on the Decision by #Canada to Authorize Military Force Against #ISIL: http:\/\/t.co\/Zt9dvcR9em",
    "id" : 519856823856156672,
    "created_at" : "2014-10-08 14:28:19 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 519861406884442113,
  "created_at" : "2014-10-08 14:46:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519856361585528832\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xmy2HfmjgL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzbmmyYCUAAqgr0.jpg",
      "id_str" : "519856361039876096",
      "id" : 519856361039876096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzbmmyYCUAAqgr0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xmy2HfmjgL"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/akWsI1nrq5",
      "expanded_url" : "http:\/\/go.wh.gov\/WLVMA1",
      "display_url" : "go.wh.gov\/WLVMA1"
    } ]
  },
  "geo" : { },
  "id_str" : "519856361585528832",
  "text" : "Raising the minimum wage would help millions of Americans. Read their stories \u2192 http:\/\/t.co\/akWsI1nrq5 #RaiseTheWage http:\/\/t.co\/xmy2HfmjgL",
  "id" : 519856361585528832,
  "created_at" : "2014-10-08 14:26:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HireWomenVets",
      "indices" : [ 29, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519609709469261824",
  "text" : "RT @FLOTUS: How you can help #HireWomenVets:\nMentor female veterans \u2714\nFind veterans in your town \u2714\nReach out to local bases \u2714\nhttp:\/\/t.co\/1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HireWomenVets",
        "indices" : [ 17, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/1Yaqgu2Xbv",
        "expanded_url" : "http:\/\/redbk.co\/6019U9td",
        "display_url" : "redbk.co\/6019U9td"
      } ]
    },
    "geo" : { },
    "id_str" : "519608196881596417",
    "text" : "How you can help #HireWomenVets:\nMentor female veterans \u2714\nFind veterans in your town \u2714\nReach out to local bases \u2714\nhttp:\/\/t.co\/1Yaqgu2Xbv",
    "id" : 519608196881596417,
    "created_at" : "2014-10-07 22:00:22 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 519609709469261824,
  "created_at" : "2014-10-07 22:06:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519572366569910272",
  "text" : "RT @VP: \"Nobody in America should be working 40 hours a week and living below the poverty line.\" -VP Biden in Los Angeles on need to #Raise\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519547882790084608",
    "text" : "\"Nobody in America should be working 40 hours a week and living below the poverty line.\" -VP Biden in Los Angeles on need to #RaiseTheWage",
    "id" : 519547882790084608,
    "created_at" : "2014-10-07 18:00:42 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 519572366569910272,
  "created_at" : "2014-10-07 19:38:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 40, 45 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Podesta44\/status\/519515354813726720\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/JESzEZ0jiV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzWwdjzCcAA3RCQ.png",
      "id_str" : "519515353903165440",
      "id" : 519515353903165440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzWwdjzCcAA3RCQ.png",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JESzEZ0jiV"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519568660839415808",
  "text" : "RT @Podesta44: Yikes! Check out these 3 @NASA satellite images of water loss in CA #ActOnClimate http:\/\/t.co\/JESzEZ0jiV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 25, 30 ],
        "id_str" : "11348282",
        "id" : 11348282
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Podesta44\/status\/519515354813726720\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/JESzEZ0jiV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzWwdjzCcAA3RCQ.png",
        "id_str" : "519515353903165440",
        "id" : 519515353903165440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzWwdjzCcAA3RCQ.png",
        "sizes" : [ {
          "h" : 199,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 351,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/JESzEZ0jiV"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 68, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519515354813726720",
    "text" : "Yikes! Check out these 3 @NASA satellite images of water loss in CA #ActOnClimate http:\/\/t.co\/JESzEZ0jiV",
    "id" : 519515354813726720,
    "created_at" : "2014-10-07 15:51:27 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 519568660839415808,
  "created_at" : "2014-10-07 19:23:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519513449060368384\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/lmpUGNDxqV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzWuupNCIAEgLZW.jpg",
      "id_str" : "519513448388894721",
      "id" : 519513448388894721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzWuupNCIAEgLZW.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lmpUGNDxqV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/hfl01FQuWW",
      "expanded_url" : "http:\/\/go.wh.gov\/fa8GQj",
      "display_url" : "go.wh.gov\/fa8GQj"
    } ]
  },
  "geo" : { },
  "id_str" : "519549337899397120",
  "text" : "The unemployment rate \u2193 to 5.9% last month.\nThat's the lowest it's been in 6 years.\nhttp:\/\/t.co\/hfl01FQuWW http:\/\/t.co\/lmpUGNDxqV",
  "id" : 519549337899397120,
  "created_at" : "2014-10-07 18:06:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519513449060368384\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/lmpUGNDxqV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzWuupNCIAEgLZW.jpg",
      "id_str" : "519513448388894721",
      "id" : 519513448388894721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzWuupNCIAEgLZW.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lmpUGNDxqV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519538843872419841",
  "text" : "FACT: The unemployment rate fell to 5.9% last month\u2014the lowest since July 2008\u2014and is down 1.3% over the last year. http:\/\/t.co\/lmpUGNDxqV",
  "id" : 519538843872419841,
  "created_at" : "2014-10-07 17:24:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519513449060368384\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/lmpUGNDxqV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzWuupNCIAEgLZW.jpg",
      "id_str" : "519513448388894721",
      "id" : 519513448388894721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzWuupNCIAEgLZW.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lmpUGNDxqV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/hfl01FQuWW",
      "expanded_url" : "http:\/\/go.wh.gov\/fa8GQj",
      "display_url" : "go.wh.gov\/fa8GQj"
    } ]
  },
  "geo" : { },
  "id_str" : "519513449060368384",
  "text" : "RT to spread the word: The unemployment rate is the lowest it's been in 6 years \u2192 http:\/\/t.co\/hfl01FQuWW http:\/\/t.co\/lmpUGNDxqV",
  "id" : 519513449060368384,
  "created_at" : "2014-10-07 15:43:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/519500763203383296\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/P5IEr5fLHT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzWjMEzCIAAU7Ez.jpg",
      "id_str" : "519500759872708608",
      "id" : 519500759872708608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzWjMEzCIAAU7Ez.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/P5IEr5fLHT"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/0RT8S8yZoB",
      "expanded_url" : "http:\/\/go.wh.gov\/KVpbZC",
      "display_url" : "go.wh.gov\/KVpbZC"
    } ]
  },
  "geo" : { },
  "id_str" : "519500763203383296",
  "text" : "\"We're doing everything we can to make sure...the American people are safe.\" \u2014Obama: http:\/\/t.co\/0RT8S8yZoB #Ebola http:\/\/t.co\/P5IEr5fLHT",
  "id" : 519500763203383296,
  "created_at" : "2014-10-07 14:53:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/akWsI1nrq5",
      "expanded_url" : "http:\/\/go.wh.gov\/WLVMA1",
      "display_url" : "go.wh.gov\/WLVMA1"
    } ]
  },
  "geo" : { },
  "id_str" : "519483959408078848",
  "text" : "Millions of Americans around the country support raising the minimum wage. Read some of their stories \u2192 http:\/\/t.co\/akWsI1nrq5 #RaiseTheWage",
  "id" : 519483959408078848,
  "created_at" : "2014-10-07 13:46:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519252840083365888\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/AIAZaUDmfp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzTBtNZIgAA7evs.jpg",
      "id_str" : "519252839487799296",
      "id" : 519252839487799296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzTBtNZIgAA7evs.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/AIAZaUDmfp"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 43, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/8S19Q6DDRT",
      "expanded_url" : "http:\/\/go.wh.gov\/epSSs6",
      "display_url" : "go.wh.gov\/epSSs6"
    } ]
  },
  "geo" : { },
  "id_str" : "519252840083365888",
  "text" : "Get the latest on the U.S. response to the #Ebola epidemic in West Africa \u2192 http:\/\/t.co\/8S19Q6DDRT http:\/\/t.co\/AIAZaUDmfp",
  "id" : 519252840083365888,
  "created_at" : "2014-10-06 22:28:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519247811783974912",
  "text" : "RT @VP: \"It's time to raise the wage for millions of people.\" -VP Biden meeting with local leaders in Las Vegas #RaiseTheWage http:\/\/t.co\/e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/519242561114734592\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/eJEhwfLrgZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzS4W4KCYAAXOY_.jpg",
        "id_str" : "519242560225566720",
        "id" : 519242560225566720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzS4W4KCYAAXOY_.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/eJEhwfLrgZ"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 104, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519242561114734592",
    "text" : "\"It's time to raise the wage for millions of people.\" -VP Biden meeting with local leaders in Las Vegas #RaiseTheWage http:\/\/t.co\/eJEhwfLrgZ",
    "id" : 519242561114734592,
    "created_at" : "2014-10-06 21:47:28 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 519247811783974912,
  "created_at" : "2014-10-06 22:08:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519232829356777472\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/qxJ3oBXCjS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzSvgasIIAABfHv.jpg",
      "id_str" : "519232828509528064",
      "id" : 519232828509528064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzSvgasIIAABfHv.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qxJ3oBXCjS"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519232829356777472",
  "text" : "Raising the minimum wage would benefit millions of Americans.\n\nRT if you agree it's time to raise it. #RaiseTheWage http:\/\/t.co\/qxJ3oBXCjS",
  "id" : 519232829356777472,
  "created_at" : "2014-10-06 21:08:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/akWsI1nrq5",
      "expanded_url" : "http:\/\/go.wh.gov\/WLVMA1",
      "display_url" : "go.wh.gov\/WLVMA1"
    } ]
  },
  "geo" : { },
  "id_str" : "519218903239917568",
  "text" : "\"We are preparing to voluntarily raise our employees\u2019 wages.\" \u2014Rebecca L. from PA: http:\/\/t.co\/akWsI1nrq5 #RaiseTheWage",
  "id" : 519218903239917568,
  "created_at" : "2014-10-06 20:13:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519206848155893760",
  "text" : "RT @JFriedman44: POTUS just met with lead financial regulators on the economy and ongoing implementation of Wall Street reform. More: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/kzNTjWBHd7",
        "expanded_url" : "http:\/\/1.usa.gov\/1oK8dm8",
        "display_url" : "1.usa.gov\/1oK8dm8"
      } ]
    },
    "geo" : { },
    "id_str" : "519194520639270913",
    "text" : "POTUS just met with lead financial regulators on the economy and ongoing implementation of Wall Street reform. More: http:\/\/t.co\/kzNTjWBHd7",
    "id" : 519194520639270913,
    "created_at" : "2014-10-06 18:36:34 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 519206848155893760,
  "created_at" : "2014-10-06 19:25:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Z2EgBljtUh",
      "expanded_url" : "http:\/\/go.wh.gov\/kK9mX9",
      "display_url" : "go.wh.gov\/kK9mX9"
    } ]
  },
  "geo" : { },
  "id_str" : "519196704206102528",
  "text" : "Worth a read: Small business owners on why \"The American Dream needs a fair minimum wage.\" http:\/\/t.co\/Z2EgBljtUh #RaiseTheWage",
  "id" : 519196704206102528,
  "created_at" : "2014-10-06 18:45:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/akWsI1nrq5",
      "expanded_url" : "http:\/\/go.wh.gov\/WLVMA1",
      "display_url" : "go.wh.gov\/WLVMA1"
    } ]
  },
  "geo" : { },
  "id_str" : "519188149101416448",
  "text" : "Check out stories from Americans across the country on how raising the minimum wage would help them \u2192 http:\/\/t.co\/akWsI1nrq5 #RaiseTheWage",
  "id" : 519188149101416448,
  "created_at" : "2014-10-06 18:11:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519174194446495744\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7jR4nvp2UM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzR6LZ8IIAAwOw3.png",
      "id_str" : "519174193414676480",
      "id" : 519174193414676480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzR6LZ8IIAAwOw3.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7jR4nvp2UM"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519174194446495744",
  "text" : "FACT: Raising the minimum wage would help more than 2 million Americans lift themselves out of poverty. #RaiseTheWage http:\/\/t.co\/7jR4nvp2UM",
  "id" : 519174194446495744,
  "created_at" : "2014-10-06 17:15:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Sy9g03UBaG",
      "expanded_url" : "http:\/\/wh.gov\/America-leads",
      "display_url" : "wh.gov\/America-leads"
    } ]
  },
  "geo" : { },
  "id_str" : "519165648891805696",
  "text" : "RT @usedgov: RT so your friends know: Our high school graduation rate is the highest it's ever been \u2192 http:\/\/t.co\/Sy9g03UBaG http:\/\/t.co\/q2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/519146573968576512\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/q23VUCk07I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzRhDugCAAA6rqp.jpg",
        "id_str" : "519146573704331264",
        "id" : 519146573704331264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzRhDugCAAA6rqp.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1250,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/q23VUCk07I"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/Sy9g03UBaG",
        "expanded_url" : "http:\/\/wh.gov\/America-leads",
        "display_url" : "wh.gov\/America-leads"
      } ]
    },
    "geo" : { },
    "id_str" : "519146573968576512",
    "text" : "RT so your friends know: Our high school graduation rate is the highest it's ever been \u2192 http:\/\/t.co\/Sy9g03UBaG http:\/\/t.co\/q23VUCk07I",
    "id" : 519146573968576512,
    "created_at" : "2014-10-06 15:26:03 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 519165648891805696,
  "created_at" : "2014-10-06 16:41:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/519161805382631425\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/BkgffFUFQv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzRu6PTCMAE5FIw.jpg",
      "id_str" : "519161803872284673",
      "id" : 519161803872284673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzRu6PTCMAE5FIw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BkgffFUFQv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/akWsI1nrq5",
      "expanded_url" : "http:\/\/go.wh.gov\/WLVMA1",
      "display_url" : "go.wh.gov\/WLVMA1"
    } ]
  },
  "geo" : { },
  "id_str" : "519161805382631425",
  "text" : "\"Raising the minimum wage would allow more students to pay for college\" \u2014Nicholas H. from AK: http:\/\/t.co\/akWsI1nrq5 http:\/\/t.co\/BkgffFUFQv",
  "id" : 519161805382631425,
  "created_at" : "2014-10-06 16:26:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519151412857425920\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/FjCsB0bysb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzRhVkpCAAA5tbv.jpg",
      "id_str" : "519146880295370752",
      "id" : 519146880295370752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzRhVkpCAAA5tbv.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FjCsB0bysb"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/oEArnaztyE",
      "expanded_url" : "http:\/\/go.wh.gov\/WLVMA1",
      "display_url" : "go.wh.gov\/WLVMA1"
    } ]
  },
  "geo" : { },
  "id_str" : "519151412857425920",
  "text" : "Nobody\nwho\nworks\nfull-time\nshould\nhave\nto\nlive\nin\npoverty.\nhttp:\/\/t.co\/oEArnaztyE\n#RaiseTheWage http:\/\/t.co\/FjCsB0bysb",
  "id" : 519151412857425920,
  "created_at" : "2014-10-06 15:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/519145770751389696\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/FjQqwbNSY0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzRgU5cCEAA7Gb9.jpg",
      "id_str" : "519145769186496512",
      "id" : 519145769186496512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzRgU5cCEAA7Gb9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FjQqwbNSY0"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/akWsI1nrq5",
      "expanded_url" : "http:\/\/go.wh.gov\/WLVMA1",
      "display_url" : "go.wh.gov\/WLVMA1"
    } ]
  },
  "geo" : { },
  "id_str" : "519145770751389696",
  "text" : "Here's what raising the minimum wage would mean to folks around the country \u2192 http:\/\/t.co\/akWsI1nrq5 #RaiseTheWage http:\/\/t.co\/FjQqwbNSY0",
  "id" : 519145770751389696,
  "created_at" : "2014-10-06 15:22:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519130637736087553",
  "text" : "RT @Schultz44: \"The U.S. is proving to be an oasis of prosperity in the midst of a troubled world economy.\" \u2014@BloombergNews: http:\/\/t.co\/2V\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/2VnaVLWqnF",
        "expanded_url" : "http:\/\/bloom.bg\/1n06zRS",
        "display_url" : "bloom.bg\/1n06zRS"
      } ]
    },
    "geo" : { },
    "id_str" : "519118628621668354",
    "text" : "\"The U.S. is proving to be an oasis of prosperity in the midst of a troubled world economy.\" \u2014@BloombergNews: http:\/\/t.co\/2VnaVLWqnF",
    "id" : 519118628621668354,
    "created_at" : "2014-10-06 13:35:00 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 519130637736087553,
  "created_at" : "2014-10-06 14:22:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/KNibFVKvIl",
      "expanded_url" : "http:\/\/bloom.bg\/1n06zRS",
      "display_url" : "bloom.bg\/1n06zRS"
    } ]
  },
  "geo" : { },
  "id_str" : "519119846265864192",
  "text" : "\"U.S. factories had their strongest quarter in more than three years, while exports rose to a record in August.\" http:\/\/t.co\/KNibFVKvIl",
  "id" : 519119846265864192,
  "created_at" : "2014-10-06 13:39:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/0NHVW7RMD6",
      "expanded_url" : "http:\/\/go.wh.gov\/EMKzGM",
      "display_url" : "go.wh.gov\/EMKzGM"
    } ]
  },
  "geo" : { },
  "id_str" : "518928679351492609",
  "text" : "\"We do better when the middle class does better.\" \u2014President Obama in his weekly address: http:\/\/t.co\/0NHVW7RMD6 #AmericaLeads",
  "id" : 518928679351492609,
  "created_at" : "2014-10-06 01:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/0NHVW7RMD6",
      "expanded_url" : "http:\/\/go.wh.gov\/EMKzGM",
      "display_url" : "go.wh.gov\/EMKzGM"
    } ]
  },
  "geo" : { },
  "id_str" : "518815397223481344",
  "text" : "\"The folks who keep blocking a minimum wage increase are running out of excuses. Let\u2019s give America a raise.\" \u2014Obama: http:\/\/t.co\/0NHVW7RMD6",
  "id" : 518815397223481344,
  "created_at" : "2014-10-05 17:30:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0422\u0430\u043D\u044C\u043A\u043E \u0411\u0430\u0436\u0435\u043D\u043E\u0432\u0430",
      "screen_name" : "AVDLM",
      "indices" : [ 89, 95 ],
      "id_str" : "164613896",
      "id" : 164613896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518802018929238018",
  "text" : "\"To every wounded warrior, to every disabled veteran\u2014thank you.\" \u2014President Obama at the @AVDLM #HonoringVets",
  "id" : 518802018929238018,
  "created_at" : "2014-10-05 16:36:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518801567773110272",
  "text" : "\"Let us stand united as Americans and welcome our veterans home with the thanks and respect they deserve.\" \u2014President Obama #HonoringVets",
  "id" : 518801567773110272,
  "created_at" : "2014-10-05 16:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518801404946038784",
  "text" : "\"Let\u2019s never rush into war\u2014because it is America\u2019s sons &amp; daughters who bear the scars of war for the rest of their lives.\" \u2014President Obama",
  "id" : 518801404946038784,
  "created_at" : "2014-10-05 16:34:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0422\u0430\u043D\u044C\u043A\u043E \u0411\u0430\u0436\u0435\u043D\u043E\u0432\u0430",
      "screen_name" : "AVDLM",
      "indices" : [ 125, 131 ],
      "id_str" : "164613896",
      "id" : 164613896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518800216322224128",
  "text" : "\"When you\u2019ve fallen, you\u2019ve picked yourself up, you\u2019ve carried on, you\u2019ve never give up.\" \u2014Obama to disabled veterans at the @AVDLM",
  "id" : 518800216322224128,
  "created_at" : "2014-10-05 16:29:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518799466519076866",
  "text" : "\"In the United States of America, those who have fought for our freedom should never be shunned and should never be forgotten.\" \u2014Obama",
  "id" : 518799466519076866,
  "created_at" : "2014-10-05 16:26:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0422\u0430\u043D\u044C\u043A\u043E \u0411\u0430\u0436\u0435\u043D\u043E\u0432\u0430",
      "screen_name" : "AVDLM",
      "indices" : [ 138, 144 ],
      "id_str" : "164613896",
      "id" : 164613896
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518798323487346688",
  "text" : "\"Each of you endured a moment that shaped the arc of your lives &amp; that speaks to our debt as a nation\" \u2014Obama to disabled vets at the @AVDLM",
  "id" : 518798323487346688,
  "created_at" : "2014-10-05 16:22:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "518798192511840256",
  "text" : "Watch live: President Obama speaks at the American Veterans Disabled for Life Memorial dedication \u2192 http:\/\/t.co\/b4tqL36eMn",
  "id" : 518798192511840256,
  "created_at" : "2014-10-05 16:21:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "National Mall NPS",
      "screen_name" : "NationalMallNPS",
      "indices" : [ 32, 48 ],
      "id_str" : "495149176",
      "id" : 495149176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/xSMjcOMfMy",
      "expanded_url" : "http:\/\/on.doi.gov\/1BDGY2s",
      "display_url" : "on.doi.gov\/1BDGY2s"
    } ]
  },
  "geo" : { },
  "id_str" : "518794795704385536",
  "text" : "RT @Interior: FIRST LOOK at new @NationalMallNPS memorial American Disabled Veterans for Life Memorial \u2192 http:\/\/t.co\/xSMjcOMfMy http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Mall NPS",
        "screen_name" : "NationalMallNPS",
        "indices" : [ 18, 34 ],
        "id_str" : "495149176",
        "id" : 495149176
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/518764387864444928\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/D36PbgViJA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzMFdjgIAAAFPxN.jpg",
        "id_str" : "518764387382067200",
        "id" : 518764387382067200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzMFdjgIAAAFPxN.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/D36PbgViJA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/xSMjcOMfMy",
        "expanded_url" : "http:\/\/on.doi.gov\/1BDGY2s",
        "display_url" : "on.doi.gov\/1BDGY2s"
      } ]
    },
    "geo" : { },
    "id_str" : "518764387864444928",
    "text" : "FIRST LOOK at new @NationalMallNPS memorial American Disabled Veterans for Life Memorial \u2192 http:\/\/t.co\/xSMjcOMfMy http:\/\/t.co\/D36PbgViJA",
    "id" : 518764387864444928,
    "created_at" : "2014-10-05 14:07:22 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 518794795704385536,
  "created_at" : "2014-10-05 16:08:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "518786877160439809",
  "text" : "At 12pm ET, watch President Obama speak at the American Veterans Disabled for Life Memorial dedication  \u2192 http:\/\/t.co\/b4tqL36eMn",
  "id" : 518786877160439809,
  "created_at" : "2014-10-05 15:36:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/518119047809220608\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Nt5lAzWUTg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzC6hz4CEAA-eUf.jpg",
      "id_str" : "518119047171280896",
      "id" : 518119047171280896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzC6hz4CEAA-eUf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Nt5lAzWUTg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/0NHVW7RMD6",
      "expanded_url" : "http:\/\/go.wh.gov\/EMKzGM",
      "display_url" : "go.wh.gov\/EMKzGM"
    } ]
  },
  "geo" : { },
  "id_str" : "518777713109106689",
  "text" : "\"Over the past 55 months, our businesses have added 10.3 million new jobs.\" \u2014President Obama: http:\/\/t.co\/0NHVW7RMD6 http:\/\/t.co\/Nt5lAzWUTg",
  "id" : 518777713109106689,
  "created_at" : "2014-10-05 15:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/0NHVW7RMD6",
      "expanded_url" : "http:\/\/go.wh.gov\/EMKzGM",
      "display_url" : "go.wh.gov\/EMKzGM"
    } ]
  },
  "geo" : { },
  "id_str" : "518762615481196544",
  "text" : "\"It\u2019s time to raise the minimum wage. It would put more money in workers\u2019 pockets.\" \u2014President Obama: http:\/\/t.co\/0NHVW7RMD6 #RaiseTheWage",
  "id" : 518762615481196544,
  "created_at" : "2014-10-05 14:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/KNibFVKvIl",
      "expanded_url" : "http:\/\/bloom.bg\/1n06zRS",
      "display_url" : "bloom.bg\/1n06zRS"
    } ]
  },
  "geo" : { },
  "id_str" : "518497161953419264",
  "text" : "Worth a read from @BloombergNews: \"American Exceptionalism Thrives Amid Struggling Global Economy.\" \u2192 http:\/\/t.co\/KNibFVKvIl",
  "id" : 518497161953419264,
  "created_at" : "2014-10-04 20:25:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518119047809220608\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Nt5lAzWUTg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzC6hz4CEAA-eUf.jpg",
      "id_str" : "518119047171280896",
      "id" : 518119047171280896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzC6hz4CEAA-eUf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Nt5lAzWUTg"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/0NHVW7RMD6",
      "expanded_url" : "http:\/\/go.wh.gov\/EMKzGM",
      "display_url" : "go.wh.gov\/EMKzGM"
    } ]
  },
  "geo" : { },
  "id_str" : "518445561855242240",
  "text" : "\"Last month, our businesses added 236,000 new jobs.\" \u2014President Obama: http:\/\/t.co\/0NHVW7RMD6 #AmericaLeads http:\/\/t.co\/Nt5lAzWUTg",
  "id" : 518445561855242240,
  "created_at" : "2014-10-04 17:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/0NHVW7RMD6",
      "expanded_url" : "http:\/\/go.wh.gov\/EMKzGM",
      "display_url" : "go.wh.gov\/EMKzGM"
    } ]
  },
  "geo" : { },
  "id_str" : "518422841012662273",
  "text" : "President Obama's weekly address: We do better when the middle class does better \u2192 http:\/\/t.co\/0NHVW7RMD6 #AmericaLeads",
  "id" : 518422841012662273,
  "created_at" : "2014-10-04 15:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/eC06zyYFWf",
      "expanded_url" : "http:\/\/go.wh.gov\/EMKzGM",
      "display_url" : "go.wh.gov\/EMKzGM"
    } ]
  },
  "geo" : { },
  "id_str" : "518407554989584384",
  "text" : "\"We\u2019re on pace to make 2014 the strongest year of job growth since the 1990s.\" \u2014President Obama: http:\/\/t.co\/eC06zyYFWf #AmericaLeads",
  "id" : 518407554989584384,
  "created_at" : "2014-10-04 14:29:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/518181127115112448\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/Avnjx3ixml",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzDy959CcAEYQRY.jpg",
      "id_str" : "518181102490382337",
      "id" : 518181102490382337,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzDy959CcAEYQRY.jpg",
      "sizes" : [ {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1960,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Avnjx3ixml"
    } ],
    "hashtags" : [ {
      "text" : "HappyAnniversary",
      "indices" : [ 22, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518181838217818113",
  "text" : "RT @FLOTUS: 22 years. #HappyAnniversary http:\/\/t.co\/Avnjx3ixml",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/518181127115112448\/photo\/1",
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/Avnjx3ixml",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzDy959CcAEYQRY.jpg",
        "id_str" : "518181102490382337",
        "id" : 518181102490382337,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzDy959CcAEYQRY.jpg",
        "sizes" : [ {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1960,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Avnjx3ixml"
      } ],
      "hashtags" : [ {
        "text" : "HappyAnniversary",
        "indices" : [ 10, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518181127115112448",
    "text" : "22 years. #HappyAnniversary http:\/\/t.co\/Avnjx3ixml",
    "id" : 518181127115112448,
    "created_at" : "2014-10-03 23:29:42 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 518181838217818113,
  "created_at" : "2014-10-03 23:32:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518169499775016960\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Aa5WnTzQqx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzDoae0CAAA52g1.png",
      "id_str" : "518169498793148416",
      "id" : 518169498793148416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzDoae0CAAA52g1.png",
      "sizes" : [ {
        "h" : 99,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 175,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Aa5WnTzQqx"
    } ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518169499775016960",
  "text" : "\"The United States strongly condemns the brutal murder of United Kingdom citizen Alan Henning.\" \u2014Obama #ISIL http:\/\/t.co\/Aa5WnTzQqx",
  "id" : 518169499775016960,
  "created_at" : "2014-10-03 22:43:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 1, 9 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/oIc2EQXozx",
      "expanded_url" : "http:\/\/go.wh.gov\/JzRXda",
      "display_url" : "go.wh.gov\/JzRXda"
    } ]
  },
  "geo" : { },
  "id_str" : "518165148419522561",
  "text" : ".@Cabinet members touted the strength of U.S. manufacturing at factories across the country today: http:\/\/t.co\/oIc2EQXozx #MadeInAmerica",
  "id" : 518165148419522561,
  "created_at" : "2014-10-03 22:26:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/wVyNoqv1Qu",
      "expanded_url" : "http:\/\/www.vox.com\/2014\/10\/3\/6902847\/accelerating-recovery?utm_medium=social&utm_source=facebook&utm_campaign=voxdotcom&utm_content=friday",
      "display_url" : "vox.com\/2014\/10\/3\/6902\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518150114570166272",
  "text" : "RT @voxdotcom: Good news! The economy is adding jobs at its fastest pace since the recession began: http:\/\/t.co\/wVyNoqv1Qu http:\/\/t.co\/TqmQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/voxdotcom\/status\/518124648446189568\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/TqmQARVZ2C",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzC4g7oCAAE3AG4.png",
        "id_str" : "518116833048526849",
        "id" : 518116833048526849,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzC4g7oCAAE3AG4.png",
        "sizes" : [ {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TqmQARVZ2C"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/wVyNoqv1Qu",
        "expanded_url" : "http:\/\/www.vox.com\/2014\/10\/3\/6902847\/accelerating-recovery?utm_medium=social&utm_source=facebook&utm_campaign=voxdotcom&utm_content=friday",
        "display_url" : "vox.com\/2014\/10\/3\/6902\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "518124648446189568",
    "text" : "Good news! The economy is adding jobs at its fastest pace since the recession began: http:\/\/t.co\/wVyNoqv1Qu http:\/\/t.co\/TqmQARVZ2C",
    "id" : 518124648446189568,
    "created_at" : "2014-10-03 19:45:17 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 518150114570166272,
  "created_at" : "2014-10-03 21:26:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 97, 108 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/518139861086531584\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/oKROBZZqqp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzDNdP3CUAAoKCI.jpg",
      "id_str" : "518139859504877568",
      "id" : 518139859504877568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzDNdP3CUAAoKCI.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oKROBZZqqp"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518140598126383104",
  "text" : "RT @WHLive: \u201CWe have the public health systems\u2026in place to contain the spread of this disease.\u201D \u2014@SecBurwell #Ebola http:\/\/t.co\/oKROBZZqqp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sylvia Burwell",
        "screen_name" : "SecBurwell",
        "indices" : [ 85, 96 ],
        "id_str" : "2458567464",
        "id" : 2458567464
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/518139861086531584\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/oKROBZZqqp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzDNdP3CUAAoKCI.jpg",
        "id_str" : "518139859504877568",
        "id" : 518139859504877568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzDNdP3CUAAoKCI.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/oKROBZZqqp"
      } ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 97, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518139861086531584",
    "text" : "\u201CWe have the public health systems\u2026in place to contain the spread of this disease.\u201D \u2014@SecBurwell #Ebola http:\/\/t.co\/oKROBZZqqp",
    "id" : 518139861086531584,
    "created_at" : "2014-10-03 20:45:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 518140598126383104,
  "created_at" : "2014-10-03 20:48:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518139440603340800\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/osKZjzqCkC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzDNE0fCcAA4SbN.jpg",
      "id_str" : "518139439839604736",
      "id" : 518139439839604736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzDNE0fCcAA4SbN.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/osKZjzqCkC"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/a6FF1SVTFj",
      "expanded_url" : "http:\/\/go.wh.gov\/o5KjEZ",
      "display_url" : "go.wh.gov\/o5KjEZ"
    } ]
  },
  "geo" : { },
  "id_str" : "518139440603340800",
  "text" : "Get the facts on the #Ebola epidemic: http:\/\/t.co\/a6FF1SVTFj http:\/\/t.co\/osKZjzqCkC",
  "id" : 518139440603340800,
  "created_at" : "2014-10-03 20:44:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518138971239755776",
  "text" : "RT @WHLive: \u201CThe United States is prepared to deal with this crisis, both at home and in the [West Africa] region.\u201D\nWatch: http:\/\/t.co\/AGvp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/AGvpbNmCcC",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "518138942059978752",
    "text" : "\u201CThe United States is prepared to deal with this crisis, both at home and in the [West Africa] region.\u201D\nWatch: http:\/\/t.co\/AGvpbNmCcC #Ebola",
    "id" : 518138942059978752,
    "created_at" : "2014-10-03 20:42:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 518138971239755776,
  "created_at" : "2014-10-03 20:42:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 99, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/v6cj5zWcBT",
      "expanded_url" : "http:\/\/go.wh.gov\/nmxLSU",
      "display_url" : "go.wh.gov\/nmxLSU"
    } ]
  },
  "geo" : { },
  "id_str" : "518137288740864001",
  "text" : "Watch live: Senior Administration officials hold a briefing on the U.S. government response to the #Ebola epidemic \u2192 http:\/\/t.co\/v6cj5zWcBT",
  "id" : 518137288740864001,
  "created_at" : "2014-10-03 20:35:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/518134329281875968\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/FJmQ3KqB3j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzDIbM4CIAACh1i.jpg",
      "id_str" : "518134326785875968",
      "id" : 518134326785875968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzDIbM4CIAACh1i.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FJmQ3KqB3j"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518134405114916864",
  "text" : "RT @WHLive: \u201CSince I\u2019ve been President...the deficit\u2019s been cut by more than half.\u201D \u2014Obama http:\/\/t.co\/FJmQ3KqB3j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/518134329281875968\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/FJmQ3KqB3j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzDIbM4CIAACh1i.jpg",
        "id_str" : "518134326785875968",
        "id" : 518134326785875968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzDIbM4CIAACh1i.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1250,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FJmQ3KqB3j"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518134329281875968",
    "text" : "\u201CSince I\u2019ve been President...the deficit\u2019s been cut by more than half.\u201D \u2014Obama http:\/\/t.co\/FJmQ3KqB3j",
    "id" : 518134329281875968,
    "created_at" : "2014-10-03 20:23:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 518134405114916864,
  "created_at" : "2014-10-03 20:24:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518132205978398721\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/xCuAGkL7Zx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzDGft7CUAAwujP.jpg",
      "id_str" : "518132205353062400",
      "id" : 518132205353062400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzDGft7CUAAwujP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xCuAGkL7Zx"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518132205978398721",
  "text" : "\u201CI don\u2019t think my daughters should be treated any different than somebody else\u2019s sons.\u201D \u2014President Obama #EqualPay http:\/\/t.co\/xCuAGkL7Zx",
  "id" : 518132205978398721,
  "created_at" : "2014-10-03 20:15:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/deke6aMsTT",
      "expanded_url" : "http:\/\/go.wh.gov\/LjioaM",
      "display_url" : "go.wh.gov\/LjioaM"
    } ]
  },
  "geo" : { },
  "id_str" : "518130892129456128",
  "text" : "\u201CManufacturing offers great opportunities.\u201D \u2014President Obama encouraging more young people to go into manufacturing: http:\/\/t.co\/deke6aMsTT",
  "id" : 518130892129456128,
  "created_at" : "2014-10-03 20:10:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518125739494092802\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/SwdAbGgere",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzDAnToCYAA3BuQ.jpg",
      "id_str" : "518125738663239680",
      "id" : 518125738663239680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzDAnToCYAA3BuQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SwdAbGgere"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518125739494092802",
  "text" : "\u201CWe\u2019ve signed up 10 million people to get health coverage, in many cases for the first time.\u201D \u2014Obama #ACAWorks http:\/\/t.co\/SwdAbGgere",
  "id" : 518125739494092802,
  "created_at" : "2014-10-03 19:49:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518123503279960064\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/0tnbrbV5bN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzC-lI2CIAENc5u.jpg",
      "id_str" : "518123502386159617",
      "id" : 518123502386159617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzC-lI2CIAENc5u.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/0tnbrbV5bN"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518123503279960064",
  "text" : "\"The average age of someone getting paid the minimum wage is 35 years old, they\u2019re not 16.\u201D \u2014Obama #RaiseTheWage http:\/\/t.co\/0tnbrbV5bN",
  "id" : 518123503279960064,
  "created_at" : "2014-10-03 19:40:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518121591667191808",
  "text" : "\"Everybody should have opportunity. It shouldn\u2019t matter how you started out, if you\u2019re willing to work hard.\" \u2014Obama #OpportunityForAll",
  "id" : 518121591667191808,
  "created_at" : "2014-10-03 19:33:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518121098278621184\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/fGav2FkunB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzC8ZKACIAA43Fh.jpg",
      "id_str" : "518121097514852352",
      "id" : 518121097514852352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzC8ZKACIAA43Fh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fGav2FkunB"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518121098278621184",
  "text" : "\u201CWe should be making sure that women are getting paid the same as men for doing the same work.\u201D \u2014Obama #EqualPay http:\/\/t.co\/fGav2FkunB",
  "id" : 518121098278621184,
  "created_at" : "2014-10-03 19:31:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518120820858966016\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/r3NEfiXXoz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzC8JBDCAAAeUgD.jpg",
      "id_str" : "518120820233601024",
      "id" : 518120820233601024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzC8JBDCAAAeUgD.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/r3NEfiXXoz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518120820858966016",
  "text" : "\u201CWe should be raising the minimum wage\u2026if they\u2019re working full-time they shouldn\u2019t be living in poverty.\u201D \u2014Obama http:\/\/t.co\/r3NEfiXXoz",
  "id" : 518120820858966016,
  "created_at" : "2014-10-03 19:30:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518119677449760769\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/sdITArHsr5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzC7GdlCQAAQIzg.jpg",
      "id_str" : "518119676841181184",
      "id" : 518119676841181184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzC7GdlCQAAQIzg.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sdITArHsr5"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518119677449760769",
  "text" : "\"Manufacturing as a whole has added more than 700,000 new jobs.\" \u2014President Obama #AmericaLeads http:\/\/t.co\/sdITArHsr5",
  "id" : 518119677449760769,
  "created_at" : "2014-10-03 19:25:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518119047809220608\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Nt5lAzWUTg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzC6hz4CEAA-eUf.jpg",
      "id_str" : "518119047171280896",
      "id" : 518119047171280896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzC6hz4CEAA-eUf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Nt5lAzWUTg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518119047809220608",
  "text" : "\"Last month, our businesses added more than 236,000 jobs. The unemployment rate fell from 6.1% to 5.9%.\" \u2014Obama http:\/\/t.co\/Nt5lAzWUTg",
  "id" : 518119047809220608,
  "created_at" : "2014-10-03 19:23:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/deke6aMsTT",
      "expanded_url" : "http:\/\/go.wh.gov\/LjioaM",
      "display_url" : "go.wh.gov\/LjioaM"
    } ]
  },
  "geo" : { },
  "id_str" : "518118565917241345",
  "text" : "\"Today is National Manufacturing Day.\" \u2014President Obama to steelworkers: http:\/\/t.co\/deke6aMsTT #MadeInAmerica",
  "id" : 518118565917241345,
  "created_at" : "2014-10-03 19:21:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/up939PqClk",
      "expanded_url" : "http:\/\/go.wh.gov\/PrZYmA",
      "display_url" : "go.wh.gov\/PrZYmA"
    } ]
  },
  "geo" : { },
  "id_str" : "518117833516281856",
  "text" : "Watch live: President Obama holds a conversation with Millennium Steel Service workers in Indiana \u2192 http:\/\/t.co\/up939PqClk #MadeInAmerica",
  "id" : 518117833516281856,
  "created_at" : "2014-10-03 19:18:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/up939PqClk",
      "expanded_url" : "http:\/\/go.wh.gov\/PrZYmA",
      "display_url" : "go.wh.gov\/PrZYmA"
    } ]
  },
  "geo" : { },
  "id_str" : "518113188064546816",
  "text" : "At 3:05pm ET, President Obama holds a conversation with Millennium Steel Service workers in Indiana \u2192 http:\/\/t.co\/up939PqClk #MadeInAmerica",
  "id" : 518113188064546816,
  "created_at" : "2014-10-03 18:59:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518105786510491648\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/kGdpKbkpqd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzCud5DCQAAIMHy.jpg",
      "id_str" : "518105785700597760",
      "id" : 518105785700597760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzCud5DCQAAIMHy.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/kGdpKbkpqd"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518105786510491648",
  "text" : "RT to spread the word: Our businesses are now on pace for the strongest year of job growth since 1998. #AmericaLeads http:\/\/t.co\/kGdpKbkpqd",
  "id" : 518105786510491648,
  "created_at" : "2014-10-03 18:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHealthchat",
      "indices" : [ 96, 109 ]
    }, {
      "text" : "ACAworks",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518088271965204480",
  "text" : "RT @HealthCareTara: Hey everyone, here to answer Qs on health and the ACA.  Keep em coming with #WHHealthchat #ACAworks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHHealthchat",
        "indices" : [ 76, 89 ]
      }, {
        "text" : "ACAworks",
        "indices" : [ 90, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518087941944774656",
    "text" : "Hey everyone, here to answer Qs on health and the ACA.  Keep em coming with #WHHealthchat #ACAworks",
    "id" : 518087941944774656,
    "created_at" : "2014-10-03 17:19:25 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 518088271965204480,
  "created_at" : "2014-10-03 17:20:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 23, 38 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHealthChat",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518083590186622977",
  "text" : "RT @WHLive: At 1pm ET, @HealthCareTara answers your Q's on health care and the Affordable Care Act. Ask away with #WHHealthChat. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
        "screen_name" : "HealthCareTara",
        "indices" : [ 11, 26 ],
        "id_str" : "9448842",
        "id" : 9448842
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/518081209587732480\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/fX0YozmXKe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzCYHUVCQAAsl6U.jpg",
        "id_str" : "518081208631050240",
        "id" : 518081208631050240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzCYHUVCQAAsl6U.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1250,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/fX0YozmXKe"
      } ],
      "hashtags" : [ {
        "text" : "WHHealthChat",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518081209587732480",
    "text" : "At 1pm ET, @HealthCareTara answers your Q's on health care and the Affordable Care Act. Ask away with #WHHealthChat. http:\/\/t.co\/fX0YozmXKe",
    "id" : 518081209587732480,
    "created_at" : "2014-10-03 16:52:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 518083590186622977,
  "created_at" : "2014-10-03 17:02:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518036926646218752\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/LDae91PRtL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzBv1ukCYAAKZve.jpg",
      "id_str" : "518036925970538496",
      "id" : 518036925970538496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzBv1ukCYAAKZve.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LDae91PRtL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518079655602298881",
  "text" : "Our businesses have added 10.3 million jobs over 55 straight months of growth\u2014the longest such streak on record. http:\/\/t.co\/LDae91PRtL",
  "id" : 518079655602298881,
  "created_at" : "2014-10-03 16:46:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHeconchat",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518069483332964352",
  "text" : "RT @CEAChair: Hello everyone, I'm here to answer your questions on jobs and the economy. Ask away with #WHeconchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHeconchat",
        "indices" : [ 89, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518068943094042624",
    "text" : "Hello everyone, I'm here to answer your questions on jobs and the economy. Ask away with #WHeconchat",
    "id" : 518068943094042624,
    "created_at" : "2014-10-03 16:03:55 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 518069483332964352,
  "created_at" : "2014-10-03 16:06:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518068144121053185",
  "text" : "RT @VP: \"We\u2019re America. Americans will never, ever stand down. We endure. We overcome. We own the finish line.\" -VP Biden http:\/\/t.co\/e1sdx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/518065814055182336\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/e1sdxmqjui",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BzCKG5cIMAAYNP8.png",
        "id_str" : "518065808250253312",
        "id" : 518065808250253312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzCKG5cIMAAYNP8.png",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/e1sdxmqjui"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518065814055182336",
    "text" : "\"We\u2019re America. Americans will never, ever stand down. We endure. We overcome. We own the finish line.\" -VP Biden http:\/\/t.co\/e1sdxmqjui",
    "id" : 518065814055182336,
    "created_at" : "2014-10-03 15:51:29 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 518068144121053185,
  "created_at" : "2014-10-03 16:00:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518036926646218752\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/LDae91PRtL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzBv1ukCYAAKZve.jpg",
      "id_str" : "518036925970538496",
      "id" : 518036925970538496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzBv1ukCYAAKZve.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LDae91PRtL"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/DtCFZ3oFB3",
      "expanded_url" : "http:\/\/go.wh.gov\/P1oFaa",
      "display_url" : "go.wh.gov\/P1oFaa"
    } ]
  },
  "geo" : { },
  "id_str" : "518051617426255873",
  "text" : "FACT: Our manufacturers have added more than 700,000 jobs since February 2010. http:\/\/t.co\/DtCFZ3oFB3 #ActOnJobs http:\/\/t.co\/LDae91PRtL",
  "id" : 518051617426255873,
  "created_at" : "2014-10-03 14:55:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHealthChat",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518048290328571905",
  "text" : "RT @HealthCareTara: One of the President's cornerstones of a strong economy is affordable health care. Ask your Q's w\/ #WHHealthChat and I'\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHHealthChat",
        "indices" : [ 99, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "518047167676960768",
    "text" : "One of the President's cornerstones of a strong economy is affordable health care. Ask your Q's w\/ #WHHealthChat and I'll answer at 1pm ET.",
    "id" : 518047167676960768,
    "created_at" : "2014-10-03 14:37:24 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 518048290328571905,
  "created_at" : "2014-10-03 14:41:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHEconChat",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "518046921253224449",
  "text" : "RT @CEAChair: Got questions on the economy &amp; today's jobs report? Join me for Q&amp;A at 12ET today. Ask now with #WHEconChat: http:\/\/t.co\/8gNw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHEconChat",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/8gNwkzBmXv",
        "expanded_url" : "http:\/\/wh.gov\/iizf9",
        "display_url" : "wh.gov\/iizf9"
      } ]
    },
    "geo" : { },
    "id_str" : "518043376114216960",
    "text" : "Got questions on the economy &amp; today's jobs report? Join me for Q&amp;A at 12ET today. Ask now with #WHEconChat: http:\/\/t.co\/8gNwkzBmXv",
    "id" : 518043376114216960,
    "created_at" : "2014-10-03 14:22:20 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 518046921253224449,
  "created_at" : "2014-10-03 14:36:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/aNP60nT2PL",
      "expanded_url" : "http:\/\/go.wh.gov\/P1oFaa",
      "display_url" : "go.wh.gov\/P1oFaa"
    } ]
  },
  "geo" : { },
  "id_str" : "518043289371824128",
  "text" : "FACT: The unemployment rate fell to 5.9% last month\u2014the lowest since July 2008\u2014and is down 1.3% over the last year \u2192 http:\/\/t.co\/aNP60nT2PL",
  "id" : 518043289371824128,
  "created_at" : "2014-10-03 14:21:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/518036926646218752\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/LDae91PRtL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzBv1ukCYAAKZve.jpg",
      "id_str" : "518036925970538496",
      "id" : 518036925970538496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzBv1ukCYAAKZve.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LDae91PRtL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/aNP60nT2PL",
      "expanded_url" : "http:\/\/go.wh.gov\/P1oFaa",
      "display_url" : "go.wh.gov\/P1oFaa"
    } ]
  },
  "geo" : { },
  "id_str" : "518036926646218752",
  "text" : "Good news: Our businesses are now on pace for the strongest year of job growth since 1998. http:\/\/t.co\/aNP60nT2PL http:\/\/t.co\/LDae91PRtL",
  "id" : 518036926646218752,
  "created_at" : "2014-10-03 13:56:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/flZBDUw4Wv",
      "expanded_url" : "http:\/\/go.wh.gov\/7r4rqN",
      "display_url" : "go.wh.gov\/7r4rqN"
    } ]
  },
  "geo" : { },
  "id_str" : "517824941207859200",
  "text" : "Watch live: President Obama speaks at the Congressional Hispanic Caucus Institute Awards Gala \u2192 http:\/\/t.co\/flZBDUw4Wv",
  "id" : 517824941207859200,
  "created_at" : "2014-10-02 23:54:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Northwestern",
      "screen_name" : "NorthwesternU",
      "indices" : [ 57, 71 ],
      "id_str" : "33639255",
      "id" : 33639255
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517815347165290496\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/wjS48uMvNT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By-mUG-IcAAPmbd.jpg",
      "id_str" : "517815346569703424",
      "id" : 517815346569703424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By-mUG-IcAAPmbd.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wjS48uMvNT"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/IYD2qteVJu",
      "expanded_url" : "http:\/\/wh.gov\/America-leads",
      "display_url" : "wh.gov\/America-leads"
    } ]
  },
  "geo" : { },
  "id_str" : "517815347165290496",
  "text" : "\"The story of America is a story of progress.\" \u2014Obama at @NorthwesternU: http:\/\/t.co\/IYD2qteVJu #AmericaLeads http:\/\/t.co\/wjS48uMvNT",
  "id" : 517815347165290496,
  "created_at" : "2014-10-02 23:16:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 110, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517811182229815296",
  "text" : "RT @usedgov: Our high school graduation rate = The highest it's ever been.\nBut we've got to do more to expand #CollegeOpportunity. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/usedgov\/status\/517787367038414848\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/W4TIp3uxaJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/By-M3eVCYAETGeh.jpg",
        "id_str" : "517787366832889857",
        "id" : 517787366832889857,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By-M3eVCYAETGeh.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1250,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/W4TIp3uxaJ"
      } ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 97, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517787367038414848",
    "text" : "Our high school graduation rate = The highest it's ever been.\nBut we've got to do more to expand #CollegeOpportunity. http:\/\/t.co\/W4TIp3uxaJ",
    "id" : 517787367038414848,
    "created_at" : "2014-10-02 21:25:02 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 517811182229815296,
  "created_at" : "2014-10-02 22:59:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/fBnrKUdghA",
      "expanded_url" : "http:\/\/snpy.tv\/1r4d3KF",
      "display_url" : "snpy.tv\/1r4d3KF"
    } ]
  },
  "geo" : { },
  "id_str" : "517803898665316353",
  "text" : "\"Let's catch up to 2014. Pass a fair pay law.\" \u2014President Obama to Republicans in Congress on #EqualPay for women http:\/\/t.co\/fBnrKUdghA",
  "id" : 517803898665316353,
  "created_at" : "2014-10-02 22:30:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/wAWvLHvVvD",
      "expanded_url" : "http:\/\/snpy.tv\/1CHNxTV",
      "display_url" : "snpy.tv\/1CHNxTV"
    } ]
  },
  "geo" : { },
  "id_str" : "517799726339461120",
  "text" : "Nobody who works full-time should have to live in poverty. It's time to raise the minimum wage. #RaiseTheWage http:\/\/t.co\/wAWvLHvVvD",
  "id" : 517799726339461120,
  "created_at" : "2014-10-02 22:14:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517790172302544896\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/6xkKDGU2yG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By-PavCIUAEOUpP.jpg",
      "id_str" : "517790171635666945",
      "id" : 517790171635666945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By-PavCIUAEOUpP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6xkKDGU2yG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517790172302544896",
  "text" : "Worth sharing: Since President Obama took office:\nWind power = tripled.\n\u263C Solar \u263C power = increased tenfold.\n\u2192 http:\/\/t.co\/6xkKDGU2yG",
  "id" : 517790172302544896,
  "created_at" : "2014-10-02 21:36:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 25, 32 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhiteHouseIRL",
      "indices" : [ 116, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/lcRZ4Z7r5H",
      "expanded_url" : "http:\/\/whitehouse.tumblr.com\/",
      "display_url" : "whitehouse.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "517786778577960960",
  "text" : "RT @ks44: Missed today's @tumblr Q&amp;A with Jeff Zients on the economy? Check it out here: http:\/\/t.co\/lcRZ4Z7r5H #WhiteHouseIRL http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tumblr",
        "screen_name" : "tumblr",
        "indices" : [ 15, 22 ],
        "id_str" : "52484614",
        "id" : 52484614
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/517782771474112512\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/uZRzaft02G",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/By-Ir8JCEAAfm-c.jpg",
        "id_str" : "517782770630660096",
        "id" : 517782770630660096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By-Ir8JCEAAfm-c.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/uZRzaft02G"
      } ],
      "hashtags" : [ {
        "text" : "WhiteHouseIRL",
        "indices" : [ 106, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/lcRZ4Z7r5H",
        "expanded_url" : "http:\/\/whitehouse.tumblr.com\/",
        "display_url" : "whitehouse.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "517782771474112512",
    "text" : "Missed today's @tumblr Q&amp;A with Jeff Zients on the economy? Check it out here: http:\/\/t.co\/lcRZ4Z7r5H #WhiteHouseIRL http:\/\/t.co\/uZRzaft02G",
    "id" : 517782771474112512,
    "created_at" : "2014-10-02 21:06:47 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 517786778577960960,
  "created_at" : "2014-10-02 21:22:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/qiDUPbUMhH",
      "expanded_url" : "http:\/\/snpy.tv\/1vBqXKr",
      "display_url" : "snpy.tv\/1vBqXKr"
    } ]
  },
  "geo" : { },
  "id_str" : "517782365867745280",
  "text" : "Worth watching: President Obama shares his vision for a 21st century economy. #AmericaLeads http:\/\/t.co\/qiDUPbUMhH",
  "id" : 517782365867745280,
  "created_at" : "2014-10-02 21:05:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC Emergency",
      "screen_name" : "CDCemergency",
      "indices" : [ 3, 16 ],
      "id_str" : "19658936",
      "id" : 19658936
    }, {
      "name" : "Marcus Pearl",
      "screen_name" : "marcuspearl429",
      "indices" : [ 19, 34 ],
      "id_str" : "238797615",
      "id" : 238797615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517772360158814209",
  "text" : "RT @CDCemergency: .@marcuspearl429 Ebola not spread through the air like flu or measles. Spread through close contact with bodily fluids #C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marcus Pearl",
        "screen_name" : "marcuspearl429",
        "indices" : [ 1, 16 ],
        "id_str" : "238797615",
        "id" : 238797615
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CDCchat",
        "indices" : [ 119, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517770746765246464",
    "text" : ".@marcuspearl429 Ebola not spread through the air like flu or measles. Spread through close contact with bodily fluids #CDCchat",
    "id" : 517770746765246464,
    "created_at" : "2014-10-02 20:19:00 +0000",
    "user" : {
      "name" : "CDC Emergency",
      "screen_name" : "CDCemergency",
      "protected" : false,
      "id_str" : "19658936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/646413196694126592\/uQDUBB6b_normal.jpg",
      "id" : 19658936,
      "verified" : true
    }
  },
  "id" : 517772360158814209,
  "created_at" : "2014-10-02 20:25:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/glsFbFKc0S",
      "expanded_url" : "http:\/\/snpy.tv\/1yAYoQU",
      "display_url" : "snpy.tv\/1yAYoQU"
    } ]
  },
  "geo" : { },
  "id_str" : "517760248736530432",
  "text" : "\"We're all in this together. That's what made the American economy work.\" \u2014President Obama #AmericaLeads http:\/\/t.co\/glsFbFKc0S",
  "id" : 517760248736530432,
  "created_at" : "2014-10-02 19:37:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/517752224819474434\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/3Li4wYlHze",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9s55cIEAAFU87.jpg",
      "id_str" : "517752224098029568",
      "id" : 517752224098029568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9s55cIEAAFU87.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3Li4wYlHze"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 66, 79 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 80, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517752224819474434",
  "text" : "\u201CThe story of America is the story of progress.\u201D \u2014President Obama #AmericaLeads #OpportunityForAll http:\/\/t.co\/3Li4wYlHze",
  "id" : 517752224819474434,
  "created_at" : "2014-10-02 19:05:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517751183638016000",
  "text" : "\"America\u2019s economic greatness has never trickled down from the top. It grows from a rising, thriving middle class.\" \u2014Obama #AmericaLeads",
  "id" : 517751183638016000,
  "created_at" : "2014-10-02 19:01:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517750714203127808",
  "text" : "\"While...affordable health care might still be a fanged threat to freedom on Fox News...it\u2019s working pretty well in the real world.\" \u2014Obama",
  "id" : 517750714203127808,
  "created_at" : "2014-10-02 18:59:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 79, 92 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "ImmigrationReform",
      "indices" : [ 103, 121 ]
    }, {
      "text" : "PreK4All",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517750221603094530",
  "text" : "\"These policies are on the ballot. Every single one of them.\" \u2014President Obama #RaiseTheWage #EqualPay #ImmigrationReform #PreK4All",
  "id" : 517750221603094530,
  "created_at" : "2014-10-02 18:57:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/517749498668679168\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/f6JTizt3bc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9qbM4IYAAAany.jpg",
      "id_str" : "517749497716563968",
      "id" : 517749497716563968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9qbM4IYAAAany.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/f6JTizt3bc"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517749498668679168",
  "text" : "\"There are 28 million Americans who would benefit from a minimum wage increase.\" \u2014President Obama #RaiseTheWage http:\/\/t.co\/f6JTizt3bc",
  "id" : 517749498668679168,
  "created_at" : "2014-10-02 18:54:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517749259119382528",
  "text" : "RT @WHLive: \"I\u2019m always willing to work with anyone, Democrat or Republican, to get things done.\" \u2014President Obama #AmericaLeads",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AmericaLeads",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517749201435119616",
    "text" : "\"I\u2019m always willing to work with anyone, Democrat or Republican, to get things done.\" \u2014President Obama #AmericaLeads",
    "id" : 517749201435119616,
    "created_at" : "2014-10-02 18:53:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 517749259119382528,
  "created_at" : "2014-10-02 18:53:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517748743723319296\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/MGzgkmN7XQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9pvQ1IUAAWwcP.jpg",
      "id_str" : "517748742863474688",
      "id" : 517748742863474688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9pvQ1IUAAWwcP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MGzgkmN7XQ"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "AmericaLeads",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517748743723319296",
  "text" : "\"Let\u2019s catch up to 2014, pass a fair pay law, and make our economy stronger.\" \u2014Obama #EqualPay #AmericaLeads http:\/\/t.co\/MGzgkmN7XQ",
  "id" : 517748743723319296,
  "created_at" : "2014-10-02 18:51:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517748471630426112\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/iHQbrZ3zd9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9pfcHIgAA8UPQ.jpg",
      "id_str" : "517748471013867520",
      "id" : 517748471013867520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9pfcHIgAA8UPQ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iHQbrZ3zd9"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517748471630426112",
  "text" : "\"Nobody who works full-time in America should ever have to raise a family in poverty.\" \u2014Obama #RaiseTheWage http:\/\/t.co\/iHQbrZ3zd9",
  "id" : 517748471630426112,
  "created_at" : "2014-10-02 18:50:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517748126636322816",
  "text" : "\"Let\u2019s invest more in the kind of basic research that led to Google and GPS, and make our economy stronger.\" \u2014President Obama #AmericaLeads",
  "id" : 517748126636322816,
  "created_at" : "2014-10-02 18:49:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 83, 101 ]
    }, {
      "text" : "AmericaLeads",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517747945584996355",
  "text" : "RT @WHLive: \"Let\u2019s pass that bill, and make America stronger.\" \u2014President Obama on #ImmigrationReform #AmericaLeads",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationReform",
        "indices" : [ 71, 89 ]
      }, {
        "text" : "AmericaLeads",
        "indices" : [ 90, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517747912047333376",
    "text" : "\"Let\u2019s pass that bill, and make America stronger.\" \u2014President Obama on #ImmigrationReform #AmericaLeads",
    "id" : 517747912047333376,
    "created_at" : "2014-10-02 18:48:16 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 517747945584996355,
  "created_at" : "2014-10-02 18:48:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517747672980389888\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/nEO9ipnr6a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9ow7-IYAEr-uk.jpg",
      "id_str" : "517747672112193537",
      "id" : 517747672112193537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9ow7-IYAEr-uk.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nEO9ipnr6a"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 94, 107 ]
    }, {
      "text" : "PreK4All",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517747672980389888",
  "text" : "\"By the end of this decade, let\u2019s enroll 6 million children in high-quality preschool\" \u2014Obama #AmericaLeads #PreK4All http:\/\/t.co\/nEO9ipnr6a",
  "id" : 517747672980389888,
  "created_at" : "2014-10-02 18:47:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/AGvpbNmCcC",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "517747286605324289",
  "text" : "RT @WHLive: \"Let\u2019s help more young families buy that first home, make our economy stronger.\" \u2014President Obama: http:\/\/t.co\/AGvpbNmCcC #Amer\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AmericaLeads",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/AGvpbNmCcC",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "517747210373849088",
    "text" : "\"Let\u2019s help more young families buy that first home, make our economy stronger.\" \u2014President Obama: http:\/\/t.co\/AGvpbNmCcC #AmericaLeads",
    "id" : 517747210373849088,
    "created_at" : "2014-10-02 18:45:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 517747286605324289,
  "created_at" : "2014-10-02 18:45:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517746754947919872",
  "text" : "\"We cannot let up and we cannot be complacent. We have to be hungry as a nation. We have to compete.\" \u2014Obama #AmericaLeads",
  "id" : 517746754947919872,
  "created_at" : "2014-10-02 18:43:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517746049231114240\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/jU2GgLtRVD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9nSbfIgAAQTy3.jpg",
      "id_str" : "517746048484540416",
      "id" : 517746048484540416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9nSbfIgAAQTy3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jU2GgLtRVD"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517746049231114240",
  "text" : "\"For all the work that remains...there are some really good things happening in America.\" \u2014Obama #AmericaLeads http:\/\/t.co\/jU2GgLtRVD",
  "id" : 517746049231114240,
  "created_at" : "2014-10-02 18:40:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517745165931675648\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/FrnVnuNuGq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9me7YIAAAkMf_.jpg",
      "id_str" : "517745163691884544",
      "id" : 517745163691884544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9me7YIAAAkMf_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FrnVnuNuGq"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517745165931675648",
  "text" : "\"Over the past five years, we've cut our deficits by more than half.\" \u2014President Obama #AmericaLeads http:\/\/t.co\/FrnVnuNuGq",
  "id" : 517745165931675648,
  "created_at" : "2014-10-02 18:37:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517744670739550211\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/lh1vqmn5Bf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9mCMMIgAA9ZWH.jpg",
      "id_str" : "517744669988782080",
      "id" : 517744669988782080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9mCMMIgAA9ZWH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lh1vqmn5Bf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517744670739550211",
  "text" : "\"We\u2019re covering more people...in just the last year, we\u2019ve reduced the share of uninsured Americans by 26%.\" \u2014Obama http:\/\/t.co\/lh1vqmn5Bf",
  "id" : 517744670739550211,
  "created_at" : "2014-10-02 18:35:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517744333584605184\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/XBovY0rg9B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9lui2IYAA3UmQ.jpg",
      "id_str" : "517744332473131008",
      "id" : 517744332473131008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9lui2IYAA3UmQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XBovY0rg9B"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517744333584605184",
  "text" : "\"Today, we\u2019ve seen a dramatic slowdown in the rising cost of health care.\" \u2014President Obama #AmericaLeads http:\/\/t.co\/XBovY0rg9B",
  "id" : 517744333584605184,
  "created_at" : "2014-10-02 18:34:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/517743415375974401\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/WjpAWEpQtr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9k5GeIMAE96nS.jpg",
      "id_str" : "517743414323195905",
      "id" : 517743414323195905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9k5GeIMAE96nS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WjpAWEpQtr"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 70, 83 ]
    }, {
      "text" : "CollegeOpportunity",
      "indices" : [ 84, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517743415375974401",
  "text" : "\"We have to lead the world in education once again.\" \u2014President Obama #AmericaLeads #CollegeOpportunity http:\/\/t.co\/WjpAWEpQtr",
  "id" : 517743415375974401,
  "created_at" : "2014-10-02 18:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 64, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517743043651567616",
  "text" : "RT @WHLive: \"Today, our businesses sell more goods and services #MadeInAmerica to the rest of the world than we ever have before.\" \u2014Obama #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 52, 66 ]
      }, {
        "text" : "AmericaLeads",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517743021237211136",
    "text" : "\"Today, our businesses sell more goods and services #MadeInAmerica to the rest of the world than we ever have before.\" \u2014Obama #AmericaLeads",
    "id" : 517743021237211136,
    "created_at" : "2014-10-02 18:28:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 517743043651567616,
  "created_at" : "2014-10-02 18:28:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517742932213104640\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/40ogWfnX1E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9kc_hIUAEdnKl.jpg",
      "id_str" : "517742931420401665",
      "id" : 517742931420401665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9kc_hIUAEdnKl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/40ogWfnX1E"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/IYD2qteVJu",
      "expanded_url" : "http:\/\/wh.gov\/America-leads",
      "display_url" : "wh.gov\/America-leads"
    } ]
  },
  "geo" : { },
  "id_str" : "517742932213104640",
  "text" : "\"Today, American manufacturing has added more than 700,000 new jobs.\" \u2014President Obama: http:\/\/t.co\/IYD2qteVJu http:\/\/t.co\/40ogWfnX1E",
  "id" : 517742932213104640,
  "created_at" : "2014-10-02 18:28:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517742658174074882\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/7ZApnNCLaa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9kND1IYAAXQpq.jpg",
      "id_str" : "517742657700126720",
      "id" : 517742657700126720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9kND1IYAAXQpq.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7ZApnNCLaa"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 75, 88 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517742658174074882",
  "text" : "\"We\u2019ve tripled the electricity we harness from the wind.\" \u2014President Obama #AmericaLeads #ActOnClimate http:\/\/t.co\/7ZApnNCLaa",
  "id" : 517742658174074882,
  "created_at" : "2014-10-02 18:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517742301272358912",
  "text" : "RT @WHLive: \"I set a goal to cut our oil imports in half by 2020...and we will meet that goal this year.\" \u2014President Obama #AmericaLeads",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AmericaLeads",
        "indices" : [ 111, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517742269768937472",
    "text" : "\"I set a goal to cut our oil imports in half by 2020...and we will meet that goal this year.\" \u2014President Obama #AmericaLeads",
    "id" : 517742269768937472,
    "created_at" : "2014-10-02 18:25:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 517742301272358912,
  "created_at" : "2014-10-02 18:25:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517741849168314368",
  "text" : "\"We have to make our economy work for every working American. And every policy I pursue...is aimed at answering that challenge.\" \u2014Obama",
  "id" : 517741849168314368,
  "created_at" : "2014-10-02 18:24:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517741790418710528\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/cuLDdWr23C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9jadkIUAAwPkx.jpg",
      "id_str" : "517741788434812928",
      "id" : 517741788434812928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9jadkIUAAwPkx.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cuLDdWr23C"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/IYD2qteVJu",
      "expanded_url" : "http:\/\/wh.gov\/America-leads",
      "display_url" : "wh.gov\/America-leads"
    } ]
  },
  "geo" : { },
  "id_str" : "517741790418710528",
  "text" : "\"When the middle class thrives, America thrives.\" \u2014President Obama: http:\/\/t.co\/IYD2qteVJu #AmericaLeads http:\/\/t.co\/cuLDdWr23C",
  "id" : 517741790418710528,
  "created_at" : "2014-10-02 18:23:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517741586961408000",
  "text" : "\"We believe that even if we\u2019re born into nothing, with hard work, we can change our lives, and our kids\u2019 lives.\" \u2014Obama #AmericaLeads",
  "id" : 517741586961408000,
  "created_at" : "2014-10-02 18:23:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517740785937424384",
  "text" : "\"The stress that families feel\u2014that\u2019s real, too. It\u2019s still harder than it should be to pay the bills and put away some money.\" \u2014Obama",
  "id" : 517740785937424384,
  "created_at" : "2014-10-02 18:19:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517740670392758273",
  "text" : "RT @WHLive: \"Our broader economy...has come a long way, but the gains of recovery aren\u2019t yet broadly shared.\" \u2014President Obama at @Northwes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Northwestern",
        "screen_name" : "NorthwesternU",
        "indices" : [ 118, 132 ],
        "id_str" : "33639255",
        "id" : 33639255
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517740646225149952",
    "text" : "\"Our broader economy...has come a long way, but the gains of recovery aren\u2019t yet broadly shared.\" \u2014President Obama at @NorthwesternU",
    "id" : 517740646225149952,
    "created_at" : "2014-10-02 18:19:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 517740670392758273,
  "created_at" : "2014-10-02 18:19:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517740385763069952",
  "text" : "\"The United States has put more people back to work than Europe, Japan, and every other advanced economy combined.\" \u2014Obama #AmericaLeads",
  "id" : 517740385763069952,
  "created_at" : "2014-10-02 18:18:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/517740317723095040\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/wHKPVGwCNs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9iEwqIcAE9jwV.jpg",
      "id_str" : "517740316091510785",
      "id" : 517740316091510785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9iEwqIcAE9jwV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wHKPVGwCNs"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517740317723095040",
  "text" : "\"The unemployment rate has come down from a high of 10% in 2009, to 6.1%.\" \u2014President Obama #AmericaLeads http:\/\/t.co\/wHKPVGwCNs",
  "id" : 517740317723095040,
  "created_at" : "2014-10-02 18:18:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517740179650777088\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/TqCv0Q5kUV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9h8w2IEAA4Qic.jpg",
      "id_str" : "517740178702864384",
      "id" : 517740178702864384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9h8w2IEAA4Qic.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TqCv0Q5kUV"
    } ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517740179650777088",
  "text" : "\"As Americans\u2014we can &amp; should be proud of the progress our country has made these past 6 years\" \u2014Obama #AmericaLeads http:\/\/t.co\/TqCv0Q5kUV",
  "id" : 517740179650777088,
  "created_at" : "2014-10-02 18:17:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517739988612816896",
  "text" : "\"When alarms go off somewhere in the world, whether the disaster is natural or man-made...they call us.\" \u2014Obama #AmericaLeads",
  "id" : 517739988612816896,
  "created_at" : "2014-10-02 18:16:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Northwestern",
      "screen_name" : "NorthwesternU",
      "indices" : [ 85, 99 ],
      "id_str" : "33639255",
      "id" : 33639255
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaLeads",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/vCw8vM0FwA",
      "expanded_url" : "http:\/\/go.wh.gov\/NABMDP",
      "display_url" : "go.wh.gov\/NABMDP"
    } ]
  },
  "geo" : { },
  "id_str" : "517739572902764544",
  "text" : "\"American leadership is the one constant in an uncertain world.\" \u2014President Obama at @NorthwesternU: http:\/\/t.co\/vCw8vM0FwA #AmericaLeads",
  "id" : 517739572902764544,
  "created_at" : "2014-10-02 18:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Northwestern",
      "screen_name" : "NorthwesternU",
      "indices" : [ 124, 138 ],
      "id_str" : "33639255",
      "id" : 33639255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517739482997882882",
  "text" : "RT @WHLive: \"Young people like you, and universities like this\u2026will...set the conditions for middle-class growth.\"\u2014Obama at @NorthwesternU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Northwestern",
        "screen_name" : "NorthwesternU",
        "indices" : [ 112, 126 ],
        "id_str" : "33639255",
        "id" : 33639255
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517739453188952066",
    "text" : "\"Young people like you, and universities like this\u2026will...set the conditions for middle-class growth.\"\u2014Obama at @NorthwesternU",
    "id" : 517739453188952066,
    "created_at" : "2014-10-02 18:14:39 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 517739482997882882,
  "created_at" : "2014-10-02 18:14:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Northwestern",
      "screen_name" : "NorthwesternU",
      "indices" : [ 54, 68 ],
      "id_str" : "33639255",
      "id" : 33639255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/vCw8vM0FwA",
      "expanded_url" : "http:\/\/go.wh.gov\/NABMDP",
      "display_url" : "go.wh.gov\/NABMDP"
    } ]
  },
  "geo" : { },
  "id_str" : "517738751226036225",
  "text" : "\"Hello, Northwestern...go 'Cats!\" \u2014President Obama at @NorthwesternU: http:\/\/t.co\/vCw8vM0FwA",
  "id" : 517738751226036225,
  "created_at" : "2014-10-02 18:11:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517736981288468480\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/7Vqs1HYMZk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9fCmVIEAA6RG6.jpg",
      "id_str" : "517736980424429568",
      "id" : 517736980424429568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9fCmVIEAA6RG6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7Vqs1HYMZk"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "517736981288468480",
  "text" : "Don't miss President Obama speak at 2:15pm ET on a new foundation for our economy: http:\/\/t.co\/b4tqL36eMn http:\/\/t.co\/7Vqs1HYMZk",
  "id" : 517736981288468480,
  "created_at" : "2014-10-02 18:04:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "Northwestern",
      "screen_name" : "NorthwesternU",
      "indices" : [ 42, 56 ],
      "id_str" : "33639255",
      "id" : 33639255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517732301535711232",
  "text" : "RT @Schultz44: Marine One brings POTUS to @NorthwesternU - on Lake Michigan. Will speak shortly on a new foundation for our economy. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Northwestern",
        "screen_name" : "NorthwesternU",
        "indices" : [ 27, 41 ],
        "id_str" : "33639255",
        "id" : 33639255
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Schultz44\/status\/517731905312395264\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/17gpSInqK6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/By9abLgIQAAX0oO.jpg",
        "id_str" : "517731905161412608",
        "id" : 517731905161412608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9abLgIQAAX0oO.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/17gpSInqK6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "517731905312395264",
    "text" : "Marine One brings POTUS to @NorthwesternU - on Lake Michigan. Will speak shortly on a new foundation for our economy. http:\/\/t.co\/17gpSInqK6",
    "id" : 517731905312395264,
    "created_at" : "2014-10-02 17:44:39 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 517732301535711232,
  "created_at" : "2014-10-02 17:46:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 3, 10 ],
      "id_str" : "146569971",
      "id" : 146569971
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 80, 86 ]
    }, {
      "text" : "CDCchat",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ftKhpR5UdU",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/2432f8f9-aee0-481c-8d7d-c26bdbd1ec7c",
      "display_url" : "amp.twimg.com\/v\/2432f8f9-aee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "517730090453860352",
  "text" : "RT @CDCgov: CDC experts will answer questions today at 4PM ET on 1st US case of #Ebola. Use #CDCchat to participate.\nhttps:\/\/t.co\/ftKhpR5UdU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 68, 74 ]
      }, {
        "text" : "CDCchat",
        "indices" : [ 80, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/ftKhpR5UdU",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/2432f8f9-aee0-481c-8d7d-c26bdbd1ec7c",
        "display_url" : "amp.twimg.com\/v\/2432f8f9-aee\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517679214909087744",
    "text" : "CDC experts will answer questions today at 4PM ET on 1st US case of #Ebola. Use #CDCchat to participate.\nhttps:\/\/t.co\/ftKhpR5UdU",
    "id" : 517679214909087744,
    "created_at" : "2014-10-02 14:15:17 +0000",
    "user" : {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "protected" : false,
      "id_str" : "146569971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748879958538321920\/iPUVbyKu_normal.jpg",
      "id" : 146569971,
      "verified" : true
    }
  },
  "id" : 517730090453860352,
  "created_at" : "2014-10-02 17:37:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517717296102776832\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/1in4A5q7jK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9NIwrIgAAzry4.jpg",
      "id_str" : "517717295071002624",
      "id" : 517717295071002624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9NIwrIgAAzry4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1in4A5q7jK"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/IYD2qteVJu",
      "expanded_url" : "http:\/\/wh.gov\/America-leads",
      "display_url" : "wh.gov\/America-leads"
    } ]
  },
  "geo" : { },
  "id_str" : "517717296102776832",
  "text" : "We're helping more Americans gain quality, affordable health coverage \u2192 http:\/\/t.co\/IYD2qteVJu #ACAWorks http:\/\/t.co\/1in4A5q7jK",
  "id" : 517717296102776832,
  "created_at" : "2014-10-02 16:46:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/517712272710709248\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Cf0YcPnzZl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By9IkYIIgAA1cj_.jpg",
      "id_str" : "517712271959949312",
      "id" : 517712271959949312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By9IkYIIgAA1cj_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Cf0YcPnzZl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/IYD2qteVJu",
      "expanded_url" : "http:\/\/wh.gov\/America-leads",
      "display_url" : "wh.gov\/America-leads"
    } ]
  },
  "geo" : { },
  "id_str" : "517712272710709248",
  "text" : "Don't miss President Obama speak at 2:15pm ET on a new foundation for our economy \u2192 http:\/\/t.co\/IYD2qteVJu http:\/\/t.co\/Cf0YcPnzZl",
  "id" : 517712272710709248,
  "created_at" : "2014-10-02 16:26:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/IYD2qteVJu",
      "expanded_url" : "http:\/\/wh.gov\/America-leads",
      "display_url" : "wh.gov\/America-leads"
    } ]
  },
  "geo" : { },
  "id_str" : "517710668511064065",
  "text" : "President Obama's speaking today on a new foundation for our economy. See where we are, and where we're going \u2192 http:\/\/t.co\/IYD2qteVJu",
  "id" : 517710668511064065,
  "created_at" : "2014-10-02 16:20:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "Perry Bacon Jr.",
      "screen_name" : "perrybaconjr",
      "indices" : [ 104, 117 ],
      "id_str" : "20815668",
      "id" : 20815668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/foEDlM6Fwt",
      "expanded_url" : "http:\/\/on.msnbc.com\/1v6bEXG",
      "display_url" : "on.msnbc.com\/1v6bEXG"
    } ]
  },
  "geo" : { },
  "id_str" : "517706385631768577",
  "text" : "RT @Schultz44: A year later, Obamacare shows signs of success and permanence http:\/\/t.co\/foEDlM6Fwt via @perrybaconjr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Perry Bacon Jr.",
        "screen_name" : "perrybaconjr",
        "indices" : [ 89, 102 ],
        "id_str" : "20815668",
        "id" : 20815668
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/foEDlM6Fwt",
        "expanded_url" : "http:\/\/on.msnbc.com\/1v6bEXG",
        "display_url" : "on.msnbc.com\/1v6bEXG"
      } ]
    },
    "geo" : { },
    "id_str" : "517671767348097024",
    "text" : "A year later, Obamacare shows signs of success and permanence http:\/\/t.co\/foEDlM6Fwt via @perrybaconjr",
    "id" : 517671767348097024,
    "created_at" : "2014-10-02 13:45:41 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 517706385631768577,
  "created_at" : "2014-10-02 16:03:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517697471469092864",
  "text" : "RT @arneduncan: Happy to see the University of Chicago is working to increase access and make college more affordable for students. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/AJPHkl8Ewx",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/10\/01\/education\/university-of-chicago-acts-to-improve-access-for-lower-income-students-.html",
        "display_url" : "nytimes.com\/2014\/10\/01\/edu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517694083159322624",
    "text" : "Happy to see the University of Chicago is working to increase access and make college more affordable for students. http:\/\/t.co\/AJPHkl8Ewx",
    "id" : 517694083159322624,
    "created_at" : "2014-10-02 15:14:22 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 517697471469092864,
  "created_at" : "2014-10-02 15:27:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517690088231538688",
  "text" : "RT @JFriedman44: Following UN speech last week POTUS today will make similarly forceful case for American strength, leadership at home http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/56rrmcGVpq",
        "expanded_url" : "http:\/\/abcn.ws\/1xFfdsF",
        "display_url" : "abcn.ws\/1xFfdsF"
      } ]
    },
    "geo" : { },
    "id_str" : "517632128612573184",
    "text" : "Following UN speech last week POTUS today will make similarly forceful case for American strength, leadership at home http:\/\/t.co\/56rrmcGVpq",
    "id" : 517632128612573184,
    "created_at" : "2014-10-02 11:08:11 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 517690088231538688,
  "created_at" : "2014-10-02 14:58:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517452553416876032\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/Du99I0S524",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By5cWutIEAAvb2J.jpg",
      "id_str" : "517452552758366208",
      "id" : 517452552758366208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By5cWutIEAAvb2J.jpg",
      "sizes" : [ {
        "h" : 879,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 944,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 515,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Du99I0S524"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517452553416876032",
  "text" : "Happy 90th Birthday, President Carter! Michelle and I send our best wishes to you and Rosalynn. -bo http:\/\/t.co\/Du99I0S524",
  "id" : 517452553416876032,
  "created_at" : "2014-10-01 23:14:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517429258395062272\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/KmB9pPuNrm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By5HKyQIQAEMz15.jpg",
      "id_str" : "517429257807872001",
      "id" : 517429257807872001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By5HKyQIQAEMz15.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KmB9pPuNrm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/4P4JflMACK",
      "expanded_url" : "http:\/\/go.wh.gov\/BYMB1U",
      "display_url" : "go.wh.gov\/BYMB1U"
    } ]
  },
  "geo" : { },
  "id_str" : "517429258395062272",
  "text" : "President Obama met with Israeli Prime Minister Netanyahu this morning on Gaza and ISIL \u2192 http:\/\/t.co\/4P4JflMACK http:\/\/t.co\/KmB9pPuNrm",
  "id" : 517429258395062272,
  "created_at" : "2014-10-01 21:42:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 3, 19 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517410455586107392",
  "text" : "RT @SecretaryCastro: Today we\u2019re announcing over $62 million to help more than 9,000 homeless veterans find permanent supportive housing. h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/aOXjLLP0me",
        "expanded_url" : "http:\/\/portal.hud.gov\/hudportal\/HUD?src=\/press\/press_releases_media_advisories\/2014\/HUDNo_14-119",
        "display_url" : "portal.hud.gov\/hudportal\/HUD?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517337804506796032",
    "text" : "Today we\u2019re announcing over $62 million to help more than 9,000 homeless veterans find permanent supportive housing. http:\/\/t.co\/aOXjLLP0me",
    "id" : 517337804506796032,
    "created_at" : "2014-10-01 15:38:38 +0000",
    "user" : {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "protected" : false,
      "id_str" : "2695663285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686622077491654658\/oEOE5IDE_normal.jpg",
      "id" : 2695663285,
      "verified" : true
    }
  },
  "id" : 517410455586107392,
  "created_at" : "2014-10-01 20:27:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Pearce",
      "screen_name" : "KevinPearce",
      "indices" : [ 3, 15 ],
      "id_str" : "68025598",
      "id" : 68025598
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 41, 52 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/UMwxfezCvb",
      "expanded_url" : "http:\/\/1.usa.gov\/1rLVu7g",
      "display_url" : "1.usa.gov\/1rLVu7g"
    } ]
  },
  "geo" : { },
  "id_str" : "517406685577900032",
  "text" : "RT @KevinPearce: Just sent an email with @WhiteHouse supporting BRAIN Initiative. See http:\/\/t.co\/UMwxfezCvb Share your story! #loveyourbra\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 24, 35 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "LoveYourBrain",
        "screen_name" : "loveyourbrain",
        "indices" : [ 125, 139 ],
        "id_str" : "2230235677",
        "id" : 2230235677
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "loveyourbrain",
        "indices" : [ 110, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/UMwxfezCvb",
        "expanded_url" : "http:\/\/1.usa.gov\/1rLVu7g",
        "display_url" : "1.usa.gov\/1rLVu7g"
      } ]
    },
    "geo" : { },
    "id_str" : "517397635939184641",
    "text" : "Just sent an email with @WhiteHouse supporting BRAIN Initiative. See http:\/\/t.co\/UMwxfezCvb Share your story! #loveyourbrain @loveyourbrain",
    "id" : 517397635939184641,
    "created_at" : "2014-10-01 19:36:23 +0000",
    "user" : {
      "name" : "Kevin Pearce",
      "screen_name" : "KevinPearce",
      "protected" : false,
      "id_str" : "68025598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704318562186477568\/2rRdBOcN_normal.jpg",
      "id" : 68025598,
      "verified" : true
    }
  },
  "id" : 517406685577900032,
  "created_at" : "2014-10-01 20:12:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/eCFFJOjNbN",
      "expanded_url" : "http:\/\/1.usa.gov\/1c9uKXI",
      "display_url" : "1.usa.gov\/1c9uKXI"
    } ]
  },
  "geo" : { },
  "id_str" : "517392210611163137",
  "text" : "RT @GinaEPA: Spread the word about how to #ActOnClimate. We have a moral obligation to act for future generations. http:\/\/t.co\/eCFFJOjNbN #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 29, 42 ]
      }, {
        "text" : "CleanAir4Kids",
        "indices" : [ 125, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/eCFFJOjNbN",
        "expanded_url" : "http:\/\/1.usa.gov\/1c9uKXI",
        "display_url" : "1.usa.gov\/1c9uKXI"
      } ]
    },
    "geo" : { },
    "id_str" : "517386223003127808",
    "text" : "Spread the word about how to #ActOnClimate. We have a moral obligation to act for future generations. http:\/\/t.co\/eCFFJOjNbN #CleanAir4Kids",
    "id" : 517386223003127808,
    "created_at" : "2014-10-01 18:51:02 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 517392210611163137,
  "created_at" : "2014-10-01 19:14:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Major League Soccer",
      "screen_name" : "MLS",
      "indices" : [ 44, 48 ],
      "id_str" : "107146095",
      "id" : 107146095
    }, {
      "name" : "Sporting Kansas City",
      "screen_name" : "SportingKC",
      "indices" : [ 64, 75 ],
      "id_str" : "17493398",
      "id" : 17493398
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SportingKC",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "517377546095431680",
  "text" : "Watch live: President Obama honors the 2013 @MLS Cup champions, @SportingKC \u2192 http:\/\/t.co\/b4tqL36eMn #SportingKC",
  "id" : 517377546095431680,
  "created_at" : "2014-10-01 18:16:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/OSd7Uhkcs2",
      "expanded_url" : "http:\/\/go.wh.gov\/ezfECC",
      "display_url" : "go.wh.gov\/ezfECC"
    } ]
  },
  "geo" : { },
  "id_str" : "517373705140588545",
  "text" : "\"We renew our commitment to better prevent, detect, and treat breast cancer\" \u2014Obama on Breast Cancer Awareness Month: http:\/\/t.co\/OSd7Uhkcs2",
  "id" : 517373705140588545,
  "created_at" : "2014-10-01 18:01:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517369246377332737",
  "text" : "RT @Cecilia44: Today's Min Wage rule will raise wages for 200k American workers, reward work and grow the middle class: http:\/\/t.co\/gGZzL2k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/gGZzL2kR4C",
        "expanded_url" : "http:\/\/www.dol.gov\/opa\/media\/press\/whd\/WHD20141888.htm",
        "display_url" : "dol.gov\/opa\/media\/pres\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "517362458097238018",
    "text" : "Today's Min Wage rule will raise wages for 200k American workers, reward work and grow the middle class: http:\/\/t.co\/gGZzL2kR4C",
    "id" : 517362458097238018,
    "created_at" : "2014-10-01 17:16:36 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 517369246377332737,
  "created_at" : "2014-10-01 17:43:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/D36WWgDEn1",
      "expanded_url" : "http:\/\/wh.gov\/iiyOz",
      "display_url" : "wh.gov\/iiyOz"
    } ]
  },
  "geo" : { },
  "id_str" : "517347410717474816",
  "text" : "RT @DrBiden: It\u2019s Breast Cancer Awareness Month: http:\/\/t.co\/D36WWgDEn1 Let\u2019s all commit to the prevention, detection &amp; treatment of this d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/D36WWgDEn1",
        "expanded_url" : "http:\/\/wh.gov\/iiyOz",
        "display_url" : "wh.gov\/iiyOz"
      } ]
    },
    "geo" : { },
    "id_str" : "517327310341828608",
    "text" : "It\u2019s Breast Cancer Awareness Month: http:\/\/t.co\/D36WWgDEn1 Let\u2019s all commit to the prevention, detection &amp; treatment of this disease. -Jill",
    "id" : 517327310341828608,
    "created_at" : "2014-10-01 14:56:56 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 517347410717474816,
  "created_at" : "2014-10-01 16:16:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517325009178886144\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/8owDJhPEcp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By3oWpdIEAEf880.jpg",
      "id_str" : "517325008000258049",
      "id" : 517325008000258049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By3oWpdIEAEf880.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8owDJhPEcp"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Cn45X01hMf",
      "expanded_url" : "http:\/\/go.wh.gov\/LGsQnf",
      "display_url" : "go.wh.gov\/LGsQnf"
    } ]
  },
  "geo" : { },
  "id_str" : "517325009178886144",
  "text" : "#Ebola cannot be spread through air, water, or food in the U.S.\nLearn more and get the facts: http:\/\/t.co\/Cn45X01hMf http:\/\/t.co\/8owDJhPEcp",
  "id" : 517325009178886144,
  "created_at" : "2014-10-01 14:47:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]