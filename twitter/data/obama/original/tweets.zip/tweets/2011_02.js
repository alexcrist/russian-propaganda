Grailbird.data.tweets_2011_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "indices" : [ 3, 17 ],
      "id_str" : "28576135",
      "id" : 28576135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42307132317638656",
  "text" : "RT @thejointstaff: Rest in peace to last known American WWI vet Frank Buckles-his service and sacrifices serve as a reminder of what mak ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42304872648945664",
    "text" : "Rest in peace to last known American WWI vet Frank Buckles-his service and sacrifices serve as a reminder of what makes our nation great",
    "id" : 42304872648945664,
    "created_at" : "2011-02-28 19:27:22 +0000",
    "user" : {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "protected" : false,
      "id_str" : "28576135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459045440063672320\/SOEE5LHU_normal.png",
      "id" : 28576135,
      "verified" : true
    }
  },
  "id" : 42307132317638656,
  "created_at" : "2011-02-28 19:36:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42290412295176192",
  "text" : "Obama \u201CIf you can come up w\/ a better system for your state to provide coverage of the same quality & affordability\u2026you can take that route\"",
  "id" : 42290412295176192,
  "created_at" : "2011-02-28 18:29:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42287006411272192",
  "text" : "Obama: \u201CI don\u2019t think it does anybody any good when public employees are\u2026 vilified or their rights are infringed upon\u201D http:\/\/wh.gov\/xUJ",
  "id" : 42287006411272192,
  "created_at" : "2011-02-28 18:16:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 68, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42273463196594176",
  "text" : "HHS Sec Sebelius explains the \u201CEmpowering States to Innovate Act\u201D & #hcr http:\/\/wh.gov\/xU5",
  "id" : 42273463196594176,
  "created_at" : "2011-02-28 17:22:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42266632709607424",
  "text" : "RT @PressSec: For info on the President's announcement re health care, go to http:\/\/is.gd\/qIZDNE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42265556472172544",
    "text" : "For info on the President's announcement re health care, go to http:\/\/is.gd\/qIZDNE",
    "id" : 42265556472172544,
    "created_at" : "2011-02-28 16:51:08 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 42266632709607424,
  "created_at" : "2011-02-28 16:55:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 47, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42247833759383552",
  "text" : "11AM EST: President & VP speak to Governors on #hcr, economy. Watch: http:\/\/wh.gov\/live",
  "id" : 42247833759383552,
  "created_at" : "2011-02-28 15:40:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Belinda Smith",
      "screen_name" : "lindismith",
      "indices" : [ 1, 12 ],
      "id_str" : "10316902",
      "id" : 10316902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40827529149288448",
  "geo" : { },
  "id_str" : "42230362356715520",
  "in_reply_to_user_id" : 10316902,
  "text" : ".@lindismith asked us about the 17 small business tax cuts President Obama has signed into law. We answered: http:\/\/wh.gov\/xnC",
  "id" : 42230362356715520,
  "in_reply_to_status_id" : 40827529149288448,
  "created_at" : "2011-02-28 14:31:17 +0000",
  "in_reply_to_screen_name" : "lindismith",
  "in_reply_to_user_id_str" : "10316902",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41312782263517184",
  "text" : "President Obama \"These sanctions\u2026target the Qaddafi government...protecting the assets that belong to the people of Libya\" http:\/\/wh.gov\/xQj",
  "id" : 41312782263517184,
  "created_at" : "2011-02-26 01:45:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41252645171769344",
  "text" : "Fresh West Wing Week: \"Don't Bump My Atoms\" http:\/\/wh.gov\/xR4",
  "id" : 41252645171769344,
  "created_at" : "2011-02-25 21:46:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41232944513155072",
  "text" : "WH Press Sec: \u201CColonel Gaddafi has lost the confidence of his people,\u201D US will pursue unilateral sanctions #Libya",
  "id" : 41232944513155072,
  "created_at" : "2011-02-25 20:27:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penni",
      "screen_name" : "pennilesspoet",
      "indices" : [ 98, 112 ],
      "id_str" : "184627322",
      "id" : 184627322
    }, {
      "name" : "\u0627\u0644\u0634\u0645\u0631\u064A",
      "screen_name" : "dazzleeyes",
      "indices" : [ 115, 126 ],
      "id_str" : "3392249169",
      "id" : 3392249169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41178077044277248",
  "text" : "Honorable mentions for \u201CHayes\u201D who received the desk, but Jackie\/ JFK brought to Oval. Looks like @pennilesspoet & @dazzleeyes got in 1st",
  "id" : 41178077044277248,
  "created_at" : "2011-02-25 16:49:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41175280626171904",
  "text" : "Photo of the Day contest: Who 1st brought the Resolute Desk into the Oval? Prize:  The desk! Kidding, it's nothing http:\/\/twitpic.com\/43mrlm",
  "id" : 41175280626171904,
  "created_at" : "2011-02-25 16:38:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 57, 66 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41163625464991744",
  "text" : "RT @pfeiffer44: Jay Carney will officially take over the @PressSec account next week. He will start by taking your questions on Monday a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 41, 50 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41160172349034496",
    "text" : "Jay Carney will officially take over the @PressSec account next week. He will start by taking your questions on Monday afternoon.",
    "id" : 41160172349034496,
    "created_at" : "2011-02-25 15:38:44 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 41163625464991744,
  "created_at" : "2011-02-25 15:52:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40843895843594240",
  "text" : "1:45: 1st meeting of the President's Council on Jobs & Competitiveness w\/ GE\u2019s Immelt, watch\/ discuss: http:\/\/bit.ly\/bLTH91",
  "id" : 40843895843594240,
  "created_at" : "2011-02-24 18:41:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40804245288521728",
  "text" : "Photo of the Day: The President, Secretary Clinton & National Security Advisor Donilon in the Oval  http:\/\/twitpic.com\/439wd6",
  "id" : 40804245288521728,
  "created_at" : "2011-02-24 16:04:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40799782997856256",
  "text" : "What it's like to be a WH intern (and how to apply): http:\/\/wh.gov\/xNg",
  "id" : 40799782997856256,
  "created_at" : "2011-02-24 15:46:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40776962456686593",
  "text" : "Didn\u2019t get your homework done? It\u2019s ok, deadline to apply for Commencement Challenge extended to March 11 http:\/\/wh.gov\/xXc",
  "id" : 40776962456686593,
  "created_at" : "2011-02-24 14:16:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40541265367928832",
  "text" : "President Obama's full remarks on #Libya: http:\/\/wh.gov\/x5j  \"These are human rights. They are not negotiable.\"",
  "id" : 40541265367928832,
  "created_at" : "2011-02-23 22:39:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40536286062190592",
  "text" : "President Obama: \"The suffering and bloodshed is outrageous, and it is unacceptable\"",
  "id" : 40536286062190592,
  "created_at" : "2011-02-23 22:19:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40534754730319872",
  "text" : "President Obama: \"the US will continue to stand up for freedom, to stand up for justice, to stand up for the dignity of all people\"",
  "id" : 40534754730319872,
  "created_at" : "2011-02-23 22:13:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40534594839126016",
  "text" : "President Obama: \"As one Libyan said, 'We just want to be able to live like human beings.'\"",
  "id" : 40534594839126016,
  "created_at" : "2011-02-23 22:12:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40534398025596929",
  "text" : "President Obama: \"Let me be clear: the change that is taking place across the region is being driven by the people of the region\"",
  "id" : 40534398025596929,
  "created_at" : "2011-02-23 22:12:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40533875834753024",
  "text" : "President speaking on Libya now: http:\/\/wh.gov\/live",
  "id" : 40533875834753024,
  "created_at" : "2011-02-23 22:10:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 36, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40523879755546624",
  "text" : "5:15PM EST: The President speaks on #Libya, watch live: http:\/\/wh.gov\/live (corrected)",
  "id" : 40523879755546624,
  "created_at" : "2011-02-23 21:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Lybia",
      "indices" : [ 36, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40514519352475648",
  "text" : "5:15PM EST: The President speaks on #Lybia, watch live: http:\/\/wh.gov\/live",
  "id" : 40514519352475648,
  "created_at" : "2011-02-23 20:53:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40150350027689984",
  "text" : "Not too late (but getting close!): Enter your high school in the Commencement Challenge to get Obama to give your address http:\/\/wh.gov\/xDt",
  "id" : 40150350027689984,
  "created_at" : "2011-02-22 20:46:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40116679111344128",
  "text" : "President takes a couple of your questions the economy, live now: http:\/\/bit.ly\/hSr1F",
  "id" : 40116679111344128,
  "created_at" : "2011-02-22 18:32:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40104008379150337",
  "text" : "Just in: The President says he\u2019ll pop in on Goolsbee\u2019s live chat from OH at 1:00 (don\u2019t tell Austan), check it out: http:\/\/bit.ly\/hSr1F",
  "id" : 40104008379150337,
  "created_at" : "2011-02-22 17:41:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40084398590132224",
  "text" : "11:35EST: The WH Forum on Small Biz in OH kicks off w\/ President\u2019s remarks, live chat w\/ Goolsbee at 1:00 http:\/\/wh.gov\/live",
  "id" : 40084398590132224,
  "created_at" : "2011-02-22 16:24:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38712244716052480",
  "text" : "Obama on violence in Bahrain, Libya & Yemen: \u201CWherever they are, people have certain universal rights...\u201D http:\/\/wh.gov\/x0O",
  "id" : 38712244716052480,
  "created_at" : "2011-02-18 21:31:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Araceli Arroyo",
      "screen_name" : "celikins",
      "indices" : [ 3, 12 ],
      "id_str" : "10765192",
      "id" : 10765192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38681239254728704",
  "text" : "RT @celikins: Entrepreneur\/small businesses did you know you could 'Advise the Advisor\" @ White House? Have you yet? http:\/\/www.whitehou ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38664413317840896",
    "text" : "Entrepreneur\/small businesses did you know you could 'Advise the Advisor\" @ White House? Have you yet? http:\/\/www.whitehouse.gov\/advise",
    "id" : 38664413317840896,
    "created_at" : "2011-02-18 18:21:29 +0000",
    "user" : {
      "name" : "Araceli Arroyo",
      "screen_name" : "celikins",
      "protected" : false,
      "id_str" : "10765192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736649338823180288\/U2SR8exJ_normal.jpg",
      "id" : 10765192,
      "verified" : false
    }
  },
  "id" : 38681239254728704,
  "created_at" : "2011-02-18 19:28:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38679574321696768",
  "text" : "2:35(ish): The President speaks on education & innovation at Intel, watch: http:\/\/wh.gov\/xkf",
  "id" : 38679574321696768,
  "created_at" : "2011-02-18 19:21:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 33, 41 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 43, 52 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38635242650603520",
  "text" : "The President toasts w\/ heads of @Twitter, @Facebook, other tech biz leaders at dinner in Woodside  http:\/\/twitpic.com\/413q50",
  "id" : 38635242650603520,
  "created_at" : "2011-02-18 16:25:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 89, 104 ],
      "id_str" : "14511951",
      "id" : 14511951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38626554250657792",
  "text" : "RT @HHSGov: Secretary Sebelius blogs on \"Protecting and Strengthening Women's Health\" on @HuffingtonPost http:\/\/huff.to\/eDpcIk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Huffington Post",
        "screen_name" : "HuffingtonPost",
        "indices" : [ 77, 92 ],
        "id_str" : "14511951",
        "id" : 14511951
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38620013761925120",
    "text" : "Secretary Sebelius blogs on \"Protecting and Strengthening Women's Health\" on @HuffingtonPost http:\/\/huff.to\/eDpcIk",
    "id" : 38620013761925120,
    "created_at" : "2011-02-18 15:25:03 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 38626554250657792,
  "created_at" : "2011-02-18 15:51:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womenshealth",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38626467617308673",
  "text" : "RT @HealthCareGov: Great new online resource for women to learn about benefits in the health care law http:\/\/bit.ly\/idxirp #womenshealth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "womenshealth",
        "indices" : [ 104, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38623662550679553",
    "text" : "Great new online resource for women to learn about benefits in the health care law http:\/\/bit.ly\/idxirp #womenshealth",
    "id" : 38623662550679553,
    "created_at" : "2011-02-18 15:39:33 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 38626467617308673,
  "created_at" : "2011-02-18 15:50:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38613628844384256",
  "text" : "Fresh West Wing Week: Releasing the Budget; \u201CEgypt will never be the same\u201D; Goodbye to Gibbs http:\/\/wh.gov\/xkE",
  "id" : 38613628844384256,
  "created_at" : "2011-02-18 14:59:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38379151429738496",
  "text" : "Jared Bernstein on the Recovery Act: http:\/\/wh.gov\/xKe Summary: 2 years, 3.5 million jobs",
  "id" : 38379151429738496,
  "created_at" : "2011-02-17 23:27:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38368090567876608",
  "text" : "Exclusive video: Medal of Freedom recipients in their own words http:\/\/wh.gov\/xWi  Angelou: \u201CThis is not a rehearsal. This is your life\u201D",
  "id" : 38368090567876608,
  "created_at" : "2011-02-17 22:44:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 78, 88 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38330458617937920",
  "text" : "President Obama signs the John M. Roll US Courthouse Bill in the Oval Office (@petesouza) http:\/\/twitpic.com\/40tqwz",
  "id" : 38330458617937920,
  "created_at" : "2011-02-17 20:14:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38324016129376256",
  "text" : "Austan Goolsbee kicks off the next Advise the Advisor, watch the vid & give him your feedback on small biz http:\/\/wh.gov\/xBI",
  "id" : 38324016129376256,
  "created_at" : "2011-02-17 19:48:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38280419296157696",
  "text" : "David Plouffe: What I\u2019m Hearing from You Through Advise the Advisor http:\/\/wh.gov\/xWO Word cloud form:  http:\/\/twitpic.com\/40s5m2",
  "id" : 38280419296157696,
  "created_at" : "2011-02-17 16:55:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38272134509891584",
  "text" : "Commencement Challenge deadline to have Obama give your address: Feb 25 http:\/\/wh.gov\/xDt Of course if you don\u2019t want to win the future\u2026",
  "id" : 38272134509891584,
  "created_at" : "2011-02-17 16:22:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37997963431247872",
  "text" : "Dr. Jill Biden shares stories and photos from her & the VP's visits with our troops and their families http:\/\/wh.gov\/xZV",
  "id" : 37997963431247872,
  "created_at" : "2011-02-16 22:13:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37987286264201216",
  "text" : "4:45EST: The President speaks at the America\u2019s Great Outdoors event http:\/\/wh.gov\/live",
  "id" : 37987286264201216,
  "created_at" : "2011-02-16 21:30:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37935615836160000",
  "text" : "RT @Pfeiffer44: Happening Now: Jay Carney's first briefing as White House Press Secretary  \/\/ Watch: http:\/\/wh.gov\/live",
  "id" : 37935615836160000,
  "created_at" : "2011-02-16 18:05:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 59, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37925460126076928",
  "text" : "OK, gotta run, tx all 4 the great Qs. More on the youths & #hcr: http:\/\/bit.ly\/bpwflx Sign up for youth email updates: http:\/\/bit.ly\/cGxZSg",
  "id" : 37925460126076928,
  "created_at" : "2011-02-16 17:25:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freddy Victoria",
      "screen_name" : "fpvictoria",
      "indices" : [ 1, 12 ],
      "id_str" : "72580058",
      "id" : 72580058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37923598970793984",
  "geo" : { },
  "id_str" : "37924703121321984",
  "in_reply_to_user_id" : 72580058,
  "text" : ".@fpvictoria Many small biz eligible for tax credits already:http:\/\/bit.ly\/bpwflx 2014 small biz can go through Exchanges for best deal",
  "id" : 37924703121321984,
  "in_reply_to_status_id" : 37923598970793984,
  "created_at" : "2011-02-16 17:22:08 +0000",
  "in_reply_to_screen_name" : "fpvictoria",
  "in_reply_to_user_id_str" : "72580058",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamin Keene",
      "screen_name" : "thespianjk",
      "indices" : [ 1, 12 ],
      "id_str" : "435084327",
      "id" : 435084327
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 13, 17 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37919853683806209",
  "geo" : { },
  "id_str" : "37923959592722433",
  "in_reply_to_user_id" : 16332215,
  "text" : ".@thespianJK #hcr law very much alive, provisions will keep kicking in, law won't be repealed & is Constitutional: http:\/\/wh.gov\/cz0",
  "id" : 37923959592722433,
  "in_reply_to_status_id" : 37919853683806209,
  "created_at" : "2011-02-16 17:19:11 +0000",
  "in_reply_to_screen_name" : "KeenePOV",
  "in_reply_to_user_id_str" : "16332215",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamin Keene",
      "screen_name" : "thespianjk",
      "indices" : [ 1, 12 ],
      "id_str" : "435084327",
      "id" : 435084327
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 13, 17 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37919853683806209",
  "geo" : { },
  "id_str" : "37923960050036736",
  "in_reply_to_user_id" : 16332215,
  "text" : ".@thespianJK #hcr law very much alive, provisions will keep kicking in, law won't be repealed & is Constitutional: http:\/\/wh.gov\/cz0",
  "id" : 37923960050036736,
  "in_reply_to_status_id" : 37919853683806209,
  "created_at" : "2011-02-16 17:19:11 +0000",
  "in_reply_to_screen_name" : "KeenePOV",
  "in_reply_to_user_id_str" : "16332215",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cheryl young",
      "screen_name" : "girlsplayinc",
      "indices" : [ 1, 14 ],
      "id_str" : "37000944",
      "id" : 37000944
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 15, 19 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37921116714434560",
  "geo" : { },
  "id_str" : "37922416298565632",
  "in_reply_to_user_id" : 37000944,
  "text" : ".@girlsplayinc #hcr law gives you much more control over health decisions, protections against ins co abuses. Details: http:\/\/bit.ly\/cwPeDT",
  "id" : 37922416298565632,
  "in_reply_to_status_id" : 37921116714434560,
  "created_at" : "2011-02-16 17:13:03 +0000",
  "in_reply_to_screen_name" : "girlsplayinc",
  "in_reply_to_user_id_str" : "37000944",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard French",
      "screen_name" : "RichardFrench",
      "indices" : [ 1, 15 ],
      "id_str" : "15592486",
      "id" : 15592486
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 125, 129 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37918484591681536",
  "geo" : { },
  "id_str" : "37921364132364288",
  "in_reply_to_user_id" : 15592486,
  "text" : ".@RichardFrench Consulted with all stakeholders throughout & ongoing, more video than you can handle here: http:\/\/wh.gov\/xWg #hcr",
  "id" : 37921364132364288,
  "in_reply_to_status_id" : 37918484591681536,
  "created_at" : "2011-02-16 17:08:52 +0000",
  "in_reply_to_screen_name" : "RichardFrench",
  "in_reply_to_user_id_str" : "15592486",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TRICARE",
      "screen_name" : "TRICARE",
      "indices" : [ 46, 54 ],
      "id_str" : "28558205",
      "id" : 28558205
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 16, 20 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37918910661668864",
  "geo" : { },
  "id_str" : "37920396711960576",
  "in_reply_to_user_id" : 24722025,
  "text" : ".@amariefelicio #hcr will definitely not hurt @TRICARE, it's safe & sound http:\/\/wh.gov\/xWY",
  "id" : 37920396711960576,
  "in_reply_to_status_id" : 37918910661668864,
  "created_at" : "2011-02-16 17:05:01 +0000",
  "in_reply_to_screen_name" : "amarieF0X",
  "in_reply_to_user_id_str" : "24722025",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al ~ LockHerUp!",
      "screen_name" : "alpipkin",
      "indices" : [ 1, 10 ],
      "id_str" : "25713562",
      "id" : 25713562
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 11, 13 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37889594095702016",
  "geo" : { },
  "id_str" : "37919227444854784",
  "in_reply_to_user_id" : 25713562,
  "text" : ".@alpipkin #s on govt costs\/ deficits are consistent, reduces deficits by $1T+ over 20 yrs, more here: http:\/\/bit.ly\/hzR1rP Thanks for the Q",
  "id" : 37919227444854784,
  "in_reply_to_status_id" : 37889594095702016,
  "created_at" : "2011-02-16 17:00:22 +0000",
  "in_reply_to_screen_name" : "alpipkin",
  "in_reply_to_user_id_str" : "25713562",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan E. Magen",
      "screen_name" : "yonkeltron",
      "indices" : [ 1, 12 ],
      "id_str" : "16798767",
      "id" : 16798767
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37915454479675392",
  "geo" : { },
  "id_str" : "37917547479171072",
  "in_reply_to_user_id" : 16798767,
  "text" : ".@yonkeltron Lots of good info here, from fact sheets to stories of impact on people across the country: http:\/\/wh.gov\/healthreform",
  "id" : 37917547479171072,
  "in_reply_to_status_id" : 37915454479675392,
  "created_at" : "2011-02-16 16:53:42 +0000",
  "in_reply_to_screen_name" : "yonkeltron",
  "in_reply_to_user_id_str" : "16798767",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 98, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37916362558935040",
  "text" : "More on the \"under 26\" provisions from our \u201Cvoices of health reform\u201D series: http:\/\/bit.ly\/hIYOX1 #hcr",
  "id" : 37916362558935040,
  "created_at" : "2011-02-16 16:48:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37915996513779712",
  "text" : ".@thegreatbobo Law includes funding to ensure unjustified hikes get reviewed, experts agree lower costs\/ better quality http:\/\/bit.ly\/fZk2SB",
  "id" : 37915996513779712,
  "created_at" : "2011-02-16 16:47:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mcraves",
      "screen_name" : "mcraves",
      "indices" : [ 1, 9 ],
      "id_str" : "2545517346",
      "id" : 2545517346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37893279374782464",
  "geo" : { },
  "id_str" : "37915052187197441",
  "in_reply_to_user_id" : 66405602,
  "text" : ".@mcraves Kids &lt;26 can stay on parents\u2019 plan,costs depend on plan, in 2014 Exchanges kick in w\/other affordable options http:\/\/bit.ly\/cGxZSg",
  "id" : 37915052187197441,
  "in_reply_to_status_id" : 37893279374782464,
  "created_at" : "2011-02-16 16:43:47 +0000",
  "in_reply_to_screen_name" : "CRAVENSomeMARY",
  "in_reply_to_user_id_str" : "66405602",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 63, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37914607926386688",
  "text" : "Hey all, Kal here sitting w\/ the health reform team, send your #hcr Qs our way  http:\/\/twitpic.com\/40gr1r",
  "id" : 37914607926386688,
  "created_at" : "2011-02-16 16:42:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37887449355128832",
  "text" : "Today at 11:30AM EST: Kalpen Modi + the health reform team take your questions, send Qs using #hcr http:\/\/wh.gov\/xbV",
  "id" : 37887449355128832,
  "created_at" : "2011-02-16 14:54:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37581002620538881",
  "text" : "Starting now: President Obama & the First Lady honor recipients of the 2010 Medal of Freedom http:\/\/wh.gov\/live",
  "id" : 37581002620538881,
  "created_at" : "2011-02-15 18:36:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 97, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37563658699685889",
  "text" : "Tomorrow at 11:30AM EST: Kalpen Modi + the health reform team take your questions, send Qs using #hcr http:\/\/wh.gov\/xbV",
  "id" : 37563658699685889,
  "created_at" : "2011-02-15 17:27:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37557365217689601",
  "text" : "Photo of the Day: President Obama walks along the Colonnade of the White House to the Oval Office  http:\/\/twitpic.com\/405pya",
  "id" : 37557365217689601,
  "created_at" : "2011-02-15 17:02:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37542677293568002",
  "text" : "Now: The President\u2019s press conference on the Budget, watch: http:\/\/wh.gov\/live",
  "id" : 37542677293568002,
  "created_at" : "2011-02-15 16:04:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37522397091332096",
  "text" : "11AM: President holds a press conference on the Budget, watch: http:\/\/wh.gov\/live",
  "id" : 37522397091332096,
  "created_at" : "2011-02-15 14:43:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 15, 22 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37294458072608768",
  "text" : "Romantical\u2026 RT @HHSGov It\u2019s Valentine's Day! Share this e-card about cost-free preventive benefits http:\/\/bit.ly\/dOVCiQ",
  "id" : 37294458072608768,
  "created_at" : "2011-02-14 23:37:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37291945441099777",
  "text" : "Dive a little deeper into the President\u2019s Budget w\/ interactive charts, videos, more: http:\/\/wh.gov\/winning-the-future",
  "id" : 37291945441099777,
  "created_at" : "2011-02-14 23:27:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37285037921677312",
  "text" : "Dr Jill Biden: Keeping Military Families Close to Our Hearts on Valentine\u2019s Day http:\/\/wh.gov\/xTA",
  "id" : 37285037921677312,
  "created_at" : "2011-02-14 23:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37276150451548160",
  "text" : "Full video: The President unveils his budget at Parkville Middle School in Baltimore. (Win the Future) http:\/\/wh.gov\/xT9",
  "id" : 37276150451548160,
  "created_at" : "2011-02-14 22:25:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37170551881474048",
  "text" : "Starting now: The President talks about his FY 2012 Budget http:\/\/wh.gov\/live",
  "id" : 37170551881474048,
  "created_at" : "2011-02-14 15:25:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Grammys",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37001178847907840",
  "text" : "Video of Esperanza Spalding performing \"Tell Him\" @ the White House http:\/\/goo.gl\/rB1SF More music: http:\/\/goo.gl\/N1UGS #Grammys",
  "id" : 37001178847907840,
  "created_at" : "2011-02-14 04:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36527740567953408",
  "text" : "\"... the Iranian government has declared illegal for Iranians what it claimed was noble for Egyptians.\" Full stmt: http:\/\/goo.gl\/8e9gN",
  "id" : 36527740567953408,
  "created_at" : "2011-02-12 20:51:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36481759856181248",
  "text" : "RT @petesouza: New behind-the-scenes photos of President Obama from January: http:\/\/bit.ly\/eNgrEG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36481506704625664",
    "text" : "New behind-the-scenes photos of President Obama from January: http:\/\/bit.ly\/eNgrEG",
    "id" : 36481506704625664,
    "created_at" : "2011-02-12 17:47:23 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 36481759856181248,
  "created_at" : "2011-02-12 17:48:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 29, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36173081416306688",
  "text" : "Full video: The President on #Egypt http:\/\/wh.gov\/xrw  \u201CFor in Egypt, it was the moral force of nonviolence...\u201D",
  "id" : 36173081416306688,
  "created_at" : "2011-02-11 21:21:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36155871025168385",
  "text" : "President Obama: \"Today belongs to the people of Egypt... Americans are moved... because of who we are as a people\"",
  "id" : 36155871025168385,
  "created_at" : "2011-02-11 20:13:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 17, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36155327997026304",
  "text" : "President Obama: #Egypt showed \"we need not be defined by our differences, we can be defined by the common humanity that we share\"",
  "id" : 36155327997026304,
  "created_at" : "2011-02-11 20:11:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36154334534176768",
  "text" : "President Obama: \"Nothing less than genuine democracy will carry the day.\"",
  "id" : 36154334534176768,
  "created_at" : "2011-02-11 20:07:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36154184881541120",
  "text" : "President Obama: \"The people of Egypt have spoken, their voices have been heard, and Egypt will never be the same\"",
  "id" : 36154184881541120,
  "created_at" : "2011-02-11 20:06:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36153591974727680",
  "text" : "Starting now: The President on #Egypt http:\/\/wh.gov\/live",
  "id" : 36153591974727680,
  "created_at" : "2011-02-11 20:04:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 50, 59 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 27, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36146898909798400",
  "text" : "The President\u2019s remarks on #Egypt now at 3:00EST, @PressSec briefs at 3:30. Watch: http:\/\/wh.gov\/live",
  "id" : 36146898909798400,
  "created_at" : "2011-02-11 19:37:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36146433413353473",
  "text" : "Find out why you should be a WH intern & apply here: http:\/\/wh.gov\/xrX",
  "id" : 36146433413353473,
  "created_at" : "2011-02-11 19:35:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36135909518745600",
  "text" : "New West Wing Week: \"The New Electrification\" A week dedicated to out-building the rest of the world http:\/\/wh.gov\/xrZ",
  "id" : 36135909518745600,
  "created_at" : "2011-02-11 18:54:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 39, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36124950280667136",
  "text" : "Update: President Obama\u2019s statement on #Egypt moved back, will send updated time when announced",
  "id" : 36124950280667136,
  "created_at" : "2011-02-11 18:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 35, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36118829998284801",
  "text" : "1:30EST: President Obama speaks on #Egypt, watch http:\/\/wh.gov\/live",
  "id" : 36118829998284801,
  "created_at" : "2011-02-11 17:46:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36082280216657921",
  "text" : "New Goolsbee White Board: Wireless for All, Infrastructure, Jobs, 1st-ever WH Angry Birds reference http:\/\/wh.gov\/x1s",
  "id" : 36082280216657921,
  "created_at" : "2011-02-11 15:21:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35868975229313025",
  "text" : "Obama: \"Egyptian gov\u2019t must put forward\u2026unequivocal path toward genuine democracy\u2026have not yet seized that opportunity\" http:\/\/is.gd\/OK8OmK",
  "id" : 35868975229313025,
  "created_at" : "2011-02-11 01:13:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35775731690643456",
  "text" : "The President: \u201CAmericans will continue to do everything that we can to support an orderly & genuine transition to democracy\u201D",
  "id" : 35775731690643456,
  "created_at" : "2011-02-10 19:02:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 63, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35774866745462784",
  "text" : "The President: \"We are witnessing history unfold\u2026the people of #Egypt are calling for change\u2026 at the forefront\u2026a new generation\u201D",
  "id" : 35774866745462784,
  "created_at" : "2011-02-10 18:59:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35759923266592768",
  "text" : "1:30EST: The President speaks on the National Wireless Initiative, infrastructure & winning the future in MI: http:\/\/wh.gov\/live",
  "id" : 35759923266592768,
  "created_at" : "2011-02-10 18:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35443240131887104",
  "text" : "Want to read about something that saves 160,000 lives\/yr & protects kids from asthma & lung disease? Search no more: http:\/\/goo.gl\/CMCUj",
  "id" : 35443240131887104,
  "created_at" : "2011-02-09 21:01:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Glenn Thrush",
      "screen_name" : "GlennThrush",
      "indices" : [ 57, 69 ],
      "id_str" : "19107878",
      "id" : 19107878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35441664436879360",
  "text" : "RT @pfeiffer44: Tough choices = cutting things u like RT:@GlennThrush April Ryan asks good question: How does Obama feel about cutting H ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glenn Thrush",
        "screen_name" : "GlennThrush",
        "indices" : [ 41, 53 ],
        "id_str" : "19107878",
        "id" : 19107878
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35433912184471552",
    "text" : "Tough choices = cutting things u like RT:@GlennThrush April Ryan asks good question: How does Obama feel about cutting HUD block grants?",
    "id" : 35433912184471552,
    "created_at" : "2011-02-09 20:24:37 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 35441664436879360,
  "created_at" : "2011-02-09 20:55:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rail",
      "indices" : [ 87, 92 ]
    }, {
      "text" : "hsr",
      "indices" : [ 99, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35395229854994433",
  "text" : "RT @RayLaHood: Dreaming big, building big; VP Biden announces comprehensive high-speed #rail plan. #hsr http:\/\/bit.ly\/hvdG4A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rail",
        "indices" : [ 72, 77 ]
      }, {
        "text" : "hsr",
        "indices" : [ 84, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35381427214229504",
    "text" : "Dreaming big, building big; VP Biden announces comprehensive high-speed #rail plan. #hsr http:\/\/bit.ly\/hvdG4A",
    "id" : 35381427214229504,
    "created_at" : "2011-02-09 16:56:04 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 35395229854994433,
  "created_at" : "2011-02-09 17:50:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35366457827139584",
  "text" : "Photo of the Day: Biden & LaHood on Amtrak to High Speed Rail event in Philly. Info: http:\/\/wh.gov\/xxe Photo:  http:\/\/twitpic.com\/3y0w6e",
  "id" : 35366457827139584,
  "created_at" : "2011-02-09 15:56:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 11, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35359400860450816",
  "text" : "\u201CVoices of #HCR\u201D: Nan Warshaw owns a record company in IL, repeal would take away her small biz tax credits http:\/\/wh.gov\/xa3",
  "id" : 35359400860450816,
  "created_at" : "2011-02-09 15:28:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 3, 8 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CFPB",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35057206055411712",
  "text" : "RT @CFPB: Blog: The #CFPB and the Religious Community http:\/\/go.usa.gov\/YLb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CFPB",
        "indices" : [ 10, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35011963532615680",
    "text" : "Blog: The #CFPB and the Religious Community http:\/\/go.usa.gov\/YLb",
    "id" : 35011963532615680,
    "created_at" : "2011-02-08 16:27:57 +0000",
    "user" : {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "protected" : false,
      "id_str" : "234826866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026267147\/ab435400ed4215d94370fdfcf836dfbe_normal.png",
      "id" : 234826866,
      "verified" : true
    }
  },
  "id" : 35057206055411712,
  "created_at" : "2011-02-08 19:27:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Groninga",
      "screen_name" : "JoelGroninga",
      "indices" : [ 41, 54 ],
      "id_str" : "130375773",
      "id" : 130375773
    }, {
      "name" : "Patrick Roath",
      "screen_name" : "PatrickRoath",
      "indices" : [ 55, 68 ],
      "id_str" : "19291702",
      "id" : 19291702
    }, {
      "name" : "Josh Anderson",
      "screen_name" : "joshdanderson",
      "indices" : [ 69, 83 ],
      "id_str" : "17447558",
      "id" : 17447558
    }, {
      "name" : "Allie Bedell",
      "screen_name" : "AllieBedell",
      "indices" : [ 84, 96 ],
      "id_str" : "155796527",
      "id" : 155796527
    }, {
      "name" : "Gianni Lovato",
      "screen_name" : "gianpadano",
      "indices" : [ 97, 108 ],
      "id_str" : "34585196",
      "id" : 34585196
    }, {
      "name" : "Dr. Jim Diamond",
      "screen_name" : "Jim_Diamond",
      "indices" : [ 109, 121 ],
      "id_str" : "19832305",
      "id" : 19832305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35036917506650112",
  "text" : "Winners of joy (not to be sold on eBay): @JoelGroninga @PatrickRoath @joshdanderson @AllieBedell @gianpadano @Jim_Diamond",
  "id" : 35036917506650112,
  "created_at" : "2011-02-08 18:07:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35033931061403649",
  "text" : "Photo of the Day contest: Name the 3 people the President is walking w\/ back from Chamber of Commerce. Prize: joy. http:\/\/twitpic.com\/3xren6",
  "id" : 35033931061403649,
  "created_at" : "2011-02-08 17:55:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 5, 15 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35017507551199232",
  "text" : "VP & @RayLaHood: major $53B investment in high speed rail, bring it to 80% of US in 25 yrs, 1000s of jobs http:\/\/wh.gov\/xco",
  "id" : 35017507551199232,
  "created_at" : "2011-02-08 16:49:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 10, 19 ],
      "id_str" : "39293968",
      "id" : 39293968
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 92, 101 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35014197041430531",
  "geo" : { },
  "id_str" : "35015052188860416",
  "in_reply_to_user_id" : 39293968,
  "text" : "Thanks to @iVillage & everybody else for joining, more info at http:\/\/letsmove.gov & follow @letsmove which just launched!",
  "id" : 35015052188860416,
  "in_reply_to_status_id" : 35014197041430531,
  "created_at" : "2011-02-08 16:40:13 +0000",
  "in_reply_to_screen_name" : "iVillage",
  "in_reply_to_user_id_str" : "39293968",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 0, 9 ],
      "id_str" : "39293968",
      "id" : 39293968
    }, {
      "name" : "Digital Health Maven",
      "screen_name" : "healthwebmaven",
      "indices" : [ 10, 25 ],
      "id_str" : "16942915",
      "id" : 16942915
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsmoveivillage",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35012842327379968",
  "geo" : { },
  "id_str" : "35014034663153664",
  "in_reply_to_user_id" : 39293968,
  "text" : "@iVillage @healthwebmaven All have roles, communities can build playgrounds, make schools healthier http:\/\/is.gd\/NooVLa #letsmoveivillage",
  "id" : 35014034663153664,
  "in_reply_to_status_id" : 35012842327379968,
  "created_at" : "2011-02-08 16:36:11 +0000",
  "in_reply_to_screen_name" : "iVillage",
  "in_reply_to_user_id_str" : "39293968",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 0, 9 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsmoveivillage",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35011931555233792",
  "geo" : { },
  "id_str" : "35012693349900289",
  "in_reply_to_user_id" : 39293968,
  "text" : "@iVillage First Lady challenged restaurants to offer & promote healthy options, reduce portion size http:\/\/is.gd\/4MIjCl #letsmoveivillage",
  "id" : 35012693349900289,
  "in_reply_to_status_id" : 35011931555233792,
  "created_at" : "2011-02-08 16:30:51 +0000",
  "in_reply_to_screen_name" : "iVillage",
  "in_reply_to_user_id_str" : "39293968",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 0, 9 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsmoveivillage",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35010533266554880",
  "geo" : { },
  "id_str" : "35011841231040512",
  "in_reply_to_user_id" : 39293968,
  "text" : "@iVillage Walmart's products will have less sugar & salt, lower prices 4 fruits\/veg as customers asked http:\/\/is.gd\/CGvIPq #letsmoveivillage",
  "id" : 35011841231040512,
  "in_reply_to_status_id" : 35010533266554880,
  "created_at" : "2011-02-08 16:27:28 +0000",
  "in_reply_to_screen_name" : "iVillage",
  "in_reply_to_user_id_str" : "39293968",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 0, 9 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsmoveivillage",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35009817726681088",
  "geo" : { },
  "id_str" : "35010337266868224",
  "in_reply_to_user_id" : 39293968,
  "text" : "@iVillage In 2nd yr, focus on encouraging more groups to help, emphasis on early childhood as strategy to prevent obesity #letsmoveivillage",
  "id" : 35010337266868224,
  "in_reply_to_status_id" : 35009817726681088,
  "created_at" : "2011-02-08 16:21:29 +0000",
  "in_reply_to_screen_name" : "iVillage",
  "in_reply_to_user_id_str" : "39293968",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 0, 9 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsmoveivillage",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35008670374830080",
  "geo" : { },
  "id_str" : "35009645030408192",
  "in_reply_to_user_id" : 39293968,
  "text" : "@iVillage As of 1\/11, you can see full clear calorie counts on containers of major beverage brands, was only per serving  #letsmoveivillage",
  "id" : 35009645030408192,
  "in_reply_to_status_id" : 35008670374830080,
  "created_at" : "2011-02-08 16:18:44 +0000",
  "in_reply_to_screen_name" : "iVillage",
  "in_reply_to_user_id_str" : "39293968",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 0, 9 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsmoveivillage",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35007725163253761",
  "geo" : { },
  "id_str" : "35008583854866432",
  "in_reply_to_user_id" : 39293968,
  "text" : "@iVillage 1 yr in, we've changed conversation about how we eat & move. All parts of society stepped up http:\/\/is.gd\/hp8J9e #letsmoveivillage",
  "id" : 35008583854866432,
  "in_reply_to_status_id" : 35007725163253761,
  "created_at" : "2011-02-08 16:14:31 +0000",
  "in_reply_to_screen_name" : "iVillage",
  "in_reply_to_user_id_str" : "39293968",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 0, 9 ],
      "id_str" : "39293968",
      "id" : 39293968
    }, {
      "name" : "Beth Engelman",
      "screen_name" : "momonashoe",
      "indices" : [ 10, 21 ],
      "id_str" : "40988939",
      "id" : 40988939
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsmoveivillage",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35006603899969536",
  "geo" : { },
  "id_str" : "35007630271463424",
  "in_reply_to_user_id" : 39293968,
  "text" : "@iVillage @momonashoe Get creative, I have dance-a-thons w\/ my kids, or hide stuffed animals & they have 2 min 2 find them #letsmoveivillage",
  "id" : 35007630271463424,
  "in_reply_to_status_id" : 35006603899969536,
  "created_at" : "2011-02-08 16:10:44 +0000",
  "in_reply_to_screen_name" : "iVillage",
  "in_reply_to_user_id_str" : "39293968",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 0, 9 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35005890222358528",
  "geo" : { },
  "id_str" : "35006397636681729",
  "in_reply_to_user_id" : 39293968,
  "text" : "@iVillage Hey everybody, Robin here -- My background helps me understand what parents face every day trying to raise healthy children",
  "id" : 35006397636681729,
  "in_reply_to_status_id" : 35005890222358528,
  "created_at" : "2011-02-08 16:05:50 +0000",
  "in_reply_to_screen_name" : "iVillage",
  "in_reply_to_user_id_str" : "39293968",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 3, 12 ],
      "id_str" : "39293968",
      "id" : 39293968
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 79, 90 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsmoveivillage",
      "indices" : [ 92, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35005807166750720",
  "text" : "RT @iVillage: Hi Everyone! Welcome to our live Twitterview with Robin Schepper @whitehouse! #letsmoveivillage",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 65, 76 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "letsmoveivillage",
        "indices" : [ 78, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35004939545612288",
    "text" : "Hi Everyone! Welcome to our live Twitterview with Robin Schepper @whitehouse! #letsmoveivillage",
    "id" : 35004939545612288,
    "created_at" : "2011-02-08 16:00:02 +0000",
    "user" : {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "protected" : false,
      "id_str" : "39293968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3055453806\/63bb40e83d33d15f721064533681a4c4_normal.png",
      "id" : 39293968,
      "verified" : true
    }
  },
  "id" : 35005807166750720,
  "created_at" : "2011-02-08 16:03:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 3, 12 ],
      "id_str" : "39293968",
      "id" : 39293968
    }, {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 19, 28 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34999946084093953",
  "text" : "RT @iVillage: Join @iVillage Twitterview 2\/8 11-11:30 AM ET w Robin Schepper of First Lady's #LetsMove initiative. Qs welcome! Use #lets ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "iVillage",
        "screen_name" : "iVillage",
        "indices" : [ 5, 14 ],
        "id_str" : "39293968",
        "id" : 39293968
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 79, 88 ]
      }, {
        "text" : "letsmoveivillage",
        "indices" : [ 117, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34703045199659008",
    "text" : "Join @iVillage Twitterview 2\/8 11-11:30 AM ET w Robin Schepper of First Lady's #LetsMove initiative. Qs welcome! Use #letsmoveivillage",
    "id" : 34703045199659008,
    "created_at" : "2011-02-07 20:00:25 +0000",
    "user" : {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "protected" : false,
      "id_str" : "39293968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3055453806\/63bb40e83d33d15f721064533681a4c4_normal.png",
      "id" : 39293968,
      "verified" : true
    }
  },
  "id" : 34999946084093953,
  "created_at" : "2011-02-08 15:40:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34749120740593664",
  "text" : "\"Advise the Advisor\": New series explains what the President\u2019s up to, asks for your ideas. Plouffe up 1st: http:\/\/wh.gov\/xcY",
  "id" : 34749120740593664,
  "created_at" : "2011-02-07 23:03:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34741247402975232",
  "text" : "Of Refrigerators & Regulations: Obama at CofC breaks down false dichotomy of good biz vs public protections http:\/\/wh.gov\/xOA",
  "id" : 34741247402975232,
  "created_at" : "2011-02-07 22:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34737346717040640",
  "text" : "Video: Valerie Jarrett on National Black HIV\/AIDS Awareness Day: Coming Together to Fight HIV\/AIDS http:\/\/wh.gov\/xci",
  "id" : 34737346717040640,
  "created_at" : "2011-02-07 22:16:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34719163985571840",
  "text" : "Videos: Meet the new Consumer Financial Protection Bureau & the people it will affect http:\/\/wh.gov\/xON",
  "id" : 34719163985571840,
  "created_at" : "2011-02-07 21:04:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34701884631556096",
  "text" : "Obama:  \u201CUnited States to formally recognize Southern Sudan as a sovereign, independent state in July 2011\u201D http:\/\/wh.gov\/xOG",
  "id" : 34701884631556096,
  "created_at" : "2011-02-07 19:55:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34657606786093056",
  "text" : "Obama: \u201CNow is the time to invest in America\u2026 companies have nearly $2T sitting on their balance sheets\u2026 encourage you to get in the game\u201D",
  "id" : 34657606786093056,
  "created_at" : "2011-02-07 16:59:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34654263837724672",
  "text" : "Obama: \"I\u2019ll go anywhere, any time to be a booster for American businesses, American workers & American products\"",
  "id" : 34654263837724672,
  "created_at" : "2011-02-07 16:46:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34651581576126465",
  "text" : "Obama: Americans \u201Csee a widening chasm of wealth & opportunity in this country & they wonder if the American Dream is slipping away\u201D",
  "id" : 34651581576126465,
  "created_at" : "2011-02-07 16:35:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34649964760006656",
  "text" : "Starting now: The President addresses the Chamber of Commerce on gov and biz responsibilities to America, watch http:\/\/wh.gov\/live",
  "id" : 34649964760006656,
  "created_at" : "2011-02-07 16:29:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34642336843563008",
  "text" : "Raw video: The President drops by a roundtable with Penn State students to talk energy & the future http:\/\/wh.gov\/xOa",
  "id" : 34642336843563008,
  "created_at" : "2011-02-07 15:59:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34243148561514496",
  "text" : "RT @pfeiffer44: In today's NYT: OMB Dir Lew lays out some of the tough spending cuts in the upcoming budget. http:\/\/nyti.ms\/hzhFJ5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34223816334905344",
    "text" : "In today's NYT: OMB Dir Lew lays out some of the tough spending cuts in the upcoming budget. http:\/\/nyti.ms\/hzhFJ5",
    "id" : 34223816334905344,
    "created_at" : "2011-02-06 12:16:08 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 34243148561514496,
  "created_at" : "2011-02-06 13:32:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33666136839036928",
  "text" : "Sympathies for the TX, tough times w\/ rolling blackouts. Story blaming Obama, however, is completely bogus http:\/\/wh.gov\/xi9",
  "id" : 33666136839036928,
  "created_at" : "2011-02-04 23:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 17, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33662930641747968",
  "text" : "The President on #Egypt: \u201CSuppression is not going to work.  Engaging in violence is not going to work.\u201D http:\/\/wh.gov\/xiv",
  "id" : 33662930641747968,
  "created_at" : "2011-02-04 23:07:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33616786960297984",
  "text" : "Gotta run -- please share your ideas on innovation http:\/\/wh.gov\/cNh  Stay tuned for wireless initiative (WI3) next Thursday",
  "id" : 33616786960297984,
  "created_at" : "2011-02-04 20:04:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "indices" : [ 0, 10 ],
      "id_str" : "1175221",
      "id" : 1175221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33614777569779713",
  "geo" : { },
  "id_str" : "33616239121137665",
  "in_reply_to_user_id" : 1175221,
  "text" : "@digiphile Prescription data available now, working on lab data in coming months; this remains a top priority for health exchange",
  "id" : 33616239121137665,
  "in_reply_to_status_id" : 33614777569779713,
  "created_at" : "2011-02-04 20:01:50 +0000",
  "in_reply_to_screen_name" : "digiphile",
  "in_reply_to_user_id_str" : "1175221",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brettberry Sauce",
      "screen_name" : "brettglass",
      "indices" : [ 0, 11 ],
      "id_str" : "22828837",
      "id" : 22828837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33614890149089280",
  "geo" : { },
  "id_str" : "33615860723621888",
  "in_reply_to_user_id" : 22828837,
  "text" : "@brettglass President has been very clear about commitment to open internet, thanked FCC for taking action, pledged future vigilance",
  "id" : 33615860723621888,
  "in_reply_to_status_id" : 33614890149089280,
  "created_at" : "2011-02-04 20:00:20 +0000",
  "in_reply_to_screen_name" : "brettglass",
  "in_reply_to_user_id_str" : "22828837",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "indices" : [ 1, 11 ],
      "id_str" : "1175221",
      "id" : 1175221
    }, {
      "name" : "BrightScope",
      "screen_name" : "BrightScope",
      "indices" : [ 12, 24 ],
      "id_str" : "19565198",
      "id" : 19565198
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33614448333692928",
  "geo" : { },
  "id_str" : "33615432090914816",
  "in_reply_to_user_id" : 1175221,
  "text" : ".@digiphile @BrightScope 3 ways: Folks request data on data.gov; Startups are joining Open Health Data Initiative; Agency CTOs also focused",
  "id" : 33615432090914816,
  "in_reply_to_status_id" : 33614448333692928,
  "created_at" : "2011-02-04 19:58:38 +0000",
  "in_reply_to_screen_name" : "digiphile",
  "in_reply_to_user_id_str" : "1175221",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Campbell",
      "screen_name" : "dominiccampbell",
      "indices" : [ 1, 17 ],
      "id_str" : "7526892",
      "id" : 7526892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33612700131000320",
  "geo" : { },
  "id_str" : "33613582642069504",
  "in_reply_to_user_id" : 7526892,
  "text" : ".@dominiccampbell Thanks, we want to hear your ideas on it",
  "id" : 33613582642069504,
  "in_reply_to_status_id" : 33612700131000320,
  "created_at" : "2011-02-04 19:51:17 +0000",
  "in_reply_to_screen_name" : "dominiccampbell",
  "in_reply_to_user_id_str" : "7526892",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atlas Corps",
      "screen_name" : "atlascorps",
      "indices" : [ 0, 11 ],
      "id_str" : "12761622",
      "id" : 12761622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33610325001646080",
  "geo" : { },
  "id_str" : "33611135659941888",
  "in_reply_to_user_id" : 12761622,
  "text" : "@atlascorps we need your help - this is about a national effort; please comment on the document at www.whitehouse.gov\/innovation",
  "id" : 33611135659941888,
  "in_reply_to_status_id" : 33610325001646080,
  "created_at" : "2011-02-04 19:41:33 +0000",
  "in_reply_to_screen_name" : "atlascorps",
  "in_reply_to_user_id_str" : "12761622",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041D\u0438\u043A\u043E\u043B\u0430\u0439 \u0421\u043E\u043B\u043E\u0432\u044C\u0435\u0432",
      "screen_name" : "alexanderfurnas",
      "indices" : [ 0, 16 ],
      "id_str" : "3040431425",
      "id" : 3040431425
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 17, 32 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33609555023757313",
  "geo" : { },
  "id_str" : "33610637137416192",
  "in_reply_to_user_id" : 230541978,
  "text" : "@AlexanderFurnas @whitehouseostp as Austan said at the presser today, we shouldn't chew up our seed corn that we need for our future growth",
  "id" : 33610637137416192,
  "in_reply_to_status_id" : 33609555023757313,
  "created_at" : "2011-02-04 19:39:35 +0000",
  "in_reply_to_screen_name" : "zfurnas",
  "in_reply_to_user_id_str" : "230541978",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33609506000732160",
  "geo" : { },
  "id_str" : "33610292004913152",
  "in_reply_to_user_id" : 89782108,
  "text" : "@PWiley87 ARPA-e is focused on performance outcomes, not specific technologies; we have an \"all of the above\" approach for R&D",
  "id" : 33610292004913152,
  "in_reply_to_status_id" : 33609506000732160,
  "created_at" : "2011-02-04 19:38:12 +0000",
  "in_reply_to_screen_name" : "pmwcville",
  "in_reply_to_user_id_str" : "89782108",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atlas Corps",
      "screen_name" : "atlascorps",
      "indices" : [ 0, 11 ],
      "id_str" : "12761622",
      "id" : 12761622
    }, {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 12, 22 ],
      "id_str" : "6708952",
      "id" : 6708952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33609000859734016",
  "geo" : { },
  "id_str" : "33609803532083201",
  "in_reply_to_user_id" : 12761622,
  "text" : "@atlascorps @SteveCase great question! we announced today a new \"ARPA-ED\" initiative to catalyze breakthrough learning technologies",
  "id" : 33609803532083201,
  "in_reply_to_status_id" : 33609000859734016,
  "created_at" : "2011-02-04 19:36:16 +0000",
  "in_reply_to_screen_name" : "atlascorps",
  "in_reply_to_user_id_str" : "12761622",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vijay Renganathan",
      "screen_name" : "vijtable",
      "indices" : [ 0, 9 ],
      "id_str" : "156658828",
      "id" : 156658828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33606493131505664",
  "geo" : { },
  "id_str" : "33609511608516608",
  "in_reply_to_user_id" : 156658828,
  "text" : "@vijtable cio.gov has plan to consolidate data centers, emphasize cloud computing; we are focused on open government (re: data.gov)",
  "id" : 33609511608516608,
  "in_reply_to_status_id" : 33606493131505664,
  "created_at" : "2011-02-04 19:35:06 +0000",
  "in_reply_to_screen_name" : "vijtable",
  "in_reply_to_user_id_str" : "156658828",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u04355\u0443\u0432\u0435\u0446\u0443\u043A\u0430\u043F\u044B\u0432\u0440\u0432",
      "screen_name" : "5Xc",
      "indices" : [ 0, 4 ],
      "id_str" : "441170759",
      "id" : 441170759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33605365362851840",
  "geo" : { },
  "id_str" : "33609045185142784",
  "in_reply_to_user_id" : 64165042,
  "text" : "@5xC Aneesh here - Fed R&D helped Andreessen create 1st browser, led to Netscape; Startup America will emphasize student entrepreneurs",
  "id" : 33609045185142784,
  "in_reply_to_status_id" : 33605365362851840,
  "created_at" : "2011-02-04 19:33:15 +0000",
  "in_reply_to_screen_name" : "SmellTheTea",
  "in_reply_to_user_id_str" : "64165042",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33604337854849024",
  "text" : "2:30EST WH CTO Aneesh Chopra takes your Qs via Twitter on the Innovation Strategy (http:\/\/wh.gov\/cNh), send replies this way",
  "id" : 33604337854849024,
  "created_at" : "2011-02-04 19:14:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33556392245731328",
  "text" : "An Innovation-Week West Wing Week: \u201CEnter the Hub\u201D http:\/\/wh.gov\/xlf",
  "id" : 33556392245731328,
  "created_at" : "2011-02-04 16:04:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33537539872800768",
  "text" : "Austan Goolsbee posts on new jobs numbers: private payroll +50K, rate down to 9.0% http:\/\/wh.gov\/xlV",
  "id" : 33537539872800768,
  "created_at" : "2011-02-04 14:49:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33527320450961408",
  "text" : "915am: WH Council for Community Solutions on innovative ways to connect youth to jobs of the future. Watch: http:\/\/wh.gov\/live",
  "id" : 33527320450961408,
  "created_at" : "2011-02-04 14:08:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33328303473430528",
  "text" : "RT @pfeiffer44: In case you missed it: President Clinton to help lead today\u2019s energy efficiency initiative. Read what people are saying: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33318606573936640",
    "text" : "In case you missed it: President Clinton to help lead today\u2019s energy efficiency initiative. Read what people are saying: http:\/\/wh.gov\/xlO",
    "id" : 33318606573936640,
    "created_at" : "2011-02-04 00:19:09 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 33328303473430528,
  "created_at" : "2011-02-04 00:57:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33296368009355264",
  "text" : "Photos, video, fact sheet of Obama at Penn State on \u201CWinning the Future\u201D via innovation & \"Better Buildings\" http:\/\/wh.gov\/xqu",
  "id" : 33296368009355264,
  "created_at" : "2011-02-03 22:50:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 73, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33272225742331904",
  "text" : "Gibbs: \u201Cworld is watching the actions that are taking place right now in #Egypt\u201D re: violence, reporters: http:\/\/wh.gov\/xqN",
  "id" : 33272225742331904,
  "created_at" : "2011-02-03 21:14:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philip J. Crowley",
      "screen_name" : "PJCrowley",
      "indices" : [ 3, 13 ],
      "id_str" : "138787319",
      "id" : 138787319
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cairo",
      "indices" : [ 88, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33259956283121664",
  "text" : "RT @PJCrowley: There is a concerted campaign to intimidate international journalists in #Cairo and interfere with their reporting. We co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cairo",
        "indices" : [ 73, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33152085247660032",
    "text" : "There is a concerted campaign to intimidate international journalists in #Cairo and interfere with their reporting. We condemn such actions.",
    "id" : 33152085247660032,
    "created_at" : "2011-02-03 13:17:27 +0000",
    "user" : {
      "name" : "Philip J. Crowley",
      "screen_name" : "PJCrowley",
      "protected" : false,
      "id_str" : "138787319",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2763730831\/13e19c4dd633f21170c0cd0d56c368dd_normal.jpeg",
      "id" : 138787319,
      "verified" : true
    }
  },
  "id" : 33259956283121664,
  "created_at" : "2011-02-03 20:26:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 3, 8 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33257480792317952",
  "text" : "RT @CFPB: From day one, the Consumer Financial Protection Bureau is Open for Suggestions. Check out http:\/\/go.usa.gov\/Yvx or tag your su ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cfpb",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33208265521233920",
    "text" : "From day one, the Consumer Financial Protection Bureau is Open for Suggestions. Check out http:\/\/go.usa.gov\/Yvx or tag your suggestion #cfpb",
    "id" : 33208265521233920,
    "created_at" : "2011-02-03 17:00:42 +0000",
    "user" : {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "protected" : false,
      "id_str" : "234826866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026267147\/ab435400ed4215d94370fdfcf836dfbe_normal.png",
      "id" : 234826866,
      "verified" : true
    }
  },
  "id" : 33257480792317952,
  "created_at" : "2011-02-03 20:16:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33205171844677632",
  "text" : "RT @ENERGY: Clean Energy Firms Aided by U.S. Find Investors - http:\/\/nyti.ms\/fr7SRr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33189542139797504",
    "text" : "Clean Energy Firms Aided by U.S. Find Investors - http:\/\/nyti.ms\/fr7SRr",
    "id" : 33189542139797504,
    "created_at" : "2011-02-03 15:46:18 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 33205171844677632,
  "created_at" : "2011-02-03 16:48:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33204701969256448",
  "text" : "12EST: Obama talks clean energy, infrastructure, innovation & jobs at Penn State. Watch & discuss via FB: http:\/\/is.gd\/5GNn1r",
  "id" : 33204701969256448,
  "created_at" : "2011-02-03 16:46:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 54, 69 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33176643082133504",
  "text" : "Austan Goolsbee gets riled up w\/ the White Board: How @startupamerica works http:\/\/is.gd\/DfMABH",
  "id" : 33176643082133504,
  "created_at" : "2011-02-03 14:55:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32849680912097280",
  "text" : "Gibbs: \u201CUS deplores and condemns the violence that is taking place in Egypt\u2026 repeat our strong call for restraint\u201D http:\/\/wh.gov\/cJu",
  "id" : 32849680912097280,
  "created_at" : "2011-02-02 17:15:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Martin",
      "screen_name" : "LauraKMM",
      "indices" : [ 53, 62 ],
      "id_str" : "22069212",
      "id" : 22069212
    }, {
      "name" : "Patrick Fitzgibbons",
      "screen_name" : "gravitas28",
      "indices" : [ 63, 74 ],
      "id_str" : "138089041",
      "id" : 138089041
    }, {
      "name" : "Only4RM",
      "screen_name" : "Only4RM",
      "indices" : [ 75, 83 ],
      "id_str" : "60841112",
      "id" : 60841112
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32849016555315201",
  "text" : "Congrats to the winners of Cabinet meeting jeopardy: @LauraKMM @gravitas28 @Only4RM @Diament_OU, others we missed",
  "id" : 32849016555315201,
  "created_at" : "2011-02-02 17:13:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 103, 113 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32837808305475584",
  "text" : "Photo of the Day contest: Name 4 Cabinet members pictured here. Bonus for 5. Prize: not much. (credit: @petesouza) http:\/\/twitpic.com\/3vsscd",
  "id" : 32837808305475584,
  "created_at" : "2011-02-02 16:28:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32812746277920769",
  "text" : "Meanwhile in Sudan\u2026Check out amazing West Wing Week traveling w\/ President\u2019s Special Envoy for referendum http:\/\/wh.gov\/cuh",
  "id" : 32812746277920769,
  "created_at" : "2011-02-02 14:49:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32610732029771777",
  "text" : "Full video: the President on transition in Egypt: http:\/\/is.gd\/MjZ2lc \"a new chapter in the history of a great country\"",
  "id" : 32610732029771777,
  "created_at" : "2011-02-02 01:26:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "Travel - State Dept",
      "screen_name" : "TravelGov",
      "indices" : [ 121, 131 ],
      "id_str" : "15649433",
      "id" : 15649433
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32609472278958080",
  "text" : "RT @StateDept: Public service announcement for American citizens affected by events in #Egypt: http:\/\/bit.ly\/EgyptAmCits @TravelGov",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Travel - State Dept",
        "screen_name" : "TravelGov",
        "indices" : [ 106, 116 ],
        "id_str" : "15649433",
        "id" : 15649433
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Egypt",
        "indices" : [ 72, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32597686645428224",
    "text" : "Public service announcement for American citizens affected by events in #Egypt: http:\/\/bit.ly\/EgyptAmCits @TravelGov",
    "id" : 32597686645428224,
    "created_at" : "2011-02-02 00:34:28 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 32609472278958080,
  "created_at" : "2011-02-02 01:21:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32604020908498945",
  "text" : "President\u2019s full remarks on Egypt: \"I have an unyielding belief that you will determine your own destiny\" http:\/\/is.gd\/5UhIPq",
  "id" : 32604020908498945,
  "created_at" : "2011-02-02 00:59:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32586440688799744",
  "text" : "President Obama: \u201CTo the people of Egypt, particularly the young people of Egypt, I want to be clear: we hear your voices\u201D",
  "id" : 32586440688799744,
  "created_at" : "2011-02-01 23:49:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32586301479845888",
  "text" : "President Obama: Orderly transition in Egypt \"must be meaningful, must be peaceful, and must begin now.\"",
  "id" : 32586301479845888,
  "created_at" : "2011-02-01 23:49:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32578302610771968",
  "text" : "6:20: The President speaks on the situation in Egypt. Watch live http:\/\/wh.gov\/live",
  "id" : 32578302610771968,
  "created_at" : "2011-02-01 23:17:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32525129137266688",
  "text" : "RT @pfeiffer44: Lots happening today, but he WH Commemncement Challenge also launched. Apply to have POTUS speak at your graduation http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32520518670229504",
    "text" : "Lots happening today, but he WH Commemncement Challenge also launched. Apply to have POTUS speak at your graduation http:\/\/bit.ly\/exL39y",
    "id" : 32520518670229504,
    "created_at" : "2011-02-01 19:27:50 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 32525129137266688,
  "created_at" : "2011-02-01 19:46:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32501231586902016",
  "text" : "RT @petesouza: Photo of President Obama participating in a conference call with FEMA regarding the winter storm: http:\/\/bit.ly\/eMopKn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32492485909413889",
    "text" : "Photo of President Obama participating in a conference call with FEMA regarding the winter storm: http:\/\/bit.ly\/eMopKn",
    "id" : 32492485909413889,
    "created_at" : "2011-02-01 17:36:26 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 32501231586902016,
  "created_at" : "2011-02-01 18:11:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32456599930937344",
  "text" : "Photo of the Day: The President at PDB yesterday being briefed on Egypt by National Security Advisor, Deputy, COS http:\/\/twitpic.com\/3vhboo",
  "id" : 32456599930937344,
  "created_at" : "2011-02-01 15:13:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]