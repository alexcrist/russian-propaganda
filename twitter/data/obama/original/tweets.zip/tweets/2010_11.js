Grailbird.data.tweets_2010_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 13, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9729897681395713",
  "text" : "Obama on DOD #DADT report: \u201CI call on the Senate to act as soon as possible so I can sign this repeal\u201D http:\/\/bit.ly\/dGsCHy",
  "id" : 9729897681395713,
  "created_at" : "2010-11-30 22:06:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9724472332386304",
  "text" : "Claims Settlement Act passes. Vilsack on the Pigford settlement: http:\/\/go.usa.gov\/1rQ Salazar on Cobell: http:\/\/bit.ly\/e23sZY",
  "id" : 9724472332386304,
  "created_at" : "2010-11-30 21:44:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 4, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9694185904934912",
  "text" : "DOD #DADT report: \u201Dthey can effectively implement this change, maintain unit cohesion \u2026 focus on mission\u201D http:\/\/bit.ly\/bPd67e",
  "id" : 9694185904934912,
  "created_at" : "2010-11-30 19:44:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Jason Petri",
      "screen_name" : "jasonpetri",
      "indices" : [ 107, 118 ],
      "id_str" : "14516704",
      "id" : 14516704
    }, {
      "name" : "Don Giles",
      "screen_name" : "dongiles1",
      "indices" : [ 121, 131 ],
      "id_str" : "59930333",
      "id" : 59930333
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 26, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9684303390711808",
  "text" : "RT @PressSec: Video of my #1Q answers are up on the bipartisan mtg & jack-o\u2019-lanterns: http:\/\/wh.gov\/1q cc @jasonpetri & @dongiles1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Petri",
        "screen_name" : "jasonpetri",
        "indices" : [ 93, 104 ],
        "id_str" : "14516704",
        "id" : 14516704
      }, {
        "name" : "Don Giles",
        "screen_name" : "dongiles1",
        "indices" : [ 107, 117 ],
        "id_str" : "59930333",
        "id" : 59930333
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 12, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9682581561806849",
    "text" : "Video of my #1Q answers are up on the bipartisan mtg & jack-o\u2019-lanterns: http:\/\/wh.gov\/1q cc @jasonpetri & @dongiles1",
    "id" : 9682581561806849,
    "created_at" : "2010-11-30 18:58:01 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 9684303390711808,
  "created_at" : "2010-11-30 19:04:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9673283561590784",
  "text" : "Just started: Tuesday Talk live video chat with Energy Secretary Chu, join via Facebook http:\/\/bit.ly\/hSr1F",
  "id" : 9673283561590784,
  "created_at" : "2010-11-30 18:21:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9659988716822528",
  "text" : "Starting soon - The President speaks after bipartisan meeting, watch: http:\/\/wh.gov\/live",
  "id" : 9659988716822528,
  "created_at" : "2010-11-30 17:28:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 94, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9623309821943808",
  "text" : "RT @PressSec: President meets w\/bipartisan Congressional Leaders this am; Send Qs my way with #1Q & check out past video answers here: w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 80, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9622904446652416",
    "text" : "President meets w\/bipartisan Congressional Leaders this am; Send Qs my way with #1Q & check out past video answers here: wh.gov\/1q",
    "id" : 9622904446652416,
    "created_at" : "2010-11-30 15:00:53 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 9623309821943808,
  "created_at" : "2010-11-30 15:02:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9372723759292416",
  "text" : "Miss the Thanksgiving week West Wing Week? Obama on Apple the turkey: \"That\u2019s like a prehistoric beast\u201D http:\/\/bit.ly\/g3BfMU",
  "id" : 9372723759292416,
  "created_at" : "2010-11-29 22:26:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9332967730061312",
  "text" : "3:00 EST Live video chat on DREAM Act with Cecilia Mu\u00F1oz via Facebook  http:\/\/bit.ly\/bLTH91",
  "id" : 9332967730061312,
  "created_at" : "2010-11-29 19:48:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "itgetsbetter",
      "indices" : [ 4, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9313692281733120",
  "text" : "New #itgetsbetter contributions from Vilsack: http:\/\/bit.ly\/fCVNdL Very powerful from OPM\u2019s John Berry: http:\/\/bit.ly\/idfWuI",
  "id" : 9313692281733120,
  "created_at" : "2010-11-29 18:32:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9295639355596800",
  "text" : "New OMB Director Jack Lew explains the pay freeze for civilian federal workers http:\/\/bit.ly\/h9Uu3t",
  "id" : 9295639355596800,
  "created_at" : "2010-11-29 17:20:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9281773762519040",
  "text" : "11:35: Obama proposes 2-year pay freeze for civilian fed workers, saving $2B this yr, $60B next 10 yrs http:\/\/wh.gov\/live",
  "id" : 9281773762519040,
  "created_at" : "2010-11-29 16:25:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9270507773894657",
  "text" : "3:00 EST: Youth live video chat on DREAM Act. Ask Q\u2019s now on FB: http:\/\/on.fb.me\/zy1YS Join live at 3:00: http:\/\/wh.gov\/Ojo",
  "id" : 9270507773894657,
  "created_at" : "2010-11-29 15:40:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 123, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9263702746333186",
  "text" : "RT @PressSec: Hope everyone had a great TG. Let's open up the floor for questions, tell me what you want to know w\/hashtag #1Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 109, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9260944806912000",
    "text" : "Hope everyone had a great TG. Let's open up the floor for questions, tell me what you want to know w\/hashtag #1Q",
    "id" : 9260944806912000,
    "created_at" : "2010-11-29 15:02:35 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 9263702746333186,
  "created_at" : "2010-11-29 15:13:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7483483303714816",
  "text" : "RT @NASA: Who's number one on the list of \"Top Ten Must Have Government Apps?\" http:\/\/go.usa.gov\/1iI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7483091572498432",
    "text" : "Who's number one on the list of \"Top Ten Must Have Government Apps?\" http:\/\/go.usa.gov\/1iI",
    "id" : 7483091572498432,
    "created_at" : "2010-11-24 17:18:02 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 7483483303714816,
  "created_at" : "2010-11-24 17:19:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7154428838678529",
  "text" : "Happening now: Tuesday Talk live chat with Health Reform Director Nancy-Ann DeParle http:\/\/ow.ly\/3esMS",
  "id" : 7154428838678529,
  "created_at" : "2010-11-23 19:32:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7097947372126208",
  "text" : "On tap: Obama in Kokomo, IN, an auto success story. Kokomo background: http:\/\/ow.ly\/3eiWI Auto White Board: http:\/\/ow.ly\/3eiXR",
  "id" : 7097947372126208,
  "created_at" : "2010-11-23 15:47:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NKorea",
      "indices" : [ 54, 61 ]
    }, {
      "text" : "SKorea",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "7092100680126464",
  "text" : "RT @AmbassadorRice: The White House strongly condemns #NKorea attack against #SKorea http:\/\/bit.ly\/gnVpLZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NKorea",
        "indices" : [ 34, 41 ]
      }, {
        "text" : "SKorea",
        "indices" : [ 57, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "7091849395179520",
    "text" : "The White House strongly condemns #NKorea attack against #SKorea http:\/\/bit.ly\/gnVpLZ",
    "id" : 7091849395179520,
    "created_at" : "2010-11-23 15:23:23 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 7092100680126464,
  "created_at" : "2010-11-23 15:24:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6828996083851264",
  "text" : "WH White Board (w\/ new links): Your Health Care Dollars. Video: http:\/\/wh.gov\/OYi Ask your Qs: http:\/\/wh.gov\/O4O",
  "id" : 6828996083851264,
  "created_at" : "2010-11-22 21:58:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6823493010202625",
  "text" : "WH White Board: Nancy-Ann DeParle explains how your health care $ is working for you w\/ a new rule wh.gov\/O4l Ask Qs wh.gov\/O15",
  "id" : 6823493010202625,
  "created_at" : "2010-11-22 21:37:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 19, 28 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6764911585660928",
  "text" : "#1Q is live: Watch @presssec take your Qs on DADT & START VIDEO: wh.gov\/1Q",
  "id" : 6764911585660928,
  "created_at" : "2010-11-22 17:44:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6736791839178752",
  "text" : "Fresh photo gallery: Behind the scenes w\/ President Obama at the NATO and EU\/US Summits in Portugal http:\/\/ow.ly\/3dF1C",
  "id" : 6736791839178752,
  "created_at" : "2010-11-22 15:52:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 96, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6723242253352960",
  "text" : "RT @PressSec: Had a trip or 2 since last time, but let\u2019s get back to it: Send in your q's using #1Q. What do you want to know?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 82, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "6722384526577665",
    "text" : "Had a trip or 2 since last time, but let\u2019s get back to it: Send in your q's using #1Q. What do you want to know?",
    "id" : 6722384526577665,
    "created_at" : "2010-11-22 14:55:16 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 6723242253352960,
  "created_at" : "2010-11-22 14:58:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "6135678651863040",
  "text" : "Obama at NATO: \"we stand united \u2026 transition to full Afghan lead\u2026 begin in early 2011\u2026 conclude in 2014\" http:\/\/bit.ly\/9Pqo0U",
  "id" : 6135678651863040,
  "created_at" : "2010-11-21 00:03:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 3, 13 ],
      "id_str" : "6708952",
      "id" : 6708952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5722581374074880",
  "text" : "RT @SteveCase: Obama: \"Today is National Entrepreneurship Day\" http:\/\/bit.ly\/9fnXNL\"We renew our commitment to support entrepreneurs who ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5711994304856064",
    "text" : "Obama: \"Today is National Entrepreneurship Day\" http:\/\/bit.ly\/9fnXNL\"We renew our commitment to support entrepreneurs who power economy\"",
    "id" : 5711994304856064,
    "created_at" : "2010-11-19 20:00:20 +0000",
    "user" : {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "protected" : false,
      "id_str" : "6708952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708164499014987780\/w8TcvuF0_normal.jpg",
      "id" : 6708952,
      "verified" : true
    }
  },
  "id" : 5722581374074880,
  "created_at" : "2010-11-19 20:42:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TEDxPentagon",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5689451590189056",
  "text" : "RT @DeptofDefense: #TEDxPentagon is today! Tune into http:\/\/bit.ly\/bOWtjg or our Facebook page to watch live and participate with other  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TEDxPentagon",
        "indices" : [ 0, 13 ]
      }, {
        "text" : "gov20",
        "indices" : [ 126, 132 ]
      }, {
        "text" : "tedx",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "5634969804210176",
    "text" : "#TEDxPentagon is today! Tune into http:\/\/bit.ly\/bOWtjg or our Facebook page to watch live and participate with other viewers! #gov20 #tedx",
    "id" : 5634969804210176,
    "created_at" : "2010-11-19 14:54:16 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 5689451590189056,
  "created_at" : "2010-11-19 18:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5688561684713474",
  "text" : "New West Wing Week: Behind the scenes from the G20 in Seoul to the Medal of Honor to GM http:\/\/ow.ly\/3cFqW",
  "id" : 5688561684713474,
  "created_at" : "2010-11-19 18:27:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fast Company",
      "screen_name" : "FastCompany",
      "indices" : [ 18, 30 ],
      "id_str" : "2735591",
      "id" : 2735591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lockechat",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5679606019399681",
  "text" : "1:15 Live chat w\/ @fastcompany & Commerce Secretary Gary Locke on Obama admin & entrepreneurs http:\/\/ow.ly\/3cDUj #lockechat",
  "id" : 5679606019399681,
  "created_at" : "2010-11-19 17:51:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5643268050132992",
  "text" : "Fresh WH White Board: Austan Goolsbee on the GM IPO, the rebirth of American autos, American jobs:  http:\/\/ow.ly\/3cxbY",
  "id" : 5643268050132992,
  "created_at" : "2010-11-19 15:27:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5385686488190976",
  "text" : "President Obama on GM IPO: \"One of the Toughest Tales\" Becoming a \"Success Story.\" Video: http:\/\/ow.ly\/3cbFi",
  "id" : 5385686488190976,
  "created_at" : "2010-11-18 22:23:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lgbt",
      "indices" : [ 73, 78 ]
    }, {
      "text" : "itgetsbetter",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5377525035311105",
  "text" : "Vice President Biden's contribution: \"It Gets Better\" http:\/\/ow.ly\/3caFg #lgbt #itgetsbetter",
  "id" : 5377525035311105,
  "created_at" : "2010-11-18 21:51:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lgbt",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5036142873280512",
  "text" : "New rules: equal hospital visitation rights for all patients, includes same-sex domestic partners http:\/\/bit.ly\/bNZ4qV #lgbt",
  "id" : 5036142873280512,
  "created_at" : "2010-11-17 23:14:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "5006931336888320",
  "text" : "What do Yo-Yo Ma, Rep John Lewis, Maya Angelou & Bill Russell have in common? All getting Medal of Freedom http:\/\/ow.ly\/3bvEW",
  "id" : 5006931336888320,
  "created_at" : "2010-11-17 21:18:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4978890812432384",
  "text" : "President Obama on Senate Republicans blocking Paycheck Fairness Act ensuring fair pay for women: http:\/\/ow.ly\/3brH9",
  "id" : 4978890812432384,
  "created_at" : "2010-11-17 19:27:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4666143360950272",
  "text" : "\"Sal had saved him from the enemy-now he had to try to save his life\" Full video\/ photos of Medal of Honor: http:\/\/ow.ly\/3aTXL",
  "id" : 4666143360950272,
  "created_at" : "2010-11-16 22:44:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4640137719848961",
  "text" : "Vice President Biden: \"Failure to pass the New START Treaty this year would endanger our national security\" http:\/\/ow.ly\/3aQym",
  "id" : 4640137719848961,
  "created_at" : "2010-11-16 21:01:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4607401214873600",
  "text" : "Watch live at 2:00EST: The President awards Staff Sergeant Salvatore Giunta, US Army, the Medal of Honor. http:\/\/wh.gov\/live",
  "id" : 4607401214873600,
  "created_at" : "2010-11-16 18:51:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4592728201494528",
  "text" : "Tues Talk: 1:00 EST live chat w\/ the inventor of the digital camera, a chemist & a climate change expert: http:\/\/ow.ly\/3aJ60",
  "id" : 4592728201494528,
  "created_at" : "2010-11-16 17:52:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDAgov",
      "indices" : [ 3, 11 ],
      "id_str" : "249715521",
      "id" : 249715521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4581480554561536",
  "text" : "RT @USDAgov: USDA Blog: We Built the Dataset and Map, Now You Can Design a Farmers Market App! http:\/\/bit.ly\/a7TWkS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4577815294906368",
    "text" : "USDA Blog: We Built the Dataset and Map, Now You Can Design a Farmers Market App! http:\/\/bit.ly\/a7TWkS",
    "id" : 4577815294906368,
    "created_at" : "2010-11-16 16:53:30 +0000",
    "user" : {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "protected" : false,
      "id_str" : "61853389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475696751\/bf524afc612e7aa534d6c543a3d3e144_normal.jpeg",
      "id" : 61853389,
      "verified" : true
    }
  },
  "id" : 4581480554561536,
  "created_at" : "2010-11-16 17:08:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4549102721310720",
  "text" : "On tap: 2:00 President awards Staff Sergeant Salvatore Giunta, US Army, the Medal of Honor. Full schedule http:\/\/ow.ly\/3aAcE",
  "id" : 4549102721310720,
  "created_at" : "2010-11-16 14:59:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4314736011247616",
  "text" : "Internets are getting crowded nowadays, there are now 8 WH Twitter accounts. Turn your back for a second\u2026 http:\/\/ow.ly\/3aeMM",
  "id" : 4314736011247616,
  "created_at" : "2010-11-15 23:28:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "solar",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4304829404938241",
  "text" : "RT @USInteriorNews: Check out our new \"Ask Interior\" video pilot on our #solar work and let us know what you think: http:\/\/bit.ly\/deiR0s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "solar",
        "indices" : [ 52, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4279509729677312",
    "text" : "Check out our new \"Ask Interior\" video pilot on our #solar work and let us know what you think: http:\/\/bit.ly\/deiR0s",
    "id" : 4279509729677312,
    "created_at" : "2010-11-15 21:08:09 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 4304829404938241,
  "created_at" : "2010-11-15 22:48:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4263999717773312",
  "text" : "Learn a bit more about our 2010 SAVE Award winner, courtesy of 57K public votes, from OMB\u2019s Jeff Zients http:\/\/ow.ly\/3a8jL",
  "id" : 4263999717773312,
  "created_at" : "2010-11-15 20:06:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gov20",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4254151835914241",
  "text" : "Heard here 1st: SAVE Award Winner is Trudy Givens of WI, idea to dramatically cut needless printing of Federal Register #gov20",
  "id" : 4254151835914241,
  "created_at" : "2010-11-15 19:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4227245233147904",
  "text" : "RT @whitehouseostp: Submit questions now for tomorrow's Tuesday Talk: National Medals Laureates of Science, Technology and Innovation ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "4216019019112448",
    "text" : "Submit questions now for tomorrow's Tuesday Talk: National Medals Laureates of Science, Technology and Innovation http:\/\/go.usa.gov\/Cyt",
    "id" : 4216019019112448,
    "created_at" : "2010-11-15 16:55:51 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 4227245233147904,
  "created_at" : "2010-11-15 17:40:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4221940403273728",
  "text" : "Last photo gallery of the Asia trip: The President in Japan. APEC Summit, robots, Great Buddha http:\/\/ow.ly\/39Tzc",
  "id" : 4221940403273728,
  "created_at" : "2010-11-15 17:19:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3207150142750721",
  "text" : "\"Those Who Served & Sacrificed\" Quick, moving video & photos of VP at the Tomb of the Unknowns yesterday http:\/\/ow.ly\/393Rm",
  "id" : 3207150142750721,
  "created_at" : "2010-11-12 22:06:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3182724160430082",
  "text" : "The President at the G20 Summit in Seoul - remarks, fact sheets, photo gallery. Something for every one http:\/\/ow.ly\/3912m",
  "id" : 3182724160430082,
  "created_at" : "2010-11-12 20:29:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3143625676431360",
  "text" : "West Wing Week: A special behind-the-scenes look at the President & First Lady in Asia:\nhttp:\/\/ow.ly\/38Vmo",
  "id" : 3143625676431360,
  "created_at" : "2010-11-12 17:54:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3133747805290496",
  "text" : "Energy Secretary Steven Chu is introduced to The Onion http:\/\/ow.ly\/38TA2",
  "id" : 3133747805290496,
  "created_at" : "2010-11-12 17:15:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "NPR",
      "screen_name" : "NPR",
      "indices" : [ 69, 73 ],
      "id_str" : "5392522",
      "id" : 5392522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gov20",
      "indices" : [ 33, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3114876432023553",
  "text" : "RT @macon44: Your morning cup o' #Gov20: 2 SAVE award finalists tell @NPR abt ideas 2 cut costs http:\/\/is.gd\/gYjbt See more & vote http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NPR",
        "screen_name" : "NPR",
        "indices" : [ 56, 60 ],
        "id_str" : "5392522",
        "id" : 5392522
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gov20",
        "indices" : [ 20, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "3108462774984704",
    "text" : "Your morning cup o' #Gov20: 2 SAVE award finalists tell @NPR abt ideas 2 cut costs http:\/\/is.gd\/gYjbt See more & vote http:\/\/is.gd\/gQt3v",
    "id" : 3108462774984704,
    "created_at" : "2010-11-12 15:34:49 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 3114876432023553,
  "created_at" : "2010-11-12 16:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 16, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2766350409797632",
  "text" : "The President's #VeteransDay Troop Rally in Seoul: \"We remember.\" Full video\/ transcript\/ photos: http:\/\/ow.ly\/38fPR",
  "id" : 2766350409797632,
  "created_at" : "2010-11-11 16:55:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 16, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2765862767435776",
  "text" : "The President's #VeteransDay Troop Rally in Seoul: \"We remember.\" Full video\/ transcript\/ photos: http:\/\/ow.ly\/38fBB",
  "id" : 2765862767435776,
  "created_at" : "2010-11-11 16:53:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2538661610528768",
  "text" : "Live Now: President Obama speaks to troops for Veterans Day in Seoul, South Korea. Watch: WH.gov\/Live",
  "id" : 2538661610528768,
  "created_at" : "2010-11-11 01:50:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 79, 89 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2514734301585409",
  "text" : "ICYMI, an amazing 19-photo gallery of the President & First Lady in India from @petesouza & Co. http:\/\/bit.ly\/dr1cb1",
  "id" : 2514734301585409,
  "created_at" : "2010-11-11 00:15:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2488635660177408",
  "text" : "More late night live-stream: The President at a Veterans Day Troop Rally in Seoul, great event, 8:40PM EST http:\/\/wh.gov\/live",
  "id" : 2488635660177408,
  "created_at" : "2010-11-10 22:31:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2446716892610560",
  "text" : "Fresh WH White Board: Goolsbee on why the President is promoting US exports in Asia. Interesting! http:\/\/is.gd\/gUy9J",
  "id" : 2446716892610560,
  "created_at" : "2010-11-10 19:45:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2415854004207616",
  "text" : "The President in Jakarta on democracy, economy, America & Muslim communities. Remarks\/ photo gallery http:\/\/is.gd\/gUn8s",
  "id" : 2415854004207616,
  "created_at" : "2010-11-10 17:42:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2191640890441728",
  "text" : "Obama in Indonesia: \"Prosperity without freedom is just another form of poverty\"",
  "id" : 2191640890441728,
  "created_at" : "2010-11-10 02:51:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2190348323389440",
  "text" : "President Obama speaking to University of Indonesia, watch live now: http:\/\/wh.gov\/live",
  "id" : 2190348323389440,
  "created_at" : "2010-11-10 02:46:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2074427537760256",
  "text" : "2:15: Live video chat w\/ Tammy Duckworth, Veterans Affairs Asst Secretary, Iraq War Vet, on Veterans Day http:\/\/is.gd\/g8omo",
  "id" : 2074427537760256,
  "created_at" : "2010-11-09 19:05:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2060276157386752",
  "text" : "Check out the new \u201CInside the White House\u201D interactive tour of the building, tons of great photos\/ videos http:\/\/is.gd\/gSfWp",
  "id" : 2060276157386752,
  "created_at" : "2010-11-09 18:09:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 46, 61 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2010681679286272",
  "text" : "Tues. Talks: Veterans Day w\/ Tammy Duckworth, @DeptVetAffairs Ass't Sec, Ask your Q's now & join live @ 2:15 ET http:\/\/wh.gov\/3Lz",
  "id" : 2010681679286272,
  "created_at" : "2010-11-09 14:52:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1745446842146816",
  "text" : "Vote now: 2010 SAVE Award, choose winner from 4 finalist ideas submitted by fed employees to streamline govt: http:\/\/is.gd\/gQt3v",
  "id" : 1745446842146816,
  "created_at" : "2010-11-08 21:18:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1712642485915648",
  "text" : "RT @DeptVetAffairs: Check out the first piece on VA's new blog. Be sure to comment and let us know what you think! http:\/\/go.usa.gov\/CWI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1446343826481152",
    "text" : "Check out the first piece on VA's new blog. Be sure to comment and let us know what you think! http:\/\/go.usa.gov\/CWI",
    "id" : 1446343826481152,
    "created_at" : "2010-11-08 01:30:09 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 1712642485915648,
  "created_at" : "2010-11-08 19:08:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monster Worldwide",
      "screen_name" : "MonsterWW",
      "indices" : [ 3, 13 ],
      "id_str" : "17426969",
      "id" : 17426969
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 70, 81 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "economy",
      "indices" : [ 60, 68 ]
    }, {
      "text" : "ATWH",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1670811266060288",
  "text" : "RT @MonsterWW: Ask the White House - Want answers about the #economy? @whitehouse will answer your Qs here: http:\/\/mnstr.me\/a6uF5Y #ATWH",
  "id" : 1670811266060288,
  "created_at" : "2010-11-08 16:22:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1656505870843904",
  "text" : "Photo of the Day: The First Lady dancing with kids in India http:\/\/is.gd\/gPYpp",
  "id" : 1656505870843904,
  "created_at" : "2010-11-08 15:25:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1067710163197952",
  "text" : "Up late in US? Morning person in India? Obama town hall in Mumbai on trip promoting US exports. 1:15AM EST http:\/\/wh.gov\/live",
  "id" : 1067710163197952,
  "created_at" : "2010-11-07 00:25:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDAgov",
      "indices" : [ 25, 33 ],
      "id_str" : "249715521",
      "id" : 249715521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "984469959872512",
  "text" : "Interesting snapshot\u2026 RT @USDAgov: NRCS Around the World: Overcoming Obstacles in Afghanistan http:\/\/bit.ly\/c7TF9F",
  "id" : 984469959872512,
  "created_at" : "2010-11-06 18:54:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "978456380710912",
  "text" : "Weekly Address: Obama lays out priorities on taxes - no to middle class increase, no to $700B in deficits http:\/\/is.gd\/gMHtz",
  "id" : 978456380710912,
  "created_at" : "2010-11-06 18:30:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "977830087233536",
  "text" : "Weekly Address: Obama lays out priorities on taxes - no to middle class increase, no to $700B in deficits",
  "id" : 977830087233536,
  "created_at" : "2010-11-06 18:28:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652966151331840",
  "text" : "Intern Picks: 10 Must-See WH Videos. Perhaps the most agonized-over blog post in WH.gov history: http:\/\/is.gd\/gL7GR",
  "id" : 652966151331840,
  "created_at" : "2010-11-05 20:57:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634148888772609",
  "text" : "Behind-the-Scenes Video: President Obama\u2019s call to the San Francisco Giants, 2010 World Series Champions http:\/\/is.gd\/gL12b",
  "id" : 634148888772609,
  "created_at" : "2010-11-05 19:42:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 28, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575640277356544",
  "text" : "President Obama on new jobs #s: \u201CEncouraging News\u2026 Not Good Enough\u201D Video\/ photos\/ new jobs chart http:\/\/is.gd\/gKEto",
  "id" : 575640277356544,
  "created_at" : "2010-11-05 15:50:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552948014776321",
  "text" : "Heard about how the President\u2019s trip to Asia cost $200 quadrillion per hour? Not true as it turns out http:\/\/is.gd\/gKu1M",
  "id" : 552948014776321,
  "created_at" : "2010-11-05 14:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 29, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545462675312640",
  "text" : "Goolsbee post on latest jobs #s: Private sector up 159K in Oct, gained 1.1 million since last December http:\/\/is.gd\/gKqO3",
  "id" : 545462675312640,
  "created_at" : "2010-11-05 13:50:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 23, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29670112331",
  "text" : "RT @PressSec: One more #1Q before we head abroad. Tell me what you want to know & I\u2019ll answer before briefing today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 9, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29669979016",
    "text" : "One more #1Q before we head abroad. Tell me what you want to know & I\u2019ll answer before briefing today.",
    "id" : 29669979016,
    "created_at" : "2010-11-04 13:59:12 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 29670112331,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29672688198",
  "text" : "Obama invites bipartisan Congressional meeting to \"move the American people's agenda forward\u2026not just going to be a photo op\"",
  "id" : 29672688198,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/yfrog.com\" rel=\"nofollow\"\u003EYfrog\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 15, 24 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 44, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29685832635",
  "text" : "Quick photo of @PressSec answering a couple #1Q questions, video soon http:\/\/yfrog.com\/5n22ij",
  "id" : 29685832635,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 11, 20 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 59, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29690168755",
  "text" : "You asked, @PressSec answered: http:\/\/youtu.be\/9wYWJZMaJwE #1q",
  "id" : 29690168755,
  "created_at" : "2010-11-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29580792309",
  "text" : "1:00 EDT: The President holds a press conference, watch at http:\/\/wh.gov\/live or on your iPhone",
  "id" : 29580792309,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29588775461",
  "text" : "Starting soon: President Obama\u2019s press conference, watch: http:\/\/wh.gov\/live",
  "id" : 29588775461,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29606984263",
  "text" : "Obama\u2019s presser: We all owe it to American people \u201Cto focus on\u2026their jobs, their security & their future\u201D http:\/\/is.gd\/gGoFS",
  "id" : 29606984263,
  "created_at" : "2010-11-03 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29487075875",
  "text" : "1:00: Tuesday Talk w\/ National Security Council folks on President\u2019s upcoming trip to Asia, watch\/engage: http:\/\/is.gd\/g8omo",
  "id" : 29487075875,
  "created_at" : "2010-11-02 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]