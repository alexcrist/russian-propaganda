Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/472906887890223105\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/8gb6tkdSZ0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpAaTuJCIAAx6hz.jpg",
      "id_str" : "472906886979657728",
      "id" : 472906886979657728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpAaTuJCIAAx6hz.jpg",
      "sizes" : [ {
        "h" : 236,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 762,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 709,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8gb6tkdSZ0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472906887890223105",
  "text" : "\"It's a good day.\" \u2014President Obama to Bob and Jani Bergdahl on the recovery of their son, Sergeant Bowe Bergdahl http:\/\/t.co\/8gb6tkdSZ0",
  "id" : 472906887890223105,
  "created_at" : "2014-06-01 01:06:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472865477002559488",
  "text" : "\"We cannot wait for the moment when you are reunited, and your son Bowe is back in your arms.\" \u2014President Obama to Bowe Bergdahl's parents",
  "id" : 472865477002559488,
  "created_at" : "2014-05-31 22:21:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472865314808819712",
  "text" : "\"Bob and Jani\u2014today, families across the United States share in the joy that you feel.\" \u2014President Obama to Bowe Bergdahl's parents",
  "id" : 472865314808819712,
  "created_at" : "2014-05-31 22:20:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472865060805967872",
  "text" : "\"We also maintain an ironclad commitment to bring our prisoners of war home. That\u2019s who we are as Americans.\" \u2014President Obama",
  "id" : 472865060805967872,
  "created_at" : "2014-05-31 22:19:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472864814294106112",
  "text" : "RT @WHLive: Obama on Bergdahl: \"Our top priority is making sure that he gets the care and support he needs and that he can be reunited with\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "472864752872730624",
    "text" : "Obama on Bergdahl: \"Our top priority is making sure that he gets the care and support he needs and that he can be reunited with his family.\"",
    "id" : 472864752872730624,
    "created_at" : "2014-05-31 22:18:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 472864814294106112,
  "created_at" : "2014-05-31 22:18:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472864577445961728",
  "text" : "\"The United States does not ever leave our men and women in uniform behind.\" \u2014President Obama",
  "id" : 472864577445961728,
  "created_at" : "2014-05-31 22:17:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472864478506520576",
  "text" : "\"This morning, I called Bob &amp; Jani Bergdahl and told them that after nearly 5 years in captivity, their son Bowe is coming home.\" \u2014Obama",
  "id" : 472864478506520576,
  "created_at" : "2014-05-31 22:17:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "472864368959692801",
  "text" : "Happening now: President Obama delivers a statement from the Rose Garden. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 472864368959692801,
  "created_at" : "2014-05-31 22:17:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "472858564944740354",
  "text" : "At 6:15pm ET, President Obama delivers a statement from the Rose Garden. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 472858564944740354,
  "created_at" : "2014-05-31 21:54:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/vH98WRY86K",
      "expanded_url" : "http:\/\/go.wh.gov\/UC1PhA",
      "display_url" : "go.wh.gov\/UC1PhA"
    } ]
  },
  "geo" : { },
  "id_str" : "472814844953894912",
  "text" : "\"We\u2019re helping families and businesses save billions with more efficient homes, buildings, and appliances.\" \u2014Obama: http:\/\/t.co\/vH98WRY86K",
  "id" : 472814844953894912,
  "created_at" : "2014-05-31 19:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/vH98WRY86K",
      "expanded_url" : "http:\/\/go.wh.gov\/UC1PhA",
      "display_url" : "go.wh.gov\/UC1PhA"
    } ]
  },
  "geo" : { },
  "id_str" : "472799711523373056",
  "text" : "\"The electricity America generates from wind has tripled, and from the sun\u2014it\u2019s increased more than tenfold.\" \u2014Obama: http:\/\/t.co\/vH98WRY86K",
  "id" : 472799711523373056,
  "created_at" : "2014-05-31 18:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 134, 147 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/vH98WRY86K",
      "expanded_url" : "http:\/\/go.wh.gov\/UC1PhA",
      "display_url" : "go.wh.gov\/UC1PhA"
    } ]
  },
  "geo" : { },
  "id_str" : "472788361782898690",
  "text" : "\"Its costs can be measured in lost lives &amp; livelihoods, homes &amp; businesses.\" \u2014Obama on climate change: http:\/\/t.co\/vH98WRY86K #ActOnClimate",
  "id" : 472788361782898690,
  "created_at" : "2014-05-31 17:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/472780114741047296\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/6uay3DMmZB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo-nAj1CMAAxqh3.png",
      "id_str" : "472780113956712448",
      "id" : 472780113956712448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo-nAj1CMAAxqh3.png",
      "sizes" : [ {
        "h" : 397,
        "resize" : "fit",
        "w" : 873
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 873
      }, {
        "h" : 155,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6uay3DMmZB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472780114741047296",
  "text" : "\"Today, the American people are pleased that we will be able to welcome home Sergeant Bowe Bergdahl.\" \u2014Obama: http:\/\/t.co\/6uay3DMmZB",
  "id" : 472780114741047296,
  "created_at" : "2014-05-31 16:42:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/vH98WRY86K",
      "expanded_url" : "http:\/\/go.wh.gov\/UC1PhA",
      "display_url" : "go.wh.gov\/UC1PhA"
    } ]
  },
  "geo" : { },
  "id_str" : "472759472599744512",
  "text" : "\"As President &amp; as a parent, I refuse to condemn our children to a planet that\u2019s beyond fixing\" \u2014Obama: http:\/\/t.co\/vH98WRY86K #ActOnClimate",
  "id" : 472759472599744512,
  "created_at" : "2014-05-31 15:20:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472750132984037377",
  "text" : "RT @Simas44: It's a false choice between a healthy economy &amp; a healthy future for our kids. America's ready to innovate for both! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/YIH86xXPoC",
        "expanded_url" : "http:\/\/go.wh.gov\/UC1PhA",
        "display_url" : "go.wh.gov\/UC1PhA"
      } ]
    },
    "geo" : { },
    "id_str" : "472747179619414016",
    "text" : "It's a false choice between a healthy economy &amp; a healthy future for our kids. America's ready to innovate for both! http:\/\/t.co\/YIH86xXPoC",
    "id" : 472747179619414016,
    "created_at" : "2014-05-31 14:31:25 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 472750132984037377,
  "created_at" : "2014-05-31 14:43:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 51, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/hDqxVkr1uW",
      "expanded_url" : "http:\/\/go.wh.gov\/UC1PhA",
      "display_url" : "go.wh.gov\/UC1PhA"
    } ]
  },
  "geo" : { },
  "id_str" : "472745164096933888",
  "text" : "President Obama announces new steps he's taking to #ActOnClimate by reducing carbon pollution from power plants \u2192 http:\/\/t.co\/hDqxVkr1uW",
  "id" : 472745164096933888,
  "created_at" : "2014-05-31 14:23:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/WhgjTirUjI",
      "expanded_url" : "http:\/\/wh.gov\/my-brothers-keeper",
      "display_url" : "wh.gov\/my-brothers-ke\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "472508957874216961",
  "text" : "It's time to give more young Americans the support they need to achieve their dreams. Get involved: http:\/\/t.co\/WhgjTirUjI #MyBrothersKeeper",
  "id" : 472508957874216961,
  "created_at" : "2014-05-30 22:44:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Lehrich44\/status\/472478841416736768\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/f5kMBZkuFJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo6VAE_IgAAgwZ6.jpg",
      "id_str" : "472478839491559424",
      "id" : 472478839491559424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo6VAE_IgAAgwZ6.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 619,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/f5kMBZkuFJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472483904008757250",
  "text" : "RT @Lehrich44: PHOTO: Obama tapes weekly address on cutting carbon pollution after meeting children with asthma http:\/\/t.co\/f5kMBZkuFJ #Act\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lehrich44\/status\/472478841416736768\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/f5kMBZkuFJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo6VAE_IgAAgwZ6.jpg",
        "id_str" : "472478839491559424",
        "id" : 472478839491559424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo6VAE_IgAAgwZ6.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 619,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/f5kMBZkuFJ"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 120, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "472481395747868674",
    "text" : "PHOTO: Obama tapes weekly address on cutting carbon pollution after meeting children with asthma http:\/\/t.co\/f5kMBZkuFJ #ActOnClimate",
    "id" : 472481395747868674,
    "created_at" : "2014-05-30 20:55:17 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 472483904008757250,
  "created_at" : "2014-05-30 21:05:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earvin Magic Johnson",
      "screen_name" : "MagicJohnson",
      "indices" : [ 3, 16 ],
      "id_str" : "248900032",
      "id" : 248900032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 117, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/iN1raPxUTM",
      "expanded_url" : "http:\/\/youtu.be\/sZZLSUIlPTk",
      "display_url" : "youtu.be\/sZZLSUIlPTk"
    } ]
  },
  "geo" : { },
  "id_str" : "472461264023998465",
  "text" : "RT @MagicJohnson: Every single one of us can make a difference in the life of a young person. http:\/\/t.co\/iN1raPxUTM #MyBrothersKeeper",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 99, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/iN1raPxUTM",
        "expanded_url" : "http:\/\/youtu.be\/sZZLSUIlPTk",
        "display_url" : "youtu.be\/sZZLSUIlPTk"
      } ]
    },
    "geo" : { },
    "id_str" : "472447739947933697",
    "text" : "Every single one of us can make a difference in the life of a young person. http:\/\/t.co\/iN1raPxUTM #MyBrothersKeeper",
    "id" : 472447739947933697,
    "created_at" : "2014-05-30 18:41:33 +0000",
    "user" : {
      "name" : "Earvin Magic Johnson",
      "screen_name" : "MagicJohnson",
      "protected" : false,
      "id_str" : "248900032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735621697642975232\/YznfoCzt_normal.jpg",
      "id" : 248900032,
      "verified" : true
    }
  },
  "id" : 472461264023998465,
  "created_at" : "2014-05-30 19:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 9, 18 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472453190785724416",
  "text" : "RT @VP: .@PressSec is a great friend, a trusted advisor and an incredible asset for the President and the White House. We'll miss you. -VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 1, 10 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "472452574097211394",
    "text" : ".@PressSec is a great friend, a trusted advisor and an incredible asset for the President and the White House. We'll miss you. -VP",
    "id" : 472452574097211394,
    "created_at" : "2014-05-30 19:00:46 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 472453190785724416,
  "created_at" : "2014-05-30 19:03:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 72, 81 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 83, 94 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/472449528562724864\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/TYq3E50iG6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo56V6SCQAIdRgZ.jpg",
      "id_str" : "472449527761223682",
      "id" : 472449527761223682,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo56V6SCQAIdRgZ.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TYq3E50iG6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472449528562724864",
  "text" : "Thanks for everything, Jay Carney! And congrats to our next White House @PressSec, @JEarnest44. http:\/\/t.co\/TYq3E50iG6",
  "id" : 472449528562724864,
  "created_at" : "2014-05-30 18:48:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Zcx9Unugg7",
      "expanded_url" : "http:\/\/youtu.be\/sZZLSUIlPTk",
      "display_url" : "youtu.be\/sZZLSUIlPTk"
    } ]
  },
  "geo" : { },
  "id_str" : "472426022713847810",
  "text" : "\"To my surprise, he was just like me, growing up without a father.\" \u2014Christian on President Obama: http:\/\/t.co\/Zcx9Unugg7 #MyBrothersKeeper",
  "id" : 472426022713847810,
  "created_at" : "2014-05-30 17:15:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/5PSlOrbyZ5",
      "expanded_url" : "http:\/\/1.usa.gov\/1pEC68L",
      "display_url" : "1.usa.gov\/1pEC68L"
    } ]
  },
  "geo" : { },
  "id_str" : "472425940598153216",
  "text" : "RT @kerrywashington: You can become a positive influence in a young person's life. Sign up + become a mentor TODAY http:\/\/t.co\/5PSlOrbyZ5 #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mybrotherskeeper",
        "indices" : [ 117, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/5PSlOrbyZ5",
        "expanded_url" : "http:\/\/1.usa.gov\/1pEC68L",
        "display_url" : "1.usa.gov\/1pEC68L"
      } ]
    },
    "geo" : { },
    "id_str" : "472425540948086784",
    "text" : "You can become a positive influence in a young person's life. Sign up + become a mentor TODAY http:\/\/t.co\/5PSlOrbyZ5 #mybrotherskeeper -krew",
    "id" : 472425540948086784,
    "created_at" : "2014-05-30 17:13:20 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 472425940598153216,
  "created_at" : "2014-05-30 17:14:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earvin Magic Johnson",
      "screen_name" : "MagicJohnson",
      "indices" : [ 81, 94 ],
      "id_str" : "248900032",
      "id" : 248900032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Zcx9Unugg7",
      "expanded_url" : "http:\/\/youtu.be\/sZZLSUIlPTk",
      "display_url" : "youtu.be\/sZZLSUIlPTk"
    } ]
  },
  "geo" : { },
  "id_str" : "472416538880798720",
  "text" : "President Obama on expanding opportunity for young Americans\u2014with an assist from @MagicJohnson: http:\/\/t.co\/Zcx9Unugg7 #MyBrothersKeeper",
  "id" : 472416538880798720,
  "created_at" : "2014-05-30 16:37:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472398199748308992",
  "text" : "\"We\u2019ll never stop working to do right by you and your families.\" \u2014President Obama to our men and women in uniform",
  "id" : 472398199748308992,
  "created_at" : "2014-05-30 15:24:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472397858768187393",
  "text" : "\"They're the best our country has to offer. They do their duty. They expect us to do ours.\" \u2014President Obama on our veterans",
  "id" : 472397858768187393,
  "created_at" : "2014-05-30 15:23:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472397188505829376",
  "text" : "\"Ric\u2019s commitment to our veterans is unquestioned. I am grateful for his service.\" \u2014President Obama on Secretary Shinseki",
  "id" : 472397188505829376,
  "created_at" : "2014-05-30 15:20:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472396586404683777",
  "text" : "Obama: Shinseki's \"ordered the VA to...contact every veteran in Phoenix waiting for appointments to get them the care they need &amp; deserve.\"",
  "id" : 472396586404683777,
  "created_at" : "2014-05-30 15:18:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "472396463772028928",
  "text" : "Happening now: Watch President Obama deliver a statement from the Briefing Room \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 472396463772028928,
  "created_at" : "2014-05-30 15:17:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "472393609443282944",
  "text" : "At 11:15am ET, President Obama delivers a statement from the White House Briefing Room. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 472393609443282944,
  "created_at" : "2014-05-30 15:06:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/8oNPO3Miv0",
      "expanded_url" : "http:\/\/go.wh.gov\/Y5Kdaz",
      "display_url" : "go.wh.gov\/Y5Kdaz"
    } ]
  },
  "geo" : { },
  "id_str" : "472388645509267456",
  "text" : "Here's how President Obama is expanding opportunity for more hardworking young Americans \u2192 http:\/\/t.co\/8oNPO3Miv0 #MyBrothersKeeper",
  "id" : 472388645509267456,
  "created_at" : "2014-05-30 14:46:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScrippsNationalSpellingBee",
      "indices" : [ 62, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472217047410434048",
  "text" : "Congrats to Ansun and Sriram, the incredible co-champs of the #ScrippsNationalSpellingBee. You make us all proud! -bo",
  "id" : 472217047410434048,
  "created_at" : "2014-05-30 03:24:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/472168593371979776\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/56PTUhR6bL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo161WDCEAACpCD.jpg",
      "id_str" : "472168592813723648",
      "id" : 472168592813723648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo161WDCEAACpCD.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/56PTUhR6bL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472168593371979776",
  "text" : "Group hug! http:\/\/t.co\/56PTUhR6bL",
  "id" : 472168593371979776,
  "created_at" : "2014-05-30 00:12:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadsUp4Safety",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/BmMJ0gujmI",
      "expanded_url" : "http:\/\/go.wh.gov\/1Mykr4",
      "display_url" : "go.wh.gov\/1Mykr4"
    } ]
  },
  "geo" : { },
  "id_str" : "472165476114923520",
  "text" : "\"Sports teach us about...what it takes to succeed not only on the field, but in life.\" \u2014Obama: http:\/\/t.co\/BmMJ0gujmI #HeadsUp4Safety",
  "id" : 472165476114923520,
  "created_at" : "2014-05-29 23:59:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Zion National Park",
      "screen_name" : "ZionNPS",
      "indices" : [ 57, 65 ],
      "id_str" : "44984439",
      "id" : 44984439
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Utah",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472136298212651009",
  "text" : "RT @Interior: If you've never seen a photo of The Subway @ZionNPS, we highly recommend you check out this photo. #Utah http:\/\/t.co\/lBkEH8Df\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zion National Park",
        "screen_name" : "ZionNPS",
        "indices" : [ 43, 51 ],
        "id_str" : "44984439",
        "id" : 44984439
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/472135813774708736\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/lBkEH8Dfqy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo1dBGjIIAA5ipa.jpg",
        "id_str" : "472135809462968320",
        "id" : 472135809462968320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo1dBGjIIAA5ipa.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/lBkEH8Dfqy"
      } ],
      "hashtags" : [ {
        "text" : "Utah",
        "indices" : [ 99, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "472135813774708736",
    "text" : "If you've never seen a photo of The Subway @ZionNPS, we highly recommend you check out this photo. #Utah http:\/\/t.co\/lBkEH8Dfqy",
    "id" : 472135813774708736,
    "created_at" : "2014-05-29 22:02:04 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 472136298212651009,
  "created_at" : "2014-05-29 22:04:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadsUp4Safety",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/SAM28uknRt",
      "expanded_url" : "http:\/\/go.wh.gov\/3U2s1Y",
      "display_url" : "go.wh.gov\/3U2s1Y"
    } ]
  },
  "geo" : { },
  "id_str" : "472112685945868288",
  "text" : "President Obama's convening key stakeholders to help prevent, identify and respond to concussions \u2192 http:\/\/t.co\/SAM28uknRt #HeadsUp4Safety",
  "id" : 472112685945868288,
  "created_at" : "2014-05-29 20:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/CP80GHm2o5",
      "expanded_url" : "http:\/\/youtu.be\/fG_hX_XM4Ks",
      "display_url" : "youtu.be\/fG_hX_XM4Ks"
    } ]
  },
  "geo" : { },
  "id_str" : "472101910812827648",
  "text" : "\"You are the first class to graduate since 9\/11 who may not be sent into combat in Iraq or Afghanistan.\" \u2014Obama: http:\/\/t.co\/CP80GHm2o5",
  "id" : 472101910812827648,
  "created_at" : "2014-05-29 19:47:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JORGE RAMOS",
      "screen_name" : "jorgeramosnews",
      "indices" : [ 3, 18 ],
      "id_str" : "110213431",
      "id" : 110213431
    }, {
      "name" : "Fusion",
      "screen_name" : "ThisIsFusion",
      "indices" : [ 114, 127 ],
      "id_str" : "726088145180217345",
      "id" : 726088145180217345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/5BoiJ1NljK",
      "expanded_url" : "http:\/\/fus.in\/1nsL77L",
      "display_url" : "fus.in\/1nsL77L"
    } ]
  },
  "geo" : { },
  "id_str" : "472083935552618497",
  "text" : "RT @jorgeramosnews: My column: Yes, You, Mr. Boehner, Are Blocking Immigration Reform  http:\/\/t.co\/5BoiJ1NljK via @ThisIsFusion",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fusion",
        "screen_name" : "ThisIsFusion",
        "indices" : [ 94, 107 ],
        "id_str" : "726088145180217345",
        "id" : 726088145180217345
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/5BoiJ1NljK",
        "expanded_url" : "http:\/\/fus.in\/1nsL77L",
        "display_url" : "fus.in\/1nsL77L"
      } ]
    },
    "geo" : { },
    "id_str" : "472071234167898113",
    "text" : "My column: Yes, You, Mr. Boehner, Are Blocking Immigration Reform  http:\/\/t.co\/5BoiJ1NljK via @ThisIsFusion",
    "id" : 472071234167898113,
    "created_at" : "2014-05-29 17:45:27 +0000",
    "user" : {
      "name" : "JORGE RAMOS",
      "screen_name" : "jorgeramosnews",
      "protected" : false,
      "id_str" : "110213431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1136679713\/_T8I5829_normal.jpg",
      "id" : 110213431,
      "verified" : true
    }
  },
  "id" : 472083935552618497,
  "created_at" : "2014-05-29 18:35:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Military Academy",
      "screen_name" : "WestPoint_USMA",
      "indices" : [ 97, 112 ],
      "id_str" : "249844732",
      "id" : 249844732
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/472079145737129984\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/IQ37fHrfEw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo0pezmCIAAP_tu.jpg",
      "id_str" : "472079145166315520",
      "id" : 472079145166315520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo0pezmCIAAP_tu.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IQ37fHrfEw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472079145737129984",
  "text" : "\"To the class of 2014, I congratulate you on taking your place on the Long Gray Line.\" \u2014Obama at @WestPoint_USMA http:\/\/t.co\/IQ37fHrfEw",
  "id" : 472079145737129984,
  "created_at" : "2014-05-29 18:16:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/XgbnRNzbdM",
      "expanded_url" : "http:\/\/go.wh.gov\/n9VcKC",
      "display_url" : "go.wh.gov\/n9VcKC"
    } ]
  },
  "geo" : { },
  "id_str" : "472063611129430016",
  "text" : "\"Just because we have the best hammer does not mean that every problem is a nail.\" \u2014Obama on U.S. leadership: http:\/\/t.co\/XgbnRNzbdM",
  "id" : 472063611129430016,
  "created_at" : "2014-05-29 17:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Military Academy",
      "screen_name" : "WestPoint_USMA",
      "indices" : [ 73, 88 ],
      "id_str" : "249844732",
      "id" : 249844732
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/472054338597425153\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/SZE6n562nK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bo0S60FCMAAqYOo.jpg",
      "id_str" : "472054337565241344",
      "id" : 472054337565241344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bo0S60FCMAAqYOo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/SZE6n562nK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/AA9S3t9Vy2",
      "expanded_url" : "http:\/\/go.wh.gov\/n9VcKC",
      "display_url" : "go.wh.gov\/n9VcKC"
    } ]
  },
  "geo" : { },
  "id_str" : "472054338597425153",
  "text" : "\"You will embody what it means for America to lead the world.\" \u2014Obama at @WestPoint_USMA: http:\/\/t.co\/AA9S3t9Vy2 http:\/\/t.co\/SZE6n562nK",
  "id" : 472054338597425153,
  "created_at" : "2014-05-29 16:38:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472048957171183616",
  "text" : "RT @FLOTUS: \"We know that when we rely on sound science, we can actually begin to turn the tide on childhood obesity.\" \u2014FLOTUS: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/TxJHvfLlTA",
        "expanded_url" : "http:\/\/nyti.ms\/1gBSo29",
        "display_url" : "nyti.ms\/1gBSo29"
      } ]
    },
    "geo" : { },
    "id_str" : "472047608790532096",
    "text" : "\"We know that when we rely on sound science, we can actually begin to turn the tide on childhood obesity.\" \u2014FLOTUS: http:\/\/t.co\/TxJHvfLlTA",
    "id" : 472047608790532096,
    "created_at" : "2014-05-29 16:11:34 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 472048957171183616,
  "created_at" : "2014-05-29 16:16:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadsUp4Safety",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472038319363485696",
  "text" : "\"That\u2019s what today\u2019s about\u2014let\u2019s give parents the information they need to help their kids compete safely.\" \u2014President Obama #HeadsUp4Safety",
  "id" : 472038319363485696,
  "created_at" : "2014-05-29 15:34:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadsUp4Safety",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472037087643193344",
  "text" : "\"That doesn\u2019t mean you\u2019re weak\u2014it means you\u2019re strong.\" \u2014Obama on athletes admitting when they get concussions #HeadsUp4Safety",
  "id" : 472037087643193344,
  "created_at" : "2014-05-29 15:29:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadsUp4Safety",
      "indices" : [ 97, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472035718705848321",
  "text" : "\"We want our kids playing sports\u2026as parents though, we want to keep them safe.\" \u2014President Obama #HeadsUp4Safety",
  "id" : 472035718705848321,
  "created_at" : "2014-05-29 15:24:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadsUp4Safety",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472034771380764673",
  "text" : "\"Sports teach us about teamwork and hard work and what it takes to succeed not only on the field, but in life.\" \u2014Obama #HeadsUp4Safety",
  "id" : 472034771380764673,
  "created_at" : "2014-05-29 15:20:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadsUp4Safety",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472034622092898304",
  "text" : "\"For so many of our kids, sports aren\u2019t just something they do\u2014they're part of their identity.\" \u2014President Obama #HeadsUp4Safety",
  "id" : 472034622092898304,
  "created_at" : "2014-05-29 15:19:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadsUp4Safety",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "472034203836882945",
  "text" : "Watch live: President Obama speaks at the Healthy Kids and Safe Sports Concussion Summit. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v #HeadsUp4Safety",
  "id" : 472034203836882945,
  "created_at" : "2014-05-29 15:18:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadsUp4Safety",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "472025837001125888",
  "text" : "At 11:10am ET, President Obama speaks at the Healthy Kids and Safe Sports Concussion Summit. Watch \u2192 http:\/\/t.co\/7QUc084BX3 #HeadsUp4Safety",
  "id" : 472025837001125888,
  "created_at" : "2014-05-29 14:45:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Richard Sherman",
      "screen_name" : "RSherman_25",
      "indices" : [ 15, 27 ],
      "id_str" : "27698202",
      "id" : 27698202
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 57, 64 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 97, 108 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472022721883553792",
  "text" : "RT @FLOTUS: 1. @RSherman_25\n2. His Seahawk Sous-chefs\n3. @FLOTUS\nInside the frozen tundra of the @WhiteHouse kitchen \u2192 http:\/\/t.co\/YbIb4bhy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard Sherman",
        "screen_name" : "RSherman_25",
        "indices" : [ 3, 15 ],
        "id_str" : "27698202",
        "id" : 27698202
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 45, 52 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 85, 96 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsCook",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/YbIb4bhyQN",
        "expanded_url" : "http:\/\/youtu.be\/3PhV9DzkV-s",
        "display_url" : "youtu.be\/3PhV9DzkV-s"
      } ]
    },
    "geo" : { },
    "id_str" : "472020380383981568",
    "text" : "1. @RSherman_25\n2. His Seahawk Sous-chefs\n3. @FLOTUS\nInside the frozen tundra of the @WhiteHouse kitchen \u2192 http:\/\/t.co\/YbIb4bhyQN #LetsCook",
    "id" : 472020380383981568,
    "created_at" : "2014-05-29 14:23:23 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 472022721883553792,
  "created_at" : "2014-05-29 14:32:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 3, 15 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    }, {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 120, 132 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 97, 109 ]
    }, {
      "text" : "tbt",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472021152043659264",
  "text" : "RT @ReachHigher: Before he was President Clinton, he was Bill Clinton, Georgetown class of 1968. #ReachHigher #tbt (h\/t @billclinton) http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Clinton",
        "screen_name" : "billclinton",
        "indices" : [ 103, 115 ],
        "id_str" : "1330457336",
        "id" : 1330457336
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ReachHigher\/status\/471974676277645312\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Mhhp6QfRBe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BozKdvJIgAAxSn8.jpg",
        "id_str" : "471974673186848768",
        "id" : 471974673186848768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BozKdvJIgAAxSn8.jpg",
        "sizes" : [ {
          "h" : 467,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 825,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 745
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 745
        } ],
        "display_url" : "pic.twitter.com\/Mhhp6QfRBe"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 80, 92 ]
      }, {
        "text" : "tbt",
        "indices" : [ 93, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471974676277645312",
    "text" : "Before he was President Clinton, he was Bill Clinton, Georgetown class of 1968. #ReachHigher #tbt (h\/t @billclinton) http:\/\/t.co\/Mhhp6QfRBe",
    "id" : 471974676277645312,
    "created_at" : "2014-05-29 11:21:46 +0000",
    "user" : {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "protected" : false,
      "id_str" : "2461821548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508240407688663040\/El8GILjl_normal.jpeg",
      "id" : 2461821548,
      "verified" : true
    }
  },
  "id" : 472021152043659264,
  "created_at" : "2014-05-29 14:26:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ltYv6BfWzb",
      "expanded_url" : "http:\/\/instagram.com\/p\/ojlS8WlwTX\/",
      "display_url" : "instagram.com\/p\/ojlS8WlwTX\/"
    } ]
  },
  "geo" : { },
  "id_str" : "471782063532933120",
  "text" : "RT @VP: \"You are Falcons &amp; you carry America on your back. And America will have your back forever\"-VP http:\/\/t.co\/ltYv6BfWzb http:\/\/t.co\/0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/471779856716279808\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/0jWOkeBMhr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BowZRwMIYAATQI0.jpg",
        "id_str" : "471779853751312384",
        "id" : 471779853751312384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BowZRwMIYAATQI0.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/0jWOkeBMhr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/ltYv6BfWzb",
        "expanded_url" : "http:\/\/instagram.com\/p\/ojlS8WlwTX\/",
        "display_url" : "instagram.com\/p\/ojlS8WlwTX\/"
      } ]
    },
    "geo" : { },
    "id_str" : "471779856716279808",
    "text" : "\"You are Falcons &amp; you carry America on your back. And America will have your back forever\"-VP http:\/\/t.co\/ltYv6BfWzb http:\/\/t.co\/0jWOkeBMhr",
    "id" : 471779856716279808,
    "created_at" : "2014-05-28 22:27:37 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 471782063532933120,
  "created_at" : "2014-05-28 22:36:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Military Academy",
      "screen_name" : "WestPoint_USMA",
      "indices" : [ 100, 115 ],
      "id_str" : "249844732",
      "id" : 249844732
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/471776483787423744\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/DAygaZmDnH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BowWNjwCMAAFx_c.jpg",
      "id_str" : "471776483157880832",
      "id" : 471776483157880832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BowWNjwCMAAFx_c.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/DAygaZmDnH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471776483787423744",
  "text" : "\"Your charge, now, is not only to protect our country, but to do what is right and just.\" \u2014Obama at @WestPoint_USMA http:\/\/t.co\/DAygaZmDnH",
  "id" : 471776483787423744,
  "created_at" : "2014-05-28 22:14:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/uhtdTQ3f33",
      "expanded_url" : "http:\/\/youtu.be\/l26Uq3PX-fk",
      "display_url" : "youtu.be\/l26Uq3PX-fk"
    } ]
  },
  "geo" : { },
  "id_str" : "471752699923681280",
  "text" : "\"I'd rather be born black, American, female, in the 20th century, and I was. What luck I have!\" \u2014Maya Angelou: http:\/\/t.co\/uhtdTQ3f33",
  "id" : 471752699923681280,
  "created_at" : "2014-05-28 20:39:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/471746450624643073\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/VFLwyhWK7p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bov65Z5CcAA03Qi.jpg",
      "id_str" : "471746450099957760",
      "id" : 471746450099957760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bov65Z5CcAA03Qi.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VFLwyhWK7p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471746450624643073",
  "text" : "Rest in peace, Maya Angelou. http:\/\/t.co\/VFLwyhWK7p",
  "id" : 471746450624643073,
  "created_at" : "2014-05-28 20:14:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/PduegAWSbH",
      "expanded_url" : "http:\/\/wh.gov\/lo5WJ",
      "display_url" : "wh.gov\/lo5WJ"
    } ]
  },
  "geo" : { },
  "id_str" : "471731640126177281",
  "text" : "RT @whitehouseostp: \"I love this event. It's one of my favorite things all year long.\" - Obama on #WHScienceFair: http:\/\/t.co\/PduegAWSbH ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/471713663943196673\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/gYf6JUm8eI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BovdE6BIUAAy9V0.jpg",
        "id_str" : "471713662353559552",
        "id" : 471713662353559552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BovdE6BIUAAy9V0.jpg",
        "sizes" : [ {
          "h" : 373,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/gYf6JUm8eI"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 78, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/PduegAWSbH",
        "expanded_url" : "http:\/\/wh.gov\/lo5WJ",
        "display_url" : "wh.gov\/lo5WJ"
      } ]
    },
    "geo" : { },
    "id_str" : "471713663943196673",
    "text" : "\"I love this event. It's one of my favorite things all year long.\" - Obama on #WHScienceFair: http:\/\/t.co\/PduegAWSbH http:\/\/t.co\/gYf6JUm8eI",
    "id" : 471713663943196673,
    "created_at" : "2014-05-28 18:04:36 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 471731640126177281,
  "created_at" : "2014-05-28 19:16:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/471723453175693313\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/MiH6YUNxv5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bovl-xkCQAEmKFG.png",
      "id_str" : "471723452609478657",
      "id" : 471723452609478657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bovl-xkCQAEmKFG.png",
      "sizes" : [ {
        "h" : 354,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 502,
        "resize" : "fit",
        "w" : 851
      } ],
      "display_url" : "pic.twitter.com\/MiH6YUNxv5"
    } ],
    "hashtags" : [ {
      "text" : "MayaAngelou",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/N0U1f4O0Ho",
      "expanded_url" : "http:\/\/go.wh.gov\/NrA26q",
      "display_url" : "go.wh.gov\/NrA26q"
    } ]
  },
  "geo" : { },
  "id_str" : "471723453175693313",
  "text" : "\"One of the brightest lights of our time.\" \u2014President Obama on the passing of #MayaAngelou: http:\/\/t.co\/N0U1f4O0Ho http:\/\/t.co\/MiH6YUNxv5",
  "id" : 471723453175693313,
  "created_at" : "2014-05-28 18:43:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471699633073573888",
  "text" : "Michelle and I join millions in remembering Maya Angelou, a storyteller whose voice convinced us we all have something to offer. -bo",
  "id" : 471699633073573888,
  "created_at" : "2014-05-28 17:08:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "US Military Academy",
      "screen_name" : "WestPoint_USMA",
      "indices" : [ 36, 51 ],
      "id_str" : "249844732",
      "id" : 249844732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471688724292829185",
  "text" : "RT @JohnKerry: Tuned in to POTUS at @WestPoint_USMA. Important speech on US leadership. Diplomacy, defense, development all key. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Military Academy",
        "screen_name" : "WestPoint_USMA",
        "indices" : [ 21, 36 ],
        "id_str" : "249844732",
        "id" : 249844732
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/471686690797793280\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/GySbo2hdMG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BovEi37IMAEa1_u.jpg",
        "id_str" : "471686689396895745",
        "id" : 471686689396895745,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BovEi37IMAEa1_u.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/GySbo2hdMG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471686690797793280",
    "text" : "Tuned in to POTUS at @WestPoint_USMA. Important speech on US leadership. Diplomacy, defense, development all key. http:\/\/t.co\/GySbo2hdMG",
    "id" : 471686690797793280,
    "created_at" : "2014-05-28 16:17:25 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 471688724292829185,
  "created_at" : "2014-05-28 16:25:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Military Academy",
      "screen_name" : "WestPoint_USMA",
      "indices" : [ 110, 125 ],
      "id_str" : "249844732",
      "id" : 249844732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471669215813173248",
  "text" : "\"Your charge, now, is not only to protect our country, but to do what is right and just.\" \u2014President Obama to @WestPoint_USMA graduates",
  "id" : 471669215813173248,
  "created_at" : "2014-05-28 15:07:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Military Academy",
      "screen_name" : "WestPoint_USMA",
      "indices" : [ 98, 113 ],
      "id_str" : "249844732",
      "id" : 249844732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471667712771756032",
  "text" : "\"America is not afraid of individual empowerment, we are strengthened by it.\" \u2014President Obama at @WestPoint_USMA",
  "id" : 471667712771756032,
  "created_at" : "2014-05-28 15:02:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471666195994013696",
  "text" : "\"American influence is always stronger when we lead by example\u2014we cannot exempt ourselves from the rules that apply to everyone else\" \u2014Obama",
  "id" : 471666195994013696,
  "created_at" : "2014-05-28 14:55:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471665580505042944",
  "text" : "\"We have a very real chance of achieving a breakthrough agreement.\" \u2014President Obama on preventing Iran from obtaining a nuclear weapon",
  "id" : 471665580505042944,
  "created_at" : "2014-05-28 14:53:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471664992157442048",
  "text" : "\"Standing with our allies on behalf of international order...has given a chance for the Ukrainian people to choose their future.\" \u2014Obama",
  "id" : 471664992157442048,
  "created_at" : "2014-05-28 14:51:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471664306522947584",
  "text" : "RT @WHLive: \"We must be more transparent about both the basis for our actions, and the manner in which they are carried out.\" \u2014President Ob\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471664233567248384",
    "text" : "\"We must be more transparent about both the basis for our actions, and the manner in which they are carried out.\" \u2014President Obama",
    "id" : 471664233567248384,
    "created_at" : "2014-05-28 14:48:11 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 471664306522947584,
  "created_at" : "2014-05-28 14:48:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471662922000003072",
  "text" : "\"At the end of this year, a new Afghan President will be in office, and America\u2019s combat mission will be over.\" \u2014President Obama",
  "id" : 471662922000003072,
  "created_at" : "2014-05-28 14:42:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471661822333161472",
  "text" : "\"Just because we have the best hammer does not mean that every problem is a nail.\" \u2014President Obama on U.S. leadership in the world",
  "id" : 471661822333161472,
  "created_at" : "2014-05-28 14:38:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471661557848764416",
  "text" : "\"U.S. military action cannot be the only\u2014or even primary\u2014component of our leadership in every instance.\" \u2014President Obama",
  "id" : 471661557848764416,
  "created_at" : "2014-05-28 14:37:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471661174971715584",
  "text" : "RT @WHLive: Obama: \"Since WWII, some of our most costly mistakes came not from our restraint, but from our willingness to rush into militar\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471661001654288385",
    "text" : "Obama: \"Since WWII, some of our most costly mistakes came not from our restraint, but from our willingness to rush into military adventures\"",
    "id" : 471661001654288385,
    "created_at" : "2014-05-28 14:35:20 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 471661174971715584,
  "created_at" : "2014-05-28 14:36:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471660835366907904",
  "text" : "\"We have a real stake...in making sure our children and grandchildren grow up in a world where school girls are not kidnapped.\" \u2014Obama",
  "id" : 471660835366907904,
  "created_at" : "2014-05-28 14:34:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471660439730806785",
  "text" : "\"In the 21st century, American isolationism is not an option.\" \u2014President Obama",
  "id" : 471660439730806785,
  "created_at" : "2014-05-28 14:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Military Academy",
      "screen_name" : "WestPoint_USMA",
      "indices" : [ 101, 116 ],
      "id_str" : "249844732",
      "id" : 249844732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471660052915683329",
  "text" : "\"The question we face...is not whether America will lead, but how we will lead.\" \u2014President Obama to @WestPoint_USMA graduates",
  "id" : 471660052915683329,
  "created_at" : "2014-05-28 14:31:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Military Academy",
      "screen_name" : "WestPoint_USMA",
      "indices" : [ 104, 119 ],
      "id_str" : "249844732",
      "id" : 249844732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471658961058664448",
  "text" : "\"We have removed our troops from Iraq. We are winding down our war in Afghanistan.\" \u2014President Obama at @WestPoint_USMA",
  "id" : 471658961058664448,
  "created_at" : "2014-05-28 14:27:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Military Academy",
      "screen_name" : "WestPoint_USMA",
      "indices" : [ 115, 130 ],
      "id_str" : "249844732",
      "id" : 249844732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471658751880364032",
  "text" : "\"You are the first class to graduate since 9\/11 who may not be sent into combat in Iraq or Afghanistan.\" \u2014Obama at @WestPoint_USMA",
  "id" : 471658751880364032,
  "created_at" : "2014-05-28 14:26:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Military Academy",
      "screen_name" : "WestPoint_USMA",
      "indices" : [ 68, 83 ],
      "id_str" : "249844732",
      "id" : 249844732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "471657936184680448",
  "text" : "Happening now: President Obama delivers the Commencement Address at @WestPoint_USMA. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 471657936184680448,
  "created_at" : "2014-05-28 14:23:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Military Academy",
      "screen_name" : "WestPoint_USMA",
      "indices" : [ 65, 80 ],
      "id_str" : "249844732",
      "id" : 249844732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "471649672621473792",
  "text" : "At 10am ET, President Obama delivers the Commencement Address at @WestPoint_USMA. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 471649672621473792,
  "created_at" : "2014-05-28 13:50:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 3, 17 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 53, 64 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471642488453595137",
  "text" : "RT @TheScienceGuy: Spent an extraordinary day at the @WhiteHouse with some of the young, brilliant minds of our future. #WHScienceFair http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 34, 45 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheScienceGuy\/status\/471536775861518336\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/m2NoUmx1Oh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bos8MqGCYAAkXX2.jpg",
        "id_str" : "471536774146056192",
        "id" : 471536774146056192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bos8MqGCYAAkXX2.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/m2NoUmx1Oh"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 101, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471536775861518336",
    "text" : "Spent an extraordinary day at the @WhiteHouse with some of the young, brilliant minds of our future. #WHScienceFair http:\/\/t.co\/m2NoUmx1Oh",
    "id" : 471536775861518336,
    "created_at" : "2014-05-28 06:21:42 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 471642488453595137,
  "created_at" : "2014-05-28 13:21:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/471421738274664448\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/gsQ7o1cqBe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BorTkpCCEAA9Hws.jpg",
      "id_str" : "471421737456766976",
      "id" : 471421737456766976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BorTkpCCEAA9Hws.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 733
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 733
      } ],
      "display_url" : "pic.twitter.com\/gsQ7o1cqBe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/D2YOpwePnO",
      "expanded_url" : "http:\/\/go.wh.gov\/8FnTzp",
      "display_url" : "go.wh.gov\/8FnTzp"
    } ]
  },
  "geo" : { },
  "id_str" : "471421738274664448",
  "text" : "\"This is the year we will conclude our combat mission in Afghanistan.\" \u2014President Obama: http:\/\/t.co\/D2YOpwePnO http:\/\/t.co\/gsQ7o1cqBe",
  "id" : 471421738274664448,
  "created_at" : "2014-05-27 22:44:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/HRfD4XeNUn",
      "expanded_url" : "http:\/\/youtu.be\/vke-SE1mqIs",
      "display_url" : "youtu.be\/vke-SE1mqIs"
    } ]
  },
  "geo" : { },
  "id_str" : "471408243890077696",
  "text" : "\"We have to celebrate outstanding work by young people in science at least as much as we do Super Bowl winners.\" http:\/\/t.co\/HRfD4XeNUn",
  "id" : 471408243890077696,
  "created_at" : "2014-05-27 21:50:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471382478197096448",
  "text" : "RT @VP: We're ending America\u2019s longest war responsibly, bringing home our nation\u2019s heroes, and supporting Afghans as they take the lead. \u2013VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471381580729290753",
    "text" : "We're ending America\u2019s longest war responsibly, bringing home our nation\u2019s heroes, and supporting Afghans as they take the lead. \u2013VP",
    "id" : 471381580729290753,
    "created_at" : "2014-05-27 20:05:01 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 471382478197096448,
  "created_at" : "2014-05-27 20:08:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/471373841298890752\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/1PVl5qn72C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoqoAqiCIAAroKd.jpg",
      "id_str" : "471373840384139264",
      "id" : 471373840384139264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoqoAqiCIAAroKd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1PVl5qn72C"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471373841298890752",
  "text" : "By the end of this year, we will bring America's longest war to a responsible end. http:\/\/t.co\/1PVl5qn72C",
  "id" : 471373841298890752,
  "created_at" : "2014-05-27 19:34:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471365984083668992",
  "text" : "\"We can responsibly end our war in Afghanistan, achieve the objectives that took us to war in the first place &amp; begin a new chapter.\" \u2014Obama",
  "id" : 471365984083668992,
  "created_at" : "2014-05-27 19:03:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471365235052662785",
  "text" : "\u201CThe future of Afghanistan must be decided by Afghans.\u201D \u2014President Obama",
  "id" : 471365235052662785,
  "created_at" : "2014-05-27 19:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471364135746539521",
  "text" : "\"Afghanistan will not be a perfect place and it is not America\u2019s responsibility to make it one.\" \u2014President Obama",
  "id" : 471364135746539521,
  "created_at" : "2014-05-27 18:55:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471363778949677056",
  "text" : "\"When I took office, we had nearly 180,000 troops in harm\u2019s way. By the end of this year, we will have less than 10,000.\" \u2014President Obama",
  "id" : 471363778949677056,
  "created_at" : "2014-05-27 18:54:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471363313217978368",
  "text" : "\"By the end of 2016, our military will draw down to a normal Embassy presence in Kabul, with a security assistance component.\" \u2014Obama",
  "id" : 471363313217978368,
  "created_at" : "2014-05-27 18:52:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471363215059083264",
  "text" : "\"At the beginning of 2015, we will have...9,800 U.S. servicemembers in different parts of the country.\" \u2014President Obama on Afghanistan",
  "id" : 471363215059083264,
  "created_at" : "2014-05-27 18:52:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471362651575308288",
  "text" : "RT @WHLive: \"This transition has allowed us to steadily draw down our own forces\u2014from a peak of 100,000 U.S. troops, to roughly 32,000 toda\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471362489549332480",
    "text" : "\"This transition has allowed us to steadily draw down our own forces\u2014from a peak of 100,000 U.S. troops, to roughly 32,000 today.\" \u2014Obama",
    "id" : 471362489549332480,
    "created_at" : "2014-05-27 18:49:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 471362651575308288,
  "created_at" : "2014-05-27 18:49:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471362288675717120",
  "text" : "\"We have eliminated Osama bin Laden, and we have prevented Afghanistan from being used to launch attacks against our homeland.\" \u2014Obama",
  "id" : 471362288675717120,
  "created_at" : "2014-05-27 18:48:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471362147461922816",
  "text" : "\"This year, we will bring America\u2019s longest war to a responsible end.\" \u2014President Obama on the war in Afghanistan",
  "id" : 471362147461922816,
  "created_at" : "2014-05-27 18:47:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "471362048895361024",
  "text" : "Happening now: President Obama delivers a statement on the way forward in Afghanistan \u2192 http:\/\/t.co\/7QUc084BX3",
  "id" : 471362048895361024,
  "created_at" : "2014-05-27 18:47:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "471353086028808192",
  "text" : "President Obama will deliver a statement from the Rose Garden on the way forward in Afghanistan. Watch at 2:45pm ET \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 471353086028808192,
  "created_at" : "2014-05-27 18:11:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobak Ferdowsi",
      "screen_name" : "tweetsoutloud",
      "indices" : [ 3, 17 ],
      "id_str" : "61306578",
      "id" : 61306578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 107, 121 ]
    }, {
      "text" : "GirlsinSTEM",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471339925238190080",
  "text" : "RT @tweetsoutloud: Love that the president treats these science fair students like the rock stars they are #WHScienceFair #GirlsinSTEM http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tweetsoutloud\/status\/471331954995245057\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/olB2u4iExU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoqB6mnIQAApd2x.jpg",
        "id_str" : "471331954810699776",
        "id" : 471331954810699776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoqB6mnIQAApd2x.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/olB2u4iExU"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 88, 102 ]
      }, {
        "text" : "GirlsinSTEM",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471331954995245057",
    "text" : "Love that the president treats these science fair students like the rock stars they are #WHScienceFair #GirlsinSTEM http:\/\/t.co\/olB2u4iExU",
    "id" : 471331954995245057,
    "created_at" : "2014-05-27 16:47:49 +0000",
    "user" : {
      "name" : "Bobak Ferdowsi",
      "screen_name" : "tweetsoutloud",
      "protected" : false,
      "id_str" : "61306578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745368236384911361\/qx3hr6Fb_normal.jpg",
      "id" : 61306578,
      "verified" : true
    }
  },
  "id" : 471339925238190080,
  "created_at" : "2014-05-27 17:19:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Discovery Education",
      "screen_name" : "DiscoveryEd",
      "indices" : [ 3, 15 ],
      "id_str" : "1665531",
      "id" : 1665531
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OfThePeople",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/eL3JJPgbIL",
      "expanded_url" : "http:\/\/dlc.com\/1t38XUR",
      "display_url" : "dlc.com\/1t38XUR"
    } ]
  },
  "geo" : { },
  "id_str" : "471330608783032321",
  "text" : "RT @DiscoveryEd: Our next Virtual Field Trip from the White House is TODAY! JOIN US at 1:00 pm ET  http:\/\/t.co\/eL3JJPgbIL #OfThePeople",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/coschedule.com\" rel=\"nofollow\"\u003ECoSchedule\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OfThePeople",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/eL3JJPgbIL",
        "expanded_url" : "http:\/\/dlc.com\/1t38XUR",
        "display_url" : "dlc.com\/1t38XUR"
      } ]
    },
    "geo" : { },
    "id_str" : "471312597124644865",
    "text" : "Our next Virtual Field Trip from the White House is TODAY! JOIN US at 1:00 pm ET  http:\/\/t.co\/eL3JJPgbIL #OfThePeople",
    "id" : 471312597124644865,
    "created_at" : "2014-05-27 15:30:54 +0000",
    "user" : {
      "name" : "Discovery Education",
      "screen_name" : "DiscoveryEd",
      "protected" : false,
      "id_str" : "1665531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605812969688043521\/aKoqrKWQ_normal.jpg",
      "id" : 1665531,
      "verified" : false
    }
  },
  "id" : 471330608783032321,
  "created_at" : "2014-05-27 16:42:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471327276739461120",
  "text" : "\"Those of us who are grownups have an obligation to help them reach their full potential, just as others helped us.\" \u2014Obama on STEM students",
  "id" : 471327276739461120,
  "created_at" : "2014-05-27 16:29:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GirlsInSTEM",
      "indices" : [ 110, 122 ]
    }, {
      "text" : "WHScienceFair",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471326746881843200",
  "text" : "\"Fewer than 3 in 10 workers in science and engineering are women...we've got to change those numbers.\" \u2014Obama #GirlsInSTEM #WHScienceFair",
  "id" : 471326746881843200,
  "created_at" : "2014-05-27 16:27:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471325531783180288",
  "text" : "RT @WHLive: \"The solutions they\u2019ve come up with have the potential to help people all over the world.\" \u2014Obama to young innovators at the #W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 125, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471325498157838336",
    "text" : "\"The solutions they\u2019ve come up with have the potential to help people all over the world.\" \u2014Obama to young innovators at the #WHScienceFair",
    "id" : 471325498157838336,
    "created_at" : "2014-05-27 16:22:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 471325531783180288,
  "created_at" : "2014-05-27 16:22:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/471286171906363393\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/1lCofhloV4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BopYRqIIAAA9eL4.jpg",
      "id_str" : "471286171403026432",
      "id" : 471286171403026432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BopYRqIIAAA9eL4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1050,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1lCofhloV4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471325189540950017",
  "text" : "Obama: \"We\u2019re putting a special focus on all the inspiring girls and young women who are excelling in science.\" http:\/\/t.co\/1lCofhloV4",
  "id" : 471325189540950017,
  "created_at" : "2014-05-27 16:20:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/471325033533812736\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/i0TU4jFpOh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bop7nsjCUAACwk0.jpg",
      "id_str" : "471325032916865024",
      "id" : 471325032916865024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bop7nsjCUAACwk0.jpg",
      "sizes" : [ {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/i0TU4jFpOh"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471325033533812736",
  "text" : "\"We need to celebrate science fair winners...at least as much as we do Super Bowl winners.\" \u2014Obama #WHScienceFair http:\/\/t.co\/i0TU4jFpOh",
  "id" : 471325033533812736,
  "created_at" : "2014-05-27 16:20:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/471323620464427008\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/yPLFu3PnXz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bop6VcuCQAAq44s.jpg",
      "id_str" : "471323619918757888",
      "id" : 471323619918757888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bop6VcuCQAAq44s.jpg",
      "sizes" : [ {
        "h" : 551,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 551,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/yPLFu3PnXz"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/1c1OWsTtlY",
      "expanded_url" : "http:\/\/wh.gov\/ScienceFair",
      "display_url" : "wh.gov\/ScienceFair"
    } ]
  },
  "geo" : { },
  "id_str" : "471323620464427008",
  "text" : "Happening now: President Obama speaks at the #WHScienceFair. Watch \u2192 http:\/\/t.co\/1c1OWsTtlY http:\/\/t.co\/yPLFu3PnXz",
  "id" : 471323620464427008,
  "created_at" : "2014-05-27 16:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/471313940472143872\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/sv1NypPOYW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BopxiAJIYAAZDaH.jpg",
      "id_str" : "471313939981426688",
      "id" : 471313939981426688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BopxiAJIYAAZDaH.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sv1NypPOYW"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 44, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/1c1OWsTtlY",
      "expanded_url" : "http:\/\/wh.gov\/ScienceFair",
      "display_url" : "wh.gov\/ScienceFair"
    } ]
  },
  "geo" : { },
  "id_str" : "471313940472143872",
  "text" : "Don't miss President Obama's remarks at the #WHScienceFair. Tune in at 11:45am ET \u2192 http:\/\/t.co\/1c1OWsTtlY http:\/\/t.co\/sv1NypPOYW",
  "id" : 471313940472143872,
  "created_at" : "2014-05-27 15:36:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/471309415644016640\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/lOaxwjE64x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoptakSIUAAR6vV.jpg",
      "id_str" : "471309414197383168",
      "id" : 471309414197383168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoptakSIUAAR6vV.jpg",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/lOaxwjE64x"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/kPm3L0rWng",
      "expanded_url" : "http:\/\/wh.gov\/sciencefair",
      "display_url" : "wh.gov\/sciencefair"
    } ]
  },
  "geo" : { },
  "id_str" : "471309415644016640",
  "text" : "President Obama's doing a walkthrough of all the exhibits at the #WHScienceFair. Watch \u2192 http:\/\/t.co\/kPm3L0rWng http:\/\/t.co\/lOaxwjE64x",
  "id" : 471309415644016640,
  "created_at" : "2014-05-27 15:18:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Larson",
      "screen_name" : "Phil44",
      "indices" : [ 3, 10 ],
      "id_str" : "2525192749",
      "id" : 2525192749
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 41, 52 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/rf0zfLOuXs",
      "expanded_url" : "http:\/\/www.WH.gov\/sciencefair",
      "display_url" : "WH.gov\/sciencefair"
    } ]
  },
  "geo" : { },
  "id_str" : "471306268196757504",
  "text" : "RT @phil44: It's Science Fair Day at the @WhiteHouse! The President's walkthrough of exhibits starts at 11:15am ET http:\/\/t.co\/rf0zfLOuXs #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 29, 40 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/rf0zfLOuXs",
        "expanded_url" : "http:\/\/www.WH.gov\/sciencefair",
        "display_url" : "WH.gov\/sciencefair"
      } ]
    },
    "geo" : { },
    "id_str" : "471304705273257984",
    "text" : "It's Science Fair Day at the @WhiteHouse! The President's walkthrough of exhibits starts at 11:15am ET http:\/\/t.co\/rf0zfLOuXs #WHScienceFair",
    "id" : 471304705273257984,
    "created_at" : "2014-05-27 14:59:32 +0000",
    "user" : {
      "name" : "Phil Larson",
      "screen_name" : "Phil44",
      "protected" : false,
      "id_str" : "2525192749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470938302095183874\/eFAyUNAe_normal.jpeg",
      "id" : 2525192749,
      "verified" : true
    }
  },
  "id" : 471306268196757504,
  "created_at" : "2014-05-27 15:05:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 6, 20 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    }, {
      "name" : "Kari Byron",
      "screen_name" : "KariByron",
      "indices" : [ 27, 37 ],
      "id_str" : "143244854",
      "id" : 143244854
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/471300338503671809\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/c8IugqVroz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoplKM6IMAAsuhf.jpg",
      "id_str" : "471300336951767040",
      "id" : 471300336951767040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoplKM6IMAAsuhf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/c8IugqVroz"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/rU1MJ567WH",
      "expanded_url" : "http:\/\/wh.gov\/sciencefair",
      "display_url" : "wh.gov\/sciencefair"
    } ]
  },
  "geo" : { },
  "id_str" : "471300338503671809",
  "text" : "Watch @TheScienceGuy &amp; @KariByron interview amazing young scientists at the #WHScienceFair \u2192 http:\/\/t.co\/rU1MJ567WH http:\/\/t.co\/c8IugqVroz",
  "id" : 471300338503671809,
  "created_at" : "2014-05-27 14:42:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 106, 120 ]
    }, {
      "text" : "GirlsinSTEM",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471297694745784320",
  "text" : "RT @whitehouseostp: Maria Hanes loves football: she wears it, and studies the science of making it safer. #WHScienceFair #GirlsinSTEM http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/471291286839107584\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/XoXLOfwyiI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bopc7Z8IEAAXpJk.jpg",
        "id_str" : "471291286658748416",
        "id" : 471291286658748416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bopc7Z8IEAAXpJk.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/XoXLOfwyiI"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 86, 100 ]
      }, {
        "text" : "GirlsinSTEM",
        "indices" : [ 101, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471291286839107584",
    "text" : "Maria Hanes loves football: she wears it, and studies the science of making it safer. #WHScienceFair #GirlsinSTEM http:\/\/t.co\/XoXLOfwyiI",
    "id" : 471291286839107584,
    "created_at" : "2014-05-27 14:06:13 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 471297694745784320,
  "created_at" : "2014-05-27 14:31:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecile Richards",
      "screen_name" : "CecileRichards",
      "indices" : [ 3, 18 ],
      "id_str" : "17011177",
      "id" : 17011177
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 90, 95 ]
    }, {
      "text" : "WHScienceFair",
      "indices" : [ 127, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/hYOMBjUziU",
      "expanded_url" : "http:\/\/nbcnews.to\/1tJDysY",
      "display_url" : "nbcnews.to\/1tJDysY"
    } ]
  },
  "geo" : { },
  "id_str" : "471294375029661696",
  "text" : "RT @CecileRichards: Awesome! @WhiteHouse science fair will highlight women &amp; girls in #STEM fields: http:\/\/t.co\/hYOMBjUziU #WHScienceFair",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 9, 20 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 70, 75 ]
      }, {
        "text" : "WHScienceFair",
        "indices" : [ 107, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/hYOMBjUziU",
        "expanded_url" : "http:\/\/nbcnews.to\/1tJDysY",
        "display_url" : "nbcnews.to\/1tJDysY"
      } ]
    },
    "geo" : { },
    "id_str" : "471290928247083008",
    "text" : "Awesome! @WhiteHouse science fair will highlight women &amp; girls in #STEM fields: http:\/\/t.co\/hYOMBjUziU #WHScienceFair",
    "id" : 471290928247083008,
    "created_at" : "2014-05-27 14:04:48 +0000",
    "user" : {
      "name" : "Cecile Richards",
      "screen_name" : "CecileRichards",
      "protected" : false,
      "id_str" : "17011177",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797173764903550977\/fngu4jxk_normal.jpg",
      "id" : 17011177,
      "verified" : true
    }
  },
  "id" : 471294375029661696,
  "created_at" : "2014-05-27 14:18:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouseostp\/status\/471286171906363393\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/1lCofhloV4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BopYRqIIAAA9eL4.jpg",
      "id_str" : "471286171403026432",
      "id" : 471286171403026432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BopYRqIIAAA9eL4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1050,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1lCofhloV4"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 56, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/MjGp78QIqd",
      "expanded_url" : "http:\/\/wh.gov\/science-fair",
      "display_url" : "wh.gov\/science-fair"
    } ]
  },
  "geo" : { },
  "id_str" : "471289523230769154",
  "text" : "Robots, \"Lego queens,\" rockets and more!\nTune in to the #WHScienceFair at 10am ET \u2192 http:\/\/t.co\/MjGp78QIqd http:\/\/t.co\/1lCofhloV4",
  "id" : 471289523230769154,
  "created_at" : "2014-05-27 13:59:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/471277899337568259\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ddMgArby1e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BopQwJTCEAIZ8as.jpg",
      "id_str" : "471277899073327106",
      "id" : 471277899073327106,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BopQwJTCEAIZ8as.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1050,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ddMgArby1e"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 91, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471285708293177344",
  "text" : "RT @whitehouseostp: The kids have arrived! Girl-powered rocketry team from MD is ready for #WHScienceFair! http:\/\/t.co\/ddMgArby1e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/471277899337568259\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/ddMgArby1e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BopQwJTCEAIZ8as.jpg",
        "id_str" : "471277899073327106",
        "id" : 471277899073327106,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BopQwJTCEAIZ8as.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1050,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ddMgArby1e"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 71, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "471277899337568259",
    "text" : "The kids have arrived! Girl-powered rocketry team from MD is ready for #WHScienceFair! http:\/\/t.co\/ddMgArby1e",
    "id" : 471277899337568259,
    "created_at" : "2014-05-27 13:13:01 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 471285708293177344,
  "created_at" : "2014-05-27 13:44:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/471081560662609920\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/bZU74jh2YL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BomeLtZCAAAGvjF.jpg",
      "id_str" : "471081560037261312",
      "id" : 471081560037261312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BomeLtZCAAAGvjF.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/bZU74jh2YL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471081560662609920",
  "text" : "\"Today, we pause to remember our fallen troops, to mourn their loss &amp; to pray for their loved ones.\" \u2014President Obama http:\/\/t.co\/bZU74jh2YL",
  "id" : 471081560662609920,
  "created_at" : "2014-05-27 00:12:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/TaWFJAxcMX",
      "expanded_url" : "http:\/\/go.wh.gov\/WTymUo",
      "display_url" : "go.wh.gov\/WTymUo"
    } ]
  },
  "geo" : { },
  "id_str" : "471014204527214592",
  "text" : "Today, President Obama spoke at Arlington National Cemetery to commemorate Memorial Day:  http:\/\/t.co\/TaWFJAxcMX",
  "id" : 471014204527214592,
  "created_at" : "2014-05-26 19:45:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/470994558990704641\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/lnkeGQ3AGK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BolPDh0CYAA6NVP.jpg",
      "id_str" : "470994558071758848",
      "id" : 470994558071758848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BolPDh0CYAA6NVP.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/lnkeGQ3AGK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/R7Uys8hGlx",
      "expanded_url" : "http:\/\/go.wh.gov\/ZDPg2J",
      "display_url" : "go.wh.gov\/ZDPg2J"
    } ]
  },
  "geo" : { },
  "id_str" : "470994558990704641",
  "text" : "Early this morning, President Obama returned from Afghanistan. View the photo gallery \u2192 http:\/\/t.co\/R7Uys8hGlx, http:\/\/t.co\/lnkeGQ3AGK",
  "id" : 470994558990704641,
  "created_at" : "2014-05-26 18:27:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 29, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470976928787464194",
  "text" : "RT @AmbassadorPower: On this #MemorialDay, reflecting on those who sacrificed everything for our country. To our fallen heroes, thank you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MemorialDay",
        "indices" : [ 8, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "470965801181511680",
    "text" : "On this #MemorialDay, reflecting on those who sacrificed everything for our country. To our fallen heroes, thank you.",
    "id" : 470965801181511680,
    "created_at" : "2014-05-26 16:32:51 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 470976928787464194,
  "created_at" : "2014-05-26 17:17:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470965624491892739",
  "text" : "RT @JohnKerry: Today we pay tribute to our fallen heroes who gave the full measure of sacrifice for our country. #MemorialDay http:\/\/t.co\/d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MemorialDay",
        "indices" : [ 98, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/dqRvX99YEJ",
        "expanded_url" : "http:\/\/go.usa.gov\/8RQ5",
        "display_url" : "go.usa.gov\/8RQ5"
      } ]
    },
    "geo" : { },
    "id_str" : "470958388369575938",
    "text" : "Today we pay tribute to our fallen heroes who gave the full measure of sacrifice for our country. #MemorialDay http:\/\/t.co\/dqRvX99YEJ",
    "id" : 470958388369575938,
    "created_at" : "2014-05-26 16:03:24 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 470965624491892739,
  "created_at" : "2014-05-26 16:32:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470956421375619072",
  "text" : "\"Everything that we hold precious in this country was made possible by Americans who gave their all.\" \u2014President Obama at Arlington Cemetery",
  "id" : 470956421375619072,
  "created_at" : "2014-05-26 15:55:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470956015807389696",
  "text" : "Obama: \"We rededicate ourselves to our sacred obligations to all who wear America\u2019s uniform and to the families who stand by them always.\"",
  "id" : 470956015807389696,
  "created_at" : "2014-05-26 15:53:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470955805203001344",
  "text" : "\"On this Memorial Day, and every day, these are the families and veterans we are sworn to look after.\" \u2014President Obama",
  "id" : 470955805203001344,
  "created_at" : "2014-05-26 15:53:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470955583898927104",
  "text" : "\"This day and this place, are solemn reminders of the extraordinary sacrifice they have made \u2013 in our name.\" \u2014Obama at Arlington Cemetery",
  "id" : 470955583898927104,
  "created_at" : "2014-05-26 15:52:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arlington Cemetery",
      "screen_name" : "ArlingtonNatl",
      "indices" : [ 60, 74 ],
      "id_str" : "102455692",
      "id" : 102455692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/MXZKXpVyqC",
      "expanded_url" : "http:\/\/go.wh.gov\/5c1vLe",
      "display_url" : "go.wh.gov\/5c1vLe"
    } ]
  },
  "geo" : { },
  "id_str" : "470948096290344960",
  "text" : "Happening now: President Obama commemorates Memorial Day at @ArlingtonNatl Cemetery \u2192 http:\/\/t.co\/MXZKXpVyqC",
  "id" : 470948096290344960,
  "created_at" : "2014-05-26 15:22:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/470740848687464448\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/FkHRRiIOez",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BohoTj6CYAAkYzq.jpg",
      "id_str" : "470740846325686272",
      "id" : 470740846325686272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BohoTj6CYAAkYzq.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FkHRRiIOez"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470740848687464448",
  "text" : "\"I\u2019m here on a single mission &amp; that is to thank you for your extraordinary service.\" \u2014Obama to troops in Afghanistan http:\/\/t.co\/FkHRRiIOez",
  "id" : 470740848687464448,
  "created_at" : "2014-05-26 01:38:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/470703618833014784\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/lCcOV8Nu5E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BohGcjaCMAAlxHv.png",
      "id_str" : "470703617414934528",
      "id" : 470703617414934528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BohGcjaCMAAlxHv.png",
      "sizes" : [ {
        "h" : 569,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 570
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 570
      } ],
      "display_url" : "pic.twitter.com\/lCcOV8Nu5E"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/HiX354DecU",
      "expanded_url" : "http:\/\/go.wh.gov\/RYzFFL",
      "display_url" : "go.wh.gov\/RYzFFL"
    } ]
  },
  "geo" : { },
  "id_str" : "470703618833014784",
  "text" : "\"We stand in awe of your service.\" \u2014President Obama to troops in Afghanistan today: http:\/\/t.co\/HiX354DecU, http:\/\/t.co\/lCcOV8Nu5E",
  "id" : 470703618833014784,
  "created_at" : "2014-05-25 23:11:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/PQ5Ah7bZ49",
      "expanded_url" : "http:\/\/go.wh.gov\/a7pTsY",
      "display_url" : "go.wh.gov\/a7pTsY"
    } ]
  },
  "geo" : { },
  "id_str" : "470688099539116032",
  "text" : "President Obama visited Bagram Air Base in Afghanistan to thank our troops for their service this Memorial Day: http:\/\/t.co\/PQ5Ah7bZ49",
  "id" : 470688099539116032,
  "created_at" : "2014-05-25 22:09:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/470644825348648961\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/s5NMLngl7T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BogQ-W4CMAA3eDN.jpg",
      "id_str" : "470644824538755072",
      "id" : 470644824538755072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BogQ-W4CMAA3eDN.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/s5NMLngl7T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470644825348648961",
  "text" : "\"We support you. We are proud of you. We stand in awe of your service.\" \u2013President Obama to troops in Afghanistan http:\/\/t.co\/s5NMLngl7T",
  "id" : 470644825348648961,
  "created_at" : "2014-05-25 19:17:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/8obB7yvpU5",
      "expanded_url" : "http:\/\/go.wh.gov\/SCW75h",
      "display_url" : "go.wh.gov\/SCW75h"
    } ]
  },
  "geo" : { },
  "id_str" : "470610298382987265",
  "text" : "In this week's address, President Obama pays tribute to our fallen heroes this Memorial Day: http:\/\/t.co\/8obB7yvpU5",
  "id" : 470610298382987265,
  "created_at" : "2014-05-25 17:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/se7sva13Ir",
      "expanded_url" : "http:\/\/go.wh.gov\/SCW75h",
      "display_url" : "go.wh.gov\/SCW75h"
    } ]
  },
  "geo" : { },
  "id_str" : "470578771431784448",
  "text" : "Obama: \"As Commander in Chief, I believe that taking care of our veterans and their families is a sacred obligation.\" http:\/\/t.co\/se7sva13Ir",
  "id" : 470578771431784448,
  "created_at" : "2014-05-25 14:54:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/8obB7yvpU5",
      "expanded_url" : "http:\/\/go.wh.gov\/SCW75h",
      "display_url" : "go.wh.gov\/SCW75h"
    } ]
  },
  "geo" : { },
  "id_str" : "470263009642688512",
  "text" : "\"Let\u2019s keep working to make sure that our country upholds our sacred trust to all who\u2019ve served.\" \u2014President Obama: http:\/\/t.co\/8obB7yvpU5",
  "id" : 470263009642688512,
  "created_at" : "2014-05-24 18:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/se7sva13Ir",
      "expanded_url" : "http:\/\/go.wh.gov\/SCW75h",
      "display_url" : "go.wh.gov\/SCW75h"
    } ]
  },
  "geo" : { },
  "id_str" : "470244357183123456",
  "text" : "\"Every single one of us owes our fallen heroes a profound debt of gratitude.\" \u2014President Obama on Memorial Day: http:\/\/t.co\/se7sva13Ir",
  "id" : 470244357183123456,
  "created_at" : "2014-05-24 16:46:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/QccCEdkJ20",
      "expanded_url" : "http:\/\/go.wh.gov\/z4wFwx",
      "display_url" : "go.wh.gov\/z4wFwx"
    } ]
  },
  "geo" : { },
  "id_str" : "469976142871396353",
  "text" : "This week, the President spoke on investing in infrastructure, bringing more jobs &amp; tourism to America, and more \u2192 http:\/\/t.co\/QccCEdkJ20",
  "id" : 469976142871396353,
  "created_at" : "2014-05-23 23:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469965019929915392",
  "text" : "RT @LaborSec: I'm proud of Hawaii for raising its MinWage to $10.10. Now it's time for Congress to #RaiseTheWage for ALL Americans. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/469930854563971072\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/HbH8yuId3e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoWHnx2CIAILV7Y.png",
        "id_str" : "469930853594701826",
        "id" : 469930853594701826,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoWHnx2CIAILV7Y.png",
        "sizes" : [ {
          "h" : 514,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 514,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 514,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HbH8yuId3e"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 85, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469930854563971072",
    "text" : "I'm proud of Hawaii for raising its MinWage to $10.10. Now it's time for Congress to #RaiseTheWage for ALL Americans. http:\/\/t.co\/HbH8yuId3e",
    "id" : 469930854563971072,
    "created_at" : "2014-05-23 20:00:21 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 469965019929915392,
  "created_at" : "2014-05-23 22:16:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Temp",
      "screen_name" : "ShaunHUD",
      "indices" : [ 107, 116 ],
      "id_str" : "2687896501",
      "id" : 2687896501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469928743897927681",
  "text" : "\"I hope that the Senate confirms them both without games or delay.\" \u2014President Obama on the nominations of @ShaunHUD &amp; Juli\u00E1n Castro",
  "id" : 469928743897927681,
  "created_at" : "2014-05-23 19:51:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469927774967578625",
  "text" : "President Obama: \"We also need someone to continue Shaun\u2019s good work at HUD.  And that public servant is Juli\u00E1n Castro.\"",
  "id" : 469927774967578625,
  "created_at" : "2014-05-23 19:48:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "469927145557745665",
  "text" : "President Obama: \"Today, I\u2019m nominating Shaun to be the next Director of the Office of Management and Budget\" http:\/\/t.co\/b4tqL3oo0v",
  "id" : 469927145557745665,
  "created_at" : "2014-05-23 19:45:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Temp",
      "screen_name" : "ShaunHUD",
      "indices" : [ 41, 50 ],
      "id_str" : "2687896501",
      "id" : 2687896501
    }, {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "indices" : [ 90, 97 ],
      "id_str" : "19948202",
      "id" : 19948202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "469926445402554368",
  "text" : "Happening now: President Obama nominates @ShaunHUD for OMB Director and Juli\u00E1n Castro for @HUDGov Secretary \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 469926445402554368,
  "created_at" : "2014-05-23 19:42:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Temp",
      "screen_name" : "ShaunHUD",
      "indices" : [ 40, 49 ],
      "id_str" : "2687896501",
      "id" : 2687896501
    }, {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "indices" : [ 103, 110 ],
      "id_str" : "19948202",
      "id" : 19948202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "469912464654860288",
  "text" : "At 3:30pm ET, President Obama nominates @ShaunHUD for OMB Director and Juli\u00E1n Castro to replace him at @HUDGov: http:\/\/t.co\/b4tqL3oo0v",
  "id" : 469912464654860288,
  "created_at" : "2014-05-23 18:47:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/VRowZR98Oh",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/05\/23\/investing-our-ports-and-infrastructure",
      "display_url" : "whitehouse.gov\/blog\/2014\/05\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "469910826498158592",
  "text" : "RT @VP: Infrastructure + ports + growing the economy = VP Biden's first-ever blog post. Check it out \u2192 http:\/\/t.co\/VRowZR98Oh #RebuildAmeri\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 118, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/VRowZR98Oh",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/05\/23\/investing-our-ports-and-infrastructure",
        "display_url" : "whitehouse.gov\/blog\/2014\/05\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "469893626043310080",
    "text" : "Infrastructure + ports + growing the economy = VP Biden's first-ever blog post. Check it out \u2192 http:\/\/t.co\/VRowZR98Oh #RebuildAmerica",
    "id" : 469893626043310080,
    "created_at" : "2014-05-23 17:32:25 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 469910826498158592,
  "created_at" : "2014-05-23 18:40:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 1, 8 ],
      "id_str" : "15647676",
      "id" : 15647676
    }, {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "indices" : [ 29, 43 ],
      "id_str" : "308573576",
      "id" : 308573576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 147 ],
      "url" : "http:\/\/t.co\/9mdUWEP9kt",
      "expanded_url" : "http:\/\/onforb.es\/1r0UInT",
      "display_url" : "onforb.es\/1r0UInT"
    } ]
  },
  "geo" : { },
  "id_str" : "469872935834906624",
  "text" : ".@DHSGov's Jeh Johnson &amp; @PennyPritzker on how boosting tourism will \"generate more jobs &amp; prosperity here at home.\" http:\/\/t.co\/9mdUWEP9kt",
  "id" : 469872935834906624,
  "created_at" : "2014-05-23 16:10:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/469861567945637889\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/51QvcG8LPA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoVImv9CAAIX4c1.jpg",
      "id_str" : "469861566674763778",
      "id" : 469861566674763778,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoVImv9CAAIX4c1.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/51QvcG8LPA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/RoSUB6guzJ",
      "expanded_url" : "http:\/\/go.wh.gov\/BuF1vJ",
      "display_url" : "go.wh.gov\/BuF1vJ"
    } ]
  },
  "geo" : { },
  "id_str" : "469861567945637889",
  "text" : "\"Tourism translates into jobs and it translates into economic growth.\" \u2014President Obama: http:\/\/t.co\/RoSUB6guzJ http:\/\/t.co\/51QvcG8LPA",
  "id" : 469861567945637889,
  "created_at" : "2014-05-23 15:25:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baseball Hall \u26BE",
      "screen_name" : "baseballhall",
      "indices" : [ 28, 41 ],
      "id_str" : "28406235",
      "id" : 28406235
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 123, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/7cxd5SrhZa",
      "expanded_url" : "http:\/\/youtu.be\/l3YoG53wSWE",
      "display_url" : "youtu.be\/l3YoG53wSWE"
    } ]
  },
  "geo" : { },
  "id_str" : "469847455321051136",
  "text" : "President Obama visited the @BaseballHall to highlight how growing tourism is boosting our economy: http:\/\/t.co\/7cxd5SrhZa #InvestInAmerica",
  "id" : 469847455321051136,
  "created_at" : "2014-05-23 14:28:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/469643723761287168\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/hi3BqhyAoM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoSCelhCYAAoREl.jpg",
      "id_str" : "469643723131740160",
      "id" : 469643723131740160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoSCelhCYAAoREl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hi3BqhyAoM"
    } ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 83, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/1TO0mIdsYv",
      "expanded_url" : "http:\/\/go.wh.gov\/XFxX54",
      "display_url" : "go.wh.gov\/XFxX54"
    } ]
  },
  "geo" : { },
  "id_str" : "469643723761287168",
  "text" : "President Obama talks tourism at the Baseball Hall of Fame: http:\/\/t.co\/1TO0mIdsYv #InvestInAmerica http:\/\/t.co\/hi3BqhyAoM",
  "id" : 469643723761287168,
  "created_at" : "2014-05-23 00:59:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 3, 17 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheScienceGuy\/status\/469604185562836992\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/lYOZf2IePC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoRehJHCIAAGEPd.jpg",
      "id_str" : "469604184627486720",
      "id" : 469604184627486720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoRehJHCIAAGEPd.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lYOZf2IePC"
    } ],
    "hashtags" : [ {
      "text" : "TBTsciencefair",
      "indices" : [ 19, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469605346416529408",
  "text" : "RT @TheScienceGuy: #TBTsciencefair to 1994. Worldwide CO2 was 360 ppm back then. Today it\u2019s over 400. http:\/\/t.co\/lYOZf2IePC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheScienceGuy\/status\/469604185562836992\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/lYOZf2IePC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoRehJHCIAAGEPd.jpg",
        "id_str" : "469604184627486720",
        "id" : 469604184627486720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoRehJHCIAAGEPd.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1529,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lYOZf2IePC"
      } ],
      "hashtags" : [ {
        "text" : "TBTsciencefair",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469604185562836992",
    "text" : "#TBTsciencefair to 1994. Worldwide CO2 was 360 ppm back then. Today it\u2019s over 400. http:\/\/t.co\/lYOZf2IePC",
    "id" : 469604185562836992,
    "created_at" : "2014-05-22 22:22:17 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 469605346416529408,
  "created_at" : "2014-05-22 22:26:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/469602279784329218\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/twklIWHeEa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoRcyOjCcAAUVM-.jpg",
      "id_str" : "469602279121645568",
      "id" : 469602279121645568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoRcyOjCcAAUVM-.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/twklIWHeEa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469602279784329218",
  "text" : "\"Baseball describes our history in so many ways. We\u2019re reminded of all the obstacles that we\u2019ve overcome.\" \u2014Obama http:\/\/t.co\/twklIWHeEa",
  "id" : 469602279784329218,
  "created_at" : "2014-05-22 22:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeVar Burton",
      "screen_name" : "levarburton",
      "indices" : [ 3, 15 ],
      "id_str" : "18396070",
      "id" : 18396070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbtsciencefair",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/XZgSbhIn2X",
      "expanded_url" : "https:\/\/vine.co\/v\/bP7JIZtYxrK",
      "display_url" : "vine.co\/v\/bP7JIZtYxrK"
    } ]
  },
  "geo" : { },
  "id_str" : "469595461700308992",
  "text" : "RT @levarburton: #tbtsciencefair https:\/\/t.co\/XZgSbhIn2X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tbtsciencefair",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/XZgSbhIn2X",
        "expanded_url" : "https:\/\/vine.co\/v\/bP7JIZtYxrK",
        "display_url" : "vine.co\/v\/bP7JIZtYxrK"
      } ]
    },
    "geo" : { },
    "id_str" : "469560339831742464",
    "text" : "#tbtsciencefair https:\/\/t.co\/XZgSbhIn2X",
    "id" : 469560339831742464,
    "created_at" : "2014-05-22 19:28:03 +0000",
    "user" : {
      "name" : "LeVar Burton",
      "screen_name" : "levarburton",
      "protected" : false,
      "id_str" : "18396070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796350503001137152\/XFySV_Qz_normal.jpg",
      "id" : 18396070,
      "verified" : true
    }
  },
  "id" : 469595461700308992,
  "created_at" : "2014-05-22 21:47:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469568205120606209",
  "text" : "\"Nothing says '#MadeInAmerica' like the Empire State Building or the Hoover Dam.\" \u2014Obama on how increased tourism is boosting our economy",
  "id" : 469568205120606209,
  "created_at" : "2014-05-22 19:59:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 121, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469568005522079744",
  "text" : "Obama: \"Last year alone, travel and tourism were responsible for $1.5 trillion in economic activity across the country.\" #InvestInAmerica",
  "id" : 469568005522079744,
  "created_at" : "2014-05-22 19:58:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/469567581243060225\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/C71PrMcfQD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoQ9Of5CEAEM5Gl.jpg",
      "id_str" : "469567580441546753",
      "id" : 469567580441546753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoQ9Of5CEAEM5Gl.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C71PrMcfQD"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469567581243060225",
  "text" : "\"We should be making sure that people are rewarded for hard work with higher wages.\" \u2014Obama #RaiseTheWage http:\/\/t.co\/C71PrMcfQD",
  "id" : 469567581243060225,
  "created_at" : "2014-05-22 19:56:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 117, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469567228317560835",
  "text" : "\"More companies are choosing to create jobs and invest right here in the United States of America.\" \u2014President Obama #InvestInAmerica",
  "id" : 469567228317560835,
  "created_at" : "2014-05-22 19:55:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/469566957571043329\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/J3Jg3y9H1O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoQ8qNrCQAEVCU6.jpg",
      "id_str" : "469566957075709953",
      "id" : 469566957075709953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoQ8qNrCQAEVCU6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/J3Jg3y9H1O"
    } ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 94, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469566957571043329",
  "text" : "\"In just over four years, our businesses have created 9.2 million new jobs.\" \u2014President Obama #InvestInAmerica http:\/\/t.co\/J3Jg3y9H1O",
  "id" : 469566957571043329,
  "created_at" : "2014-05-22 19:54:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 109, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469566293608505344",
  "text" : "\"It is a great honor to be the first sitting president to visit the Baseball Hall of Fame.\" \u2014President Obama #InvestInAmerica",
  "id" : 469566293608505344,
  "created_at" : "2014-05-22 19:51:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ql620EuaRk",
      "expanded_url" : "http:\/\/go.wh.gov\/DXcXt6",
      "display_url" : "go.wh.gov\/DXcXt6"
    } ]
  },
  "geo" : { },
  "id_str" : "469566151220264960",
  "text" : "Happening now: Watch President Obama speak at the Baseball Hall of Fame on how tourism is boosting our economy \u2192 http:\/\/t.co\/ql620EuaRk",
  "id" : 469566151220264960,
  "created_at" : "2014-05-22 19:51:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ql620EuaRk",
      "expanded_url" : "http:\/\/go.wh.gov\/DXcXt6",
      "display_url" : "go.wh.gov\/DXcXt6"
    } ]
  },
  "geo" : { },
  "id_str" : "469558880016805888",
  "text" : "At 3:30pm ET, President Obama speaks at the Baseball Hall of Fame on how tourism is boosting our economy \u2192 http:\/\/t.co\/ql620EuaRk",
  "id" : 469558880016805888,
  "created_at" : "2014-05-22 19:22:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/469538169835511808\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/70ULrMrGwP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoQieiRCYAAJ_Eo.jpg",
      "id_str" : "469538169143058432",
      "id" : 469538169143058432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoQieiRCYAAJ_Eo.jpg",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/70ULrMrGwP"
    } ],
    "hashtags" : [ {
      "text" : "TBTScienceFair",
      "indices" : [ 83, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/D3kCOiFbXB",
      "expanded_url" : "http:\/\/go.wh.gov\/QYv8HC",
      "display_url" : "go.wh.gov\/QYv8HC"
    } ]
  },
  "geo" : { },
  "id_str" : "469538169835511808",
  "text" : "That time President Obama filtered water by riding a bike \u2192 http:\/\/t.co\/D3kCOiFbXB #TBTScienceFair http:\/\/t.co\/70ULrMrGwP",
  "id" : 469538169835511808,
  "created_at" : "2014-05-22 17:59:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBTScienceFair",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469524722611261440",
  "text" : "RT @whitehouseostp: In \u201898, OSTP Senior Advisor for Space &amp; Innovation Phil Larson launched a rocket, rocked a bowl cut. #TBTScienceFair ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/469521277414559744\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/i5GCRJzg0D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoQTHM7IYAE3nXG.jpg",
        "id_str" : "469521275602624513",
        "id" : 469521275602624513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoQTHM7IYAE3nXG.jpg",
        "sizes" : [ {
          "h" : 501,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 652
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/i5GCRJzg0D"
      } ],
      "hashtags" : [ {
        "text" : "TBTScienceFair",
        "indices" : [ 105, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469521277414559744",
    "text" : "In \u201898, OSTP Senior Advisor for Space &amp; Innovation Phil Larson launched a rocket, rocked a bowl cut. #TBTScienceFair http:\/\/t.co\/i5GCRJzg0D",
    "id" : 469521277414559744,
    "created_at" : "2014-05-22 16:52:50 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 469524722611261440,
  "created_at" : "2014-05-22 17:06:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/469515629616447488\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/2xk3Qqhymx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoQN-iKCQAAS2Dw.jpg",
      "id_str" : "469515629125320704",
      "id" : 469515629125320704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoQN-iKCQAAS2Dw.jpg",
      "sizes" : [ {
        "h" : 551,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 551,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/2xk3Qqhymx"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 42, 56 ]
    }, {
      "text" : "TBTScienceFair",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/D3kCOiFbXB",
      "expanded_url" : "http:\/\/go.wh.gov\/QYv8HC",
      "display_url" : "go.wh.gov\/QYv8HC"
    } ]
  },
  "geo" : { },
  "id_str" : "469515629616447488",
  "text" : "3-D printed robotic arms? The kids at the #WHScienceFair know their stuff \u2192 http:\/\/t.co\/D3kCOiFbXB #TBTScienceFair http:\/\/t.co\/2xk3Qqhymx",
  "id" : 469515629616447488,
  "created_at" : "2014-05-22 16:30:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Alex44\/status\/469491167017844736\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/e1Ctda0ZkH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoP3uoWIQAA37kg.jpg",
      "id_str" : "469491166652940288",
      "id" : 469491166652940288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoP3uoWIQAA37kg.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/e1Ctda0ZkH"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 29, 43 ]
    }, {
      "text" : "TBTScienceFair",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/i7uyAAk22t",
      "expanded_url" : "http:\/\/go.wh.gov\/QYv8HC",
      "display_url" : "go.wh.gov\/QYv8HC"
    } ]
  },
  "geo" : { },
  "id_str" : "469509483270782976",
  "text" : "RT @usedgov: Excited for the #WHScienceFair? You should be. It's a blast \u2192 http:\/\/t.co\/i7uyAAk22t #TBTScienceFair http:\/\/t.co\/e1Ctda0ZkH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Alex44\/status\/469491167017844736\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/e1Ctda0ZkH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoP3uoWIQAA37kg.jpg",
        "id_str" : "469491166652940288",
        "id" : 469491166652940288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoP3uoWIQAA37kg.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/e1Ctda0ZkH"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 16, 30 ]
      }, {
        "text" : "TBTScienceFair",
        "indices" : [ 85, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/i7uyAAk22t",
        "expanded_url" : "http:\/\/go.wh.gov\/QYv8HC",
        "display_url" : "go.wh.gov\/QYv8HC"
      } ]
    },
    "geo" : { },
    "id_str" : "469507361468858369",
    "text" : "Excited for the #WHScienceFair? You should be. It's a blast \u2192 http:\/\/t.co\/i7uyAAk22t #TBTScienceFair http:\/\/t.co\/e1Ctda0ZkH",
    "id" : 469507361468858369,
    "created_at" : "2014-05-22 15:57:32 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 469509483270782976,
  "created_at" : "2014-05-22 16:05:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 104, 113 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/w5dV9vRptz",
      "expanded_url" : "http:\/\/youtu.be\/gZR1CvSQntE",
      "display_url" : "youtu.be\/gZR1CvSQntE"
    } ]
  },
  "geo" : { },
  "id_str" : "469498045496049666",
  "text" : "\"The bear is loose!\" President Obama surprises people on the street as he walks from the White House to @Interior \u2192 http:\/\/t.co\/w5dV9vRptz",
  "id" : 469498045496049666,
  "created_at" : "2014-05-22 15:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/469490779267010560\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/kwgKV5KLbb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoP3YDdIYAET0oP.jpg",
      "id_str" : "469490778793074689",
      "id" : 469490778793074689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoP3YDdIYAET0oP.jpg",
      "sizes" : [ {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 561,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/kwgKV5KLbb"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 26, 40 ]
    }, {
      "text" : "TBTScienceFair",
      "indices" : [ 86, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469490779267010560",
  "text" : "Get ready for next week's #WHScienceFair: Share a photo of your science project using #TBTScienceFair. http:\/\/t.co\/kwgKV5KLbb",
  "id" : 469490779267010560,
  "created_at" : "2014-05-22 14:51:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/469317062767435776\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/qpzha4QK81",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoNZYZ4IYAEJxsm.jpg",
      "id_str" : "469317061974712321",
      "id" : 469317061974712321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoNZYZ4IYAEJxsm.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qpzha4QK81"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469320655796973568",
  "text" : "RT @FLOTUS: LOOK! http:\/\/t.co\/qpzha4QK81",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/469317062767435776\/photo\/1",
        "indices" : [ 6, 28 ],
        "url" : "http:\/\/t.co\/qpzha4QK81",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoNZYZ4IYAEJxsm.jpg",
        "id_str" : "469317061974712321",
        "id" : 469317061974712321,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoNZYZ4IYAEJxsm.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/qpzha4QK81"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469317062767435776",
    "text" : "LOOK! http:\/\/t.co\/qpzha4QK81",
    "id" : 469317062767435776,
    "created_at" : "2014-05-22 03:21:21 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 469320655796973568,
  "created_at" : "2014-05-22 03:35:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/469229814927589377\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/vf4jnRDwAX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoMKB61IQAAQd2M.jpg",
      "id_str" : "469229814264905728",
      "id" : 469229814264905728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoMKB61IQAAQd2M.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/vf4jnRDwAX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469229814927589377",
  "text" : "Great news: President Obama just designated Organ Mountains-Desert Peaks National Monument\u2014protecting 500,000 acres. http:\/\/t.co\/vf4jnRDwAX",
  "id" : 469229814927589377,
  "created_at" : "2014-05-21 21:34:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Phillips",
      "screen_name" : "MatthewPhillips",
      "indices" : [ 3, 19 ],
      "id_str" : "77304134",
      "id" : 77304134
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MatthewPhillips\/status\/469221565146877954\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/pUjfi47HSa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoMChrbIIAAyWBB.png",
      "id_str" : "469221563792105472",
      "id" : 469221563792105472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoMChrbIIAAyWBB.png",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 676,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/pUjfi47HSa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469227221086138369",
  "text" : "RT @MatthewPhillips: Obamacare already working? Check the sharp decline in US health care inflation ... http:\/\/t.co\/pUjfi47HSa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MatthewPhillips\/status\/469221565146877954\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/pUjfi47HSa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoMChrbIIAAyWBB.png",
        "id_str" : "469221563792105472",
        "id" : 469221563792105472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoMChrbIIAAyWBB.png",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/pUjfi47HSa"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469221565146877954",
    "text" : "Obamacare already working? Check the sharp decline in US health care inflation ... http:\/\/t.co\/pUjfi47HSa",
    "id" : 469221565146877954,
    "created_at" : "2014-05-21 21:01:53 +0000",
    "user" : {
      "name" : "Matt Phillips",
      "screen_name" : "MatthewPhillips",
      "protected" : false,
      "id_str" : "77304134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497818611973513216\/_OlgrdyG_normal.jpeg",
      "id" : 77304134,
      "verified" : true
    }
  },
  "id" : 469227221086138369,
  "created_at" : "2014-05-21 21:24:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469214621388513280",
  "text" : "RT @WHLive: \"Congress is sitting on dozens of bills that would help protect our precious land and wildlife.\" \u2014President Obama #MonumentsMat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MonumentsMatter",
        "indices" : [ 114, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469214573883822080",
    "text" : "\"Congress is sitting on dozens of bills that would help protect our precious land and wildlife.\" \u2014President Obama #MonumentsMatter",
    "id" : 469214573883822080,
    "created_at" : "2014-05-21 20:34:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 469214621388513280,
  "created_at" : "2014-05-21 20:34:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MonumentsMatter",
      "indices" : [ 123, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469214320837279744",
  "text" : "\"I\u2019ve preserved more than 3 million acres of public lands for future generations, and I am not finished.\" \u2014President Obama #MonumentsMatter",
  "id" : 469214320837279744,
  "created_at" : "2014-05-21 20:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MonumentsMatter",
      "indices" : [ 127, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469214060618473472",
  "text" : "\"Outdoor recreation at parks &amp; forests and other public lands brings in tourism dollars\u2014attracting new businesses.\" \u2014Obama #MonumentsMatter",
  "id" : 469214060618473472,
  "created_at" : "2014-05-21 20:32:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/469213293199228928\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/WWgCnweXIZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoL7ANeIAAAnINx.jpg",
      "id_str" : "469213292234539008",
      "id" : 469213292234539008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoL7ANeIAAAnINx.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/WWgCnweXIZ"
    } ],
    "hashtags" : [ {
      "text" : "MonumentsMatter",
      "indices" : [ 99, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469213293199228928",
  "text" : "\"I am...designating the Organ Mountains-Desert Peaks region a National Monument.\" \u2014President Obama #MonumentsMatter http:\/\/t.co\/WWgCnweXIZ",
  "id" : 469213293199228928,
  "created_at" : "2014-05-21 20:29:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/469213112370212864\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/CM7SmvRBoq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoL61rfIMAAPXSH.jpg",
      "id_str" : "469213111313248256",
      "id" : 469213111313248256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoL61rfIMAAPXSH.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 3000
      } ],
      "display_url" : "pic.twitter.com\/CM7SmvRBoq"
    } ],
    "hashtags" : [ {
      "text" : "MonumentsMatter",
      "indices" : [ 96, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469213112370212864",
  "text" : "\"As Americans, we are blessed with some of the world\u2019s most beautiful places.\" \u2014President Obama #MonumentsMatter http:\/\/t.co\/CM7SmvRBoq",
  "id" : 469213112370212864,
  "created_at" : "2014-05-21 20:28:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MonumentsMatter",
      "indices" : [ 111, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "469212780088672256",
  "text" : "Watch live: President Obama designates Organ Mountains-Desert Peaks National Monument \u2192 http:\/\/t.co\/7QUc084BX3 #MonumentsMatter",
  "id" : 469212780088672256,
  "created_at" : "2014-05-21 20:26:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/469204757333442560\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ojRrd7S0bV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoLzPWuIYAAT_sg.jpg",
      "id_str" : "469204756322607104",
      "id" : 469204756322607104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoLzPWuIYAAT_sg.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ojRrd7S0bV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/FuOfZYyfwo",
      "expanded_url" : "http:\/\/go.wh.gov\/RrJPKE",
      "display_url" : "go.wh.gov\/RrJPKE"
    } ]
  },
  "geo" : { },
  "id_str" : "469204757333442560",
  "text" : "At 4:10pm ET, President Obama will designate Organ Mountains-Desert Peaks National Monument \u2192 http:\/\/t.co\/FuOfZYyfwo http:\/\/t.co\/ojRrd7S0bV",
  "id" : 469204757333442560,
  "created_at" : "2014-05-21 19:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seattle Seahawks",
      "screen_name" : "Seahawks",
      "indices" : [ 62, 71 ],
      "id_str" : "23642374",
      "id" : 23642374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469181321865351168",
  "text" : "\"Let\u2019s give it up for this quiet, reserved bunch: the Seattle @Seahawks. World champions!\" \u2014President Obama",
  "id" : 469181321865351168,
  "created_at" : "2014-05-21 18:21:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seattle Seahawks",
      "screen_name" : "Seahawks",
      "indices" : [ 70, 79 ],
      "id_str" : "23642374",
      "id" : 23642374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/S0KMudgkgt",
      "expanded_url" : "http:\/\/go.wh.gov\/J5QiMw",
      "display_url" : "go.wh.gov\/J5QiMw"
    } ]
  },
  "geo" : { },
  "id_str" : "469180104342790145",
  "text" : "Happening now: President Obama honors the Super Bowl Champion Seattle @Seahawks at the White House \u2192 http:\/\/t.co\/S0KMudgkgt",
  "id" : 469180104342790145,
  "created_at" : "2014-05-21 18:17:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469132633247850497",
  "text" : "\"I\u2019m going to keep on fighting to deliver the care &amp; the benefits &amp; opportunities that you &amp; your families deserve.\" \u2014Obama to our veterans",
  "id" : 469132633247850497,
  "created_at" : "2014-05-21 15:08:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469130965613158400",
  "text" : "RT @WHLive: \"Anyone found to have manipulated or falsified records at VA facilities has to be held accountable.\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "469130784368889856",
    "text" : "\"Anyone found to have manipulated or falsified records at VA facilities has to be held accountable.\" \u2014President Obama",
    "id" : 469130784368889856,
    "created_at" : "2014-05-21 15:01:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 469130965613158400,
  "created_at" : "2014-05-21 15:01:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469130695030628353",
  "text" : "\"If these allegations prove to be true, it is dishonorable, it is disgraceful, and I will not tolerate it.\" \u2014Obama on alleged VA misconduct",
  "id" : 469130695030628353,
  "created_at" : "2014-05-21 15:00:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "469130251470397440",
  "text" : "\"As Commander in Chief, I have the honor of standing with our men and women in uniform at every step of their service.\" \u2014President Obama",
  "id" : 469130251470397440,
  "created_at" : "2014-05-21 14:59:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "469130103419863040",
  "text" : "Happening now: Watch President Obama deliver a statement from the White House Briefing Room \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 469130103419863040,
  "created_at" : "2014-05-21 14:58:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "469120432285962240",
  "text" : "At 10:45am ET, President Obama delivers a statement from the White House Briefing Room. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 469120432285962240,
  "created_at" : "2014-05-21 14:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/468899197094473729\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/AX9fhyaqbt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoHdVcBIEAEegFV.jpg",
      "id_str" : "468899196591149057",
      "id" : 468899196591149057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoHdVcBIEAEegFV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/AX9fhyaqbt"
    } ],
    "hashtags" : [ {
      "text" : "MarriageEquality",
      "indices" : [ 78, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468899197094473729",
  "text" : "RT if you agree: Every American should be able to marry the person they love. #MarriageEquality http:\/\/t.co\/AX9fhyaqbt",
  "id" : 468899197094473729,
  "created_at" : "2014-05-20 23:40:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 122, 130 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468874321570840577",
  "text" : "RT @vj44: \"Flexibility needs to be ingrained in the employer\u2019s culture &amp; seen as available to workers of all stripes\u201D @nytimes http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 112, 120 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/lNZLMNjKxC",
        "expanded_url" : "http:\/\/nyti.ms\/1p8uVWb",
        "display_url" : "nyti.ms\/1p8uVWb"
      } ]
    },
    "geo" : { },
    "id_str" : "468870847793725440",
    "text" : "\"Flexibility needs to be ingrained in the employer\u2019s culture &amp; seen as available to workers of all stripes\u201D @nytimes http:\/\/t.co\/lNZLMNjKxC",
    "id" : 468870847793725440,
    "created_at" : "2014-05-20 21:48:15 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 468874321570840577,
  "created_at" : "2014-05-20 22:02:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Romania",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468863366866681856",
  "text" : "RT @VP: \"To the Americans here today, let me say..you are the greatest generation of warriors\" -VP to U.S. troops in #Romania http:\/\/t.co\/j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/468840615422464000\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/jrQFO3aAhD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoGoDP8CIAAi2tA.png",
        "id_str" : "468840609994645504",
        "id" : 468840609994645504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoGoDP8CIAAi2tA.png",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jrQFO3aAhD"
      } ],
      "hashtags" : [ {
        "text" : "Romania",
        "indices" : [ 109, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "468840615422464000",
    "text" : "\"To the Americans here today, let me say..you are the greatest generation of warriors\" -VP to U.S. troops in #Romania http:\/\/t.co\/jrQFO3aAhD",
    "id" : 468840615422464000,
    "created_at" : "2014-05-20 19:48:08 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 468863366866681856,
  "created_at" : "2014-05-20 21:18:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "indices" : [ 3, 17 ],
      "id_str" : "308573576",
      "id" : 308573576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestinAmerica",
      "indices" : [ 77, 93 ]
    }, {
      "text" : "jobs",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468860057447587842",
  "text" : "RT @PennyPritzker: America is Open for Business. Learn why 13 firms chose to #InvestinAmerica &amp; create #jobs in the US http:\/\/t.co\/FkVgEc9g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InvestinAmerica",
        "indices" : [ 58, 74 ]
      }, {
        "text" : "jobs",
        "indices" : [ 88, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/FkVgEc9ggP",
        "expanded_url" : "http:\/\/1.usa.gov\/1ncg5kz",
        "display_url" : "1.usa.gov\/1ncg5kz"
      } ]
    },
    "geo" : { },
    "id_str" : "468813362605072385",
    "text" : "America is Open for Business. Learn why 13 firms chose to #InvestinAmerica &amp; create #jobs in the US http:\/\/t.co\/FkVgEc9ggP",
    "id" : 468813362605072385,
    "created_at" : "2014-05-20 17:59:50 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 468860057447587842,
  "created_at" : "2014-05-20 21:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viagra n tayac. Dagr",
      "screen_name" : "DagVega44",
      "indices" : [ 3, 13 ],
      "id_str" : "2785789802",
      "id" : 2785789802
    }, {
      "name" : "Lufthansa",
      "screen_name" : "lufthansa",
      "indices" : [ 22, 32 ],
      "id_str" : "124476322",
      "id" : 124476322
    }, {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "indices" : [ 44, 54 ],
      "id_str" : "1099296103",
      "id" : 1099296103
    }, {
      "name" : "Bloomberg TV",
      "screen_name" : "BloombergTV",
      "indices" : [ 117, 129 ],
      "id_str" : "35002876",
      "id" : 35002876
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 71, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/NtrG2EBwSi",
      "expanded_url" : "http:\/\/bloom.bg\/1gj33OZ",
      "display_url" : "bloom.bg\/1gj33OZ"
    } ]
  },
  "geo" : { },
  "id_str" : "468853407886090243",
  "text" : "RT @DagVega44: Video: @Lufthansa CEO on how @SelectUSA has helped them #InvestInAmerica \u2192 http:\/\/t.co\/NtrG2EBwSi via @BloombergTV http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lufthansa",
        "screen_name" : "lufthansa",
        "indices" : [ 7, 17 ],
        "id_str" : "124476322",
        "id" : 124476322
      }, {
        "name" : "SelectUSA",
        "screen_name" : "SelectUSA",
        "indices" : [ 29, 39 ],
        "id_str" : "1099296103",
        "id" : 1099296103
      }, {
        "name" : "Bloomberg TV",
        "screen_name" : "BloombergTV",
        "indices" : [ 102, 114 ],
        "id_str" : "35002876",
        "id" : 35002876
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DagVega44\/status\/468821620430487553\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/i81V9inrSV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoGWx5zIYAA3eLx.jpg",
        "id_str" : "468821620296278016",
        "id" : 468821620296278016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoGWx5zIYAA3eLx.jpg",
        "sizes" : [ {
          "h" : 444,
          "resize" : "fit",
          "w" : 712
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 712
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/i81V9inrSV"
      } ],
      "hashtags" : [ {
        "text" : "InvestInAmerica",
        "indices" : [ 56, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/NtrG2EBwSi",
        "expanded_url" : "http:\/\/bloom.bg\/1gj33OZ",
        "display_url" : "bloom.bg\/1gj33OZ"
      } ]
    },
    "geo" : { },
    "id_str" : "468821620430487553",
    "text" : "Video: @Lufthansa CEO on how @SelectUSA has helped them #InvestInAmerica \u2192 http:\/\/t.co\/NtrG2EBwSi via @BloombergTV http:\/\/t.co\/i81V9inrSV",
    "id" : 468821620430487553,
    "created_at" : "2014-05-20 18:32:39 +0000",
    "user" : {
      "name" : "Rob O'Donnell",
      "screen_name" : "RODonnell44",
      "protected" : false,
      "id_str" : "1873091689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664483086738952192\/UukL2zFT_normal.jpg",
      "id" : 1873091689,
      "verified" : true
    }
  },
  "id" : 468853407886090243,
  "created_at" : "2014-05-20 20:38:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 123, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468832529345437696",
  "text" : "In 2013, the share of U.S. execs actively considering bringing production back from China rose to 54%\u2014up from 37% in 2012. #InvestInAmerica",
  "id" : 468832529345437696,
  "created_at" : "2014-05-20 19:16:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 100, 111 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/LOPmvlKPOo",
      "expanded_url" : "http:\/\/huff.to\/1lI51pS",
      "display_url" : "huff.to\/1lI51pS"
    } ]
  },
  "geo" : { },
  "id_str" : "468826074651312128",
  "text" : "Worth a read: \"How to govern when Congress would rather repeal and re-investigate than legislate.\" \u2014@Pfeiffer44: http:\/\/t.co\/LOPmvlKPOo",
  "id" : 468826074651312128,
  "created_at" : "2014-05-20 18:50:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/468818607624159232\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/6CUtX9THGI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoGUChCIgAENwT2.jpg",
      "id_str" : "468818607171207169",
      "id" : 468818607171207169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoGUChCIgAENwT2.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6CUtX9THGI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468818607624159232",
  "text" : "Pre-game pep talk. http:\/\/t.co\/6CUtX9THGI",
  "id" : 468818607624159232,
  "created_at" : "2014-05-20 18:20:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 23, 26 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Lubin44\/status\/468799288727056384\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/SeZJ3iLmcZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoGCeAMIAAA0yaT.jpg",
      "id_str" : "468799288181784576",
      "id" : 468799288181784576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoGCeAMIAAA0yaT.jpg",
      "sizes" : [ {
        "h" : 651,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 651,
        "resize" : "fit",
        "w" : 976
      } ],
      "display_url" : "pic.twitter.com\/SeZJ3iLmcZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/6ayiyq2Ts5",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/being-biden",
      "display_url" : "whitehouse.gov\/being-biden"
    } ]
  },
  "geo" : { },
  "id_str" : "468802697609506816",
  "text" : "RT @Lubin44: Why's the @VP pouring coffee? He's got a good reason: http:\/\/t.co\/6ayiyq2Ts5 http:\/\/t.co\/SeZJ3iLmcZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 10, 13 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Lubin44\/status\/468799288727056384\/photo\/1",
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/SeZJ3iLmcZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoGCeAMIAAA0yaT.jpg",
        "id_str" : "468799288181784576",
        "id" : 468799288181784576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoGCeAMIAAA0yaT.jpg",
        "sizes" : [ {
          "h" : 651,
          "resize" : "fit",
          "w" : 976
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 976
        } ],
        "display_url" : "pic.twitter.com\/SeZJ3iLmcZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/6ayiyq2Ts5",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/being-biden",
        "display_url" : "whitehouse.gov\/being-biden"
      } ]
    },
    "geo" : { },
    "id_str" : "468799288727056384",
    "text" : "Why's the @VP pouring coffee? He's got a good reason: http:\/\/t.co\/6ayiyq2Ts5 http:\/\/t.co\/SeZJ3iLmcZ",
    "id" : 468799288727056384,
    "created_at" : "2014-05-20 17:03:54 +0000",
    "user" : {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "protected" : false,
      "id_str" : "1563426390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615987325261082625\/QxtC65p2_normal.jpg",
      "id" : 1563426390,
      "verified" : true
    }
  },
  "id" : 468802697609506816,
  "created_at" : "2014-05-20 17:17:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 121, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468793479238135808",
  "text" : "FACT: U.S. manufacturers have added 647,000 new jobs since Feb of 2010\u2014their fastest rate of job growth since the 1990s. #InvestInAmerica",
  "id" : 468793479238135808,
  "created_at" : "2014-05-20 16:40:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/468780908670377984\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Tq7Pr1OInf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoFxwJJIcAAvPeQ.jpg",
      "id_str" : "468780908125122560",
      "id" : 468780908125122560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoFxwJJIcAAvPeQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Tq7Pr1OInf"
    } ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 86, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468780908670377984",
  "text" : "FACT: Our businesses have created more than 9.2 million jobs over the past 50 months. #InvestInAmerica http:\/\/t.co\/Tq7Pr1OInf",
  "id" : 468780908670377984,
  "created_at" : "2014-05-20 15:50:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 124, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468767979812184064",
  "text" : "FACT: The President's Select USA initiative has helped secure more than $18 billion in job-creating investments in the U.S. #InvestInAmerica",
  "id" : 468767979812184064,
  "created_at" : "2014-05-20 14:59:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 94, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/t9ey2bwu6B",
      "expanded_url" : "http:\/\/go.wh.gov\/YqvCb4",
      "display_url" : "go.wh.gov\/YqvCb4"
    } ]
  },
  "geo" : { },
  "id_str" : "468761042081030145",
  "text" : "Here's the latest on how President Obama's making it easier for businesses to create jobs and #InvestInAmerica \u2192 http:\/\/t.co\/t9ey2bwu6B",
  "id" : 468761042081030145,
  "created_at" : "2014-05-20 14:31:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "indices" : [ 3, 13 ],
      "id_str" : "1729062162",
      "id" : 1729062162
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 28, 39 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInAmerica",
      "indices" : [ 92, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468742844543664128",
  "text" : "RT @Racusen44: Today at the @WhiteHouse, POTUS meets w\/ CEOs to talk abt admin's efforts to #InvestInAmerica, part of weeklong push: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 13, 24 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InvestInAmerica",
        "indices" : [ 77, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/jmihfC4jdq",
        "expanded_url" : "http:\/\/wapo.st\/1j52LGp",
        "display_url" : "wapo.st\/1j52LGp"
      } ]
    },
    "geo" : { },
    "id_str" : "468733857257521152",
    "text" : "Today at the @WhiteHouse, POTUS meets w\/ CEOs to talk abt admin's efforts to #InvestInAmerica, part of weeklong push: http:\/\/t.co\/jmihfC4jdq",
    "id" : 468733857257521152,
    "created_at" : "2014-05-20 12:43:54 +0000",
    "user" : {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "protected" : false,
      "id_str" : "1729062162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411689100\/e84b5f12ff73878aa785c296671e9ef8_normal.png",
      "id" : 1729062162,
      "verified" : true
    }
  },
  "id" : 468742844543664128,
  "created_at" : "2014-05-20 13:19:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 34, 42 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 44, 56 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "grist",
      "screen_name" : "grist",
      "indices" : [ 63, 69 ],
      "id_str" : "7215512",
      "id" : 7215512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHClimateChat",
      "indices" : [ 14, 28 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/tdm4UWXw1T",
      "expanded_url" : "http:\/\/youtu.be\/vNl4J3IkEzc",
      "display_url" : "youtu.be\/vNl4J3IkEzc"
    } ]
  },
  "geo" : { },
  "id_str" : "468535554108571648",
  "text" : "Watch today's #WHClimateChat with @GinaEPA, @ErnestMoniz &amp; @Grist on what President Obama's doing to #ActOnClimate \u2192 http:\/\/t.co\/tdm4UWXw1T",
  "id" : 468535554108571648,
  "created_at" : "2014-05-19 23:35:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468523053677568000",
  "text" : "RT @VP: Meet Police Officer Peter Laboy - or as his doctor calls him, \u201CSuperman\u201D - in the latest installment of Being Biden \u2192 http:\/\/t.co\/s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/sE5mZ727Yz",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/being-biden",
        "display_url" : "whitehouse.gov\/being-biden"
      } ]
    },
    "geo" : { },
    "id_str" : "468508730267803648",
    "text" : "Meet Police Officer Peter Laboy - or as his doctor calls him, \u201CSuperman\u201D - in the latest installment of Being Biden \u2192 http:\/\/t.co\/sE5mZ727Yz",
    "id" : 468508730267803648,
    "created_at" : "2014-05-19 21:49:20 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 468523053677568000,
  "created_at" : "2014-05-19 22:46:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Schultz44\/status\/468509512953901057\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/JEZIYo2sPM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoB662jCcAA9o1M.jpg",
      "id_str" : "468509512740007936",
      "id" : 468509512740007936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoB662jCcAA9o1M.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JEZIYo2sPM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468516228789575680",
  "text" : "RT @Schultz44: POTUS plays catch with Little League team at afternoon drop-by http:\/\/t.co\/JEZIYo2sPM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Schultz44\/status\/468509512953901057\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/JEZIYo2sPM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoB662jCcAA9o1M.jpg",
        "id_str" : "468509512740007936",
        "id" : 468509512740007936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoB662jCcAA9o1M.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JEZIYo2sPM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "468509512953901057",
    "text" : "POTUS plays catch with Little League team at afternoon drop-by http:\/\/t.co\/JEZIYo2sPM",
    "id" : 468509512953901057,
    "created_at" : "2014-05-19 21:52:27 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 468516228789575680,
  "created_at" : "2014-05-19 22:19:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Baker",
      "screen_name" : "MassGovernor",
      "indices" : [ 3, 16 ],
      "id_str" : "18023868",
      "id" : 18023868
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkingFamilies",
      "indices" : [ 50, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468499307185078272",
  "text" : "RT @MassGovernor: Proud that @whitehouse Forum on #WorkingFamilies &amp; @CEABetsey is in MA today, strengthening opportunities for working wom\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 11, 22 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorkingFamilies",
        "indices" : [ 32, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "468421964919754752",
    "text" : "Proud that @whitehouse Forum on #WorkingFamilies &amp; @CEABetsey is in MA today, strengthening opportunities for working women &amp; families.",
    "id" : 468421964919754752,
    "created_at" : "2014-05-19 16:04:33 +0000",
    "user" : {
      "name" : "Charlie Baker",
      "screen_name" : "MassGovernor",
      "protected" : false,
      "id_str" : "18023868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588540751430033408\/5rOCtVsL_normal.jpg",
      "id" : 18023868,
      "verified" : true
    }
  },
  "id" : 468499307185078272,
  "created_at" : "2014-05-19 21:11:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/ILl3L1WwRr",
      "expanded_url" : "http:\/\/go.wh.gov\/6v9n7N",
      "display_url" : "go.wh.gov\/6v9n7N"
    } ]
  },
  "geo" : { },
  "id_str" : "468492283927883776",
  "text" : "FACT: President Obama's taking steps to save businesses $26 billion in energy costs \u2192 http:\/\/t.co\/ILl3L1WwRr #ActOnClimate",
  "id" : 468492283927883776,
  "created_at" : "2014-05-19 20:43:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 31, 39 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 41, 53 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "grist",
      "screen_name" : "grist",
      "indices" : [ 60, 66 ],
      "id_str" : "7215512",
      "id" : 7215512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHClimateChat",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/dH8NhtiHUr",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=jnBaZltqHbw",
      "display_url" : "youtube.com\/watch?v=jnBaZl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "468440348348678144",
  "text" : "Happening now: G+ Hangout with @GinaEPA, @ErnestMoniz &amp; @Grist on climate change. Ask Q's with #WHClimateChat: https:\/\/t.co\/dH8NhtiHUr",
  "id" : 468440348348678144,
  "created_at" : "2014-05-19 17:17:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    }, {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 16, 24 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 31, 38 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHClimateChat",
      "indices" : [ 59, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/YlprNINzsj",
      "expanded_url" : "http:\/\/go.usa.gov\/84We",
      "display_url" : "go.usa.gov\/84We"
    } ]
  },
  "geo" : { },
  "id_str" : "468426668135415808",
  "text" : "RT @EPA: TODAY: @GinaEPA joins @Energy Secretary Moniz for #WHClimateChat Google+ Hangout at 1:00 pm EDT. http:\/\/t.co\/YlprNINzsj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gina McCarthy",
        "screen_name" : "GinaEPA",
        "indices" : [ 7, 15 ],
        "id_str" : "1530850933",
        "id" : 1530850933
      }, {
        "name" : "Energy Department",
        "screen_name" : "ENERGY",
        "indices" : [ 22, 29 ],
        "id_str" : "166252256",
        "id" : 166252256
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHClimateChat",
        "indices" : [ 50, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/YlprNINzsj",
        "expanded_url" : "http:\/\/go.usa.gov\/84We",
        "display_url" : "go.usa.gov\/84We"
      } ]
    },
    "geo" : { },
    "id_str" : "468397599775805440",
    "text" : "TODAY: @GinaEPA joins @Energy Secretary Moniz for #WHClimateChat Google+ Hangout at 1:00 pm EDT. http:\/\/t.co\/YlprNINzsj",
    "id" : 468397599775805440,
    "created_at" : "2014-05-19 14:27:44 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 468426668135415808,
  "created_at" : "2014-05-19 16:23:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 27, 39 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHClimateChat",
      "indices" : [ 50, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468424277126287360",
  "text" : "RT @GinaEPA: Join me &amp; @ErnestMoniz today for #WHClimateChat to find out what actions we are taking now to safeguard our future http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ernest Moniz",
        "screen_name" : "ErnestMoniz",
        "indices" : [ 14, 26 ],
        "id_str" : "1393155566",
        "id" : 1393155566
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHClimateChat",
        "indices" : [ 37, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/zrtSi3KknH",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/05\/14\/state-our-climate-google-hangout-secretary-moniz-and-administrator-mccarthy",
        "display_url" : "whitehouse.gov\/blog\/2014\/05\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "468402339620339712",
    "text" : "Join me &amp; @ErnestMoniz today for #WHClimateChat to find out what actions we are taking now to safeguard our future http:\/\/t.co\/zrtSi3KknH",
    "id" : 468402339620339712,
    "created_at" : "2014-05-19 14:46:34 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 468424277126287360,
  "created_at" : "2014-05-19 16:13:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/468413245162655744\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/qo0XODf6jg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BoAjXShIAAA1ifR.jpg",
      "id_str" : "468413244261269504",
      "id" : 468413244261269504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoAjXShIAAA1ifR.jpg",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qo0XODf6jg"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 52, 66 ]
    }, {
      "text" : "STEM",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/rvHbQLsEj2",
      "expanded_url" : "http:\/\/go.wh.gov\/hbBFx1",
      "display_url" : "go.wh.gov\/hbBFx1"
    } ]
  },
  "geo" : { },
  "id_str" : "468413245162655744",
  "text" : "Robots, marshmallow cannons &amp; more!\nThis year's #WHScienceFair will feature girls in #STEM \u2192\nhttp:\/\/t.co\/rvHbQLsEj2 http:\/\/t.co\/qo0XODf6jg",
  "id" : 468413245162655744,
  "created_at" : "2014-05-19 15:29:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/YMQCODf41w",
      "expanded_url" : "http:\/\/wh.gov\/lANeS",
      "display_url" : "wh.gov\/lANeS"
    } ]
  },
  "geo" : { },
  "id_str" : "468408014492684289",
  "text" : "RT @whitehouseostp: We're excited to announce the next White House Science Fair &amp; celebrate girls in #STEM! \u2192 http:\/\/t.co\/YMQCODf41w http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/468407505165762560\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/GrqNl75nP5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoAeJIbIMAAi3sz.jpg",
        "id_str" : "468407503475453952",
        "id" : 468407503475453952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoAeJIbIMAAi3sz.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/GrqNl75nP5"
      } ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 85, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/YMQCODf41w",
        "expanded_url" : "http:\/\/wh.gov\/lANeS",
        "display_url" : "wh.gov\/lANeS"
      } ]
    },
    "geo" : { },
    "id_str" : "468407505165762560",
    "text" : "We're excited to announce the next White House Science Fair &amp; celebrate girls in #STEM! \u2192 http:\/\/t.co\/YMQCODf41w http:\/\/t.co\/GrqNl75nP5",
    "id" : 468407505165762560,
    "created_at" : "2014-05-19 15:07:06 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 468408014492684289,
  "created_at" : "2014-05-19 15:09:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 23, 31 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 33, 45 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "grist",
      "screen_name" : "grist",
      "indices" : [ 52, 58 ],
      "id_str" : "7215512",
      "id" : 7215512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHClimateChat",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/zfkmoDOWp1",
      "expanded_url" : "http:\/\/go.wh.gov\/BtzRsx",
      "display_url" : "go.wh.gov\/BtzRsx"
    } ]
  },
  "geo" : { },
  "id_str" : "468403229999775746",
  "text" : "Join a G+ Hangout with @GinaEPA, @ErnestMoniz &amp; @Grist at 1pm ET on climate change. Ask your Q's with #WHClimateChat: http:\/\/t.co\/zfkmoDOWp1",
  "id" : 468403229999775746,
  "created_at" : "2014-05-19 14:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 55, 62 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHClimateChat",
      "indices" : [ 95, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "468394902309834753",
  "text" : "RT @ErnestMoniz: Now's your chance to ask me about how @Energy is fighting climate change. Use #WHClimateChat &amp; watch live at 1PM \u2192 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Energy Department",
        "screen_name" : "ENERGY",
        "indices" : [ 38, 45 ],
        "id_str" : "166252256",
        "id" : 166252256
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHClimateChat",
        "indices" : [ 78, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/WZ762J9xyN",
        "expanded_url" : "http:\/\/go.usa.gov\/8g6B",
        "display_url" : "go.usa.gov\/8g6B"
      } ]
    },
    "geo" : { },
    "id_str" : "468394689318879233",
    "text" : "Now's your chance to ask me about how @Energy is fighting climate change. Use #WHClimateChat &amp; watch live at 1PM \u2192 http:\/\/t.co\/WZ762J9xyN",
    "id" : 468394689318879233,
    "created_at" : "2014-05-19 14:16:10 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 468394902309834753,
  "created_at" : "2014-05-19 14:17:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/kGORX6FfUb",
      "expanded_url" : "http:\/\/go.wh.gov\/t2m9i9",
      "display_url" : "go.wh.gov\/t2m9i9"
    } ]
  },
  "geo" : { },
  "id_str" : "468073602068148225",
  "text" : "\"I announced a new plan to cut red tape and speed up the process for even more projects across the country.\" \u2014Obama: http:\/\/t.co\/kGORX6FfUb",
  "id" : 468073602068148225,
  "created_at" : "2014-05-18 17:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/kGORX6FfUb",
      "expanded_url" : "http:\/\/go.wh.gov\/t2m9i9",
      "display_url" : "go.wh.gov\/t2m9i9"
    } ]
  },
  "geo" : { },
  "id_str" : "468050952126087169",
  "text" : "\"If Congress fails to act, nearly 700,000 jobs would be at risk over the next year\" \u2014Obama on transportation funding: http:\/\/t.co\/kGORX6FfUb",
  "id" : 468050952126087169,
  "created_at" : "2014-05-18 15:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/kGORX6FfUb",
      "expanded_url" : "http:\/\/go.wh.gov\/t2m9i9",
      "display_url" : "go.wh.gov\/t2m9i9"
    } ]
  },
  "geo" : { },
  "id_str" : "468028303954046976",
  "text" : "\"Where Congress won\u2019t act, I will.\" \u2014President Obama on creating jobs and expanding opportunity for more Americans: http:\/\/t.co\/kGORX6FfUb",
  "id" : 468028303954046976,
  "created_at" : "2014-05-18 14:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/kGORX6FfUb",
      "expanded_url" : "http:\/\/go.wh.gov\/t2m9i9",
      "display_url" : "go.wh.gov\/t2m9i9"
    } ]
  },
  "geo" : { },
  "id_str" : "467703655739572225",
  "text" : "\"If Congress doesn\u2019t act by the end of this summer, federal funding for transportation projects will run out\" \u2014Obama: http:\/\/t.co\/kGORX6FfUb",
  "id" : 467703655739572225,
  "created_at" : "2014-05-17 16:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467680605573234688",
  "text" : "60 years after Brown v. Board, let's remember that while progress has never come easily, people who love their country can change it. -bo",
  "id" : 467680605573234688,
  "created_at" : "2014-05-17 14:58:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/5khN1xmbbc",
      "expanded_url" : "http:\/\/go.wh.gov\/t2m9i9",
      "display_url" : "go.wh.gov\/t2m9i9"
    } ]
  },
  "geo" : { },
  "id_str" : "467670521862443008",
  "text" : "\"Investing in first-class infrastructure attracts first-class jobs.\" \u2014Obama in his weekly address: http:\/\/t.co\/5khN1xmbbc #RebuildAmerica",
  "id" : 467670521862443008,
  "created_at" : "2014-05-17 14:18:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SHAKE SHACK",
      "screen_name" : "shakeshack",
      "indices" : [ 58, 69 ],
      "id_str" : "212255045",
      "id" : 212255045
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/467465439237664768\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/egDE1lHmK0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnzFVuOCIAEDl4A.jpg",
      "id_str" : "467465438314504193",
      "id" : 467465438314504193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnzFVuOCIAEDl4A.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      } ],
      "display_url" : "pic.twitter.com\/egDE1lHmK0"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/FiVvEf89Yl",
      "expanded_url" : "http:\/\/youtu.be\/ZGoJDBuVZPo",
      "display_url" : "youtu.be\/ZGoJDBuVZPo"
    } ]
  },
  "geo" : { },
  "id_str" : "467465439237664768",
  "text" : "President Obama \u2714\nBurgers \u2714\nConstruction workers \u2714\nAll at @ShakeShack today \u2192 http:\/\/t.co\/FiVvEf89Yl #RebuildAmerica http:\/\/t.co\/egDE1lHmK0",
  "id" : 467465439237664768,
  "created_at" : "2014-05-17 00:43:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467431898965630976",
  "text" : "RT @VP: As we reflect on the 60th anniversary of Brown v. Board, let us remember what Dr. King said: Change \"comes through continuous strug\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467431284412002304",
    "text" : "As we reflect on the 60th anniversary of Brown v. Board, let us remember what Dr. King said: Change \"comes through continuous struggle.\" -VP",
    "id" : 467431284412002304,
    "created_at" : "2014-05-16 22:27:57 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 467431898965630976,
  "created_at" : "2014-05-16 22:30:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467430531114991616",
  "text" : "RT @FLOTUS: FLOTUS tours a 1950's-style classroom in Topeka, KS ahead of the 60th anniversary of Brown v. Board of Education. http:\/\/t.co\/N\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/467420722172669953\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/N3Hr0YHwPm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bnycq41CUAEXHzX.jpg",
        "id_str" : "467420721962962945",
        "id" : 467420721962962945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bnycq41CUAEXHzX.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/N3Hr0YHwPm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467420722172669953",
    "text" : "FLOTUS tours a 1950's-style classroom in Topeka, KS ahead of the 60th anniversary of Brown v. Board of Education. http:\/\/t.co\/N3Hr0YHwPm",
    "id" : 467420722172669953,
    "created_at" : "2014-05-16 21:45:59 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 467430531114991616,
  "created_at" : "2014-05-16 22:24:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467413977761583104",
  "text" : "\"We recommit ourselves to the long struggle to stamp out bigotry and racism.\" \u2014Obama on the 60th anniversary of Brown v. Board of Education",
  "id" : 467413977761583104,
  "created_at" : "2014-05-16 21:19:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/sCqZPCCTGe",
      "expanded_url" : "http:\/\/go.wh.gov\/ajQwib",
      "display_url" : "go.wh.gov\/ajQwib"
    } ]
  },
  "geo" : { },
  "id_str" : "467397798837886978",
  "text" : "President Obama on the 60th anniversary of Brown v. Board of Education \u2192 http:\/\/t.co\/sCqZPCCTGe",
  "id" : 467397798837886978,
  "created_at" : "2014-05-16 20:14:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "CHANGE THE EQUATION",
      "screen_name" : "changeequation",
      "indices" : [ 103, 118 ],
      "id_str" : "140136223",
      "id" : 140136223
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467359475993944065",
  "text" : "RT @VP: \"Educating our young people is the most critical responsibility we have as a nation.\" -- VP to @changeequation #STEM http:\/\/t.co\/t2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CHANGE THE EQUATION",
        "screen_name" : "changeequation",
        "indices" : [ 95, 110 ],
        "id_str" : "140136223",
        "id" : 140136223
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/467353546955165696\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/t2a6J2necQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnxfkjvCQAATlZW.png",
        "id_str" : "467353543012139008",
        "id" : 467353543012139008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnxfkjvCQAATlZW.png",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/t2a6J2necQ"
      } ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 111, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467353546955165696",
    "text" : "\"Educating our young people is the most critical responsibility we have as a nation.\" -- VP to @changeequation #STEM http:\/\/t.co\/t2a6J2necQ",
    "id" : 467353546955165696,
    "created_at" : "2014-05-16 17:19:03 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 467359475993944065,
  "created_at" : "2014-05-16 17:42:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 47, 55 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 57, 69 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "grist",
      "screen_name" : "grist",
      "indices" : [ 76, 82 ],
      "id_str" : "7215512",
      "id" : 7215512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHClimateChat",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/vFb2Th7wgA",
      "expanded_url" : "http:\/\/go.wh.gov\/4HHmUE",
      "display_url" : "go.wh.gov\/4HHmUE"
    } ]
  },
  "geo" : { },
  "id_str" : "467345840810758144",
  "text" : "Climate change is affecting us right now. Join @GinaEPA, @ErnestMoniz &amp; @Grist for a #WHClimateChat on Mon at 1pm ET: http:\/\/t.co\/vFb2Th7wgA",
  "id" : 467345840810758144,
  "created_at" : "2014-05-16 16:48:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Barbara Walters",
      "screen_name" : "BarbaraJWalters",
      "indices" : [ 24, 40 ],
      "id_str" : "33514869",
      "id" : 33514869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467337091865927680",
  "text" : "RT @FLOTUS: Congrats to @BarbaraJWalters on a truly groundbreaking and inspiring career from the whole Obama family! -mo http:\/\/t.co\/pUG66h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barbara Walters",
        "screen_name" : "BarbaraJWalters",
        "indices" : [ 12, 28 ],
        "id_str" : "33514869",
        "id" : 33514869
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/467333141183479808\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/pUG66hqpID",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnxNA-kCMAAptZo.jpg",
        "id_str" : "467333140529164288",
        "id" : 467333140529164288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnxNA-kCMAAptZo.jpg",
        "sizes" : [ {
          "h" : 669,
          "resize" : "fit",
          "w" : 862
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 466,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 862
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/pUG66hqpID"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467333141183479808",
    "text" : "Congrats to @BarbaraJWalters on a truly groundbreaking and inspiring career from the whole Obama family! -mo http:\/\/t.co\/pUG66hqpID",
    "id" : 467333141183479808,
    "created_at" : "2014-05-16 15:57:58 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 467337091865927680,
  "created_at" : "2014-05-16 16:13:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/USDOL\/status\/467314365482295297\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/y2XBHg6QLc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bnw78DxCcAAA9Zl.png",
      "id_str" : "467314364328865792",
      "id" : 467314364328865792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bnw78DxCcAAA9Zl.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1036,
        "resize" : "fit",
        "w" : 1036
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/y2XBHg6QLc"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 41, 54 ]
    }, {
      "text" : "NNHW",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467319477093543936",
  "text" : "RT @USDOL: RT if you agree: It's time to #RaiseTheWage and take care of those who take care of us. #NNHW http:\/\/t.co\/y2XBHg6QLc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USDOL\/status\/467314365482295297\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/y2XBHg6QLc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bnw78DxCcAAA9Zl.png",
        "id_str" : "467314364328865792",
        "id" : 467314364328865792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bnw78DxCcAAA9Zl.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1036,
          "resize" : "fit",
          "w" : 1036
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/y2XBHg6QLc"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 30, 43 ]
      }, {
        "text" : "NNHW",
        "indices" : [ 88, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467314365482295297",
    "text" : "RT if you agree: It's time to #RaiseTheWage and take care of those who take care of us. #NNHW http:\/\/t.co\/y2XBHg6QLc",
    "id" : 467314365482295297,
    "created_at" : "2014-05-16 14:43:21 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 467319477093543936,
  "created_at" : "2014-05-16 15:03:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/467312477190225920\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/HXzOseQUMs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bnw6OLTIUAAsThe.jpg",
      "id_str" : "467312476565295104",
      "id" : 467312476565295104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bnw6OLTIUAAsThe.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/HXzOseQUMs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467312477190225920",
  "text" : "\"Here we tell their story, so that generations yet unborn will never forget.\" \u2014Obama at the 9\/11 Memorial dedication http:\/\/t.co\/HXzOseQUMs",
  "id" : 467312477190225920,
  "created_at" : "2014-05-16 14:35:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/ENsfoSVNNQ",
      "expanded_url" : "http:\/\/youtu.be\/5ULtHI3zXXk",
      "display_url" : "youtu.be\/5ULtHI3zXXk"
    } ]
  },
  "geo" : { },
  "id_str" : "467081448462508032",
  "text" : "\"Those we lost live on in us.\" \u2014President Obama at the 9\/11 Memorial dedication: http:\/\/t.co\/ENsfoSVNNQ",
  "id" : 467081448462508032,
  "created_at" : "2014-05-15 23:17:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Madeleine Albright",
      "screen_name" : "madeleine",
      "indices" : [ 75, 85 ],
      "id_str" : "1707321486",
      "id" : 1707321486
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JohnKerry\/status\/467046817679413248\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/DCjiLpUHjm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BntImu9IAAAJcGP.jpg",
      "id_str" : "467046816639614976",
      "id" : 467046816639614976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BntImu9IAAAJcGP.jpg",
      "sizes" : [ {
        "h" : 573,
        "resize" : "fit",
        "w" : 798
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 573,
        "resize" : "fit",
        "w" : 798
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DCjiLpUHjm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467075214304886785",
  "text" : "RT @JohnKerry: Happy birthday to my friend &amp; the first Madam Secretary @madeleine Albright! http:\/\/t.co\/DCjiLpUHjm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Madeleine Albright",
        "screen_name" : "madeleine",
        "indices" : [ 60, 70 ],
        "id_str" : "1707321486",
        "id" : 1707321486
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JohnKerry\/status\/467046817679413248\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/DCjiLpUHjm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BntImu9IAAAJcGP.jpg",
        "id_str" : "467046816639614976",
        "id" : 467046816639614976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BntImu9IAAAJcGP.jpg",
        "sizes" : [ {
          "h" : 573,
          "resize" : "fit",
          "w" : 798
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 573,
          "resize" : "fit",
          "w" : 798
        }, {
          "h" : 244,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DCjiLpUHjm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "467046817679413248",
    "text" : "Happy birthday to my friend &amp; the first Madam Secretary @madeleine Albright! http:\/\/t.co\/DCjiLpUHjm",
    "id" : 467046817679413248,
    "created_at" : "2014-05-15 21:00:13 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 467075214304886785,
  "created_at" : "2014-05-15 22:53:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadsUp4Safety",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467029194036088833",
  "text" : "POTUS's May 29th #HeadsUp4Safety summit will:\n1. Raise awareness on youth sports safety.\n2. Encourage commitments to research concussions.",
  "id" : 467029194036088833,
  "created_at" : "2014-05-15 19:50:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadsUp4Safety",
      "indices" : [ 128, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467027195932975104",
  "text" : "As a parent &amp; sports fan, President Obama's committed to youth sports safety.\nHe'll host a summit on concussions on May 29. #HeadsUp4Safety",
  "id" : 467027195932975104,
  "created_at" : "2014-05-15 19:42:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "467010390061502465",
  "text" : "RT @EPA: Today we proposed pollution standards that will protect air quality in neighborhoods near petroleum refineries: http:\/\/t.co\/NyyWEI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/NyyWEIXHR3",
        "expanded_url" : "http:\/\/go.usa.gov\/8Tgj",
        "display_url" : "go.usa.gov\/8Tgj"
      } ]
    },
    "geo" : { },
    "id_str" : "467001774684254208",
    "text" : "Today we proposed pollution standards that will protect air quality in neighborhoods near petroleum refineries: http:\/\/t.co\/NyyWEIXHR3",
    "id" : 467001774684254208,
    "created_at" : "2014-05-15 18:01:14 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 467010390061502465,
  "created_at" : "2014-05-15 18:35:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/466995613226504193\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/crr18mdkOv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnsaCETCAAAidPi.png",
      "id_str" : "466995609178603520",
      "id" : 466995609178603520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnsaCETCAAAidPi.png",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/crr18mdkOv"
    } ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/aExQPlgQCo",
      "expanded_url" : "http:\/\/time.com\/97452\/campus-sexual-assault-joe-biden\/",
      "display_url" : "time.com\/97452\/campus-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "467000180244770816",
  "text" : "RT @VP: You don\u2019t want to be a school that mishandles rape. Step up. It\u2019s time. #1is2Many http:\/\/t.co\/aExQPlgQCo http:\/\/t.co\/crr18mdkOv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/466995613226504193\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/crr18mdkOv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnsaCETCAAAidPi.png",
        "id_str" : "466995609178603520",
        "id" : 466995609178603520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnsaCETCAAAidPi.png",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/crr18mdkOv"
      } ],
      "hashtags" : [ {
        "text" : "1is2Many",
        "indices" : [ 72, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/aExQPlgQCo",
        "expanded_url" : "http:\/\/time.com\/97452\/campus-sexual-assault-joe-biden\/",
        "display_url" : "time.com\/97452\/campus-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "466995613226504193",
    "text" : "You don\u2019t want to be a school that mishandles rape. Step up. It\u2019s time. #1is2Many http:\/\/t.co\/aExQPlgQCo http:\/\/t.co\/crr18mdkOv",
    "id" : 466995613226504193,
    "created_at" : "2014-05-15 17:36:45 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 467000180244770816,
  "created_at" : "2014-05-15 17:54:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/466992135460622336\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/KlJIaQLbMM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnsW31uCYAAjM4Q.jpg",
      "id_str" : "466992134931767296",
      "id" : 466992134931767296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnsW31uCYAAjM4Q.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      } ],
      "display_url" : "pic.twitter.com\/KlJIaQLbMM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466992135460622336",
  "text" : "\"No act of terror can match the strength or the character of our country.\" \u2014Obama at the 9\/11 Memorial dedication http:\/\/t.co\/KlJIaQLbMM",
  "id" : 466992135460622336,
  "created_at" : "2014-05-15 17:22:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466946294410657792",
  "text" : "\"Those we lost live on in us. In the families who love them still. In the friends who remember them always.\" \u2014Obama at the 9\/11 Memorial",
  "id" : 466946294410657792,
  "created_at" : "2014-05-15 14:20:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466946051505922048",
  "text" : "\"Those who come here will know the sacrifice of a young man who\u2014like so many\u2014gave his life so others might live.\" \u2014Obama on Welles Crowther",
  "id" : 466946051505922048,
  "created_at" : "2014-05-15 14:19:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466945364135002112",
  "text" : "\"No act of terror can match the strength or the character of our country.\" \u2014President Obama at the 9\/11 Memorial and Museum",
  "id" : 466945364135002112,
  "created_at" : "2014-05-15 14:17:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466945255406059520",
  "text" : "\"Here we tell their story, so that generations yet unborn will never forget.\" \u2014Obama on the victims of the 9\/11 attacks",
  "id" : 466945255406059520,
  "created_at" : "2014-05-15 14:16:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466945126888386560",
  "text" : "Obama: \"At this memorial...we come together. We can stand in the footprints of two mighty towers, graced by the rush of eternal waters.\"",
  "id" : 466945126888386560,
  "created_at" : "2014-05-15 14:16:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466944954154377216",
  "text" : "\"It is an honor for us to join in your memories\u2026to reaffirm the true spirit of 9\/11\u2014love, compassion, sacrifice\" \u2014Obama at the 9\/11 Memorial",
  "id" : 466944954154377216,
  "created_at" : "2014-05-15 14:15:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "466943914214445056",
  "text" : "Happening now: President Obama speaks at the National September 11 Memorial and Museum \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 466943914214445056,
  "created_at" : "2014-05-15 14:11:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "466940674991210496",
  "text" : "Starting soon: President Obama speaks at the National September 11 Memorial and Museum. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 466940674991210496,
  "created_at" : "2014-05-15 13:58:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/466723043247919104\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/nWGjkbREhW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnoiIniCUAAOJqD.jpg",
      "id_str" : "466723042832306176",
      "id" : 466723042832306176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnoiIniCUAAOJqD.jpg",
      "sizes" : [ {
        "h" : 622,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 933,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 364,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nWGjkbREhW"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/v2ch1i00Rr",
      "expanded_url" : "http:\/\/go.wh.gov\/5uQqGZ",
      "display_url" : "go.wh.gov\/5uQqGZ"
    } ]
  },
  "geo" : { },
  "id_str" : "466723043247919104",
  "text" : "\"I want us to be 1st when it comes to infrastructure around the world\" \u2014Obama: http:\/\/t.co\/v2ch1i00Rr #RebuildAmerica http:\/\/t.co\/nWGjkbREhW",
  "id" : 466723043247919104,
  "created_at" : "2014-05-14 23:33:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466704908549619714",
  "text" : "RT @NancyPelosi: What you need to know: If the GOP doesn't act on transportation, \u2248700,000 jobs would be at risk. #RebuildAmerica http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/466662204734181377\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/ElEd5tLNBm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnnqzVVIYAAwpOd.jpg",
        "id_str" : "466662204029558784",
        "id" : 466662204029558784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnnqzVVIYAAwpOd.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ElEd5tLNBm"
      } ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 97, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466662204734181377",
    "text" : "What you need to know: If the GOP doesn't act on transportation, \u2248700,000 jobs would be at risk. #RebuildAmerica http:\/\/t.co\/ElEd5tLNBm",
    "id" : 466662204734181377,
    "created_at" : "2014-05-14 19:31:54 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 466704908549619714,
  "created_at" : "2014-05-14 22:21:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466690812357931008",
  "text" : "RT @VP: \u201CWe will continue to be the most dominant economic force if we invest in infrastructure\u201D -VP in Ohio #RebuildAmerica http:\/\/t.co\/pN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/466679581194600448\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/pNHCn9OvGK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bnn6moaIQAA361c.png",
        "id_str" : "466679577998540800",
        "id" : 466679577998540800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bnn6moaIQAA361c.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/pNHCn9OvGK"
      } ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466679581194600448",
    "text" : "\u201CWe will continue to be the most dominant economic force if we invest in infrastructure\u201D -VP in Ohio #RebuildAmerica http:\/\/t.co\/pNHCn9OvGK",
    "id" : 466679581194600448,
    "created_at" : "2014-05-14 20:40:57 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 466690812357931008,
  "created_at" : "2014-05-14 21:25:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/466684123047002112\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/n3uBvws5pP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bnn-vJHIcAAJEXK.jpg",
      "id_str" : "466684122262695936",
      "id" : 466684122262695936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bnn-vJHIcAAJEXK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n3uBvws5pP"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 30, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466684123047002112",
  "text" : "RT if you agree: It's time to #RebuildAmerica and create jobs by fixing our crumbling roads, bridges and ports. http:\/\/t.co\/n3uBvws5pP",
  "id" : 466684123047002112,
  "created_at" : "2014-05-14 20:59:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466668101518757888",
  "text" : "\"A great nation doesn\u2019t say 'no, we can\u2019t.' We say 'yes, we can.'\" \u2014Obama on fixing our crumbling infrastructure #RebuildAmerica",
  "id" : 466668101518757888,
  "created_at" : "2014-05-14 19:55:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 126, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466667531307319296",
  "text" : "Obama: \"It\u2019s time for the folks who run around yelling about what\u2019s wrong with America to roll up their sleeves &amp; help us #RebuildAmerica.\"",
  "id" : 466667531307319296,
  "created_at" : "2014-05-14 19:53:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466666492822822914",
  "text" : "\"If they don\u2019t act by the end of summer, federal funding for transportation projects will run out.\" \u2014Obama on Congress #RebuildAmerica",
  "id" : 466666492822822914,
  "created_at" : "2014-05-14 19:48:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466666270835109888",
  "text" : "\"First-class infrastructure attracts first-class jobs. Business owners don\u2019t seek out crumbling roads and bridges.\" \u2014Obama #RebuildAmerica",
  "id" : 466666270835109888,
  "created_at" : "2014-05-14 19:48:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/BuK9sotib8",
      "expanded_url" : "http:\/\/go.wh.gov\/1ZekAt",
      "display_url" : "go.wh.gov\/1ZekAt"
    } ]
  },
  "geo" : { },
  "id_str" : "466666083030945792",
  "text" : "RT @WHLive: \"Nearly half our people don\u2019t have access to transit at all.\" \u2014President Obama: http:\/\/t.co\/BuK9sotib8 #RebuildAmerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 103, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/BuK9sotib8",
        "expanded_url" : "http:\/\/go.wh.gov\/1ZekAt",
        "display_url" : "go.wh.gov\/1ZekAt"
      } ]
    },
    "geo" : { },
    "id_str" : "466666048360816641",
    "text" : "\"Nearly half our people don\u2019t have access to transit at all.\" \u2014President Obama: http:\/\/t.co\/BuK9sotib8 #RebuildAmerica",
    "id" : 466666048360816641,
    "created_at" : "2014-05-14 19:47:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 466666083030945792,
  "created_at" : "2014-05-14 19:47:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/466665941703856128\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/S6aaICcZ5M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnnuM17IgAAqYIT.jpg",
      "id_str" : "466665940810498048",
      "id" : 466665940810498048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnnuM17IgAAqYIT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/S6aaICcZ5M"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466665941703856128",
  "text" : "\"We\u2019ve got more than 100,000 bridges that are old enough to qualify for Medicare.\" \u2014Obama #RebuildAmerica http:\/\/t.co\/S6aaICcZ5M",
  "id" : 466665941703856128,
  "created_at" : "2014-05-14 19:46:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466665774900588544",
  "text" : "\"4 years ago...the unemployment rate for construction workers stood at\u202620%. Today, we\u2019ve cut it by more than half.\" \u2014Obama #RebuildAmerica",
  "id" : 466665774900588544,
  "created_at" : "2014-05-14 19:46:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466665033024692225",
  "text" : "RT @WHLive: \"Workers are building a replacement\u2014the first new bridge in New York in 50 years.\" \u2014Obama by the Tappan Zee Bridge #RebuildAmer\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 115, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466664802409267200",
    "text" : "\"Workers are building a replacement\u2014the first new bridge in New York in 50 years.\" \u2014Obama by the Tappan Zee Bridge #RebuildAmerica",
    "id" : 466664802409267200,
    "created_at" : "2014-05-14 19:42:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 466665033024692225,
  "created_at" : "2014-05-14 19:43:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/466664242863947776\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/tkO7wtEt9u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bnnsp91IEAEShiX.jpg",
      "id_str" : "466664242125737985",
      "id" : 466664242125737985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bnnsp91IEAEShiX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tkO7wtEt9u"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 91, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466664242863947776",
  "text" : "\"In just over 4 years, our businesses have created 9.2 million new jobs.\" \u2014President Obama #RebuildAmerica http:\/\/t.co\/tkO7wtEt9u",
  "id" : 466664242863947776,
  "created_at" : "2014-05-14 19:40:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 58, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/QhXESJP7MA",
      "expanded_url" : "http:\/\/go.wh.gov\/puPTKC",
      "display_url" : "go.wh.gov\/puPTKC"
    } ]
  },
  "geo" : { },
  "id_str" : "466661210558332929",
  "text" : "Starting soon: President Obama speaks on why it's time to #RebuildAmerica by fixing our crumbling infrastructure \u2192 http:\/\/t.co\/QhXESJP7MA",
  "id" : 466661210558332929,
  "created_at" : "2014-05-14 19:27:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 83, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ZOy0wKPsym",
      "expanded_url" : "http:\/\/go.wh.gov\/1ZekAt",
      "display_url" : "go.wh.gov\/1ZekAt"
    } ]
  },
  "geo" : { },
  "id_str" : "466651699201855488",
  "text" : "FACT: 45% of Americans lack access to transit.\nIt's time to reauthorize funding to #RebuildAmerica's infrastructure \u2192 http:\/\/t.co\/ZOy0wKPsym",
  "id" : 466651699201855488,
  "created_at" : "2014-05-14 18:50:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466647343249784832",
  "text" : "RT @VP: Starting right now: The VP is speaking in Cleveland on the importance of investing in infrastructure. Follow along \u2192 http:\/\/t.co\/J8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/J8GRuzB2l0",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/vice-president-biden-speaks-infrastructure-improvement-0",
        "display_url" : "whitehouse.gov\/live\/vice-pres\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "466646049445380096",
    "text" : "Starting right now: The VP is speaking in Cleveland on the importance of investing in infrastructure. Follow along \u2192 http:\/\/t.co\/J8GRuzB2l0",
    "id" : 466646049445380096,
    "created_at" : "2014-05-14 18:27:42 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 466647343249784832,
  "created_at" : "2014-05-14 18:32:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/466640843416535040\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/RWQoBpWs17",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnnXX7RIEAEuZ-U.jpg",
      "id_str" : "466640842456043521",
      "id" : 466640842456043521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnnXX7RIEAEuZ-U.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RWQoBpWs17"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/MA4sN1wleE",
      "expanded_url" : "http:\/\/go.wh.gov\/1ZekAt",
      "display_url" : "go.wh.gov\/1ZekAt"
    } ]
  },
  "geo" : { },
  "id_str" : "466640843416535040",
  "text" : "FACT: 65% of America's major roads are rated in less than good condition \u2192 http:\/\/t.co\/MA4sN1wleE #RebuildAmerica http:\/\/t.co\/RWQoBpWs17",
  "id" : 466640843416535040,
  "created_at" : "2014-05-14 18:07:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/466625820501741568\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/VO7UjlXEZX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnnJtewIcAAlle0.jpg",
      "id_str" : "466625819595796480",
      "id" : 466625819595796480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnnJtewIcAAlle0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VO7UjlXEZX"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 97, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466625820501741568",
  "text" : "Here's what's at stake if Congress fails to act on infrastructure:\n112,000 projects\n700,000 jobs\n#RebuildAmerica http:\/\/t.co\/VO7UjlXEZX",
  "id" : 466625820501741568,
  "created_at" : "2014-05-14 17:07:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/7RGn0S5L5D",
      "expanded_url" : "http:\/\/go.wh.gov\/GimtAV",
      "display_url" : "go.wh.gov\/GimtAV"
    } ]
  },
  "geo" : { },
  "id_str" : "466624116855152640",
  "text" : "Today, we're releasing a new plan to accelerate and expand infrastructure permitting \u2192 http:\/\/t.co\/7RGn0S5L5D #RebuildAmerica",
  "id" : 466624116855152640,
  "created_at" : "2014-05-14 17:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Rick Mastracchio",
      "screen_name" : "AstroRM",
      "indices" : [ 17, 25 ],
      "id_str" : "541158674",
      "id" : 541158674
    }, {
      "name" : "Koichi Wakata",
      "screen_name" : "Astro_Wakata",
      "indices" : [ 27, 40 ],
      "id_str" : "1081962504",
      "id" : 1081962504
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISS",
      "indices" : [ 124, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466593341153370112",
  "text" : "RT @NASA: ICYMI: @AstroRM, @Astro_Wakata &amp; Tyurin return from spending 6 months &amp; 3,008 orbits around the planet on #ISS http:\/\/t.co\/KvQ5NF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rick Mastracchio",
        "screen_name" : "AstroRM",
        "indices" : [ 7, 15 ],
        "id_str" : "541158674",
        "id" : 541158674
      }, {
        "name" : "Koichi Wakata",
        "screen_name" : "Astro_Wakata",
        "indices" : [ 17, 30 ],
        "id_str" : "1081962504",
        "id" : 1081962504
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/466567472993558530\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/KvQ5NF7hnR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnmUpGXIIAA2m-8.jpg",
        "id_str" : "466567470212718592",
        "id" : 466567470212718592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnmUpGXIIAA2m-8.jpg",
        "sizes" : [ {
          "h" : 531,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 906,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 301,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 906,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KvQ5NF7hnR"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/466567472993558530\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/KvQ5NF7hnR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnmUpABIEAIRz3X.jpg",
        "id_str" : "466567468509827074",
        "id" : 466567468509827074,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnmUpABIEAIRz3X.jpg",
        "sizes" : [ {
          "h" : 482,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 850,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 723
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 723
        } ],
        "display_url" : "pic.twitter.com\/KvQ5NF7hnR"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/466567472993558530\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/KvQ5NF7hnR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnmUpH8IIAEaC_2.jpg",
        "id_str" : "466567470636343297",
        "id" : 466567470636343297,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnmUpH8IIAEaC_2.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 791
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 791
        }, {
          "h" : 777,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/KvQ5NF7hnR"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/466567472993558530\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/KvQ5NF7hnR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnmUo0JIUAA1FYc.jpg",
        "id_str" : "466567465322172416",
        "id" : 466567465322172416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnmUo0JIUAA1FYc.jpg",
        "sizes" : [ {
          "h" : 902,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 681
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 681
        } ],
        "display_url" : "pic.twitter.com\/KvQ5NF7hnR"
      } ],
      "hashtags" : [ {
        "text" : "ISS",
        "indices" : [ 114, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466567472993558530",
    "text" : "ICYMI: @AstroRM, @Astro_Wakata &amp; Tyurin return from spending 6 months &amp; 3,008 orbits around the planet on #ISS http:\/\/t.co\/KvQ5NF7hnR",
    "id" : 466567472993558530,
    "created_at" : "2014-05-14 13:15:28 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 466593341153370112,
  "created_at" : "2014-05-14 14:58:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/466370095204556800\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/iR7t0kkJw1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnjhIVrIAAAetyW.jpg",
      "id_str" : "466370094806073344",
      "id" : 466370094806073344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnjhIVrIAAAetyW.jpg",
      "sizes" : [ {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 746,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/iR7t0kkJw1"
    } ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466370095204556800",
  "text" : "\"You motivate all of us to be the best we can be.\" \u2014Obama awarding the #MedalOfHonor to Sergeant Kyle White http:\/\/t.co\/iR7t0kkJw1",
  "id" : 466370095204556800,
  "created_at" : "2014-05-14 00:11:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466357870096056320",
  "text" : "RT @VP: \u201CInfrastructure is the back upon which this great nation has been built.\u201D \u2013VP discussing the need to #RebuildAmerica http:\/\/t.co\/c9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/466355989764407296\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/c94A8QuPOX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnjUS-cIUAAe2sa.png",
        "id_str" : "466355983896563712",
        "id" : 466355983896563712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnjUS-cIUAAe2sa.png",
        "sizes" : [ {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/c94A8QuPOX"
      } ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466355989764407296",
    "text" : "\u201CInfrastructure is the back upon which this great nation has been built.\u201D \u2013VP discussing the need to #RebuildAmerica http:\/\/t.co\/c94A8QuPOX",
    "id" : 466355989764407296,
    "created_at" : "2014-05-13 23:15:07 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 466357870096056320,
  "created_at" : "2014-05-13 23:22:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 108, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466329099322277888",
  "text" : "RT @VP: \"We have to rebuild the infrastructure in this country.\" \u2013 VP outside the Gateway Arch in St. Louis #RebuildAmerica http:\/\/t.co\/Lq7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/466328367416229891\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Lq7kBoEQ8y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bni7LU1CQAAk6Tf.png",
        "id_str" : "466328364676956160",
        "id" : 466328364676956160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bni7LU1CQAAk6Tf.png",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Lq7kBoEQ8y"
      } ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 100, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466328367416229891",
    "text" : "\"We have to rebuild the infrastructure in this country.\" \u2013 VP outside the Gateway Arch in St. Louis #RebuildAmerica http:\/\/t.co\/Lq7kBoEQ8y",
    "id" : 466328367416229891,
    "created_at" : "2014-05-13 21:25:21 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 466329099322277888,
  "created_at" : "2014-05-13 21:28:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/gPaPNZt2fP",
      "expanded_url" : "http:\/\/go.wh.gov\/h73cYd",
      "display_url" : "go.wh.gov\/h73cYd"
    } ]
  },
  "geo" : { },
  "id_str" : "466317406433210369",
  "text" : "FACT: The Affordable Care Act prohibits insurers from charging women higher premiums simply because of their gender \u2192 http:\/\/t.co\/gPaPNZt2fP",
  "id" : 466317406433210369,
  "created_at" : "2014-05-13 20:41:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/gPaPNZt2fP",
      "expanded_url" : "http:\/\/go.wh.gov\/h73cYd",
      "display_url" : "go.wh.gov\/h73cYd"
    } ]
  },
  "geo" : { },
  "id_str" : "466298935142014976",
  "text" : "\"My Administration remains dedicated to protecting women's rights to make their own health care decisions.\" \u2014Obama: http:\/\/t.co\/gPaPNZt2fP",
  "id" : 466298935142014976,
  "created_at" : "2014-05-13 19:28:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466292013797998592",
  "text" : "\"You motivate all of us to be the best we can be, as Americans, as a nation.\" \u2014Obama awarding the #MedalOfHonor to Sergeant Kyle White",
  "id" : 466292013797998592,
  "created_at" : "2014-05-13 19:00:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466288929285500928",
  "text" : "\"Today, we pay tribute to a soldier who embodies the courage of his generation.\" \u2014President Obama on Sergeant Kyle White #MedalOfHonor",
  "id" : 466288929285500928,
  "created_at" : "2014-05-13 18:48:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 42, 55 ]
    }, {
      "text" : "HonoringVets",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/jPkNMO1R8Z",
      "expanded_url" : "http:\/\/go.wh.gov\/p8kTkk",
      "display_url" : "go.wh.gov\/p8kTkk"
    } ]
  },
  "geo" : { },
  "id_str" : "466288230586142720",
  "text" : "Happening now: President Obama awards the #MedalOfHonor to Sergeant Kyle White \u2192 http:\/\/t.co\/jPkNMO1R8Z #HonoringVets",
  "id" : 466288230586142720,
  "created_at" : "2014-05-13 18:45:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DeptVetAffairs\/status\/466280472025104384\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/o7Zthndaf6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BniPnljCAAArG7t.jpg",
      "id_str" : "466280471689560064",
      "id" : 466280471689560064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BniPnljCAAArG7t.jpg",
      "sizes" : [ {
        "h" : 896,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 508,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1530,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1936,
        "resize" : "fit",
        "w" : 1296
      } ],
      "display_url" : "pic.twitter.com\/o7Zthndaf6"
    } ],
    "hashtags" : [ {
      "text" : "MOH",
      "indices" : [ 96, 100 ]
    }, {
      "text" : "HonoringVets",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/PVuwLc6BIX",
      "expanded_url" : "http:\/\/1.usa.gov\/1jWnP6p",
      "display_url" : "1.usa.gov\/1jWnP6p"
    } ]
  },
  "geo" : { },
  "id_str" : "466281679951126528",
  "text" : "RT @DeptVetAffairs: The story behind today\u2019s Medal of Honor presentation http:\/\/t.co\/PVuwLc6BIX #MOH #HonoringVets http:\/\/t.co\/o7Zthndaf6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeptVetAffairs\/status\/466280472025104384\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/o7Zthndaf6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BniPnljCAAArG7t.jpg",
        "id_str" : "466280471689560064",
        "id" : 466280471689560064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BniPnljCAAArG7t.jpg",
        "sizes" : [ {
          "h" : 896,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 508,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1530,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1936,
          "resize" : "fit",
          "w" : 1296
        } ],
        "display_url" : "pic.twitter.com\/o7Zthndaf6"
      } ],
      "hashtags" : [ {
        "text" : "MOH",
        "indices" : [ 76, 80 ]
      }, {
        "text" : "HonoringVets",
        "indices" : [ 81, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/PVuwLc6BIX",
        "expanded_url" : "http:\/\/1.usa.gov\/1jWnP6p",
        "display_url" : "1.usa.gov\/1jWnP6p"
      } ]
    },
    "geo" : { },
    "id_str" : "466280472025104384",
    "text" : "The story behind today\u2019s Medal of Honor presentation http:\/\/t.co\/PVuwLc6BIX #MOH #HonoringVets http:\/\/t.co\/o7Zthndaf6",
    "id" : 466280472025104384,
    "created_at" : "2014-05-13 18:15:02 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 466281679951126528,
  "created_at" : "2014-05-13 18:19:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 95, 98 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/ccjKubFJe4",
      "expanded_url" : "http:\/\/youtu.be\/T9DoC3qH89o",
      "display_url" : "youtu.be\/T9DoC3qH89o"
    } ]
  },
  "geo" : { },
  "id_str" : "466265396153049089",
  "text" : "\"Manufacturing's coming back to the United States. We're not outsourcing, we are insourcing.\" \u2014@VP: http:\/\/t.co\/ccjKubFJe4 #RebuildAmerica",
  "id" : 466265396153049089,
  "created_at" : "2014-05-13 17:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "GlacierNationalPark",
      "screen_name" : "GlacierNPS",
      "indices" : [ 25, 36 ],
      "id_str" : "32887168",
      "id" : 32887168
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/466236320008785920\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/nnDbWEKQ6c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnhndlHCUAAWUMU.jpg",
      "id_str" : "466236319308337152",
      "id" : 466236319308337152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnhndlHCUAAWUMU.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nnDbWEKQ6c"
    } ],
    "hashtags" : [ {
      "text" : "Montana",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466258422867181568",
  "text" : "RT @Interior: This week, @GlacierNPS turns 104. Retweet this photo to wish them a happy birthday! #Montana http:\/\/t.co\/nnDbWEKQ6c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GlacierNationalPark",
        "screen_name" : "GlacierNPS",
        "indices" : [ 11, 22 ],
        "id_str" : "32887168",
        "id" : 32887168
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/466236320008785920\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/nnDbWEKQ6c",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnhndlHCUAAWUMU.jpg",
        "id_str" : "466236319308337152",
        "id" : 466236319308337152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnhndlHCUAAWUMU.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/nnDbWEKQ6c"
      } ],
      "hashtags" : [ {
        "text" : "Montana",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466236320008785920",
    "text" : "This week, @GlacierNPS turns 104. Retweet this photo to wish them a happy birthday! #Montana http:\/\/t.co\/nnDbWEKQ6c",
    "id" : 466236320008785920,
    "created_at" : "2014-05-13 15:19:35 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 466258422867181568,
  "created_at" : "2014-05-13 16:47:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466249067929300992",
  "text" : "RT @Podesta44: This is your earth on climate change: Collapse of Antarctic ice sheet \u201Calmost certainly unstoppable,\" scientists say. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/rCsuRj6KAA",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/05\/13\/science\/earth\/collapse-of-parts-of-west-antarctica-ice-sheet-has-begun-scientists-say.html?hp",
        "display_url" : "nytimes.com\/2014\/05\/13\/sci\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "466241445142487040",
    "text" : "This is your earth on climate change: Collapse of Antarctic ice sheet \u201Calmost certainly unstoppable,\" scientists say. http:\/\/t.co\/rCsuRj6KAA",
    "id" : 466241445142487040,
    "created_at" : "2014-05-13 15:39:57 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 466249067929300992,
  "created_at" : "2014-05-13 16:10:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 96, 99 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/szKtHz95go",
      "expanded_url" : "http:\/\/youtu.be\/T9DoC3qH89o",
      "display_url" : "youtu.be\/T9DoC3qH89o"
    } ]
  },
  "geo" : { },
  "id_str" : "466236375084564480",
  "text" : "\"Every time we've invested in infrastructure, as Democrats and Republicans\u2026the economy grows.\" \u2014@VP: http:\/\/t.co\/szKtHz95go #RebuildAmerica",
  "id" : 466236375084564480,
  "created_at" : "2014-05-13 15:19:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/gCO45Tz3IM",
      "expanded_url" : "http:\/\/youtu.be\/T9DoC3qH89o",
      "display_url" : "youtu.be\/T9DoC3qH89o"
    } ]
  },
  "geo" : { },
  "id_str" : "466229665670000641",
  "text" : "RT @VP: Investing in America\u2019s infrastructure means:\nEconomic growth \u2713\nGood-paying jobs \u2713\n\nWatch \u2192 http:\/\/t.co\/gCO45Tz3IM #RebuildAmerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 114, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/gCO45Tz3IM",
        "expanded_url" : "http:\/\/youtu.be\/T9DoC3qH89o",
        "display_url" : "youtu.be\/T9DoC3qH89o"
      } ]
    },
    "geo" : { },
    "id_str" : "466229358592811008",
    "text" : "Investing in America\u2019s infrastructure means:\nEconomic growth \u2713\nGood-paying jobs \u2713\n\nWatch \u2192 http:\/\/t.co\/gCO45Tz3IM #RebuildAmerica",
    "id" : 466229358592811008,
    "created_at" : "2014-05-13 14:51:55 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 466229665670000641,
  "created_at" : "2014-05-13 14:53:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAworks",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466225479091908609",
  "text" : "RT @NancyPelosi: This National Women\u2019s Health Week, we can celebrate that being a woman is no longer a preexisting condition #ACAworks http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NancyPelosi\/status\/466212313448861697\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/hbx7bKcFCB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnhRoNRCUAEuoy8.png",
        "id_str" : "466212312630579201",
        "id" : 466212312630579201,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnhRoNRCUAEuoy8.png",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hbx7bKcFCB"
      } ],
      "hashtags" : [ {
        "text" : "ACAworks",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "466212313448861697",
    "text" : "This National Women\u2019s Health Week, we can celebrate that being a woman is no longer a preexisting condition #ACAworks http:\/\/t.co\/hbx7bKcFCB",
    "id" : 466212313448861697,
    "created_at" : "2014-05-13 13:44:11 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 466225479091908609,
  "created_at" : "2014-05-13 14:36:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBusinessWeek",
      "indices" : [ 86, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/repullNivA",
      "expanded_url" : "http:\/\/go.wh.gov\/GVAPHy",
      "display_url" : "go.wh.gov\/GVAPHy"
    } ]
  },
  "geo" : { },
  "id_str" : "465984674314334208",
  "text" : "\"Small businesses represent what is best about America.\" \u2014President Obama on National #SmallBusinessWeek: http:\/\/t.co\/repullNivA",
  "id" : 465984674314334208,
  "created_at" : "2014-05-12 22:39:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465972559058829314",
  "text" : "\"We have to do our part by making sure you have the resources and protections and support you need to do your jobs well.\" \u2014Obama to Top Cops",
  "id" : 465972559058829314,
  "created_at" : "2014-05-12 21:51:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465972336228069376",
  "text" : "\"Maintaining the public safety is the foundation for everything that is good that happens every day in America.\" \u2014Obama honoring Top Cops",
  "id" : 465972336228069376,
  "created_at" : "2014-05-12 21:50:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465971070244515842",
  "text" : "\"It takes a lot of courage to be a cop, but it also takes courage to love a cop &amp; send them off to work every single day.\" \u2014President Obama",
  "id" : 465971070244515842,
  "created_at" : "2014-05-12 21:45:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "465970616898953216",
  "text" : "Happening now: President Obama honors the 2014 National Association of Police Organizations Top Cops award winners \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 465970616898953216,
  "created_at" : "2014-05-12 21:43:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/USDOL\/status\/465917038926368768\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/m27qgK8YlX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BndFE9eIcAAn7TC.png",
      "id_str" : "465917037978873856",
      "id" : 465917037978873856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BndFE9eIcAAn7TC.png",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/m27qgK8YlX"
    } ],
    "hashtags" : [ {
      "text" : "WorkingFamilies",
      "indices" : [ 72, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465965066412912640",
  "text" : "RT @USDOL: RT if you agree: It's time to build an economy that supports #WorkingFamilies. http:\/\/t.co\/m27qgK8YlX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USDOL\/status\/465917038926368768\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/m27qgK8YlX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BndFE9eIcAAn7TC.png",
        "id_str" : "465917037978873856",
        "id" : 465917037978873856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BndFE9eIcAAn7TC.png",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/m27qgK8YlX"
      } ],
      "hashtags" : [ {
        "text" : "WorkingFamilies",
        "indices" : [ 61, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "465917038926368768",
    "text" : "RT if you agree: It's time to build an economy that supports #WorkingFamilies. http:\/\/t.co\/m27qgK8YlX",
    "id" : 465917038926368768,
    "created_at" : "2014-05-12 18:10:53 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 465965066412912640,
  "created_at" : "2014-05-12 21:21:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/3DZK0AuJyV",
      "expanded_url" : "http:\/\/go.wh.gov\/NabWZs",
      "display_url" : "go.wh.gov\/NabWZs"
    } ]
  },
  "geo" : { },
  "id_str" : "465962108392587264",
  "text" : "Here's why it's time to repair our crumbling roads and bridges and invest in our infrastructure \u2192 http:\/\/t.co\/3DZK0AuJyV #RebuildAmerica",
  "id" : 465962108392587264,
  "created_at" : "2014-05-12 21:09:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBusinessWeek",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/wZovnlAnlp",
      "expanded_url" : "http:\/\/go.wh.gov\/erUWRB",
      "display_url" : "go.wh.gov\/erUWRB"
    } ]
  },
  "geo" : { },
  "id_str" : "465922483099803648",
  "text" : "FACT: America's 28 million small businesses create nearly 2 out of 3 jobs in our economy \u2192 http:\/\/t.co\/wZovnlAnlp #SmallBusinessWeek",
  "id" : 465922483099803648,
  "created_at" : "2014-05-12 18:32:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 105, 110 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/zTpPyGRRRL",
      "expanded_url" : "http:\/\/huff.to\/1jSvouW",
      "display_url" : "huff.to\/1jSvouW"
    } ]
  },
  "geo" : { },
  "id_str" : "465898481874632704",
  "text" : "\"Empowering women in our workplaces is not only good for American families, it increases productivity.\" \u2014@VJ44: http:\/\/t.co\/zTpPyGRRRL",
  "id" : 465898481874632704,
  "created_at" : "2014-05-12 16:57:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 46, 55 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/465880149280710657\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/yP30YY1loq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bncjht4CIAE_40h.jpg",
      "id_str" : "465880148613406721",
      "id" : 465880148613406721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bncjht4CIAE_40h.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/yP30YY1loq"
    } ],
    "hashtags" : [ {
      "text" : "MonuMeet",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465880149280710657",
  "text" : "The Washington Monument reopens today! Follow @Interior and #MonuMeet for photos and coverage throughout the day. http:\/\/t.co\/yP30YY1loq",
  "id" : 465880149280710657,
  "created_at" : "2014-05-12 15:44:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "indices" : [ 3, 10 ],
      "id_str" : "2169098419",
      "id" : 2169098419
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 79, 88 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MonuMeet",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465856188970573824",
  "text" : "RT @Alex44: No more scaffolding: The Washington Monument reopens today! Follow @Interior and #MonuMeet for pics all day. http:\/\/t.co\/SfDWbV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 67, 76 ],
        "id_str" : "76348185",
        "id" : 76348185
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Alex44\/status\/465849332097613824\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/SfDWbVKjc9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BncHf5tCYAE37Q8.jpg",
        "id_str" : "465849331103195137",
        "id" : 465849331103195137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BncHf5tCYAE37Q8.jpg",
        "sizes" : [ {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        } ],
        "display_url" : "pic.twitter.com\/SfDWbVKjc9"
      } ],
      "hashtags" : [ {
        "text" : "MonuMeet",
        "indices" : [ 81, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "465849332097613824",
    "text" : "No more scaffolding: The Washington Monument reopens today! Follow @Interior and #MonuMeet for pics all day. http:\/\/t.co\/SfDWbVKjc9",
    "id" : 465849332097613824,
    "created_at" : "2014-05-12 13:41:50 +0000",
    "user" : {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "protected" : false,
      "id_str" : "2169098419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632215085256081409\/_vjZ92WM_normal.jpg",
      "id" : 2169098419,
      "verified" : true
    }
  },
  "id" : 465856188970573824,
  "created_at" : "2014-05-12 14:09:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 95, 102 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyMothersDay",
      "indices" : [ 75, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/DaOIhOaf3f",
      "expanded_url" : "http:\/\/go.wh.gov\/cbWJnW",
      "display_url" : "go.wh.gov\/cbWJnW"
    } ]
  },
  "geo" : { },
  "id_str" : "465521733303160833",
  "text" : "\"I want to take a moment to honor all the mothers out there and wish you a #HappyMothersDay.\" \u2014@FLOTUS: http:\/\/t.co\/DaOIhOaf3f",
  "id" : 465521733303160833,
  "created_at" : "2014-05-11 16:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 39, 51 ]
    }, {
      "text" : "HappyMothersDay",
      "indices" : [ 108, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465498720919117826",
  "text" : "RT @FLOTUS: Thanks for inspiring me to #ReachHigher mom! Wishing you and all the wonderful moms out there a #HappyMothersDay. -mo http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/465496783674949632\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/AOFJIcb17A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnXG2vcCQAAXQTi.jpg",
        "id_str" : "465496780252004352",
        "id" : 465496780252004352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnXG2vcCQAAXQTi.jpg",
        "sizes" : [ {
          "h" : 1535,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2561,
          "resize" : "fit",
          "w" : 1708
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/AOFJIcb17A"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 27, 39 ]
      }, {
        "text" : "HappyMothersDay",
        "indices" : [ 96, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "465496783674949632",
    "text" : "Thanks for inspiring me to #ReachHigher mom! Wishing you and all the wonderful moms out there a #HappyMothersDay. -mo http:\/\/t.co\/AOFJIcb17A",
    "id" : 465496783674949632,
    "created_at" : "2014-05-11 14:20:56 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 465498720919117826,
  "created_at" : "2014-05-11 14:28:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 84, 91 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BringBackOurGirls",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/DaOIhOaf3f",
      "expanded_url" : "http:\/\/go.wh.gov\/cbWJnW",
      "display_url" : "go.wh.gov\/cbWJnW"
    } ]
  },
  "geo" : { },
  "id_str" : "465205892183379970",
  "text" : "\"Let us all pray for their safe return. Let us hold their families in our hearts.\" \u2014@FLOTUS: http:\/\/t.co\/DaOIhOaf3f #BringBackOurGirls",
  "id" : 465205892183379970,
  "created_at" : "2014-05-10 19:05:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 102, 109 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/DaOIhOaf3f",
      "expanded_url" : "http:\/\/go.wh.gov\/cbWJnW",
      "display_url" : "go.wh.gov\/cbWJnW"
    } ]
  },
  "geo" : { },
  "id_str" : "465160593045868545",
  "text" : "\"My husband and I are outraged and heartbroken over the kidnapping of more than 200 Nigerian girls.\" \u2014@FLOTUS: http:\/\/t.co\/DaOIhOaf3f",
  "id" : 465160593045868545,
  "created_at" : "2014-05-10 16:05:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BringBackOurGirls",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/fUabhgwfDS",
      "expanded_url" : "http:\/\/go.wh.gov\/cbWJnW",
      "display_url" : "go.wh.gov\/cbWJnW"
    } ]
  },
  "geo" : { },
  "id_str" : "465120918596247552",
  "text" : "RT @FLOTUS: The First Lady marks Mother's Day and speaks out on the tragic kidnapping in Nigeria \u2192 http:\/\/t.co\/fUabhgwfDS #BringBackOurGirls",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BringBackOurGirls",
        "indices" : [ 110, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/fUabhgwfDS",
        "expanded_url" : "http:\/\/go.wh.gov\/cbWJnW",
        "display_url" : "go.wh.gov\/cbWJnW"
      } ]
    },
    "geo" : { },
    "id_str" : "465120694733639681",
    "text" : "The First Lady marks Mother's Day and speaks out on the tragic kidnapping in Nigeria \u2192 http:\/\/t.co\/fUabhgwfDS #BringBackOurGirls",
    "id" : 465120694733639681,
    "created_at" : "2014-05-10 13:26:29 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 465120918596247552,
  "created_at" : "2014-05-10 13:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BringBackOurGirls",
      "indices" : [ 73, 91 ]
    }, {
      "text" : "MothersDay",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464860238227984385",
  "text" : "RT @FLOTUS: The First Lady will deliver her first solo weekly address on #BringBackOurGirls &amp; #MothersDay. Watch it tomorrow at http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BringBackOurGirls",
        "indices" : [ 61, 79 ]
      }, {
        "text" : "MothersDay",
        "indices" : [ 86, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/MsIxlQLNZA",
        "expanded_url" : "http:\/\/WhiteHouse.gov",
        "display_url" : "WhiteHouse.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "464857452094447616",
    "text" : "The First Lady will deliver her first solo weekly address on #BringBackOurGirls &amp; #MothersDay. Watch it tomorrow at http:\/\/t.co\/MsIxlQLNZA.",
    "id" : 464857452094447616,
    "created_at" : "2014-05-09 20:00:27 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 464860238227984385,
  "created_at" : "2014-05-09 20:11:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 57, 69 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/O5KracmHln",
      "expanded_url" : "http:\/\/go.wh.gov\/5wJRCj",
      "display_url" : "go.wh.gov\/5wJRCj"
    } ]
  },
  "geo" : { },
  "id_str" : "464843805318197248",
  "text" : "\"Solar is here. We are doing it. We can do a lot more.\" \u2014@ErnestMoniz on deploying more solar power: http:\/\/t.co\/O5KracmHln #ActOnClimate",
  "id" : 464843805318197248,
  "created_at" : "2014-05-09 19:06:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ILl3L1WwRr",
      "expanded_url" : "http:\/\/go.wh.gov\/6v9n7N",
      "display_url" : "go.wh.gov\/6v9n7N"
    } ]
  },
  "geo" : { },
  "id_str" : "464824529169428480",
  "text" : "FACT: Today, President Obama's taking steps to save businesses $26 billion in energy costs \u2192 http:\/\/t.co\/ILl3L1WwRr #ActOnClimate",
  "id" : 464824529169428480,
  "created_at" : "2014-05-09 17:49:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/D0mgjuWHlP",
      "expanded_url" : "http:\/\/go.wh.gov\/sstqgC",
      "display_url" : "go.wh.gov\/sstqgC"
    } ]
  },
  "geo" : { },
  "id_str" : "464813023186923521",
  "text" : "\"We don\u2019t look backwards. We look forward. We don\u2019t fear the future.\" \u2014Obama on why it's time to #ActOnClimate: http:\/\/t.co\/D0mgjuWHlP",
  "id" : 464813023186923521,
  "created_at" : "2014-05-09 17:03:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/eGvdZBYgH1",
      "expanded_url" : "http:\/\/go.wh.gov\/6v9n7N",
      "display_url" : "go.wh.gov\/6v9n7N"
    } ]
  },
  "geo" : { },
  "id_str" : "464812339263709184",
  "text" : "RT @WHLive: \"More than 300 organizations...announced they\u2019re going to expand the use of solar energy.\" \u2014Obama: http:\/\/t.co\/eGvdZBYgH1 #ActO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/eGvdZBYgH1",
        "expanded_url" : "http:\/\/go.wh.gov\/6v9n7N",
        "display_url" : "go.wh.gov\/6v9n7N"
      } ]
    },
    "geo" : { },
    "id_str" : "464811920961597440",
    "text" : "\"More than 300 organizations...announced they\u2019re going to expand the use of solar energy.\" \u2014Obama: http:\/\/t.co\/eGvdZBYgH1 #ActOnClimate",
    "id" : 464811920961597440,
    "created_at" : "2014-05-09 16:59:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 464812339263709184,
  "created_at" : "2014-05-09 17:01:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464810989398290432",
  "text" : "\"No matter where you live or where you do business, solar is getting cheaper and easier to use than ever before.\" \u2014Obama #ActOnClimate",
  "id" : 464810989398290432,
  "created_at" : "2014-05-09 16:55:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464810796862951424",
  "text" : "\"We set new fuel standards for our cars and trucks so that they\u2019ll go twice as far on a gallon of gas.\" \u2014President Obama #ActOnClimate",
  "id" : 464810796862951424,
  "created_at" : "2014-05-09 16:55:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464810589509132288",
  "text" : "\"We generate more renewable energy than ever, with tens of thousands of good, American jobs to show for it.\" \u2014Obama #ActOnClimate",
  "id" : 464810589509132288,
  "created_at" : "2014-05-09 16:54:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 95, 108 ]
    }, {
      "text" : "MadeInAmerica",
      "indices" : [ 109, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464810451508158464",
  "text" : "\"Today, America is closer to energy independence than we\u2019ve been in decades.\" \u2014President Obama #ActOnClimate #MadeInAmerica",
  "id" : 464810451508158464,
  "created_at" : "2014-05-09 16:53:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walmart",
      "screen_name" : "Walmart",
      "indices" : [ 21, 29 ],
      "id_str" : "17137891",
      "id" : 17137891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464809815806869504",
  "text" : "\"More companies like @Walmart are realizing that wasting less energy isn\u2019t just good for the planet. It\u2019s good for business.\" \u2014Obama",
  "id" : 464809815806869504,
  "created_at" : "2014-05-09 16:51:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "464809080084000768",
  "text" : "Happening now: President Obama speaks on new clean energy commitments \u2192 http:\/\/t.co\/b4tqL3oo0v #ActOnClimate",
  "id" : 464809080084000768,
  "created_at" : "2014-05-09 16:48:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464802222920847362",
  "text" : "FACT: Today, President Obama's taking steps to cut carbon pollution by the equivalent of taking 80 million cars off the road. #ActOnClimate",
  "id" : 464802222920847362,
  "created_at" : "2014-05-09 16:21:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464795693459472384",
  "text" : "FACT: Today's new solar commitments would deploy enough solar energy to power nearly 130,000 homes. #ActOnClimate",
  "id" : 464795693459472384,
  "created_at" : "2014-05-09 15:55:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/eel6IpfK6p",
      "expanded_url" : "http:\/\/go.wh.gov\/5wJRCj",
      "display_url" : "go.wh.gov\/5wJRCj"
    } ]
  },
  "geo" : { },
  "id_str" : "464788289510457345",
  "text" : "RT @Lubin44: \"Every 4 minutes, some small business or home owner is going solar.\" Watch \u2192 http:\/\/t.co\/eel6IpfK6p #ActOnClimate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/eel6IpfK6p",
        "expanded_url" : "http:\/\/go.wh.gov\/5wJRCj",
        "display_url" : "go.wh.gov\/5wJRCj"
      } ]
    },
    "geo" : { },
    "id_str" : "464785381435928576",
    "text" : "\"Every 4 minutes, some small business or home owner is going solar.\" Watch \u2192 http:\/\/t.co\/eel6IpfK6p #ActOnClimate",
    "id" : 464785381435928576,
    "created_at" : "2014-05-09 15:14:04 +0000",
    "user" : {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "protected" : false,
      "id_str" : "1563426390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615987325261082625\/QxtC65p2_normal.jpg",
      "id" : 1563426390,
      "verified" : true
    }
  },
  "id" : 464788289510457345,
  "created_at" : "2014-05-09 15:25:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/ILl3L1WwRr",
      "expanded_url" : "http:\/\/go.wh.gov\/6v9n7N",
      "display_url" : "go.wh.gov\/6v9n7N"
    } ]
  },
  "geo" : { },
  "id_str" : "464783318891130880",
  "text" : "President Obama's announcing more than 300 private and public solar and energy efficiency commitments \u2192 http:\/\/t.co\/ILl3L1WwRr #ActOnClimate",
  "id" : 464783318891130880,
  "created_at" : "2014-05-09 15:05:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/O5KracmHln",
      "expanded_url" : "http:\/\/go.wh.gov\/5wJRCj",
      "display_url" : "go.wh.gov\/5wJRCj"
    } ]
  },
  "geo" : { },
  "id_str" : "464777876567785472",
  "text" : "Go behind the scenes and check out the \u263C solar \u263C panels on the roof of the White House \u2192 http:\/\/t.co\/O5KracmHln #ActOnClimate",
  "id" : 464777876567785472,
  "created_at" : "2014-05-09 14:44:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 3, 17 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464537562481434625",
  "text" : "RT @TheScienceGuy: We have another report: humans are the cause: #ActOnClimate. Let's get to work.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 46, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "464528762730987521",
    "text" : "We have another report: humans are the cause: #ActOnClimate. Let's get to work.",
    "id" : 464528762730987521,
    "created_at" : "2014-05-08 22:14:22 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 464537562481434625,
  "created_at" : "2014-05-08 22:49:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/MSQhgXGka8",
      "expanded_url" : "http:\/\/go.wh.gov\/vgHpHh",
      "display_url" : "go.wh.gov\/vgHpHh"
    } ]
  },
  "geo" : { },
  "id_str" : "464505291221250048",
  "text" : "\"We're going to support you every step of the way.\" \u2014President Obama visiting tornado-damaged areas in Arkansas: http:\/\/t.co\/MSQhgXGka8",
  "id" : 464505291221250048,
  "created_at" : "2014-05-08 20:41:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BringBackOurGirls",
      "indices" : [ 49, 67 ]
    }, {
      "text" : "Nigeria",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464492675673370625",
  "text" : "RT @JohnKerry: Doing everything possible to help #BringBackOurGirls. US team hitting the ground in #Nigeria to work w\/ Pres. Jonathan.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BringBackOurGirls",
        "indices" : [ 34, 52 ]
      }, {
        "text" : "Nigeria",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "464487162507845633",
    "text" : "Doing everything possible to help #BringBackOurGirls. US team hitting the ground in #Nigeria to work w\/ Pres. Jonathan.",
    "id" : 464487162507845633,
    "created_at" : "2014-05-08 19:29:03 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 464492675673370625,
  "created_at" : "2014-05-08 19:50:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464482302563991552",
  "text" : "RT @Cecilia44: Women are primary breadwinners in 40% of households with kids. A min wage increase would improve their econ security! #WhatM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhatMothersNeed",
        "indices" : [ 118, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "464480868443381761",
    "text" : "Women are primary breadwinners in 40% of households with kids. A min wage increase would improve their econ security! #WhatMothersNeed",
    "id" : 464480868443381761,
    "created_at" : "2014-05-08 19:04:03 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 464482302563991552,
  "created_at" : "2014-05-08 19:09:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464471919295995905",
  "text" : "FACT: Since President Obama took office, we've increased the electricity we produce from \u263C solar \u263C power by more than tenfold. #ActOnClimate",
  "id" : 464471919295995905,
  "created_at" : "2014-05-08 18:28:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Weather Channel",
      "screen_name" : "weatherchannel",
      "indices" : [ 23, 38 ],
      "id_str" : "20998647",
      "id" : 20998647
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/bb3NFYdB2b",
      "expanded_url" : "http:\/\/go.wh.gov\/RD1s6K",
      "display_url" : "go.wh.gov\/RD1s6K"
    } ]
  },
  "geo" : { },
  "id_str" : "464465590879805440",
  "text" : "Starting now: Join the @WeatherChannel and the White House for a G+ Hangout on the need to #ActOnClimate \u2192 http:\/\/t.co\/bb3NFYdB2b",
  "id" : 464465590879805440,
  "created_at" : "2014-05-08 18:03:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "The Weather Channel",
      "screen_name" : "weatherchannel",
      "indices" : [ 84, 99 ],
      "id_str" : "20998647",
      "id" : 20998647
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClimateChange",
      "indices" : [ 51, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/uFmHcqSFoV",
      "expanded_url" : "http:\/\/wxch.nl\/1sq3PMh",
      "display_url" : "wxch.nl\/1sq3PMh"
    } ]
  },
  "geo" : { },
  "id_str" : "464455914880524288",
  "text" : "RT @whitehouseostp: We're taking your questions on #ClimateChange at 2pm ET live w\/ @weatherchannel \u2192 http:\/\/t.co\/uFmHcqSFoV Submit now usi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Weather Channel",
        "screen_name" : "weatherchannel",
        "indices" : [ 64, 79 ],
        "id_str" : "20998647",
        "id" : 20998647
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ClimateChange",
        "indices" : [ 31, 45 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 124, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/uFmHcqSFoV",
        "expanded_url" : "http:\/\/wxch.nl\/1sq3PMh",
        "display_url" : "wxch.nl\/1sq3PMh"
      } ]
    },
    "geo" : { },
    "id_str" : "464454960529174529",
    "text" : "We're taking your questions on #ClimateChange at 2pm ET live w\/ @weatherchannel \u2192 http:\/\/t.co\/uFmHcqSFoV Submit now using \u2192 #ActOnClimate",
    "id" : 464454960529174529,
    "created_at" : "2014-05-08 17:21:06 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 464455914880524288,
  "created_at" : "2014-05-08 17:24:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/464439764591312896\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/z1nILokdeA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnIFgS7CQAAh-wR.jpg",
      "id_str" : "464439763965984768",
      "id" : 464439763965984768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnIFgS7CQAAh-wR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/z1nILokdeA"
    } ],
    "hashtags" : [ {
      "text" : "USClimateReport",
      "indices" : [ 54, 70 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/HArBbzGtZQ",
      "expanded_url" : "http:\/\/go.wh.gov\/ohSP3y",
      "display_url" : "go.wh.gov\/ohSP3y"
    } ]
  },
  "geo" : { },
  "id_str" : "464439764591312896",
  "text" : "Watch President Obama's Science Advisor breakdown the #USClimateReport \u2192 http:\/\/t.co\/HArBbzGtZQ #ActOnClimate http:\/\/t.co\/z1nILokdeA",
  "id" : 464439764591312896,
  "created_at" : "2014-05-08 16:20:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "\u042F\u043A\u043E\u0432\u0446\u0435\u0432a \u042E\u043B\u0438\u044F",
      "screen_name" : "RMNPOfficial",
      "indices" : [ 66, 79 ],
      "id_str" : "2814678878",
      "id" : 2814678878
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/464430278039965697\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/lsJtQRWYGw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnH84BcCEAA3U9D.jpg",
      "id_str" : "464430275984756736",
      "id" : 464430275984756736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnH84BcCEAA3U9D.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lsJtQRWYGw"
    } ],
    "hashtags" : [ {
      "text" : "colorado",
      "indices" : [ 80, 89 ]
    }, {
      "text" : "nature",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464433236358467585",
  "text" : "RT @Interior: Spring has arrived in Rocky Mountain National Park! @RMNPOfficial #colorado #nature http:\/\/t.co\/lsJtQRWYGw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u042F\u043A\u043E\u0432\u0446\u0435\u0432a \u042E\u043B\u0438\u044F",
        "screen_name" : "RMNPOfficial",
        "indices" : [ 52, 65 ],
        "id_str" : "2814678878",
        "id" : 2814678878
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/464430278039965697\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/lsJtQRWYGw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnH84BcCEAA3U9D.jpg",
        "id_str" : "464430275984756736",
        "id" : 464430275984756736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnH84BcCEAA3U9D.jpg",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/lsJtQRWYGw"
      } ],
      "hashtags" : [ {
        "text" : "colorado",
        "indices" : [ 66, 75 ]
      }, {
        "text" : "nature",
        "indices" : [ 76, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "464430278039965697",
    "text" : "Spring has arrived in Rocky Mountain National Park! @RMNPOfficial #colorado #nature http:\/\/t.co\/lsJtQRWYGw",
    "id" : 464430278039965697,
    "created_at" : "2014-05-08 15:43:01 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 464433236358467585,
  "created_at" : "2014-05-08 15:54:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 5, 20 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "The Weather Channel",
      "screen_name" : "weatherchannel",
      "indices" : [ 31, 46 ],
      "id_str" : "20998647",
      "id" : 20998647
    }, {
      "name" : "Sam Champion",
      "screen_name" : "SamChampion",
      "indices" : [ 49, 61 ],
      "id_str" : "21232507",
      "id" : 21232507
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/IDRFSI8vAp",
      "expanded_url" : "http:\/\/wxch.nl\/1sq3PMh",
      "display_url" : "wxch.nl\/1sq3PMh"
    } ]
  },
  "geo" : { },
  "id_str" : "464422390932713472",
  "text" : "Join @WhiteHouseOSTP &amp; the @WeatherChannel's @SamChampion at 2pm ET for a G+ Hangout on climate change: http:\/\/t.co\/IDRFSI8vAp #ActOnClimate",
  "id" : 464422390932713472,
  "created_at" : "2014-05-08 15:11:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Weather Channel",
      "screen_name" : "weatherchannel",
      "indices" : [ 3, 18 ],
      "id_str" : "20998647",
      "id" : 20998647
    }, {
      "name" : "AMHQ",
      "screen_name" : "AMHQ",
      "indices" : [ 23, 28 ],
      "id_str" : "2325690444",
      "id" : 2325690444
    }, {
      "name" : "Sam Champion",
      "screen_name" : "SamChampion",
      "indices" : [ 107, 119 ],
      "id_str" : "21232507",
      "id" : 21232507
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464418986751700992",
  "text" : "RT @weatherchannel: MT @AMHQ: Questions on the Climate Assessment Report? Send them to #ActOnClimate! Join @SamChampion in G+ chat 2pmET! h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AMHQ",
        "screen_name" : "AMHQ",
        "indices" : [ 3, 8 ],
        "id_str" : "2325690444",
        "id" : 2325690444
      }, {
        "name" : "Sam Champion",
        "screen_name" : "SamChampion",
        "indices" : [ 87, 99 ],
        "id_str" : "21232507",
        "id" : 21232507
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 67, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/qvmk30WcPf",
        "expanded_url" : "http:\/\/wxch.nl\/1sq3PMh",
        "display_url" : "wxch.nl\/1sq3PMh"
      } ]
    },
    "geo" : { },
    "id_str" : "464399264874250240",
    "text" : "MT @AMHQ: Questions on the Climate Assessment Report? Send them to #ActOnClimate! Join @SamChampion in G+ chat 2pmET! http:\/\/t.co\/qvmk30WcPf",
    "id" : 464399264874250240,
    "created_at" : "2014-05-08 13:39:47 +0000",
    "user" : {
      "name" : "The Weather Channel",
      "screen_name" : "weatherchannel",
      "protected" : false,
      "id_str" : "20998647",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786232930108669952\/6099cLdV_normal.jpg",
      "id" : 20998647,
      "verified" : true
    }
  },
  "id" : 464418986751700992,
  "created_at" : "2014-05-08 14:58:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/464416247430791168\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/y2qTiAJCUK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnHwHatCYAAhx0D.jpg",
      "id_str" : "464416246813843456",
      "id" : 464416246813843456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnHwHatCYAAhx0D.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/y2qTiAJCUK"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/orVFa2aNyp",
      "expanded_url" : "http:\/\/go.wh.gov\/SC7YFb",
      "display_url" : "go.wh.gov\/SC7YFb"
    } ]
  },
  "geo" : { },
  "id_str" : "464416247430791168",
  "text" : "Climate change is not a distant threat. It's affecting us right now \u2192 http:\/\/t.co\/orVFa2aNyp #ActOnClimate http:\/\/t.co\/y2qTiAJCUK",
  "id" : 464416247430791168,
  "created_at" : "2014-05-08 14:47:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/464173404825092096\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/jXFs8o8Tec",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnETQH1CUAIA60D.jpg",
      "id_str" : "464173404296204290",
      "id" : 464173404296204290,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnETQH1CUAIA60D.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jXFs8o8Tec"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/3DJp8WhRI6",
      "expanded_url" : "http:\/\/go.wh.gov\/gyPnSx",
      "display_url" : "go.wh.gov\/gyPnSx"
    } ]
  },
  "geo" : { },
  "id_str" : "464173404825092096",
  "text" : "\"Your country's going to be here for you.\" \u2014Obama at the site of tornado damage in Arkansas: http:\/\/t.co\/3DJp8WhRI6 http:\/\/t.co\/jXFs8o8Tec",
  "id" : 464173404825092096,
  "created_at" : "2014-05-07 22:42:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/464148654354628608\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/glDKDotJRt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnD8vbnCUAAFdTA.jpg",
      "id_str" : "464148653414699008",
      "id" : 464148653414699008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnD8vbnCUAAFdTA.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/glDKDotJRt"
    } ],
    "hashtags" : [ {
      "text" : "BringBackOurGirls",
      "indices" : [ 93, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464149256014934016",
  "text" : "RT @FLOTUS: Our prayers are with the missing Nigerian girls and their families. It's time to #BringBackOurGirls. -mo http:\/\/t.co\/glDKDotJRt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/464148654354628608\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/glDKDotJRt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnD8vbnCUAAFdTA.jpg",
        "id_str" : "464148653414699008",
        "id" : 464148653414699008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnD8vbnCUAAFdTA.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/glDKDotJRt"
      } ],
      "hashtags" : [ {
        "text" : "BringBackOurGirls",
        "indices" : [ 81, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "464148654354628608",
    "text" : "Our prayers are with the missing Nigerian girls and their families. It's time to #BringBackOurGirls. -mo http:\/\/t.co\/glDKDotJRt",
    "id" : 464148654354628608,
    "created_at" : "2014-05-07 21:03:57 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 464149256014934016,
  "created_at" : "2014-05-07 21:06:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BringBackOurGirls",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/zXYcEpGFc8",
      "expanded_url" : "http:\/\/go.wh.gov\/RL6tpr",
      "display_url" : "go.wh.gov\/RL6tpr"
    } ]
  },
  "geo" : { },
  "id_str" : "464145247828971520",
  "text" : "\"We\u2019re going to do everything we can to provide assistance.\" \u2014President Obama on helping Nigeria #BringBackOurGirls: http:\/\/t.co\/zXYcEpGFc8",
  "id" : 464145247828971520,
  "created_at" : "2014-05-07 20:50:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464127029739524098",
  "text" : "\"Your country's going to be there for you\u2026you are in our thoughts and prayers.\" \u2014President Obama to Arkansans on the recent tornado damage",
  "id" : 464127029739524098,
  "created_at" : "2014-05-07 19:38:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464126296885592066",
  "text" : "\"Folks here are tough. They look out for one another. And that's been especially true this past week.\" \u2014President Obama in Arkansas",
  "id" : 464126296885592066,
  "created_at" : "2014-05-07 19:35:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "464125661297532928",
  "text" : "Happening now: President Obama speaks in Arkansas at the site of the recent tornado damage \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 464125661297532928,
  "created_at" : "2014-05-07 19:32:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/82tyuVVmeb",
      "expanded_url" : "http:\/\/go.wh.gov\/ohSP3y",
      "display_url" : "go.wh.gov\/ohSP3y"
    } ]
  },
  "geo" : { },
  "id_str" : "464118131141525504",
  "text" : "Due to climate change, people are experiencing changes in the length &amp; severity of seasonal allergies \u2192 http:\/\/t.co\/82tyuVVmeb #ActOnClimate",
  "id" : 464118131141525504,
  "created_at" : "2014-05-07 19:02:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 3, 11 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 84, 97 ]
    }, {
      "text" : "WHClimateChat",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464099310783959041",
  "text" : "RT @Utech44: At 2pm ET, I'll answer your Q's on the NCA and the President's plan to #ActOnClimate. Ask away using #WHClimateChat: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 71, 84 ]
      }, {
        "text" : "WHClimateChat",
        "indices" : [ 101, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tKB52Do4m1",
        "expanded_url" : "http:\/\/wh.gov\/climate-change",
        "display_url" : "wh.gov\/climate-change"
      } ]
    },
    "geo" : { },
    "id_str" : "464099211588677632",
    "text" : "At 2pm ET, I'll answer your Q's on the NCA and the President's plan to #ActOnClimate. Ask away using #WHClimateChat: http:\/\/t.co\/tKB52Do4m1",
    "id" : 464099211588677632,
    "created_at" : "2014-05-07 17:47:29 +0000",
    "user" : {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "protected" : false,
      "id_str" : "2283772130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705138779221135360\/UcDKamCq_normal.jpg",
      "id" : 2283772130,
      "verified" : true
    }
  },
  "id" : 464099310783959041,
  "created_at" : "2014-05-07 17:47:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "US Fish and Wildlife",
      "screen_name" : "USFWSNortheast",
      "indices" : [ 110, 125 ],
      "id_str" : "59184319",
      "id" : 59184319
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Delaware",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464089105173712896",
  "text" : "RT @Interior: May is National Wetlands Month. Let's celebrate with a photo from Bombay Hook NWR in #Delaware. @USFWSNortheast http:\/\/t.co\/E\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Fish and Wildlife",
        "screen_name" : "USFWSNortheast",
        "indices" : [ 96, 111 ],
        "id_str" : "59184319",
        "id" : 59184319
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/464065486720729088\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/EqewtvMjCu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnCxGQGCIAAWjSz.jpg",
        "id_str" : "464065482576764928",
        "id" : 464065482576764928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnCxGQGCIAAWjSz.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/EqewtvMjCu"
      } ],
      "hashtags" : [ {
        "text" : "Delaware",
        "indices" : [ 85, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "464065486720729088",
    "text" : "May is National Wetlands Month. Let's celebrate with a photo from Bombay Hook NWR in #Delaware. @USFWSNortheast http:\/\/t.co\/EqewtvMjCu",
    "id" : 464065486720729088,
    "created_at" : "2014-05-07 15:33:28 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 464089105173712896,
  "created_at" : "2014-05-07 17:07:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYT Graphics",
      "screen_name" : "nytgraphics",
      "indices" : [ 3, 15 ],
      "id_str" : "86640232",
      "id" : 86640232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/9WTyXH60it",
      "expanded_url" : "http:\/\/nyti.ms\/1lYnb9b",
      "display_url" : "nyti.ms\/1lYnb9b"
    } ]
  },
  "geo" : { },
  "id_str" : "464082560143073280",
  "text" : "RT @nytgraphics: Map of rising temperatures across the US on A1 of today's print NYT. Web version at http:\/\/t.co\/9WTyXH60it http:\/\/t.co\/lgz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nytgraphics\/status\/464051940683284480\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/lgz6pNlXRb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnCkx4gCAAAyr0B.png",
        "id_str" : "464051938506440704",
        "id" : 464051938506440704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnCkx4gCAAAyr0B.png",
        "sizes" : [ {
          "h" : 565,
          "resize" : "fit",
          "w" : 844
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 844
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/lgz6pNlXRb"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/9WTyXH60it",
        "expanded_url" : "http:\/\/nyti.ms\/1lYnb9b",
        "display_url" : "nyti.ms\/1lYnb9b"
      } ]
    },
    "geo" : { },
    "id_str" : "464051940683284480",
    "text" : "Map of rising temperatures across the US on A1 of today's print NYT. Web version at http:\/\/t.co\/9WTyXH60it http:\/\/t.co\/lgz6pNlXRb",
    "id" : 464051940683284480,
    "created_at" : "2014-05-07 14:39:38 +0000",
    "user" : {
      "name" : "NYT Graphics",
      "screen_name" : "nytgraphics",
      "protected" : false,
      "id_str" : "86640232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2037777108\/TEMP-Image_1_6_normal.png",
      "id" : 86640232,
      "verified" : false
    }
  },
  "id" : 464082560143073280,
  "created_at" : "2014-05-07 16:41:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Roberts",
      "screen_name" : "RobinRoberts",
      "indices" : [ 3, 16 ],
      "id_str" : "267921808",
      "id" : 267921808
    }, {
      "name" : "Michael Sam",
      "screen_name" : "MikeSamFootball",
      "indices" : [ 35, 51 ],
      "id_str" : "2491816728",
      "id" : 2491816728
    }, {
      "name" : "ESPYS",
      "screen_name" : "ESPYS",
      "indices" : [ 93, 99 ],
      "id_str" : "40104936",
      "id" : 40104936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464076952723136513",
  "text" : "RT @RobinRoberts: Happy to welcome @MikeSamFootball to the Ashe Courage Award family at 2014 @ESPYS . His courage inspires so many. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Sam",
        "screen_name" : "MikeSamFootball",
        "indices" : [ 17, 33 ],
        "id_str" : "2491816728",
        "id" : 2491816728
      }, {
        "name" : "ESPYS",
        "screen_name" : "ESPYS",
        "indices" : [ 75, 81 ],
        "id_str" : "40104936",
        "id" : 40104936
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RobinRoberts\/status\/464023382200049665\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/ZXT16wjqld",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BnCKzoCIMAAFjBf.jpg",
        "id_str" : "464023381143465984",
        "id" : 464023381143465984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnCKzoCIMAAFjBf.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/ZXT16wjqld"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "464023382200049665",
    "text" : "Happy to welcome @MikeSamFootball to the Ashe Courage Award family at 2014 @ESPYS . His courage inspires so many. http:\/\/t.co\/ZXT16wjqld",
    "id" : 464023382200049665,
    "created_at" : "2014-05-07 12:46:10 +0000",
    "user" : {
      "name" : "Robin Roberts",
      "screen_name" : "RobinRoberts",
      "protected" : false,
      "id_str" : "267921808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456076015261863936\/lJuO4EoP_normal.jpeg",
      "id" : 267921808,
      "verified" : true
    }
  },
  "id" : 464076952723136513,
  "created_at" : "2014-05-07 16:19:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 90, 98 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/B2jZJ7jy6l",
      "expanded_url" : "http:\/\/nyti.ms\/1ihAb8M",
      "display_url" : "nyti.ms\/1ihAb8M"
    } ]
  },
  "geo" : { },
  "id_str" : "464069524581793792",
  "text" : "\"The effects of human-induced climate change are being felt in every corner of the U.S.\" \u2014@NYTimes: http:\/\/t.co\/B2jZJ7jy6l #ActOnClimate",
  "id" : 464069524581793792,
  "created_at" : "2014-05-07 15:49:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/orVFa2aNyp",
      "expanded_url" : "http:\/\/go.wh.gov\/SC7YFb",
      "display_url" : "go.wh.gov\/SC7YFb"
    } ]
  },
  "geo" : { },
  "id_str" : "464060959758503936",
  "text" : "FACT: By 2030, new clean fuel standards will prevent up to 2,000 premature deaths every year \u2192 http:\/\/t.co\/orVFa2aNyp #ActOnClimate",
  "id" : 464060959758503936,
  "created_at" : "2014-05-07 15:15:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 66, 74 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 47, 60 ]
    }, {
      "text" : "WHClimateChat",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/cxuiuKdq4H",
      "expanded_url" : "http:\/\/go.wh.gov\/pJChx9",
      "display_url" : "go.wh.gov\/pJChx9"
    } ]
  },
  "geo" : { },
  "id_str" : "464049149315272705",
  "text" : "Have questions about President Obama's plan to #ActOnClimate? Ask @Utech44 with #WHClimateChat before his 2pm ET Q&amp;A: http:\/\/t.co\/cxuiuKdq4H",
  "id" : 464049149315272705,
  "created_at" : "2014-05-07 14:28:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/464038562850025474\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/d1TTf3uuQq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BnCYnQGCUAAjCEK.jpg",
      "id_str" : "464038561721765888",
      "id" : 464038561721765888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BnCYnQGCUAAjCEK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/d1TTf3uuQq"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/qbl6fRe1ZB",
      "expanded_url" : "http:\/\/go.wh.gov\/SC7YFb",
      "display_url" : "go.wh.gov\/SC7YFb"
    } ]
  },
  "geo" : { },
  "id_str" : "464038562850025474",
  "text" : "FACT: Every 4 minutes, another American home or business goes \u263C solar \u263C \u2192 http:\/\/t.co\/qbl6fRe1ZB #ActOnClimate http:\/\/t.co\/d1TTf3uuQq",
  "id" : 464038562850025474,
  "created_at" : "2014-05-07 13:46:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/463816538252795905\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/Bk9OzOkLBQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm_OrumCUAAfYNM.jpg",
      "id_str" : "463816537279713280",
      "id" : 463816537279713280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm_OrumCUAAfYNM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Bk9OzOkLBQ"
    } ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 41, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463816538252795905",
  "text" : "Happy National Teacher Appreciation Day! #ThankATeacher http:\/\/t.co\/Bk9OzOkLBQ",
  "id" : 463816538252795905,
  "created_at" : "2014-05-06 23:04:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/qbl6fRe1ZB",
      "expanded_url" : "http:\/\/go.wh.gov\/SC7YFb",
      "display_url" : "go.wh.gov\/SC7YFb"
    } ]
  },
  "geo" : { },
  "id_str" : "463792452323647490",
  "text" : "FACT: \u263C Solar \u263C power is more affordable than ever: The average cost of solar panels has dropped 60% since 2010. http:\/\/t.co\/qbl6fRe1ZB",
  "id" : 463792452323647490,
  "created_at" : "2014-05-06 21:28:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Nutter",
      "screen_name" : "Michael_Nutter",
      "indices" : [ 18, 33 ],
      "id_str" : "202790178",
      "id" : 202790178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/McySn8HhHd",
      "expanded_url" : "http:\/\/cbsloc.al\/1jxRRNF",
      "display_url" : "cbsloc.al\/1jxRRNF"
    } ]
  },
  "geo" : { },
  "id_str" : "463781287237414912",
  "text" : "Great news: Mayor @Michael_Nutter just raised the minimum wage for city contract workers in Philly: http:\/\/t.co\/McySn8HhHd #RaiseTheWage",
  "id" : 463781287237414912,
  "created_at" : "2014-05-06 20:44:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/463774461964333056\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ovGugt6Sqx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm-oal4CAAAsXFx.jpg",
      "id_str" : "463774461439639552",
      "id" : 463774461439639552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm-oal4CAAAsXFx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ovGugt6Sqx"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 51, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/orVFa2aNyp",
      "expanded_url" : "http:\/\/go.wh.gov\/SC7YFb",
      "display_url" : "go.wh.gov\/SC7YFb"
    } ]
  },
  "geo" : { },
  "id_str" : "463774461964333056",
  "text" : "RT if you agree with President Obama: It's time to #ActOnClimate change \u2192 http:\/\/t.co\/orVFa2aNyp http:\/\/t.co\/ovGugt6Sqx",
  "id" : 463774461964333056,
  "created_at" : "2014-05-06 20:17:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/463760475117731842\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/uztwYSJBVq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm-bschCQAAFQur.jpg",
      "id_str" : "463760474513752064",
      "id" : 463760474513752064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm-bschCQAAFQur.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uztwYSJBVq"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 25, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/qbl6fRe1ZB",
      "expanded_url" : "http:\/\/go.wh.gov\/SC7YFb",
      "display_url" : "go.wh.gov\/SC7YFb"
    } ]
  },
  "geo" : { },
  "id_str" : "463760475117731842",
  "text" : "We owe it to our kids to #ActOnClimate change. Share President Obama's plan \u2192 http:\/\/t.co\/qbl6fRe1ZB http:\/\/t.co\/uztwYSJBVq",
  "id" : 463760475117731842,
  "created_at" : "2014-05-06 19:21:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/oAj9k4uaGg",
      "expanded_url" : "http:\/\/GlobalChange.gov",
      "display_url" : "GlobalChange.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "463746529589612544",
  "text" : "Check out the new National Climate Assessment: A region-by-region breakdown of climate change impacts \u2192 http:\/\/t.co\/oAj9k4uaGg #ActOnClimate",
  "id" : 463746529589612544,
  "created_at" : "2014-05-06 18:26:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/82tyuVVmeb",
      "expanded_url" : "http:\/\/go.wh.gov\/ohSP3y",
      "display_url" : "go.wh.gov\/ohSP3y"
    } ]
  },
  "geo" : { },
  "id_str" : "463740204000366592",
  "text" : "FACT: Wildfires are starting earlier in the Spring and continuing later into the Fall \u2192 http:\/\/t.co\/82tyuVVmeb #ActOnClimate",
  "id" : 463740204000366592,
  "created_at" : "2014-05-06 18:00:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/463729908481794049\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/QtfUmzjevC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm9_5PFCAAAGePw.jpg",
      "id_str" : "463729907919355904",
      "id" : 463729907919355904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm9_5PFCAAAGePw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QtfUmzjevC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/6egN6ZP54H",
      "expanded_url" : "http:\/\/go.wh.gov\/rrb4Th",
      "display_url" : "go.wh.gov\/rrb4Th"
    } ]
  },
  "geo" : { },
  "id_str" : "463729908481794049",
  "text" : "The last decade was the hottest ever. See how climate change is making weather more extreme \u2192 http:\/\/t.co\/6egN6ZP54H http:\/\/t.co\/QtfUmzjevC",
  "id" : 463729908481794049,
  "created_at" : "2014-05-06 17:20:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/wFzhyDsRPM",
      "expanded_url" : "http:\/\/globalchange.gov",
      "display_url" : "globalchange.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "463728058252664833",
  "text" : "RT @Lehrich44: You can visit http:\/\/t.co\/wFzhyDsRPM now and find out how climate change is affecting your community #ActOnClimate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/wFzhyDsRPM",
        "expanded_url" : "http:\/\/globalchange.gov",
        "display_url" : "globalchange.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "463658727238017024",
    "text" : "You can visit http:\/\/t.co\/wFzhyDsRPM now and find out how climate change is affecting your community #ActOnClimate",
    "id" : 463658727238017024,
    "created_at" : "2014-05-06 12:37:09 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 463728058252664833,
  "created_at" : "2014-05-06 17:12:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463726148200185857",
  "text" : "RT @FLOTUS: Thanks to all the teachers out there who are helping students #ReachHigher and achieve their dreams. You're incredible! #ThankA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 62, 74 ]
      }, {
        "text" : "ThankATeacher",
        "indices" : [ 120, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "463707910401687552",
    "text" : "Thanks to all the teachers out there who are helping students #ReachHigher and achieve their dreams. You're incredible! #ThankATeacher \u2013mo",
    "id" : 463707910401687552,
    "created_at" : "2014-05-06 15:52:35 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 463726148200185857,
  "created_at" : "2014-05-06 17:05:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/463710267076263936\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/dSXq8dSAHx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm9uB9MCEAAMWlX.jpg",
      "id_str" : "463710266526404608",
      "id" : 463710266526404608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm9uB9MCEAAMWlX.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dSXq8dSAHx"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463710267076263936",
  "text" : "Extreme weather disasters fueled by climate change cost our economy more than $100 billion in 2012. #ActOnClimate http:\/\/t.co\/dSXq8dSAHx",
  "id" : 463710267076263936,
  "created_at" : "2014-05-06 16:01:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/82tyuVVmeb",
      "expanded_url" : "http:\/\/go.wh.gov\/ohSP3y",
      "display_url" : "go.wh.gov\/ohSP3y"
    } ]
  },
  "geo" : { },
  "id_str" : "463707645971427328",
  "text" : "Summers are getting longer and hotter with longer periods of extended heat. It's time to #ActOnClimate \u2192 http:\/\/t.co\/82tyuVVmeb",
  "id" : 463707645971427328,
  "created_at" : "2014-05-06 15:51:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/orVFa2aNyp",
      "expanded_url" : "http:\/\/go.wh.gov\/SC7YFb",
      "display_url" : "go.wh.gov\/SC7YFb"
    } ]
  },
  "geo" : { },
  "id_str" : "463694686650392576",
  "text" : "Climate change is not a distant threat, it's affecting us right now. Here's why it's time to #ActOnClimate \u2192 http:\/\/t.co\/orVFa2aNyp",
  "id" : 463694686650392576,
  "created_at" : "2014-05-06 15:00:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463683116209803265",
  "text" : "RT @Podesta44: 300 scientists, 4 years, 1 call to #ActOnClimate. Learn how climate change affects your community &amp; the economy at http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 35, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/c2ADcptnD8",
        "expanded_url" : "http:\/\/globalchange.gov",
        "display_url" : "globalchange.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "463674266328649728",
    "text" : "300 scientists, 4 years, 1 call to #ActOnClimate. Learn how climate change affects your community &amp; the economy at http:\/\/t.co\/c2ADcptnD8",
    "id" : 463674266328649728,
    "created_at" : "2014-05-06 13:38:54 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 463683116209803265,
  "created_at" : "2014-05-06 14:14:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Jn5OGyc8oj",
      "expanded_url" : "http:\/\/GlobalChange.gov",
      "display_url" : "GlobalChange.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "463674861219762177",
  "text" : "New report: Here's how climate change threatens regions across the U.S. and key sectors of our economy: http:\/\/t.co\/Jn5OGyc8oj #ActOnClimate",
  "id" : 463674861219762177,
  "created_at" : "2014-05-06 13:41:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 81, 99 ]
    }, {
      "text" : "YearOfAction",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/9v7Z9uPX8S",
      "expanded_url" : "http:\/\/youtu.be\/MMLE__d10Xo",
      "display_url" : "youtu.be\/MMLE__d10Xo"
    } ]
  },
  "geo" : { },
  "id_str" : "463447487978958849",
  "text" : "This year, President Obama has taken more than 20 actions and counting to expand #OpportunityForAll \u2192 http:\/\/t.co\/9v7Z9uPX8S #YearOfAction",
  "id" : 463447487978958849,
  "created_at" : "2014-05-05 22:37:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FelizCincoDeMayo",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463437497637548032",
  "text" : "President Obama: \"Today, on Cinco de Mayo, we celebrate our shared heritage, our shared history, and our shared future.\" #FelizCincoDeMayo",
  "id" : 463437497637548032,
  "created_at" : "2014-05-05 21:58:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnCIR",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463436626379939840",
  "text" : "President Obama to House Republicans: \"Say yes to commonsense reform that fixes our broken immigration system.\" #ActOnCIR",
  "id" : 463436626379939840,
  "created_at" : "2014-05-05 21:54:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 1, 19 ]
    }, {
      "text" : "ImmigrationReform",
      "indices" : [ 104, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463436000514277378",
  "text" : "\"#OpportunityForAll is why I\u2019m fighting so hard to fix our broken immigration system.\" \u2014President Obama #ImmigrationReform",
  "id" : 463436000514277378,
  "created_at" : "2014-05-05 21:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 15, 28 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 55, 66 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FelizCincoDeMayo",
      "indices" : [ 91, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463435433888993280",
  "text" : "\"Bienvenidos a @LaCasaBlanca!\" \u2014President Obama at the @WhiteHouse Cinco de Mayo Reception #FelizCincoDeMayo",
  "id" : 463435433888993280,
  "created_at" : "2014-05-05 21:49:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FelizCincoDeMayo",
      "indices" : [ 80, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "463434968405131264",
  "text" : "Happening now: President Obama speaks on Cinco de Mayo \u2192 http:\/\/t.co\/b4tqL3oo0v #FelizCincoDeMayo",
  "id" : 463434968405131264,
  "created_at" : "2014-05-05 21:48:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 53, 72 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 73, 82 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/9v7Z9uPX8S",
      "expanded_url" : "http:\/\/youtu.be\/MMLE__d10Xo",
      "display_url" : "youtu.be\/MMLE__d10Xo"
    } ]
  },
  "geo" : { },
  "id_str" : "463425123421544448",
  "text" : "In 2014, President Obama has acted on:\nManufacturing\n#CollegeOpportunity\n#EqualPay\n#RaiseTheWage\nAnd more \u2192 http:\/\/t.co\/9v7Z9uPX8S",
  "id" : 463425123421544448,
  "created_at" : "2014-05-05 21:08:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 80, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/qFOCfWVr4o",
      "expanded_url" : "http:\/\/instagram.com\/p\/noLMkAFwZI\/",
      "display_url" : "instagram.com\/p\/noLMkAFwZI\/"
    } ]
  },
  "geo" : { },
  "id_str" : "463408614997495809",
  "text" : "RT @VP: \u201CWe have got to get 11 million people out of the shadows.\" \u2013VP Biden on #ImmigrationReform. http:\/\/t.co\/qFOCfWVr4o http:\/\/t.co\/Zlci\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/463408266077167616\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ZlcifsFHZY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm5bXN4CYAAljow.png",
        "id_str" : "463408266085556224",
        "id" : 463408266085556224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm5bXN4CYAAljow.png",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ZlcifsFHZY"
      } ],
      "hashtags" : [ {
        "text" : "ImmigrationReform",
        "indices" : [ 72, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/qFOCfWVr4o",
        "expanded_url" : "http:\/\/instagram.com\/p\/noLMkAFwZI\/",
        "display_url" : "instagram.com\/p\/noLMkAFwZI\/"
      } ]
    },
    "geo" : { },
    "id_str" : "463408266077167616",
    "text" : "\u201CWe have got to get 11 million people out of the shadows.\" \u2013VP Biden on #ImmigrationReform. http:\/\/t.co\/qFOCfWVr4o http:\/\/t.co\/ZlcifsFHZY",
    "id" : 463408266077167616,
    "created_at" : "2014-05-05 20:01:55 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 463408614997495809,
  "created_at" : "2014-05-05 20:03:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 46, 51 ],
      "id_str" : "14293310",
      "id" : 14293310
    }, {
      "name" : "Joshua Tree NP",
      "screen_name" : "joshuatreenp",
      "indices" : [ 95, 108 ],
      "id_str" : "3825684196",
      "id" : 3825684196
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/463341838582444032\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/F4DS5Xv9vq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm4e8KIIUAAhaTX.jpg",
      "id_str" : "463341830525177856",
      "id" : 463341830525177856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm4e8KIIUAAhaTX.jpg",
      "sizes" : [ {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 572,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/F4DS5Xv9vq"
    } ],
    "hashtags" : [ {
      "text" : "Twitter140",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463362327136706560",
  "text" : "RT @Interior: To celebrate being named to the @TIME #Twitter140, here is an amazing photo from @JoshuaTreeNP. http:\/\/t.co\/F4DS5Xv9vq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TIME",
        "screen_name" : "TIME",
        "indices" : [ 32, 37 ],
        "id_str" : "14293310",
        "id" : 14293310
      }, {
        "name" : "Joshua Tree NP",
        "screen_name" : "joshuatreenp",
        "indices" : [ 81, 94 ],
        "id_str" : "3825684196",
        "id" : 3825684196
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/463341838582444032\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/F4DS5Xv9vq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm4e8KIIUAAhaTX.jpg",
        "id_str" : "463341830525177856",
        "id" : 463341830525177856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm4e8KIIUAAhaTX.jpg",
        "sizes" : [ {
          "h" : 335,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 572,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 572,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/F4DS5Xv9vq"
      } ],
      "hashtags" : [ {
        "text" : "Twitter140",
        "indices" : [ 38, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "463341838582444032",
    "text" : "To celebrate being named to the @TIME #Twitter140, here is an amazing photo from @JoshuaTreeNP. http:\/\/t.co\/F4DS5Xv9vq",
    "id" : 463341838582444032,
    "created_at" : "2014-05-05 15:37:57 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 463362327136706560,
  "created_at" : "2014-05-05 16:59:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAworks",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/fOPZ4stWMm",
      "expanded_url" : "http:\/\/goo.gl\/QiAUln",
      "display_url" : "goo.gl\/QiAUln"
    } ]
  },
  "geo" : { },
  "id_str" : "463354860859969536",
  "text" : "RT @NancyPelosi: America's uninsured rate has dropped to 13.4%, the lowest since 1\/2008! #ACAworks http:\/\/t.co\/fOPZ4stWMm http:\/\/t.co\/hvmBY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/463298177219563520\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/hvmBYwWHJl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm33PM7CEAIM692.png",
        "id_str" : "463298177227952130",
        "id" : 463298177227952130,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm33PM7CEAIM692.png",
        "sizes" : [ {
          "h" : 196,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hvmBYwWHJl"
      } ],
      "hashtags" : [ {
        "text" : "ACAworks",
        "indices" : [ 72, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/fOPZ4stWMm",
        "expanded_url" : "http:\/\/goo.gl\/QiAUln",
        "display_url" : "goo.gl\/QiAUln"
      } ]
    },
    "geo" : { },
    "id_str" : "463298177219563520",
    "text" : "America's uninsured rate has dropped to 13.4%, the lowest since 1\/2008! #ACAworks http:\/\/t.co\/fOPZ4stWMm http:\/\/t.co\/hvmBYwWHJl",
    "id" : 463298177219563520,
    "created_at" : "2014-05-05 12:44:27 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 463354860859969536,
  "created_at" : "2014-05-05 16:29:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 30, 46 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463349716127068160",
  "text" : "RT @vj44: Big congratulations @GovernorOMalley who signed legislation today to raise Maryland\u2019s minimum wage to $10.10. Thank you for your \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gov. Martin O'Malley",
        "screen_name" : "GovernorOMalley",
        "indices" : [ 20, 36 ],
        "id_str" : "3343532685",
        "id" : 3343532685
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "463337611772559360",
    "text" : "Big congratulations @GovernorOMalley who signed legislation today to raise Maryland\u2019s minimum wage to $10.10. Thank you for your leadership.",
    "id" : 463337611772559360,
    "created_at" : "2014-05-05 15:21:09 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 463349716127068160,
  "created_at" : "2014-05-05 16:09:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 34, 47 ]
    }, {
      "text" : "1010means",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463347190157807616",
  "text" : "RT @GovernorOMalley: We fought to #RaiseTheWage b\/c nobody who works full time should have to raise their family in poverty. #1010means a r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 13, 26 ]
      }, {
        "text" : "1010means",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "463338172622315520",
    "text" : "We fought to #RaiseTheWage b\/c nobody who works full time should have to raise their family in poverty. #1010means a raise for MD families.",
    "id" : 463338172622315520,
    "created_at" : "2014-05-05 15:23:23 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 463347190157807616,
  "created_at" : "2014-05-05 15:59:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 90, 103 ]
    }, {
      "text" : "1010Means",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463338548058267648",
  "text" : "Great news: Maryland just raised its minimum wage to $10.10.\nRT if you agree it's time to #RaiseTheWage for all Americans. #1010Means",
  "id" : 463338548058267648,
  "created_at" : "2014-05-05 15:24:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463334452299829248",
  "text" : "RT @GovernorOMalley: I just signed legislation that will raise Maryland\u2019s minimum wage to $10.10\/hr.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "463333472019689472",
    "text" : "I just signed legislation that will raise Maryland\u2019s minimum wage to $10.10\/hr.",
    "id" : 463333472019689472,
    "created_at" : "2014-05-05 15:04:42 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 463334452299829248,
  "created_at" : "2014-05-05 15:08:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/voxdotcom\/status\/463328159744524288\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/S5bQoptlFK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm4SgaDCQAAxqrT.png",
      "id_str" : "463328159622905856",
      "id" : 463328159622905856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm4SgaDCQAAxqrT.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 198,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/S5bQoptlFK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/ONuTmP5Dqo",
      "expanded_url" : "http:\/\/bit.ly\/1q6Wq6C",
      "display_url" : "bit.ly\/1q6Wq6C"
    } ]
  },
  "geo" : { },
  "id_str" : "463330450933825536",
  "text" : "RT @voxdotcom: The uninsured rate is at a six-year low: http:\/\/t.co\/ONuTmP5Dqo http:\/\/t.co\/S5bQoptlFK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/voxdotcom\/status\/463328159744524288\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/S5bQoptlFK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm4SgaDCQAAxqrT.png",
        "id_str" : "463328159622905856",
        "id" : 463328159622905856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm4SgaDCQAAxqrT.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 198,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 616
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 616
        }, {
          "h" : 349,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/S5bQoptlFK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/ONuTmP5Dqo",
        "expanded_url" : "http:\/\/bit.ly\/1q6Wq6C",
        "display_url" : "bit.ly\/1q6Wq6C"
      } ]
    },
    "geo" : { },
    "id_str" : "463328159744524288",
    "text" : "The uninsured rate is at a six-year low: http:\/\/t.co\/ONuTmP5Dqo http:\/\/t.co\/S5bQoptlFK",
    "id" : 463328159744524288,
    "created_at" : "2014-05-05 14:43:36 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 463330450933825536,
  "created_at" : "2014-05-05 14:52:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463326032595263488",
  "text" : "RT @LaborSec: I\u2019m proud of my home state of Maryland to come together to give workers a raise. I hope Congress will follow their lead. #Rai\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 121, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "463325140189974528",
    "text" : "I\u2019m proud of my home state of Maryland to come together to give workers a raise. I hope Congress will follow their lead. #RaiseTheWage",
    "id" : 463325140189974528,
    "created_at" : "2014-05-05 14:31:36 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 463326032595263488,
  "created_at" : "2014-05-05 14:35:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juliet Eilperin",
      "screen_name" : "eilperin",
      "indices" : [ 43, 52 ],
      "id_str" : "118747545",
      "id" : 118747545
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "climate",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "463319638634663936",
  "text" : "RT @Podesta44: Today\u2019s #climate must-read: @eilperin\u2019s dive into the President\u2019s second-term push on mitigation and resilience. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Juliet Eilperin",
        "screen_name" : "eilperin",
        "indices" : [ 28, 37 ],
        "id_str" : "118747545",
        "id" : 118747545
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "climate",
        "indices" : [ 8, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/sarexOh22b",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/politics\/for-president-obama-a-renewed-focus-on-climate\/2014\/05\/04\/6b81412c-d144-11e3-9e25-188ebe1fa93b_story.html",
        "display_url" : "washingtonpost.com\/politics\/for-p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "463309510195806210",
    "text" : "Today\u2019s #climate must-read: @eilperin\u2019s dive into the President\u2019s second-term push on mitigation and resilience. http:\/\/t.co\/sarexOh22b",
    "id" : 463309510195806210,
    "created_at" : "2014-05-05 13:29:29 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 463319638634663936,
  "created_at" : "2014-05-05 14:09:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/463097591841177601\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Yprz3BsQMr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bm1AzieCAAAO1-G.jpg",
      "id_str" : "463097590859300864",
      "id" : 463097590859300864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bm1AzieCAAAO1-G.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Yprz3BsQMr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/8SVjmLS9tg",
      "expanded_url" : "http:\/\/go.wh.gov\/LTC64C",
      "display_url" : "go.wh.gov\/LTC64C"
    } ]
  },
  "geo" : { },
  "id_str" : "463097591841177601",
  "text" : "\"Our businesses have now created 9.2 million new jobs over 50 consecutive months.\" \u2014Obama: http:\/\/t.co\/8SVjmLS9tg http:\/\/t.co\/Yprz3BsQMr",
  "id" : 463097591841177601,
  "created_at" : "2014-05-04 23:27:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ZFXs9nIE9A",
      "expanded_url" : "http:\/\/go.wh.gov\/LTC64C",
      "display_url" : "go.wh.gov\/LTC64C"
    } ]
  },
  "geo" : { },
  "id_str" : "463000813485314049",
  "text" : "Obama: \"I'm going to take action on my own wherever I can. To grow our economy from the middle-out\u2014not the top down.\" http:\/\/t.co\/ZFXs9nIE9A",
  "id" : 463000813485314049,
  "created_at" : "2014-05-04 17:02:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ZFXs9nIE9A",
      "expanded_url" : "http:\/\/go.wh.gov\/LTC64C",
      "display_url" : "go.wh.gov\/LTC64C"
    } ]
  },
  "geo" : { },
  "id_str" : "462978163488747520",
  "text" : "Obama: \"I've brought together business leaders to help us connect more classrooms to high-speed internet.\" http:\/\/t.co\/ZFXs9nIE9A #ConnectED",
  "id" : 462978163488747520,
  "created_at" : "2014-05-04 15:32:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462783357500547072",
  "text" : "Obama: \"As we celebrate a free press tonight, our thoughts are with those in places around the globe\" who risk their lives for that freedom.",
  "id" : 462783357500547072,
  "created_at" : "2014-05-04 02:38:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/462782328797159425\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/wG4KbQ7BLn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmwiE02CEAEPBoS.jpg",
      "id_str" : "462782328012410881",
      "id" : 462782328012410881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmwiE02CEAEPBoS.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wG4KbQ7BLn"
    } ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462782328797159425",
  "text" : "The Westeros Wing. #WHCD http:\/\/t.co\/wG4KbQ7BLn",
  "id" : 462782328797159425,
  "created_at" : "2014-05-04 02:34:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/mwJTtRIvBp",
      "expanded_url" : "http:\/\/go.wh.gov\/nXqGWV",
      "display_url" : "go.wh.gov\/nXqGWV"
    } ]
  },
  "geo" : { },
  "id_str" : "462779006488948736",
  "text" : "Happening now: President Obama speaks at the White House Correspondents' Association Dinner. Watch \u2192 http:\/\/t.co\/mwJTtRIvBp",
  "id" : 462779006488948736,
  "created_at" : "2014-05-04 02:21:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/lZlbzPFwar",
      "expanded_url" : "http:\/\/go.wh.gov\/nXqGWV",
      "display_url" : "go.wh.gov\/nXqGWV"
    } ]
  },
  "geo" : { },
  "id_str" : "462748349301403648",
  "text" : "Starting soon: President Obama speaks at the White House Correspondents' Association Dinner. Watch \u2192 http:\/\/t.co\/lZlbzPFwar",
  "id" : 462748349301403648,
  "created_at" : "2014-05-04 00:19:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ZFXs9nIE9A",
      "expanded_url" : "http:\/\/go.wh.gov\/LTC64C",
      "display_url" : "go.wh.gov\/LTC64C"
    } ]
  },
  "geo" : { },
  "id_str" : "462668870432460800",
  "text" : "\"I acted to encourage more pay transparency and strengthen enforcement of #EqualPay laws.\" \u2014President Obama: http:\/\/t.co\/ZFXs9nIE9A",
  "id" : 462668870432460800,
  "created_at" : "2014-05-03 19:03:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ZFXs9nIE9A",
      "expanded_url" : "http:\/\/go.wh.gov\/LTC64C",
      "display_url" : "go.wh.gov\/LTC64C"
    } ]
  },
  "geo" : { },
  "id_str" : "462643450471383041",
  "text" : "Obama: \"So far this year, Republicans in Congress have blocked or voted down every serious idea to create jobs.\" http:\/\/t.co\/ZFXs9nIE9A",
  "id" : 462643450471383041,
  "created_at" : "2014-05-03 17:22:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ZFXs9nIE9A",
      "expanded_url" : "http:\/\/go.wh.gov\/LTC64C",
      "display_url" : "go.wh.gov\/LTC64C"
    } ]
  },
  "geo" : { },
  "id_str" : "462600164037775362",
  "text" : "President Obama's Weekly Address: The President's Year of Action \u2192 http:\/\/t.co\/ZFXs9nIE9A",
  "id" : 462600164037775362,
  "created_at" : "2014-05-03 14:30:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/462365100834557953\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Z4OYs5BIk5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmqmm-oCAAAWv_u.jpg",
      "id_str" : "462365100335038464",
      "id" : 462365100335038464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmqmm-oCAAAWv_u.jpg",
      "sizes" : [ {
        "h" : 1100,
        "resize" : "fit",
        "w" : 733
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 733
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Z4OYs5BIk5"
    } ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462365100834557953",
  "text" : "RT if you agree with President Obama: It's time to help all our kids #ReachHigher and complete their education. http:\/\/t.co\/Z4OYs5BIk5",
  "id" : 462365100834557953,
  "created_at" : "2014-05-02 22:56:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/462232290467119104\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/RV18TpzznY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmot0VjCAAAjVH1.jpg",
      "id_str" : "462232288919420928",
      "id" : 462232288919420928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmot0VjCAAAjVH1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RV18TpzznY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/r9sqVmWFUX",
      "expanded_url" : "http:\/\/go.wh.gov\/ZgRrgA",
      "display_url" : "go.wh.gov\/ZgRrgA"
    } ]
  },
  "geo" : { },
  "id_str" : "462328367862124545",
  "text" : "Good news: Our businesses have added 9.2 million jobs over 50 straight months of job growth. http:\/\/t.co\/r9sqVmWFUX, http:\/\/t.co\/RV18TpzznY",
  "id" : 462328367862124545,
  "created_at" : "2014-05-02 20:30:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/WhCz0MiyO9",
      "expanded_url" : "http:\/\/go.wh.gov\/ZgRrgA",
      "display_url" : "go.wh.gov\/ZgRrgA"
    } ]
  },
  "geo" : { },
  "id_str" : "462311001996935168",
  "text" : "FACT: Our construction sector added 32,000 jobs in April, and 124,000 over the last 4 months. http:\/\/t.co\/WhCz0MiyO9 #MadeInAmerica",
  "id" : 462311001996935168,
  "created_at" : "2014-05-02 19:21:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462290409268707328",
  "text" : "RT @FLOTUS: \"We\u2019re asking everyone to take a picture in their college T-shirt and...tweet it with the hashtag #ReachHigher.\" \u2014The First Lady",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 98, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "462288984849547264",
    "text" : "\"We\u2019re asking everyone to take a picture in their college T-shirt and...tweet it with the hashtag #ReachHigher.\" \u2014The First Lady",
    "id" : 462288984849547264,
    "created_at" : "2014-05-02 17:54:17 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 462290409268707328,
  "created_at" : "2014-05-02 17:59:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/462288135733653504\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/akKXVQBX7U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmpgm8hIEAAEhim.jpg",
      "id_str" : "462288133955260416",
      "id" : 462288133955260416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmpgm8hIEAAEhim.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/akKXVQBX7U"
    } ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462289761970159616",
  "text" : "RT @FLOTUS: \"At the end of the day, the most important person in your education is you.\" \u2014The First Lady #ReachHigher http:\/\/t.co\/akKXVQBX7U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/462288135733653504\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/akKXVQBX7U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmpgm8hIEAAEhim.jpg",
        "id_str" : "462288133955260416",
        "id" : 462288133955260416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmpgm8hIEAAEhim.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/akKXVQBX7U"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 93, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "462288135733653504",
    "text" : "\"At the end of the day, the most important person in your education is you.\" \u2014The First Lady #ReachHigher http:\/\/t.co\/akKXVQBX7U",
    "id" : 462288135733653504,
    "created_at" : "2014-05-02 17:50:55 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 462289761970159616,
  "created_at" : "2014-05-02 17:57:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 3, 15 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462275249380552705",
  "text" : "RT @ReachHigher: The First Lady just landed in San Antonio wearing her Princeton t-shirt to attend College Signing Day. #ReachHigher http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ReachHigher\/status\/462273079008174080\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/cllR2JMhb6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BmpS6n0CEAAp4NO.jpg",
        "id_str" : "462273078832009216",
        "id" : 462273078832009216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmpS6n0CEAAp4NO.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/cllR2JMhb6"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "462273079008174080",
    "text" : "The First Lady just landed in San Antonio wearing her Princeton t-shirt to attend College Signing Day. #ReachHigher http:\/\/t.co\/cllR2JMhb6",
    "id" : 462273079008174080,
    "created_at" : "2014-05-02 16:51:05 +0000",
    "user" : {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "protected" : false,
      "id_str" : "2461821548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508240407688663040\/El8GILjl_normal.jpeg",
      "id" : 2461821548,
      "verified" : true
    }
  },
  "id" : 462275249380552705,
  "created_at" : "2014-05-02 16:59:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462269336082993153",
  "text" : "\u201CThe Ukrainian government has shown remarkable restraint throughout this whole process.\u201D \u2014President Obama #Ukraine",
  "id" : 462269336082993153,
  "created_at" : "2014-05-02 16:36:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462263716575444992",
  "text" : "\"Russia\u2019s actions in #Ukraine are making an already weak Russian economy even weaker.\" \u2014President Obama",
  "id" : 462263716575444992,
  "created_at" : "2014-05-02 16:13:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462263522626256896",
  "text" : "\"As both Angela and I have repeatedly said, we want to see a diplomatic resolution to the situation in #Ukraine.\" \u2014President Obama",
  "id" : 462263522626256896,
  "created_at" : "2014-05-02 16:13:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462263063140651009",
  "text" : "\"We are united in our determination to impose costs on Russia for its actions, including through coordinated sanctions.\" \u2014Obama #Ukraine",
  "id" : 462263063140651009,
  "created_at" : "2014-05-02 16:11:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462262475543420928",
  "text" : "Obama: \"I\u2019ll keep acting on my own whenever I can to make sure every American who works hard has the chance to get ahead\" #OpportunityForAll",
  "id" : 462262475543420928,
  "created_at" : "2014-05-02 16:08:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/462262252301987840\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/qCDi4ASV3Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmpJEZbCAAAmWtZ.jpg",
      "id_str" : "462262251651465216",
      "id" : 462262251651465216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmpJEZbCAAAmWtZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qCDi4ASV3Z"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462262252301987840",
  "text" : "\"Our businesses created 273,000 new jobs last month.\" \u2014President Obama #ActOnJobs http:\/\/t.co\/qCDi4ASV3Z",
  "id" : 462262252301987840,
  "created_at" : "2014-05-02 16:08:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462262099788304384",
  "text" : "President Obama: \"Germany is one of our strongest allies, and Angela is one my closest partners.\"",
  "id" : 462262099788304384,
  "created_at" : "2014-05-02 16:07:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/E8TUzLtIQo",
      "expanded_url" : "http:\/\/go.wh.gov\/EhBUdK",
      "display_url" : "go.wh.gov\/EhBUdK"
    } ]
  },
  "geo" : { },
  "id_str" : "462261988207648768",
  "text" : "Happening now: President Obama holds a press conference with German Chancellor Merkel. Watch \u2192 http:\/\/t.co\/E8TUzLtIQo",
  "id" : 462261988207648768,
  "created_at" : "2014-05-02 16:07:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 28, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/pyDCQVTNY8",
      "expanded_url" : "http:\/\/1.usa.gov\/1ktvSp8",
      "display_url" : "1.usa.gov\/1ktvSp8"
    } ]
  },
  "geo" : { },
  "id_str" : "462255966000406528",
  "text" : "RT @Simas44: State-by-state #ACA enrollment numbers were huge \u2013 see how many in your state: http:\/\/t.co\/pyDCQVTNY8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 15, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/pyDCQVTNY8",
        "expanded_url" : "http:\/\/1.usa.gov\/1ktvSp8",
        "display_url" : "1.usa.gov\/1ktvSp8"
      } ]
    },
    "geo" : { },
    "id_str" : "462255393469911041",
    "text" : "State-by-state #ACA enrollment numbers were huge \u2013 see how many in your state: http:\/\/t.co\/pyDCQVTNY8",
    "id" : 462255393469911041,
    "created_at" : "2014-05-02 15:40:48 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 462255966000406528,
  "created_at" : "2014-05-02 15:43:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/r9sqVmWFUX",
      "expanded_url" : "http:\/\/go.wh.gov\/ZgRrgA",
      "display_url" : "go.wh.gov\/ZgRrgA"
    } ]
  },
  "geo" : { },
  "id_str" : "462247831986651137",
  "text" : "FACT: Our construction sector added 32,000 jobs in April, and 124,000 over the last 4 months. http:\/\/t.co\/r9sqVmWFUX #MadeInAmerica",
  "id" : 462247831986651137,
  "created_at" : "2014-05-02 15:10:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/462232290467119104\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/RV18TpzznY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmot0VjCAAAjVH1.jpg",
      "id_str" : "462232288919420928",
      "id" : 462232288919420928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmot0VjCAAAjVH1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RV18TpzznY"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/r9sqVmWFUX",
      "expanded_url" : "http:\/\/go.wh.gov\/ZgRrgA",
      "display_url" : "go.wh.gov\/ZgRrgA"
    } ]
  },
  "geo" : { },
  "id_str" : "462240282927312901",
  "text" : "FACT: Our businesses added 273,000 jobs in April\u2014but there's more work to do: http:\/\/t.co\/r9sqVmWFUX #ActOnJobs, http:\/\/t.co\/RV18TpzznY",
  "id" : 462240282927312901,
  "created_at" : "2014-05-02 14:40:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/462232290467119104\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/RV18TpzznY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmot0VjCAAAjVH1.jpg",
      "id_str" : "462232288919420928",
      "id" : 462232288919420928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmot0VjCAAAjVH1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RV18TpzznY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462232290467119104",
  "text" : "Our businesses have added:\n9.2 million jobs over 50 months \u2714\n2.4 million in the past year \u2714\n273,000 in April \u2714\n\u2192 http:\/\/t.co\/RV18TpzznY",
  "id" : 462232290467119104,
  "created_at" : "2014-05-02 14:09:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 3, 15 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 22, 29 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462203716557619200",
  "text" : "RT @ReachHigher: Join @FLOTUS in inspiring young people to #ReachHigher and own their future! Post a photo in your school colors: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 5, 12 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 42, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/RLAGxWnyFt",
        "expanded_url" : "https:\/\/vine.co\/v\/MrXYxz0pxBa",
        "display_url" : "vine.co\/v\/MrXYxz0pxBa"
      } ]
    },
    "geo" : { },
    "id_str" : "462202692539260928",
    "text" : "Join @FLOTUS in inspiring young people to #ReachHigher and own their future! Post a photo in your school colors: https:\/\/t.co\/RLAGxWnyFt",
    "id" : 462202692539260928,
    "created_at" : "2014-05-02 12:11:23 +0000",
    "user" : {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "protected" : false,
      "id_str" : "2461821548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508240407688663040\/El8GILjl_normal.jpeg",
      "id" : 2461821548,
      "verified" : true
    }
  },
  "id" : 462203716557619200,
  "created_at" : "2014-05-02 12:15:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/462043252246732800\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/o0oCAxZB2D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BmmB45hCYAAx6PU.jpg",
      "id_str" : "462043251294232576",
      "id" : 462043251294232576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BmmB45hCYAAx6PU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/o0oCAxZB2D"
    } ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462043252246732800",
  "text" : "\"Being a teacher is a 24\/7 job &amp; yet, many say there\u2019s nothing in the world they\u2019d rather do.\" \u2014Obama #ThankATeacher http:\/\/t.co\/o0oCAxZB2D",
  "id" : 462043252246732800,
  "created_at" : "2014-05-02 01:37:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462015056499474433",
  "text" : "RT @Podesta44: Out today: our working group's 90-day review of big data and privacy. Learn more--and read the report--here: http:\/\/t.co\/8PN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/8PN9a4LQzt",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/issues\/technology\/big-data-review",
        "display_url" : "whitehouse.gov\/issues\/technol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "461965460226207744",
    "text" : "Out today: our working group's 90-day review of big data and privacy. Learn more--and read the report--here: http:\/\/t.co\/8PN9a4LQzt",
    "id" : 461965460226207744,
    "created_at" : "2014-05-01 20:28:43 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 462015056499474433,
  "created_at" : "2014-05-01 23:45:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/RfmbrIIAYD",
      "expanded_url" : "http:\/\/youtu.be\/el5kibXqmdQ",
      "display_url" : "youtu.be\/el5kibXqmdQ"
    } ]
  },
  "geo" : { },
  "id_str" : "461971005351936000",
  "text" : "\"That's why we do these things. To make sure people's daughters are OK.\" \u2014President Obama: http:\/\/t.co\/RfmbrIIAYD #ACAWorks",
  "id" : 461971005351936000,
  "created_at" : "2014-05-01 20:50:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/RfmbrIIAYD",
      "expanded_url" : "http:\/\/youtu.be\/el5kibXqmdQ",
      "display_url" : "youtu.be\/el5kibXqmdQ"
    } ]
  },
  "geo" : { },
  "id_str" : "461960015533060096",
  "text" : "Some touching moments from when President Obama met families who wrote him on how the ACA is helping them \u2192 http:\/\/t.co\/RfmbrIIAYD #ACAWorks",
  "id" : 461960015533060096,
  "created_at" : "2014-05-01 20:07:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Sebelius\/status\/461934439979692032\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/FUJFj2kYsf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmke7P0CMAA13-c.png",
      "id_str" : "461934439988080640",
      "id" : 461934439988080640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmke7P0CMAA13-c.png",
      "sizes" : [ {
        "h" : 506,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 286,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/FUJFj2kYsf"
    } ],
    "hashtags" : [ {
      "text" : "8Million",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/HXutUukb6c",
      "expanded_url" : "http:\/\/go.usa.gov\/kHck",
      "display_url" : "go.usa.gov\/kHck"
    } ]
  },
  "geo" : { },
  "id_str" : "461936595940425728",
  "text" : "RT @Sebelius: Today, health coverage is more accessible to millions of Americans: http:\/\/t.co\/HXutUukb6c #8Million http:\/\/t.co\/FUJFj2kYsf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Sebelius\/status\/461934439979692032\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/FUJFj2kYsf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bmke7P0CMAA13-c.png",
        "id_str" : "461934439988080640",
        "id" : 461934439988080640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bmke7P0CMAA13-c.png",
        "sizes" : [ {
          "h" : 506,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/FUJFj2kYsf"
      } ],
      "hashtags" : [ {
        "text" : "8Million",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/HXutUukb6c",
        "expanded_url" : "http:\/\/go.usa.gov\/kHck",
        "display_url" : "go.usa.gov\/kHck"
      } ]
    },
    "geo" : { },
    "id_str" : "461934439979692032",
    "text" : "Today, health coverage is more accessible to millions of Americans: http:\/\/t.co\/HXutUukb6c #8Million http:\/\/t.co\/FUJFj2kYsf",
    "id" : 461934439979692032,
    "created_at" : "2014-05-01 18:25:28 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 461936595940425728,
  "created_at" : "2014-05-01 18:34:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461935195621695489",
  "text" : "\"Teachers who work hard to inspire their kids every day, they too deserve our support. Because these are our kids.\" \u2014Obama #ThankATeacher",
  "id" : 461935195621695489,
  "created_at" : "2014-05-01 18:28:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NTOY14",
      "indices" : [ 99, 106 ]
    }, {
      "text" : "ThankATeacher",
      "indices" : [ 116, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461934004636495872",
  "text" : "\"What connects them is how they challenge their kids to reach their full potential.\" \u2014Obama on the #NTOY14 honorees #ThankATeacher",
  "id" : 461934004636495872,
  "created_at" : "2014-05-01 18:23:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461933687769415680",
  "text" : "\"Being a teacher is a 24-7 job. And yet, many say there\u2019s nothing in the world they\u2019d rather do.\" \u2014President Obama #ThankATeacher",
  "id" : 461933687769415680,
  "created_at" : "2014-05-01 18:22:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461933370583576576",
  "text" : "\"That\u2019s what great teachers do. They set us on a better path. And they do it even though we ask so much of them.\" \u2014Obama #ThankATeacher",
  "id" : 461933370583576576,
  "created_at" : "2014-05-01 18:21:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 91, 105 ]
    }, {
      "text" : "NTOY14",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461933010393497600",
  "text" : "\"Today is a chance for us to say thank you to all of America\u2019s teachers.\" \u2014President Obama #ThankATeacher #NTOY14",
  "id" : 461933010393497600,
  "created_at" : "2014-05-01 18:19:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NTOY14",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "ThankATeacher",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/WnrodFYTBe",
      "expanded_url" : "http:\/\/go.wh.gov\/X7YDo2",
      "display_url" : "go.wh.gov\/X7YDo2"
    } ]
  },
  "geo" : { },
  "id_str" : "461932911798022144",
  "text" : "Watch President Obama present the National Teacher of the Year Award to Sean McComb \u2192 http:\/\/t.co\/WnrodFYTBe #NTOY14 #ThankATeacher",
  "id" : 461932911798022144,
  "created_at" : "2014-05-01 18:19:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 111, 125 ]
    }, {
      "text" : "NTOY14",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/RXsEXrzh1y",
      "expanded_url" : "http:\/\/go.wh.gov\/X7YDo2",
      "display_url" : "go.wh.gov\/X7YDo2"
    } ]
  },
  "geo" : { },
  "id_str" : "461928221672357889",
  "text" : "At 2:25pm ET, President Obama speaks at the Teacher of the Year Award Ceremony. Watch \u2192 http:\/\/t.co\/RXsEXrzh1y #ThankATeacher #NTOY14",
  "id" : 461928221672357889,
  "created_at" : "2014-05-01 18:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "LetsMove",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/IZRgPSnN03",
      "expanded_url" : "http:\/\/youtu.be\/W7jMy-OgUqY",
      "display_url" : "youtu.be\/W7jMy-OgUqY"
    } ]
  },
  "geo" : { },
  "id_str" : "461924667495026688",
  "text" : "RT @FLOTUS: Bo and Sunny lead #TeamUSA to Olympic gold during the opening ceremony of the #LetsMove Olympics\u2192 http:\/\/t.co\/IZRgPSnN03",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 18, 26 ]
      }, {
        "text" : "LetsMove",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/IZRgPSnN03",
        "expanded_url" : "http:\/\/youtu.be\/W7jMy-OgUqY",
        "display_url" : "youtu.be\/W7jMy-OgUqY"
      } ]
    },
    "geo" : { },
    "id_str" : "461924443711754240",
    "text" : "Bo and Sunny lead #TeamUSA to Olympic gold during the opening ceremony of the #LetsMove Olympics\u2192 http:\/\/t.co\/IZRgPSnN03",
    "id" : 461924443711754240,
    "created_at" : "2014-05-01 17:45:44 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 461924667495026688,
  "created_at" : "2014-05-01 17:46:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "highered",
      "indices" : [ 89, 98 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 129, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/pYuIqlZ7Ck",
      "expanded_url" : "http:\/\/go.usa.gov\/k78d",
      "display_url" : "go.usa.gov\/k78d"
    } ]
  },
  "geo" : { },
  "id_str" : "461912231173947392",
  "text" : "RT @usedgov: The First Lady wants YOU to wear your college gear on Fri May 2, to support #highered --&gt; http:\/\/t.co\/pYuIqlZ7Ck #ReachHigher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "highered",
        "indices" : [ 76, 85 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 116, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/pYuIqlZ7Ck",
        "expanded_url" : "http:\/\/go.usa.gov\/k78d",
        "display_url" : "go.usa.gov\/k78d"
      } ]
    },
    "geo" : { },
    "id_str" : "461885760207978497",
    "text" : "The First Lady wants YOU to wear your college gear on Fri May 2, to support #highered --&gt; http:\/\/t.co\/pYuIqlZ7Ck #ReachHigher",
    "id" : 461885760207978497,
    "created_at" : "2014-05-01 15:12:01 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 461912231173947392,
  "created_at" : "2014-05-01 16:57:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/t4YXerFpEj",
      "expanded_url" : "http:\/\/youtu.be\/xLdElcv5qqc",
      "display_url" : "youtu.be\/xLdElcv5qqc"
    } ]
  },
  "geo" : { },
  "id_str" : "461890592377942017",
  "text" : "RT @VP: \"We need all of you to be part of the solution. This is about respect.\" \u2014 VP on ending sexual assault: http:\/\/t.co\/t4YXerFpEj #1is2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1is2Many",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/t4YXerFpEj",
        "expanded_url" : "http:\/\/youtu.be\/xLdElcv5qqc",
        "display_url" : "youtu.be\/xLdElcv5qqc"
      } ]
    },
    "geo" : { },
    "id_str" : "461888215298113536",
    "text" : "\"We need all of you to be part of the solution. This is about respect.\" \u2014 VP on ending sexual assault: http:\/\/t.co\/t4YXerFpEj #1is2Many",
    "id" : 461888215298113536,
    "created_at" : "2014-05-01 15:21:46 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 461890592377942017,
  "created_at" : "2014-05-01 15:31:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2Many",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/wmeWSURu5r",
      "expanded_url" : "http:\/\/youtu.be\/xLdElcv5qqc",
      "display_url" : "youtu.be\/xLdElcv5qqc"
    } ]
  },
  "geo" : { },
  "id_str" : "461879144272240641",
  "text" : "\"If I saw it happening, I'd never blame her. I'd help her.\" \u2014Daniel Craig on preventing sexual assault: http:\/\/t.co\/wmeWSURu5r #1is2Many",
  "id" : 461879144272240641,
  "created_at" : "2014-05-01 14:45:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/EyNaJuhJLw",
      "expanded_url" : "http:\/\/go.wh.gov\/pepknK",
      "display_url" : "go.wh.gov\/pepknK"
    } ]
  },
  "geo" : { },
  "id_str" : "461871030357991424",
  "text" : "\"I congratulate the Iraqi people on the completion of yesterday\u2019s parliamentary elections.\" \u2014President Obama: http:\/\/t.co\/EyNaJuhJLw",
  "id" : 461871030357991424,
  "created_at" : "2014-05-01 14:13:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]