Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/wjHdkPWk",
      "expanded_url" : "http:\/\/on.wh.gov\/X0Ts",
      "display_url" : "on.wh.gov\/X0Ts"
    } ]
  },
  "geo" : { },
  "id_str" : "230488062541565952",
  "text" : "\"Discoveries in science &amp; technology not only strengthen our economy, they inspire us as a people\" -President Obama: http:\/\/t.co\/wjHdkPWk",
  "id" : 230488062541565952,
  "created_at" : "2012-08-01 02:20:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/230437072870203392\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/nLeixQvY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzKtTAACYAAzZel.jpg",
      "id_str" : "230437072878592000",
      "id" : 230437072878592000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzKtTAACYAAzZel.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nLeixQvY"
    } ],
    "hashtags" : [ {
      "text" : "PECASE",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/NxdwZTtS",
      "expanded_url" : "http:\/\/on.wh.gov\/YmuX",
      "display_url" : "on.wh.gov\/YmuX"
    } ]
  },
  "geo" : { },
  "id_str" : "230437072870203392",
  "text" : "Today President Obama honored early-career scientists &amp; engineers: http:\/\/t.co\/NxdwZTtS Congrats to 96 #PECASE winners: http:\/\/t.co\/nLeixQvY",
  "id" : 230437072870203392,
  "created_at" : "2012-07-31 22:57:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230415069454954496",
  "text" : "RT @PressSec: House &amp; Senate agreement to fund the govt is encouraging; POTUS will work w\/both parties to get a bill he can sign: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/ZOZm44oO",
        "expanded_url" : "http:\/\/1.usa.gov\/Nju8wJ",
        "display_url" : "1.usa.gov\/Nju8wJ"
      } ]
    },
    "geo" : { },
    "id_str" : "230414949669810176",
    "text" : "House &amp; Senate agreement to fund the govt is encouraging; POTUS will work w\/both parties to get a bill he can sign: http:\/\/t.co\/ZOZm44oO",
    "id" : 230414949669810176,
    "created_at" : "2012-07-31 21:29:39 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 230415069454954496,
  "created_at" : "2012-07-31 21:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 14, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/Hf0Mdrcn",
      "expanded_url" : "http:\/\/www.mcclatchydc.com\/2012\/07\/31\/158921\/an-issue-beyond-debate-congress.html",
      "display_url" : "mcclatchydc.com\/2012\/07\/31\/158\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "230358409189396480",
  "text" : "RT @VP: VP on #VAWA: \u201CCongress should pass the bipartisan version approved by the US Senate.\u201D Read the full op-ed here: http:\/\/t.co\/Hf0Mdrcn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 6, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/Hf0Mdrcn",
        "expanded_url" : "http:\/\/www.mcclatchydc.com\/2012\/07\/31\/158921\/an-issue-beyond-debate-congress.html",
        "display_url" : "mcclatchydc.com\/2012\/07\/31\/158\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "230355329496522752",
    "text" : "VP on #VAWA: \u201CCongress should pass the bipartisan version approved by the US Senate.\u201D Read the full op-ed here: http:\/\/t.co\/Hf0Mdrcn",
    "id" : 230355329496522752,
    "created_at" : "2012-07-31 17:32:45 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 230358409189396480,
  "created_at" : "2012-07-31 17:44:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/230357261611040768\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/w49mdBaD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzJktX5CAAAVi15.jpg",
      "id_str" : "230357261619429376",
      "id" : 230357261619429376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzJktX5CAAAVi15.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/w49mdBaD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/rQoaplEh",
      "expanded_url" : "http:\/\/on.wh.gov\/qL2z",
      "display_url" : "on.wh.gov\/qL2z"
    } ]
  },
  "geo" : { },
  "id_str" : "230357261611040768",
  "text" : "Photo of the Day: President Obama talks on the phone with Turkish Prime Minister Erdo\u011Fan More Pics http:\/\/t.co\/rQoaplEh http:\/\/t.co\/w49mdBaD",
  "id" : 230357261611040768,
  "created_at" : "2012-07-31 17:40:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 56, 63 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "indices" : [ 103, 115 ],
      "id_str" : "15458694",
      "id" : 15458694
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "herhealth",
      "indices" : [ 116, 126 ]
    }, {
      "text" : "womenshealth",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/9tJq5vod",
      "expanded_url" : "http:\/\/on.wh.gov\/iqIt",
      "display_url" : "on.wh.gov\/iqIt"
    } ]
  },
  "geo" : { },
  "id_str" : "230335384226238464",
  "text" : "\"Women deserve to have control over their health care\" -@HHSgov Sec Sebelius: http:\/\/t.co\/9tJq5vod via @HuffPostPol #herhealth #womenshealth",
  "id" : 230335384226238464,
  "created_at" : "2012-07-31 16:13:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 51, 57 ],
      "id_str" : "25928253",
      "id" : 25928253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womenshealth",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230321311052857344",
  "text" : "RT @HHSGov: Join a LIVE chat w\/ Sec Sebelius &amp; @WebMD to talk new preventive benefits for women. 8\/1, 1:30pm. Q's to #womenshealth h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WebMD",
        "screen_name" : "WebMD",
        "indices" : [ 39, 45 ],
        "id_str" : "25928253",
        "id" : 25928253
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "womenshealth",
        "indices" : [ 109, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/I3KChsNV",
        "expanded_url" : "http:\/\/1.usa.gov\/Mh5nHy",
        "display_url" : "1.usa.gov\/Mh5nHy"
      } ]
    },
    "geo" : { },
    "id_str" : "230301233531977728",
    "text" : "Join a LIVE chat w\/ Sec Sebelius &amp; @WebMD to talk new preventive benefits for women. 8\/1, 1:30pm. Q's to #womenshealth http:\/\/t.co\/I3KChsNV",
    "id" : 230301233531977728,
    "created_at" : "2012-07-31 13:57:47 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 230321311052857344,
  "created_at" : "2012-07-31 15:17:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230074723059519489",
  "text" : "RT @Interior: 8 year old Christopher had a really cool Make-A-wish idea. See what he was doing in Yellowstone last week. http:\/\/t.co\/AOK ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/AOKZzqdY",
        "expanded_url" : "http:\/\/instagr.am\/p\/NuGDKsAu2D\/",
        "display_url" : "instagr.am\/p\/NuGDKsAu2D\/"
      } ]
    },
    "geo" : { },
    "id_str" : "230064118109990913",
    "text" : "8 year old Christopher had a really cool Make-A-wish idea. See what he was doing in Yellowstone last week. http:\/\/t.co\/AOKZzqdY",
    "id" : 230064118109990913,
    "created_at" : "2012-07-30 22:15:34 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 230074723059519489,
  "created_at" : "2012-07-30 22:57:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 45, 55 ],
      "id_str" : "23083404",
      "id" : 23083404
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/230058898319613952\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/ft20xHbF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzFVWWACIAEgdh2.jpg",
      "id_str" : "230058898323808257",
      "id" : 230058898323808257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzFVWWACIAEgdh2.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ft20xHbF"
    } ],
    "hashtags" : [ {
      "text" : "London2012",
      "indices" : [ 63, 74 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/l640upRJ",
      "expanded_url" : "http:\/\/on.wh.gov\/Sxjo",
      "display_url" : "on.wh.gov\/Sxjo"
    } ]
  },
  "geo" : { },
  "id_str" : "230058898319613952",
  "text" : "Photo: First Lady Michelle Obama hugs LeBron @KingJames at the #London2012 #Olympics. Slideshow: http:\/\/t.co\/l640upRJ http:\/\/t.co\/ft20xHbF",
  "id" : 230058898319613952,
  "created_at" : "2012-07-30 21:54:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/230046309049049088\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/NhNpK8u5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzFJ5jUCIAEtTEj.jpg",
      "id_str" : "230046309053243393",
      "id" : 230046309053243393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzFJ5jUCIAEtTEj.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      } ],
      "display_url" : "pic.twitter.com\/NhNpK8u5"
    } ],
    "hashtags" : [ {
      "text" : "Medicare",
      "indices" : [ 29, 38 ]
    }, {
      "text" : "Medicaid",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/e3pk5TUs",
      "expanded_url" : "http:\/\/on.wh.gov\/XeB3",
      "display_url" : "on.wh.gov\/XeB3"
    } ]
  },
  "geo" : { },
  "id_str" : "230046309049049088",
  "text" : "From the Archives: 47 yrs of #Medicare &amp; #Medicaid: http:\/\/t.co\/e3pk5TUs Pic: Medicare Card #1 went to President Truman http:\/\/t.co\/NhNpK8u5",
  "id" : 230046309049049088,
  "created_at" : "2012-07-30 21:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 3, 9 ],
      "id_str" : "25928253",
      "id" : 25928253
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 11, 18 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hrc",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230030776681517057",
  "text" : "RT @WebMD: @HHSGov Sec. Kathleen Sebelius will answer questions Wed. on women's medical services  covered under #hrc. More info: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HHS.gov",
        "screen_name" : "HHSGov",
        "indices" : [ 0, 7 ],
        "id_str" : "44783853",
        "id" : 44783853
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hrc",
        "indices" : [ 101, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/BfejOZfX",
        "expanded_url" : "http:\/\/on.webmd.com\/N910Z6",
        "display_url" : "on.webmd.com\/N910Z6"
      } ]
    },
    "geo" : { },
    "id_str" : "229919101030658048",
    "in_reply_to_user_id" : 44783853,
    "text" : "@HHSGov Sec. Kathleen Sebelius will answer questions Wed. on women's medical services  covered under #hrc. More info: http:\/\/t.co\/BfejOZfX",
    "id" : 229919101030658048,
    "created_at" : "2012-07-30 12:39:20 +0000",
    "in_reply_to_screen_name" : "HHSGov",
    "in_reply_to_user_id_str" : "44783853",
    "user" : {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "protected" : false,
      "id_str" : "25928253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771386734760386562\/-cRW6ixT_normal.jpg",
      "id" : 25928253,
      "verified" : true
    }
  },
  "id" : 230030776681517057,
  "created_at" : "2012-07-30 20:03:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/QzoyFChQ",
      "expanded_url" : "http:\/\/wh.gov\/1mjp",
      "display_url" : "wh.gov\/1mjp"
    } ]
  },
  "geo" : { },
  "id_str" : "230013567561265152",
  "text" : "RT @vj44: President Obama just signed HEARTH Act: great news for Native American communities http:\/\/t.co\/QzoyFChQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/QzoyFChQ",
        "expanded_url" : "http:\/\/wh.gov\/1mjp",
        "display_url" : "wh.gov\/1mjp"
      } ]
    },
    "geo" : { },
    "id_str" : "230006079789080576",
    "text" : "President Obama just signed HEARTH Act: great news for Native American communities http:\/\/t.co\/QzoyFChQ",
    "id" : 230006079789080576,
    "created_at" : "2012-07-30 18:24:57 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 230013567561265152,
  "created_at" : "2012-07-30 18:54:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/g5icuVZL",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "229966585069191169",
  "text" : "RT @WHLive: Happening Now: A conversation on the Obama Administration's sub-Saharan Africa Policy Watch http:\/\/t.co\/g5icuVZL &amp; ask a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 137, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "229962763085156352",
    "text" : "Happening Now: A conversation on the Obama Administration's sub-Saharan Africa Policy Watch http:\/\/t.co\/g5icuVZL &amp; ask a question w\/ #WHChat",
    "id" : 229962763085156352,
    "created_at" : "2012-07-30 15:32:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 229966585069191169,
  "created_at" : "2012-07-30 15:48:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Venus Williams",
      "screen_name" : "Venuseswilliams",
      "indices" : [ 101, 117 ],
      "id_str" : "50725573",
      "id" : 50725573
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/229945918558973952\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/CI00pi5Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzDumDnCMAADWmP.jpg",
      "id_str" : "229945918567362560",
      "id" : 229945918567362560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzDumDnCMAADWmP.jpg",
      "sizes" : [ {
        "h" : 1278,
        "resize" : "fit",
        "w" : 1835
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 713,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/CI00pi5Q"
    } ],
    "hashtags" : [ {
      "text" : "London2012",
      "indices" : [ 41, 52 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/zg1eGwau",
      "expanded_url" : "http:\/\/on.wh.gov\/B31T",
      "display_url" : "on.wh.gov\/B31T"
    } ]
  },
  "geo" : { },
  "id_str" : "229945918558973952",
  "text" : "Photos: First Lady Michelle Obama at the #London2012 #Olympics: http:\/\/t.co\/zg1eGwau Mrs. Obama hugs @Venuseswilliams: http:\/\/t.co\/CI00pi5Q",
  "id" : 229945918558973952,
  "created_at" : "2012-07-30 14:25:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleClassTaxCuts",
      "indices" : [ 55, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/HWEHjgQj",
      "expanded_url" : "http:\/\/on.wh.gov\/wb53",
      "display_url" : "on.wh.gov\/wb53"
    } ]
  },
  "geo" : { },
  "id_str" : "229783688337039361",
  "text" : "President Obama Pushes the House of Representatives on #MiddleClassTaxCuts: http:\/\/t.co\/HWEHjgQj",
  "id" : 229783688337039361,
  "created_at" : "2012-07-30 03:41:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Olympics",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229722760291696640",
  "text" : "RT @letsmove: My visit to the #Olympics has been incredible! Thank you to the UK and all the athletes for inspiring us all. Go Team USA! \u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Olympics",
        "indices" : [ 16, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "229631617965125632",
    "text" : "My visit to the #Olympics has been incredible! Thank you to the UK and all the athletes for inspiring us all. Go Team USA! \u2013mo",
    "id" : 229631617965125632,
    "created_at" : "2012-07-29 17:36:58 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 229722760291696640,
  "created_at" : "2012-07-29 23:39:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/229698302390697985\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/kQKePXJL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AzANY5hCAAAE6Tk.jpg",
      "id_str" : "229698302403280896",
      "id" : 229698302403280896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AzANY5hCAAAE6Tk.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kQKePXJL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/N7McWPJX",
      "expanded_url" : "http:\/\/on.wh.gov\/GUmT",
      "display_url" : "on.wh.gov\/GUmT"
    } ]
  },
  "geo" : { },
  "id_str" : "229698302390697985",
  "text" : "President Obama signs the United States-Israel Enhanced Security Cooperation Act: http:\/\/t.co\/N7McWPJX Photo: http:\/\/t.co\/kQKePXJL",
  "id" : 229698302390697985,
  "created_at" : "2012-07-29 22:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamUSA",
      "indices" : [ 37, 45 ]
    }, {
      "text" : "basketball",
      "indices" : [ 46, 57 ]
    }, {
      "text" : "olympics",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229591613675032576",
  "text" : "RT @letsmove: First lady is watching #teamUSA #basketball with US delegate and Paralympian Gabriel Diaz de Leon! #olympics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teamUSA",
        "indices" : [ 23, 31 ]
      }, {
        "text" : "basketball",
        "indices" : [ 32, 43 ]
      }, {
        "text" : "olympics",
        "indices" : [ 99, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "229584857737613312",
    "text" : "First lady is watching #teamUSA #basketball with US delegate and Paralympian Gabriel Diaz de Leon! #olympics",
    "id" : 229584857737613312,
    "created_at" : "2012-07-29 14:31:10 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 229591613675032576,
  "created_at" : "2012-07-29 14:58:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KnowBeforeYouOwe",
      "indices" : [ 101, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/P3jjL3M8",
      "expanded_url" : "http:\/\/on.wh.gov\/BEaD",
      "display_url" : "on.wh.gov\/BEaD"
    } ]
  },
  "geo" : { },
  "id_str" : "229574529993826304",
  "text" : "New \"Shopping Sheet\" Will Make It Easier for Students to \"Know Before They Owe\" http:\/\/t.co\/P3jjL3M8 #KnowBeforeYouOwe",
  "id" : 229574529993826304,
  "created_at" : "2012-07-29 13:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/229401354534260738\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/pxWAjFiV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ay7_UQhCEAAsL2-.jpg",
      "id_str" : "229401354538455040",
      "id" : 229401354538455040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ay7_UQhCEAAsL2-.jpg",
      "sizes" : [ {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1682
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pxWAjFiV"
    } ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 77, 86 ]
    }, {
      "text" : "swimming",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229401354534260738",
  "text" : "Photo: The First Lady waves an American flag &amp; cheers on #TeamUSA at the #Olympics #swimming events today: http:\/\/t.co\/pxWAjFiV",
  "id" : 229401354534260738,
  "created_at" : "2012-07-29 02:22:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/zXcWMDMS",
      "expanded_url" : "http:\/\/on.wh.gov\/7bV1",
      "display_url" : "on.wh.gov\/7bV1"
    } ]
  },
  "geo" : { },
  "id_str" : "229356447106998272",
  "text" : "President Obama: \"I'm calling on 218 Members of the House to do their job &amp; not raise taxes on the middle class\" http:\/\/t.co\/zXcWMDMS",
  "id" : 229356447106998272,
  "created_at" : "2012-07-28 23:23:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Ryan Lochte",
      "screen_name" : "RyanLochte",
      "indices" : [ 23, 34 ],
      "id_str" : "35348026",
      "id" : 35348026
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 69, 77 ]
    }, {
      "text" : "TeamUSA",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229302591312506880",
  "text" : "RT @letsmove: Congrats @RyanLochte on earning the 1st Gold medal for #TeamUSA in London! I'm so proud of you &amp; of #TeamUSA! \u2013mo",
  "id" : 229302591312506880,
  "created_at" : "2012-07-28 19:49:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 82, 91 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 123, 131 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "London2012",
      "indices" : [ 46, 57 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/muUnbAJL",
      "expanded_url" : "http:\/\/on.wh.gov\/aBat",
      "display_url" : "on.wh.gov\/aBat"
    } ]
  },
  "geo" : { },
  "id_str" : "229287980530024448",
  "text" : "The First Lady is cheering on #TeamUSA at the #London2012 #Olympics! Follow along @LetsMove &amp; http:\/\/t.co\/muUnbAJL via @storify",
  "id" : 229287980530024448,
  "created_at" : "2012-07-28 18:51:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Summer Sanders",
      "screen_name" : "SummerSanders_",
      "indices" : [ 41, 56 ],
      "id_str" : "71064101",
      "id" : 71064101
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teamUSA",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/j7j5hIwi",
      "expanded_url" : "http:\/\/yfrog.com\/odom2jinj",
      "display_url" : "yfrog.com\/odom2jinj"
    } ]
  },
  "geo" : { },
  "id_str" : "229283275921817600",
  "text" : "RT @letsmove: Just arrived at swimming w @SummerSanders_ ! Go #teamUSA! http:\/\/t.co\/j7j5hIwi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Summer Sanders",
        "screen_name" : "SummerSanders_",
        "indices" : [ 27, 42 ],
        "id_str" : "71064101",
        "id" : 71064101
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "teamUSA",
        "indices" : [ 48, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/j7j5hIwi",
        "expanded_url" : "http:\/\/yfrog.com\/odom2jinj",
        "display_url" : "yfrog.com\/odom2jinj"
      } ]
    },
    "geo" : { },
    "id_str" : "229282187239895040",
    "text" : "Just arrived at swimming w @SummerSanders_ ! Go #teamUSA! http:\/\/t.co\/j7j5hIwi",
    "id" : 229282187239895040,
    "created_at" : "2012-07-28 18:28:27 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 229283275921817600,
  "created_at" : "2012-07-28 18:32:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleClassTaxCuts",
      "indices" : [ 80, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/IbOOmj9B",
      "expanded_url" : "http:\/\/on.wh.gov\/UhHN",
      "display_url" : "on.wh.gov\/UhHN"
    } ]
  },
  "geo" : { },
  "id_str" : "229262240480645120",
  "text" : "President Obama: Republicans in the House of Representatives must act to extend #MiddleClassTaxCuts. Watch: http:\/\/t.co\/IbOOmj9B",
  "id" : 229262240480645120,
  "created_at" : "2012-07-28 17:09:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 36, 44 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 52, 61 ]
    }, {
      "text" : "LetsMoveDay",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229239982164963328",
  "text" : "RT @letsmove: While I'm cheering on #TeamUSA at the #Olympics, families &amp; neighbors back home are getting active for #LetsMoveDay. K ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 22, 30 ]
      }, {
        "text" : "Olympics",
        "indices" : [ 38, 47 ]
      }, {
        "text" : "LetsMoveDay",
        "indices" : [ 107, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "229233030278029312",
    "text" : "While I'm cheering on #TeamUSA at the #Olympics, families &amp; neighbors back home are getting active for #LetsMoveDay. Keep it up! \u2013mo",
    "id" : 229233030278029312,
    "created_at" : "2012-07-28 15:13:08 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 229239982164963328,
  "created_at" : "2012-07-28 15:40:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/229235148829372416\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/MqPOqpB0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ay5oJ0DCMAAuu93.jpg",
      "id_str" : "229235148841955328",
      "id" : 229235148841955328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ay5oJ0DCMAAuu93.jpg",
      "sizes" : [ {
        "h" : 389,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1123,
        "resize" : "fit",
        "w" : 1733
      } ],
      "display_url" : "pic.twitter.com\/MqPOqpB0"
    } ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 3, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229235148829372416",
  "text" : "Go #TeamUSA! The First Lady has her picture taken with athletes at the US Olympic Training Facility in London: http:\/\/t.co\/MqPOqpB0",
  "id" : 229235148829372416,
  "created_at" : "2012-07-28 15:21:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 50, 59 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/229161112837423104\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/TE2gbL2i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ay4k0WeCAAA4IYJ.jpg",
      "id_str" : "229161112845811712",
      "id" : 229161112845811712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ay4k0WeCAAA4IYJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1263,
        "resize" : "fit",
        "w" : 1838
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TE2gbL2i"
    } ],
    "hashtags" : [ {
      "text" : "Olympics",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/lWNIttGa",
      "expanded_url" : "http:\/\/on.wh.gov\/On5r",
      "display_url" : "on.wh.gov\/On5r"
    } ]
  },
  "geo" : { },
  "id_str" : "229161112837423104",
  "text" : "Follow the First Lady at the #Olympics on Twitter @letsmove: http:\/\/t.co\/lWNIttGa Get updates &amp; behind the scenes pics: http:\/\/t.co\/TE2gbL2i",
  "id" : 229161112837423104,
  "created_at" : "2012-07-28 10:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 102, 111 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/229064699847786496\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/KVt8Gxr9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ay3NIYGCQAARqX9.jpg",
      "id_str" : "229064699856175104",
      "id" : 229064699856175104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ay3NIYGCQAARqX9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KVt8Gxr9"
    } ],
    "hashtags" : [ {
      "text" : "London2012",
      "indices" : [ 30, 41 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/d8NcLHmA",
      "expanded_url" : "http:\/\/on.wh.gov\/Qq04",
      "display_url" : "on.wh.gov\/Qq04"
    } ]
  },
  "geo" : { },
  "id_str" : "229064699847786496",
  "text" : "PHOTOS: The First Lady at the #London2012 #Olympics: http:\/\/t.co\/d8NcLHmA Mrs. Obama plays tug of war @letsmove event: http:\/\/t.co\/KVt8Gxr9",
  "id" : 229064699847786496,
  "created_at" : "2012-07-28 04:04:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/229040625251672064\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/5fMtTsgM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ay23PDOCYAEOFPj.jpg",
      "id_str" : "229040625255866369",
      "id" : 229040625255866369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ay23PDOCYAEOFPj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5fMtTsgM"
    } ],
    "hashtags" : [ {
      "text" : "London2012",
      "indices" : [ 25, 36 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229040625251672064",
  "text" : "Photo of the Day: At the #London2012 #Olympics, the First Lady gets a lift from US wrestler Elena Pirozhkova: http:\/\/t.co\/5fMtTsgM",
  "id" : 229040625251672064,
  "created_at" : "2012-07-28 02:28:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228991079955959809",
  "text" : "RT @letsmove: At Opening Ceremonies of Olympics...have never seen anything like this..it is truly an amazing moment...the stadium is pou ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228951118070296577",
    "text" : "At Opening Ceremonies of Olympics...have never seen anything like this..it is truly an amazing moment...the stadium is pounding!!!!! -mo",
    "id" : 228951118070296577,
    "created_at" : "2012-07-27 20:32:54 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 228991079955959809,
  "created_at" : "2012-07-27 23:11:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ADA",
      "indices" : [ 91, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/VDvJEKRj",
      "expanded_url" : "http:\/\/on.wh.gov\/qf00",
      "display_url" : "on.wh.gov\/qf00"
    } ]
  },
  "geo" : { },
  "id_str" : "228989452805107713",
  "text" : "From the Archives: A Landmark Moment for Americans with Disabilities: http:\/\/t.co\/VDvJEKRj #ADA",
  "id" : 228989452805107713,
  "created_at" : "2012-07-27 23:05:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleClassTaxCuts",
      "indices" : [ 30, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/pTM1gWjf",
      "expanded_url" : "http:\/\/on.wh.gov\/1LOa",
      "display_url" : "on.wh.gov\/1LOa"
    }, {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/VoRgypWO",
      "expanded_url" : "http:\/\/on.wh.gov\/j6jY",
      "display_url" : "on.wh.gov\/j6jY"
    } ]
  },
  "geo" : { },
  "id_str" : "228935962808446976",
  "text" : "President Obama speaks out on #MiddleClassTaxCuts: http:\/\/t.co\/pTM1gWjf Watch, then add your voice to his: http:\/\/t.co\/VoRgypWO",
  "id" : 228935962808446976,
  "created_at" : "2012-07-27 19:32:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Olympics",
      "indices" : [ 53, 62 ]
    }, {
      "text" : "TeamUSA",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228934406675501056",
  "text" : "RT @letsmove: Leading our nation's delegation to the #Olympics &amp; cheering on #TeamUSA in UK is truly a dream come true. I'm beyond p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Olympics",
        "indices" : [ 39, 48 ]
      }, {
        "text" : "TeamUSA",
        "indices" : [ 67, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228924511767117824",
    "text" : "Leading our nation's delegation to the #Olympics &amp; cheering on #TeamUSA in UK is truly a dream come true. I'm beyond proud to be here -mo",
    "id" : 228924511767117824,
    "created_at" : "2012-07-27 18:47:11 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 228934406675501056,
  "created_at" : "2012-07-27 19:26:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 73, 82 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "London2012",
      "indices" : [ 40, 51 ]
    }, {
      "text" : "Olympics",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/1UR2vTbc",
      "expanded_url" : "http:\/\/on.wh.gov\/2U1m",
      "display_url" : "on.wh.gov\/2U1m"
    }, {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/2B2bu5Ui",
      "expanded_url" : "http:\/\/on.wh.gov\/MQCp",
      "display_url" : "on.wh.gov\/MQCp"
    } ]
  },
  "geo" : { },
  "id_str" : "228865386219724800",
  "text" : "Follow First Lady Michelle Obama at the #London2012 #Olympics on Twitter @LetsMove: http:\/\/t.co\/1UR2vTbc -mo tweet: http:\/\/t.co\/2B2bu5Ui",
  "id" : 228865386219724800,
  "created_at" : "2012-07-27 14:52:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/dpEChud2",
      "expanded_url" : "http:\/\/on.wh.gov\/s4nz",
      "display_url" : "on.wh.gov\/s4nz"
    } ]
  },
  "geo" : { },
  "id_str" : "228850241187758080",
  "text" : "President Obama: Our economy is \"built from a strong &amp; growing middle class &amp; that's who we should be fighting for\" http:\/\/t.co\/dpEChud2",
  "id" : 228850241187758080,
  "created_at" : "2012-07-27 13:52:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228842097262866432",
  "text" : "RT @letsmove: Just met w the US delegation and headed to meet #TeamUSA. So honored to be w these amazing athletes and excited to be at t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 48, 56 ]
      }, {
        "text" : "Olympics",
        "indices" : [ 125, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228757827043340289",
    "text" : "Just met w the US delegation and headed to meet #TeamUSA. So honored to be w these amazing athletes and excited to be at the #Olympics -mo",
    "id" : 228757827043340289,
    "created_at" : "2012-07-27 07:44:50 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 228842097262866432,
  "created_at" : "2012-07-27 13:19:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VFW",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/RjxNJ8ds",
      "expanded_url" : "http:\/\/on.wh.gov\/mbre",
      "display_url" : "on.wh.gov\/mbre"
    } ]
  },
  "geo" : { },
  "id_str" : "228710282996899840",
  "text" : "\"Even after you took off the uniform, you never stopped serving\" -President Obama to the Veterans of Foreign Wars: http:\/\/t.co\/RjxNJ8ds #VFW",
  "id" : 228710282996899840,
  "created_at" : "2012-07-27 04:35:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/228625869663531008\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/dyOcRUq7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ayw-BGQCcAA-fn0.jpg",
      "id_str" : "228625869667725312",
      "id" : 228625869667725312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ayw-BGQCcAA-fn0.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/dyOcRUq7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/qHoBfSYu",
      "expanded_url" : "http:\/\/on.wh.gov\/ZQvg",
      "display_url" : "on.wh.gov\/ZQvg"
    } ]
  },
  "geo" : { },
  "id_str" : "228625869663531008",
  "text" : "Announcing the White House Initiative on Educational Excellence for African Americans. More info: http:\/\/t.co\/qHoBfSYu http:\/\/t.co\/dyOcRUq7",
  "id" : 228625869663531008,
  "created_at" : "2012-07-26 23:00:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/slsJXKf8",
      "expanded_url" : "http:\/\/on.wh.gov\/6h2t",
      "display_url" : "on.wh.gov\/6h2t"
    } ]
  },
  "geo" : { },
  "id_str" : "228614165340778496",
  "text" : "Photo Gallery: Behind the Scenes in June 2012: http:\/\/t.co\/slsJXKf8",
  "id" : 228614165340778496,
  "created_at" : "2012-07-26 22:13:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/228599498681765888\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/ww5Gp6kO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AywmCGtCUAASq6h.jpg",
      "id_str" : "228599498690154496",
      "id" : 228599498690154496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AywmCGtCUAASq6h.jpg",
      "sizes" : [ {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/ww5Gp6kO"
    } ],
    "hashtags" : [ {
      "text" : "ADA",
      "indices" : [ 113, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/gwlDfiVE",
      "expanded_url" : "http:\/\/on.wh.gov\/p4R9",
      "display_url" : "on.wh.gov\/p4R9"
    } ]
  },
  "geo" : { },
  "id_str" : "228599498681765888",
  "text" : "From the Archives: On 7\/26\/1990, President Bush signed the Americans with Disabilities Act: http:\/\/t.co\/gwlDfiVE #ADA http:\/\/t.co\/ww5Gp6kO",
  "id" : 228599498681765888,
  "created_at" : "2012-07-26 21:15:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natl Urban League",
      "screen_name" : "NatUrbanLeague",
      "indices" : [ 85, 100 ],
      "id_str" : "21308157",
      "id" : 21308157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/mPcgl5Ue",
      "expanded_url" : "http:\/\/on.wh.gov\/ZZTT",
      "display_url" : "on.wh.gov\/ZZTT"
    } ]
  },
  "geo" : { },
  "id_str" : "228587878270246913",
  "text" : "\"This country works best when we are growing a strong middle class\" \u2013President Obama @NatUrbanLeague convention Watch: http:\/\/t.co\/mPcgl5Ue",
  "id" : 228587878270246913,
  "created_at" : "2012-07-26 20:29:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 46, 55 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228581576236208128",
  "text" : "RT @letsmove: First Lady Michelle Obama &amp; @LetsMove have arrived in London. We're excited for a full few days ahead! #TeamUSA #Londo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 32, 41 ],
        "id_str" : "36719281",
        "id" : 36719281
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 107, 115 ]
      }, {
        "text" : "London2012",
        "indices" : [ 116, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228580208700174336",
    "text" : "First Lady Michelle Obama &amp; @LetsMove have arrived in London. We're excited for a full few days ahead! #TeamUSA #London2012",
    "id" : 228580208700174336,
    "created_at" : "2012-07-26 19:59:03 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 228581576236208128,
  "created_at" : "2012-07-26 20:04:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 4, 13 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMoveDay",
      "indices" : [ 14, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/JVUojpoX",
      "expanded_url" : "http:\/\/on.wh.gov\/1TQN",
      "display_url" : "on.wh.gov\/1TQN"
    }, {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/2Tpp0hTy",
      "expanded_url" : "http:\/\/on.wh.gov\/8Lqd",
      "display_url" : "on.wh.gov\/8Lqd"
    } ]
  },
  "geo" : { },
  "id_str" : "228552953865334784",
  "text" : "\u200FMT @letsmove #LetsMoveDay is on Saturday: http:\/\/t.co\/JVUojpoX Get into the Olympic spirit &amp; get moving in your town: http:\/\/t.co\/2Tpp0hTy",
  "id" : 228552953865334784,
  "created_at" : "2012-07-26 18:10:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/228500903265726465\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/YgNLn3FS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyvMXGKCcAAxDdR.jpg",
      "id_str" : "228500903274115072",
      "id" : 228500903274115072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyvMXGKCcAAxDdR.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YgNLn3FS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228500903265726465",
  "text" : "PHOTO: President Obama talks with speechwriter Laura Dean on Air Force One en route to New Orleans yesterday. http:\/\/t.co\/YgNLn3FS",
  "id" : 228500903265726465,
  "created_at" : "2012-07-26 14:43:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleClassTaxCuts",
      "indices" : [ 99, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/KHc73nnY",
      "expanded_url" : "http:\/\/on.wh.gov\/P2SS",
      "display_url" : "on.wh.gov\/P2SS"
    } ]
  },
  "geo" : { },
  "id_str" : "228471793361494016",
  "text" : "Our economy is \"built from a strong &amp; growing middle class\" -President Obama on the passage of #MiddleClassTaxCuts: http:\/\/t.co\/KHc73nnY",
  "id" : 228471793361494016,
  "created_at" : "2012-07-26 12:48:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natl Urban League",
      "screen_name" : "NatUrbanLeague",
      "indices" : [ 57, 72 ],
      "id_str" : "21308157",
      "id" : 21308157
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 128, 135 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/rxILZ10H",
      "expanded_url" : "http:\/\/on.wh.gov\/dKpF",
      "display_url" : "on.wh.gov\/dKpF"
    } ]
  },
  "geo" : { },
  "id_str" : "228277901966065664",
  "text" : "Starting at 8ET: President Obama delivers remarks at the @NatUrbanLeague convention. Watch live at http:\/\/t.co\/rxILZ10H. Follow @WHLive",
  "id" : 228277901966065664,
  "created_at" : "2012-07-25 23:57:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleClassTaxCuts",
      "indices" : [ 82, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228250504386449408",
  "text" : "\"House Republicans are now the only people left in Washington holding hostage the #MiddleClassTaxCuts for 98% of Americans\" -President Obama",
  "id" : 228250504386449408,
  "created_at" : "2012-07-25 22:08:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/228233102873468928\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/kkqCxt6e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyrYzEACIAAIcIV.jpg",
      "id_str" : "228233102894440448",
      "id" : 228233102894440448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyrYzEACIAAIcIV.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kkqCxt6e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228233102873468928",
  "text" : "Photo of the Day: First Lady Michelle Obama greets children &amp; other patrons at the Westerville Community Center in Ohio http:\/\/t.co\/kkqCxt6e",
  "id" : 228233102873468928,
  "created_at" : "2012-07-25 20:59:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AIDS2012",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228205815612469248",
  "text" : "RT @VP: Proud that the International AIDS Conference is back in Washington. Our goal: creating an AIDS-free generation. \u2013 VP  #AIDS2012",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AIDS2012",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228194742079455232",
    "text" : "Proud that the International AIDS Conference is back in Washington. Our goal: creating an AIDS-free generation. \u2013 VP  #AIDS2012",
    "id" : 228194742079455232,
    "created_at" : "2012-07-25 18:27:20 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 228205815612469248,
  "created_at" : "2012-07-25 19:11:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/228186699157630976\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/FBmnSDAE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyqumApCcAA07f6.jpg",
      "id_str" : "228186699166019584",
      "id" : 228186699166019584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyqumApCcAA07f6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/FBmnSDAE"
    } ],
    "hashtags" : [ {
      "text" : "MiddleClassTaxCuts",
      "indices" : [ 51, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/zjGT4n7b",
      "expanded_url" : "http:\/\/on.wh.gov\/sy7w",
      "display_url" : "on.wh.gov\/sy7w"
    } ]
  },
  "geo" : { },
  "id_str" : "228186699157630976",
  "text" : "President Obama to Congress: Pass a bill extending #MiddleClassTaxCuts &amp; I will sign it tomorrow\" http:\/\/t.co\/zjGT4n7b http:\/\/t.co\/FBmnSDAE",
  "id" : 228186699157630976,
  "created_at" : "2012-07-25 17:55:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 27, 38 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/228122711740776448\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/g8xlVPmb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ayp0Zc8CAAEkD3Q.jpg",
      "id_str" : "228122711749165057",
      "id" : 228122711749165057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ayp0Zc8CAAEkD3Q.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/g8xlVPmb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/hd8Yhthn",
      "expanded_url" : "http:\/\/on.wh.gov\/4tYM",
      "display_url" : "on.wh.gov\/4tYM"
    } ]
  },
  "geo" : { },
  "id_str" : "228122711740776448",
  "text" : "AIDS Memorial Quilt in the @WhiteHouse: http:\/\/t.co\/hd8Yhthn President Obama views a section of the quilt on display: http:\/\/t.co\/g8xlVPmb",
  "id" : 228122711740776448,
  "created_at" : "2012-07-25 13:41:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AIDS2012",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/MViGkjQ0",
      "expanded_url" : "http:\/\/on.wh.gov\/Z1yU",
      "display_url" : "on.wh.gov\/Z1yU"
    } ]
  },
  "geo" : { },
  "id_str" : "227972891843641344",
  "text" : "President Obama welcomes 2012 International AIDS Conference Attendees: http:\/\/t.co\/MViGkjQ0 #AIDS2012",
  "id" : 227972891843641344,
  "created_at" : "2012-07-25 03:45:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 131, 135 ]
    }, {
      "text" : "HCR",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/dDpkzqxp",
      "expanded_url" : "http:\/\/on.wh.gov\/8mpo",
      "display_url" : "on.wh.gov\/8mpo"
    } ]
  },
  "geo" : { },
  "id_str" : "227886309195255808",
  "text" : "Get the facts: The Affordable Care Act will reduce the deficit by more than $100 billion over the next 10 yrs http:\/\/t.co\/dDpkzqxp #ACA #HCR",
  "id" : 227886309195255808,
  "created_at" : "2012-07-24 22:01:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/227880218419929088\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/90ehnKX3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AymX2e6CIAEY4ok.jpg",
      "id_str" : "227880218424123393",
      "id" : 227880218424123393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AymX2e6CIAEY4ok.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/90ehnKX3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/KeKIS3mT",
      "expanded_url" : "http:\/\/on.wh.gov\/taTr",
      "display_url" : "on.wh.gov\/taTr"
    } ]
  },
  "geo" : { },
  "id_str" : "227880218419929088",
  "text" : "Heading to college? The new Financial Aid Shopping Sheet allows students to \"Know Before They Owe\" http:\/\/t.co\/KeKIS3mT http:\/\/t.co\/90ehnKX3",
  "id" : 227880218419929088,
  "created_at" : "2012-07-24 21:37:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "HuffPost BlackVoices",
      "screen_name" : "blackvoices",
      "indices" : [ 109, 121 ],
      "id_str" : "13557972",
      "id" : 13557972
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AIDS",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227825714076995584",
  "text" : "RT @vj44: On Saturday, I joined an inspirational mtg w\/ courageous black women living w\/ #AIDS. My op-ed via @BlackVoices: http:\/\/t.co\/Y ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HuffPost BlackVoices",
        "screen_name" : "blackvoices",
        "indices" : [ 99, 111 ],
        "id_str" : "13557972",
        "id" : 13557972
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AIDS",
        "indices" : [ 79, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/Y6dqnRCw",
        "expanded_url" : "http:\/\/huff.to\/MDNBMJ",
        "display_url" : "huff.to\/MDNBMJ"
      } ]
    },
    "geo" : { },
    "id_str" : "227824192261873665",
    "text" : "On Saturday, I joined an inspirational mtg w\/ courageous black women living w\/ #AIDS. My op-ed via @BlackVoices: http:\/\/t.co\/Y6dqnRCw",
    "id" : 227824192261873665,
    "created_at" : "2012-07-24 17:54:54 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 227825714076995584,
  "created_at" : "2012-07-24 18:00:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShoppingSheet",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227809331930857472",
  "text" : "RT @arneduncan: Our new #ShoppingSheet helps unravel the mystery of college costs so students can make informed decisions http:\/\/t.co\/vb ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShoppingSheet",
        "indices" : [ 8, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/vbvuvvQB",
        "expanded_url" : "http:\/\/go.usa.gov\/fp5",
        "display_url" : "go.usa.gov\/fp5"
      } ]
    },
    "geo" : { },
    "id_str" : "227763180259139585",
    "text" : "Our new #ShoppingSheet helps unravel the mystery of college costs so students can make informed decisions http:\/\/t.co\/vbvuvvQB",
    "id" : 227763180259139585,
    "created_at" : "2012-07-24 13:52:28 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 227809331930857472,
  "created_at" : "2012-07-24 16:55:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/pUxNBpn7",
      "expanded_url" : "http:\/\/on.wh.gov\/Cdsg",
      "display_url" : "on.wh.gov\/Cdsg"
    } ]
  },
  "geo" : { },
  "id_str" : "227764869259227137",
  "text" : "New White House report highlights the effects of President Obama's proposal to extend tax cuts for 98% of families: http:\/\/t.co\/pUxNBpn7",
  "id" : 227764869259227137,
  "created_at" : "2012-07-24 13:59:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/E9Gxb25R",
      "expanded_url" : "http:\/\/on.wh.gov\/y5QB",
      "display_url" : "on.wh.gov\/y5QB"
    }, {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/5meZMqyI",
      "expanded_url" : "http:\/\/on.wh.gov\/frRa",
      "display_url" : "on.wh.gov\/frRa"
    } ]
  },
  "geo" : { },
  "id_str" : "227762591605325824",
  "text" : "Remembering Sally Ride: http:\/\/t.co\/E9Gxb25R Live from the South Lawn, Dr. Ride joined us for an online Q&amp;A in 2009: http:\/\/t.co\/5meZMqyI",
  "id" : 227762591605325824,
  "created_at" : "2012-07-24 13:50:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/Aq27AvpH",
      "expanded_url" : "http:\/\/on.wh.gov\/bd8x",
      "display_url" : "on.wh.gov\/bd8x"
    } ]
  },
  "geo" : { },
  "id_str" : "227623653003653120",
  "text" : "Wall Street Reform Two-Years Later: Reforming the System &amp; Protecting American Consumers: http:\/\/t.co\/Aq27AvpH",
  "id" : 227623653003653120,
  "created_at" : "2012-07-24 04:38:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 40, 45 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/227560287845371904\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/4faGm7eC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ayh04EpCUAAdmE3.jpg",
      "id_str" : "227560287849566208",
      "id" : 227560287849566208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ayh04EpCUAAdmE3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/4faGm7eC"
    } ],
    "hashtags" : [ {
      "text" : "ByTheNumbers",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/hYS6Qb7u",
      "expanded_url" : "http:\/\/on.wh.gov\/tc2p",
      "display_url" : "on.wh.gov\/tc2p"
    } ]
  },
  "geo" : { },
  "id_str" : "227560287845371904",
  "text" : "#ByTheNumbers: As a result of action by @CFPB, Capital One Bank must refund $140M to 2M customers: http:\/\/t.co\/hYS6Qb7u http:\/\/t.co\/4faGm7eC",
  "id" : 227560287845371904,
  "created_at" : "2012-07-24 00:26:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/227546812406460416\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/geoEEDZ7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyhonsuCcAAkAD1.jpg",
      "id_str" : "227546812410654720",
      "id" : 227546812410654720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyhonsuCcAAkAD1.jpg",
      "sizes" : [ {
        "h" : 236,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 417,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 712,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1278,
        "resize" : "fit",
        "w" : 1838
      } ],
      "display_url" : "pic.twitter.com\/geoEEDZ7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/m9eVEOG4",
      "expanded_url" : "http:\/\/on.wh.gov\/GCrD",
      "display_url" : "on.wh.gov\/GCrD"
    } ]
  },
  "geo" : { },
  "id_str" : "227546812406460416",
  "text" : "Remembering Sally Ride: President Obama Salutes an American Hero: http:\/\/t.co\/m9eVEOG4 Photo: Obama with Ride in 2009: http:\/\/t.co\/geoEEDZ7",
  "id" : 227546812406460416,
  "created_at" : "2012-07-23 23:32:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/OSCgudV0",
      "expanded_url" : "http:\/\/wh.gov\/Crpn",
      "display_url" : "wh.gov\/Crpn"
    } ]
  },
  "geo" : { },
  "id_str" : "227527277662064641",
  "text" : "RT @vj44: Saddened to hear of Sally Ride\u2019s passing, the first American woman in space; She was a true American hero. http:\/\/t.co\/OSCgudV0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/OSCgudV0",
        "expanded_url" : "http:\/\/wh.gov\/Crpn",
        "display_url" : "wh.gov\/Crpn"
      } ]
    },
    "geo" : { },
    "id_str" : "227525940220157952",
    "text" : "Saddened to hear of Sally Ride\u2019s passing, the first American woman in space; She was a true American hero. http:\/\/t.co\/OSCgudV0",
    "id" : 227525940220157952,
    "created_at" : "2012-07-23 22:09:46 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 227527277662064641,
  "created_at" : "2012-07-23 22:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/jmrClLiK",
      "expanded_url" : "http:\/\/on.wh.gov\/lsmM",
      "display_url" : "on.wh.gov\/lsmM"
    } ]
  },
  "geo" : { },
  "id_str" : "227521256558309376",
  "text" : "President Obama on the passing of Sally Ride: \"Her legacy will endure for years to come.\" Full statement: http:\/\/t.co\/jmrClLiK",
  "id" : 227521256558309376,
  "created_at" : "2012-07-23 21:51:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227489343265202176",
  "text" : "RT @WHLive: President Obama: \"Today, there are no Americans fighting in Iraq, and we are proud of all the Americans who served there\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227489294204403712",
    "text" : "President Obama: \"Today, there are no Americans fighting in Iraq, and we are proud of all the Americans who served there\"",
    "id" : 227489294204403712,
    "created_at" : "2012-07-23 19:44:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 227489343265202176,
  "created_at" : "2012-07-23 19:44:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VFW",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "227488399785877505",
  "text" : "RT @WHLive: President Obama: \"On behalf of all our men and women in uniform, on behalf of the American people, thank you #VFW\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VFW",
        "indices" : [ 109, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "227488339945738240",
    "text" : "President Obama: \"On behalf of all our men and women in uniform, on behalf of the American people, thank you #VFW\"",
    "id" : 227488339945738240,
    "created_at" : "2012-07-23 19:40:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 227488399785877505,
  "created_at" : "2012-07-23 19:40:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 115, 122 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VFW",
      "indices" : [ 45, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/dfEWfXpi",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "227486895536488448",
  "text" : "Happening now: President Obama speaks at the #VFW National Convention in Reno. Watch: http:\/\/t.co\/dfEWfXpi Follow: @WHLive",
  "id" : 227486895536488448,
  "created_at" : "2012-07-23 19:34:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Veterans",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/iOFBcuHT",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "227484997773324288",
  "text" : "RT @WHLive: Happening at 3:35ET: President Obama speaks @ #Veterans of Foreign Wars Convention in Reno. Watch: http:\/\/t.co\/iOFBcuHT Foll ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 128, 135 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Veterans",
        "indices" : [ 46, 55 ]
      }, {
        "text" : "VFW",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/iOFBcuHT",
        "expanded_url" : "http:\/\/WH.gov\/live",
        "display_url" : "WH.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "227481166339510273",
    "text" : "Happening at 3:35ET: President Obama speaks @ #Veterans of Foreign Wars Convention in Reno. Watch: http:\/\/t.co\/iOFBcuHT Follow: @WHLive #VFW",
    "id" : 227481166339510273,
    "created_at" : "2012-07-23 19:11:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 227484997773324288,
  "created_at" : "2012-07-23 19:27:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/227475866718961664\/photo\/1",
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/tSps8MD0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AygoGHeCAAAM0O3.jpg",
      "id_str" : "227475866731544576",
      "id" : 227475866731544576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AygoGHeCAAAM0O3.jpg",
      "sizes" : [ {
        "h" : 2620,
        "resize" : "fit",
        "w" : 3908
      }, {
        "h" : 402,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 687,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tSps8MD0"
    } ],
    "hashtags" : [ {
      "text" : "Aurora",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/yNORVKKW",
      "expanded_url" : "http:\/\/on.wh.gov\/qs3l",
      "display_url" : "on.wh.gov\/qs3l"
    } ]
  },
  "geo" : { },
  "id_str" : "227475866718961664",
  "text" : "President Obama meets with survivors &amp; families of victims of the shooting in #Aurora, Colorado: http:\/\/t.co\/yNORVKKW http:\/\/t.co\/tSps8MD0",
  "id" : 227475866718961664,
  "created_at" : "2012-07-23 18:50:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Aurora",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/I0L1mnWl",
      "expanded_url" : "http:\/\/on.wh.gov\/NcS9",
      "display_url" : "on.wh.gov\/NcS9"
    } ]
  },
  "geo" : { },
  "id_str" : "227457133619339264",
  "text" : "\"To the entire community of #Aurora, the country is thinking of you\" -President Obama speaks after hospital visit: http:\/\/t.co\/I0L1mnWl",
  "id" : 227457133619339264,
  "created_at" : "2012-07-23 17:36:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AIDS2012",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/2lD8Bvdo",
      "expanded_url" : "http:\/\/on.wh.gov\/FRuw",
      "display_url" : "on.wh.gov\/FRuw"
    } ]
  },
  "geo" : { },
  "id_str" : "227416882775461888",
  "text" : "\"Thank you for your commitment\" -President Obama welcomes International #AIDS2012 Conference attendees. Watch: http:\/\/t.co\/2lD8Bvdo",
  "id" : 227416882775461888,
  "created_at" : "2012-07-23 14:56:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecClinton",
      "indices" : [ 30, 41 ]
    }, {
      "text" : "AIDS",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/OHXG0LDc",
      "expanded_url" : "http:\/\/go.usa.gov\/fTa",
      "display_url" : "go.usa.gov\/fTa"
    } ]
  },
  "geo" : { },
  "id_str" : "227402216636575744",
  "text" : "RT @StateDept: Starting soon! #SecClinton addresses XIX International #AIDS Conference 10:00 AM EDT today: http:\/\/t.co\/OHXG0LDc  #AIDS20 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecClinton",
        "indices" : [ 15, 26 ]
      }, {
        "text" : "AIDS",
        "indices" : [ 55, 60 ]
      }, {
        "text" : "AIDS2012",
        "indices" : [ 114, 123 ]
      }, {
        "text" : "EndofAIDS",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/OHXG0LDc",
        "expanded_url" : "http:\/\/go.usa.gov\/fTa",
        "display_url" : "go.usa.gov\/fTa"
      } ]
    },
    "geo" : { },
    "id_str" : "227399465982627840",
    "text" : "Starting soon! #SecClinton addresses XIX International #AIDS Conference 10:00 AM EDT today: http:\/\/t.co\/OHXG0LDc  #AIDS2012 #EndofAIDS",
    "id" : 227399465982627840,
    "created_at" : "2012-07-23 13:47:12 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 227402216636575744,
  "created_at" : "2012-07-23 13:58:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 130, 150 ],
      "url" : "http:\/\/t.co\/t1IFVEoi",
      "expanded_url" : "http:\/\/on.wh.gov\/iDah",
      "display_url" : "on.wh.gov\/iDah"
    } ]
  },
  "geo" : { },
  "id_str" : "227043556882255872",
  "text" : "President Obama: \"Michelle &amp; I are shocked &amp; saddened by the horrific &amp; tragic shooting in Colorado.\" Full statement: http:\/\/t.co\/t1IFVEoi",
  "id" : 227043556882255872,
  "created_at" : "2012-07-22 14:12:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Colorado",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/EnOot1bT",
      "expanded_url" : "http:\/\/on.wh.gov\/H5og",
      "display_url" : "on.wh.gov\/H5og"
    } ]
  },
  "geo" : { },
  "id_str" : "226895198351917056",
  "text" : "\"This weekend I hope everyone takes some time for prayer and reflection\" -President Obama on the shooting in #Colorado: http:\/\/t.co\/EnOot1bT",
  "id" : 226895198351917056,
  "created_at" : "2012-07-22 04:23:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226871189207920641",
  "text" : "RT @pfeiffer44: President Obama will travel to Colorado tomorrow to visit with the families of the  victims of Friday's tragic shooting.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "226842528316522497",
    "text" : "President Obama will travel to Colorado tomorrow to visit with the families of the  victims of Friday's tragic shooting.",
    "id" : 226842528316522497,
    "created_at" : "2012-07-22 00:54:07 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 226871189207920641,
  "created_at" : "2012-07-22 02:48:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/FsiguWcF",
      "expanded_url" : "http:\/\/on.wh.gov\/SQ4v",
      "display_url" : "on.wh.gov\/SQ4v"
    } ]
  },
  "geo" : { },
  "id_str" : "226798590142590976",
  "text" : "President Obama: \"If there's anything to take away from this tragedy, it's a reminder that life is fragile\" Watch: http:\/\/t.co\/FsiguWcF",
  "id" : 226798590142590976,
  "created_at" : "2012-07-21 21:59:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Aurora",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/LHyCtUlR",
      "expanded_url" : "http:\/\/on.wh.gov\/LTu5",
      "display_url" : "on.wh.gov\/LTu5"
    } ]
  },
  "geo" : { },
  "id_str" : "226699104523280384",
  "text" : "President Obama: \"The people we lost in Aurora loved, and were loved\"  Watch: Weekly Address on the shooting in #Aurora http:\/\/t.co\/LHyCtUlR",
  "id" : 226699104523280384,
  "created_at" : "2012-07-21 15:24:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Aurora",
      "indices" : [ 47, 54 ]
    }, {
      "text" : "Colorado",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/inLcTtz6",
      "expanded_url" : "http:\/\/on.wh.gov\/lcMq",
      "display_url" : "on.wh.gov\/lcMq"
    } ]
  },
  "geo" : { },
  "id_str" : "226655393085001728",
  "text" : "Weekly Address: Remembering the Victims of the #Aurora, #Colorado Shooting Watch: http:\/\/t.co\/inLcTtz6",
  "id" : 226655393085001728,
  "created_at" : "2012-07-21 12:30:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/rqWKffZz",
      "expanded_url" : "http:\/\/on.wh.gov\/4ilM",
      "display_url" : "on.wh.gov\/4ilM"
    } ]
  },
  "geo" : { },
  "id_str" : "226507424423616513",
  "text" : "\"We must now come together as one American family\" -President Obama on the shooting in Colorado: http:\/\/t.co\/rqWKffZz",
  "id" : 226507424423616513,
  "created_at" : "2012-07-21 02:42:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/226422138859565058\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/31d10kLv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyRpvFSCMAEhwuv.jpg",
      "id_str" : "226422138867953665",
      "id" : 226422138867953665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyRpvFSCMAEhwuv.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/31d10kLv"
    } ],
    "hashtags" : [ {
      "text" : "Colorado",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/pdpvohrh",
      "expanded_url" : "http:\/\/on.wh.gov\/dVeX",
      "display_url" : "on.wh.gov\/dVeX"
    } ]
  },
  "geo" : { },
  "id_str" : "226422138859565058",
  "text" : "Photo: President Obama pauses for a moment of silence for the victims of the #Colorado shooting: http:\/\/t.co\/pdpvohrh http:\/\/t.co\/31d10kLv",
  "id" : 226422138859565058,
  "created_at" : "2012-07-20 21:03:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Colorado",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/bGAxpqLH",
      "expanded_url" : "http:\/\/on.wh.gov\/OF0a",
      "display_url" : "on.wh.gov\/OF0a"
    } ]
  },
  "geo" : { },
  "id_str" : "226408191259455489",
  "text" : "President Obama orders US flags to be flown at half-staff in honor of #Colorado victims. Presidential Proclamation: http:\/\/t.co\/bGAxpqLH",
  "id" : 226408191259455489,
  "created_at" : "2012-07-20 20:08:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226389096833093632",
  "text" : "RT @VP: VP Biden: \u201CWe stand with the city of Aurora and the state of Colorado in mourning.\u201D Read the full statement here: http:\/\/t.co\/S0 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/S00KpHov",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2012\/07\/20\/statement-vice-president-joe-biden-shooting-colorado",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "226381435483848704",
    "text" : "VP Biden: \u201CWe stand with the city of Aurora and the state of Colorado in mourning.\u201D Read the full statement here: http:\/\/t.co\/S00KpHov",
    "id" : 226381435483848704,
    "created_at" : "2012-07-20 18:21:54 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 226389096833093632,
  "created_at" : "2012-07-20 18:52:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Aurora",
      "indices" : [ 47, 54 ]
    }, {
      "text" : "Colorado",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/OpAyaY0g",
      "expanded_url" : "http:\/\/on.wh.gov\/0hJn",
      "display_url" : "on.wh.gov\/0hJn"
    } ]
  },
  "geo" : { },
  "id_str" : "226345912484646912",
  "text" : "Remarks by President Obama on the shootings in #Aurora, #Colorado: http:\/\/t.co\/OpAyaY0g",
  "id" : 226345912484646912,
  "created_at" : "2012-07-20 16:00:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/wHJmfFQ5",
      "expanded_url" : "http:\/\/on.wh.gov\/h1AT",
      "display_url" : "on.wh.gov\/h1AT"
    } ]
  },
  "geo" : { },
  "id_str" : "226314043412066304",
  "text" : "President Obama: \"All of us must have the people of Aurora in our thoughts &amp; prayers\" Full statement: http:\/\/t.co\/wHJmfFQ5",
  "id" : 226314043412066304,
  "created_at" : "2012-07-20 13:54:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/226095177553567744\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/1gb93Kos",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyNAXbfCYAMflwO.jpg",
      "id_str" : "226095177557762051",
      "id" : 226095177557762051,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyNAXbfCYAMflwO.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/1gb93Kos"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/tbOfXL4e",
      "expanded_url" : "http:\/\/on.wh.gov\/eUti",
      "display_url" : "on.wh.gov\/eUti"
    } ]
  },
  "geo" : { },
  "id_str" : "226095177553567744",
  "text" : "By the Numbers: 10,000 http:\/\/t.co\/tbOfXL4e Number of teachers who will be recognized by the STEM Master Teacher Corps http:\/\/t.co\/1gb93Kos",
  "id" : 226095177553567744,
  "created_at" : "2012-07-19 23:24:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Olympics",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226079735392919553",
  "text" : "President Obama supports a moment of silence at the #Olympics to honor the Israeli athletes killed in Munich.",
  "id" : 226079735392919553,
  "created_at" : "2012-07-19 22:23:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/226037256958398464\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/N0NcdWge",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyMLsAeCUAAeTM2.jpg",
      "id_str" : "226037256966787072",
      "id" : 226037256966787072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyMLsAeCUAAeTM2.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/N0NcdWge"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226037256958398464",
  "text" : "Photo of the Day: President Obama meets with senior advisors in the Oval Office before a call with President Putin. http:\/\/t.co\/N0NcdWge",
  "id" : 226037256958398464,
  "created_at" : "2012-07-19 19:34:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "World Bank",
      "screen_name" : "WorldBank",
      "indices" : [ 46, 56 ],
      "id_str" : "27860681",
      "id" : 27860681
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecClinton",
      "indices" : [ 30, 41 ]
    }, {
      "text" : "JimKim",
      "indices" : [ 57, 64 ]
    }, {
      "text" : "GenderGap",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/SqGfPaP5",
      "expanded_url" : "http:\/\/goo.gl\/oagvc",
      "display_url" : "goo.gl\/oagvc"
    } ]
  },
  "geo" : { },
  "id_str" : "225960849838329856",
  "text" : "RT @StateDept: Starting soon! #SecClinton and @WorldBank #JimKim address closing the data #GenderGap. Watch live: http:\/\/t.co\/SqGfPaP5 # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "World Bank",
        "screen_name" : "WorldBank",
        "indices" : [ 31, 41 ],
        "id_str" : "27860681",
        "id" : 27860681
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecClinton",
        "indices" : [ 15, 26 ]
      }, {
        "text" : "JimKim",
        "indices" : [ 42, 49 ]
      }, {
        "text" : "GenderGap",
        "indices" : [ 75, 85 ]
      }, {
        "text" : "GenderData",
        "indices" : [ 120, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/SqGfPaP5",
        "expanded_url" : "http:\/\/goo.gl\/oagvc",
        "display_url" : "goo.gl\/oagvc"
      } ]
    },
    "geo" : { },
    "id_str" : "225960538180554754",
    "text" : "Starting soon! #SecClinton and @WorldBank #JimKim address closing the data #GenderGap. Watch live: http:\/\/t.co\/SqGfPaP5 #GenderData",
    "id" : 225960538180554754,
    "created_at" : "2012-07-19 14:29:25 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 225960849838329856,
  "created_at" : "2012-07-19 14:30:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 51, 61 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/225747492329885696\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/yiErFVKB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyIEJfGCEAE7DS6.jpg",
      "id_str" : "225747492334080001",
      "id" : 225747492334080001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyIEJfGCEAE7DS6.jpg",
      "sizes" : [ {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yiErFVKB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/sOGYqXVY",
      "expanded_url" : "http:\/\/on.wh.gov\/QapN",
      "display_url" : "on.wh.gov\/QapN"
    } ]
  },
  "geo" : { },
  "id_str" : "225747492329885696",
  "text" : "Check out the latest benind-the-scenes photos from @PeteSouza, including this pic of First Dog Bo: http:\/\/t.co\/sOGYqXVY http:\/\/t.co\/yiErFVKB",
  "id" : 225747492329885696,
  "created_at" : "2012-07-19 00:22:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225730230671773696",
  "text" : "RT @VP: Today we celebrate the life of a man whose courage and resilience will resonate for generations.  Happy Birthday Nelson Mandela--VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225696186684825600",
    "text" : "Today we celebrate the life of a man whose courage and resilience will resonate for generations.  Happy Birthday Nelson Mandela--VP",
    "id" : 225696186684825600,
    "created_at" : "2012-07-18 20:58:58 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 225730230671773696,
  "created_at" : "2012-07-18 23:14:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMoveDay",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225709702510690304",
  "text" : "RT @letsmove: First Lady Michelle Obama is calling on you to participate in a #LetsMoveDay \"Olympic-Inspired\" Meetup on 7\/28. Watch: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMoveDay",
        "indices" : [ 64, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/hzzV9BDN",
        "expanded_url" : "http:\/\/youtu.be\/V78bU8k5g4I",
        "display_url" : "youtu.be\/V78bU8k5g4I"
      } ]
    },
    "geo" : { },
    "id_str" : "225668799255420928",
    "text" : "First Lady Michelle Obama is calling on you to participate in a #LetsMoveDay \"Olympic-Inspired\" Meetup on 7\/28. Watch: http:\/\/t.co\/hzzV9BDN",
    "id" : 225668799255420928,
    "created_at" : "2012-07-18 19:10:09 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 225709702510690304,
  "created_at" : "2012-07-18 21:52:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WSJwashington",
      "screen_name" : "WSJwashington",
      "indices" : [ 3, 17 ],
      "id_str" : "2518564165",
      "id" : 2518564165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/s63X9coR",
      "expanded_url" : "http:\/\/on.wsj.com\/OY0pum",
      "display_url" : "on.wsj.com\/OY0pum"
    } ]
  },
  "geo" : { },
  "id_str" : "225674573826387968",
  "text" : "RT @WSJwashington: White House Asks: Got an Idea to Simplify Regulations? http:\/\/t.co\/s63X9coR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/s63X9coR",
        "expanded_url" : "http:\/\/on.wsj.com\/OY0pum",
        "display_url" : "on.wsj.com\/OY0pum"
      } ]
    },
    "geo" : { },
    "id_str" : "225612975367663617",
    "text" : "White House Asks: Got an Idea to Simplify Regulations? http:\/\/t.co\/s63X9coR",
    "id" : 225612975367663617,
    "created_at" : "2012-07-18 15:28:19 +0000",
    "user" : {
      "name" : "Capital Journal",
      "screen_name" : "WSJPolitics",
      "protected" : false,
      "id_str" : "16311797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460821519455633409\/KU517dSk_normal.jpeg",
      "id" : 16311797,
      "verified" : true
    }
  },
  "id" : 225674573826387968,
  "created_at" : "2012-07-18 19:33:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baylor Lady Bears",
      "screen_name" : "BaylorWBB",
      "indices" : [ 80, 90 ],
      "id_str" : "21409003",
      "id" : 21409003
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/qoFSwroL",
      "expanded_url" : "http:\/\/on.wh.gov\/rq3P",
      "display_url" : "on.wh.gov\/rq3P"
    } ]
  },
  "geo" : { },
  "id_str" : "225658899053805568",
  "text" : "Happening Now: President Obama Honors the 2012 NCAA Women\u2019s Basketball Champion @BaylorWBB Lady Bears Watch: http:\/\/t.co\/qoFSwroL",
  "id" : 225658899053805568,
  "created_at" : "2012-07-18 18:30:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 4, 9 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CFPBEnforcement",
      "indices" : [ 122, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/thqtrpJC",
      "expanded_url" : "http:\/\/on.wh.gov\/Q0Yb",
      "display_url" : "on.wh.gov\/Q0Yb"
    } ]
  },
  "geo" : { },
  "id_str" : "225645659829706752",
  "text" : "RT \u200F@CFPB CFPB probe into Capital One credit card marketing results in $140 million consumer refund: http:\/\/t.co\/thqtrpJC #CFPBEnforcement",
  "id" : 225645659829706752,
  "created_at" : "2012-07-18 17:38:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225639315542245378",
  "text" : "RT @whitehouseostp: Today at 4ET: WH Office Hours on Science, Technology &amp; Engineering (STEM) Master Teacher Corps. Ask Qs now w\/ #W ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 114, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/pNDwUTsz",
        "expanded_url" : "http:\/\/on.wh.gov\/twjX",
        "display_url" : "on.wh.gov\/twjX"
      } ]
    },
    "geo" : { },
    "id_str" : "225610046409674754",
    "text" : "Today at 4ET: WH Office Hours on Science, Technology &amp; Engineering (STEM) Master Teacher Corps. Ask Qs now w\/ #WHChat http:\/\/t.co\/pNDwUTsz",
    "id" : 225610046409674754,
    "created_at" : "2012-07-18 15:16:41 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 225639315542245378,
  "created_at" : "2012-07-18 17:12:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 136, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/qFkRRkrg",
      "expanded_url" : "http:\/\/on.wh.gov\/t9dc",
      "display_url" : "on.wh.gov\/t9dc"
    } ]
  },
  "geo" : { },
  "id_str" : "225603409875705856",
  "text" : "Announcing the new Science, Math, Tech &amp; Engineering (STEM) Master Teacher Corps: http:\/\/t.co\/qFkRRkrg Have Q's on STEM? Ask now w\/ #WHChat",
  "id" : 225603409875705856,
  "created_at" : "2012-07-18 14:50:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/225587884978225152\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/LAuixzdS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyFy_HYCQAACw9H.jpg",
      "id_str" : "225587884982419456",
      "id" : 225587884982419456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyFy_HYCQAACw9H.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LAuixzdS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/zGj6RmD1",
      "expanded_url" : "http:\/\/on.wh.gov\/71h1",
      "display_url" : "on.wh.gov\/71h1"
    } ]
  },
  "geo" : { },
  "id_str" : "225587884978225152",
  "text" : "Happy Birthday Nelson Mandela: http:\/\/t.co\/zGj6RmD1 Photo: The First Lady visits with Mandela in South Africa in 2011: http:\/\/t.co\/LAuixzdS",
  "id" : 225587884978225152,
  "created_at" : "2012-07-18 13:48:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NelsonMandela",
      "indices" : [ 69, 83 ]
    }, {
      "text" : "MandelaDay",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/WixJSHgP",
      "expanded_url" : "http:\/\/on.wh.gov\/Yxl7",
      "display_url" : "on.wh.gov\/Yxl7"
    } ]
  },
  "geo" : { },
  "id_str" : "225372780118556674",
  "text" : "Video: First Lady Michelle Obama talks about an inspiring visit with #NelsonMandela in 2011 http:\/\/t.co\/WixJSHgP #MandelaDay",
  "id" : 225372780118556674,
  "created_at" : "2012-07-17 23:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Basketball",
      "screen_name" : "usabasketball",
      "indices" : [ 60, 74 ],
      "id_str" : "17049258",
      "id" : 17049258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usab2012",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/cIAirz6X",
      "expanded_url" : "http:\/\/on.wh.gov\/uwVO",
      "display_url" : "on.wh.gov\/uwVO"
    } ]
  },
  "geo" : { },
  "id_str" : "225356491673186305",
  "text" : "VIDEO: Go behind the scenes with President Obama &amp; Team @USABasketball: http:\/\/t.co\/cIAirz6X #usab2012",
  "id" : 225356491673186305,
  "created_at" : "2012-07-17 22:29:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NelsonMandela",
      "indices" : [ 1, 15 ]
    }, {
      "text" : "MandelaDay",
      "indices" : [ 136, 147 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225350103358128129",
  "text" : "\"#NelsonMandela has changed the arc of history, transforming his country, continent &amp; the world\" -The President &amp; First Lady on #MandelaDay",
  "id" : 225350103358128129,
  "created_at" : "2012-07-17 22:03:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 22, 27 ],
      "id_str" : "61853389",
      "id" : 61853389
    }, {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 47, 59 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "localfood",
      "indices" : [ 68, 78 ]
    }, {
      "text" : "WHHangout",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/g5icuVZL",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "225310220698648577",
  "text" : "RT @WHLive: Live now: @USDA D\/S Merrigan &amp; @JonCarson44 discuss #localfood. Watch: http:\/\/t.co\/g5icuVZL &amp; ask Qs: #WHHangout #KY ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dept. of Agriculture",
        "screen_name" : "USDA",
        "indices" : [ 10, 15 ],
        "id_str" : "61853389",
        "id" : 61853389
      }, {
        "name" : "Jon Carson",
        "screen_name" : "JonCarson44",
        "indices" : [ 35, 47 ],
        "id_str" : "1287388789",
        "id" : 1287388789
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/225309885766709250\/photo\/1",
        "indices" : [ 127, 147 ],
        "url" : "http:\/\/t.co\/WrpKPtWb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AyB2JboCMAA4pA9.jpg",
        "id_str" : "225309885775097856",
        "id" : 225309885775097856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyB2JboCMAA4pA9.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/WrpKPtWb"
      } ],
      "hashtags" : [ {
        "text" : "localfood",
        "indices" : [ 56, 66 ]
      }, {
        "text" : "WHHangout",
        "indices" : [ 110, 120 ]
      }, {
        "text" : "KYF2",
        "indices" : [ 121, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "225309885766709250",
    "text" : "Live now: @USDA D\/S Merrigan &amp; @JonCarson44 discuss #localfood. Watch: http:\/\/t.co\/g5icuVZL &amp; ask Qs: #WHHangout #KYF2 http:\/\/t.co\/WrpKPtWb",
    "id" : 225309885766709250,
    "created_at" : "2012-07-17 19:23:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 225310220698648577,
  "created_at" : "2012-07-17 19:25:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skyline Chili",
      "screen_name" : "Skyline_Chili",
      "indices" : [ 79, 93 ],
      "id_str" : "50631904",
      "id" : 50631904
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/225249769281437696\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/AGaaggm2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AyA_eMQCQAA35c0.jpg",
      "id_str" : "225249769285632000",
      "id" : 225249769285632000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AyA_eMQCQAA35c0.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AGaaggm2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225249769281437696",
  "text" : "Photo of the Day: President Obama talks with patrons as he waits for his lunch @Skyline_Chili in Cincinnati, OH http:\/\/t.co\/AGaaggm2",
  "id" : 225249769281437696,
  "created_at" : "2012-07-17 15:25:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 3, 8 ],
      "id_str" : "61853389",
      "id" : 61853389
    }, {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 70, 82 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "localfood",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "whhangout",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225243737666748417",
  "text" : "RT @USDA: Your Qs are key to today\u2019s #localfood chat w D\/S Merrigan + @joncarson44! Ask via #whhangout &amp; tune in at 3 ET http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jon Carson",
        "screen_name" : "JonCarson44",
        "indices" : [ 60, 72 ],
        "id_str" : "1287388789",
        "id" : 1287388789
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "localfood",
        "indices" : [ 27, 37 ]
      }, {
        "text" : "whhangout",
        "indices" : [ 82, 92 ]
      }, {
        "text" : "kyf2",
        "indices" : [ 136, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/esDW1Jiu",
        "expanded_url" : "http:\/\/WhiteHouse.gov\/live",
        "display_url" : "WhiteHouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "225230454666698752",
    "text" : "Your Qs are key to today\u2019s #localfood chat w D\/S Merrigan + @joncarson44! Ask via #whhangout &amp; tune in at 3 ET http:\/\/t.co\/esDW1Jiu #kyf2",
    "id" : 225230454666698752,
    "created_at" : "2012-07-17 14:08:19 +0000",
    "user" : {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "protected" : false,
      "id_str" : "61853389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475696751\/bf524afc612e7aa534d6c543a3d3e144_normal.jpeg",
      "id" : 61853389,
      "verified" : true
    }
  },
  "id" : 225243737666748417,
  "created_at" : "2012-07-17 15:01:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Basketball",
      "screen_name" : "usabasketball",
      "indices" : [ 46, 60 ],
      "id_str" : "17049258",
      "id" : 17049258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 98, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225032225840824321",
  "text" : "I\u2019m proud to cheer on the men\u2019s &amp; women\u2019s @USABasketball teams tonight. Join me &amp; support #TeamUSA! \u2013bo",
  "id" : 225032225840824321,
  "created_at" : "2012-07-17 01:00:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225027050384261120",
  "text" : "RT @jesseclee44: Obama on DISCLOSE Act: \"Instead of standing up for the American people, Republicans stood w\/ big banks &amp; oil compan ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/oYoTCL8K",
        "expanded_url" : "http:\/\/m.whitehouse.gov\/the-press-office\/2012\/07\/16\/statement-president-disclose-act",
        "display_url" : "m.whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "225020806818824193",
    "text" : "Obama on DISCLOSE Act: \"Instead of standing up for the American people, Republicans stood w\/ big banks &amp; oil companies\" http:\/\/t.co\/oYoTCL8K",
    "id" : 225020806818824193,
    "created_at" : "2012-07-17 00:15:15 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 225027050384261120,
  "created_at" : "2012-07-17 00:40:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA Basketball",
      "screen_name" : "usabasketball",
      "indices" : [ 48, 62 ],
      "id_str" : "17049258",
      "id" : 17049258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAB2012",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/h8Hhj8tW",
      "expanded_url" : "http:\/\/on.wh.gov\/xxv3",
      "display_url" : "on.wh.gov\/xxv3"
    } ]
  },
  "geo" : { },
  "id_str" : "225013987199303680",
  "text" : "Today at the White House: Alonzo Mourning talks @USABasketball &amp; why this team will bring home the gold: http:\/\/t.co\/h8Hhj8tW  #USAB2012",
  "id" : 225013987199303680,
  "created_at" : "2012-07-16 23:48:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/wtiasiPZ",
      "expanded_url" : "http:\/\/on.wh.gov\/hCuv",
      "display_url" : "on.wh.gov\/hCuv"
    } ]
  },
  "geo" : { },
  "id_str" : "225002521305952258",
  "text" : "What's America's #1 export? Tourism. Find out all the ways international visitors support U.S jobs &amp; the economy: http:\/\/t.co\/wtiasiPZ",
  "id" : 225002521305952258,
  "created_at" : "2012-07-16 23:02:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 59, 71 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 73, 78 ],
      "id_str" : "61853389",
      "id" : 61853389
    }, {
      "name" : "Mayor Rawlings-Blake",
      "screen_name" : "MayorSRB",
      "indices" : [ 102, 111 ],
      "id_str" : "109328493",
      "id" : 109328493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 128, 148 ],
      "url" : "http:\/\/t.co\/HTtW2Oco",
      "expanded_url" : "http:\/\/on.wh.gov\/qAFE",
      "display_url" : "on.wh.gov\/qAFE"
    } ]
  },
  "geo" : { },
  "id_str" : "224955040819978241",
  "text" : "Have Qs about local food? Ask now w\/ #WHHangout &amp; join @JonCarson44, @USDA Dep Sec Merrigan &amp; @MayorSRB tomorrow at 3ET http:\/\/t.co\/HTtW2Oco",
  "id" : 224955040819978241,
  "created_at" : "2012-07-16 19:53:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "224880041107013632",
  "text" : "RT @VP: VP to discuss retirement security for seniors today w\/ community leaders from across the country. Listen live @ 11:45: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/h9A4lIt4",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "224878854072844288",
    "text" : "VP to discuss retirement security for seniors today w\/ community leaders from across the country. Listen live @ 11:45: http:\/\/t.co\/h9A4lIt4",
    "id" : 224878854072844288,
    "created_at" : "2012-07-16 14:51:11 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 224880041107013632,
  "created_at" : "2012-07-16 14:55:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "HUD News | not",
      "screen_name" : "HUDNews",
      "indices" : [ 121, 129 ],
      "id_str" : "1881201980",
      "id" : 1881201980
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "refinance",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/XgmR6Hab",
      "expanded_url" : "http:\/\/on.wh.gov\/WLgn",
      "display_url" : "on.wh.gov\/WLgn"
    } ]
  },
  "geo" : { },
  "id_str" : "224872678685802496",
  "text" : "RT @macon44: Wow. Livestream on POTUS' #refinance plan w\/Sec Donovan had 70,000 views during event. http:\/\/t.co\/XgmR6Hab @HUDNews @Zillo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HUD News | not",
        "screen_name" : "HUDNews",
        "indices" : [ 108, 116 ],
        "id_str" : "1881201980",
        "id" : 1881201980
      }, {
        "name" : "Zillow",
        "screen_name" : "zillow",
        "indices" : [ 117, 124 ],
        "id_str" : "19262500",
        "id" : 19262500
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "refinance",
        "indices" : [ 26, 36 ]
      }, {
        "text" : "myrefi",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/XgmR6Hab",
        "expanded_url" : "http:\/\/on.wh.gov\/WLgn",
        "display_url" : "on.wh.gov\/WLgn"
      } ]
    },
    "geo" : { },
    "id_str" : "224872148177661952",
    "text" : "Wow. Livestream on POTUS' #refinance plan w\/Sec Donovan had 70,000 views during event. http:\/\/t.co\/XgmR6Hab @HUDNews @Zillow #myrefi",
    "id" : 224872148177661952,
    "created_at" : "2012-07-16 14:24:32 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 224872678685802496,
  "created_at" : "2012-07-16 14:26:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/4oKF1XSD",
      "expanded_url" : "http:\/\/on.wh.gov\/vTBI",
      "display_url" : "on.wh.gov\/vTBI"
    } ]
  },
  "geo" : { },
  "id_str" : "224856780864360452",
  "text" : "\"Let's at least agree to do what we all agree on\" -President Obama calls on Congress to extend middle class tax cut: http:\/\/t.co\/4oKF1XSD",
  "id" : 224856780864360452,
  "created_at" : "2012-07-16 13:23:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/rqBm5WiI",
      "expanded_url" : "http:\/\/on.wh.gov\/9Flw",
      "display_url" : "on.wh.gov\/9Flw"
    } ]
  },
  "geo" : { },
  "id_str" : "224691770561273857",
  "text" : "President Obama: \"I've cut middle-class taxes every year that I've been President \u2013 by $3,600 for the typical family\" http:\/\/t.co\/rqBm5WiI",
  "id" : 224691770561273857,
  "created_at" : "2012-07-16 02:27:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 69, 80 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/PgV3vMlx",
      "expanded_url" : "http:\/\/1.usa.gov\/LZV31N",
      "display_url" : "1.usa.gov\/LZV31N"
    } ]
  },
  "geo" : { },
  "id_str" : "224640190042484736",
  "text" : "RT @vj44: 1 year ago today President Obama met w\/ Ruby Bridges @ the @whitehouse -- such a special moment: http:\/\/t.co\/PgV3vMlx http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 59, 70 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/224638040314875905\/photo\/1",
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/dtSpJceq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ax4TG4SCEAA9Hc_.jpg",
        "id_str" : "224638040323264512",
        "id" : 224638040323264512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ax4TG4SCEAA9Hc_.jpg",
        "sizes" : [ {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/dtSpJceq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/PgV3vMlx",
        "expanded_url" : "http:\/\/1.usa.gov\/LZV31N",
        "display_url" : "1.usa.gov\/LZV31N"
      } ]
    },
    "geo" : { },
    "id_str" : "224638040314875905",
    "text" : "1 year ago today President Obama met w\/ Ruby Bridges @ the @whitehouse -- such a special moment: http:\/\/t.co\/PgV3vMlx http:\/\/t.co\/dtSpJceq",
    "id" : 224638040314875905,
    "created_at" : "2012-07-15 22:54:18 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 224640190042484736,
  "created_at" : "2012-07-15 23:02:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/mFjfL9vH",
      "expanded_url" : "http:\/\/on.wh.gov\/DzV5",
      "display_url" : "on.wh.gov\/DzV5"
    } ]
  },
  "geo" : { },
  "id_str" : "224593870820872192",
  "text" : "From the Archives: 1 year ago today, President Obama met with civil rights icon Ruby Bridges in the Oval Office: http:\/\/t.co\/mFjfL9vH",
  "id" : 224593870820872192,
  "created_at" : "2012-07-15 19:58:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/ACrGw9Ee",
      "expanded_url" : "http:\/\/on.wh.gov\/NOKY",
      "display_url" : "on.wh.gov\/NOKY"
    } ]
  },
  "geo" : { },
  "id_str" : "224486601055666177",
  "text" : "Extending Middle Class Tax Cuts for 98% of Americans &amp; 97% of Small Businesses: http:\/\/t.co\/ACrGw9Ee",
  "id" : 224486601055666177,
  "created_at" : "2012-07-15 12:52:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 73, 80 ],
      "id_str" : "19262500",
      "id" : 19262500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "refinance",
      "indices" : [ 35, 45 ]
    }, {
      "text" : "SecDonovan",
      "indices" : [ 55, 66 ]
    }, {
      "text" : "MyRefi",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/9dUijagB",
      "expanded_url" : "http:\/\/on.wh.gov\/mKpz",
      "display_url" : "on.wh.gov\/mKpz"
    } ]
  },
  "geo" : { },
  "id_str" : "224290842741972992",
  "text" : "Hanging out &amp; talking mortgage #refinance with HUD #SecDonovan &amp; @Zillow: http:\/\/t.co\/9dUijagB #MyRefi",
  "id" : 224290842741972992,
  "created_at" : "2012-07-14 23:54:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/NtmZMuVZ",
      "expanded_url" : "http:\/\/youtu.be\/bYDp4iWH8S8",
      "display_url" : "youtu.be\/bYDp4iWH8S8"
    } ]
  },
  "geo" : { },
  "id_str" : "224156507699286017",
  "text" : "President Obama calls on Congress to act now to extend tax cuts for 98% of Americans. Watch the Weekly Address: http:\/\/t.co\/NtmZMuVZ",
  "id" : 224156507699286017,
  "created_at" : "2012-07-14 15:00:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/yYn7LEPc",
      "expanded_url" : "http:\/\/on.wh.gov\/mIb6",
      "display_url" : "on.wh.gov\/mIb6"
    } ]
  },
  "geo" : { },
  "id_str" : "224132189296672768",
  "text" : "Did you know immigrants are 30% more likely to start a business? 10 ways immigrants help strengthen the economy: http:\/\/t.co\/yYn7LEPc",
  "id" : 224132189296672768,
  "created_at" : "2012-07-14 13:24:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/z8Bo8Iz7",
      "expanded_url" : "http:\/\/on.wh.gov\/8E3A",
      "display_url" : "on.wh.gov\/8E3A"
    } ]
  },
  "geo" : { },
  "id_str" : "223951791635701761",
  "text" : "West Wing Week: 7\/13\/12 or \"Lets Agree To Do What We Agree On.\" Your behind the scenes guide to 1600 Pennsylvania Ave: http:\/\/t.co\/z8Bo8Iz7",
  "id" : 223951791635701761,
  "created_at" : "2012-07-14 01:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 70, 75 ],
      "id_str" : "61853389",
      "id" : 61853389
    }, {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 108, 120 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/tV2F4F9X",
      "expanded_url" : "http:\/\/on.wh.gov\/tmPe",
      "display_url" : "on.wh.gov\/tmPe"
    } ]
  },
  "geo" : { },
  "id_str" : "223864621059153920",
  "text" : "On Tues. 7\/17 at 3ET join a #WHHangout on Google+ about local food w\/ @USDA Dep Sec Kathleen Merrigan &amp; @JonCarson44: http:\/\/t.co\/tV2F4F9X",
  "id" : 223864621059153920,
  "created_at" : "2012-07-13 19:40:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meetup",
      "screen_name" : "Meetup",
      "indices" : [ 3, 10 ],
      "id_str" : "14591071",
      "id" : 14591071
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 61, 70 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMoveDay",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223825206697926656",
  "text" : "RT @Meetup: Meetups are really breaking a sweat this summer! @letsmove uses Meetup to gear up for nationwide #LetsMoveDay http:\/\/t.co\/Ba ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 49, 58 ],
        "id_str" : "36719281",
        "id" : 36719281
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMoveDay",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/Ba8smNJf",
        "expanded_url" : "http:\/\/ow.ly\/cb60y",
        "display_url" : "ow.ly\/cb60y"
      } ]
    },
    "geo" : { },
    "id_str" : "223460820460388353",
    "text" : "Meetups are really breaking a sweat this summer! @letsmove uses Meetup to gear up for nationwide #LetsMoveDay http:\/\/t.co\/Ba8smNJf",
    "id" : 223460820460388353,
    "created_at" : "2012-07-12 16:56:25 +0000",
    "user" : {
      "name" : "Meetup",
      "screen_name" : "Meetup",
      "protected" : false,
      "id_str" : "14591071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781157191977930752\/JiLrNQ4h_normal.jpg",
      "id" : 14591071,
      "verified" : true
    }
  },
  "id" : 223825206697926656,
  "created_at" : "2012-07-13 17:04:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HUD News | not",
      "screen_name" : "HUDNews",
      "indices" : [ 47, 55 ],
      "id_str" : "1881201980",
      "id" : 1881201980
    }, {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 74, 81 ],
      "id_str" : "19262500",
      "id" : 19262500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 11, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/3eLmVqS9",
      "expanded_url" : "http:\/\/on.wh.gov\/qzpP",
      "display_url" : "on.wh.gov\/qzpP"
    }, {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/hIU3xPLg",
      "expanded_url" : "http:\/\/on.wh.gov\/TgK3",
      "display_url" : "on.wh.gov\/TgK3"
    } ]
  },
  "geo" : { },
  "id_str" : "223792876360962048",
  "text" : "Missed our #WHHangout on mortgage refinance w\/ @HUDNews Sec Donovan &amp; @Zillow? Read about it http:\/\/t.co\/3eLmVqS9 Watch http:\/\/t.co\/hIU3xPLg",
  "id" : 223792876360962048,
  "created_at" : "2012-07-13 14:55:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/223766515730743296\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/WKX1UjAG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Axr6deNCAAE5bXJ.jpg",
      "id_str" : "223766515739131905",
      "id" : 223766515739131905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Axr6deNCAAE5bXJ.jpg",
      "sizes" : [ {
        "h" : 358,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 304,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/WKX1UjAG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/ZlxtxNpZ",
      "expanded_url" : "http:\/\/on.wh.gov\/tgYu",
      "display_url" : "on.wh.gov\/tgYu"
    } ]
  },
  "geo" : { },
  "id_str" : "223766515730743296",
  "text" : "President Obama has a plan to help responsible homeowners refinance. Would you qualify? Find out http:\/\/t.co\/ZlxtxNpZ http:\/\/t.co\/WKX1UjAG",
  "id" : 223766515730743296,
  "created_at" : "2012-07-13 13:11:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "refinance",
      "indices" : [ 93, 103 ]
    }, {
      "text" : "MyRefi",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/LVbvTxIg",
      "expanded_url" : "http:\/\/on.wh.gov\/WMIl",
      "display_url" : "on.wh.gov\/WMIl"
    } ]
  },
  "geo" : { },
  "id_str" : "223600208976674817",
  "text" : "Here's everything you need to know about the President's plan to help responsible homeowners #refinance: http:\/\/t.co\/LVbvTxIg #MyRefi",
  "id" : 223600208976674817,
  "created_at" : "2012-07-13 02:10:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/yqpUGdvQ",
      "expanded_url" : "http:\/\/on.wh.gov\/JhoP",
      "display_url" : "on.wh.gov\/JhoP"
    }, {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/dgPI1Emv",
      "expanded_url" : "http:\/\/on.wh.gov\/r3z4",
      "display_url" : "on.wh.gov\/r3z4"
    } ]
  },
  "geo" : { },
  "id_str" : "223536883488137217",
  "text" : "How much will the President's mortgage refinance plan cost taxpayers? Watch &amp; find out http:\/\/t.co\/yqpUGdvQ Learn more http:\/\/t.co\/dgPI1Emv.",
  "id" : 223536883488137217,
  "created_at" : "2012-07-12 21:58:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Devil Dog 68",
      "screen_name" : "Fightingseventh",
      "indices" : [ 13, 29 ],
      "id_str" : "71637118",
      "id" : 71637118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223522091771756544",
  "text" : "RT @macon44: @Fightingseventh correct. this video talks about the policy, in terms of benefits for homeowners &amp; the larger community ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Devil Dog 68",
        "screen_name" : "Fightingseventh",
        "indices" : [ 0, 16 ],
        "id_str" : "71637118",
        "id" : 71637118
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/poRI4ZL2",
        "expanded_url" : "http:\/\/youtu.be\/BhpUiMp6Nlw",
        "display_url" : "youtu.be\/BhpUiMp6Nlw"
      } ]
    },
    "in_reply_to_status_id_str" : "223521334628581377",
    "geo" : { },
    "id_str" : "223521840704917505",
    "in_reply_to_user_id" : 71637118,
    "text" : "@Fightingseventh correct. this video talks about the policy, in terms of benefits for homeowners &amp; the larger community http:\/\/t.co\/poRI4ZL2",
    "id" : 223521840704917505,
    "in_reply_to_status_id" : 223521334628581377,
    "created_at" : "2012-07-12 20:58:54 +0000",
    "in_reply_to_screen_name" : "Fightingseventh",
    "in_reply_to_user_id_str" : "71637118",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 223522091771756544,
  "created_at" : "2012-07-12 20:59:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "refinance",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223515795240652800",
  "text" : "RT @macon44: ... &amp; tweeps of all sides, why wouldn't we want to make it easier for homeowners to #refinance? Seriously! http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "refinance",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/7zF8L5Hn",
        "expanded_url" : "http:\/\/wh.gov\/refi",
        "display_url" : "wh.gov\/refi"
      } ]
    },
    "geo" : { },
    "id_str" : "223512023735087104",
    "text" : "... &amp; tweeps of all sides, why wouldn't we want to make it easier for homeowners to #refinance? Seriously! http:\/\/t.co\/7zF8L5Hn",
    "id" : 223512023735087104,
    "created_at" : "2012-07-12 20:19:53 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 223515795240652800,
  "created_at" : "2012-07-12 20:34:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223513769656057856",
  "text" : "RT @macon44: Seeing\/Hearing the homeowners in the #WHHangout who have been doing the right thing drives home how important this is: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHHangout",
        "indices" : [ 37, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/mHx8igjx",
        "expanded_url" : "http:\/\/WH.gov\/Refi",
        "display_url" : "WH.gov\/Refi"
      } ]
    },
    "geo" : { },
    "id_str" : "223509853237280768",
    "text" : "Seeing\/Hearing the homeowners in the #WHHangout who have been doing the right thing drives home how important this is: http:\/\/t.co\/mHx8igjx",
    "id" : 223509853237280768,
    "created_at" : "2012-07-12 20:11:16 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 223513769656057856,
  "created_at" : "2012-07-12 20:26:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "refinance",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/BnxfwA7X",
      "expanded_url" : "http:\/\/on.wh.gov\/0eDK",
      "display_url" : "on.wh.gov\/0eDK"
    } ]
  },
  "geo" : { },
  "id_str" : "223500300726702081",
  "text" : "Watch live: HUD Sec Donovan is talking to homeowners about the President's #refinance plan in a live Google+ Hangout: http:\/\/t.co\/BnxfwA7X",
  "id" : 223500300726702081,
  "created_at" : "2012-07-12 19:33:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Rascoff",
      "screen_name" : "spencerrascoff",
      "indices" : [ 46, 61 ],
      "id_str" : "19046875",
      "id" : 19046875
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "refinance",
      "indices" : [ 67, 77 ]
    }, {
      "text" : "WHHangout",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/qprBWLCM",
      "expanded_url" : "http:\/\/on.wh.gov\/m1qP",
      "display_url" : "on.wh.gov\/m1qP"
    } ]
  },
  "geo" : { },
  "id_str" : "223496758255288320",
  "text" : "Starting soon: HUD Sec Donovan &amp; Zillow's @spencerrascoff talk #refinance. Have Qs? Ask now w\/ #WHHangout &amp; watch @ http:\/\/t.co\/qprBWLCM",
  "id" : 223496758255288320,
  "created_at" : "2012-07-12 19:19:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HUD News | not",
      "screen_name" : "HUDNews",
      "indices" : [ 56, 64 ],
      "id_str" : "1881201980",
      "id" : 1881201980
    }, {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 83, 90 ],
      "id_str" : "19262500",
      "id" : 19262500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 128, 148 ],
      "url" : "http:\/\/t.co\/iZ1UdDu0",
      "expanded_url" : "http:\/\/on.wh.gov\/uPQS",
      "display_url" : "on.wh.gov\/uPQS"
    } ]
  },
  "geo" : { },
  "id_str" : "223494016908529666",
  "text" : "Starting soon: Google+ Hangout on mortgage refinance w\/ @HUDNews Sec Donovan &amp; @Zillow.  Ask Qs w\/ #WHHangout &amp; watch @ http:\/\/t.co\/iZ1UdDu0",
  "id" : 223494016908529666,
  "created_at" : "2012-07-12 19:08:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/223465265734762499\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/r1q7rV09",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxnoeahCQAA4crp.jpg",
      "id_str" : "223465265743151104",
      "id" : 223465265743151104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxnoeahCQAA4crp.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/r1q7rV09"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223465265734762499",
  "text" : "Photo of the Day: President Obama walks with National Security Advisor Tom Donilon in the West WIng of the White House http:\/\/t.co\/r1q7rV09",
  "id" : 223465265734762499,
  "created_at" : "2012-07-12 17:14:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HUD News | not",
      "screen_name" : "HUDNews",
      "indices" : [ 73, 81 ],
      "id_str" : "1881201980",
      "id" : 1881201980
    }, {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 108, 115 ],
      "id_str" : "19262500",
      "id" : 19262500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/hK12Kblq",
      "expanded_url" : "http:\/\/on.wh.gov\/5bjA",
      "display_url" : "on.wh.gov\/5bjA"
    } ]
  },
  "geo" : { },
  "id_str" : "223441218917511168",
  "text" : "Today @ 3:15ET: Join us for a Google+ Hangout on mortgage refinancing w\/ @HUDNews Sec. Donovan moderated by @Zillow: http:\/\/t.co\/hK12Kblq",
  "id" : 223441218917511168,
  "created_at" : "2012-07-12 15:38:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HUD News | not",
      "screen_name" : "HUDNews",
      "indices" : [ 86, 94 ],
      "id_str" : "1881201980",
      "id" : 1881201980
    }, {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 114, 121 ],
      "id_str" : "19262500",
      "id" : 19262500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/Xk6JtLlU",
      "expanded_url" : "http:\/\/on.wh.gov\/Kg5M",
      "display_url" : "on.wh.gov\/Kg5M"
    } ]
  },
  "geo" : { },
  "id_str" : "223425018703511552",
  "text" : "Have Qs about mortgage refinancing? Tune in today at 3:15 ET for a Google+ Hangout w\/ @HUDNews Sec. Donovan &amp; @Zillow: http:\/\/t.co\/Xk6JtLlU",
  "id" : 223425018703511552,
  "created_at" : "2012-07-12 14:34:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dayton Daily News",
      "screen_name" : "daytondailynews",
      "indices" : [ 104, 120 ],
      "id_str" : "15627208",
      "id" : 15627208
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/vAfMAGk0",
      "expanded_url" : "http:\/\/on.wh.gov\/YmTK",
      "display_url" : "on.wh.gov\/YmTK"
    } ]
  },
  "geo" : { },
  "id_str" : "223397578396536832",
  "text" : "Today in Ohio, the Obama administration unveils new actions to help #smallbiz: http:\/\/t.co\/vAfMAGk0 via @daytondailynews",
  "id" : 223397578396536832,
  "created_at" : "2012-07-12 12:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Meetup",
      "screen_name" : "Meetup",
      "indices" : [ 104, 111 ],
      "id_str" : "14591071",
      "id" : 14591071
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223269007170600960",
  "text" : "RT @letsmove: Looking for a reason to get moving this summer? Join your local #LetsMove Olympic Fun Day @Meetup on 7\/28: http:\/\/t.co\/lH4 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Meetup",
        "screen_name" : "Meetup",
        "indices" : [ 90, 97 ],
        "id_str" : "14591071",
        "id" : 14591071
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 64, 73 ]
      }, {
        "text" : "LetsMoveDay",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/lH4tnYcs",
        "expanded_url" : "http:\/\/ow.ly\/cb5zU",
        "display_url" : "ow.ly\/cb5zU"
      } ]
    },
    "geo" : { },
    "id_str" : "223186765232611330",
    "text" : "Looking for a reason to get moving this summer? Join your local #LetsMove Olympic Fun Day @Meetup on 7\/28: http:\/\/t.co\/lH4tnYcs #LetsMoveDay",
    "id" : 223186765232611330,
    "created_at" : "2012-07-11 22:47:26 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 223269007170600960,
  "created_at" : "2012-07-12 04:14:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/223236159046811648\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/HY5AOK5C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxkYGpmCAAE3JYW.jpg",
      "id_str" : "223236159055200257",
      "id" : 223236159055200257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxkYGpmCAAE3JYW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/HY5AOK5C"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/yHBfHIKd",
      "expanded_url" : "http:\/\/on.wh.gov\/hPrp",
      "display_url" : "on.wh.gov\/hPrp"
    } ]
  },
  "geo" : { },
  "id_str" : "223236159046811648",
  "text" : "By the Numbers: 97: http:\/\/t.co\/yHBfHIKd President Obama wants to extend tax cuts for 97% of small business owners. http:\/\/t.co\/HY5AOK5C",
  "id" : 223236159046811648,
  "created_at" : "2012-07-12 02:03:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/D9hQaPI7",
      "expanded_url" : "http:\/\/on.wh.gov\/sqoP",
      "display_url" : "on.wh.gov\/sqoP"
    } ]
  },
  "geo" : { },
  "id_str" : "223221114501992448",
  "text" : "Ask an Expert: Can't refinance because your mortgage isn't backed by Fannie Mae, Freddie Mac or the FHA? Find out why: http:\/\/t.co\/D9hQaPI7",
  "id" : 223221114501992448,
  "created_at" : "2012-07-12 01:03:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "STLtoday",
      "screen_name" : "stltoday",
      "indices" : [ 104, 113 ],
      "id_str" : "6039302",
      "id" : 6039302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 114, 118 ]
    }, {
      "text" : "HCR",
      "indices" : [ 119, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/igVnRwi2",
      "expanded_url" : "http:\/\/on.wh.gov\/NP1K",
      "display_url" : "on.wh.gov\/NP1K"
    } ]
  },
  "geo" : { },
  "id_str" : "223186285198716928",
  "text" : "RT @HHSGov: Missouri, Illinois customers getting rebates under health care law http:\/\/t.co\/igVnRwi2 via @STLtoday #ACA #HCR",
  "id" : 223186285198716928,
  "created_at" : "2012-07-11 22:45:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 58, 69 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223174856269770752",
  "text" : "RT @SBAgov: Admin Mills on the new immediate actions from @WhiteHouse to help #smallbiz access loans &amp; reduce paperwork: http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 46, 57 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smallbiz",
        "indices" : [ 66, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/Ve0DCbaZ",
        "expanded_url" : "http:\/\/owl.li\/caCUM",
        "display_url" : "owl.li\/caCUM"
      } ]
    },
    "geo" : { },
    "id_str" : "223106926752440320",
    "text" : "Admin Mills on the new immediate actions from @WhiteHouse to help #smallbiz access loans &amp; reduce paperwork: http:\/\/t.co\/Ve0DCbaZ",
    "id" : 223106926752440320,
    "created_at" : "2012-07-11 17:30:11 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 223174856269770752,
  "created_at" : "2012-07-11 22:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/223149672460591104\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/98Jg2gUW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxjJcd9CIAA-4I7.jpg",
      "id_str" : "223149672468979712",
      "id" : 223149672468979712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxjJcd9CIAA-4I7.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/98Jg2gUW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223149672460591104",
  "text" : "Photo of the Day: President Obama (with ice cream cone) greets people outside of Deb's Ice Cream &amp; Deli in Iowa. http:\/\/t.co\/98Jg2gUW",
  "id" : 223149672460591104,
  "created_at" : "2012-07-11 20:20:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyRefi",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/ZLFQmjhE",
      "expanded_url" : "http:\/\/on.wh.gov\/TjuJ",
      "display_url" : "on.wh.gov\/TjuJ"
    } ]
  },
  "geo" : { },
  "id_str" : "222912697694564352",
  "text" : "Ask an Expert: How will cutting red tape for responsible homeowners help the economy at large? Watch: http:\/\/t.co\/ZLFQmjhE #MyRefi",
  "id" : 222912697694564352,
  "created_at" : "2012-07-11 04:38:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/222886553830166530\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/9vkKuLzr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxfaI8rCEAAykxZ.jpg",
      "id_str" : "222886553838555136",
      "id" : 222886553838555136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxfaI8rCEAAykxZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/9vkKuLzr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/cOUVxE6N",
      "expanded_url" : "http:\/\/on.wh.gov\/JItS",
      "display_url" : "on.wh.gov\/JItS"
    } ]
  },
  "geo" : { },
  "id_str" : "222886553830166530",
  "text" : "By the Numbers: 98% http:\/\/t.co\/cOUVxE6N President Obama is calling on Congress to extend tax cuts for 98% of Americans http:\/\/t.co\/9vkKuLzr",
  "id" : 222886553830166530,
  "created_at" : "2012-07-11 02:54:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MLB",
      "screen_name" : "MLB",
      "indices" : [ 57, 61 ],
      "id_str" : "18479513",
      "id" : 18479513
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STL",
      "indices" : [ 79, 83 ]
    }, {
      "text" : "ASG",
      "indices" : [ 134, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/4xXgyohp",
      "expanded_url" : "http:\/\/on.wh.gov\/hfl2",
      "display_url" : "on.wh.gov\/hfl2"
    } ]
  },
  "geo" : { },
  "id_str" : "222859229848010754",
  "text" : "Watch: Willie Mays joins the President on flight to 2009 @MLB All-Star game in #STL where Obama threw 1st pitch: http:\/\/t.co\/4xXgyohp #ASG",
  "id" : 222859229848010754,
  "created_at" : "2012-07-11 01:05:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 51, 63 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/3pb7EP1J",
      "expanded_url" : "http:\/\/on.wh.gov\/oIlQ",
      "display_url" : "on.wh.gov\/oIlQ"
    } ]
  },
  "geo" : { },
  "id_str" : "222825282170662914",
  "text" : "Have you seen David Plouffe's response to a recent @WeThePeople petition about extending tax cuts? http:\/\/t.co\/3pb7EP1J",
  "id" : 222825282170662914,
  "created_at" : "2012-07-10 22:51:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/xM26wUud",
      "expanded_url" : "http:\/\/www.politico.com\/news\/stories\/0712\/78291.html",
      "display_url" : "politico.com\/news\/stories\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222809800730361857",
  "text" : "RT @JonCarson44: Great Op-Ed by Jeff Zients on the need for a balanced approach to replacing the sequester.\nhttp:\/\/t.co\/xM26wUud",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/xM26wUud",
        "expanded_url" : "http:\/\/www.politico.com\/news\/stories\/0712\/78291.html",
        "display_url" : "politico.com\/news\/stories\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "222808985827426304",
    "text" : "Great Op-Ed by Jeff Zients on the need for a balanced approach to replacing the sequester.\nhttp:\/\/t.co\/xM26wUud",
    "id" : 222808985827426304,
    "created_at" : "2012-07-10 21:46:16 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 222809800730361857,
  "created_at" : "2012-07-10 21:49:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyRefi",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/Ici5Uo4X",
      "expanded_url" : "http:\/\/on.wh.gov\/9tjp",
      "display_url" : "on.wh.gov\/9tjp"
    } ]
  },
  "geo" : { },
  "id_str" : "222803021762011136",
  "text" : "Ask an Expert: How would the President's mortgage refinance plan help underwater borrowers? Watch to find out: http:\/\/t.co\/Ici5Uo4X #MyRefi",
  "id" : 222803021762011136,
  "created_at" : "2012-07-10 21:22:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/P8K8n7je",
      "expanded_url" : "http:\/\/on.wh.gov\/WOhQ",
      "display_url" : "on.wh.gov\/WOhQ"
    } ]
  },
  "geo" : { },
  "id_str" : "222770046982823936",
  "text" : "Why does the President use so many pens to sign legislation?  Watch: Inside the White House: All the President's Pens http:\/\/t.co\/P8K8n7je",
  "id" : 222770046982823936,
  "created_at" : "2012-07-10 19:11:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/CfB0tLiB",
      "expanded_url" : "http:\/\/on.wh.gov\/3FGa",
      "display_url" : "on.wh.gov\/3FGa"
    } ]
  },
  "geo" : { },
  "id_str" : "222533339523981312",
  "text" : "Today President Obama called on Congress to extend middle class tax cuts for 98% of Americans making less than $250k: http:\/\/t.co\/CfB0tLiB",
  "id" : 222533339523981312,
  "created_at" : "2012-07-10 03:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/222527735074000896\/photo\/1",
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/VXQ7xV0Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxaTy8pCEAAlhpV.jpg",
      "id_str" : "222527735082389504",
      "id" : 222527735082389504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxaTy8pCEAAlhpV.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VXQ7xV0Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222527735074000896",
  "text" : "Photo of the Day: President Obama has interview prep in the Oval Office: http:\/\/t.co\/VXQ7xV0Y",
  "id" : 222527735074000896,
  "created_at" : "2012-07-10 03:08:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HUD News | not",
      "screen_name" : "HUDNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1881201980",
      "id" : 1881201980
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 56, 67 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 87, 94 ],
      "id_str" : "19262500",
      "id" : 19262500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecDonovan",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/UEGYesZw",
      "expanded_url" : "http:\/\/ow.ly\/c6TRT",
      "display_url" : "ow.ly\/c6TRT"
    } ]
  },
  "geo" : { },
  "id_str" : "222461201945333763",
  "text" : "RT @HUDNews: Join #SecDonovan on Thurs @ 3:15 EDT for a @WhiteHouse Google+ Hangout w\/ @Zillow http:\/\/t.co\/UEGYesZw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 43, 54 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Zillow",
        "screen_name" : "zillow",
        "indices" : [ 74, 81 ],
        "id_str" : "19262500",
        "id" : 19262500
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecDonovan",
        "indices" : [ 5, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/UEGYesZw",
        "expanded_url" : "http:\/\/ow.ly\/c6TRT",
        "display_url" : "ow.ly\/c6TRT"
      } ]
    },
    "geo" : { },
    "id_str" : "222345302030557184",
    "text" : "Join #SecDonovan on Thurs @ 3:15 EDT for a @WhiteHouse Google+ Hangout w\/ @Zillow http:\/\/t.co\/UEGYesZw",
    "id" : 222345302030557184,
    "created_at" : "2012-07-09 15:03:45 +0000",
    "user" : {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "protected" : false,
      "id_str" : "19948202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000438958545\/e9038252f910c840e582818a63dd9908_normal.jpeg",
      "id" : 19948202,
      "verified" : true
    }
  },
  "id" : 222461201945333763,
  "created_at" : "2012-07-09 22:44:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HUD News | not",
      "screen_name" : "HUDNews",
      "indices" : [ 47, 55 ],
      "id_str" : "1881201980",
      "id" : 1881201980
    }, {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 82, 89 ],
      "id_str" : "19262500",
      "id" : 19262500
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/YxUBAvyh",
      "expanded_url" : "http:\/\/on.wh.gov\/Ki3o",
      "display_url" : "on.wh.gov\/Ki3o"
    } ]
  },
  "geo" : { },
  "id_str" : "222456423303487488",
  "text" : "Join us for a White House Google+ Hangout with @HUDNews Sec. Donovan Moderated by @Zillow: http:\/\/t.co\/YxUBAvyh #WHHangout",
  "id" : 222456423303487488,
  "created_at" : "2012-07-09 22:25:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222440294744989697",
  "text" : "RT @Brundage44: Here are the facts: POTUS would extend tax cuts for 98% of Americans and 97% of Small Businesses, Congress needs to act  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/6Hqz81Dn",
        "expanded_url" : "http:\/\/1.usa.gov\/MgWRV9",
        "display_url" : "1.usa.gov\/MgWRV9"
      } ]
    },
    "geo" : { },
    "id_str" : "222418297315008512",
    "text" : "Here are the facts: POTUS would extend tax cuts for 98% of Americans and 97% of Small Businesses, Congress needs to act http:\/\/t.co\/6Hqz81Dn",
    "id" : 222418297315008512,
    "created_at" : "2012-07-09 19:53:49 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 222440294744989697,
  "created_at" : "2012-07-09 21:21:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "indices" : [ 3, 10 ],
      "id_str" : "19262500",
      "id" : 19262500
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222378752531898368",
  "text" : "RT @zillow: The\u00A0@WhiteHouse is hosting a Google+ Hangout about refinancing, moderated by Zillow! Join the conversation\u00A0http:\/\/t.co\/GHusQ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHHangout",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/GHusQ4DM",
        "expanded_url" : "http:\/\/bit.ly\/refi101",
        "display_url" : "bit.ly\/refi101"
      } ]
    },
    "geo" : { },
    "id_str" : "222364488471560193",
    "text" : "The\u00A0@WhiteHouse is hosting a Google+ Hangout about refinancing, moderated by Zillow! Join the conversation\u00A0http:\/\/t.co\/GHusQ4DM \u00A0#WHHangout",
    "id" : 222364488471560193,
    "created_at" : "2012-07-09 16:20:00 +0000",
    "user" : {
      "name" : "Zillow",
      "screen_name" : "zillow",
      "protected" : false,
      "id_str" : "19262500",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732338824936751104\/vJX0_tQy_normal.jpg",
      "id" : 19262500,
      "verified" : true
    }
  },
  "id" : 222378752531898368,
  "created_at" : "2012-07-09 17:16:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222364683527667712",
  "text" : "RT @WHLive: President Obama: \"Right now, our top priority has to be giving middle class families &amp; small businesses the security the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222364612836851714",
    "text" : "President Obama: \"Right now, our top priority has to be giving middle class families &amp; small businesses the security they deserve\"",
    "id" : 222364612836851714,
    "created_at" : "2012-07-09 16:20:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 222364683527667712,
  "created_at" : "2012-07-09 16:20:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222364469739786241",
  "text" : "RT @WHLive: President Obama: \"So my message to Congress is this: Pass a bill extending the tax cuts for the middle class &amp; I\u2019ll sign ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222364420238606336",
    "text" : "President Obama: \"So my message to Congress is this: Pass a bill extending the tax cuts for the middle class &amp; I\u2019ll sign it tomorrow\"",
    "id" : 222364420238606336,
    "created_at" : "2012-07-09 16:19:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 222364469739786241,
  "created_at" : "2012-07-09 16:19:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222364054008758272",
  "text" : "RT @WHLive: Obama: \"We all say we agree that we should extend the tax cuts for 98% of the American people...let\u2019s at least agree to do w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222364021154783235",
    "text" : "Obama: \"We all say we agree that we should extend the tax cuts for 98% of the American people...let\u2019s at least agree to do what we agree on\"",
    "id" : 222364021154783235,
    "created_at" : "2012-07-09 16:18:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 222364054008758272,
  "created_at" : "2012-07-09 16:18:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 116, 123 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/phC80lPK",
      "expanded_url" : "http:\/\/on.wh.gov\/VE00",
      "display_url" : "on.wh.gov\/VE00"
    } ]
  },
  "geo" : { },
  "id_str" : "222360902106755072",
  "text" : "Happening now: President Obama speaks on extending middle class tax cuts. Watch: http:\/\/t.co\/phC80lPK &amp; follow: @WHLive",
  "id" : 222360902106755072,
  "created_at" : "2012-07-09 16:05:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222345243373215744",
  "text" : "RT @pfeiffer44: President Obama today will push for extension of middle class tax cuts. Will the GOP join him to provide certainty for 9 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "222270982478512128",
    "text" : "President Obama today will push for extension of middle class tax cuts. Will the GOP join him to provide certainty for 98% of Americans?",
    "id" : 222270982478512128,
    "created_at" : "2012-07-09 10:08:26 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 222345243373215744,
  "created_at" : "2012-07-09 15:03:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/k73AD0cQ",
      "expanded_url" : "http:\/\/on.wh.gov\/GQrk",
      "display_url" : "on.wh.gov\/GQrk"
    } ]
  },
  "geo" : { },
  "id_str" : "222322155617140736",
  "text" : "Happening @ 11:50ET: President Obama speaks on the need for Congress to act to extend middle class tax cuts. Watch: http:\/\/t.co\/k73AD0cQ",
  "id" : 222322155617140736,
  "created_at" : "2012-07-09 13:31:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 41, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/dLKbR7PO",
      "expanded_url" : "http:\/\/1.usa.gov\/NhsVJn",
      "display_url" : "1.usa.gov\/NhsVJn"
    } ]
  },
  "geo" : { },
  "id_str" : "222021967337893888",
  "text" : "Obama: \"Congratulations to the people of #Libya for another milestone on their extraordinary transition to democracy\" http:\/\/t.co\/dLKbR7PO",
  "id" : 222021967337893888,
  "created_at" : "2012-07-08 17:38:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/221791927354396674\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Ne0YMgrb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxP2lTSCEAAKDJH.jpg",
      "id_str" : "221791927362785280",
      "id" : 221791927362785280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxP2lTSCEAAKDJH.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ne0YMgrb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221791927354396674",
  "text" : "Photo of the Day: President Obama checks out baked goods yesterday during a stop at Kretchmar's Bakery in Beaver, PA http:\/\/t.co\/Ne0YMgrb",
  "id" : 221791927354396674,
  "created_at" : "2012-07-08 02:24:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/gSG9afbC",
      "expanded_url" : "http:\/\/on.wh.gov\/e9Bf",
      "display_url" : "on.wh.gov\/e9Bf"
    } ]
  },
  "geo" : { },
  "id_str" : "221736223843164160",
  "text" : "\"Our mission isn't just to put people back to work \u2013 it's to rebuild an economy.\" -President Obama's Weekly Address: http:\/\/t.co\/gSG9afbC",
  "id" : 221736223843164160,
  "created_at" : "2012-07-07 22:43:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/CqDuSKga",
      "expanded_url" : "http:\/\/on.wh.gov\/GY4w",
      "display_url" : "on.wh.gov\/GY4w"
    } ]
  },
  "geo" : { },
  "id_str" : "221686598079750145",
  "text" : "President Obama's Weekly Address: Pushing Congress to Create Jobs, Keep College in Reach for Middle Class: http:\/\/t.co\/CqDuSKga",
  "id" : 221686598079750145,
  "created_at" : "2012-07-07 19:26:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 110, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/9XEJFISZ",
      "expanded_url" : "http:\/\/on.wh.gov\/ZwWS",
      "display_url" : "on.wh.gov\/ZwWS"
    } ]
  },
  "geo" : { },
  "id_str" : "221585322167902208",
  "text" : "\"You made this happen\" -President Obama at the student loan interest rate bill signing: http:\/\/t.co\/9XEJFISZ\n #DontDoubleMyRate",
  "id" : 221585322167902208,
  "created_at" : "2012-07-07 12:43:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 58, 66 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/221407996738158592\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/MhWlQMVh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxKZZmRCQAEHdDh.jpg",
      "id_str" : "221407996742352897",
      "id" : 221407996742352897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxKZZmRCQAEHdDh.jpg",
      "sizes" : [ {
        "h" : 1271,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MhWlQMVh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/EL5BOhGN",
      "expanded_url" : "http:\/\/on.wh.gov\/eUqK",
      "display_url" : "on.wh.gov\/eUqK"
    } ]
  },
  "geo" : { },
  "id_str" : "221407996738158592",
  "text" : "1 year ago today, President Obama participated in the 1st @Twitter Town Hall @ the White House: http:\/\/t.co\/EL5BOhGN http:\/\/t.co\/MhWlQMVh",
  "id" : 221407996738158592,
  "created_at" : "2012-07-07 00:59:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221354745359638528",
  "text" : "RT @WHLive: President Obama: \"I believe with every fiber of my being that a strong economy comes not from the top-down but from a strong ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221354691508973568",
    "text" : "President Obama: \"I believe with every fiber of my being that a strong economy comes not from the top-down but from a strong middle class\"",
    "id" : 221354691508973568,
    "created_at" : "2012-07-06 21:27:25 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 221354745359638528,
  "created_at" : "2012-07-06 21:27:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 102, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/dfEWfXpi",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "221354292001505280",
  "text" : "Watch now: President Obama signs a bill to keep student loan interest rates low: http:\/\/t.co\/dfEWfXpi #DontDoubleMyRate",
  "id" : 221354292001505280,
  "created_at" : "2012-07-06 21:25:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 9, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/SPuXootC",
      "expanded_url" : "http:\/\/on.wh.gov\/SNgs",
      "display_url" : "on.wh.gov\/SNgs"
    } ]
  },
  "geo" : { },
  "id_str" : "221346831001583616",
  "text" : "You said #DontDoubleMyRate &amp; it made all the difference. Watch why your voices mattered on student loans &amp; share: http:\/\/t.co\/SPuXootC",
  "id" : 221346831001583616,
  "created_at" : "2012-07-06 20:56:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 82, 93 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "milfams",
      "indices" : [ 73, 81 ]
    }, {
      "text" : "4thofJuly",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/ugtSsAa1",
      "expanded_url" : "http:\/\/on.wh.gov\/anvW",
      "display_url" : "on.wh.gov\/anvW"
    } ]
  },
  "geo" : { },
  "id_str" : "221291743864295424",
  "text" : "West Wing Week: 7\/6\/2012: WatchPresident Obama &amp; the First Lady host #milfams @WhiteHouse to celebrate #4thofJuly http:\/\/t.co\/ugtSsAa1",
  "id" : 221291743864295424,
  "created_at" : "2012-07-06 17:17:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 94, 105 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "milfams",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "4thofJuly",
      "indices" : [ 70, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221266502068875265",
  "text" : "RT @JoiningForces: The President &amp; First Lady hosted #milfams for #4thofJuly celebration  @whitehouse.Obamas greet guests on South L ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 75, 86 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/221026317410369536\/photo\/1",
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/TS5eq8tL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AxE-Q7-CAAA-N_B.jpg",
        "id_str" : "221026317414563840",
        "id" : 221026317414563840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxE-Q7-CAAA-N_B.jpg",
        "sizes" : [ {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TS5eq8tL"
      } ],
      "hashtags" : [ {
        "text" : "milfams",
        "indices" : [ 38, 46 ]
      }, {
        "text" : "4thofJuly",
        "indices" : [ 51, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221026317410369536",
    "text" : "The President &amp; First Lady hosted #milfams for #4thofJuly celebration  @whitehouse.Obamas greet guests on South Lawn: http:\/\/t.co\/TS5eq8tL",
    "id" : 221026317410369536,
    "created_at" : "2012-07-05 23:42:35 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 221266502068875265,
  "created_at" : "2012-07-06 15:36:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/221056925977149441\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/yh1czZGJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxFaGlyCAAAKHJt.jpg",
      "id_str" : "221056925985538048",
      "id" : 221056925985538048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxFaGlyCAAAKHJt.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yh1czZGJ"
    } ],
    "hashtags" : [ {
      "text" : "4thofJuly",
      "indices" : [ 8, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/RgkxVLmI",
      "expanded_url" : "http:\/\/on.wh.gov\/O3RU",
      "display_url" : "on.wh.gov\/O3RU"
    } ]
  },
  "geo" : { },
  "id_str" : "221056925977149441",
  "text" : "Photos: #4thofJuly at the White House: http:\/\/t.co\/RgkxVLmI incl. Obamas watching fireworks over the Natl Mall in '09: http:\/\/t.co\/yh1czZGJ",
  "id" : 221056925977149441,
  "created_at" : "2012-07-06 01:44:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brad Paisley",
      "screen_name" : "BradPaisley",
      "indices" : [ 107, 119 ],
      "id_str" : "41265813",
      "id" : 41265813
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/220958498400387072\/photo\/1",
      "indices" : [ 125, 145 ],
      "url" : "http:\/\/t.co\/hmnEFKsu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxEAlWfCQAE4XCm.jpg",
      "id_str" : "220958498408775681",
      "id" : 220958498408775681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxEAlWfCQAE4XCm.jpg",
      "sizes" : [ {
        "h" : 369,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 369,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/hmnEFKsu"
    } ],
    "hashtags" : [ {
      "text" : "4thofJuly",
      "indices" : [ 45, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/P9Im5WZF",
      "expanded_url" : "http:\/\/on.wh.gov\/e2en",
      "display_url" : "on.wh.gov\/e2en"
    } ]
  },
  "geo" : { },
  "id_str" : "220958498400387072",
  "text" : "1,200 troops &amp; their families celebrated #4thofJuly at the WH w\/ fireworks: http:\/\/t.co\/P9Im5WZF &amp; @BradPaisley show http:\/\/t.co\/hmnEFKsu",
  "id" : 220958498400387072,
  "created_at" : "2012-07-05 19:13:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "July4th",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/3EqQtL28",
      "expanded_url" : "http:\/\/on.wh.gov\/rxUj",
      "display_url" : "on.wh.gov\/rxUj"
    } ]
  },
  "geo" : { },
  "id_str" : "220918687408988162",
  "text" : "President Obama began his #July4th celebrations by hosting a naturalization ceremony for active duty service members: http:\/\/t.co\/3EqQtL28",
  "id" : 220918687408988162,
  "created_at" : "2012-07-05 16:34:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/220855972917284864\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/CLGF6IXF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AxCjVlTCEAAfxQ7.jpg",
      "id_str" : "220855972925673472",
      "id" : 220855972925673472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AxCjVlTCEAAfxQ7.jpg",
      "sizes" : [ {
        "h" : 1278,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/CLGF6IXF"
    } ],
    "hashtags" : [ {
      "text" : "FourthofJuly",
      "indices" : [ 7, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/rOjI2p1x",
      "expanded_url" : "http:\/\/on.wh.gov\/frqG",
      "display_url" : "on.wh.gov\/frqG"
    } ]
  },
  "geo" : { },
  "id_str" : "220855972917284864",
  "text" : "On the #FourthofJuly, President Obama salutes new American citizens: http:\/\/t.co\/rOjI2p1x Photo of WH ceremony: http:\/\/t.co\/CLGF6IXF",
  "id" : 220855972917284864,
  "created_at" : "2012-07-05 12:25:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "July4th",
      "indices" : [ 28, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/UFittNf1",
      "expanded_url" : "http:\/\/youtu.be\/MmMitkvoLB8",
      "display_url" : "youtu.be\/MmMitkvoLB8"
    } ]
  },
  "geo" : { },
  "id_str" : "220707100521803776",
  "text" : "Missed the fireworks? Watch #July4th National Mall show from the South Lawn of the White House: http:\/\/t.co\/UFittNf1",
  "id" : 220707100521803776,
  "created_at" : "2012-07-05 02:34:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220703000421871617",
  "text" : "RT @AmbassadorRice: I feel blessed to be an American and serve my country. Happy 4th, everyone.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "220702134453280769",
    "text" : "I feel blessed to be an American and serve my country. Happy 4th, everyone.",
    "id" : 220702134453280769,
    "created_at" : "2012-07-05 02:14:23 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 220703000421871617,
  "created_at" : "2012-07-05 02:17:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 73, 84 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/gaJge5xR",
      "expanded_url" : "http:\/\/on.wh.gov\/DYwI",
      "display_url" : "on.wh.gov\/DYwI"
    } ]
  },
  "geo" : { },
  "id_str" : "220697094850228225",
  "text" : "\"We will always be there for you\" -President Obama to military heroes at @WhiteHouse Fourth of July Celebration: http:\/\/t.co\/gaJge5xR",
  "id" : 220697094850228225,
  "created_at" : "2012-07-05 01:54:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USO",
      "screen_name" : "the_USO",
      "indices" : [ 54, 62 ],
      "id_str" : "36681590",
      "id" : 36681590
    }, {
      "name" : "Brad Paisley",
      "screen_name" : "BradPaisley",
      "indices" : [ 73, 85 ],
      "id_str" : "41265813",
      "id" : 41265813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FourthOfJuly",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "220669584783585280",
  "text" : "Starting soon: #FourthOfJuly Celebration at the WH w\/ @the_USO show feat @BradPaisley, then fireworks on the Mall: http:\/\/t.co\/u95tzH8r",
  "id" : 220669584783585280,
  "created_at" : "2012-07-05 00:05:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keb' Mo'",
      "screen_name" : "kebmomusic",
      "indices" : [ 63, 74 ],
      "id_str" : "20190447",
      "id" : 20190447
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "America",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/PB3HXsP6",
      "expanded_url" : "http:\/\/on.wh.gov\/ac6z",
      "display_url" : "on.wh.gov\/ac6z"
    } ]
  },
  "geo" : { },
  "id_str" : "220650312862662657",
  "text" : "Happy 4th of July! Watch \"#America the Beautiful\" performed by @kebmomusic: http:\/\/t.co\/PB3HXsP6",
  "id" : 220650312862662657,
  "created_at" : "2012-07-04 22:48:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 81, 92 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4thofJuly",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220648425220349953",
  "text" : "RT @vj44: Happy #4thofJuly! Honored to celebrate by welcoming newest citizens to @WhiteHouse for naturalization ceremony. Watch: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 71, 82 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "4thofJuly",
        "indices" : [ 6, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/TcNXpCJ6",
        "expanded_url" : "http:\/\/youtu.be\/vlNDxtVSZIA",
        "display_url" : "youtu.be\/vlNDxtVSZIA"
      } ]
    },
    "geo" : { },
    "id_str" : "220647200160624641",
    "text" : "Happy #4thofJuly! Honored to celebrate by welcoming newest citizens to @WhiteHouse for naturalization ceremony. Watch: http:\/\/t.co\/TcNXpCJ6",
    "id" : 220647200160624641,
    "created_at" : "2012-07-04 22:36:06 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 220648425220349953,
  "created_at" : "2012-07-04 22:40:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USO",
      "screen_name" : "the_USO",
      "indices" : [ 3, 11 ],
      "id_str" : "36681590",
      "id" : 36681590
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "joiningforces",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220641272019431425",
  "text" : "RT @the_USO: \"America will always be there for you, like you were there for us\" President Obama to military families #joiningforces",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "joiningforces",
        "indices" : [ 104, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "220640227939725312",
    "text" : "\"America will always be there for you, like you were there for us\" President Obama to military families #joiningforces",
    "id" : 220640227939725312,
    "created_at" : "2012-07-04 22:08:24 +0000",
    "user" : {
      "name" : "USO",
      "screen_name" : "the_USO",
      "protected" : false,
      "id_str" : "36681590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684130528916848640\/woRtb09d_normal.jpg",
      "id" : 36681590,
      "verified" : true
    }
  },
  "id" : 220641272019431425,
  "created_at" : "2012-07-04 22:12:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 102, 113 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "July4th",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/dfEWfXpi",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "220638810562772993",
  "text" : "Happening now: President Obama &amp; the First Lady welcome military families to #July4th celebration @WhiteHouse. Watch: http:\/\/t.co\/dfEWfXpi",
  "id" : 220638810562772993,
  "created_at" : "2012-07-04 22:02:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keb' Mo'",
      "screen_name" : "kebmomusic",
      "indices" : [ 3, 14 ],
      "id_str" : "20190447",
      "id" : 20190447
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "America",
      "indices" : [ 29, 37 ]
    }, {
      "text" : "July4th",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/8bcENHh2",
      "expanded_url" : "http:\/\/youtu.be\/KSrvulzNb4k",
      "display_url" : "youtu.be\/KSrvulzNb4k"
    } ]
  },
  "geo" : { },
  "id_str" : "220585717523431424",
  "text" : "MT @kebmomusic: Just watched #America The Beautiful #July4th WH post... wow, what a great honor to be included. -Kmo http:\/\/t.co\/8bcENHh2",
  "id" : 220585717523431424,
  "created_at" : "2012-07-04 18:31:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/Yryf2Hkb",
      "expanded_url" : "http:\/\/JoiningForces.gov",
      "display_url" : "JoiningForces.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "220563217125097473",
  "text" : "RT @JoiningForces: Happy 4th of July! Please join me in honoring our military &amp; their families. Say thanks at http:\/\/t.co\/Yryf2Hkb \u2013 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "joiningforces",
        "indices" : [ 120, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/Yryf2Hkb",
        "expanded_url" : "http:\/\/JoiningForces.gov",
        "display_url" : "JoiningForces.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "220562820436209665",
    "text" : "Happy 4th of July! Please join me in honoring our military &amp; their families. Say thanks at http:\/\/t.co\/Yryf2Hkb \u2013mo #joiningforces",
    "id" : 220562820436209665,
    "created_at" : "2012-07-04 17:00:48 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 220563217125097473,
  "created_at" : "2012-07-04 17:02:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "220529888753483776",
  "text" : "Happening now: President Obama speaks at a Naturalization Ceremony for Service Members. Watch: http:\/\/t.co\/u95tzH8r",
  "id" : 220529888753483776,
  "created_at" : "2012-07-04 14:49:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/220336632576999426\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/qcIol8rj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aw7K__xCAAACrqX.jpg",
      "id_str" : "220336632585388032",
      "id" : 220336632585388032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aw7K__xCAAACrqX.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      } ],
      "display_url" : "pic.twitter.com\/qcIol8rj"
    } ],
    "hashtags" : [ {
      "text" : "4thofJuly",
      "indices" : [ 15, 25 ]
    }, {
      "text" : "fireworks",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/SIxv0ruV",
      "expanded_url" : "http:\/\/on.wh.gov\/AX44",
      "display_url" : "on.wh.gov\/AX44"
    } ]
  },
  "geo" : { },
  "id_str" : "220336632576999426",
  "text" : "Photo Gallery: #4thofJuly at the White House: \nhttp:\/\/t.co\/SIxv0ruV including #fireworks on the National Mall from 1954 http:\/\/t.co\/qcIol8rj",
  "id" : 220336632576999426,
  "created_at" : "2012-07-04 02:02:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 32, 41 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/220146906964295680\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/zkY3ww97",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aw4ecgxCAAAyptl.jpg",
      "id_str" : "220146906968489984",
      "id" : 220146906968489984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aw4ecgxCAAAyptl.jpg",
      "sizes" : [ {
        "h" : 328,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/zkY3ww97"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/mFs2DckE",
      "expanded_url" : "http:\/\/on.wh.gov\/BCaO",
      "display_url" : "on.wh.gov\/BCaO"
    } ]
  },
  "geo" : { },
  "id_str" : "220146906964295680",
  "text" : "Love great photos? The Dept. of @Interior has a tumblr with pics from America's public lands: http:\/\/t.co\/mFs2DckE http:\/\/t.co\/zkY3ww97",
  "id" : 220146906964295680,
  "created_at" : "2012-07-03 13:28:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/219980999218561025\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/Eo9v2PlY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aw2HjaSCAAASQ5D.jpg",
      "id_str" : "219980999231143936",
      "id" : 219980999231143936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aw2HjaSCAAASQ5D.jpg",
      "sizes" : [ {
        "h" : 284,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Eo9v2PlY"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/zFiGeWTV",
      "expanded_url" : "http:\/\/on.wh.gov\/zvpy",
      "display_url" : "on.wh.gov\/zvpy"
    } ]
  },
  "geo" : { },
  "id_str" : "219980999218561025",
  "text" : "$4,200: The average savings for a senior on Medicare thanks to the Affordable Care Act: http:\/\/t.co\/zFiGeWTV #ACA http:\/\/t.co\/Eo9v2PlY",
  "id" : 219980999218561025,
  "created_at" : "2012-07-03 02:28:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/219948001572036613\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/3rJgpEuL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aw1pisdCIAAv9b1.jpg",
      "id_str" : "219948001580425216",
      "id" : 219948001580425216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aw1pisdCIAAv9b1.jpg",
      "sizes" : [ {
        "h" : 284,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3rJgpEuL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/fL4QtpnV",
      "expanded_url" : "http:\/\/on.wh.gov\/L2GN",
      "display_url" : "on.wh.gov\/L2GN"
    } ]
  },
  "geo" : { },
  "id_str" : "219948001572036613",
  "text" : "Health reform by the numbers: 86 million: The number of Americans getting free preventative care.  http:\/\/t.co\/fL4QtpnV http:\/\/t.co\/3rJgpEuL",
  "id" : 219948001572036613,
  "created_at" : "2012-07-03 00:17:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 11, 19 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Jamie Smith",
      "screen_name" : "JSmith44",
      "indices" : [ 76, 85 ],
      "id_str" : "2821610174",
      "id" : 2821610174
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219851838021836802",
  "text" : "Welcome to @Twitter, Deputy White House Press Secretary Jamie Smith! Follow @JSmith44",
  "id" : 219851838021836802,
  "created_at" : "2012-07-02 17:55:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 97, 101 ]
    }, {
      "text" : "ACA",
      "indices" : [ 102, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/rwJQQi4n",
      "expanded_url" : "http:\/\/on.wh.gov\/eY1L",
      "display_url" : "on.wh.gov\/eY1L"
    } ]
  },
  "geo" : { },
  "id_str" : "219570295038676992",
  "text" : "Get the Facts: See how the health care law is helping people in your state: http:\/\/t.co\/rwJQQi4n #hcr #ACA",
  "id" : 219570295038676992,
  "created_at" : "2012-07-01 23:16:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 81, 85 ]
    }, {
      "text" : "HCR",
      "indices" : [ 86, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/VPz9JtR0",
      "expanded_url" : "http:\/\/on.wh.gov\/yDa4",
      "display_url" : "on.wh.gov\/yDa4"
    } ]
  },
  "geo" : { },
  "id_str" : "219438833589174272",
  "text" : "Supreme Court Upholds President Obama's Health Care Reform: http:\/\/t.co\/VPz9JtR0 #ACA #HCR",
  "id" : 219438833589174272,
  "created_at" : "2012-07-01 14:34:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]