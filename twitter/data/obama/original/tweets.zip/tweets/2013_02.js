Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsmovetour",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/hGmyltV21w",
      "expanded_url" : "http:\/\/at.wh.gov\/i9EGO",
      "display_url" : "at.wh.gov\/i9EGO"
    } ]
  },
  "geo" : { },
  "id_str" : "307339964176277505",
  "text" : "RT @letsmove: 2 days, 3 states, thousands of kids and lots of dancing. Check out photos from #letsmovetour http:\/\/t.co\/hGmyltV21w http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/letsmove\/status\/307323308288925696\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/5VB49GOlTG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BEPU665CYAASTiF.jpg",
        "id_str" : "307323308297314304",
        "id" : 307323308297314304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEPU665CYAASTiF.jpg",
        "sizes" : [ {
          "h" : 372,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 726
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 726
        } ],
        "display_url" : "pic.twitter.com\/5VB49GOlTG"
      } ],
      "hashtags" : [ {
        "text" : "letsmovetour",
        "indices" : [ 79, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/hGmyltV21w",
        "expanded_url" : "http:\/\/at.wh.gov\/i9EGO",
        "display_url" : "at.wh.gov\/i9EGO"
      } ]
    },
    "geo" : { },
    "id_str" : "307323308288925696",
    "text" : "2 days, 3 states, thousands of kids and lots of dancing. Check out photos from #letsmovetour http:\/\/t.co\/hGmyltV21w http:\/\/t.co\/5VB49GOlTG",
    "id" : 307323308288925696,
    "created_at" : "2013-03-01 02:56:01 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 307339964176277505,
  "created_at" : "2013-03-01 04:02:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 40, 43 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 60, 71 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/307292904911679489\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/ppUM3XPc8g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEO5RNfCMAEaXPY.jpg",
      "id_str" : "307292904920068097",
      "id" : 307292904920068097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEO5RNfCMAEaXPY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/ppUM3XPc8g"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307292904911679489",
  "text" : "Photo of the Day: President Obama &amp; @VP Biden talk with @USTreasury Sec. Jack Lew following his swearing-in ceremony: http:\/\/t.co\/ppUM3XPc8g",
  "id" : 307292904911679489,
  "created_at" : "2013-03-01 00:55:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 96, 107 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307271651039518720",
  "text" : "RT @VP: PHOTO: VP meets with parents of teen dating violence victims in his office today at the @whitehouse. (WH Photo) #VAWA http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 88, 99 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/307265601469046784\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/KmXmxy55jk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BEOgb8PCYAEkp6G.jpg",
        "id_str" : "307265601477435393",
        "id" : 307265601477435393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEOgb8PCYAEkp6G.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/KmXmxy55jk"
      } ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 112, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "307265601469046784",
    "text" : "PHOTO: VP meets with parents of teen dating violence victims in his office today at the @whitehouse. (WH Photo) #VAWA http:\/\/t.co\/KmXmxy55jk",
    "id" : 307265601469046784,
    "created_at" : "2013-02-28 23:06:43 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 307271651039518720,
  "created_at" : "2013-02-28 23:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 34, 37 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 54, 65 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/EInn2T0SoX",
      "expanded_url" : "http:\/\/flic.kr\/p\/dYvteR",
      "display_url" : "flic.kr\/p\/dYvteR"
    } ]
  },
  "geo" : { },
  "id_str" : "307235926499815424",
  "text" : "Photo: President Obama watches as @VP Biden swears in @USTreasury Secretary Jack Lew during a ceremony in the Oval: http:\/\/t.co\/EInn2T0SoX",
  "id" : 307235926499815424,
  "created_at" : "2013-02-28 21:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307233826982223872",
  "text" : "RT @Simas44: R's proposal to avoid the sequester protects wealthy &amp; forces middle class to bear the burden of deficit reduction: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/x4058nfRYp",
        "expanded_url" : "http:\/\/wh.gov\/sequester",
        "display_url" : "wh.gov\/sequester"
      } ]
    },
    "geo" : { },
    "id_str" : "307229817693151232",
    "text" : "R's proposal to avoid the sequester protects wealthy &amp; forces middle class to bear the burden of deficit reduction: http:\/\/t.co\/x4058nfRYp",
    "id" : 307229817693151232,
    "created_at" : "2013-02-28 20:44:31 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 307233826982223872,
  "created_at" : "2013-02-28 21:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307201823683514368",
  "text" : "RT @VP: Happening now: Vice President Biden delivers remarks on the passage of the Violence Against Women Act. Watch: http:\/\/t.co\/bv0q4S ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/bv0q4STu6F",
        "expanded_url" : "http:\/\/WH.gov\/Live",
        "display_url" : "WH.gov\/Live"
      } ]
    },
    "geo" : { },
    "id_str" : "307201572293709825",
    "text" : "Happening now: Vice President Biden delivers remarks on the passage of the Violence Against Women Act. Watch: http:\/\/t.co\/bv0q4STu6F #VAWA",
    "id" : 307201572293709825,
    "created_at" : "2013-02-28 18:52:17 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 307201823683514368,
  "created_at" : "2013-02-28 18:53:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/5IstJKgOq0",
      "expanded_url" : "http:\/\/at.wh.gov\/i8J49",
      "display_url" : "at.wh.gov\/i8J49"
    } ]
  },
  "geo" : { },
  "id_str" : "307183281353404416",
  "text" : "Statement from President Obama on the House Passage of the Violence Against Women Act: http:\/\/t.co\/5IstJKgOq0 #VAWA",
  "id" : 307183281353404416,
  "created_at" : "2013-02-28 17:39:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/SM819DOy2e",
      "expanded_url" : "http:\/\/flic.kr\/p\/dYgHZK",
      "display_url" : "flic.kr\/p\/dYgHZK"
    } ]
  },
  "geo" : { },
  "id_str" : "306954569685016577",
  "text" : "Photo of the Day: President Obama talks w\/ Congressional leaders at the Capitol before Rosa Parks statue dedication: http:\/\/t.co\/SM819DOy2e",
  "id" : 306954569685016577,
  "created_at" : "2013-02-28 02:30:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/306938558894186497\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/rYbTjGxr1G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEJ2_jsCIAEeAk2.jpg",
      "id_str" : "306938558898380801",
      "id" : 306938558898380801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEJ2_jsCIAEeAk2.jpg",
      "sizes" : [ {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rYbTjGxr1G"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/8oqcpWSPAo",
      "expanded_url" : "http:\/\/at.wh.gov\/i7giq",
      "display_url" : "at.wh.gov\/i7giq"
    } ]
  },
  "geo" : { },
  "id_str" : "306938558894186497",
  "text" : "\"She helped change America &amp; change the world\" \u2014President Obama at Rosa Parks statue unveiling http:\/\/t.co\/8oqcpWSPAo http:\/\/t.co\/rYbTjGxr1G",
  "id" : 306938558894186497,
  "created_at" : "2013-02-28 01:27:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 79, 90 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/FpVImEvYlN",
      "expanded_url" : "http:\/\/at.wh.gov\/i7fRd",
      "display_url" : "at.wh.gov\/i7fRd"
    } ]
  },
  "geo" : { },
  "id_str" : "306927738068013056",
  "text" : "Statement from President Obama on the Confirmation of Jack Lew as Secretary of @USTreasury: http:\/\/t.co\/FpVImEvYlN",
  "id" : 306927738068013056,
  "created_at" : "2013-02-28 00:44:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Code.org",
      "screen_name" : "codeorg",
      "indices" : [ 33, 41 ],
      "id_str" : "850107536",
      "id" : 850107536
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "code",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/6l7M0pRyNo",
      "expanded_url" : "http:\/\/youtu.be\/nKIu9yen5nc",
      "display_url" : "youtu.be\/nKIu9yen5nc"
    }, {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/mAKOK1K5SO",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=PClfyIbIr5Q",
      "display_url" : "youtube.com\/watch?v=PClfyI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306910030479892480",
  "text" : "Lots of buzz around this awesome @codeorg video: http:\/\/t.co\/6l7M0pRyNo &amp; here's the President on kids learning #code http:\/\/t.co\/mAKOK1K5SO",
  "id" : 306910030479892480,
  "created_at" : "2013-02-27 23:33:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/306898992107757568\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Nx3EuovTp6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEJTAd7CIAECWIF.jpg",
      "id_str" : "306898992111951873",
      "id" : 306898992111951873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEJTAd7CIAECWIF.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/Nx3EuovTp6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/DRFsn5VCG0",
      "expanded_url" : "http:\/\/wh.gov\/sequester",
      "display_url" : "wh.gov\/sequester"
    } ]
  },
  "geo" : { },
  "id_str" : "306898992107757568",
  "text" : "Republicans in Congress are choosing jet owners over teacher jobs: http:\/\/t.co\/DRFsn5VCG0 http:\/\/t.co\/Nx3EuovTp6",
  "id" : 306898992107757568,
  "created_at" : "2013-02-27 22:49:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/PCXeLxDwZK",
      "expanded_url" : "http:\/\/youtu.be\/rs4XUpoa5wM",
      "display_url" : "youtu.be\/rs4XUpoa5wM"
    } ]
  },
  "geo" : { },
  "id_str" : "306813356092829696",
  "text" : "RT @Simas44: Listen to a teacher of the year describe what happens when education is cut: http:\/\/t.co\/PCXeLxDwZK Let's cut tax loopholes ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/PCXeLxDwZK",
        "expanded_url" : "http:\/\/youtu.be\/rs4XUpoa5wM",
        "display_url" : "youtu.be\/rs4XUpoa5wM"
      } ]
    },
    "geo" : { },
    "id_str" : "306797796906897409",
    "text" : "Listen to a teacher of the year describe what happens when education is cut: http:\/\/t.co\/PCXeLxDwZK Let's cut tax loopholes instead.",
    "id" : 306797796906897409,
    "created_at" : "2013-02-27 16:07:49 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 306813356092829696,
  "created_at" : "2013-02-27 17:09:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306809163672080385",
  "text" : "Obama: \"Rosa Parks tells us there is always something we can do. She tells us that we all have responsibilities, to ourselves &amp; one another\"",
  "id" : 306809163672080385,
  "created_at" : "2013-02-27 16:52:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "306807636161085440",
  "text" : "President Obama: \"Today, [Rosa Parks] takes her rightful place among those who have shaped this nation\u2019s course\" http:\/\/t.co\/b4tqL3nPDV",
  "id" : 306807636161085440,
  "created_at" : "2013-02-27 16:46:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306807475439550464",
  "text" : "President Obama on Rosa Parks: \"In a single moment, with the simplest of gestures, she helped change America \u2013 and change the world\"",
  "id" : 306807475439550464,
  "created_at" : "2013-02-27 16:46:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/yzlFGDWNE1",
      "expanded_url" : "http:\/\/at.wh.gov\/i6fY3",
      "display_url" : "at.wh.gov\/i6fY3"
    } ]
  },
  "geo" : { },
  "id_str" : "306799341270626305",
  "text" : "Watch live: President Obama speaks at the unveiling of the Rosa Parks statue\nat the Capitol: http:\/\/t.co\/yzlFGDWNE1",
  "id" : 306799341270626305,
  "created_at" : "2013-02-27 16:13:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/4lYDrZjNip",
      "expanded_url" : "http:\/\/at.wh.gov\/i6aLu",
      "display_url" : "at.wh.gov\/i6aLu"
    } ]
  },
  "geo" : { },
  "id_str" : "306795044864675840",
  "text" : "Happening at 11ET: President Obama speaks at the unveiling of the Rosa Parks statue\nat the Capitol. Watch: http:\/\/t.co\/4lYDrZjNip",
  "id" : 306795044864675840,
  "created_at" : "2013-02-27 15:56:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/306618688000380928\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/SXtj5dSNvg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEFUEnwCUAACObg.jpg",
      "id_str" : "306618688004575232",
      "id" : 306618688004575232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEFUEnwCUAACObg.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/SXtj5dSNvg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/YRdM5d89hU",
      "expanded_url" : "http:\/\/wh.gov\/vS2r",
      "display_url" : "wh.gov\/vS2r"
    } ]
  },
  "geo" : { },
  "id_str" : "306618688000380928",
  "text" : "Today, the President toured a shipyard in Newport News &amp; spoke on the impact of the sequester: http:\/\/t.co\/YRdM5d89hU http:\/\/t.co\/SXtj5dSNvg",
  "id" : 306618688000380928,
  "created_at" : "2013-02-27 04:16:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/306578678966521856\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/a5wqreuSgO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEEvryhCEAAZ8on.jpg",
      "id_str" : "306578678979104768",
      "id" : 306578678979104768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEEvryhCEAAZ8on.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/a5wqreuSgO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/c1bqqBOIxI",
      "expanded_url" : "http:\/\/on.wh.gov\/DT3dYZ5",
      "display_url" : "on.wh.gov\/DT3dYZ5"
    } ]
  },
  "geo" : { },
  "id_str" : "306578678966521856",
  "text" : "RT if you agree: Our troops &amp; veterans shouldn't have to bear the burden of deficit reduction: http:\/\/t.co\/c1bqqBOIxI http:\/\/t.co\/a5wqreuSgO",
  "id" : 306578678966521856,
  "created_at" : "2013-02-27 01:37:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/LvWiTPXN2p",
      "expanded_url" : "http:\/\/at.wh.gov\/i4Vym",
      "display_url" : "at.wh.gov\/i4Vym"
    } ]
  },
  "geo" : { },
  "id_str" : "306565646664212480",
  "text" : "Full video: President Obama speaks on the impact the sequester will have on jobs &amp; middle class families. Watch: http:\/\/t.co\/LvWiTPXN2p",
  "id" : 306565646664212480,
  "created_at" : "2013-02-27 00:45:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/eaiVEqbiNO",
      "expanded_url" : "http:\/\/at.wh.gov\/i4W1A",
      "display_url" : "at.wh.gov\/i4W1A"
    } ]
  },
  "geo" : { },
  "id_str" : "306548072895361025",
  "text" : "Statement from the President on the Confirmation of Chuck Hagel as Secretary of Defense:  http:\/\/t.co\/eaiVEqbiNO",
  "id" : 306548072895361025,
  "created_at" : "2013-02-26 23:35:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306475132833120256",
  "text" : "President Obama: \"I need you to keep up the pressure and keep up the effort, and keep up the fight, I guarantee you \u2013 Congress will listen\"",
  "id" : 306475132833120256,
  "created_at" : "2013-02-26 18:45:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306474204658810881",
  "text" : "\"Our North Star is a growing economy that creates good, middle-class jobs.\" \u2014President Obama",
  "id" : 306474204658810881,
  "created_at" : "2013-02-26 18:41:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306473945710854144",
  "text" : "\"We can\u2019t ask seniors &amp; working families like yours to shoulder the entire burden of deficit reduction\" \u2014President Obama in Newport News, VA",
  "id" : 306473945710854144,
  "created_at" : "2013-02-26 18:40:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306472812569305088",
  "text" : "RT @PressSec: POTUS @ Newport News Shipbldg, maker VA-class subs: \"hundreds of thousands of jobs are in jeopardy because of politics in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306472604804456449",
    "text" : "POTUS @ Newport News Shipbldg, maker VA-class subs: \"hundreds of thousands of jobs are in jeopardy because of politics in Washington.\"",
    "id" : 306472604804456449,
    "created_at" : "2013-02-26 18:35:37 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 306472812569305088,
  "created_at" : "2013-02-26 18:36:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/305385254997331969\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Lf4QeXtGZu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDzyRXxCEAA_HjX.jpg",
      "id_str" : "305385255005720576",
      "id" : 305385255005720576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDzyRXxCEAA_HjX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1013,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 1013,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1013,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/Lf4QeXtGZu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306472312063029249",
  "text" : "Obama: \"I\u2019ve laid out a plan that details how we can pay down our deficit in a way that\u2019s balanced &amp; responsible\" http:\/\/t.co\/Lf4QeXtGZu",
  "id" : 306472312063029249,
  "created_at" : "2013-02-26 18:34:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/DRFsn5VCG0",
      "expanded_url" : "http:\/\/wh.gov\/sequester",
      "display_url" : "wh.gov\/sequester"
    } ]
  },
  "geo" : { },
  "id_str" : "306471897128910848",
  "text" : "Pres. Obama: \"These cuts are wrong. They\u2019re not smart...They\u2019re a self-inflicted wound that doesn\u2019t have to happen\" http:\/\/t.co\/DRFsn5VCG0",
  "id" : 306471897128910848,
  "created_at" : "2013-02-26 18:32:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306470432880611328",
  "text" : "RT @WHLive: Obama: \"In a few days, Congress might allow a series of...arbitrary budget cuts to take place \u2013 known in Washington as \u201Cthe  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "306470240198471684",
    "text" : "Obama: \"In a few days, Congress might allow a series of...arbitrary budget cuts to take place \u2013 known in Washington as \u201Cthe sequester.\u201D",
    "id" : 306470240198471684,
    "created_at" : "2013-02-26 18:26:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 306470432880611328,
  "created_at" : "2013-02-26 18:26:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/84fStMZ8p2",
      "expanded_url" : "http:\/\/at.wh.gov\/i4hGO",
      "display_url" : "at.wh.gov\/i4hGO"
    } ]
  },
  "geo" : { },
  "id_str" : "306469418286866433",
  "text" : "Happening now: President Obama speaks on the impact the sequester will have on jobs &amp; middle class families. Watch: http:\/\/t.co\/84fStMZ8p2",
  "id" : 306469418286866433,
  "created_at" : "2013-02-26 18:22:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/Mffizne435",
      "expanded_url" : "http:\/\/at.wh.gov\/i3Y8b",
      "display_url" : "at.wh.gov\/i3Y8b"
    } ]
  },
  "geo" : { },
  "id_str" : "306432223341580289",
  "text" : "At 1:05ET: President Obama speaks on the impact the sequester will have on jobs &amp; middle class families. Watch live: http:\/\/t.co\/Mffizne435",
  "id" : 306432223341580289,
  "created_at" : "2013-02-26 15:55:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/306216292149506049\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/jyzbml8ZKE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD_mGGaCMAA8J7G.jpg",
      "id_str" : "306216292157894656",
      "id" : 306216292157894656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD_mGGaCMAA8J7G.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/jyzbml8ZKE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/fesXHPGPco",
      "expanded_url" : "http:\/\/on.wh.gov\/ijBJyFN",
      "display_url" : "on.wh.gov\/ijBJyFN"
    } ]
  },
  "geo" : { },
  "id_str" : "306216292149506049",
  "text" : "RT if you agree: Our troops shouldn't have to bear the burden of deficit reduction: http:\/\/t.co\/fesXHPGPco http:\/\/t.co\/jyzbml8ZKE",
  "id" : 306216292149506049,
  "created_at" : "2013-02-26 01:37:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/306184254491095040\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/yxaGapFva5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD_I9Q1CcAAvMCY.jpg",
      "id_str" : "306184254499483648",
      "id" : 306184254499483648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD_I9Q1CcAAvMCY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/yxaGapFva5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306184254491095040",
  "text" : "Photo of the Day: President Obama takes questions during a meeting with the National Governors Association at the WH: http:\/\/t.co\/yxaGapFva5",
  "id" : 306184254491095040,
  "created_at" : "2013-02-25 23:29:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 99, 110 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/JSTE4QnNvy",
      "expanded_url" : "http:\/\/flic.kr\/p\/dXQYxQ",
      "display_url" : "flic.kr\/p\/dXQYxQ"
    } ]
  },
  "geo" : { },
  "id_str" : "306176935376080897",
  "text" : "RT @VP: Check out the new official portrait of Vice President Biden in his West Wing Office at the @WhiteHouse: http:\/\/t.co\/JSTE4QnNvy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 91, 102 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/JSTE4QnNvy",
        "expanded_url" : "http:\/\/flic.kr\/p\/dXQYxQ",
        "display_url" : "flic.kr\/p\/dXQYxQ"
      } ]
    },
    "geo" : { },
    "id_str" : "306175907922583552",
    "text" : "Check out the new official portrait of Vice President Biden in his West Wing Office at the @WhiteHouse: http:\/\/t.co\/JSTE4QnNvy",
    "id" : 306175907922583552,
    "created_at" : "2013-02-25 22:56:39 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 306176935376080897,
  "created_at" : "2013-02-25 23:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/7YveU0fNOO",
      "expanded_url" : "http:\/\/at.wh.gov\/i1MOy",
      "display_url" : "at.wh.gov\/i1MOy"
    } ]
  },
  "geo" : { },
  "id_str" : "306082866406772737",
  "text" : "New state-by-state reports on the impact the sequester will have on jobs &amp; middle class families across the country: http:\/\/t.co\/7YveU0fNOO",
  "id" : 306082866406772737,
  "created_at" : "2013-02-25 16:46:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 68, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306080462793752576",
  "text" : "President Obama: \"Every dollar that we invest in high-quality early #education can save more than seven dollars later on\"",
  "id" : 306080462793752576,
  "created_at" : "2013-02-25 16:37:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306079400309444608",
  "text" : "President Obama: \"We\u2019ve got to make the tough, smart choices to cut what we don\u2019t need so that we can invest the things we do need.\"",
  "id" : 306079400309444608,
  "created_at" : "2013-02-25 16:33:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306078646047748097",
  "text" : "President Obama: \"Here\u2019s the thing: these cuts don\u2019t have to happen. Congress can turn them off anytime with just a little compromise.\"",
  "id" : 306078646047748097,
  "created_at" : "2013-02-25 16:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306078349460115456",
  "text" : "President Obama: \"In 4 days, Congress is poised to allow a series of arbitrary, automatic budget cuts to kick in that will slow our economy\"",
  "id" : 306078349460115456,
  "created_at" : "2013-02-25 16:28:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306078179100073984",
  "text" : "President Obama to governors: \"We share a responsibility to do whatever we can to help grow our economy, create good, middle class jobs\"",
  "id" : 306078179100073984,
  "created_at" : "2013-02-25 16:28:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 35, 38 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/btaVgDpKUc",
      "expanded_url" : "http:\/\/at.wh.gov\/i1HAL",
      "display_url" : "at.wh.gov\/i1HAL"
    } ]
  },
  "geo" : { },
  "id_str" : "306075655295098881",
  "text" : "Happening now: President Obama and @VP Biden speak to the National Governors Association: http:\/\/t.co\/btaVgDpKUc",
  "id" : 306075655295098881,
  "created_at" : "2013-02-25 16:18:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 12, 19 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 60, 74 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/bLdqEKvBS3",
      "expanded_url" : "http:\/\/at.wh.gov\/i1tJ1",
      "display_url" : "at.wh.gov\/i1tJ1"
    } ]
  },
  "geo" : { },
  "id_str" : "306057698108112896",
  "text" : "At 10:45ET: @FLOTUS Michelle Obama &amp; Dr. Biden speak on @JoiningForces to the National Governors Association. Watch: http:\/\/t.co\/bLdqEKvBS3",
  "id" : 306057698108112896,
  "created_at" : "2013-02-25 15:06:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 110, 121 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oscars2013",
      "indices" : [ 75, 86 ]
    }, {
      "text" : "BestPicture",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305915165554135041",
  "text" : "RT @FLOTUS: Tonight, First Lady Michelle Obama announced the winner of the #Oscars2013 #BestPicture live from @WhiteHouse: http:\/\/t.co\/o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 98, 109 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oscars2013",
        "indices" : [ 63, 74 ]
      }, {
        "text" : "BestPicture",
        "indices" : [ 75, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/oAzjnd1zqV",
        "expanded_url" : "http:\/\/flic.kr\/p\/dXA6Fi",
        "display_url" : "flic.kr\/p\/dXA6Fi"
      } ]
    },
    "geo" : { },
    "id_str" : "305914684375187456",
    "text" : "Tonight, First Lady Michelle Obama announced the winner of the #Oscars2013 #BestPicture live from @WhiteHouse: http:\/\/t.co\/oAzjnd1zqV",
    "id" : 305914684375187456,
    "created_at" : "2013-02-25 05:38:39 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 305915165554135041,
  "created_at" : "2013-02-25 05:40:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/305859439943094273\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/KNP30PULau",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD6hikVCEAAbtGl.jpg",
      "id_str" : "305859439947288576",
      "id" : 305859439947288576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD6hikVCEAAbtGl.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/KNP30PULau"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305859439943094273",
  "text" : "Automatic spending cuts - know as the sequester - would leave 370k mentally ill children &amp; adults without treatment: http:\/\/t.co\/KNP30PULau",
  "id" : 305859439943094273,
  "created_at" : "2013-02-25 01:59:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/305806836865572864\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/fHtLslN1Dr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD5xsqnCIAI2zv_.jpg",
      "id_str" : "305806836873961474",
      "id" : 305806836873961474,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD5xsqnCIAI2zv_.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/fHtLslN1Dr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/YJLyDcZlPq",
      "expanded_url" : "http:\/\/on.wh.gov\/c94pVG0",
      "display_url" : "on.wh.gov\/c94pVG0"
    } ]
  },
  "geo" : { },
  "id_str" : "305806836865572864",
  "text" : "What you need to know about the sequester: http:\/\/t.co\/YJLyDcZlPq This is about small businesses: http:\/\/t.co\/fHtLslN1Dr",
  "id" : 305806836865572864,
  "created_at" : "2013-02-24 22:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/eeFP80DpsA",
      "expanded_url" : "http:\/\/on.wh.gov\/nYSrdzj",
      "display_url" : "on.wh.gov\/nYSrdzj"
    } ]
  },
  "geo" : { },
  "id_str" : "305749198043742208",
  "text" : "Pres. Obama: \"Our top priority as a country right now should be doing everything we can to grow our economy\" Watch: http:\/\/t.co\/eeFP80DpsA",
  "id" : 305749198043742208,
  "created_at" : "2013-02-24 18:41:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/305698364803129344\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/eKDhZvsmOV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD4PCwsCIAAx2Nq.jpg",
      "id_str" : "305698364811517952",
      "id" : 305698364811517952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD4PCwsCIAAx2Nq.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/eKDhZvsmOV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/Z05w0B7lmp",
      "expanded_url" : "http:\/\/on.wh.gov\/s9IhtyO",
      "display_url" : "on.wh.gov\/s9IhtyO"
    } ]
  },
  "geo" : { },
  "id_str" : "305698364803129344",
  "text" : "What you need to know about the sequester: http:\/\/t.co\/Z05w0B7lmp. This is about people living with mental illness: http:\/\/t.co\/eKDhZvsmOV",
  "id" : 305698364803129344,
  "created_at" : "2013-02-24 15:19:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "indices" : [ 67, 79 ],
      "id_str" : "15485441",
      "id" : 15485441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/MSKJKL2DbZ",
      "expanded_url" : "http:\/\/at.wh.gov\/hZjEl",
      "display_url" : "at.wh.gov\/hZjEl"
    } ]
  },
  "geo" : { },
  "id_str" : "305457409005076480",
  "text" : "RT @FLOTUS: In case you missed it: First Lady Michelle Obama &amp; @JimmyFallon in \"Evolution of Mom Dancing.\" http:\/\/t.co\/MSKJKL2DbZ  # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jimmy fallon",
        "screen_name" : "jimmyfallon",
        "indices" : [ 55, 67 ],
        "id_str" : "15485441",
        "id" : 15485441
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 123, 132 ]
      }, {
        "text" : "Momdancing",
        "indices" : [ 133, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/MSKJKL2DbZ",
        "expanded_url" : "http:\/\/at.wh.gov\/hZjEl",
        "display_url" : "at.wh.gov\/hZjEl"
      } ]
    },
    "geo" : { },
    "id_str" : "305445043890700288",
    "text" : "In case you missed it: First Lady Michelle Obama &amp; @JimmyFallon in \"Evolution of Mom Dancing.\" http:\/\/t.co\/MSKJKL2DbZ  #LetsMove #Momdancing",
    "id" : 305445043890700288,
    "created_at" : "2013-02-23 22:32:28 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 305457409005076480,
  "created_at" : "2013-02-23 23:21:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/305443700333502466\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/MKbB39fSJZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BD0nbVmCYAAMwFq.jpg",
      "id_str" : "305443700337696768",
      "id" : 305443700337696768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BD0nbVmCYAAMwFq.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/MKbB39fSJZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/6vprs6nNmM",
      "expanded_url" : "http:\/\/on.wh.gov\/JEOZR6M",
      "display_url" : "on.wh.gov\/JEOZR6M"
    } ]
  },
  "geo" : { },
  "id_str" : "305443700333502466",
  "text" : "Automatic cuts - known as the sequester - would cut lending to small businesses by $540M: http:\/\/t.co\/6vprs6nNmM http:\/\/t.co\/MKbB39fSJZ",
  "id" : 305443700333502466,
  "created_at" : "2013-02-23 22:27:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/305385254997331969\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/Lf4QeXtGZu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDzyRXxCEAA_HjX.jpg",
      "id_str" : "305385255005720576",
      "id" : 305385255005720576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDzyRXxCEAA_HjX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1013,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 1013,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1013,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/Lf4QeXtGZu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/cAnWjNlUsD",
      "expanded_url" : "http:\/\/youtu.be\/4ZS-vS2lmlw",
      "display_url" : "youtu.be\/4ZS-vS2lmlw"
    } ]
  },
  "geo" : { },
  "id_str" : "305385254997331969",
  "text" : "\"Smart spending cuts, entitlement reform, &amp; tax reform. That\u2019s my plan.\" -Pres. Obama: http:\/\/t.co\/cAnWjNlUsD Plan: http:\/\/t.co\/Lf4QeXtGZu",
  "id" : 305385254997331969,
  "created_at" : "2013-02-23 18:34:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/8v15mdrYpF",
      "expanded_url" : "http:\/\/at.wh.gov\/hYWtN",
      "display_url" : "at.wh.gov\/hYWtN"
    } ]
  },
  "geo" : { },
  "id_str" : "305331002040004610",
  "text" : "In this week's address President Obama urges Congress to act now to stop the sequester from taking effect on March 1: http:\/\/t.co\/8v15mdrYpF",
  "id" : 305331002040004610,
  "created_at" : "2013-02-23 14:59:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/305143391782588417\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/6gsEIJNEFg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDwWTFGCUAAeqQC.jpg",
      "id_str" : "305143391795171328",
      "id" : 305143391795171328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDwWTFGCUAAeqQC.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6gsEIJNEFg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/sO4mqM95lr",
      "expanded_url" : "http:\/\/wh.gov\/vVyd",
      "display_url" : "wh.gov\/vVyd"
    } ]
  },
  "geo" : { },
  "id_str" : "305143391782588417",
  "text" : "Photo of the Day: President Obama talks with Prime Minister Abe of Japan in the West Wing: http:\/\/t.co\/sO4mqM95lr http:\/\/t.co\/6gsEIJNEFg",
  "id" : 305143391782588417,
  "created_at" : "2013-02-23 02:33:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305131107937046528",
  "text" : "RT @pfeiffer44: On p 362 of Woodward's book, he reports Boehner told Dave Camp to offer $600b in revenue to replace the sequester http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pfeiffer44\/status\/305114106711646209\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/AieWyUeBVY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDv7qdsCIAAgKJi.jpg",
        "id_str" : "305114106720034816",
        "id" : 305114106720034816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDv7qdsCIAAgKJi.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/AieWyUeBVY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "305114106711646209",
    "text" : "On p 362 of Woodward's book, he reports Boehner told Dave Camp to offer $600b in revenue to replace the sequester http:\/\/t.co\/AieWyUeBVY",
    "id" : 305114106711646209,
    "created_at" : "2013-02-23 00:37:26 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 305131107937046528,
  "created_at" : "2013-02-23 01:44:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/305115769639940096\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/iZSzJ6fpa1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDv9LQlCMAAZeUL.jpg",
      "id_str" : "305115769648328704",
      "id" : 305115769648328704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDv9LQlCMAAZeUL.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/iZSzJ6fpa1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/DRFsn5VCG0",
      "expanded_url" : "http:\/\/wh.gov\/sequester",
      "display_url" : "wh.gov\/sequester"
    } ]
  },
  "geo" : { },
  "id_str" : "305115769639940096",
  "text" : "What you need to know about the sequester: http:\/\/t.co\/DRFsn5VCG0 This is about our students and teachers: http:\/\/t.co\/iZSzJ6fpa1",
  "id" : 305115769639940096,
  "created_at" : "2013-02-23 00:44:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 95, 107 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "openaccess",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "305037492632051713",
  "text" : "RT @macon44: \"Americans should have easy access to the results of research they help support.\" @wethepeople #openaccess response: https: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 82, 94 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "openaccess",
        "indices" : [ 95, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/kQc66oZyYa",
        "expanded_url" : "https:\/\/petitions.whitehouse.gov\/response\/increasing-public-access-results-scientific-research",
        "display_url" : "petitions.whitehouse.gov\/response\/incre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "305025046215266304",
    "text" : "\"Americans should have easy access to the results of research they help support.\" @wethepeople #openaccess response: https:\/\/t.co\/kQc66oZyYa",
    "id" : 305025046215266304,
    "created_at" : "2013-02-22 18:43:32 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 305037492632051713,
  "created_at" : "2013-02-22 19:33:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "solar",
      "indices" : [ 23, 29 ]
    }, {
      "text" : "askEnergy",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/fxpKPCTfSZ",
      "expanded_url" : "http:\/\/energy.gov\/live",
      "display_url" : "energy.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "305023718613188608",
  "text" : "RT @ENERGY: Send Qs on #solar for today's G+ Hangout w\/ Sec Chu &amp; industry experts using #askEnergy. Watch on http:\/\/t.co\/fxpKPCTfSZ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "solar",
        "indices" : [ 11, 17 ]
      }, {
        "text" : "askEnergy",
        "indices" : [ 81, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/fxpKPCTfSZ",
        "expanded_url" : "http:\/\/energy.gov\/live",
        "display_url" : "energy.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "304972833476448256",
    "text" : "Send Qs on #solar for today's G+ Hangout w\/ Sec Chu &amp; industry experts using #askEnergy. Watch on http:\/\/t.co\/fxpKPCTfSZ @ 2pm ET",
    "id" : 304972833476448256,
    "created_at" : "2013-02-22 15:16:04 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 305023718613188608,
  "created_at" : "2013-02-22 18:38:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/XY7E6gZJg3",
      "expanded_url" : "http:\/\/at.wh.gov\/hXFup",
      "display_url" : "at.wh.gov\/hXFup"
    } ]
  },
  "geo" : { },
  "id_str" : "305007852374851584",
  "text" : "Watch: A behind-the-scenes peek at this week at the White House: http:\/\/t.co\/XY7E6gZJg3",
  "id" : 305007852374851584,
  "created_at" : "2013-02-22 17:35:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "NASA Astronauts",
      "screen_name" : "NASA_Astronauts",
      "indices" : [ 55, 71 ],
      "id_str" : "43166813",
      "id" : 43166813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askAstro",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304965519574986752",
  "text" : "RT @whitehouseostp: First-ever Hangout from space! Ask @NASA_Astronauts questions using #askAstro and watch live at 10:30 ET http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA Astronauts",
        "screen_name" : "NASA_Astronauts",
        "indices" : [ 35, 51 ],
        "id_str" : "43166813",
        "id" : 43166813
      }, {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 128, 133 ],
        "id_str" : "11348282",
        "id" : 11348282
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askAstro",
        "indices" : [ 68, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/ZfGPrsDREl",
        "expanded_url" : "http:\/\/plus.google.com\/+NASA",
        "display_url" : "plus.google.com\/+NASA"
      } ]
    },
    "geo" : { },
    "id_str" : "304964918740922369",
    "text" : "First-ever Hangout from space! Ask @NASA_Astronauts questions using #askAstro and watch live at 10:30 ET http:\/\/t.co\/ZfGPrsDREl @NASA",
    "id" : 304964918740922369,
    "created_at" : "2013-02-22 14:44:37 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 304965519574986752,
  "created_at" : "2013-02-22 14:47:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/304768749154750464\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/dM4OjzDdUT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDrBkAhCUAA8AN_.jpg",
      "id_str" : "304768749158944768",
      "id" : 304768749158944768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDrBkAhCUAA8AN_.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dM4OjzDdUT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304768749154750464",
  "text" : "Photo of the Day: President Obama meets with senior advisors in the Oval Office: http:\/\/t.co\/dM4OjzDdUT",
  "id" : 304768749154750464,
  "created_at" : "2013-02-22 01:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/304713878628098048\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/NqBlMJqOkB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDqPqH4CYAEgdlK.jpg",
      "id_str" : "304713878632292353",
      "id" : 304713878632292353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDqPqH4CYAEgdlK.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/NqBlMJqOkB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304713878628098048",
  "text" : "Automatic &amp; arbitrary spending cuts will affect millions of Americans if Congress doesn't act by March 1: http:\/\/t.co\/NqBlMJqOkB",
  "id" : 304713878628098048,
  "created_at" : "2013-02-21 22:07:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/d51QM1h9oP",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/02\/21\/balanced-plan-avert-sequester-and-reduce-deficit-balanced-way",
      "display_url" : "whitehouse.gov\/blog\/2013\/02\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304675100421128195",
  "text" : "RT @PressSec: Jen Palmieri's refresher on the President's balanced plan to end the sequester and reduce the deficit: http:\/\/t.co\/d51QM1h9oP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/d51QM1h9oP",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/02\/21\/balanced-plan-avert-sequester-and-reduce-deficit-balanced-way",
        "display_url" : "whitehouse.gov\/blog\/2013\/02\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304658042954317825",
    "text" : "Jen Palmieri's refresher on the President's balanced plan to end the sequester and reduce the deficit: http:\/\/t.co\/d51QM1h9oP",
    "id" : 304658042954317825,
    "created_at" : "2013-02-21 18:25:12 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 304675100421128195,
  "created_at" : "2013-02-21 19:32:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "indices" : [ 28, 44 ],
      "id_str" : "627799297",
      "id" : 627799297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/L7drUfKkLX",
      "expanded_url" : "http:\/\/youtu.be\/f1OHJUc2QTU",
      "display_url" : "youtu.be\/f1OHJUc2QTU"
    } ]
  },
  "geo" : { },
  "id_str" : "304657569228673024",
  "text" : "Kids dancing, eggs rolling. @iamkidpresident and President Obama announce the White House #EasterEggRoll: http:\/\/t.co\/L7drUfKkLX",
  "id" : 304657569228673024,
  "created_at" : "2013-02-21 18:23:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/R4gj9lPica",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "304643094203207680",
  "text" : "RT @VP: Hear the VP speak today in Danbury, CT about reducing gun violence in the US. Tune in at 12:45 PM: http:\/\/t.co\/R4gj9lPica  #NowI ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/R4gj9lPica",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "304642610906140672",
    "text" : "Hear the VP speak today in Danbury, CT about reducing gun violence in the US. Tune in at 12:45 PM: http:\/\/t.co\/R4gj9lPica  #NowIsTheTime",
    "id" : 304642610906140672,
    "created_at" : "2013-02-21 17:23:53 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 304643094203207680,
  "created_at" : "2013-02-21 17:25:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Sesame Street",
      "screen_name" : "sesamestreet",
      "indices" : [ 13, 26 ],
      "id_str" : "86330674",
      "id" : 86330674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/OdOyfFVCc6",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=uVn6p9s1gUk",
      "display_url" : "youtube.com\/watch?v=uVn6p9\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "304614807015923713",
  "text" : "RT @FLOTUS: .@SesameStreet comes to 1600 Pennsylvania Ave. to encourage kids to eat healthy: http:\/\/t.co\/OdOyfFVCc6 &amp; get active: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sesame Street",
        "screen_name" : "sesamestreet",
        "indices" : [ 1, 14 ],
        "id_str" : "86330674",
        "id" : 86330674
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/OdOyfFVCc6",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=uVn6p9s1gUk",
        "display_url" : "youtube.com\/watch?v=uVn6p9\u2026"
      }, {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/YjwIzYxUtt",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=vXOswkMRLkc",
        "display_url" : "youtube.com\/watch?v=vXOswk\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "304612185802428416",
    "text" : ".@SesameStreet comes to 1600 Pennsylvania Ave. to encourage kids to eat healthy: http:\/\/t.co\/OdOyfFVCc6 &amp; get active: http:\/\/t.co\/YjwIzYxUtt",
    "id" : 304612185802428416,
    "created_at" : "2013-02-21 15:22:59 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 304614807015923713,
  "created_at" : "2013-02-21 15:33:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/304404645021884416\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/uxwip7bENx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDl2aW8CIAEIOoU.jpg",
      "id_str" : "304404645030273025",
      "id" : 304404645030273025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDl2aW8CIAEIOoU.jpg",
      "sizes" : [ {
        "h" : 409,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/uxwip7bENx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/t3BAnZGr64",
      "expanded_url" : "http:\/\/wh.gov\/nzpF",
      "display_url" : "wh.gov\/nzpF"
    } ]
  },
  "geo" : { },
  "id_str" : "304404645021884416",
  "text" : "Today, President Obama met with Frederick Winter, 2012 SAVE award winner, in the Oval Office: http:\/\/t.co\/t3BAnZGr64 http:\/\/t.co\/uxwip7bENx",
  "id" : 304404645021884416,
  "created_at" : "2013-02-21 01:38:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 18, 21 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/304386952164163585\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/gC3AyuBMv0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDlmUf6CQAAfZJB.jpg",
      "id_str" : "304386952172552192",
      "id" : 304386952172552192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDlmUf6CQAAfZJB.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gC3AyuBMv0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304386952164163585",
  "text" : "Photo of the Day: @VP Biden receives a bracelet from Paige Baitinger, who accepted the Medal of Valor for her husband http:\/\/t.co\/gC3AyuBMv0",
  "id" : 304386952164163585,
  "created_at" : "2013-02-21 00:27:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeDemandAVote",
      "indices" : [ 37, 51 ]
    }, {
      "text" : "NowIsTheTime",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304321430022152194",
  "text" : "RT @VP: Americans are speaking out - #WeDemandAVote to reduce gun violence &amp; save lives. It's going to take us all. #NowIsTheTime fo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeDemandAVote",
        "indices" : [ 29, 43 ]
      }, {
        "text" : "NowIsTheTime",
        "indices" : [ 112, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "304320260801191938",
    "text" : "Americans are speaking out - #WeDemandAVote to reduce gun violence &amp; save lives. It's going to take us all. #NowIsTheTime for action. -VP",
    "id" : 304320260801191938,
    "created_at" : "2013-02-20 20:02:58 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 304321430022152194,
  "created_at" : "2013-02-20 20:07:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/9HJaMY1X",
      "expanded_url" : "http:\/\/flic.kr\/p\/dWmSV8",
      "display_url" : "flic.kr\/p\/dWmSV8"
    } ]
  },
  "geo" : { },
  "id_str" : "304311225200812032",
  "text" : "RT @FLOTUS: A new term, a new official portrait of the First Lady: http:\/\/t.co\/9HJaMY1X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/9HJaMY1X",
        "expanded_url" : "http:\/\/flic.kr\/p\/dWmSV8",
        "display_url" : "flic.kr\/p\/dWmSV8"
      } ]
    },
    "geo" : { },
    "id_str" : "304310420905275394",
    "text" : "A new term, a new official portrait of the First Lady: http:\/\/t.co\/9HJaMY1X",
    "id" : 304310420905275394,
    "created_at" : "2013-02-20 19:23:52 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 304311225200812032,
  "created_at" : "2013-02-20 19:27:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304295666891489280",
  "text" : "RT @VP: Happening now: Vice President Biden delivers remarks at a Medal of Valor ceremony from the White House. Watch live: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/VjqJPEsO",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "304295547647442944",
    "text" : "Happening now: Vice President Biden delivers remarks at a Medal of Valor ceremony from the White House. Watch live: http:\/\/t.co\/VjqJPEsO",
    "id" : 304295547647442944,
    "created_at" : "2013-02-20 18:24:46 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 304295666891489280,
  "created_at" : "2013-02-20 18:25:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infrastructure",
      "indices" : [ 85, 100 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/gSfVjBPv",
      "expanded_url" : "http:\/\/at.wh.gov\/hThGo",
      "display_url" : "at.wh.gov\/hThGo"
    } ]
  },
  "geo" : { },
  "id_str" : "304286223118266369",
  "text" : "Fact Sheet: President Obama\u2019s plan to make America a magnet for jobs by investing in #infrastructure: http:\/\/t.co\/gSfVjBPv #JobsNow",
  "id" : 304286223118266369,
  "created_at" : "2013-02-20 17:47:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 15, 22 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 103, 112 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/MHxtscxf",
      "expanded_url" : "http:\/\/at.wh.gov\/hT3nM",
      "display_url" : "at.wh.gov\/hT3nM"
    } ]
  },
  "geo" : { },
  "id_str" : "304264996135772160",
  "text" : "RT @letsmove: .@FLOTUS Michelle Obama kicks off a nation-wide tour to celebrate the 3rd anniversary of @LetsMove! http:\/\/t.co\/MHxtscxf # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 1, 8 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 89, 98 ],
        "id_str" : "36719281",
        "id" : 36719281
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMoveTour",
        "indices" : [ 121, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/MHxtscxf",
        "expanded_url" : "http:\/\/at.wh.gov\/hT3nM",
        "display_url" : "at.wh.gov\/hT3nM"
      } ]
    },
    "geo" : { },
    "id_str" : "304264638298738689",
    "text" : ".@FLOTUS Michelle Obama kicks off a nation-wide tour to celebrate the 3rd anniversary of @LetsMove! http:\/\/t.co\/MHxtscxf #LetsMoveTour",
    "id" : 304264638298738689,
    "created_at" : "2013-02-20 16:21:57 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 304264996135772160,
  "created_at" : "2013-02-20 16:23:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/Y5ZPWkkn",
      "expanded_url" : "http:\/\/wh.gov\/vjO5",
      "display_url" : "wh.gov\/vjO5"
    } ]
  },
  "geo" : { },
  "id_str" : "304255287626461186",
  "text" : "RT @PressSec: Senior Advisor Dan Pfeiffer sets the record straight about the sequester: http:\/\/t.co\/Y5ZPWkkn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/Y5ZPWkkn",
        "expanded_url" : "http:\/\/wh.gov\/vjO5",
        "display_url" : "wh.gov\/vjO5"
      } ]
    },
    "geo" : { },
    "id_str" : "304187474316513281",
    "text" : "Senior Advisor Dan Pfeiffer sets the record straight about the sequester: http:\/\/t.co\/Y5ZPWkkn",
    "id" : 304187474316513281,
    "created_at" : "2013-02-20 11:15:20 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 304255287626461186,
  "created_at" : "2013-02-20 15:44:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/304107324975480833\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/ile4iZJC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDhoADeCAAA9D0H.jpg",
      "id_str" : "304107324988063744",
      "id" : 304107324988063744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDhoADeCAAA9D0H.jpg",
      "sizes" : [ {
        "h" : 492,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 492,
        "resize" : "fit",
        "w" : 492
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 492,
        "resize" : "fit",
        "w" : 492
      } ],
      "display_url" : "pic.twitter.com\/ile4iZJC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/dN3cZ3jU",
      "expanded_url" : "http:\/\/wh.gov\/vCnb",
      "display_url" : "wh.gov\/vCnb"
    } ]
  },
  "geo" : { },
  "id_str" : "304107324975480833",
  "text" : "If Congress doesn't act, automatic budget cuts will hurt our economy &amp; middle class families: http:\/\/t.co\/dN3cZ3jU http:\/\/t.co\/ile4iZJC",
  "id" : 304107324975480833,
  "created_at" : "2013-02-20 05:56:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/304081044884316160\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/4MGIZ7bk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDhQGWfCYAAR-Wy.jpg",
      "id_str" : "304081044892704768",
      "id" : 304081044892704768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDhQGWfCYAAR-Wy.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4MGIZ7bk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304081044884316160",
  "text" : "Photo of the Day: President Obama w\/ emergency responders before remarks urging action to stop automatic budget cuts: http:\/\/t.co\/4MGIZ7bk",
  "id" : 304081044884316160,
  "created_at" : "2013-02-20 04:12:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Inaug2013",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/2Jls0lq6",
      "expanded_url" : "http:\/\/wh.gov\/vgcR",
      "display_url" : "wh.gov\/vgcR"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/8MxKg88a",
      "expanded_url" : "http:\/\/flic.kr\/p\/dUYyWz",
      "display_url" : "flic.kr\/p\/dUYyWz"
    } ]
  },
  "geo" : { },
  "id_str" : "304046419545833473",
  "text" : "New Photo Gallery: Behind the scenes in January: http:\/\/t.co\/2Jls0lq6 &amp; inside the Presidential limo on #Inaug2013: http:\/\/t.co\/8MxKg88a",
  "id" : 304046419545833473,
  "created_at" : "2013-02-20 01:54:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/w5Zu2TwB",
      "expanded_url" : "http:\/\/on.wh.gov\/TTKjnds",
      "display_url" : "on.wh.gov\/TTKjnds"
    } ]
  },
  "geo" : { },
  "id_str" : "304013283336282112",
  "text" : "\"These cuts are not smart. They are not fair. They will hurt our economy.\" -President Obama on automatic budget cuts: http:\/\/t.co\/w5Zu2TwB",
  "id" : 304013283336282112,
  "created_at" : "2013-02-19 23:43:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 15, 18 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Parents Magazine",
      "screen_name" : "parentsmagazine",
      "indices" : [ 57, 73 ],
      "id_str" : "29730065",
      "id" : 29730065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "303964648141635584",
  "text" : "Starting soon: @VP Biden joins a Facebook Town Hall with @parentsmagazine about reducing gun violence: http:\/\/t.co\/u95tzH8r",
  "id" : 303964648141635584,
  "created_at" : "2013-02-19 20:29:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/MxHzEtGx",
      "expanded_url" : "http:\/\/on.wh.gov\/ypqnkRv",
      "display_url" : "on.wh.gov\/ypqnkRv"
    } ]
  },
  "geo" : { },
  "id_str" : "303940426954579968",
  "text" : "Full video: President Obama urges action to avoid the automatic budget cuts scheduled to hit next Friday: http:\/\/t.co\/MxHzEtGx",
  "id" : 303940426954579968,
  "created_at" : "2013-02-19 18:53:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parents Magazine",
      "screen_name" : "parentsmagazine",
      "indices" : [ 3, 19 ],
      "id_str" : "29730065",
      "id" : 29730065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303919848080154624",
  "text" : "RT @parentsmagazine: Today is the day! We're asking Vice President Joe Biden your questions about gun violence at 3:30 P.M. Eastern: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/DuqM0fZB",
        "expanded_url" : "http:\/\/www.facebook.com\/parentsmagazine",
        "display_url" : "facebook.com\/parentsmagazine"
      } ]
    },
    "geo" : { },
    "id_str" : "303911871222779905",
    "text" : "Today is the day! We're asking Vice President Joe Biden your questions about gun violence at 3:30 P.M. Eastern: http:\/\/t.co\/DuqM0fZB #AskVP",
    "id" : 303911871222779905,
    "created_at" : "2013-02-19 17:00:11 +0000",
    "user" : {
      "name" : "Parents Magazine",
      "screen_name" : "parentsmagazine",
      "protected" : false,
      "id_str" : "29730065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795790508715024386\/TcChxlY8_normal.jpg",
      "id" : 29730065,
      "verified" : true
    }
  },
  "id" : 303919848080154624,
  "created_at" : "2013-02-19 17:31:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303897269399326721",
  "text" : "RT @WHLive: Obama: \"The American people have worked too hard, for too long, rebuilding from one crisis to see their elected officials ca ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303896979283517440",
    "text" : "Obama: \"The American people have worked too hard, for too long, rebuilding from one crisis to see their elected officials cause another.\"",
    "id" : 303896979283517440,
    "created_at" : "2013-02-19 16:01:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 303897269399326721,
  "created_at" : "2013-02-19 16:02:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303896921938984960",
  "text" : "\"My door is open. I\u2019ve put tough cuts and reforms on the table. I\u2019m willing to work with anybody to get the job done.\" \u2014President Obama",
  "id" : 303896921938984960,
  "created_at" : "2013-02-19 16:00:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303896556761915392",
  "text" : "RT @WHLive: President Obama: \"I will not sign a plan that harms the middle class.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303896455293308928",
    "text" : "President Obama: \"I will not sign a plan that harms the middle class.\"",
    "id" : 303896455293308928,
    "created_at" : "2013-02-19 15:58:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 303896556761915392,
  "created_at" : "2013-02-19 15:59:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303895934440452096",
  "text" : "RT @WHLive: President Obama: \"I\u2019m willing to save hundreds of billions of dollars by enacting comprehensive tax reform that gets rid of  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303895793939648513",
    "text" : "President Obama: \"I\u2019m willing to save hundreds of billions of dollars by enacting comprehensive tax reform that gets rid of tax loopholes\"",
    "id" : 303895793939648513,
    "created_at" : "2013-02-19 15:56:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 303895934440452096,
  "created_at" : "2013-02-19 15:56:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303895590788530177",
  "text" : "President Obama: \"These cuts are not smart...They will hurt our economy &amp; add hundreds of thousands of Americans to the unemployment rolls\"",
  "id" : 303895590788530177,
  "created_at" : "2013-02-19 15:55:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303894510902071296",
  "text" : "President Obama: \"Our top priority must be doing everything we can to grow the economy &amp; create good, middle-class jobs.\" #JobsNow",
  "id" : 303894510902071296,
  "created_at" : "2013-02-19 15:51:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "303894184643919872",
  "text" : "Happening now: President Obama urges action to avoid the automatic budget cuts scheduled to hit next Friday: http:\/\/t.co\/u95tzH8r",
  "id" : 303894184643919872,
  "created_at" : "2013-02-19 15:49:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "303878203502641152",
  "text" : "Happening at 10:45 ET: President Obama urges action to avoid the automatic budget cuts scheduled to hit next Friday: http:\/\/t.co\/u95tzH8r",
  "id" : 303878203502641152,
  "created_at" : "2013-02-19 14:46:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Arts",
      "screen_name" : "googleart",
      "indices" : [ 75, 85 ],
      "id_str" : "4433429660",
      "id" : 4433429660
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/303647765924306946\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/CETCRqPj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDbGCMmCYAI9a0g.jpg",
      "id_str" : "303647765936889858",
      "id" : 303647765936889858,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDbGCMmCYAI9a0g.jpg",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/CETCRqPj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/B5khxny8",
      "expanded_url" : "http:\/\/at.wh.gov\/hPtFA",
      "display_url" : "at.wh.gov\/hPtFA"
    } ]
  },
  "geo" : { },
  "id_str" : "303647765924306946",
  "text" : "In honor of his birthday, see George Washington like never before with the @GoogleArt project: http:\/\/t.co\/B5khxny8 http:\/\/t.co\/CETCRqPj",
  "id" : 303647765924306946,
  "created_at" : "2013-02-18 23:30:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/jOuNWGSd",
      "expanded_url" : "http:\/\/at.wh.gov\/hP739",
      "display_url" : "at.wh.gov\/hP739"
    } ]
  },
  "geo" : { },
  "id_str" : "303602526303961088",
  "text" : "Get the inside story on Theodore Roosevelt's official portrait: http:\/\/t.co\/jOuNWGSd",
  "id" : 303602526303961088,
  "created_at" : "2013-02-18 20:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US National Archives",
      "screen_name" : "USNatArchives",
      "indices" : [ 43, 57 ],
      "id_str" : "101802390",
      "id" : 101802390
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/303582402465382400\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/UNfBW7Lp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDaKliuCQAA7JGH.jpg",
      "id_str" : "303582402473771008",
      "id" : 303582402473771008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDaKliuCQAA7JGH.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 645
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 645
      }, {
        "h" : 953,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UNfBW7Lp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/Yu9DQx8u",
      "expanded_url" : "http:\/\/wh.gov\/vqnb",
      "display_url" : "wh.gov\/vqnb"
    } ]
  },
  "geo" : { },
  "id_str" : "303582402465382400",
  "text" : "Happy Presidents\u2019 Day! See photos from the @USNatArchives http:\/\/t.co\/Yu9DQx8u Incl Washington\u2019s Inaugural Address: http:\/\/t.co\/UNfBW7Lp",
  "id" : 303582402465382400,
  "created_at" : "2013-02-18 19:10:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/303541599915352064\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/gCzI2Sqf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDZlehYCIAEPTPj.jpg",
      "id_str" : "303541599923740673",
      "id" : 303541599923740673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDZlehYCIAEPTPj.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gCzI2Sqf"
    } ],
    "hashtags" : [ {
      "text" : "WashingtonMonument",
      "indices" : [ 58, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303570550201135104",
  "text" : "RT @Interior: Happy Presidents' Day! Here's a shot of the #WashingtonMonument from an angle you don't see every day. http:\/\/t.co\/gCzI2Sqf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/303541599915352064\/photo\/1",
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/gCzI2Sqf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BDZlehYCIAEPTPj.jpg",
        "id_str" : "303541599923740673",
        "id" : 303541599923740673,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDZlehYCIAEPTPj.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/gCzI2Sqf"
      } ],
      "hashtags" : [ {
        "text" : "WashingtonMonument",
        "indices" : [ 44, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "303541599915352064",
    "text" : "Happy Presidents' Day! Here's a shot of the #WashingtonMonument from an angle you don't see every day. http:\/\/t.co\/gCzI2Sqf",
    "id" : 303541599915352064,
    "created_at" : "2013-02-18 16:28:51 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 303570550201135104,
  "created_at" : "2013-02-18 18:23:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 95, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/rDwjslHu",
      "expanded_url" : "http:\/\/at.wh.gov\/hNF0Q",
      "display_url" : "at.wh.gov\/hNF0Q"
    } ]
  },
  "geo" : { },
  "id_str" : "303360299724050433",
  "text" : "Weekly Address: Following the President\u2019s Plan for a Strong Middle Class: http:\/\/t.co\/rDwjslHu #JobsNow",
  "id" : 303360299724050433,
  "created_at" : "2013-02-18 04:28:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/O9kVmtcr",
      "expanded_url" : "http:\/\/at.wh.gov\/hM4Ze",
      "display_url" : "at.wh.gov\/hM4Ze"
    } ]
  },
  "geo" : { },
  "id_str" : "302807226014384129",
  "text" : "\"America only moves forward when we do so together\" \u2014President Obama in his Weekly Address. Watch: http:\/\/t.co\/O9kVmtcr #JobsNow",
  "id" : 302807226014384129,
  "created_at" : "2013-02-16 15:50:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/49KATKrQ",
      "expanded_url" : "http:\/\/at.wh.gov\/hLApe",
      "display_url" : "at.wh.gov\/hLApe"
    } ]
  },
  "geo" : { },
  "id_str" : "302589682120794113",
  "text" : "Everything you need to know about President Obama's plan to ensure hard work leads to a decent living: http:\/\/t.co\/49KATKrQ #JobsNow",
  "id" : 302589682120794113,
  "created_at" : "2013-02-16 01:26:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elianne Ramos",
      "screen_name" : "ergeekgoddess",
      "indices" : [ 3, 17 ],
      "id_str" : "16462209",
      "id" : 16462209
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 96, 107 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/qqGxRTyJ",
      "expanded_url" : "http:\/\/bit.ly\/GSrDlQ",
      "display_url" : "bit.ly\/GSrDlQ"
    } ]
  },
  "geo" : { },
  "id_str" : "302520622980931584",
  "text" : "RT @ergeekgoddess: Tomorrow at 4pm ET, I'll discuss YOUR Qs on Immigration w\/Cecilia Mu\u00F1oz from @WhiteHouse. Watch http:\/\/t.co\/qqGxRTyJ  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 77, 88 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 126, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/qqGxRTyJ",
        "expanded_url" : "http:\/\/bit.ly\/GSrDlQ",
        "display_url" : "bit.ly\/GSrDlQ"
      } ]
    },
    "geo" : { },
    "id_str" : "302199410845184000",
    "text" : "Tomorrow at 4pm ET, I'll discuss YOUR Qs on Immigration w\/Cecilia Mu\u00F1oz from @WhiteHouse. Watch http:\/\/t.co\/qqGxRTyJ - Ask Qs #WHChat",
    "id" : 302199410845184000,
    "created_at" : "2013-02-14 23:35:28 +0000",
    "user" : {
      "name" : "Elianne Ramos",
      "screen_name" : "ergeekgoddess",
      "protected" : false,
      "id_str" : "16462209",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764134581775822848\/P1sQjtrW_normal.jpg",
      "id" : 16462209,
      "verified" : false
    }
  },
  "id" : 302520622980931584,
  "created_at" : "2013-02-15 20:51:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/dfEWfXpi",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "302517334285885441",
  "text" : "3:45ET: President Obama speaks from Chicago on strengthening the economy for the middle class. Tune in: http:\/\/t.co\/dfEWfXpi",
  "id" : 302517334285885441,
  "created_at" : "2013-02-15 20:38:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 8, 11 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 75, 84 ],
      "id_str" : "39293968",
      "id" : 39293968
    }, {
      "name" : "Kelly Wallace",
      "screen_name" : "kellywallacetv",
      "indices" : [ 85, 100 ],
      "id_str" : "21411381",
      "id" : 21411381
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 135, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "302503550632747008",
  "text" : "At 3ET: @VP's COS Bruce Reed joins a Q&amp;A on preventing gun violence w\/ @iVillage @kellywallacetv. Watch: http:\/\/t.co\/u95tzH8r Ask: #WHChat",
  "id" : 302503550632747008,
  "created_at" : "2013-02-15 19:44:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 3, 12 ],
      "id_str" : "39293968",
      "id" : 39293968
    }, {
      "name" : "Kelly Wallace",
      "screen_name" : "kellywallacetv",
      "indices" : [ 14, 29 ],
      "id_str" : "21411381",
      "id" : 21411381
    }, {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 100, 109 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gunviolence",
      "indices" : [ 41, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302468045119557632",
  "text" : "RT @iVillage: @kellywallacetv is talking #gunviolence at the White House tomorrow at 3 pm EST. Send @iVillage your questions! http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kelly Wallace",
        "screen_name" : "kellywallacetv",
        "indices" : [ 0, 15 ],
        "id_str" : "21411381",
        "id" : 21411381
      }, {
        "name" : "iVillage",
        "screen_name" : "iVillage",
        "indices" : [ 86, 95 ],
        "id_str" : "39293968",
        "id" : 39293968
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gunviolence",
        "indices" : [ 27, 39 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/z3o0VSma",
        "expanded_url" : "http:\/\/bit.ly\/XFyYx1",
        "display_url" : "bit.ly\/XFyYx1"
      } ]
    },
    "geo" : { },
    "id_str" : "302252901672312834",
    "in_reply_to_user_id" : 21411381,
    "text" : "@kellywallacetv is talking #gunviolence at the White House tomorrow at 3 pm EST. Send @iVillage your questions! http:\/\/t.co\/z3o0VSma #WHChat",
    "id" : 302252901672312834,
    "created_at" : "2013-02-15 03:08:02 +0000",
    "in_reply_to_screen_name" : "kellywallacetv",
    "in_reply_to_user_id_str" : "21411381",
    "user" : {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "protected" : false,
      "id_str" : "39293968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3055453806\/63bb40e83d33d15f721064533681a4c4_normal.png",
      "id" : 39293968,
      "verified" : true
    }
  },
  "id" : 302468045119557632,
  "created_at" : "2013-02-15 17:22:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 3, 16 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    }, {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 95, 108 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IGASOTU",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302460224894291968",
  "text" : "RT @DavidAgnew44: Elected offiicials have Qs about President\u2019s State of the Union address? Ask @DavidAgnew44 using #IGASOTU - I\u2019ll answe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "sarlynnmarmi19",
        "screen_name" : "DavidAgnew44",
        "indices" : [ 77, 90 ],
        "id_str" : "2982158781",
        "id" : 2982158781
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IGASOTU",
        "indices" : [ 97, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "302451312400936962",
    "text" : "Elected offiicials have Qs about President\u2019s State of the Union address? Ask @DavidAgnew44 using #IGASOTU - I\u2019ll answer TODAY @ 2:30PM EST",
    "id" : 302451312400936962,
    "created_at" : "2013-02-15 16:16:26 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 302460224894291968,
  "created_at" : "2013-02-15 16:51:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "302446816987860992",
  "text" : "Starting at 11:10ET: President Obama welcomes the recipients of the 2012 Presidential Citizens Medal. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 302446816987860992,
  "created_at" : "2013-02-15 15:58:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 114, 122 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302441004726894592",
  "text" : "RT @Brundage44: More details about POTUS Ladders of Opportunity initiatives he will speak on in Chicago today via @nytimes here http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 98, 106 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/vB34BOiD",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/02\/16\/us\/politics\/obama-promise-zone-program-distressed-areas.html",
        "display_url" : "nytimes.com\/2013\/02\/16\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "302397673938497537",
    "text" : "More details about POTUS Ladders of Opportunity initiatives he will speak on in Chicago today via @nytimes here http:\/\/t.co\/vB34BOiD",
    "id" : 302397673938497537,
    "created_at" : "2013-02-15 12:43:18 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 302441004726894592,
  "created_at" : "2013-02-15 15:35:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/302265745176416256\/photo\/1",
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/onfEjpQI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDHdGAGCUAEGBA1.jpg",
      "id_str" : "302265745184804865",
      "id" : 302265745184804865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDHdGAGCUAEGBA1.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/onfEjpQI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/W20vfymR",
      "expanded_url" : "http:\/\/on.wh.gov\/eSc2iRq",
      "display_url" : "on.wh.gov\/eSc2iRq"
    } ]
  },
  "geo" : { },
  "id_str" : "302265745176416256",
  "text" : "Photo of the Day: President Obama visits a pre-kindergarten classroom in Decatur, GA: http:\/\/t.co\/W20vfymR http:\/\/t.co\/onfEjpQI",
  "id" : 302265745176416256,
  "created_at" : "2013-02-15 03:59:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiresideHangout",
      "indices" : [ 46, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/DYxWCANX",
      "expanded_url" : "http:\/\/at.wh.gov\/hJvyo",
      "display_url" : "at.wh.gov\/hJvyo"
    } ]
  },
  "geo" : { },
  "id_str" : "302239199925526528",
  "text" : "Check out the full video of President Obama's #FiresideHangout from the White House: http:\/\/t.co\/DYxWCANX",
  "id" : 302239199925526528,
  "created_at" : "2013-02-15 02:13:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/302212153354616833\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/QxMVmoya",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDGsWjACAAELrRK.jpg",
      "id_str" : "302212153363005441",
      "id" : 302212153363005441,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDGsWjACAAELrRK.jpg",
      "sizes" : [ {
        "h" : 415,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/QxMVmoya"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "302212153354616833",
  "text" : "Photo of the Day: President Obama tours the Linamar Corporation auto-parts plant in Arden, NC, Feb. 13, 2013: http:\/\/t.co\/QxMVmoya",
  "id" : 302212153354616833,
  "created_at" : "2013-02-15 00:26:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiresideHangout",
      "indices" : [ 18, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/bPhFZAmE",
      "expanded_url" : "http:\/\/wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "302188515045818369",
  "text" : "President Obama's #FiresideHangout has concluded. Full video will be available later today on http:\/\/t.co\/bPhFZAmE",
  "id" : 302188515045818369,
  "created_at" : "2013-02-14 22:52:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiresideHangout",
      "indices" : [ 39, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/bPhFZAmE",
      "expanded_url" : "http:\/\/wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "302173398518358016",
  "text" : "Happening now: President Obama joins a #FiresideHangout live from the White House. Watch: http:\/\/t.co\/bPhFZAmE",
  "id" : 302173398518358016,
  "created_at" : "2013-02-14 21:52:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiresideHangout",
      "indices" : [ 33, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/LEI6ldrp",
      "expanded_url" : "http:\/\/wh.gov\/d5zH",
      "display_url" : "wh.gov\/d5zH"
    } ]
  },
  "geo" : { },
  "id_str" : "302164195993059328",
  "text" : "Today, the President will join a #FiresideHangout live from the West Wing. Tune in at 4:50ET: http:\/\/t.co\/LEI6ldrp",
  "id" : 302164195993059328,
  "created_at" : "2013-02-14 21:15:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 84, 89 ]
    }, {
      "text" : "FiresideHangout",
      "indices" : [ 95, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/rc4409sn",
      "expanded_url" : "http:\/\/on.wh.gov\/SaRmCs4",
      "display_url" : "on.wh.gov\/SaRmCs4"
    } ]
  },
  "geo" : { },
  "id_str" : "302130191130587136",
  "text" : "Today at 4:50ET, President Obama joins Americans from across the country to discuss #SOTU in a #FiresideHangout: http:\/\/t.co\/rc4409sn",
  "id" : 302130191130587136,
  "created_at" : "2013-02-14 19:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/8TMmc6Bt",
      "expanded_url" : "http:\/\/wh.gov\/dv2y",
      "display_url" : "wh.gov\/dv2y"
    } ]
  },
  "geo" : { },
  "id_str" : "302122385744723968",
  "text" : "RT @jesseclee44: \"Valentine's Day: Our Beautiful, Romantic National Parks\" How to win \"best engagement\" contests: http:\/\/t.co\/8TMmc6Bt c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nita Chaudhary",
        "screen_name" : "nitalovesmiles",
        "indices" : [ 121, 136 ],
        "id_str" : "16195411",
        "id" : 16195411
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/8TMmc6Bt",
        "expanded_url" : "http:\/\/wh.gov\/dv2y",
        "display_url" : "wh.gov\/dv2y"
      } ]
    },
    "geo" : { },
    "id_str" : "302121705885818880",
    "text" : "\"Valentine's Day: Our Beautiful, Romantic National Parks\" How to win \"best engagement\" contests: http:\/\/t.co\/8TMmc6Bt cc @nitalovesmiles",
    "id" : 302121705885818880,
    "created_at" : "2013-02-14 18:26:42 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 302122385744723968,
  "created_at" : "2013-02-14 18:29:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "302114278721351680",
  "text" : "Today at 1:20 ET: President Obama speaks on education from Decatur, GA. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 302114278721351680,
  "created_at" : "2013-02-14 17:57:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/4qBWPIwN",
      "expanded_url" : "http:\/\/on.wh.gov\/Ohw6VFP",
      "display_url" : "on.wh.gov\/Ohw6VFP"
    } ]
  },
  "geo" : { },
  "id_str" : "301900594086547456",
  "text" : "Full video: President Obama delivers the 2013 State of the Union address: http:\/\/t.co\/4qBWPIwN #SOTU",
  "id" : 301900594086547456,
  "created_at" : "2013-02-14 03:48:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 45, 52 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301879451870969856\/photo\/1",
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/GtU2wfQn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDB9wxZCQAE5wHP.jpg",
      "id_str" : "301879451879358465",
      "id" : 301879451879358465,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDB9wxZCQAE5wHP.jpg",
      "sizes" : [ {
        "h" : 554,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 416,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 554,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/GtU2wfQn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301879451870969856",
  "text" : "Photo of the Day: President Obama talks with @FLOTUS Michelle Obama &amp; Tina Tchen on the Colonnade of the White House http:\/\/t.co\/GtU2wfQn",
  "id" : 301879451870969856,
  "created_at" : "2013-02-14 02:24:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301864737384304641\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/AuJEScGB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDBwYRqCEAAgwWA.jpg",
      "id_str" : "301864737392693248",
      "id" : 301864737392693248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDBwYRqCEAAgwWA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/AuJEScGB"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/7knzGACy",
      "expanded_url" : "http:\/\/wh.gov\/dKlO",
      "display_url" : "wh.gov\/dKlO"
    } ]
  },
  "geo" : { },
  "id_str" : "301864737384304641",
  "text" : "New Photos: 2013 State of the Union: http:\/\/t.co\/7knzGACy View from the motorcade en route to the WH after #SOTU: http:\/\/t.co\/AuJEScGB",
  "id" : 301864737384304641,
  "created_at" : "2013-02-14 01:25:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/301819067336110080\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/js6oao0n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDBG17eCMAI10bC.jpg",
      "id_str" : "301819067344498690",
      "id" : 301819067344498690,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDBG17eCMAI10bC.jpg",
      "sizes" : [ {
        "h" : 620,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 620,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/js6oao0n"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 44, 49 ]
    }, {
      "text" : "FiresideHangout",
      "indices" : [ 50, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/dRSthSoY",
      "expanded_url" : "http:\/\/on.wh.gov\/Ye1RwzM",
      "display_url" : "on.wh.gov\/Ye1RwzM"
    } ]
  },
  "geo" : { },
  "id_str" : "301819067336110080",
  "text" : "Tomorrow at 4:50ET: President Obama joins a #SOTU #FiresideHangout live from the White House: http:\/\/t.co\/dRSthSoY http:\/\/t.co\/js6oao0n",
  "id" : 301819067336110080,
  "created_at" : "2013-02-13 22:24:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Popular Science",
      "screen_name" : "PopSci",
      "indices" : [ 90, 97 ],
      "id_str" : "19722699",
      "id" : 19722699
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 35, 40 ]
    }, {
      "text" : "Energy",
      "indices" : [ 41, 48 ]
    }, {
      "text" : "environment",
      "indices" : [ 49, 61 ]
    }, {
      "text" : "climatechange",
      "indices" : [ 62, 76 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "301797730626441216",
  "text" : "At 4ET: Heather Zichal takes Qs on #SOTU #Energy #environment #climatechange moderated by @PopSci Watch: http:\/\/t.co\/u95tzH8r Ask: #WHChat",
  "id" : 301797730626441216,
  "created_at" : "2013-02-13 20:59:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 36, 47 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Babble",
      "screen_name" : "BabbleEditors",
      "indices" : [ 67, 81 ],
      "id_str" : "18708066",
      "id" : 18708066
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Education",
      "indices" : [ 85, 95 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 96, 101 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 135, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "301785151506108416",
  "text" : "We're Open for Questions! At 3:15ET @arneduncan joins a Q&amp;A w\/ @BabbleEditors on #Education #SOTU. Watch http:\/\/t.co\/u95tzH8r Ask: #WHChat",
  "id" : 301785151506108416,
  "created_at" : "2013-02-13 20:09:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 84, 97 ],
      "id_str" : "19546277",
      "id" : 19546277
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 50, 55 ]
    }, {
      "text" : "Jobs",
      "indices" : [ 56, 61 ]
    }, {
      "text" : "Economy",
      "indices" : [ 62, 70 ]
    }, {
      "text" : "YFinSOTU",
      "indices" : [ 135, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "301775823709560833",
  "text" : "Happening Now: CEAs Alan Krueger joins Q&amp;A on #SOTU #Jobs #Economy moderated by @YahooFinance. Watch: http:\/\/t.co\/u95tzH8r  Ask w\/ #YFinSOTU",
  "id" : 301775823709560833,
  "created_at" : "2013-02-13 19:32:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 83, 96 ],
      "id_str" : "19546277",
      "id" : 19546277
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "Jobs",
      "indices" : [ 55, 60 ]
    }, {
      "text" : "Economy",
      "indices" : [ 61, 69 ]
    }, {
      "text" : "YFinSOTU",
      "indices" : [ 133, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "301757632392351744",
  "text" : "At 2:30ET: CEAs Alan Krueger joins a Q&amp;A on #SOTU, #Jobs #Economy moderated by @YahooFinance. Watch: http:\/\/t.co\/u95tzH8r Ask w\/ #YFinSOTU",
  "id" : 301757632392351744,
  "created_at" : "2013-02-13 18:20:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 85, 96 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301750597344964608",
  "text" : "RT @usedgov: Questions about education initiatives mentioned in the #SOTU? Tune into @ArneDuncan live today at 3:15pm http:\/\/t.co\/azogAn ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 72, 83 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 55, 60 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/azogAn8l",
        "expanded_url" : "http:\/\/1.usa.gov\/XzZxnn",
        "display_url" : "1.usa.gov\/XzZxnn"
      } ]
    },
    "geo" : { },
    "id_str" : "301743879915438081",
    "text" : "Questions about education initiatives mentioned in the #SOTU? Tune into @ArneDuncan live today at 3:15pm http:\/\/t.co\/azogAn8l Use #WHchat",
    "id" : 301743879915438081,
    "created_at" : "2013-02-13 17:25:21 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 301750597344964608,
  "created_at" : "2013-02-13 17:52:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/301734176573489153\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/IWeBfI4Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC_5oovCAAEvPTT.jpg",
      "id_str" : "301734176581877761",
      "id" : 301734176581877761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC_5oovCAAEvPTT.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IWeBfI4Y"
    } ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 55, 62 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "STEM",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "SpaceCampFTW",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301734566509568001",
  "text" : "RT @macon44: The Mohawk has landed! Happening now: Use #whchat to ask your \nquestions #SOTU #STEM #SpaceCampFTW http:\/\/t.co\/IWeBfI4Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/301734176573489153\/photo\/1",
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/IWeBfI4Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BC_5oovCAAEvPTT.jpg",
        "id_str" : "301734176581877761",
        "id" : 301734176581877761,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC_5oovCAAEvPTT.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/IWeBfI4Y"
      } ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 42, 49 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 73, 78 ]
      }, {
        "text" : "STEM",
        "indices" : [ 79, 84 ]
      }, {
        "text" : "SpaceCampFTW",
        "indices" : [ 85, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301734176573489153",
    "text" : "The Mohawk has landed! Happening now: Use #whchat to ask your \nquestions #SOTU #STEM #SpaceCampFTW http:\/\/t.co\/IWeBfI4Y",
    "id" : 301734176573489153,
    "created_at" : "2013-02-13 16:46:48 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 301734566509568001,
  "created_at" : "2013-02-13 16:48:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 15, 20 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 21, 36 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Bobak Ferdowsi",
      "screen_name" : "tweetsoutloud",
      "indices" : [ 43, 57 ],
      "id_str" : "61306578",
      "id" : 61306578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 99, 104 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301731433213468672",
  "text" : "Happening now: @NASA @WhiteHouseOSTP &amp; @tweetsoutloud are answering your Qs on space, science, #STEM &amp; tech. Ask with #WHChat",
  "id" : 301731433213468672,
  "created_at" : "2013-02-13 16:35:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 32, 37 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Bobak Ferdowsi",
      "screen_name" : "tweetsoutloud",
      "indices" : [ 53, 67 ],
      "id_str" : "61306578",
      "id" : 61306578
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 80, 95 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 108, 113 ]
    }, {
      "text" : "space",
      "indices" : [ 115, 121 ]
    }, {
      "text" : "science",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301724047786508290",
  "text" : "RT @whitehouseostp: At 11:30ET, @NASA Admin. Bolden, @Tweetsoutloud Bobak &amp; @WhitehouseOSTP answer your #STEM, #space #science Q's o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 12, 17 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "Bobak Ferdowsi",
        "screen_name" : "tweetsoutloud",
        "indices" : [ 33, 47 ],
        "id_str" : "61306578",
        "id" : 61306578
      }, {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 60, 75 ],
        "id_str" : "33998183",
        "id" : 33998183
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 88, 93 ]
      }, {
        "text" : "space",
        "indices" : [ 95, 101 ]
      }, {
        "text" : "science",
        "indices" : [ 102, 110 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 134, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301723273635434496",
    "text" : "At 11:30ET, @NASA Admin. Bolden, @Tweetsoutloud Bobak &amp; @WhitehouseOSTP answer your #STEM, #space #science Q's on Twitter. Ask w\/ #WHchat.",
    "id" : 301723273635434496,
    "created_at" : "2013-02-13 16:03:28 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 301724047786508290,
  "created_at" : "2013-02-13 16:06:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "indices" : [ 3, 16 ],
      "id_str" : "19546277",
      "id" : 19546277
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Jobs",
      "indices" : [ 34, 39 ]
    }, {
      "text" : "economy",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301708916394446848",
  "text" : "RT @YahooFinance: Wed. 2:30p ET: \"#Jobs and the #economy\" Q&amp;A w\/Jason Furman, Deputy Director of the Nat'l Economic Council, moderat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Nesto",
        "screen_name" : "MattNesto",
        "indices" : [ 124, 134 ],
        "id_str" : "143922209",
        "id" : 143922209
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Jobs",
        "indices" : [ 16, 21 ]
      }, {
        "text" : "economy",
        "indices" : [ 30, 38 ]
      }, {
        "text" : "YFinSOTU",
        "indices" : [ 135, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301536530760081408",
    "text" : "Wed. 2:30p ET: \"#Jobs and the #economy\" Q&amp;A w\/Jason Furman, Deputy Director of the Nat'l Economic Council, moderated by @MattNesto #YFinSOTU",
    "id" : 301536530760081408,
    "created_at" : "2013-02-13 03:41:25 +0000",
    "user" : {
      "name" : "Yahoo Finance",
      "screen_name" : "YahooFinance",
      "protected" : false,
      "id_str" : "19546277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710978975376388096\/1U2djlFO_normal.jpg",
      "id" : 19546277,
      "verified" : true
    }
  },
  "id" : 301708916394446848,
  "created_at" : "2013-02-13 15:06:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 78, 89 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301706407273717760",
  "text" : "RT @whitehouseostp: State of Science, Technology, Engineering and Math at the @whitehouse starting soon. Watch live at http:\/\/t.co\/HPkvF ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 58, 69 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SoSTEM",
        "indices" : [ 120, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/HPkvF3i8",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "301705706510376961",
    "text" : "State of Science, Technology, Engineering and Math at the @whitehouse starting soon. Watch live at http:\/\/t.co\/HPkvF3i8 #SoSTEM",
    "id" : 301705706510376961,
    "created_at" : "2013-02-13 14:53:40 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 301706407273717760,
  "created_at" : "2013-02-13 14:56:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 43, 48 ]
    }, {
      "text" : "Jobs",
      "indices" : [ 55, 60 ]
    }, {
      "text" : "Education",
      "indices" : [ 61, 71 ]
    }, {
      "text" : "CleanEnergy",
      "indices" : [ 75, 87 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/zyaHMbTK",
      "expanded_url" : "http:\/\/wh.gov\/dCtQ",
      "display_url" : "wh.gov\/dCtQ"
    } ]
  },
  "geo" : { },
  "id_str" : "301691175616774144",
  "text" : "The White House is Open for Questions. Got #SOTU Qs on #Jobs #Education or #CleanEnergy? Ask us with #WHChat: http:\/\/t.co\/zyaHMbTK",
  "id" : 301691175616774144,
  "created_at" : "2013-02-13 13:55:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/tMh7iOc6",
      "expanded_url" : "http:\/\/at.wh.gov\/hFrgL",
      "display_url" : "at.wh.gov\/hFrgL"
    } ]
  },
  "geo" : { },
  "id_str" : "301679763817365504",
  "text" : "Missed the enhanced State of the Union? Watch the full video here: http:\/\/t.co\/tMh7iOc6 #SOTU",
  "id" : 301679763817365504,
  "created_at" : "2013-02-13 13:10:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn SlideShare",
      "screen_name" : "SlideShare",
      "indices" : [ 91, 102 ],
      "id_str" : "9676152",
      "id" : 9676152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 27, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/Cq1o2eHG",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    }, {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/aVnjMGxI",
      "expanded_url" : "http:\/\/www.slideshare.net\/whitehouse\/white-house-state-of-the-union-2013-enhanced-graphics",
      "display_url" : "slideshare.net\/whitehouse\/whi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301598355077873664",
  "text" : "Did you watch the enhanced #SOTU at http:\/\/t.co\/Cq1o2eHG? Check out all of the graphics on @slideshare: http:\/\/t.co\/aVnjMGxI",
  "id" : 301598355077873664,
  "created_at" : "2013-02-13 07:47:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "SoundCloud",
      "screen_name" : "SoundCloud",
      "indices" : [ 62, 73 ],
      "id_str" : "5943942",
      "id" : 5943942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 97, 102 ]
    }, {
      "text" : "SoundCloud",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 96 ],
      "url" : "https:\/\/t.co\/5F5Hqw6Z",
      "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/president-obama-delivers-the?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter&utm_content=https:\/\/soundcloud.com\/whitehouse\/president-obama-delivers-the",
      "display_url" : "soundcloud.com\/whitehouse\/pre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301594912099540993",
  "text" : "RT @ks44: President Obama's State of the Union Address now at @soundcloud: https:\/\/t.co\/5F5Hqw6Z #SOTU #SoundCloud",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SoundCloud",
        "screen_name" : "SoundCloud",
        "indices" : [ 52, 63 ],
        "id_str" : "5943942",
        "id" : 5943942
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 87, 92 ]
      }, {
        "text" : "SoundCloud",
        "indices" : [ 93, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 86 ],
        "url" : "https:\/\/t.co\/5F5Hqw6Z",
        "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/president-obama-delivers-the?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter&utm_content=https:\/\/soundcloud.com\/whitehouse\/president-obama-delivers-the",
        "display_url" : "soundcloud.com\/whitehouse\/pre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301589561669206016",
    "text" : "President Obama's State of the Union Address now at @soundcloud: https:\/\/t.co\/5F5Hqw6Z #SOTU #SoundCloud",
    "id" : 301589561669206016,
    "created_at" : "2013-02-13 07:12:09 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 301594912099540993,
  "created_at" : "2013-02-13 07:33:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Montgomery",
      "screen_name" : "kmonty",
      "indices" : [ 3, 10 ],
      "id_str" : "8795392",
      "id" : 8795392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 111, 116 ]
    }, {
      "text" : "CitizenResponse",
      "indices" : [ 117, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301584284576268288",
  "text" : "RT @kmonty: This line in the President's State of the Union Address spoke to me. Check it out &amp; share your #SOTU #CitizenResponse ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 99, 104 ]
      }, {
        "text" : "CitizenResponse",
        "indices" : [ 105, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/5ci7VZZ3",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/sotu2013?sss_id=400403f4",
        "display_url" : "whitehouse.gov\/sotu2013?sss_i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301581182632603648",
    "text" : "This line in the President's State of the Union Address spoke to me. Check it out &amp; share your #SOTU #CitizenResponse http:\/\/t.co\/5ci7VZZ3",
    "id" : 301581182632603648,
    "created_at" : "2013-02-13 06:38:51 +0000",
    "user" : {
      "name" : "Karen Montgomery",
      "screen_name" : "kmonty",
      "protected" : false,
      "id_str" : "8795392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77809893\/EdwardRobertHughes-1_normal.jpg",
      "id" : 8795392,
      "verified" : false
    }
  },
  "id" : 301584284576268288,
  "created_at" : "2013-02-13 06:51:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/301580251404849153\/photo\/1",
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/VtRHEFfu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC9tpAzCUAA3o50.jpg",
      "id_str" : "301580251413237760",
      "id" : 301580251413237760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC9tpAzCUAA3o50.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/VtRHEFfu"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301580251404849153",
  "text" : "Tonight in #SOTU, President Obama called on Congress to reward hard work by raising the minimum wage: http:\/\/t.co\/VtRHEFfu",
  "id" : 301580251404849153,
  "created_at" : "2013-02-13 06:35:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Westley Bayas",
      "screen_name" : "WestleyBayas",
      "indices" : [ 3, 16 ],
      "id_str" : "19667003",
      "id" : 19667003
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 113, 118 ]
    }, {
      "text" : "CitizenResponse",
      "indices" : [ 119, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301579443997118464",
  "text" : "RT @WestleyBayas: ths line in the President's State of the Union Address spoke 2 me. Check it out &amp; share yr #SOTU #CitizenResponse  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 95, 100 ]
      }, {
        "text" : "CitizenResponse",
        "indices" : [ 101, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/K8qfaY7E",
        "expanded_url" : "http:\/\/1.usa.gov\/Wkv0bJ",
        "display_url" : "1.usa.gov\/Wkv0bJ"
      } ]
    },
    "geo" : { },
    "id_str" : "301578472386617345",
    "text" : "ths line in the President's State of the Union Address spoke 2 me. Check it out &amp; share yr #SOTU #CitizenResponse http:\/\/t.co\/K8qfaY7E",
    "id" : 301578472386617345,
    "created_at" : "2013-02-13 06:28:05 +0000",
    "user" : {
      "name" : "Westley Bayas",
      "screen_name" : "WestleyBayas",
      "protected" : false,
      "id_str" : "19667003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666441325768654848\/ONtBGM8Y_normal.jpg",
      "id" : 19667003,
      "verified" : false
    }
  },
  "id" : 301579443997118464,
  "created_at" : "2013-02-13 06:31:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clark Miller",
      "screen_name" : "clarkamiller",
      "indices" : [ 3, 16 ],
      "id_str" : "36589271",
      "id" : 36589271
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 109, 114 ]
    }, {
      "text" : "CitizenResponse",
      "indices" : [ 115, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301577951022030848",
  "text" : "RT @clarkamiller: The President's focus on climate in the State of the Union Address is critical. Share your #SOTU #CitizenResponse http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 91, 96 ]
      }, {
        "text" : "CitizenResponse",
        "indices" : [ 97, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/v96b4MAv",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/sotu2013?sss_id=71866a7f",
        "display_url" : "whitehouse.gov\/sotu2013?sss_i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301576563646947328",
    "text" : "The President's focus on climate in the State of the Union Address is critical. Share your #SOTU #CitizenResponse http:\/\/t.co\/v96b4MAv",
    "id" : 301576563646947328,
    "created_at" : "2013-02-13 06:20:30 +0000",
    "user" : {
      "name" : "Clark Miller",
      "screen_name" : "clarkamiller",
      "protected" : false,
      "id_str" : "36589271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/574240813628043264\/0Nd-vdMr_normal.jpeg",
      "id" : 36589271,
      "verified" : false
    }
  },
  "id" : 301577951022030848,
  "created_at" : "2013-02-13 06:26:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judith Fardig",
      "screen_name" : "FardigJudith",
      "indices" : [ 3, 16 ],
      "id_str" : "312108472",
      "id" : 312108472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301576909517619200",
  "text" : "RT @FardigJudith: This line in the President's State of the Union Address spoke to me. Check it out &amp; share your #SOTU #CitizenRespo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 99, 104 ]
      }, {
        "text" : "CitizenResponse",
        "indices" : [ 105, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/4RG8iQ0S",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/sotu2013?sss_id=e06eba57",
        "display_url" : "whitehouse.gov\/sotu2013?sss_i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301572216880001024",
    "text" : "This line in the President's State of the Union Address spoke to me. Check it out &amp; share your #SOTU #CitizenResponse http:\/\/t.co\/4RG8iQ0S",
    "id" : 301572216880001024,
    "created_at" : "2013-02-13 06:03:14 +0000",
    "user" : {
      "name" : "Judith Fardig",
      "screen_name" : "FardigJudith",
      "protected" : false,
      "id_str" : "312108472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606109176188657664\/-0Lqgmcq_normal.jpg",
      "id" : 312108472,
      "verified" : false
    }
  },
  "id" : 301576909517619200,
  "created_at" : "2013-02-13 06:21:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 35, 40 ]
    }, {
      "text" : "CitizenResponse",
      "indices" : [ 92, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/Cq1o2eHG",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "301568182378958848",
  "text" : "President Obama just delivered the #SOTU Address, now he wants to hear from you. Share your #CitizenResponse: http:\/\/t.co\/Cq1o2eHG",
  "id" : 301568182378958848,
  "created_at" : "2013-02-13 05:47:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301561431478898689\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/KoOfbVvf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC9chjHCEAAn61j.jpg",
      "id_str" : "301561431487287296",
      "id" : 301561431487287296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC9chjHCEAAn61j.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/KoOfbVvf"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/Cq1o2eHG",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "301561431478898689",
  "text" : "\"As Americans, we all share the same proud title: We are citizens.\" \u2014President Obama: http:\/\/t.co\/Cq1o2eHG #SOTU http:\/\/t.co\/KoOfbVvf",
  "id" : 301561431478898689,
  "created_at" : "2013-02-13 05:20:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 10, 17 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 137, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/Cq1o2eHG",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "301548384895004673",
  "text" : "Tonight's #WHChat will be ending shortly but President Obama &amp; WH officials are taking your questions all week: http:\/\/t.co\/Cq1o2eHG #SOTU",
  "id" : 301548384895004673,
  "created_at" : "2013-02-13 04:28:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Revkin",
      "screen_name" : "Revkin",
      "indices" : [ 3, 10 ],
      "id_str" : "11178672",
      "id" : 11178672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 34, 39 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/ELXcDw1M",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/state-of-the-union-2013",
      "display_url" : "whitehouse.gov\/state-of-the-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301543805138657280",
  "text" : "RT @Revkin: More interesting than #SOTU is #WHchat going on now with White House staff addressing questions: http:\/\/t.co\/ELXcDw1M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 22, 27 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 31, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/ELXcDw1M",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/state-of-the-union-2013",
        "display_url" : "whitehouse.gov\/state-of-the-u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "301542166524723202",
    "text" : "More interesting than #SOTU is #WHchat going on now with White House staff addressing questions: http:\/\/t.co\/ELXcDw1M",
    "id" : 301542166524723202,
    "created_at" : "2013-02-13 04:03:49 +0000",
    "user" : {
      "name" : "Andy Revkin",
      "screen_name" : "Revkin",
      "protected" : false,
      "id_str" : "11178672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433051183289073664\/QCA_FvgX_normal.jpeg",
      "id" : 11178672,
      "verified" : true
    }
  },
  "id" : 301543805138657280,
  "created_at" : "2013-02-13 04:10:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301543450493472768",
  "text" : "RT @FLOTUS: Just watched Barack give the State of the Union Address. I'm proud of him, hopeful for our future\u2014and ready to get to work. \u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301537154025279490",
    "text" : "Just watched Barack give the State of the Union Address. I'm proud of him, hopeful for our future\u2014and ready to get to work. \u2013mo",
    "id" : 301537154025279490,
    "created_at" : "2013-02-13 03:43:54 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 301543450493472768,
  "created_at" : "2013-02-13 04:08:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "301531760565571585",
  "text" : "Happening now: WH officials answer your questions on the State of the Union Address. Ask now with #WHChat. Watch: http:\/\/t.co\/u95tzH8r",
  "id" : 301531760565571585,
  "created_at" : "2013-02-13 03:22:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/301530305163055104\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/z6giLzwQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC9ANwiCUAEW8qB.jpg",
      "id_str" : "301530305167249409",
      "id" : 301530305167249409,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC9ANwiCUAEW8qB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/z6giLzwQ"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301530305163055104",
  "text" : "Obama: \"It remains the task of us all...to be the authors of the next great chapter in our American story.\u201D #SOTU http:\/\/t.co\/z6giLzwQ",
  "id" : 301530305163055104,
  "created_at" : "2013-02-13 03:16:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301530174447562752",
  "text" : "President Obama: \"Thank you, God bless you, and God bless the United States of America.\" #SOTU",
  "id" : 301530174447562752,
  "created_at" : "2013-02-13 03:16:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301530131707621376",
  "text" : "\"It remains the task of us all, as citizens...to be the authors of the next great chapter in our American story.\" \u2014President Obama in #SOTU",
  "id" : 301530131707621376,
  "created_at" : "2013-02-13 03:16:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301529958071795714",
  "text" : "\"As Americans, we all share the same proud title: We are citizens.\" \u2014President Obama in #SOTU",
  "id" : 301529958071795714,
  "created_at" : "2013-02-13 03:15:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301529288291794944",
  "text" : "President Obama: \"We were sent here to look out for our fellow Americans the same way they look out for one another, every single day\" #SOTU",
  "id" : 301529288291794944,
  "created_at" : "2013-02-13 03:12:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 138, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301529225222045696",
  "text" : "We were sent here to make what difference we can, to secure this nation, expand opportunity &amp; uphold our ideals.\" \u2014President Obama in #SOTU",
  "id" : 301529225222045696,
  "created_at" : "2013-02-13 03:12:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/301529177625088000\/photo\/1",
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/f1i8MWIu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC8_MIJCUAAC5tn.jpg",
      "id_str" : "301529177633476608",
      "id" : 301529177633476608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC8_MIJCUAAC5tn.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/f1i8MWIu"
    } ],
    "hashtags" : [ {
      "text" : "NowistheTime",
      "indices" : [ 46, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301529177625088000",
  "text" : "\"They deserve a simple vote.\"\u2014President Obama #NowistheTime http:\/\/t.co\/f1i8MWIu",
  "id" : 301529177625088000,
  "created_at" : "2013-02-13 03:12:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301529165604208641",
  "text" : "Obama: \"No administrative acts will perfectly solve all the challenges I\u2019ve outlined tonight. But we were never sent here to be perfect.\"",
  "id" : 301529165604208641,
  "created_at" : "2013-02-13 03:12:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 27, 41 ],
      "id_str" : "44177383",
      "id" : 44177383
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/301528943050244098\/photo\/1",
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/EM672uTr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC8--eRCQAAOzTQ.jpg",
      "id_str" : "301528943054438400",
      "id" : 301528943054438400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC8--eRCQAAOzTQ.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/EM672uTr"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 19, 24 ]
    }, {
      "text" : "NowIsTheTime",
      "indices" : [ 60, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301528943050244098",
  "text" : "President Obama in #SOTU: \"@GabbyGiffords deserves a vote.\" #NowIsTheTime http:\/\/t.co\/EM672uTr",
  "id" : 301528943050244098,
  "created_at" : "2013-02-13 03:11:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301528245453611009\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/cyHmafLw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC8-V3hCYAEOBXN.jpg",
      "id_str" : "301528245457805313",
      "id" : 301528245457805313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC8-V3hCYAEOBXN.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/cyHmafLw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301528245453611009",
  "text" : "Obama: \"This is not the first time this country has debated how to reduce gun violence. But this time is different.\" http:\/\/t.co\/cyHmafLw",
  "id" : 301528245453611009,
  "created_at" : "2013-02-13 03:08:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301528153455747072",
  "text" : "President Obama: \"What I\u2019ve said tonight matters little if we don\u2019t come together to protect our most precious resource \u2013 our children.\"",
  "id" : 301528153455747072,
  "created_at" : "2013-02-13 03:08:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301528104206233600",
  "text" : "President Obama: \"We can fix this, and we will.  The American people demand it.  And so does our democracy.\" #SOTU",
  "id" : 301528104206233600,
  "created_at" : "2013-02-13 03:07:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301527987365494784",
  "text" : "President Obama in #SOTU: \"I\u2019m announcing a non-partisan commission to improve the voting experience in America.\"",
  "id" : 301527987365494784,
  "created_at" : "2013-02-13 03:07:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301527818750287873",
  "text" : "President Obama: \"That includes our most fundamental right as citizens:  the right to vote.\" #SOTU",
  "id" : 301527818750287873,
  "created_at" : "2013-02-13 03:06:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301527727461244929",
  "text" : "President Obama: \"We must all do our part to make sure our God-given rights are protected here at home.\" #SOTU",
  "id" : 301527727461244929,
  "created_at" : "2013-02-13 03:06:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301527480517394432\/photo\/1",
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/0uKOu48i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC89pV7CAAAaDVR.jpg",
      "id_str" : "301527480525783040",
      "id" : 301527480525783040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC89pV7CAAAaDVR.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/0uKOu48i"
    } ],
    "hashtags" : [ {
      "text" : "stateoftheunion",
      "indices" : [ 56, 72 ]
    }, {
      "text" : "JoiningForces",
      "indices" : [ 73, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301527480517394432",
  "text" : "President Obama: \"We will keep faith with our veterans\" #stateoftheunion #JoiningForces http:\/\/t.co\/0uKOu48i",
  "id" : 301527480517394432,
  "created_at" : "2013-02-13 03:05:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301527448598757376",
  "text" : "Obama: \"We will draw upon the courage and skills of our sisters...because women have proven under fire that they are ready for combat.\"",
  "id" : 301527448598757376,
  "created_at" : "2013-02-13 03:05:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301527366805618690",
  "text" : "\"We will ensure equal treatment for all service members, and equal benefits for their families \u2013 gay and straight.\"\u2014President Obama in #SOTU",
  "id" : 301527366805618690,
  "created_at" : "2013-02-13 03:05:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301527314414567424",
  "text" : "\"As long as I\u2019m Commander-in-Chief...we will maintain the best military the world has ever known.\" \u2014President Obama in #SOTU",
  "id" : 301527314414567424,
  "created_at" : "2013-02-13 03:04:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301527170080178177",
  "text" : "President Obama: \"All this work depends on the courage and sacrifice of those who serve in dangerous places at great personal risk\" #SOTU",
  "id" : 301527170080178177,
  "created_at" : "2013-02-13 03:04:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301527126228758528",
  "text" : "President Obama: \"We will stand steadfast with Israel in pursuit of security and a lasting peace.\" #SOTU",
  "id" : 301527126228758528,
  "created_at" : "2013-02-13 03:04:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301527006191968256",
  "text" : "\"We can \u2013 and will \u2013 insist on respect for the fundamental rights of all people.\" \u2014President Obama in #SOTU",
  "id" : 301527006191968256,
  "created_at" : "2013-02-13 03:03:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301526909223858176",
  "text" : "Obama: \"In the Middle East, we will stand with citizens as they demand their universal rights &amp; support stable transitions to democracy\"",
  "id" : 301526909223858176,
  "created_at" : "2013-02-13 03:03:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301526845491396608",
  "text" : "President Obama: \"In defense of freedom, we will remain the anchor of strong alliances from the Americas to Africa; from Europe to Asia.\"",
  "id" : 301526845491396608,
  "created_at" : "2013-02-13 03:02:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301526700330713088",
  "text" : "\"America must remain a beacon to all who seek freedom during this period of historic change.\" \u2014President Obama in #SOTU",
  "id" : 301526700330713088,
  "created_at" : "2013-02-13 03:02:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301526528204894208",
  "text" : "\"The United States will join with our allies to eradicate such extreme poverty in the next two decades\" \u2014President Obama in #SOTU",
  "id" : 301526528204894208,
  "created_at" : "2013-02-13 03:01:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301526451969196034",
  "text" : "\"Progress in the impoverished parts of our world enriches us all. \" \u2014President Obama in #SOTU",
  "id" : 301526451969196034,
  "created_at" : "2013-02-13 03:01:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301526400307978241",
  "text" : "\"Trade that is free and fair across the Atlantic supports millions of good-paying American jobs.\" \u2014President Obama in #SOTU",
  "id" : 301526400307978241,
  "created_at" : "2013-02-13 03:01:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301526338135801856\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/bV6UX7On",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC88m2OCQAEoiRu.jpg",
      "id_str" : "301526338144190465",
      "id" : 301526338144190465,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC88m2OCQAEoiRu.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/bV6UX7On"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301526338135801856",
  "text" : "\"To boost American exports, support American jobs...we intend to complete negotiations on a Trans-Pacific Partnership http:\/\/t.co\/bV6UX7On",
  "id" : 301526338135801856,
  "created_at" : "2013-02-13 03:00:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301526277297426432",
  "text" : "President Obama: \"Even as we protect our people, we should remember that today\u2019s world presents not only dangers, but opportunities.\" #SOTU",
  "id" : 301526277297426432,
  "created_at" : "2013-02-13 03:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301526188046815232",
  "text" : "President Obama: \"Congress must act as well, by passing legislation to give our government a greater capacity to secure our networks\" #SOTU",
  "id" : 301526188046815232,
  "created_at" : "2013-02-13 03:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301526100843057152",
  "text" : "President Obama: \"Earlier today, I signed a new executive order that will strengthen our cyber defenses.\" #SOTU",
  "id" : 301526100843057152,
  "created_at" : "2013-02-13 02:59:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301526063572455424",
  "text" : "President Obama: \"We cannot look back years from now &amp; wonder why we did nothing in the face of real threats to our security &amp; our economy\"",
  "id" : 301526063572455424,
  "created_at" : "2013-02-13 02:59:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301526018685009920",
  "text" : "Pres. Obama: \"Our enemies are seeking the ability to sabotage our power grid, our financial institutions &amp; our air traffic control systems.\"",
  "id" : 301526018685009920,
  "created_at" : "2013-02-13 02:59:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301525961436966912",
  "text" : "\"America must also face the real and rapidly growing threat from cyber-attacks.\" \u2014President Obama in #SOTU",
  "id" : 301525961436966912,
  "created_at" : "2013-02-13 02:59:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301525853236502528",
  "text" : "President Obama: \"We will engage Russia to seek further reductions in our nuclear arsenals.\" #SOTU",
  "id" : 301525853236502528,
  "created_at" : "2013-02-13 02:59:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301525725964550144",
  "text" : "\"The leaders of Iran must recognize that now is the time for a diplomatic solution.\" \u2014President Obama in #SOTU",
  "id" : 301525725964550144,
  "created_at" : "2013-02-13 02:58:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 138, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301525639465406464",
  "text" : "President Obama: \"North Korea must know that they will only achieve security &amp; prosperity by meeting their international obligations\" #SOTU",
  "id" : 301525639465406464,
  "created_at" : "2013-02-13 02:58:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301525603935481856",
  "text" : "President Obama: \"America will continue to lead the effort to prevent the spread of the world\u2019s most dangerous weapons.\" #SOTU",
  "id" : 301525603935481856,
  "created_at" : "2013-02-13 02:58:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301525416131321859",
  "text" : "Pres. Obama: \"My Administration has worked tirelessly to forge a durable legal &amp; policy framework to guide our counterterrorism operations\"",
  "id" : 301525416131321859,
  "created_at" : "2013-02-13 02:57:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301525314276823041",
  "text" : "President Obama: \"Where necessary...we will continue to take direct action against those terrorists who pose the gravest threat.\" #SOTU",
  "id" : 301525314276823041,
  "created_at" : "2013-02-13 02:56:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301525257204936705",
  "text" : "\"We will need to help countries like Yemen, Libya &amp; Somalia provide for their own security.\" -President Obama in #SOTU",
  "id" : 301525257204936705,
  "created_at" : "2013-02-13 02:56:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301525118738391040",
  "text" : "\"Today, the organization that attacked us on 9\/11 is a shadow of its former self.\" \u2014President Obama in #SOTU",
  "id" : 301525118738391040,
  "created_at" : "2013-02-13 02:56:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301525096240140289\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/ak1wWQkF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC87ejzCUAA4WA2.jpg",
      "id_str" : "301525096248528896",
      "id" : 301525096248528896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC87ejzCUAA4WA2.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/ak1wWQkF"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301525096240140289",
  "text" : "President Obama: \"Over the next year, another 34,000 American troops will come home from Afghanistan\" #SOTU http:\/\/t.co\/ak1wWQkF",
  "id" : 301525096240140289,
  "created_at" : "2013-02-13 02:55:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301525045371613184",
  "text" : "President Obama: \"America\u2019s commitment to a unified and sovereign Afghanistan will endure, but the nature of our commitment will change.\"",
  "id" : 301525045371613184,
  "created_at" : "2013-02-13 02:55:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301525025289297920",
  "text" : "President Obama: \"By the end of next year, our war in Afghanistan will be over.\" #SOTU",
  "id" : 301525025289297920,
  "created_at" : "2013-02-13 02:55:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301524711182057472",
  "text" : "President Obama: \"Tonight, we stand united in saluting the troops and civilians who sacrifice every day to protect us.\" #SOTU",
  "id" : 301524711182057472,
  "created_at" : "2013-02-13 02:54:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301524677195612161",
  "text" : "Obama: \"It is this kind of prosperity \u2013 broad, shared &amp; built on a thriving middle class \u2013 that has always been the source of our progress\"",
  "id" : 301524677195612161,
  "created_at" : "2013-02-13 02:54:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301524627467956224",
  "text" : "President Obama: \"Stronger families.  Stronger communities.  A stronger America.\"",
  "id" : 301524627467956224,
  "created_at" : "2013-02-13 02:54:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301524474950459392",
  "text" : "\"What makes you a man isn\u2019t the ability to conceive a child; it\u2019s having the courage to raise one.\" \u2014President Obama in #SOTU",
  "id" : 301524474950459392,
  "created_at" : "2013-02-13 02:53:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301524415454248960",
  "text" : "President Obama: \"Let\u2019s put people back to work rebuilding vacant homes in run-down neighborhoods.\" #JobsNow",
  "id" : 301524415454248960,
  "created_at" : "2013-02-13 02:53:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301524383925669889",
  "text" : "Obama: \"My Administration will begin to partner with 20 of the hardest-hit towns in America to get these communities back on their feet.\"",
  "id" : 301524383925669889,
  "created_at" : "2013-02-13 02:53:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301524291684560898",
  "text" : "\"We need to build new ladders of opportunity into the middle class for all who are willing to climb them.\" \u2014President Obama #JobsNow",
  "id" : 301524291684560898,
  "created_at" : "2013-02-13 02:52:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301524251394064384",
  "text" : "\"America is not a place where chance of birth or circumstance should decide our destiny.\" \u2014President Obama in #SOTU",
  "id" : 301524251394064384,
  "created_at" : "2013-02-13 02:52:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301524246595772416",
  "text" : "President Obama: \"Let\u2019s tie the minimum wage to the cost of living, so that it finally becomes a wage you can live on.\" #SOTU",
  "id" : 301524246595772416,
  "created_at" : "2013-02-13 02:52:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301524201817391104",
  "text" : "President Obama: \"There are communities in this country where no matter how hard you work, it\u2019s virtually impossible to get ahead.\" #JobsNow",
  "id" : 301524201817391104,
  "created_at" : "2013-02-13 02:52:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301524044967186432",
  "text" : "President Obama: \"Working folks shouldn\u2019t have to wait year after year for the minimum wage to go up while CEO pay has never been higher.\"",
  "id" : 301524044967186432,
  "created_at" : "2013-02-13 02:51:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301523862305259520",
  "text" : "\"Let\u2019s declare that in the wealthiest nation on Earth, no one who works full-time should have to live in poverty\" \u2014President Obama #JobsNow",
  "id" : 301523862305259520,
  "created_at" : "2013-02-13 02:51:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301523807565398016",
  "text" : "President Obama: \"A family with 2 kids that earns the minimum wage still lives below the poverty line. That\u2019s wrong.\"",
  "id" : 301523807565398016,
  "created_at" : "2013-02-13 02:50:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301523764624105472",
  "text" : "President Obama: \"We know our economy is stronger when we reward an honest day\u2019s work with honest wages.\" #SOTU",
  "id" : 301523764624105472,
  "created_at" : "2013-02-13 02:50:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301523725872922624\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/NONmmUjO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC86OyzCAAE-SPe.jpg",
      "id_str" : "301523725885505537",
      "id" : 301523725885505537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC86OyzCAAE-SPe.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/NONmmUjO"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301523725872922624",
  "text" : "\"I ask this Congress to declare that women should earn a living equal to their efforts.\" \u2014President Obama #EqualPay http:\/\/t.co\/NONmmUjO",
  "id" : 301523725872922624,
  "created_at" : "2013-02-13 02:50:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/301523573510656000\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/Ic56MRyj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC86F7NCUAAlEa5.jpg",
      "id_str" : "301523573523238912",
      "id" : 301523573523238912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC86F7NCUAAlEa5.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/Ic56MRyj"
    } ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301523573510656000",
  "text" : "\"Today, the Senate passed the Violence Against Women Act...I urge the House to do the same.\" \u2014President Obama #VAWA http:\/\/t.co\/Ic56MRyj",
  "id" : 301523573510656000,
  "created_at" : "2013-02-13 02:49:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 25, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301523365590626304",
  "text" : "\"Send me a comprehensive #ImmigrationReform bill in the next few months and I will sign it right away.\" \u2014President Obama",
  "id" : 301523365590626304,
  "created_at" : "2013-02-13 02:49:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 100, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301523280236519426",
  "text" : "President Obama: \"And real reform means fixing the legal immigration system to cut waiting periods\" #ImmigrationReform",
  "id" : 301523280236519426,
  "created_at" : "2013-02-13 02:48:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 94, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301523191313076224",
  "text" : "President Obama: \"Real reform means establishing a responsible pathway to earned citizenship\" #ImmigrationReform",
  "id" : 301523191313076224,
  "created_at" : "2013-02-13 02:48:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigrationreform",
      "indices" : [ 60, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301523132668313600",
  "text" : "President Obama: \"Real reform means strong border security\" #immigrationreform",
  "id" : 301523132668313600,
  "created_at" : "2013-02-13 02:48:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301523076070375424\/photo\/1",
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/YKuIYuPl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC85o-ECAAAhqE5.jpg",
      "id_str" : "301523076074569728",
      "id" : 301523076074569728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC85o-ECAAAhqE5.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/YKuIYuPl"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 41, 59 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301523076070375424",
  "text" : "\"The time has come to pass comprehensive #ImmigrationReform.\" \u2014President Obama in #SOTU http:\/\/t.co\/YKuIYuPl",
  "id" : 301523076070375424,
  "created_at" : "2013-02-13 02:47:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301522901394415616",
  "text" : "\"Our economy is stronger when we harness the talents and ingenuity of striving, hopeful immigrants.\" \u2014President Obama in #SOTU",
  "id" : 301522901394415616,
  "created_at" : "2013-02-13 02:47:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301522847891877888",
  "text" : "Obama: \"We also have to make sure that America remains a place where everyone who\u2019s willing to work hard has the chance to get ahead.\"",
  "id" : 301522847891877888,
  "created_at" : "2013-02-13 02:47:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301522787158355968",
  "text" : "\"To grow our middle class, our citizens must have access to the education and training that today\u2019s jobs require.\" \u2014President Obama #JobsNow",
  "id" : 301522787158355968,
  "created_at" : "2013-02-13 02:46:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301522547697139713",
  "text" : "\"Through tax credits, grants, and better loans, we have made college more affordable\" \u2014President Obama in #SOTU",
  "id" : 301522547697139713,
  "created_at" : "2013-02-13 02:45:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 30, 40 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301522483943723008",
  "text" : "\"It\u2019s a simple fact: the more #education you have, the more likely you are to have a good job.\" \u2014President Obama in #SOTU",
  "id" : 301522483943723008,
  "created_at" : "2013-02-13 02:45:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301522200488468480",
  "text" : "Obama: \"At schools like P-Tech ... students will graduate with a high school diploma &amp; an associate degree in computers or engineering.\"",
  "id" : 301522200488468480,
  "created_at" : "2013-02-13 02:44:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301522090232774657",
  "text" : "President Obama: \"Let\u2019s also make sure that a high school diploma puts our kids on a path to a good job.\" #JobsNow",
  "id" : 301522090232774657,
  "created_at" : "2013-02-13 02:44:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 120, 125 ]
    }, {
      "text" : "Education",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521984469221376",
  "text" : "\"So let\u2019s do what works, and make sure none of our children start the race of life already behind.\" -President Obama in #SOTU #Education",
  "id" : 301521984469221376,
  "created_at" : "2013-02-13 02:43:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 56, 66 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521844954099713",
  "text" : "\"Every dollar we invest in high-quality early childhood #education can save more than seven dollars later on.\" -President Obama in #SOTU",
  "id" : 301521844954099713,
  "created_at" : "2013-02-13 02:43:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301521755720278016\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/FeKlVvl7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC84cHYCYAIdSGa.jpg",
      "id_str" : "301521755724472322",
      "id" : 301521755724472322,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC84cHYCYAIdSGa.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/FeKlVvl7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521755720278016",
  "text" : "\"I propose working with states to make high-quality pre-school available to every child in America.\" -President Obama http:\/\/t.co\/FeKlVvl7",
  "id" : 301521755720278016,
  "created_at" : "2013-02-13 02:42:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521736921395201",
  "text" : "President Obama: \"Poor kids who need help the most, this lack of access to preschool education can shadow them for the rest of their lives.\"",
  "id" : 301521736921395201,
  "created_at" : "2013-02-13 02:42:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521691710992384",
  "text" : "President Obama: \"Today, fewer than 3 in 10 four year-olds are enrolled in a high-quality preschool program\"",
  "id" : 301521691710992384,
  "created_at" : "2013-02-13 02:42:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Education",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521596735184896",
  "text" : "President Obama: \"Study after study shows that the sooner a child begins learning, the better he or she does down the road.\" #Education",
  "id" : 301521596735184896,
  "created_at" : "2013-02-13 02:42:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301521537108934656\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/gTUBCoMj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC84PY_CAAMbqjl.jpg",
      "id_str" : "301521537113128963",
      "id" : 301521537113128963,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC84PY_CAAMbqjl.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/gTUBCoMj"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521537108934656",
  "text" : "Obama: \"Too many families who have never missed a payment and want to refinance are being told no.\" #SOTU http:\/\/t.co\/gTUBCoMj",
  "id" : 301521537108934656,
  "created_at" : "2013-02-13 02:41:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521479454060545",
  "text" : "Obama: \"Initiatives in manufacturing, energy, infrastructure &amp; housing will help entrepreneurs &amp; small business expand &amp; create new jobs.\"",
  "id" : 301521479454060545,
  "created_at" : "2013-02-13 02:41:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521406787723265",
  "text" : "President Obama: \"Overlapping regulations keep responsible young families from buying their first home. \"",
  "id" : 301521406787723265,
  "created_at" : "2013-02-13 02:41:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521168911962114",
  "text" : "\"Too many families with solid credit who want to buy a home are being rejected.\" -President Obama in #SOTU",
  "id" : 301521168911962114,
  "created_at" : "2013-02-13 02:40:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521116759990273",
  "text" : "President Obama: \"Home prices are rising at the fastest pace in 6 years, home purchases are up nearly 50% &amp; construction is expanding again\"",
  "id" : 301521116759990273,
  "created_at" : "2013-02-13 02:40:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521073143439361",
  "text" : "President Obama: \u201CToday, our housing market is finally healing from the collapse of 2007.\u201D #SOTU",
  "id" : 301521073143439361,
  "created_at" : "2013-02-13 02:40:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 122, 127 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301521024825036800",
  "text" : "\"Let\u2019s prove that there is no better place to do business than here in the United States of America.\" -President Obama in #SOTU #JobsNow",
  "id" : 301521024825036800,
  "created_at" : "2013-02-13 02:39:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301520944806113280",
  "text" : "President Obama: \"I\u2019m also proposing a Partnership to Rebuild America that attracts private capital to upgrade what our businesses need.\"",
  "id" : 301520944806113280,
  "created_at" : "2013-02-13 02:39:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301520827730518018",
  "text" : "President Obama: \"Tonight, I propose a \u201CFix-It-First\u201D program to put people to work as soon as possible on our most urgent repairs.\"",
  "id" : 301520827730518018,
  "created_at" : "2013-02-13 02:39:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 119, 127 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301520755143892992",
  "text" : "Obama: \"I know that you want these job-creating projects in your districts. I\u2019ve seen you all at the ribbon-cuttings.\" #JobsNow #SOTU",
  "id" : 301520755143892992,
  "created_at" : "2013-02-13 02:38:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301520528039108608",
  "text" : "Obama: \"I\u2019m also issuing a new goal for America: let\u2019s cut in half the energy wasted by our homes &amp; businesses over the next 20 yrs\"",
  "id" : 301520528039108608,
  "created_at" : "2013-02-13 02:37:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cleanenergy",
      "indices" : [ 123, 135 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 136, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301520406895009794",
  "text" : "President Obama: \"I propose we use some of our oil &amp; gas revenues ... to shift our cars &amp; trucks off oil for good\" #cleanenergy #SOTU",
  "id" : 301520406895009794,
  "created_at" : "2013-02-13 02:37:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cleanenergy",
      "indices" : [ 100, 112 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301520283561500672",
  "text" : "President Obama: \"the natural gas boom has led to cleaner power &amp; greater energy independence.\" #cleanenergy #SOTU",
  "id" : 301520283561500672,
  "created_at" : "2013-02-13 02:36:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanEnergy",
      "indices" : [ 98, 110 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 111, 119 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301520234823700480",
  "text" : "President Obama: \"As long as countries like China keep going all-in on clean energy, so must we.\" #CleanEnergy #JobsNow #SOTU",
  "id" : 301520234823700480,
  "created_at" : "2013-02-13 02:36:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301520189709750273\/photo\/1",
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/GgwyDWlA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC83A9jCEAEK8Po.jpg",
      "id_str" : "301520189718138881",
      "id" : 301520189718138881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC83A9jCEAEK8Po.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/GgwyDWlA"
    } ],
    "hashtags" : [ {
      "text" : "CleanEnergy",
      "indices" : [ 84, 96 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301520189709750273",
  "text" : "President Obama: \"If Congress won\u2019t act soon to protect future generations, I will\" #CleanEnergy #SOTU http:\/\/t.co\/GgwyDWlA",
  "id" : 301520189709750273,
  "created_at" : "2013-02-13 02:36:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cleanenergy",
      "indices" : [ 118, 130 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301520169413529600",
  "text" : "Obama: \"Last year, wind energy added nearly half of all new power capacity in America.  So let\u2019s generate even more.\" #cleanenergy #SOTU",
  "id" : 301520169413529600,
  "created_at" : "2013-02-13 02:36:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "climatechange",
      "indices" : [ 101, 115 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301520011313430528",
  "text" : "President Obama: \"I urge this Congress get together to pursue a bipartisan, market-based solution to #climatechange\" #SOTU",
  "id" : 301520011313430528,
  "created_at" : "2013-02-13 02:35:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301519951913684992\/photo\/1",
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/FZEtj018",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC82zHrCEAASi0n.jpg",
      "id_str" : "301519951917879296",
      "id" : 301519951917879296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC82zHrCEAASi0n.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/FZEtj018"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 19, 24 ]
    }, {
      "text" : "ClimateChange",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301519951913684992",
  "text" : "President Obama in #SOTU: \"we must do more to combat #ClimateChange\" http:\/\/t.co\/FZEtj018",
  "id" : 301519951913684992,
  "created_at" : "2013-02-13 02:35:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 19, 24 ]
    }, {
      "text" : "climatechange",
      "indices" : [ 53, 67 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301519784527417344",
  "text" : "President Obama in #SOTU: \"We must do more to combat #climatechange.\" #SOTU",
  "id" : 301519784527417344,
  "created_at" : "2013-02-13 02:34:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cleanenergy",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301519627647856640",
  "text" : "Obama: \"Over the last 4 years, our emissions of the dangerous carbon pollution that threatens our planet have actually fallen\" #cleanenergy",
  "id" : 301519627647856640,
  "created_at" : "2013-02-13 02:34:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cleanenergy",
      "indices" : [ 114, 126 ]
    }, {
      "text" : "sotu",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301519583595094016",
  "text" : "Obama: \"We produce more natural gas than ever before \u2013 and nearly everyone\u2019s energy bill is lower because of it.\" #cleanenergy #sotu",
  "id" : 301519583595094016,
  "created_at" : "2013-02-13 02:34:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301519507984355329\/photo\/1",
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/aV8GzDph",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC82ZR7CEAE36Jj.jpg",
      "id_str" : "301519507992743937",
      "id" : 301519507992743937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC82ZR7CEAE36Jj.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/aV8GzDph"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 73, 78 ]
    }, {
      "text" : "CleanEnergy",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301519507984355329",
  "text" : "President Obama: \"We produce more oil at home than we have in 15 years.\" #SOTU #CleanEnergy http:\/\/t.co\/aV8GzDph",
  "id" : 301519507984355329,
  "created_at" : "2013-02-13 02:33:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanEnergy",
      "indices" : [ 108, 120 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 121, 129 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301519484546580480",
  "text" : "President Obama: \"After years of talking about it, we are finally poised to control our own energy future.\" #CleanEnergy #JobsNow #SOTU",
  "id" : 301519484546580480,
  "created_at" : "2013-02-13 02:33:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 125, 133 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301519406431879169",
  "text" : "President Obama: \"Now is the time to reach a level of research and development not seen since the height of the Space Race.\" #JobsNow #SOTU",
  "id" : 301519406431879169,
  "created_at" : "2013-02-13 02:33:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 112, 120 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301519280376262657",
  "text" : "Obama: \"We also have to invest in the best ideas.  Every $1 we invested to map the human genome returned $140\"  #JobsNow #SOTU",
  "id" : 301519280376262657,
  "created_at" : "2013-02-13 02:32:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 9, 14 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301518987005677568",
  "text" : "Obama in #SOTU: \"this year, Apple will start making Macs in America again.\" #JobsNow",
  "id" : 301518987005677568,
  "created_at" : "2013-02-13 02:31:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301518950079012864",
  "text" : "President Obama: \" After shedding jobs for more than 10 years, our manufacturers have added about 500,000 jobs over the past three.\"",
  "id" : 301518950079012864,
  "created_at" : "2013-02-13 02:31:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301518900733038592\/photo\/1",
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/f20OhKDn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC8117uCUAES8Vz.jpg",
      "id_str" : "301518900737232897",
      "id" : 301518900737232897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC8117uCUAES8Vz.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/f20OhKDn"
    } ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 87, 95 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301518900733038592",
  "text" : "Obama: \"Our first priority is making America a magnet for new jobs and manufacturing.\" #JobsNow #SOTU http:\/\/t.co\/f20OhKDn",
  "id" : 301518900733038592,
  "created_at" : "2013-02-13 02:31:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301518794709413889",
  "text" : "Obama: \"It\u2019s not a bigger government we need, but a smarter government that sets priorities and invests in broad-based growth.\" #JobsNow",
  "id" : 301518794709413889,
  "created_at" : "2013-02-13 02:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 111, 119 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301518728699465729",
  "text" : "President Obama: \"Let me repeat \u2013 nothing I\u2019m proposing tonight should increase our deficit by a single dime.\" #JobsNow #SOTU",
  "id" : 301518728699465729,
  "created_at" : "2013-02-13 02:30:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301518481684299778\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/ySqO7QeF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC81diqCAAAxyEN.jpg",
      "id_str" : "301518481692688384",
      "id" : 301518481692688384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC81diqCAAAxyEN.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/ySqO7QeF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301518481684299778",
  "text" : "\"A growing economy that creates good, middle-class jobs \u2013 that must be the North Star that guides our efforts.\" http:\/\/t.co\/ySqO7QeF",
  "id" : 301518481684299778,
  "created_at" : "2013-02-13 02:29:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 87, 92 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301518426965434368",
  "text" : "\"Let\u2019s be clear: deficit reduction alone is not an economic plan.\" -President Obama in #SOTU #JobsNow",
  "id" : 301518426965434368,
  "created_at" : "2013-02-13 02:29:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301518186950561792",
  "text" : "Obama: \"The greatest nation on Earth cannot keep conducting its business by drifting from one manufactured crisis to the next.\" #SOTU",
  "id" : 301518186950561792,
  "created_at" : "2013-02-13 02:28:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 137, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301518109163003905",
  "text" : "Obama: \"Let\u2019s set party interests aside &amp; work to pass a budget that replaces reckless cuts w\/ smart savings &amp; wise investments\" #SOTU",
  "id" : 301518109163003905,
  "created_at" : "2013-02-13 02:28:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301518003764342784",
  "text" : "President Obama: \"I realize that tax reform and entitlement reform won\u2019t be easy.\" #SOTU",
  "id" : 301518003764342784,
  "created_at" : "2013-02-13 02:27:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301517845202878464",
  "text" : "Obama: \"The American people deserve a tax code that helps small businesses spend less time filling out complicated forms\" #jobsnow",
  "id" : 301517845202878464,
  "created_at" : "2013-02-13 02:27:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301517744468267008",
  "text" : "Obama: \"Now is our best chance for bipartisan, comprehensive tax reform that encourages job creation &amp; helps bring down the deficit.\"",
  "id" : 301517744468267008,
  "created_at" : "2013-02-13 02:26:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301517623659749376\/photo\/1",
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/lgFXcDbb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC80rmSCYAALvTk.jpg",
      "id_str" : "301517623672332288",
      "id" : 301517623672332288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC80rmSCYAALvTk.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/lgFXcDbb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301517623659749376",
  "text" : "Obama: \"Why would we choose to make deeper cuts to education &amp; Medicare just to protect special interest tax breaks?\" http:\/\/t.co\/lgFXcDbb",
  "id" : 301517623659749376,
  "created_at" : "2013-02-13 02:26:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301517568181694465",
  "text" : "Obama: \"We should do what leaders in both parties have already suggested &amp; save 100s of billions of dollars by getting rid of tax loopholes\"",
  "id" : 301517568181694465,
  "created_at" : "2013-02-13 02:26:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301517489353936896",
  "text" : "\"Our government shouldn\u2019t make promises we cannot keep \u2013 but we must keep the promises we\u2019ve already made.\" \u2014President Obama in #SOTU",
  "id" : 301517489353936896,
  "created_at" : "2013-02-13 02:25:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301517456239890433",
  "text" : "\"I am open to additional reforms from both parties, so long as they don\u2019t violate the guarantee of a secure retirement\" \u2014President Obama",
  "id" : 301517456239890433,
  "created_at" : "2013-02-13 02:25:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301517238597480449\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/dmW1NeVV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC80VLzCcAAf3gN.jpg",
      "id_str" : "301517238605869056",
      "id" : 301517238605869056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC80VLzCcAAf3gN.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/dmW1NeVV"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301517238597480449",
  "text" : "President Obama: \"Already, the Affordable Care Act is helping to slow the growth of health care costs.\" #SOTU http:\/\/t.co\/dmW1NeVV",
  "id" : 301517238597480449,
  "created_at" : "2013-02-13 02:24:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301517168267362304",
  "text" : "President Obama: \"broad-based economic growth requires a balanced approach to deficit reduction...that\u2019s the approach I offer tonight\" #SOTU",
  "id" : 301517168267362304,
  "created_at" : "2013-02-13 02:24:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301517112441184257",
  "text" : "\"Most Americans \u2013 Democrats, Republicans &amp; Independents \u2013 understand that we can\u2019t just cut our way to prosperity\" \u2014President Obama",
  "id" : 301517112441184257,
  "created_at" : "2013-02-13 02:24:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301517030224445440",
  "text" : "Obama: \"We won\u2019t grow the middle class simply by shifting the cost of health care or college onto families that are already struggling.\"",
  "id" : 301517030224445440,
  "created_at" : "2013-02-13 02:23:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301516968819838976",
  "text" : "Obama: We can\u2019t ask \"working families to shoulder the entire burden of deficit reduction while asking nothing more from the wealthiest\"",
  "id" : 301516968819838976,
  "created_at" : "2013-02-13 02:23:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301516881049837569",
  "text" : "President Obama: \"Those of us who care deeply about programs like Medicare must embrace the need for modest reforms.\" #SOTU",
  "id" : 301516881049837569,
  "created_at" : "2013-02-13 02:23:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301516665458405376",
  "text" : "President Obama: \"Democrats, Republicans, business leaders, and economists have already said that these cuts...are a really bad idea\" #SOTU",
  "id" : 301516665458405376,
  "created_at" : "2013-02-13 02:22:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301516556930781185",
  "text" : "President Obama: \"These sudden, harsh, arbitrary cuts would jeopardize our military readiness.\" #SOTU",
  "id" : 301516556930781185,
  "created_at" : "2013-02-13 02:22:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 79, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301516459107028992",
  "text" : "\"Now we need to finish the job. And the question is, how?\" \u2014President Obama in #SOTU",
  "id" : 301516459107028992,
  "created_at" : "2013-02-13 02:21:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301516433232388096\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/1ZIZFBWe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC8zmTkCYAIIKoq.jpg",
      "id_str" : "301516433236582402",
      "id" : 301516433236582402,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC8zmTkCYAIIKoq.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/1ZIZFBWe"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301516433232388096",
  "text" : "President Obama in #SOTU: \"We are more than halfway towards the goal of $4 trillion in deficit reduction\" http:\/\/t.co\/1ZIZFBWe",
  "id" : 301516433232388096,
  "created_at" : "2013-02-13 02:21:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301516370410082304",
  "text" : "President Obama: \"Over the last few years, both parties have worked together to reduce the deficit by more than $2.5 trillion.\" #SOTU",
  "id" : 301516370410082304,
  "created_at" : "2013-02-13 02:21:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301516322821525505",
  "text" : "Obama: \"Our work must begin by making some basic decisions about our budget...will have a huge impact on the strength of our recovery\" #SOTU",
  "id" : 301516322821525505,
  "created_at" : "2013-02-13 02:21:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301516274075320320",
  "text" : "\"America moves forward only when we do so together...the responsibility of improving this union remains the task of us all\" \u2014President Obama",
  "id" : 301516274075320320,
  "created_at" : "2013-02-13 02:20:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301516126402252801",
  "text" : "Obama: The American people don\u2019t expect government to solve every problem...but they do expect us to put the nation\u2019s interests before party",
  "id" : 301516126402252801,
  "created_at" : "2013-02-13 02:20:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515981451325440",
  "text" : "\"It is our unfinished task to make sure that this government works on behalf of the many, and not just the few\" \u2014President Obama in #SOTU",
  "id" : 301515981451325440,
  "created_at" : "2013-02-13 02:19:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515931241299968",
  "text" : "Obama: \"It is our unfinished task to restore the basic bargain that built this country \u2013 the idea that if you work hard...you can get ahead\"",
  "id" : 301515931241299968,
  "created_at" : "2013-02-13 02:19:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515840296202240",
  "text" : "Obama: \"It is our generation\u2019s task, then, to reignite the true engine of America\u2019s economic growth \u2013 a rising, thriving middle class\" #SOTU",
  "id" : 301515840296202240,
  "created_at" : "2013-02-13 02:19:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 138, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515793009631232",
  "text" : "President Obama: \"Corporate profits have rocketed to all-time highs \u2013 but for more than a decade, wages &amp; incomes have barely budged\" #SOTU",
  "id" : 301515793009631232,
  "created_at" : "2013-02-13 02:19:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515750605201409",
  "text" : "President Obama: \"Our economy is adding jobs \u2013 but too many people still can\u2019t find full-time employment.\" #SOTU",
  "id" : 301515750605201409,
  "created_at" : "2013-02-13 02:18:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 139, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515714437709824",
  "text" : "Obama: \"We gather here knowing that there are millions of Americans whose hard work &amp; daily determination have not yet been rewarded.\" #SOTU",
  "id" : 301515714437709824,
  "created_at" : "2013-02-13 02:18:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 139, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515624818036736",
  "text" : "Obama: \"Together, we have cleared away the rubble of crisis &amp; can say with renewed confidence that the state of our union is stronger\" #SOTU",
  "id" : 301515624818036736,
  "created_at" : "2013-02-13 02:18:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 141, 146 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515550834696192",
  "text" : "Obama: \"Our housing market is healing, our stock market is rebounding &amp; consumers, patients &amp; homeowners enjoy stronger protections\" #SOTU",
  "id" : 301515550834696192,
  "created_at" : "2013-02-13 02:18:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515481754529792",
  "text" : "\"We buy more American cars than we have in five years, and less foreign oil than we have in twenty.\" \u2014President Obama in #SOTU",
  "id" : 301515481754529792,
  "created_at" : "2013-02-13 02:17:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301515448468525056\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/vHrCIRlT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC8ys_DCUAAng5g.jpg",
      "id_str" : "301515448476913664",
      "id" : 301515448476913664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC8ys_DCUAAng5g.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/vHrCIRlT"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515448468525056",
  "text" : "\"After years of grueling recession, our businesses have created over six million new jobs\" \u2014President Obama in #SOTU http:\/\/t.co\/vHrCIRlT",
  "id" : 301515448468525056,
  "created_at" : "2013-02-13 02:17:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515368936116226",
  "text" : "\"After a decade of grinding war, our brave men and women in uniform are coming home.\" \u2014President Obama in #SOTU",
  "id" : 301515368936116226,
  "created_at" : "2013-02-13 02:17:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515309410570240",
  "text" : "Obama: \"Tonight, thanks to the grit &amp; determination of the American people, there is much progress to report\" #SOTU",
  "id" : 301515309410570240,
  "created_at" : "2013-02-13 02:17:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301515284341211137\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/mRIAPzgf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC8yjboCQAArVSC.jpg",
      "id_str" : "301515284349599744",
      "id" : 301515284349599744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC8yjboCQAArVSC.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/mRIAPzgf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515284341211137",
  "text" : "Pres Obama quotes Kennedy: \u201CIt is my task to report the State of the Union \u2013 to improve it is the task of us all\u201D http:\/\/t.co\/mRIAPzgf",
  "id" : 301515284341211137,
  "created_at" : "2013-02-13 02:17:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301515165323628544\/photo\/1",
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/fThUrNNZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC8ycgPCEAI6l7D.jpg",
      "id_str" : "301515165327822850",
      "id" : 301515165327822850,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC8ycgPCEAI6l7D.jpg",
      "sizes" : [ {
        "h" : 483,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 507
      } ],
      "display_url" : "pic.twitter.com\/fThUrNNZ"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301515165323628544",
  "text" : "President Obama in #SOTU: \"Mr. Speaker, Mr. Vice President, Members of Congress, fellow citizens:\" http:\/\/t.co\/fThUrNNZ",
  "id" : 301515165323628544,
  "created_at" : "2013-02-13 02:16:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/Cq1o2eHG",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "301513536969011200",
  "text" : "Happening now: President Obama delivers the 2013 State of the Union Address: http:\/\/t.co\/Cq1o2eHG #SOTU",
  "id" : 301513536969011200,
  "created_at" : "2013-02-13 02:10:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/Cq1o2eHG",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "301505663916441600",
  "text" : "Starting in 20 min: President Obama delivers the State of the Union Address from the Capitol. Watch live: http:\/\/t.co\/Cq1o2eHG #SOTU",
  "id" : 301505663916441600,
  "created_at" : "2013-02-13 01:38:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/VnQI7RRY",
      "expanded_url" : "http:\/\/on.wh.gov\/U7xPj5U",
      "display_url" : "on.wh.gov\/U7xPj5U"
    }, {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/l1VFHDkR",
      "expanded_url" : "http:\/\/on.wh.gov\/Th4GGN0",
      "display_url" : "on.wh.gov\/Th4GGN0"
    } ]
  },
  "geo" : { },
  "id_str" : "301439911318401024",
  "text" : "The State of the Union like you've never seen it before: http:\/\/t.co\/VnQI7RRY Tune in tonight at 9ET: http:\/\/t.co\/l1VFHDkR #SOTU",
  "id" : 301439911318401024,
  "created_at" : "2013-02-12 21:17:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301437876447608832",
  "text" : "RT @VP: This issue should be beyond debate\u2013the House should follow the Senate\u2019s lead and pass the Violence Against Women Act right away. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301432305178775552",
    "text" : "This issue should be beyond debate\u2013the House should follow the Senate\u2019s lead and pass the Violence Against Women Act right away.\u2013VP on #VAWA",
    "id" : 301432305178775552,
    "created_at" : "2013-02-12 20:47:16 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 301437876447608832,
  "created_at" : "2013-02-12 21:09:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301425222970662912",
  "text" : "RT @FLOTUS: Some amazing Americans will be next to me for Barack\u2019s State of the Union Address. Read their incredible stories: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/mm3pbOUk",
        "expanded_url" : "http:\/\/wh.gov\/d2JS",
        "display_url" : "wh.gov\/d2JS"
      } ]
    },
    "geo" : { },
    "id_str" : "301425037372690432",
    "text" : "Some amazing Americans will be next to me for Barack\u2019s State of the Union Address. Read their incredible stories: http:\/\/t.co\/mm3pbOUk \u2013mo",
    "id" : 301425037372690432,
    "created_at" : "2013-02-12 20:18:23 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 301425222970662912,
  "created_at" : "2013-02-12 20:19:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobak Ferdowsi",
      "screen_name" : "tweetsoutloud",
      "indices" : [ 3, 17 ],
      "id_str" : "61306578",
      "id" : 61306578
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 29, 34 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 73, 87 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301389871753342980",
  "text" : "RT @tweetsoutloud: Excited! \u201C@NASA: Mr. Bobak 'Mohawk Guy' Ferdowsi from @MarsCuriosity team goes to Washington for tonight's #SOTU, sit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 10, 15 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "Curiosity Rover",
        "screen_name" : "MarsCuriosity",
        "indices" : [ 54, 68 ],
        "id_str" : "15473958",
        "id" : 15473958
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 131, 138 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 107, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "301388763383349248",
    "text" : "Excited! \u201C@NASA: Mr. Bobak 'Mohawk Guy' Ferdowsi from @MarsCuriosity team goes to Washington for tonight's #SOTU, sitting with the @FLOTUS\u201D",
    "id" : 301388763383349248,
    "created_at" : "2013-02-12 17:54:15 +0000",
    "user" : {
      "name" : "Bobak Ferdowsi",
      "screen_name" : "tweetsoutloud",
      "protected" : false,
      "id_str" : "61306578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745368236384911361\/qx3hr6Fb_normal.jpg",
      "id" : 61306578,
      "verified" : true
    }
  },
  "id" : 301389871753342980,
  "created_at" : "2013-02-12 17:58:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301377201465614337\/photo\/1",
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/O1YPyEQc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC60981CYAAjAS3.jpg",
      "id_str" : "301377201474002944",
      "id" : 301377201474002944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC60981CYAAjAS3.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/O1YPyEQc"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/Cq1o2eHG",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "301377201465614337",
  "text" : "Want a better way to watch the State of the Union? Watch live w\/ charts, graphs &amp; data at http:\/\/t.co\/Cq1o2eHG #SOTU http:\/\/t.co\/O1YPyEQc",
  "id" : 301377201465614337,
  "created_at" : "2013-02-12 17:08:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FiresideHangout",
      "indices" : [ 7, 23 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/ALnb10WN",
      "expanded_url" : "http:\/\/at.wh.gov\/hE0YL",
      "display_url" : "at.wh.gov\/hE0YL"
    } ]
  },
  "geo" : { },
  "id_str" : "301344855668432897",
  "text" : "Join a #FiresideHangout w\/ President Obama on Thurs at 4:50pm ET. Watch #SOTU tonight &amp; submit Qs for the President: http:\/\/t.co\/ALnb10WN",
  "id" : 301344855668432897,
  "created_at" : "2013-02-12 14:59:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 31, 36 ]
    }, {
      "text" : "FiresideHangout",
      "indices" : [ 37, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/zuSucb8T",
      "expanded_url" : "http:\/\/at.wh.gov\/hDcNI",
      "display_url" : "at.wh.gov\/hDcNI"
    } ]
  },
  "geo" : { },
  "id_str" : "301209297625440256",
  "text" : "On Thurs. at 3:50pm ET, join a #SOTU #FiresideHangout with President Obama. Submit your questions now &amp; watch live: http:\/\/t.co\/zuSucb8T",
  "id" : 301209297625440256,
  "created_at" : "2013-02-12 06:01:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301186398847909888\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/077VeC3I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC4HbxrCQAAQIvE.jpg",
      "id_str" : "301186398852104192",
      "id" : 301186398852104192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC4HbxrCQAAQIvE.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/077VeC3I"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/t3giXnvW",
      "expanded_url" : "http:\/\/on.wh.gov\/Rg5ntsd",
      "display_url" : "on.wh.gov\/Rg5ntsd"
    } ]
  },
  "geo" : { },
  "id_str" : "301186398847909888",
  "text" : "Tomorrow at 9 ET: Watch an exclusive enhanced live stream of the State of the Union Address: http:\/\/t.co\/t3giXnvW http:\/\/t.co\/077VeC3I",
  "id" : 301186398847909888,
  "created_at" : "2013-02-12 04:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/301179119666864129\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/SLTgbYpj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BC4A0EoCIAM2GVB.jpg",
      "id_str" : "301179119675252739",
      "id" : 301179119675252739,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BC4A0EoCIAM2GVB.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SLTgbYpj"
    } ],
    "hashtags" : [ {
      "text" : "MOH",
      "indices" : [ 106, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/ZDKs2vrj",
      "expanded_url" : "http:\/\/on.wh.gov\/3AB8UDS",
      "display_url" : "on.wh.gov\/3AB8UDS"
    } ]
  },
  "geo" : { },
  "id_str" : "301179119666864129",
  "text" : "Today, President Obama awarded the Medal of Honor to Staff Sergeant Clinton Romesha: http:\/\/t.co\/ZDKs2vrj #MOH Pic: http:\/\/t.co\/SLTgbYpj",
  "id" : 301179119666864129,
  "created_at" : "2013-02-12 04:01:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 3, 10 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firesidehangout",
      "indices" : [ 21, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/lRbLandb",
      "expanded_url" : "http:\/\/goo.gl\/pP25r",
      "display_url" : "goo.gl\/pP25r"
    } ]
  },
  "geo" : { },
  "id_str" : "301115707565936640",
  "text" : "RT @google: Join our #firesidehangout w\/ President Obama Thurs, 2\/14 @ 4:50pm ET http:\/\/t.co\/lRbLandb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "firesidehangout",
        "indices" : [ 9, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/lRbLandb",
        "expanded_url" : "http:\/\/goo.gl\/pP25r",
        "display_url" : "goo.gl\/pP25r"
      } ]
    },
    "geo" : { },
    "id_str" : "301005729958088704",
    "text" : "Join our #firesidehangout w\/ President Obama Thurs, 2\/14 @ 4:50pm ET http:\/\/t.co\/lRbLandb",
    "id" : 301005729958088704,
    "created_at" : "2013-02-11 16:32:13 +0000",
    "user" : {
      "name" : "Google",
      "screen_name" : "google",
      "protected" : false,
      "id_str" : "20536157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762369348300251136\/5Obhonwa_normal.jpg",
      "id" : 20536157,
      "verified" : true
    }
  },
  "id" : 301115707565936640,
  "created_at" : "2013-02-11 23:49:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/H30bwMO7",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=W09rCDX8ST4",
      "display_url" : "youtube.com\/watch?v=W09rCD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "301107742490386432",
  "text" : "Get an update from @WhiteHouse Communications Director Jennifer Palmieri on State of the Union prep: http:\/\/t.co\/H30bwMO7 #SOTU",
  "id" : 301107742490386432,
  "created_at" : "2013-02-11 23:17:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "301039730659844099",
  "text" : "Happening now: President Obama awards Clinton Romesha the Medal of Honor. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 301039730659844099,
  "created_at" : "2013-02-11 18:47:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "301014970374688769",
  "text" : "Happening at 1:45ET: President Obama awards Clinton Romesha the Medal of Honor. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 301014970374688769,
  "created_at" : "2013-02-11 17:08:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/vdiGQ5o9",
      "expanded_url" : "http:\/\/on.wh.gov\/eLoER2W",
      "display_url" : "on.wh.gov\/eLoER2W"
    }, {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/CA76Hvhh",
      "expanded_url" : "http:\/\/on.wh.gov\/qZRrVcQ",
      "display_url" : "on.wh.gov\/qZRrVcQ"
    } ]
  },
  "geo" : { },
  "id_str" : "300796045074513921",
  "text" : "Learn about our enhanced live stream of the State of the Union Address: http:\/\/t.co\/vdiGQ5o9 Watch 2\/12 @ 9ET: http:\/\/t.co\/CA76Hvhh #SOTU",
  "id" : 300796045074513921,
  "created_at" : "2013-02-11 02:39:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 17, 28 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/0RxQMHw9",
      "expanded_url" : "http:\/\/wh.gov\/pJ2x",
      "display_url" : "wh.gov\/pJ2x"
    } ]
  },
  "geo" : { },
  "id_str" : "300684803542491136",
  "text" : "RT @Brundage44: .@pfeiffer44 takes on myths perpetuated by some Congressional Republicans on the sequester here: http:\/\/t.co\/0RxQMHw9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 1, 12 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/0RxQMHw9",
        "expanded_url" : "http:\/\/wh.gov\/pJ2x",
        "display_url" : "wh.gov\/pJ2x"
      } ]
    },
    "geo" : { },
    "id_str" : "300679532116074497",
    "text" : ".@pfeiffer44 takes on myths perpetuated by some Congressional Republicans on the sequester here: http:\/\/t.co\/0RxQMHw9",
    "id" : 300679532116074497,
    "created_at" : "2013-02-10 18:56:01 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 300684803542491136,
  "created_at" : "2013-02-10 19:16:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/eL6aOWhd",
      "expanded_url" : "http:\/\/on.wh.gov\/kaXR5SO",
      "display_url" : "on.wh.gov\/kaXR5SO"
    } ]
  },
  "geo" : { },
  "id_str" : "300398948642869248",
  "text" : "President Obama to Congress on deficit reduction: \"Let's keep working together to solve this problem.\" Weekly Address: http:\/\/t.co\/eL6aOWhd",
  "id" : 300398948642869248,
  "created_at" : "2013-02-10 00:21:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 67, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/fek8iooF",
      "expanded_url" : "http:\/\/on.wh.gov\/oeqNFLp",
      "display_url" : "on.wh.gov\/oeqNFLp"
    }, {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/vI5clwoi",
      "expanded_url" : "http:\/\/on.wh.gov\/VQ5M11Q",
      "display_url" : "on.wh.gov\/VQ5M11Q"
    } ]
  },
  "geo" : { },
  "id_str" : "300363902838001664",
  "text" : "The best way to watch the State of the Union: http:\/\/t.co\/fek8iooF #SOTU Learn more: http:\/\/t.co\/vI5clwoi",
  "id" : 300363902838001664,
  "created_at" : "2013-02-09 22:01:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/Hb2LJDgj",
      "expanded_url" : "http:\/\/on.wh.gov\/h02kwoG",
      "display_url" : "on.wh.gov\/h02kwoG"
    } ]
  },
  "geo" : { },
  "id_str" : "300276360750968832",
  "text" : "In this week's address, President Obama calls on Congress to find a balanced approach to deficit reduction. Watch: http:\/\/t.co\/Hb2LJDgj",
  "id" : 300276360750968832,
  "created_at" : "2013-02-09 16:13:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 34, 43 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300113188941361153",
  "text" : "RT @FLOTUS: Happy 3rd anniversary @LetsMove! I\u2019ve been so inspired by Americans coming together for our kids\u2019 health. Stay tuned, more o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 22, 31 ],
        "id_str" : "36719281",
        "id" : 36719281
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "300108021693026304",
    "text" : "Happy 3rd anniversary @LetsMove! I\u2019ve been so inspired by Americans coming together for our kids\u2019 health. Stay tuned, more on the way! -mo",
    "id" : 300108021693026304,
    "created_at" : "2013-02-09 05:05:02 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 300113188941361153,
  "created_at" : "2013-02-09 05:25:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 40, 54 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/300090162887667713\/photo\/1",
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/0ld4BTLB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCoiacfCMAIFb8z.jpg",
      "id_str" : "300090162891862018",
      "id" : 300090162891862018,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCoiacfCMAIFb8z.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0ld4BTLB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300090162887667713",
  "text" : "Photo of the Day: President Obama &amp; @DeptofDefense Sec Panetta at the Armed Forces Farewell Tribute in Arlington, VA: http:\/\/t.co\/0ld4BTLB",
  "id" : 300090162887667713,
  "created_at" : "2013-02-09 03:54:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/NEQ1aFoW",
      "expanded_url" : "http:\/\/on.wh.gov\/lbTD7Gi",
      "display_url" : "on.wh.gov\/lbTD7Gi"
    } ]
  },
  "geo" : { },
  "id_str" : "300072563126697984",
  "text" : "This week, we let 18 outstanding Americans know that President Obama selected them to receive a 2012 Citizens Medal: http:\/\/t.co\/NEQ1aFoW",
  "id" : 300072563126697984,
  "created_at" : "2013-02-09 02:44:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/hn6oBzAx",
      "expanded_url" : "http:\/\/on.wh.gov\/8Hr3Ps1",
      "display_url" : "on.wh.gov\/8Hr3Ps1"
    } ]
  },
  "geo" : { },
  "id_str" : "300057441771601920",
  "text" : "On Feb 12 at 9 pm ET watch an exclusive enhanced live broadcast of President Obama's State of the Union Address: http:\/\/t.co\/hn6oBzAx #SOTU",
  "id" : 300057441771601920,
  "created_at" : "2013-02-09 01:44:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/300052317057724416\/photo\/1",
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/MpHe8WkJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCn__hzCMAADnWH.jpg",
      "id_str" : "300052317066113024",
      "id" : 300052317066113024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCn__hzCMAADnWH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/MpHe8WkJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "300053010153865217",
  "text" : "RT @petesouza: Photo of the day: POTUS w outgoing SecDef Panetta at his farewell tribute http:\/\/t.co\/MpHe8WkJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/300052317057724416\/photo\/1",
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/MpHe8WkJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BCn__hzCMAADnWH.jpg",
        "id_str" : "300052317066113024",
        "id" : 300052317066113024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCn__hzCMAADnWH.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/MpHe8WkJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "300052317057724416",
    "text" : "Photo of the day: POTUS w outgoing SecDef Panetta at his farewell tribute http:\/\/t.co\/MpHe8WkJ",
    "id" : 300052317057724416,
    "created_at" : "2013-02-09 01:23:41 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 300053010153865217,
  "created_at" : "2013-02-09 01:26:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowisthetime",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/bXSekACQ",
      "expanded_url" : "http:\/\/youtu.be\/gW-5kNMDVe4",
      "display_url" : "youtu.be\/gW-5kNMDVe4"
    } ]
  },
  "geo" : { },
  "id_str" : "300039364027772928",
  "text" : "RT @VP: VP's Chief of Staff Bruce Reed gives an update on the effort to reduce gun violence: http:\/\/t.co\/bXSekACQ #nowisthetime",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nowisthetime",
        "indices" : [ 106, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/bXSekACQ",
        "expanded_url" : "http:\/\/youtu.be\/gW-5kNMDVe4",
        "display_url" : "youtu.be\/gW-5kNMDVe4"
      } ]
    },
    "geo" : { },
    "id_str" : "300039257765076992",
    "text" : "VP's Chief of Staff Bruce Reed gives an update on the effort to reduce gun violence: http:\/\/t.co\/bXSekACQ #nowisthetime",
    "id" : 300039257765076992,
    "created_at" : "2013-02-09 00:31:48 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 300039364027772928,
  "created_at" : "2013-02-09 00:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/fUlZzP2G",
      "expanded_url" : "http:\/\/wh.gov\/p6WO",
      "display_url" : "wh.gov\/p6WO"
    } ]
  },
  "geo" : { },
  "id_str" : "299994898441052160",
  "text" : "Fact Sheet: Examples of How the Sequester Would Impact Middle Class Families, Jobs and Economic Security: http:\/\/t.co\/fUlZzP2G",
  "id" : 299994898441052160,
  "created_at" : "2013-02-08 21:35:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/JBClB50Q",
      "expanded_url" : "http:\/\/at.wh.gov\/hy9Un",
      "display_url" : "at.wh.gov\/hy9Un"
    } ]
  },
  "geo" : { },
  "id_str" : "299936919968694273",
  "text" : "President Obama: \"What's up, camera man?\" Behind-the-scenes look at this week at 1600 Penn: http:\/\/t.co\/JBClB50Q",
  "id" : 299936919968694273,
  "created_at" : "2013-02-08 17:45:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/J8Iahztm",
      "expanded_url" : "http:\/\/on.wh.gov\/nf3kDp1",
      "display_url" : "on.wh.gov\/nf3kDp1"
    } ]
  },
  "geo" : { },
  "id_str" : "299691048819646464",
  "text" : "\"Let us summon the common resolve that comes from our faith\" -President Obama at the National Prayer Breakfast: http:\/\/t.co\/J8Iahztm",
  "id" : 299691048819646464,
  "created_at" : "2013-02-08 01:28:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/299676954343374849\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/1wp4Etsl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCiqmiuCAAAPazK.jpg",
      "id_str" : "299676954351763456",
      "id" : 299676954351763456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCiqmiuCAAAPazK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/1wp4Etsl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/X3f6k9zQ",
      "expanded_url" : "http:\/\/on.wh.gov\/p7DOdwe",
      "display_url" : "on.wh.gov\/p7DOdwe"
    } ]
  },
  "geo" : { },
  "id_str" : "299676954343374849",
  "text" : "President Obama delivers remarks at the House Democratic Issues Conference in Leesburg, VA: http:\/\/t.co\/X3f6k9zQ Pic: http:\/\/t.co\/1wp4Etsl",
  "id" : 299676954343374849,
  "created_at" : "2013-02-08 00:32:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/299646217774825473\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/Xhqb6INZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCiOpcFCAAAAdQI.jpg",
      "id_str" : "299646217783214080",
      "id" : 299646217783214080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCiOpcFCAAAAdQI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/Xhqb6INZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/3xwULiSP",
      "expanded_url" : "http:\/\/on.wh.gov\/C20lE3P",
      "display_url" : "on.wh.gov\/C20lE3P"
    } ]
  },
  "geo" : { },
  "id_str" : "299646217774825473",
  "text" : "Today, President Obama addressed the National Prayer Breakfast in Washington, DC: http:\/\/t.co\/3xwULiSP Pic: http:\/\/t.co\/Xhqb6INZ",
  "id" : 299646217774825473,
  "created_at" : "2013-02-07 22:30:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/299331689140858880\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/MLS04fY0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCdwldmCMAAg-Oi.jpg",
      "id_str" : "299331689145053184",
      "id" : 299331689145053184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCdwldmCMAAg-Oi.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MLS04fY0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299331689140858880",
  "text" : "Photo of the Day: President Obama travels aboard Marine One from Annapolis, Md., en route to the White House: http:\/\/t.co\/MLS04fY0",
  "id" : 299331689140858880,
  "created_at" : "2013-02-07 01:40:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 75, 84 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/UVqeus7C",
      "expanded_url" : "http:\/\/at.wh.gov\/hurtD",
      "display_url" : "at.wh.gov\/hurtD"
    } ]
  },
  "geo" : { },
  "id_str" : "299314219952783361",
  "text" : "Today, President Obama nominated Sally Jewell as the next Secretary of the @Interior: http:\/\/t.co\/UVqeus7C",
  "id" : 299314219952783361,
  "created_at" : "2013-02-07 00:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baltimore Ravens",
      "screen_name" : "Ravens",
      "indices" : [ 63, 70 ],
      "id_str" : "22146282",
      "id" : 22146282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Superbowl",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/DlpH2T3n",
      "expanded_url" : "http:\/\/youtu.be\/T6qJyMvhTP0",
      "display_url" : "youtu.be\/T6qJyMvhTP0"
    } ]
  },
  "geo" : { },
  "id_str" : "299282106650091520",
  "text" : "Behind-the-scenes video: President Obama calls to congratulate @Ravens Coach John Harbaugh on their #Superbowl victory: http:\/\/t.co\/DlpH2T3n",
  "id" : 299282106650091520,
  "created_at" : "2013-02-06 22:23:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 87, 97 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "299254638237069312",
  "text" : "RT @VP: Today, the VP will administer the oath of office at a swearing-in ceremony for @StateDept Sec. Kerry. Watch at 4 PM ET: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 79, 89 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/e73UozAH",
        "expanded_url" : "http:\/\/video.state.gov\/live",
        "display_url" : "video.state.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "299251698562650112",
    "text" : "Today, the VP will administer the oath of office at a swearing-in ceremony for @StateDept Sec. Kerry. Watch at 4 PM ET: http:\/\/t.co\/e73UozAH",
    "id" : 299251698562650112,
    "created_at" : "2013-02-06 20:22:19 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 299254638237069312,
  "created_at" : "2013-02-06 20:34:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 45, 56 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 32, 37 ]
    }, {
      "text" : "WHSocial",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/H4Zay3XA",
      "expanded_url" : "http:\/\/at.wh.gov\/htZBQ",
      "display_url" : "at.wh.gov\/htZBQ"
    } ]
  },
  "geo" : { },
  "id_str" : "299245765023379456",
  "text" : "Don't miss your chance to watch #SOTU at the @WhiteHouse. Registration for the latest #WHSocial ends today at 6ET: http:\/\/t.co\/H4Zay3XA",
  "id" : 299245765023379456,
  "created_at" : "2013-02-06 19:58:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/KJZX7tLG",
      "expanded_url" : "http:\/\/at.wh.gov\/htSBk",
      "display_url" : "at.wh.gov\/htSBk"
    } ]
  },
  "geo" : { },
  "id_str" : "299232680103538689",
  "text" : "Happening now: President Obama makes a personnel announcement. Watch: http:\/\/t.co\/KJZX7tLG",
  "id" : 299232680103538689,
  "created_at" : "2013-02-06 19:06:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/Rje8XNrk",
      "expanded_url" : "http:\/\/blogs.nasa.gov\/cm\/blog\/nasadotgov\/posts\/post_1360093494762.html",
      "display_url" : "blogs.nasa.gov\/cm\/blog\/nasado\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "299228538123464705",
  "text" : "RT @macon44: \u201CCompared to similar periods, NASA saw a 1,400% increase in Spot the Station site usage.\u201D http:\/\/t.co\/Rje8XNrk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/Rje8XNrk",
        "expanded_url" : "http:\/\/blogs.nasa.gov\/cm\/blog\/nasadotgov\/posts\/post_1360093494762.html",
        "display_url" : "blogs.nasa.gov\/cm\/blog\/nasado\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "299226140667674625",
    "text" : "\u201CCompared to similar periods, NASA saw a 1,400% increase in Spot the Station site usage.\u201D http:\/\/t.co\/Rje8XNrk",
    "id" : 299226140667674625,
    "created_at" : "2013-02-06 18:40:45 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 299228538123464705,
  "created_at" : "2013-02-06 18:50:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "299179463688740864",
  "text" : "Today at 2 ET: President Obama makes a personnel announcement from the White House. Watch live: http:\/\/t.co\/u95tzH8r",
  "id" : 299179463688740864,
  "created_at" : "2013-02-06 15:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/298969034274242561\/photo\/1",
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/DpTiCiVq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCYmwK-CAAAOiov.jpg",
      "id_str" : "298969034286825472",
      "id" : 298969034286825472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCYmwK-CAAAOiov.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DpTiCiVq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298969034274242561",
  "text" : "Photo of the Day: President Obama meets with speechwriters Cody Keenan and Jon Favreau in the Oval Office: http:\/\/t.co\/DpTiCiVq",
  "id" : 298969034274242561,
  "created_at" : "2013-02-06 01:39:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "WHSocial",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/T9Q5lQLd",
      "expanded_url" : "http:\/\/at.wh.gov\/hrZ1h",
      "display_url" : "at.wh.gov\/hrZ1h"
    } ]
  },
  "geo" : { },
  "id_str" : "298910887811633153",
  "text" : "Want to watch #SOTU live at the @Whitehouse? Apply to attend our latest #WHSocial: http:\/\/t.co\/T9Q5lQLd",
  "id" : 298910887811633153,
  "created_at" : "2013-02-05 21:48:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 118, 130 ],
      "id_str" : "14224719",
      "id" : 14224719
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298878971980955648",
  "text" : "RT @VP: PHOTO: VP arrives at 10 Downing St. in London to meet w\/ British PM Cameron &amp; Deputy PM Clegg. (WH Photo) @Number10gov http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UK Prime Minister",
        "screen_name" : "Number10gov",
        "indices" : [ 110, 122 ],
        "id_str" : "14224719",
        "id" : 14224719
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/298875750373810178\/photo\/1",
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/CE7zznUi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BCXR6VWCYAE8ZDY.jpg",
        "id_str" : "298875750382198785",
        "id" : 298875750382198785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCXR6VWCYAE8ZDY.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CE7zznUi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298875750373810178",
    "text" : "PHOTO: VP arrives at 10 Downing St. in London to meet w\/ British PM Cameron &amp; Deputy PM Clegg. (WH Photo) @Number10gov http:\/\/t.co\/CE7zznUi",
    "id" : 298875750373810178,
    "created_at" : "2013-02-05 19:28:26 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 298878971980955648,
  "created_at" : "2013-02-05 19:41:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "298857875932065792",
  "text" : "Happening now: President Obama delivers a statement on the need for a balanced approach for deficit reduction. Watch: http:\/\/t.co\/u95tzH8r",
  "id" : 298857875932065792,
  "created_at" : "2013-02-05 18:17:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Innovation",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298844679292727296",
  "text" : "RT @whitehouseostp: Throw your hat in the ring...applications for 2nd class of Presidential #Innovation Fellows are now open! http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Innovation",
        "indices" : [ 72, 83 ]
      }, {
        "text" : "opengov",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/1gecEJge",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/02\/05\/throw-your-hat-ring-round-2-presidential-innovation-fellows-program",
        "display_url" : "whitehouse.gov\/blog\/2013\/02\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "298795971175919616",
    "text" : "Throw your hat in the ring...applications for 2nd class of Presidential #Innovation Fellows are now open! http:\/\/t.co\/1gecEJge #opengov",
    "id" : 298795971175919616,
    "created_at" : "2013-02-05 14:11:25 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 298844679292727296,
  "created_at" : "2013-02-05 17:24:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "298819935512170497",
  "text" : "At 1:15 ET: President Obama will call on Congress to act to avoid the sequester &amp; reduce the deficit in a balanced way: http:\/\/t.co\/u95tzH8r",
  "id" : 298819935512170497,
  "created_at" : "2013-02-05 15:46:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/EJ28pjB8",
      "expanded_url" : "http:\/\/on.wh.gov\/992xRVU",
      "display_url" : "on.wh.gov\/992xRVU"
    }, {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/iTlQq5r8",
      "expanded_url" : "http:\/\/on.wh.gov\/aZLBKal",
      "display_url" : "on.wh.gov\/aZLBKal"
    } ]
  },
  "geo" : { },
  "id_str" : "298755366538326016",
  "text" : "President Obama's message to the people of Kenya on their upcoming elections: http:\/\/t.co\/EJ28pjB8 Watch: http:\/\/t.co\/iTlQq5r8",
  "id" : 298755366538326016,
  "created_at" : "2013-02-05 11:30:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/nDQZNioQ",
      "expanded_url" : "http:\/\/on.wh.gov\/JVQ1huj",
      "display_url" : "on.wh.gov\/JVQ1huj"
    } ]
  },
  "geo" : { },
  "id_str" : "298638605407096832",
  "text" : "\"We don't have to agree on everything to agree it's time to do something.\" -President Obama on reducing gun violence: http:\/\/t.co\/nDQZNioQ",
  "id" : 298638605407096832,
  "created_at" : "2013-02-05 03:46:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/298606895076347904\/photo\/1",
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/rRn7f0nR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCTdY5UCEAA55fY.jpg",
      "id_str" : "298606895084736512",
      "id" : 298606895084736512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCTdY5UCEAA55fY.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rRn7f0nR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298606895076347904",
  "text" : "Photo of the Day: President Obama high fives a youngster Minneapolis-St. Paul International Airport: http:\/\/t.co\/rRn7f0nR",
  "id" : 298606895076347904,
  "created_at" : "2013-02-05 01:40:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/298578333325725696\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/jgLiPgAt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCTDaYgCEAAiVZB.jpg",
      "id_str" : "298578333334114304",
      "id" : 298578333334114304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCTDaYgCEAAiVZB.jpg",
      "sizes" : [ {
        "h" : 380,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jgLiPgAt"
    } ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/04zOJHxS",
      "expanded_url" : "http:\/\/on.wh.gov\/WZaTesl",
      "display_url" : "on.wh.gov\/WZaTesl"
    } ]
  },
  "geo" : { },
  "id_str" : "298578333325725696",
  "text" : "Today, the President met w\/ law enforcement &amp; spoke on reducing gun violence in MN: http:\/\/t.co\/04zOJHxS #NowIsTheTime http:\/\/t.co\/jgLiPgAt",
  "id" : 298578333325725696,
  "created_at" : "2013-02-04 23:46:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/298551767820550144\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/KpmgHFiO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCSrQESCQAAPNFz.jpg",
      "id_str" : "298551767828938752",
      "id" : 298551767828938752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCSrQESCQAAPNFz.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KpmgHFiO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298551767820550144",
  "text" : "Photo of the Day: President Obama before a ceremony to honor recipients of science, technology &amp; innovation medals: http:\/\/t.co\/KpmgHFiO",
  "id" : 298551767820550144,
  "created_at" : "2013-02-04 22:01:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298521919911780352",
  "text" : "RT @WHLive: President Obama: \"It may not be the perfect solution; we may not save every life; but we can make a difference.\" #NowIsTheTime",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 113, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298521762990276609",
    "text" : "President Obama: \"It may not be the perfect solution; we may not save every life; but we can make a difference.\" #NowIsTheTime",
    "id" : 298521762990276609,
    "created_at" : "2013-02-04 20:01:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 298521919911780352,
  "created_at" : "2013-02-04 20:02:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 49, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298521897954594816",
  "text" : "President Obama: \"Tell [your Member of Congress] #NowIsTheTime for action \u2013 we're not going to wait until after the next Newtown\"",
  "id" : 298521897954594816,
  "created_at" : "2013-02-04 20:02:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298521379047882752",
  "text" : "RT @WHLive: President Obama: \"That\u2019s why I need everyone listening to keep the pressure on your Members of Congress to do the right thin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298521157223710720",
    "text" : "President Obama: \"That\u2019s why I need everyone listening to keep the pressure on your Members of Congress to do the right thing\" #NowIsTheTime",
    "id" : 298521157223710720,
    "created_at" : "2013-02-04 19:59:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 298521379047882752,
  "created_at" : "2013-02-04 20:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298521128324972544",
  "text" : "\"The only way we can reduce gun violence in this country is if the American people decide it\u2019s important.\" \u2014President Obama #NowIsTheTime",
  "id" : 298521128324972544,
  "created_at" : "2013-02-04 19:59:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298520002263388160",
  "text" : "RT @WHLive: President Obama: \"The vast majority of Americans \u2013 including a majority of gun owners \u2013 support requiring criminal backgroun ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298519763917881344",
    "text" : "President Obama: \"The vast majority of Americans \u2013 including a majority of gun owners \u2013 support requiring criminal background checks\"",
    "id" : 298519763917881344,
    "created_at" : "2013-02-04 19:53:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 298520002263388160,
  "created_at" : "2013-02-04 19:54:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298519478906531840",
  "text" : "RT @WHLive: President Obama: \"If there\u2019s even one thing we can do \u2013 even one life we can save \u2013 we have an obligation to try.\" #NowIsTheTime",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowIsTheTime",
        "indices" : [ 115, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298519238547750913",
    "text" : "President Obama: \"If there\u2019s even one thing we can do \u2013 even one life we can save \u2013 we have an obligation to try.\" #NowIsTheTime",
    "id" : 298519238547750913,
    "created_at" : "2013-02-04 19:51:47 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 298519478906531840,
  "created_at" : "2013-02-04 19:52:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "298517372061499393",
  "text" : "Happening now: President Obama speaks on reducing gun violence from Minneapolis, MN. Watch live: http:\/\/t.co\/u95tzH8r #NowIsTheTime",
  "id" : 298517372061499393,
  "created_at" : "2013-02-04 19:44:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "glo flacco",
      "screen_name" : "TeamFlacco",
      "indices" : [ 120, 131 ],
      "id_str" : "753484945469747200",
      "id" : 753484945469747200
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298465972656959488",
  "text" : "RT @VP: Joe, congrats on the Superbowl ring and MVP. Coach Tubby and Blue Hens everywhere are proud. Including me. \u2013VP  @TeamFlacco",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "glo flacco",
        "screen_name" : "TeamFlacco",
        "indices" : [ 112, 123 ],
        "id_str" : "753484945469747200",
        "id" : 753484945469747200
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298465735477432321",
    "text" : "Joe, congrats on the Superbowl ring and MVP. Coach Tubby and Blue Hens everywhere are proud. Including me. \u2013VP  @TeamFlacco",
    "id" : 298465735477432321,
    "created_at" : "2013-02-04 16:19:11 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 298465972656959488,
  "created_at" : "2013-02-04 16:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nowisthetime",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "298464176500776960",
  "text" : "Today at 2:30ET: President Obama speaks on reducing gun violence from Minneapolis, MN. Watch live: http:\/\/t.co\/u95tzH8r #nowisthetime",
  "id" : 298464176500776960,
  "created_at" : "2013-02-04 16:12:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 50, 60 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecKerry",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298443101821874176",
  "text" : "RT @StateDept: #SecKerry will start tweeting from @StateDept. Tweets from him will have his initials -JK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 35, 45 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecKerry",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298433014776623104",
    "text" : "#SecKerry will start tweeting from @StateDept. Tweets from him will have his initials -JK",
    "id" : 298433014776623104,
    "created_at" : "2013-02-04 14:09:09 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 298443101821874176,
  "created_at" : "2013-02-04 14:49:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Baltimore Ravens",
      "screen_name" : "Ravens",
      "indices" : [ 40, 47 ],
      "id_str" : "22146282",
      "id" : 22146282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298277341711437825",
  "text" : "RT @FLOTUS: Great game! Congrats to the @Ravens. See you at the White House! -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Baltimore Ravens",
        "screen_name" : "Ravens",
        "indices" : [ 28, 35 ],
        "id_str" : "22146282",
        "id" : 22146282
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298277038782038017",
    "text" : "Great game! Congrats to the @Ravens. See you at the White House! -mo",
    "id" : 298277038782038017,
    "created_at" : "2013-02-04 03:49:22 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 298277341711437825,
  "created_at" : "2013-02-04 03:50:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "BEYONC\u00C9",
      "screen_name" : "Beyonce",
      "indices" : [ 63, 71 ],
      "id_str" : "31239408",
      "id" : 31239408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SuperBowl",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298241029667164161",
  "text" : "RT @FLOTUS: Watching the #SuperBowl with family &amp; friends. @Beyonce was phenomenal! I am so proud of her! -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BEYONC\u00C9",
        "screen_name" : "Beyonce",
        "indices" : [ 51, 59 ],
        "id_str" : "31239408",
        "id" : 31239408
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SuperBowl",
        "indices" : [ 13, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298240788943499267",
    "text" : "Watching the #SuperBowl with family &amp; friends. @Beyonce was phenomenal! I am so proud of her! -mo",
    "id" : 298240788943499267,
    "created_at" : "2013-02-04 01:25:19 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 298241029667164161,
  "created_at" : "2013-02-04 01:26:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/298192234946383873\/photo\/1",
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/5v2W4Xdo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCNkQf8CUAECwcU.jpg",
      "id_str" : "298192234950578177",
      "id" : 298192234950578177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCNkQf8CUAECwcU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 707,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1325,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5v2W4Xdo"
    } ],
    "hashtags" : [ {
      "text" : "SuperBowl",
      "indices" : [ 6, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298192234946383873",
  "text" : "Happy #SuperBowl Sunday! http:\/\/t.co\/5v2W4Xdo",
  "id" : 298192234946383873,
  "created_at" : "2013-02-03 22:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 3, 15 ],
      "id_str" : "59204932",
      "id" : 59204932
    }, {
      "name" : "Mayor Rawlings-Blake",
      "screen_name" : "MayorSRB",
      "indices" : [ 72, 81 ],
      "id_str" : "109328493",
      "id" : 109328493
    }, {
      "name" : "Mayor Ed Lee",
      "screen_name" : "mayoredlee",
      "indices" : [ 88, 99 ],
      "id_str" : "234489403",
      "id" : 234489403
    }, {
      "name" : "Super Bowl",
      "screen_name" : "SuperBowl",
      "indices" : [ 116, 126 ],
      "id_str" : "19425947",
      "id" : 19425947
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ServiceBowl",
      "indices" : [ 17, 29 ]
    }, {
      "text" : "volunteer",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298178497233420290",
  "text" : "RT @ServeDotGov: #ServiceBowl 2013 - Get off the sidelines &amp; serve! @MayorSRB &amp; @MayorEdLee make #volunteer @Superbowl bet http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mayor Rawlings-Blake",
        "screen_name" : "MayorSRB",
        "indices" : [ 55, 64 ],
        "id_str" : "109328493",
        "id" : 109328493
      }, {
        "name" : "Mayor Ed Lee",
        "screen_name" : "mayoredlee",
        "indices" : [ 71, 82 ],
        "id_str" : "234489403",
        "id" : 234489403
      }, {
        "name" : "Super Bowl",
        "screen_name" : "SuperBowl",
        "indices" : [ 99, 109 ],
        "id_str" : "19425947",
        "id" : 19425947
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ServiceBowl",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "volunteer",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/NaTdteAu",
        "expanded_url" : "http:\/\/ow.ly\/hkNbs",
        "display_url" : "ow.ly\/hkNbs"
      } ]
    },
    "geo" : { },
    "id_str" : "297378547566252033",
    "text" : "#ServiceBowl 2013 - Get off the sidelines &amp; serve! @MayorSRB &amp; @MayorEdLee make #volunteer @Superbowl bet http:\/\/t.co\/NaTdteAu",
    "id" : 297378547566252033,
    "created_at" : "2013-02-01 16:19:05 +0000",
    "user" : {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "protected" : false,
      "id_str" : "59204932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1119135330\/serve_normal.JPG",
      "id" : 59204932,
      "verified" : true
    }
  },
  "id" : 298178497233420290,
  "created_at" : "2013-02-03 21:17:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298130236472709123",
  "text" : "RT @PressSec: Obama: \"2013 can be a year of solid growth...will only happen if we put a stop to self-inflicted wounds in Washington\" htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/YW8PImIZ",
        "expanded_url" : "http:\/\/youtu.be\/7P_3WDJe5QY",
        "display_url" : "youtu.be\/7P_3WDJe5QY"
      } ]
    },
    "geo" : { },
    "id_str" : "297768692232642560",
    "text" : "Obama: \"2013 can be a year of solid growth...will only happen if we put a stop to self-inflicted wounds in Washington\" http:\/\/t.co\/YW8PImIZ",
    "id" : 297768692232642560,
    "created_at" : "2013-02-02 18:09:23 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 298130236472709123,
  "created_at" : "2013-02-03 18:06:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298127127717494784",
  "text" : "RT @VP: VP &amp; Dr. Biden talk with medical staff today during a visit to Landstuhl Regional Medical Center in Germany. (WH Photo) http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/EQPUpeII",
        "expanded_url" : "http:\/\/www.flickr.com\/photos\/whitehouse\/8440916837\/in\/photostream",
        "display_url" : "flickr.com\/photos\/whiteho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "298126754986467328",
    "text" : "VP &amp; Dr. Biden talk with medical staff today during a visit to Landstuhl Regional Medical Center in Germany. (WH Photo) http:\/\/t.co\/EQPUpeII",
    "id" : 298126754986467328,
    "created_at" : "2013-02-03 17:52:11 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 298127127717494784,
  "created_at" : "2013-02-03 17:53:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 91, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/n396SJnL",
      "expanded_url" : "http:\/\/wh.gov\/pqMo",
      "display_url" : "wh.gov\/pqMo"
    } ]
  },
  "geo" : { },
  "id_str" : "297804268243668992",
  "text" : "\"Let us honor those who came before by striving toward their example.\" -President Obama on #BlackHistoryMonth: http:\/\/t.co\/n396SJnL",
  "id" : 297804268243668992,
  "created_at" : "2013-02-02 20:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/gTLeVIqu",
      "expanded_url" : "http:\/\/at.wh.gov\/hmnTz",
      "display_url" : "at.wh.gov\/hmnTz"
    } ]
  },
  "geo" : { },
  "id_str" : "297749766719275008",
  "text" : "\"Everyone in Washington needs to focus not on politics but on what\u2019s right for the country\" \u2014President Obama in Weekly: http:\/\/t.co\/gTLeVIqu",
  "id" : 297749766719275008,
  "created_at" : "2013-02-02 16:54:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "potinleftgrog1",
      "screen_name" : "Mayor_Smith",
      "indices" : [ 53, 65 ],
      "id_str" : "2982225435",
      "id" : 2982225435
    }, {
      "name" : "Charlie Baker",
      "screen_name" : "MassGovernor",
      "indices" : [ 66, 79 ],
      "id_str" : "18023868",
      "id" : 18023868
    }, {
      "name" : "Ashley Swearengin",
      "screen_name" : "MayorSwearengin",
      "indices" : [ 80, 96 ],
      "id_str" : "15672761",
      "id" : 15672761
    }, {
      "name" : "Governor Pat Quinn",
      "screen_name" : "GovernorQuinn",
      "indices" : [ 97, 111 ],
      "id_str" : "243271477",
      "id" : 243271477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 33, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/WZD7ezds",
      "expanded_url" : "http:\/\/wh.gov\/V7rf",
      "display_url" : "wh.gov\/V7rf"
    } ]
  },
  "geo" : { },
  "id_str" : "297519756825743360",
  "text" : "State officials urging action on #ImmigrationReform: @Mayor_smith @MassGovernor @MayorSwearengin @GovernorQuinn &amp; more: http:\/\/t.co\/WZD7ezds",
  "id" : 297519756825743360,
  "created_at" : "2013-02-02 01:40:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boys & Girls Clubs",
      "screen_name" : "BGCA_Clubs",
      "indices" : [ 76, 87 ],
      "id_str" : "28585586",
      "id" : 28585586
    }, {
      "name" : "Miami HEAT",
      "screen_name" : "MiamiHEAT",
      "indices" : [ 104, 114 ],
      "id_str" : "11026952",
      "id" : 11026952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 49, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/MlaszrJv",
      "expanded_url" : "http:\/\/wh.gov\/VhlR",
      "display_url" : "wh.gov\/VhlR"
    } ]
  },
  "geo" : { },
  "id_str" : "297502232042164224",
  "text" : "This week at 1600 Penn: President Obama spoke on #ImmigrationReform, met w\/ @BGCA_Clubs youth &amp; the @MiamiHeat. Watch: http:\/\/t.co\/MlaszrJv",
  "id" : 297502232042164224,
  "created_at" : "2013-02-02 00:30:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/297491555613302784\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/E9cZxXJh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BCDm_mBCYAAEmyK.jpg",
      "id_str" : "297491555617497088",
      "id" : 297491555617497088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BCDm_mBCYAAEmyK.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/E9cZxXJh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/GCLfKhm8",
      "expanded_url" : "http:\/\/on.wh.gov\/knPkVBs",
      "display_url" : "on.wh.gov\/knPkVBs"
    } ]
  },
  "geo" : { },
  "id_str" : "297491555613302784",
  "text" : "Today marks the 100th Anniversary of Rosa Parks' birth: http:\/\/t.co\/GCLfKhm8 Photo: President Obama sits on her bus: http:\/\/t.co\/E9cZxXJh",
  "id" : 297491555613302784,
  "created_at" : "2013-02-01 23:48:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 17, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297457226292027392",
  "text" : "RT @FLOTUS: This #BlackHistoryMonth, let\u2019s honor the legacy of those who came before us by taking action for our next generation. \u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackHistoryMonth",
        "indices" : [ 5, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "297457079315230721",
    "text" : "This #BlackHistoryMonth, let\u2019s honor the legacy of those who came before us by taking action for our next generation. \u2013mo",
    "id" : 297457079315230721,
    "created_at" : "2013-02-01 21:31:08 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 297457226292027392,
  "created_at" : "2013-02-01 21:31:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 93, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/n396SJnL",
      "expanded_url" : "http:\/\/wh.gov\/pqMo",
      "display_url" : "wh.gov\/pqMo"
    } ]
  },
  "geo" : { },
  "id_str" : "297453142663114753",
  "text" : "\"We live in a moment when the dream of equal opportunity is within reach\"-President Obama on #BlackHistoryMonth: http:\/\/t.co\/n396SJnL",
  "id" : 297453142663114753,
  "created_at" : "2013-02-01 21:15:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/iuZoRNFf",
      "expanded_url" : "http:\/\/wh.gov\/pq6P",
      "display_url" : "wh.gov\/pq6P"
    } ]
  },
  "geo" : { },
  "id_str" : "297444439775911936",
  "text" : "RT @pfeiffer44: More than 6.1 million private sector jobs were created in the past 35 months; more work to do: http:\/\/t.co\/iuZoRNFf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/iuZoRNFf",
        "expanded_url" : "http:\/\/wh.gov\/pq6P",
        "display_url" : "wh.gov\/pq6P"
      } ]
    },
    "geo" : { },
    "id_str" : "297430301527908353",
    "text" : "More than 6.1 million private sector jobs were created in the past 35 months; more work to do: http:\/\/t.co\/iuZoRNFf",
    "id" : 297430301527908353,
    "created_at" : "2013-02-01 19:44:44 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 297444439775911936,
  "created_at" : "2013-02-01 20:40:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 127, 147 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "297420977107763200",
  "text" : "Starting soon: President Obama awards the National Medals of Science &amp; the National Medals of Technology &amp; Innovation: http:\/\/t.co\/u95tzH8r",
  "id" : 297420977107763200,
  "created_at" : "2013-02-01 19:07:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]