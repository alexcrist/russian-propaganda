Grailbird.data.tweets_2011_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32220234203004928",
  "text" : "Busy this Fall? Application to be a Fall WH intern just went up, clear your schedule http:\/\/wh.gov\/internship",
  "id" : 32220234203004928,
  "created_at" : "2011-01-31 23:34:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 68, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32195543849500672",
  "text" : "\"Judicial Activism and the Affordable Care Act\" http:\/\/is.gd\/Y06qta #hcr",
  "id" : 32195543849500672,
  "created_at" : "2011-01-31 21:56:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32105395518439424",
  "text" : "11AM: Launch of Startup America w\/ Austan Goolsbee & others, new package to help entrepreneurs. Watch: http:\/\/wh.gov\/live",
  "id" : 32105395518439424,
  "created_at" : "2011-01-31 15:58:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EMHE",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31903477366001665",
  "text" : "RT @RayLaHood: We've got more from the family of Alex Brown tonight directly after Extreme Home Makeover! #EMHE http:\/\/bit.ly\/i4ZA6d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EMHE",
        "indices" : [ 91, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "31881965028245505",
    "text" : "We've got more from the family of Alex Brown tonight directly after Extreme Home Makeover! #EMHE http:\/\/bit.ly\/i4ZA6d",
    "id" : 31881965028245505,
    "created_at" : "2011-01-31 01:10:27 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 31903477366001665,
  "created_at" : "2011-01-31 02:35:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31758373355524096",
  "text" : "RT @pfeiffer44: Jeff Zients to head effort to reform and reorganize govt -- key part of President's plan to win the future.  http:\/\/goo. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "31751293533954048",
    "text" : "Jeff Zients to head effort to reform and reorganize govt -- key part of President's plan to win the future.  http:\/\/goo.gl\/bo3rM",
    "id" : 31751293533954048,
    "created_at" : "2011-01-30 16:31:12 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 31758373355524096,
  "created_at" : "2011-01-30 16:59:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 35, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31443638860914689",
  "text" : "VIDEO of President Obama's stmt re #Egypt: http:\/\/goo.gl\/bQdaw - \"Violence will not address the grievances of the Egyptian people.\"",
  "id" : 31443638860914689,
  "created_at" : "2011-01-29 20:08:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31158676710494208",
  "text" : "President Obama on the phone with President Hosni Mubarak of Egypt in the Oval Office, VP Biden listens  http:\/\/twitpic.com\/3ubl1u",
  "id" : 31158676710494208,
  "created_at" : "2011-01-29 01:16:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31152728134656000",
  "text" : "President Obama calls on Egypt to \"reverse the actions that they\u2019ve taken to interfere with access to the Internet\" http:\/\/is.gd\/RTBYyY",
  "id" : 31152728134656000,
  "created_at" : "2011-01-29 00:52:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31152462622629888",
  "text" : "President Obama: \"All governments must maintain power through consent, not coercion\" http:\/\/is.gd\/RTBYyY #Egypt",
  "id" : 31152462622629888,
  "created_at" : "2011-01-29 00:51:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31132916016746496",
  "text" : "Happening Now: The President delivers a statement on Egypt http:\/\/www.wh.gov\/live",
  "id" : 31132916016746496,
  "created_at" : "2011-01-28 23:34:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31076467907493888",
  "text" : "RT @petesouza: Photo of President discussing situation in Egypt with his national security team: http:\/\/bit.ly\/i0FlMj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "31041140580950016",
    "text" : "Photo of President discussing situation in Egypt with his national security team: http:\/\/bit.ly\/i0FlMj",
    "id" : 31041140580950016,
    "created_at" : "2011-01-28 17:29:19 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 31076467907493888,
  "created_at" : "2011-01-28 19:49:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maybenexttime",
      "screen_name" : "1ideaatatime",
      "indices" : [ 1, 14 ],
      "id_str" : "108494073",
      "id" : 108494073
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 47, 51 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "31073476076900352",
  "geo" : { },
  "id_str" : "31075095111802880",
  "in_reply_to_user_id" : 108494073,
  "text" : ".@1ideaatatime The President certainly agrees, #hcr strengthens Medicare, closes Rx coverage gap, improves benefits http:\/\/bit.ly\/b0NFxl",
  "id" : 31075095111802880,
  "in_reply_to_status_id" : 31073476076900352,
  "created_at" : "2011-01-28 19:44:14 +0000",
  "in_reply_to_screen_name" : "1ideaatatime",
  "in_reply_to_user_id_str" : "108494073",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maddie Clarke",
      "screen_name" : "MMClarke",
      "indices" : [ 1, 10 ],
      "id_str" : "423045616",
      "id" : 423045616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31072950887129088",
  "text" : ".@mmclarke Middle class tax credits, more affordable options, ending hidden $1K tax of uncompensated care. More here: http:\/\/bit.ly\/hYUE70",
  "id" : 31072950887129088,
  "created_at" : "2011-01-28 19:35:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TabbieWolf",
      "screen_name" : "tabbiewolf",
      "indices" : [ 1, 12 ],
      "id_str" : "8835722",
      "id" : 8835722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "31070143773679616",
  "geo" : { },
  "id_str" : "31071457488404481",
  "in_reply_to_user_id" : 8835722,
  "text" : ".@tabbiewolf 2014: You'll have better more affordable options. Check http:\/\/hc.gov to make sure you're getting best deal now.",
  "id" : 31071457488404481,
  "in_reply_to_status_id" : 31070143773679616,
  "created_at" : "2011-01-28 19:29:47 +0000",
  "in_reply_to_screen_name" : "tabbiewolf",
  "in_reply_to_user_id_str" : "8835722",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TabbieWolf",
      "screen_name" : "tabbiewolf",
      "indices" : [ 1, 12 ],
      "id_str" : "8835722",
      "id" : 8835722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "31070143773679616",
  "geo" : { },
  "id_str" : "31071085109714944",
  "in_reply_to_user_id" : 8835722,
  "text" : ".@tabbiewolf Now: Ins. companies can no longer raise rates by double digits w\/out accountability, 80% of premiums must go to care not profit",
  "id" : 31071085109714944,
  "in_reply_to_status_id" : 31070143773679616,
  "created_at" : "2011-01-28 19:28:18 +0000",
  "in_reply_to_screen_name" : "tabbiewolf",
  "in_reply_to_user_id_str" : "8835722",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 10, 14 ]
    }, {
      "text" : "hcr",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31069290388000769",
  "text" : "Voices of #HCR: Kayla is 1 of 1.2M young adults who can stay on parents\u2019 plan http:\/\/bit.ly\/hIYOX1 Taking your Qs on #hcr\u2026 now",
  "id" : 31069290388000769,
  "created_at" : "2011-01-28 19:21:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31031437230604288",
  "text" : "RT @PressSec: Very concerned about violence in Egypt - government must respect the rights of the Egyptian people & turn on social networ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "31026478648926208",
    "text" : "Very concerned about violence in Egypt - government must respect the rights of the Egyptian people & turn on social networking and internet",
    "id" : 31026478648926208,
    "created_at" : "2011-01-28 16:31:03 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 31031437230604288,
  "created_at" : "2011-01-28 16:50:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "31006434070106112",
  "text" : "Watch Live: President Obama addresses Families USA conference on #hcr at 10:15 ET http:\/\/bit.ly\/gSsmJH",
  "id" : 31006434070106112,
  "created_at" : "2011-01-28 15:11:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30826405730193408",
  "text" : "RT @pfeiffer44: Lots of questions on Egypt tonight.  POTUS discussed it today during an interview with YouTube. http:\/\/goo.gl\/D9c8U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "30825570887536640",
    "text" : "Lots of questions on Egypt tonight.  POTUS discussed it today during an interview with YouTube. http:\/\/goo.gl\/D9c8U",
    "id" : 30825570887536640,
    "created_at" : "2011-01-28 03:12:43 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 30826405730193408,
  "created_at" : "2011-01-28 03:16:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30724617731571713",
  "text" : "3rd out of 4: Education online chat via Facebook with Secretary Duncan now: http:\/\/is.gd\/vaeb96",
  "id" : 30724617731571713,
  "created_at" : "2011-01-27 20:31:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 48, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30706458509185024",
  "text" : "2:30EST: President Obama\u2019s YouTube interview on #SOTU. You asked, you voted, now watch live: http:\/\/wh.gov\/live",
  "id" : 30706458509185024,
  "created_at" : "2011-01-27 19:19:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30656443036213248",
  "text" : "All day: 4 Facebook live chats w\/ our policy gurus & 1 YouTube interview with the President. Schedule: http:\/\/wh.gov\/live",
  "id" : 30656443036213248,
  "created_at" : "2011-01-27 16:00:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 29, 39 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 46, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30385911099293696",
  "text" : "Great new photo gallery from @petesouza & Co: #SOTU http:\/\/is.gd\/vLP3GT",
  "id" : 30385911099293696,
  "created_at" : "2011-01-26 22:05:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TeachGov",
      "screen_name" : "teachgov",
      "indices" : [ 3, 12 ],
      "id_str" : "1685994038",
      "id" : 1685994038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 14, 20 ]
    }, {
      "text" : "STEM",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "jobs",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30382976768413697",
  "text" : "RT @TEACHgov: #Obama discussed the goal of recruiting 100K #STEM teachers. Over 8,500 #jobs @ http:\/\/www.teach.gov\/ \u2013 is one yours?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "STEM",
        "indices" : [ 45, 50 ]
      }, {
        "text" : "jobs",
        "indices" : [ 72, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "30346689063690240",
    "text" : "#Obama discussed the goal of recruiting 100K #STEM teachers. Over 8,500 #jobs @ http:\/\/www.teach.gov\/ \u2013 is one yours?",
    "id" : 30346689063690240,
    "created_at" : "2011-01-26 19:29:49 +0000",
    "user" : {
      "name" : "TEACHorg",
      "screen_name" : "TEACHorg",
      "protected" : false,
      "id_str" : "134234059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459769392264269824\/yCwcgBJe_normal.png",
      "id" : 134234059,
      "verified" : false
    }
  },
  "id" : 30382976768413697,
  "created_at" : "2011-01-26 21:54:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "jobs",
      "indices" : [ 65, 70 ]
    }, {
      "text" : "hcr",
      "indices" : [ 71, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30366880568967169",
  "text" : "We're hosting a conf call w\/ young Americans tonight. Talk #sotu #jobs #hcr w\/ David Plouffe. RSVP: http:\/\/www.wh.gov\/youthcall",
  "id" : 30366880568967169,
  "created_at" : "2011-01-26 20:50:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Joel Sax",
      "screen_name" : "EmperorNorton",
      "indices" : [ 17, 31 ],
      "id_str" : "2719961",
      "id" : 2719961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30350325722386433",
  "text" : "RT @pfeiffer44: .@EmperorNorton POTUS strongly opposes privatization",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joel Sax",
        "screen_name" : "EmperorNorton",
        "indices" : [ 1, 15 ],
        "id_str" : "2719961",
        "id" : 2719961
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "30348228692017154",
    "geo" : { },
    "id_str" : "30349154324578304",
    "in_reply_to_user_id" : 2719961,
    "text" : ".@EmperorNorton POTUS strongly opposes privatization",
    "id" : 30349154324578304,
    "in_reply_to_status_id" : 30348228692017154,
    "created_at" : "2011-01-26 19:39:36 +0000",
    "in_reply_to_screen_name" : "EmperorNorton",
    "in_reply_to_user_id_str" : "2719961",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 30350325722386433,
  "created_at" : "2011-01-26 19:44:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Rich Farmer",
      "screen_name" : "Searching4Par",
      "indices" : [ 16, 30 ],
      "id_str" : "190725105",
      "id" : 190725105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30348012966379521",
  "text" : "RT @pfeiffer44: @Searching4Par He can shoot from all over the court. If you play with POTUS pls watch the elbows",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rich Farmer",
        "screen_name" : "Searching4Par",
        "indices" : [ 0, 14 ],
        "id_str" : "190725105",
        "id" : 190725105
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "30345757840121857",
    "geo" : { },
    "id_str" : "30346540933451776",
    "in_reply_to_user_id" : 190725105,
    "text" : "@Searching4Par He can shoot from all over the court. If you play with POTUS pls watch the elbows",
    "id" : 30346540933451776,
    "in_reply_to_status_id" : 30345757840121857,
    "created_at" : "2011-01-26 19:29:13 +0000",
    "in_reply_to_screen_name" : "Searching4Par",
    "in_reply_to_user_id_str" : "190725105",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 30348012966379521,
  "created_at" : "2011-01-26 19:35:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "sandra barley",
      "screen_name" : "missdee68",
      "indices" : [ 17, 27 ],
      "id_str" : "37813916",
      "id" : 37813916
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30347946474086400",
  "text" : "RT @pfeiffer44: .@missdee68 As POTUS said last night, we want to work with Congress, but any changes must strengthen, not undermine Soci ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "sandra barley",
        "screen_name" : "missdee68",
        "indices" : [ 1, 11 ],
        "id_str" : "37813916",
        "id" : 37813916
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "30346693442539520",
    "geo" : { },
    "id_str" : "30347369555955713",
    "in_reply_to_user_id" : 37813916,
    "text" : ".@missdee68 As POTUS said last night, we want to work with Congress, but any changes must strengthen, not undermine Social Security",
    "id" : 30347369555955713,
    "in_reply_to_status_id" : 30346693442539520,
    "created_at" : "2011-01-26 19:32:31 +0000",
    "in_reply_to_screen_name" : "missdee68",
    "in_reply_to_user_id_str" : "37813916",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 30347946474086400,
  "created_at" : "2011-01-26 19:34:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Scott Wooledge",
      "screen_name" : "Clarknt67",
      "indices" : [ 16, 26 ],
      "id_str" : "97273575",
      "id" : 97273575
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30346870408617986",
  "text" : "RT @pfeiffer44: @Clarknt67 POTUS is very concerned about bullying and is hosting a conference on the subject. Will send more details whe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Wooledge",
        "screen_name" : "Clarknt67",
        "indices" : [ 0, 10 ],
        "id_str" : "97273575",
        "id" : 97273575
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "30342762876370944",
    "geo" : { },
    "id_str" : "30345718002622464",
    "in_reply_to_user_id" : 97273575,
    "text" : "@Clarknt67 POTUS is very concerned about bullying and is hosting a conference on the subject. Will send more details when we have them.",
    "id" : 30345718002622464,
    "in_reply_to_status_id" : 30342762876370944,
    "created_at" : "2011-01-26 19:25:57 +0000",
    "in_reply_to_screen_name" : "Clarknt67",
    "in_reply_to_user_id_str" : "97273575",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 30346870408617986,
  "created_at" : "2011-01-26 19:30:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 74, 85 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitter",
      "indices" : [ 56, 64 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30344785571086336",
  "text" : "Just RT'd WH Communications Director Dan Pfeiffer's new #twitter account, @pfeiffer44.  Reply to him with your ?'s about #SOTU",
  "id" : 30344785571086336,
  "created_at" : "2011-01-26 19:22:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30344382334902272",
  "text" : "RT @pfeiffer44: Is this thing on? Ok, keep sending questions & I\u2019ll start knocking them down",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "30343976556953600",
    "text" : "Is this thing on? Ok, keep sending questions & I\u2019ll start knocking them down",
    "id" : 30343976556953600,
    "created_at" : "2011-01-26 19:19:02 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 30344382334902272,
  "created_at" : "2011-01-26 19:20:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 114, 125 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30329910782332930",
  "text" : "RT @PressSec: Special guest to take your Qs in a bit. Introducing WH Comm Dir Dan Pfeiffer to Twitter, send Qs to @Pfeiffer44 & follow him",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 100, 111 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "30327963698335745",
    "text" : "Special guest to take your Qs in a bit. Introducing WH Comm Dir Dan Pfeiffer to Twitter, send Qs to @Pfeiffer44 & follow him",
    "id" : 30327963698335745,
    "created_at" : "2011-01-26 18:15:24 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 30329910782332930,
  "created_at" : "2011-01-26 18:23:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 102, 112 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30307608145436672",
  "text" : "Photo of the Day: A Member of Congress wearing a ribbon for Rep. Giffords reads along with the #SOTU (@petesouza) http:\/\/twitpic.com\/3tlwqa",
  "id" : 30307608145436672,
  "created_at" : "2011-01-26 16:54:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 61, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30293962946248704",
  "text" : "In case you missed it: Watch the full, first-ever \u201Cenhanced\u201D #SOTU w\/ chart, info, photos & salmon: http:\/\/wh.gov\/sotu",
  "id" : 30293962946248704,
  "created_at" : "2011-01-26 16:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chu",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30293034302177281",
  "text" : "RT @ENERGY: TUNE IN: Sec. Chu's town hall today at 12:45 PM EST at energy.gov\/livechat. Tweet us any Qs you have for him w\/ hashtag #chu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "chu",
        "indices" : [ 120, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "30262598763028480",
    "text" : "TUNE IN: Sec. Chu's town hall today at 12:45 PM EST at energy.gov\/livechat. Tweet us any Qs you have for him w\/ hashtag #chu",
    "id" : 30262598763028480,
    "created_at" : "2011-01-26 13:55:40 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 30293034302177281,
  "created_at" : "2011-01-26 15:56:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Sanford",
      "screen_name" : "brainygirlnyc",
      "indices" : [ 3, 17 ],
      "id_str" : "4231982249",
      "id" : 4231982249
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 86, 97 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30102032647983105",
  "text" : "RT @brainygirlnyc: The Social Nation: if you want your questions answered live, tweet @whitehouse using the hashtag #SOTU. #nowthatsenga ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 67, 78 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 97, 102 ]
      }, {
        "text" : "nowthatsengagement",
        "indices" : [ 104, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "30101646058987520",
    "text" : "The Social Nation: if you want your questions answered live, tweet @whitehouse using the hashtag #SOTU. #nowthatsengagement",
    "id" : 30101646058987520,
    "created_at" : "2011-01-26 03:16:06 +0000",
    "user" : {
      "name" : "Latched On, MD",
      "screen_name" : "latchedonMD",
      "protected" : false,
      "id_str" : "101650645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1419853342\/Lo-Res_azarya_0097_normal.jpg",
      "id" : 101650645,
      "verified" : false
    }
  },
  "id" : 30102032647983105,
  "created_at" : "2011-01-26 03:17:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 37, 48 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30101643341074432",
  "text" : "For those of you still subscribed to @whitehouse after all those tweets, we're just getting started! LIVE #SOTU Q&A: http:\/\/goo.gl\/qnxBN",
  "id" : 30101643341074432,
  "created_at" : "2011-01-26 03:16:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30100827901272064",
  "text" : "\"... it is because of our people that our future is hopeful, our journey goes forward, and the state of our union is strong.\" #SOTU",
  "id" : 30100827901272064,
  "created_at" : "2011-01-26 03:12:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30100616302829568",
  "text" : "From the earliest days of our founding, America has been the story of ordinary people who dare to dream. That\u2019s how we win the future. #SOTU",
  "id" : 30100616302829568,
  "created_at" : "2011-01-26 03:12:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30099815626969088",
  "text" : "\"We may have different opinions, but we believe in the same promise that says this is a place where you can make it if you try.\" #SOTU",
  "id" : 30099815626969088,
  "created_at" : "2011-01-26 03:08:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30099309689053184",
  "text" : "\"I call on all of our college campuses to open their doors to our military recruiters and the ROTC.\" #SOTU",
  "id" : 30099309689053184,
  "created_at" : "2011-01-26 03:06:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30099225521946625",
  "text" : "\"Starting this year, no American will be forbidden from serving the country they love because of who they love.\" #SOTU",
  "id" : 30099225521946625,
  "created_at" : "2011-01-26 03:06:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30098951248019456",
  "text" : "we must always remember that the Americans who have borne the greatest burden in this struggle are the men & women who serve our country.",
  "id" : 30098951248019456,
  "created_at" : "2011-01-26 03:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30098624213946368",
  "text" : "let us be clear: the United States of America stands with the people of Tunisia, & supports the democratic aspirations of all people. #SOTU",
  "id" : 30098624213946368,
  "created_at" : "2011-01-26 03:04:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30098456412430336",
  "text" : "\"In South Sudan \u2013 with our assistance \u2013 the people were finally able to vote for independence after years of war.\" #SOTU",
  "id" : 30098456412430336,
  "created_at" : "2011-01-26 03:03:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30097851660898305",
  "text" : "\"we will work w\/nearly 50 countries to begin a transition to an Afghan lead. And this July, we will begin to bring our troops home.\" #SOTU",
  "id" : 30097851660898305,
  "created_at" : "2011-01-26 03:01:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30097653953994753",
  "text" : "\"Thanks to our heroic troops and civilians, fewer Afghans are under the control of the insurgency.\" #SOTU",
  "id" : 30097653953994753,
  "created_at" : "2011-01-26 03:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30097271467020288",
  "text" : "\"America\u2019s commitment has been kept; the Iraq War is coming to an end.\" #SOTU",
  "id" : 30097271467020288,
  "created_at" : "2011-01-26 02:58:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30097088188514304",
  "text" : "\"tonight we can say that American leadership has been renewed and America\u2019s standing has been restored.\" #SOTU",
  "id" : 30097088188514304,
  "created_at" : "2011-01-26 02:57:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30096641176379392",
  "text" : "\"... both parties in Congress should know this: if a bill comes to my desk with earmarks inside, I will veto it.\" #SOTU",
  "id" : 30096641176379392,
  "created_at" : "2011-01-26 02:56:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30096503238299649",
  "text" : "In the coming months, my administration will develop a proposal to merge, consolidate, and reorganize the federal government #SOTU",
  "id" : 30096503238299649,
  "created_at" : "2011-01-26 02:55:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30096060261076993",
  "text" : "\"We live & do business in the information age, but the last major reorganization of the gvt happened in the age of black & white TV.\" #SOTU",
  "id" : 30096060261076993,
  "created_at" : "2011-01-26 02:53:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30095885182443520",
  "text" : "\"the best thing we could do on taxes for all Americans is to simplify the individual tax code.\" #SOTU",
  "id" : 30095885182443520,
  "created_at" : "2011-01-26 02:53:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30095812029583360",
  "text" : "\"Before we take money away from our schools, or scholarships away from our students, we should ask millionaires to give up their tax break.\"",
  "id" : 30095812029583360,
  "created_at" : "2011-01-26 02:52:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30095540578426880",
  "text" : "\"we should also find a bipartisan solution to strengthen Social Security for future generations.\" #SOTU",
  "id" : 30095540578426880,
  "created_at" : "2011-01-26 02:51:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30094691718406144",
  "text" : "\"So tonight, I am proposing that starting this year, we freeze annual domestic spending for the next five years.\" #SOTU",
  "id" : 30094691718406144,
  "created_at" : "2011-01-26 02:48:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30094591445172224",
  "text" : "\"Every day, families sacrifice to live within their means. They deserve a government that does the same.\" #SOTU",
  "id" : 30094591445172224,
  "created_at" : "2011-01-26 02:48:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30094385173499904",
  "text" : "\"instead of re-fighting the battles of the last two years, let\u2019s fix what needs fixing and move forward.\" #sotu",
  "id" : 30094385173499904,
  "created_at" : "2011-01-26 02:47:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30094124510085120",
  "text" : "What I\u2019m not willing to do is go back to the days when ins. companies could deny someone coverage because of a pre-existing condition #sotu",
  "id" : 30094124510085120,
  "created_at" : "2011-01-26 02:46:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30093945207791617",
  "text" : "\"If you have ideas about how to improve this law by making care better or more affordable, I am eager to work with you.\" #SOTU",
  "id" : 30093945207791617,
  "created_at" : "2011-01-26 02:45:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30093812269326337",
  "text" : "\"Now, I have heard rumors that a few of you have some concerns about the new health care law.\" #SOTU",
  "id" : 30093812269326337,
  "created_at" : "2011-01-26 02:44:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30093532458909697",
  "text" : "\"To reduce barriers to growth and investment, I\u2019ve ordered a review of government regulations.\" #SOTU",
  "id" : 30093532458909697,
  "created_at" : "2011-01-26 02:43:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30093245610467328",
  "text" : "\"To help businesses sell more products abroad, we set a goal of doubling our exports by 2014\" #SOTU",
  "id" : 30093245610467328,
  "created_at" : "2011-01-26 02:42:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30093020409896962",
  "text" : "\"So tonight, I\u2019m asking Democrats and Republicans to simplify the system. Get rid of the loopholes. Level the playing field.\" #SOTU",
  "id" : 30093020409896962,
  "created_at" : "2011-01-26 02:41:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30092914268831745",
  "text" : "\"Over the years, a parade of lobbyists has rigged the tax code to benefit particular companies and industries.\" #SOTU",
  "id" : 30092914268831745,
  "created_at" : "2011-01-26 02:41:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30092482511380481",
  "text" : "\"Within 25 years, our goal is to give 80% of Americans access to high-speed rail\" #SOTU",
  "id" : 30092482511380481,
  "created_at" : "2011-01-26 02:39:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30092255612116992",
  "text" : "[[Service note: if you have problems with the live video feed, just try refreshing your page]] http:\/\/goo.gl\/qnxBN #SOTU",
  "id" : 30092255612116992,
  "created_at" : "2011-01-26 02:38:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30092018889793536",
  "text" : "\"To attract new businesses to our shores, we need the fastest, most reliable ways to move people, goods, and information\" #SOTU",
  "id" : 30092018889793536,
  "created_at" : "2011-01-26 02:37:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30091238422093825",
  "text" : "\"I ask Congress to ... make permanent our tuition tax credit \u2013 worth $10,000 for four years of college.\" #SOTU",
  "id" : 30091238422093825,
  "created_at" : "2011-01-26 02:34:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30090917138399232",
  "text" : "If you want to make a difference in the life of our nation; if you want to make a difference in the life of a child\u2013 become a teacher. #SOTU",
  "id" : 30090917138399232,
  "created_at" : "2011-01-26 02:33:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30090647054589953",
  "text" : "\"after parents, the biggest impact on a child\u2019s success comes from the man or woman at the front of the classroom.\" #SOTU",
  "id" : 30090647054589953,
  "created_at" : "2011-01-26 02:32:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30090396411371520",
  "text" : "\"Race to the Top should be the approach we follow this year as we replace No Child Left Behind\" #SOTU",
  "id" : 30090396411371520,
  "created_at" : "2011-01-26 02:31:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30090088473956352",
  "text" : "\"When a child walks into a classroom, it should be a place of high expectations and high performance.\" #SOTU",
  "id" : 30090088473956352,
  "created_at" : "2011-01-26 02:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30090034447122433",
  "text" : "\"it\u2019s not just the winner of the Super Bowl who deserves to be celebrated, but the winner of the science fair\" #SOTU",
  "id" : 30090034447122433,
  "created_at" : "2011-01-26 02:29:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30089622373535745",
  "text" : "\"I challenge you to join me in setting a new goal: by 2035, 80% of America\u2019s electricity will come from clean energy sources.\" #sotu",
  "id" : 30089622373535745,
  "created_at" : "2011-01-26 02:28:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30089383054942208",
  "text" : "\"I\u2019m asking Congress to eliminate the billions in taxpayer dollars we currently give to oil companies.\" #SOTU",
  "id" : 30089383054942208,
  "created_at" : "2011-01-26 02:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30088968598982657",
  "text" : "people seem to be digging the enhanced #SOTU -- check it out here http:\/\/goo.gl\/qnxBN",
  "id" : 30088968598982657,
  "created_at" : "2011-01-26 02:25:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 43, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30088705507069956",
  "text" : "\"This is our generation\u2019s Sputnik moment.\" #SOTU",
  "id" : 30088705507069956,
  "created_at" : "2011-01-26 02:24:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 115, 122 ],
      "id_str" : "20536157",
      "id" : 20536157
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 125, 134 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30088469439057920",
  "text" : "We are the nation that put cars in driveways & computers in offices;the nation of Edison & the Wright brothers; of @Google & @Facebook #sotu",
  "id" : 30088469439057920,
  "created_at" : "2011-01-26 02:23:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30088171039494145",
  "text" : "\"The first step in winning the future is encouraging American innovation.\" #sotu",
  "id" : 30088171039494145,
  "created_at" : "2011-01-26 02:22:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30088056497250304",
  "text" : "We need to out-innovate, out-educate, and out-build the rest of the world. We have to make America the best place on Earth to do business.",
  "id" : 30088056497250304,
  "created_at" : "2011-01-26 02:22:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30087763399278592",
  "text" : "we are the first nation to be founded for the sake of an idea \u2013 the idea that each of us deserves the chance to shape our own destiny. #sotu",
  "id" : 30087763399278592,
  "created_at" : "2011-01-26 02:20:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30087523854192640",
  "text" : "\"The competition for jobs is real. But this shouldn\u2019t discourage us. It should challenge us.\" #sotu",
  "id" : 30087523854192640,
  "created_at" : "2011-01-26 02:19:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30087274255351808",
  "text" : "\"The rules have changed. In a single generation, revolutions in technology have transformed the way we live, work and do business.\" #sotu",
  "id" : 30087274255351808,
  "created_at" : "2011-01-26 02:18:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 96, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30086934634176512",
  "text" : "\"... to win the future, we\u2019ll need to take on challenges that have been decades in the making.\" #sotu",
  "id" : 30086934634176512,
  "created_at" : "2011-01-26 02:17:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30086654316249088",
  "text" : "\"We measure progress by the success of our people. By the jobs they can find and the quality of life those jobs offer.\" #sotu",
  "id" : 30086654316249088,
  "created_at" : "2011-01-26 02:16:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30086175066689537",
  "text" : "What comes of this moment will be determined not by whether we can sit together tonight, but whether we can work together tomorrow. #sotu",
  "id" : 30086175066689537,
  "created_at" : "2011-01-26 02:14:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30085976269266944",
  "text" : "\"Tucson reminded us that no matter who we are or where we come from, each of us is a part of something greater\" #sotu",
  "id" : 30085976269266944,
  "created_at" : "2011-01-26 02:13:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 27, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30085343915016196",
  "text" : "President Obama begins his #SOTU now: http:\/\/www.whitehouse.gov\/sotu",
  "id" : 30085343915016196,
  "created_at" : "2011-01-26 02:11:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sotu",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30083913527336960",
  "text" : "Live: President Obama delivers State of the Union. Watch the enhanced live stream & engage only on http:\/\/www.wh.gov #sotu",
  "id" : 30083913527336960,
  "created_at" : "2011-01-26 02:05:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30048699535065091",
  "text" : "Reply to us w\/ your questions for top WH policy folks, we\u2019ll take some in our online panel right after #SOTU at http:\/\/wh.gov",
  "id" : 30048699535065091,
  "created_at" : "2011-01-25 23:45:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30046435688841216",
  "text" : "#SOTU excerpt: \"This is our generation\u2019s Sputnik moment\" Watch the 1st-ever enhanced State of the Union at 9:00 http:\/\/wh.gov",
  "id" : 30046435688841216,
  "created_at" : "2011-01-25 23:36:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29985992651833345",
  "text" : "Lots of coverage leading up to #SOTU: http:\/\/wh.gov\/blog \u201CEnhanced\u201D SOTU at 9:00, Big \u201COpen for Questions\u201D right after",
  "id" : 29985992651833345,
  "created_at" : "2011-01-25 19:36:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kaplan",
      "screen_name" : "andrewjkaplan",
      "indices" : [ 1, 15 ],
      "id_str" : "6658932",
      "id" : 6658932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "29609420790956032",
  "geo" : { },
  "id_str" : "29927791872970752",
  "in_reply_to_user_id" : 6658932,
  "text" : ".@andrewjkaplan Yes. Watch President Obama walk through how tonight @ 9pm EST http:\/\/goo.gl\/qnxBN",
  "id" : 29927791872970752,
  "in_reply_to_status_id" : 29609420790956032,
  "created_at" : "2011-01-25 15:45:16 +0000",
  "in_reply_to_screen_name" : "andrewjkaplan",
  "in_reply_to_user_id_str" : "6658932",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29924230942429184",
  "text" : "State of the Union tonight at 9EST, go behind the scenes now w\/ Axelrod, Favreau & historians: http:\/\/is.gd\/iewaZX #SOTU",
  "id" : 29924230942429184,
  "created_at" : "2011-01-25 15:31:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29711540189921281",
  "text" : "No really, don't miss the \"Enhanced\" SOTU at WH.gov tomorrow: http:\/\/is.gd\/LMfYZ8 Finishing touches going on now  http:\/\/twitpic.com\/3t4zv0",
  "id" : 29711540189921281,
  "created_at" : "2011-01-25 01:25:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bloggers",
      "indices" : [ 23, 32 ]
    }, {
      "text" : "military",
      "indices" : [ 52, 61 ]
    }, {
      "text" : "slideshare",
      "indices" : [ 77, 88 ]
    }, {
      "text" : "blogs",
      "indices" : [ 106, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29653516310028288",
  "text" : "RT @DeptofDefense: Hey #bloggers - the WH report on #military families is on #slideshare to embed in your #blogs! http:\/\/slidesha.re\/g04 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JP",
        "screen_name" : "milblogging",
        "indices" : [ 121, 133 ],
        "id_str" : "16624180",
        "id" : 16624180
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bloggers",
        "indices" : [ 4, 13 ]
      }, {
        "text" : "military",
        "indices" : [ 33, 42 ]
      }, {
        "text" : "slideshare",
        "indices" : [ 58, 69 ]
      }, {
        "text" : "blogs",
        "indices" : [ 87, 93 ]
      }, {
        "text" : "sot",
        "indices" : [ 134, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29653001362735104",
    "text" : "Hey #bloggers - the WH report on #military families is on #slideshare to embed in your #blogs! http:\/\/slidesha.re\/g04cDR @milblogging #sot",
    "id" : 29653001362735104,
    "created_at" : "2011-01-24 21:33:21 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 29653516310028288,
  "created_at" : "2011-01-24 21:35:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 11, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29600284791537666",
  "text" : "\u201CVoices of #HCR\u201D: Jim from OR on how hcr helps small biz offer employees benefits that keep them around  http:\/\/is.gd\/ZCK0jz",
  "id" : 29600284791537666,
  "created_at" : "2011-01-24 18:03:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28955936102031360",
  "text" : "The Vice President & First Lady Honor Sargent Shriver: \"a heart that was teeming with love\" Photos: http:\/\/is.gd\/utkrj0",
  "id" : 28955936102031360,
  "created_at" : "2011-01-22 23:23:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28518290687004673",
  "text" : "Tuesday at 9PM EST: State of the Union. See how you can get involved: http:\/\/wh.gov\/sotu",
  "id" : 28518290687004673,
  "created_at" : "2011-01-21 18:24:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28492524498718721",
  "text" : "New West Wing Week: China State Dinner, singing Happy Birthday to the First Lady, mayors & jobs, more  http:\/\/is.gd\/fD5may",
  "id" : 28492524498718721,
  "created_at" : "2011-01-21 16:42:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28479763152642049",
  "text" : "Ok, apparently more White House layout experts than anticipated. Self-satisfaction for all who said Blue, Green & East. Tougher next time.",
  "id" : 28479763152642049,
  "created_at" : "2011-01-21 15:51:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28476619509202944",
  "text" : "Photo of the Day: First Lady surprises tour. Name 2 of 3 rooms pictured, bonus pts for 3rd. Prize: A job well done http:\/\/twitpic.com\/3s1h31",
  "id" : 28476619509202944,
  "created_at" : "2011-01-21 15:38:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 11, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28467509719998464",
  "text" : "\u201CVoices of #HCR\u201D: Paul from IN needs the Rx donut hole to keep closing, not open back up under repeal http:\/\/is.gd\/RZq0Jz",
  "id" : 28467509719998464,
  "created_at" : "2011-01-21 15:02:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28250621626810368",
  "text" : "Don't see this every day: live video teleconference from the WH w\/ Chinese bloggers on State visit. Watch & chat: http:\/\/wh.gov\/live",
  "id" : 28250621626810368,
  "created_at" : "2011-01-21 00:40:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28195269606637568",
  "text" : "RT @PressSec: Let\u2019s take a few Twitter questions, send your replies my way with what you want to know and I\u2019ll take a few around 4:30",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "28195196097269761",
    "text" : "Let\u2019s take a few Twitter questions, send your replies my way with what you want to know and I\u2019ll take a few around 4:30",
    "id" : 28195196097269761,
    "created_at" : "2011-01-20 21:00:33 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 28195269606637568,
  "created_at" : "2011-01-20 21:00:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28115034701832192",
  "text" : "10:45: On 2nd anniversary of inauguration, First Lady & Bo surprise WH tours. Good for a laugh, watch live http:\/\/wh.gov\/live",
  "id" : 28115034701832192,
  "created_at" : "2011-01-20 15:42:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 11, 15 ]
    }, {
      "text" : "hcr",
      "indices" : [ 53, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28099897811017728",
  "text" : "\"Voices of #HCR\" Libbie & Natalie from NC: Repealing #hcr means repealing a Mom's peace of mind http:\/\/bit.ly\/hMp4QI",
  "id" : 28099897811017728,
  "created_at" : "2011-01-20 14:41:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 23, 33 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27854828285730816",
  "text" : "New photo gallery from @petesouza & Co: China State Visit: http:\/\/is.gd\/9i6pqD",
  "id" : 27854828285730816,
  "created_at" : "2011-01-19 22:28:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 119, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27767962597326848",
  "text" : "OK, have to run, thanks for the Qs, for those asking about jobs & economy read Sec Geithner here: http:\/\/bit.ly\/ibOTfx #hcr",
  "id" : 27767962597326848,
  "created_at" : "2011-01-19 16:42:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Brennan",
      "screen_name" : "ryan13rennan",
      "indices" : [ 0, 13 ],
      "id_str" : "201330859",
      "id" : 201330859
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27766556482076673",
  "in_reply_to_user_id" : 201330859,
  "text" : "@ryan13rennan Will create jobs by driving down costs for business, repeal would prevent 250-400K jobs\/ year http:\/\/bit.ly\/gdugcV",
  "id" : 27766556482076673,
  "created_at" : "2011-01-19 16:37:17 +0000",
  "in_reply_to_screen_name" : "ryan13rennan",
  "in_reply_to_user_id_str" : "201330859",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VOTE VOTE VOTE",
      "screen_name" : "MikeEngelhart",
      "indices" : [ 0, 14 ],
      "id_str" : "3167271",
      "id" : 3167271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27762618227752960",
  "geo" : { },
  "id_str" : "27765988950810624",
  "in_reply_to_user_id" : 3167271,
  "text" : "@MikeEngelhart We're confident the law is Constitutional, states are moving forward to implement the law http:\/\/is.gd\/ysENCZ",
  "id" : 27765988950810624,
  "in_reply_to_status_id" : 27762618227752960,
  "created_at" : "2011-01-19 16:35:02 +0000",
  "in_reply_to_screen_name" : "MikeEngelhart",
  "in_reply_to_user_id_str" : "3167271",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juan Zelaya",
      "screen_name" : "JHZelaya",
      "indices" : [ 0, 9 ],
      "id_str" : "46758095",
      "id" : 46758095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27763887403175937",
  "geo" : { },
  "id_str" : "27764867779796992",
  "in_reply_to_user_id" : 46758095,
  "text" : "@JHZelaya Learn about ins options\/protections at http:\/\/hc.gov  Also in 2014 new state exchanges make easier to shop, compare plans",
  "id" : 27764867779796992,
  "in_reply_to_status_id" : 27763887403175937,
  "created_at" : "2011-01-19 16:30:34 +0000",
  "in_reply_to_screen_name" : "JHZelaya",
  "in_reply_to_user_id_str" : "46758095",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27764250814451712",
  "text" : "Have to run to be on Fox, handing over the Twitter reins to colleague Nick Papas...",
  "id" : 27764250814451712,
  "created_at" : "2011-01-19 16:28:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0421\u043E\u0431\u043E\u043B\u0435\u0432\u0430   \u041B\u0438\u043B\u0438\u0430\u043D\u0430 \u041A",
      "screen_name" : "parkerbriden",
      "indices" : [ 0, 13 ],
      "id_str" : "2988233303",
      "id" : 2988233303
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 59, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27763628623003648",
  "text" : "@parkerbriden Independent Congressional Budget Office says #hcr reduces deficits by $1trillion+ over 2 decades http:\/\/bit.ly\/hzR1rP",
  "id" : 27763628623003648,
  "created_at" : "2011-01-19 16:25:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Foster",
      "screen_name" : "CMFoster23",
      "indices" : [ 0, 11 ],
      "id_str" : "32558940",
      "id" : 32558940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27762023622254592",
  "geo" : { },
  "id_str" : "27763070105292801",
  "in_reply_to_user_id" : 32558940,
  "text" : "@CMFoster23 Ins Cos could once again deny\/ drop\/ cap coverage when sick, premiums\/ deficits\/ seniors Rx costs all up http:\/\/bit.ly\/hl68Jd",
  "id" : 27763070105292801,
  "in_reply_to_status_id" : 27762023622254592,
  "created_at" : "2011-01-19 16:23:26 +0000",
  "in_reply_to_screen_name" : "CMFoster23",
  "in_reply_to_user_id_str" : "32558940",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Gillan",
      "screen_name" : "paul_gillan",
      "indices" : [ 0, 12 ],
      "id_str" : "185724600",
      "id" : 185724600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27757864844009475",
  "geo" : { },
  "id_str" : "27762149744975872",
  "in_reply_to_user_id" : 185724600,
  "text" : "@paul_gillan Affordability measures: smallbiz\/mid. class tax credits, reducing costs u pay for uninsured, premium review http:\/\/is.gd\/uFrA0b",
  "id" : 27762149744975872,
  "in_reply_to_status_id" : 27757864844009475,
  "created_at" : "2011-01-19 16:19:46 +0000",
  "in_reply_to_screen_name" : "paul_gillan",
  "in_reply_to_user_id_str" : "185724600",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Jennings",
      "screen_name" : "hopeforvandj",
      "indices" : [ 0, 13 ],
      "id_str" : "29323239",
      "id" : 29323239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27756550001008640",
  "geo" : { },
  "id_str" : "27760999822000128",
  "in_reply_to_user_id" : 29323239,
  "text" : "@hopeforvandj Yes, under the law insurance cos can no longer discriminate against kids w\/ any medical condition http:\/\/bit.ly\/bsxqA9",
  "id" : 27760999822000128,
  "in_reply_to_status_id" : 27756550001008640,
  "created_at" : "2011-01-19 16:15:12 +0000",
  "in_reply_to_screen_name" : "hopeforvandj",
  "in_reply_to_user_id_str" : "29323239",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27760521184813057",
  "text" : "Hey everybody, Stephanie Cutter here, what are your questions on #hcr & repeal?",
  "id" : 27760521184813057,
  "created_at" : "2011-01-19 16:13:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 23, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27751560603770880",
  "text" : "11AM: Send yours Qs on #HCR repeal over Twitter for Stephanie Cutter, who just put out this WH White Board http:\/\/is.gd\/uFrA0b",
  "id" : 27751560603770880,
  "created_at" : "2011-01-19 15:37:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 11, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27743834569965568",
  "text" : "\"Voices of #HCR\" Betsy from UT: under repeal, small biz tax credits for her employees would go away http:\/\/bit.ly\/hksMAV",
  "id" : 27743834569965568,
  "created_at" : "2011-01-19 15:07:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27727957426442240",
  "text" : "Happening Now: President Obama welcomes President Hu of China to the White House. Watch live: http:\/\/wh.gov\/live",
  "id" : 27727957426442240,
  "created_at" : "2011-01-19 14:03:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27498834468802560",
  "text" : "President Obama on passing of Sargent Shriver: \u201Cone of the brightest lights of the greatest generation\u201D http:\/\/is.gd\/3AJYKj",
  "id" : 27498834468802560,
  "created_at" : "2011-01-18 22:53:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lgbt",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27498716017467392",
  "text" : "Another step forward for #lgbt equality: new hospital visitation regulations go into effect today http:\/\/is.gd\/tuHdL1",
  "id" : 27498716017467392,
  "created_at" : "2011-01-18 22:52:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 11, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27415288509112321",
  "text" : "\"Voices of #HCR\" Cathy from OH: under repeal, pre-existing condition would again prevent her from getting insurance http:\/\/ow.ly\/3FTho",
  "id" : 27415288509112321,
  "created_at" : "2011-01-18 17:21:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27403013475794944",
  "text" : "OMB's Jack Lew digs into the President\u2019s strategy to \"strike the right balance\" on regulations & jobs http:\/\/ow.ly\/3FQKj",
  "id" : 27403013475794944,
  "created_at" : "2011-01-18 16:32:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MLK Day",
      "screen_name" : "MLKDay",
      "indices" : [ 3, 10 ],
      "id_str" : "17001730",
      "id" : 17001730
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27090141373792256",
  "text" : "RT @MLKDay: How are you are serving this #MLKDay? Please take a few minute to share your plans: http:\/\/mlkday.gov\/share\/index.php",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLKDay",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27067711087443968",
    "text" : "How are you are serving this #MLKDay? Please take a few minute to share your plans: http:\/\/mlkday.gov\/share\/index.php",
    "id" : 27067711087443968,
    "created_at" : "2011-01-17 18:20:19 +0000",
    "user" : {
      "name" : "MLK Day",
      "screen_name" : "MLKDay",
      "protected" : false,
      "id_str" : "17001730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556146916442902528\/Cu6dRDjT_normal.jpeg",
      "id" : 17001730,
      "verified" : false
    }
  },
  "id" : 27090141373792256,
  "created_at" : "2011-01-17 19:49:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26081114955194369",
  "text" : "Great words and images from a great memorial for a great American. Remembering Holbrooke: http:\/\/ow.ly\/3EdPN",
  "id" : 26081114955194369,
  "created_at" : "2011-01-15 00:59:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26047635555098624",
  "text" : "President opens purposeful travel, non-family remittances, airports supporting licensed charter flights to\/from Cuba http:\/\/ow.ly\/3Eb33",
  "id" : 26047635555098624,
  "created_at" : "2011-01-14 22:46:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26001785122459648",
  "text" : "Payroll Tax Cuts: In Numbers http:\/\/is.gd\/m7BHQy Example: average worker gets $695 this year from this alone",
  "id" : 26001785122459648,
  "created_at" : "2011-01-14 19:44:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MLK Day",
      "screen_name" : "MLKDay",
      "indices" : [ 69, 76 ],
      "id_str" : "17001730",
      "id" : 17001730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25994790042607616",
  "text" : "Looking to come together & serve your community this weekend? Follow @MLKDay & check out http:\/\/mlkday.gov\/",
  "id" : 25994790042607616,
  "created_at" : "2011-01-14 19:16:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25982507874787328",
  "text" : "New West Wing Week: Preview of \"Dispatches from Sudan\" focusing on their pivotal referendum\n http:\/\/ow.ly\/3E1ZB",
  "id" : 25982507874787328,
  "created_at" : "2011-01-14 18:28:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Braisted",
      "screen_name" : "Sean_Braisted",
      "indices" : [ 54, 68 ],
      "id_str" : "6953742",
      "id" : 6953742
    }, {
      "name" : "Eli Tarin",
      "screen_name" : "oneseven3",
      "indices" : [ 69, 79 ],
      "id_str" : "17881825",
      "id" : 17881825
    }, {
      "name" : "K.C.",
      "screen_name" : "redaction00",
      "indices" : [ 80, 92 ],
      "id_str" : "35688745",
      "id" : 35688745
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25945844884705280",
  "text" : "Bonus winners for rightly identifying Axelrod\u2019s tuft: @Sean_Braisted @oneseven3 @redaction00. Prize of $0 redeemable nowhere.",
  "id" : 25945844884705280,
  "created_at" : "2011-01-14 16:02:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25935973246312448",
  "text" : "Bonus for the 3rd person represented by tuft of hair in doorway still unclaimed. Prize doubles.",
  "id" : 25935973246312448,
  "created_at" : "2011-01-14 15:23:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mugizi Rwebangira",
      "screen_name" : "rweba",
      "indices" : [ 7, 13 ],
      "id_str" : "10474152",
      "id" : 10474152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25935676721602561",
  "text" : "FTW RT @rweba: Jon Favreau (head speech writer) and Ben Rhodes (national security guy)\/\/ Check of $0.00 is in the mail",
  "id" : 25935676721602561,
  "created_at" : "2011-01-14 15:22:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25932343952801792",
  "text" : "Photo of the Day contest: Name who Obama is talking to. Bonus for the tuft of hair. Prize: Nothing. http:\/\/twitpic.com\/3pxvoq",
  "id" : 25932343952801792,
  "created_at" : "2011-01-14 15:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25658305560973312",
  "text" : "New photo gallery: The President & First Lady in Arizona  http:\/\/ow.ly\/3Dtge",
  "id" : 25658305560973312,
  "created_at" : "2011-01-13 20:59:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsten Gillibrand",
      "screen_name" : "SenGillibrand",
      "indices" : [ 14, 28 ],
      "id_str" : "72198806",
      "id" : 72198806
    }, {
      "name" : "D Wasserman Schultz",
      "screen_name" : "DWStweets",
      "indices" : [ 31, 41 ],
      "id_str" : "115979444",
      "id" : 115979444
    }, {
      "name" : "Rep_Giffords",
      "screen_name" : "Rep_Giffords",
      "indices" : [ 61, 74 ],
      "id_str" : "2484571640",
      "id" : 2484571640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25595797714239488",
  "text" : "Transcript of @SenGillibrand & @DWStweets on AF1 telling how @Rep_Giffords opened her eyes for first time http:\/\/wh.gov\/cX5",
  "id" : 25595797714239488,
  "created_at" : "2011-01-13 16:51:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25590927800139777",
  "text" : "RT @PressSec: Take a few minutes today and read this about the miracle of Giffords opening her eyes yesterday http:\/\/tinyurl.com\/68gajfm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "25590551562690561",
    "text" : "Take a few minutes today and read this about the miracle of Giffords opening her eyes yesterday http:\/\/tinyurl.com\/68gajfm",
    "id" : 25590551562690561,
    "created_at" : "2011-01-13 16:30:37 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 25590927800139777,
  "created_at" : "2011-01-13 16:32:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25407116885884928",
  "text" : "Video of POTUS's speech in Tucson: http:\/\/goo.gl\/MLwKB \"... the forces that divide us are not as strong as those that unite us.\"",
  "id" : 25407116885884928,
  "created_at" : "2011-01-13 04:21:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25399452869070848",
  "text" : "The President\u2019s full remarks in Tucson: http:\/\/is.gd\/xT8yvg \"...our hopes and dreams are bound together\u2026\"",
  "id" : 25399452869070848,
  "created_at" : "2011-01-13 03:51:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25321245683752960",
  "text" : "8:00 EST: Watch the President\u2019s speech in Tucson http:\/\/wh.gov\/live",
  "id" : 25321245683752960,
  "created_at" : "2011-01-12 22:40:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25223572779704320",
  "text" : "Photo of the Day: VP Joe Biden awards a Bronze Star to Staff Sergeant Workman in Afghanistan  http:\/\/twitpic.com\/3pe7o5",
  "id" : 25223572779704320,
  "created_at" : "2011-01-12 16:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24945824899276800",
  "text" : "President Obama on Haiti, One Year Later: \"Haitian people\u2026 extraordinary courage and faith\" http:\/\/ow.ly\/3C7iQ",
  "id" : 24945824899276800,
  "created_at" : "2011-01-11 21:48:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24888284782010369",
  "text" : "Photo of the Day: The President & First Lady walk back to the WH Residence after moment of silence yesterday  http:\/\/twitpic.com\/3p4xzi",
  "id" : 24888284782010369,
  "created_at" : "2011-01-11 18:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24530031145390080",
  "text" : "Video: The President & First Lady\u2019s moment of silence for victims in AZ, including those still fighting http:\/\/ow.ly\/3Bjnm",
  "id" : 24530031145390080,
  "created_at" : "2011-01-10 18:16:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24495281403854849",
  "text" : "Now: The President & White House observe a moment of silence for AZ victims, watch & join: http:\/\/wh.gov\/live",
  "id" : 24495281403854849,
  "created_at" : "2011-01-10 15:58:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24476628524470272",
  "text" : "11AM EST: The President & White House will observe a moment of silence for AZ victims, watch & join: http:\/\/wh.gov\/live",
  "id" : 24476628524470272,
  "created_at" : "2011-01-10 14:44:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24224633242779648",
  "text" : "Proclamation: Flags at half-staff for the week http:\/\/is.gd\/krNws Moment of silence 11AM EST tomorrow http:\/\/is.gd\/krNkm",
  "id" : 24224633242779648,
  "created_at" : "2011-01-09 22:02:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23881574797803520",
  "text" : "Video: The President on Tucson shootings & Giffords: \"Gabby is as tough as they come\" Also VP, DOJ, DHS http:\/\/is.gd\/kos1r",
  "id" : 23881574797803520,
  "created_at" : "2011-01-08 23:19:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23852498628378624",
  "text" : "Starting soon: The President speaks on today\u2019s events & Rep Gabrielle Giffords, watch: http:\/\/wh.gov\/live",
  "id" : 23852498628378624,
  "created_at" : "2011-01-08 21:24:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23841498407632896",
  "text" : "President Obama: \"Representative Giffords, the victims of this tragedy, and their families in our prayers\" http:\/\/is.gd\/ko0rT",
  "id" : 23841498407632896,
  "created_at" : "2011-01-08 20:40:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23470271327371266",
  "text" : "West Wing Week: A whole bunch of bill signings, WH Staff New Year\u2019s Resolutions, yoga, cuticles. http:\/\/ow.ly\/3AaWH",
  "id" : 23470271327371266,
  "created_at" : "2011-01-07 20:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 12, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23424393669509120",
  "text" : ".@KyrazyDoy #hcr = \"health care reform\" which people have been using for a while to discuss this important issue",
  "id" : 23424393669509120,
  "created_at" : "2011-01-07 17:03:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Rogers",
      "screen_name" : "katierogers",
      "indices" : [ 0, 12 ],
      "id_str" : "14116915",
      "id" : 14116915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23422997771583488",
  "geo" : { },
  "id_str" : "23423888624979968",
  "in_reply_to_user_id" : 14116915,
  "text" : "@katierogers thanks Katie!",
  "id" : 23423888624979968,
  "in_reply_to_status_id" : 23422997771583488,
  "created_at" : "2011-01-07 17:01:04 +0000",
  "in_reply_to_screen_name" : "katierogers",
  "in_reply_to_user_id_str" : "14116915",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 92, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23422360027664384",
  "text" : "Thanks for all the questions - we've got to run, but please reply with more questions about #hcr & we'll try to answer more soon",
  "id" : 23422360027664384,
  "created_at" : "2011-01-07 16:55:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Gehr",
      "screen_name" : "GregGehr",
      "indices" : [ 0, 9 ],
      "id_str" : "9043992",
      "id" : 9043992
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23420483340865536",
  "geo" : { },
  "id_str" : "23421887606423552",
  "in_reply_to_user_id" : 9043992,
  "text" : "@GregGehr sounds like you may have heard something that isn't true: no one (in govt or not) is paying personal taxes on health insurance",
  "id" : 23421887606423552,
  "in_reply_to_status_id" : 23420483340865536,
  "created_at" : "2011-01-07 16:53:07 +0000",
  "in_reply_to_screen_name" : "GregGehr",
  "in_reply_to_user_id_str" : "9043992",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gardenofthegods\u0646",
      "screen_name" : "gardenofthegods",
      "indices" : [ 0, 16 ],
      "id_str" : "26447410",
      "id" : 26447410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23420281179611136",
  "geo" : { },
  "id_str" : "23421369668608000",
  "in_reply_to_user_id" : 26447410,
  "text" : "@gardenofthegods that's terrible - your state ins commissioner has new powers to figure out what's going on: http:\/\/bit.ly\/gprTQp",
  "id" : 23421369668608000,
  "in_reply_to_status_id" : 23420281179611136,
  "created_at" : "2011-01-07 16:51:04 +0000",
  "in_reply_to_screen_name" : "gardenofthegods",
  "in_reply_to_user_id_str" : "26447410",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Carpenter",
      "screen_name" : "carpware",
      "indices" : [ 0, 9 ],
      "id_str" : "14129407",
      "id" : 14129407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23419722443788288",
  "geo" : { },
  "id_str" : "23420675519680513",
  "in_reply_to_user_id" : 14129407,
  "text" : "@carpware Yes! Starting this month, doctors & hospitals will get incentives for modernizing medical record mgmt. more: http:\/\/goo.gl\/ZlrgH",
  "id" : 23420675519680513,
  "in_reply_to_status_id" : 23419722443788288,
  "created_at" : "2011-01-07 16:48:18 +0000",
  "in_reply_to_screen_name" : "carpware",
  "in_reply_to_user_id_str" : "14129407",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pamela Phillips",
      "screen_name" : "pamelajeri",
      "indices" : [ 0, 11 ],
      "id_str" : "22055806",
      "id" : 22055806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23418956580659200",
  "geo" : { },
  "id_str" : "23420218315382784",
  "in_reply_to_user_id" : 22055806,
  "text" : "@pamelajeri exactly.  we're getting the word out, and since this report just came out today, please share it broadly!",
  "id" : 23420218315382784,
  "in_reply_to_status_id" : 23418956580659200,
  "created_at" : "2011-01-07 16:46:29 +0000",
  "in_reply_to_screen_name" : "pamelajeri",
  "in_reply_to_user_id_str" : "22055806",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Emanuel",
      "screen_name" : "jeffemanuel",
      "indices" : [ 0, 12 ],
      "id_str" : "18168799",
      "id" : 18168799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23418843946815488",
  "geo" : { },
  "id_str" : "23419072104374273",
  "in_reply_to_user_id" : 18168799,
  "text" : "@jeffemanuel it's just that there are a bunch coming in so we are getting to \"what we can\" - we'll also answer more in a blog post later",
  "id" : 23419072104374273,
  "in_reply_to_status_id" : 23418843946815488,
  "created_at" : "2011-01-07 16:41:56 +0000",
  "in_reply_to_screen_name" : "jeffemanuel",
  "in_reply_to_user_id_str" : "18168799",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gardenofthegods\u0646",
      "screen_name" : "gardenofthegods",
      "indices" : [ 0, 16 ],
      "id_str" : "26447410",
      "id" : 26447410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23416463092097024",
  "geo" : { },
  "id_str" : "23418861596446721",
  "in_reply_to_user_id" : 26447410,
  "text" : "@gardenofthegods This is the reason why health reform is so important. Here's a good example from CA - http:\/\/bit.ly\/dRnkRn",
  "id" : 23418861596446721,
  "in_reply_to_status_id" : 23416463092097024,
  "created_at" : "2011-01-07 16:41:06 +0000",
  "in_reply_to_screen_name" : "gardenofthegods",
  "in_reply_to_user_id_str" : "26447410",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pamela Phillips",
      "screen_name" : "pamelajeri",
      "indices" : [ 1, 12 ],
      "id_str" : "22055806",
      "id" : 22055806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23416820874616832",
  "geo" : { },
  "id_str" : "23418356010852354",
  "in_reply_to_user_id" : 22055806,
  "text" : ".@pamelajeri Don't know. But there's this: \"Health Care Reform Could Boost Employment by 400,000 a Year this Decade\" http:\/\/goo.gl\/Ffrqc",
  "id" : 23418356010852354,
  "in_reply_to_status_id" : 23416820874616832,
  "created_at" : "2011-01-07 16:39:05 +0000",
  "in_reply_to_screen_name" : "pamelajeri",
  "in_reply_to_user_id_str" : "22055806",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dave",
      "screen_name" : "davidpetschull",
      "indices" : [ 41, 56 ],
      "id_str" : "134184281",
      "id" : 134184281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23416901761769473",
  "geo" : { },
  "id_str" : "23417500607709184",
  "in_reply_to_user_id" : 31317245,
  "text" : "@swingmann11 check out what we just told @davidpetschull",
  "id" : 23417500607709184,
  "in_reply_to_status_id" : 23416901761769473,
  "created_at" : "2011-01-07 16:35:41 +0000",
  "in_reply_to_screen_name" : "Mr_skyhigh11",
  "in_reply_to_user_id_str" : "31317245",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farmer Dave",
      "screen_name" : "davidpetschull",
      "indices" : [ 0, 15 ],
      "id_str" : "134184281",
      "id" : 134184281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23416856626864128",
  "geo" : { },
  "id_str" : "23417388825313280",
  "in_reply_to_user_id" : 134184281,
  "text" : "@davidpetschull already making impact, including consumer protections for people w\/ins. Check out timeline here: http:\/\/bit.ly\/aG4FR5",
  "id" : 23417388825313280,
  "in_reply_to_status_id" : 23416856626864128,
  "created_at" : "2011-01-07 16:35:15 +0000",
  "in_reply_to_screen_name" : "davidpetschull",
  "in_reply_to_user_id_str" : "134184281",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lynda onuoha",
      "screen_name" : "LOnuoha",
      "indices" : [ 0, 8 ],
      "id_str" : "2673367047",
      "id" : 2673367047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23416940554883072",
  "text" : "@LOnuoha you may be eligible for PCIP or a number of other options.  Check out the finder on http:\/\/www.HealthCare.gov",
  "id" : 23416940554883072,
  "created_at" : "2011-01-07 16:33:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23415547693637634",
  "geo" : { },
  "id_str" : "23416666641661952",
  "in_reply_to_user_id" : 28400816,
  "text" : "@RoeBizness Good question - President would veto repeal, b\/c it would add billions to deficit, among many other reasons http:\/\/bit.ly\/hzR1rP",
  "id" : 23416666641661952,
  "in_reply_to_status_id" : 23415547693637634,
  "created_at" : "2011-01-07 16:32:23 +0000",
  "in_reply_to_screen_name" : "RoeBizzy",
  "in_reply_to_user_id_str" : "28400816",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V. September McCrady",
      "screen_name" : "Nineof12",
      "indices" : [ 0, 9 ],
      "id_str" : "5927482",
      "id" : 5927482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23414766366101504",
  "geo" : { },
  "id_str" : "23415661602537473",
  "in_reply_to_user_id" : 5927482,
  "text" : "@Nineof12 New ins. plans are required to offer certain free preventive care (http:\/\/goo.gl\/nFBIL) but ACA does not set prices",
  "id" : 23415661602537473,
  "in_reply_to_status_id" : 23414766366101504,
  "created_at" : "2011-01-07 16:28:23 +0000",
  "in_reply_to_screen_name" : "Nineof12",
  "in_reply_to_user_id_str" : "5927482",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 21, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23414729368145920",
  "text" : "Have questions about #hcr?  Reply and we'll answer what we can (10 minutes left)",
  "id" : 23414729368145920,
  "created_at" : "2011-01-07 16:24:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NHayworthTracker",
      "screen_name" : "NanHayworthNews",
      "indices" : [ 0, 16 ],
      "id_str" : "211519368",
      "id" : 211519368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23409913531203585",
  "geo" : { },
  "id_str" : "23413956391469056",
  "in_reply_to_user_id" : 211519368,
  "text" : "@NanHayworthNews getting younger, healthier people into the insurance pool helps lower costs for everyone over time",
  "id" : 23413956391469056,
  "in_reply_to_status_id" : 23409913531203585,
  "created_at" : "2011-01-07 16:21:36 +0000",
  "in_reply_to_screen_name" : "NanHayworthNews",
  "in_reply_to_user_id_str" : "211519368",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Molloy",
      "screen_name" : "dylan555",
      "indices" : [ 0, 9 ],
      "id_str" : "11635002",
      "id" : 11635002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23412103901618176",
  "geo" : { },
  "id_str" : "23413399211745281",
  "in_reply_to_user_id" : 11635002,
  "text" : "@dylan555 you might be interested in learning more about something called \"Medical Loss Ratio\" measures now in place: http:\/\/bit.ly\/hWHP1F",
  "id" : 23413399211745281,
  "in_reply_to_status_id" : 23412103901618176,
  "created_at" : "2011-01-07 16:19:24 +0000",
  "in_reply_to_screen_name" : "dylan555",
  "in_reply_to_user_id_str" : "11635002",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marty Crimmins",
      "screen_name" : "eeegad",
      "indices" : [ 1, 8 ],
      "id_str" : "105572712",
      "id" : 105572712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23408622738350080",
  "geo" : { },
  "id_str" : "23413014619230208",
  "in_reply_to_user_id" : 105572712,
  "text" : ".@eeegad You have the right to appeal to an independent 3rd party, thx to ACA. Call your state ins. commissioner: http:\/\/goo.gl\/2jFkb",
  "id" : 23413014619230208,
  "in_reply_to_status_id" : 23408622738350080,
  "created_at" : "2011-01-07 16:17:52 +0000",
  "in_reply_to_screen_name" : "eeegad",
  "in_reply_to_user_id_str" : "105572712",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wendy",
      "screen_name" : "wendylefty",
      "indices" : [ 0, 11 ],
      "id_str" : "17252004",
      "id" : 17252004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23230230206349312",
  "geo" : { },
  "id_str" : "23412263364861954",
  "in_reply_to_user_id" : 17252004,
  "text" : "@wendylefty W\/O ACA, 165 million who have insurance lose consumer protections such as no lifetime limits #hcr http:\/\/bit.ly\/bHXmG5",
  "id" : 23412263364861954,
  "in_reply_to_status_id" : 23230230206349312,
  "created_at" : "2011-01-07 16:14:53 +0000",
  "in_reply_to_screen_name" : "wendylefty",
  "in_reply_to_user_id_str" : "17252004",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Molloy",
      "screen_name" : "dylan555",
      "indices" : [ 0, 9 ],
      "id_str" : "11635002",
      "id" : 11635002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "23405960663928832",
  "geo" : { },
  "id_str" : "23410907711275008",
  "in_reply_to_user_id" : 11635002,
  "text" : "@dylan555 small biz w\/20 emp can get tax credits to pay for up to 35% of premiums for workers.  More info here: http:\/\/bit.ly\/bpwflx",
  "id" : 23410907711275008,
  "in_reply_to_status_id" : 23405960663928832,
  "created_at" : "2011-01-07 16:09:30 +0000",
  "in_reply_to_screen_name" : "dylan555",
  "in_reply_to_user_id_str" : "11635002",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 102, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23405563417202688",
  "text" : "Get some background on the consumer protections in the Affordable Care Act here: http:\/\/bit.ly\/cu5MKT #hcr",
  "id" : 23405563417202688,
  "created_at" : "2011-01-07 15:48:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23404936662360064",
  "text" : "Starting at 11:00 some of our health care experts will be here answering Qs on #hcr & consumer protections, reply w\/ yours",
  "id" : 23404936662360064,
  "created_at" : "2011-01-07 15:45:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23390549071372288",
  "text" : "Goolsbee on new jobs numbers: +112K last month, +1.3 million in 2010, rate falls to 9.4%, more to do http:\/\/ow.ly\/3zXFz",
  "id" : 23390549071372288,
  "created_at" : "2011-01-07 14:48:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23116597040250880",
  "text" : "Video\/ transcript: Obama introduces Bill Daley as new Chief of Staff http:\/\/ow.ly\/3zzI1",
  "id" : 23116597040250880,
  "created_at" : "2011-01-06 20:40:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23063903206375424",
  "text" : "2:30 EST: President makes a personnel announcement: new interns have been picked. Just kidding. Watch: http:\/\/wh.gov\/live",
  "id" : 23063903206375424,
  "created_at" : "2011-01-06 17:10:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 31, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23055388899282944",
  "text" : "RT @NancyPelosi: CBO finds GOP #hcr repeal bill adds $230 BILLION to the deficit & Americans would pay more for less http:\/\/go.usa.gov\/rIh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcr",
        "indices" : [ 14, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "23044959837888512",
    "text" : "CBO finds GOP #hcr repeal bill adds $230 BILLION to the deficit & Americans would pay more for less http:\/\/go.usa.gov\/rIh",
    "id" : 23044959837888512,
    "created_at" : "2011-01-06 15:55:21 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 23055388899282944,
  "created_at" : "2011-01-06 16:36:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 85, 95 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23050183600250881",
  "text" : "Photo of the Day: Obama & Biden in the Oval, Bob Bauer & Tom Donilon outside. Credit @petesouza   http:\/\/twitpic.com\/3njo32",
  "id" : 23050183600250881,
  "created_at" : "2011-01-06 16:16:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "23030100438032384",
  "text" : "Elizabeth Warren: Welcoming Holly Petraeus to the Consumer Financial Protection Bureau team http:\/\/ow.ly\/3zl8k",
  "id" : 23030100438032384,
  "created_at" : "2011-01-06 14:56:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22775467194978304",
  "text" : "Photo of the Day: What signing 35 bills in a row looks like  http:\/\/twitpic.com\/3nccba",
  "id" : 22775467194978304,
  "created_at" : "2011-01-05 22:04:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 69, 78 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 132, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22742549567377408",
  "text" : "RT @PressSec: First Question answers up on my future & the future of @PressSec, better late than never: http:\/\/wh.gov\/firstquestion #1Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 55, 64 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 118, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "22742455841460224",
    "text" : "First Question answers up on my future & the future of @PressSec, better late than never: http:\/\/wh.gov\/firstquestion #1Q",
    "id" : 22742455841460224,
    "created_at" : "2011-01-05 19:53:18 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 22742549567377408,
  "created_at" : "2011-01-05 19:53:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22683711828918272",
  "text" : "Under-reported in WH staff shake-up: we\u2019ll be bringing in whole new crop of interns for summer. Apply: www.wh.gov\/internship",
  "id" : 22683711828918272,
  "created_at" : "2011-01-05 15:59:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 96, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22678085132357632",
  "text" : "Collecting questions for Press Secretary Robert Gibbs for another 30 min, tweet them over using #1Q and he'll answer a few",
  "id" : 22678085132357632,
  "created_at" : "2011-01-05 15:37:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 85, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22666195404595200",
  "text" : "RT @PressSec: How about some good old fashioned First Question? Send me your Qs with #1Q and I\u2019ll answer a couple on video",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 71, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "22666011564056577",
    "text" : "How about some good old fashioned First Question? Send me your Qs with #1Q and I\u2019ll answer a couple on video",
    "id" : 22666011564056577,
    "created_at" : "2011-01-05 14:49:32 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 22666195404595200,
  "created_at" : "2011-01-05 14:50:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDAgov",
      "indices" : [ 3, 11 ],
      "id_str" : "249715521",
      "id" : 249715521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22391011875495936",
  "text" : "RT @USDAgov: USDA Blog: USDA: A Look Back on 2010 http:\/\/bit.ly\/f9n6HW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "22012529538502656",
    "text" : "USDA Blog: USDA: A Look Back on 2010 http:\/\/bit.ly\/f9n6HW",
    "id" : 22012529538502656,
    "created_at" : "2011-01-03 19:32:50 +0000",
    "user" : {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "protected" : false,
      "id_str" : "61853389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475696751\/bf524afc612e7aa534d6c543a3d3e144_normal.jpeg",
      "id" : 61853389,
      "verified" : true
    }
  },
  "id" : 22391011875495936,
  "created_at" : "2011-01-04 20:36:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22382531961683970",
  "text" : "The First Family walks across the South Lawn after returning from Hawaii  http:\/\/twitpic.com\/3n1jbb",
  "id" : 22382531961683970,
  "created_at" : "2011-01-04 20:03:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22073193300762625",
  "text" : "Closer look at another move forward for the country being signed tomorrow: Food Safety Modernization Act http:\/\/ow.ly\/3xHVL",
  "id" : 22073193300762625,
  "created_at" : "2011-01-03 23:33:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22038455202611200",
  "text" : "RT @usedgov: Let's fix NCLB. Increase flexibility & fairness, invest in teachers, focus on schools & students most at risk. http:\/\/go.us ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "21935918013218816",
    "text" : "Let's fix NCLB. Increase flexibility & fairness, invest in teachers, focus on schools & students most at risk. http:\/\/go.usa.gov\/rDq",
    "id" : 21935918013218816,
    "created_at" : "2011-01-03 14:28:25 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 22038455202611200,
  "created_at" : "2011-01-03 21:15:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "questiontime",
      "indices" : [ 31, 44 ]
    }, {
      "text" : "hcr",
      "indices" : [ 48, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22027073711247360",
  "text" : "WH Blog's Top 10 of 2010: From #questiontime to #hcr to photos of the day, see what people read the most http:\/\/ow.ly\/3xCc4",
  "id" : 22027073711247360,
  "created_at" : "2011-01-03 20:30:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 24, 34 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "22018782155243520",
  "text" : "In case you missed it - @petesouza's favorite WH photos of 2010, with his intro: http:\/\/ow.ly\/3xB0t",
  "id" : 22018782155243520,
  "created_at" : "2011-01-03 19:57:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 115, 124 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitter",
      "indices" : [ 51, 59 ]
    }, {
      "text" : "1q",
      "indices" : [ 125, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21977233396604928",
  "text" : "RT @PressSec: Starting @ 1230EST I'll be answering #twitter ?'s for ~30mins, which you can send by replying to me, @PressSec #1q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 101, 110 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "twitter",
        "indices" : [ 37, 45 ]
      }, {
        "text" : "1q",
        "indices" : [ 111, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "21958994067193856",
    "text" : "Starting @ 1230EST I'll be answering #twitter ?'s for ~30mins, which you can send by replying to me, @PressSec #1q",
    "id" : 21958994067193856,
    "created_at" : "2011-01-03 16:00:06 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 21977233396604928,
  "created_at" : "2011-01-03 17:12:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21692695558750208",
  "text" : "RT @petesouza: Photo of potus signing 9\/11 health and compensation bill: http:\/\/bit.ly\/fhIH6T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "21686429864173569",
    "text" : "Photo of potus signing 9\/11 health and compensation bill: http:\/\/bit.ly\/fhIH6T",
    "id" : 21686429864173569,
    "created_at" : "2011-01-02 21:57:02 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 21692695558750208,
  "created_at" : "2011-01-02 22:21:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]