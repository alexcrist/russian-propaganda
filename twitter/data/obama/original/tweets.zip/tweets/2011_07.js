Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/97860891256696832\/photo\/1",
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/58D9gru",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AVur9k0CMAENgxS.jpg",
      "id_str" : "97860891260891137",
      "id" : 97860891260891137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AVur9k0CMAENgxS.jpg",
      "sizes" : [ {
        "h" : 356,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/58D9gru"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97860891256696832",
  "text" : "Photo: President Obama announces a bipartisan debt deal to reduce the deficit & avoid default in the Press Briefing Rm: http:\/\/t.co\/58D9gru",
  "id" : 97860891256696832,
  "created_at" : "2011-08-01 02:47:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/s6TPjxX",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/07\/31\/president-obama-speaks-support-bipartisan-deal-reduce-deficit-and-raise-debt-limit",
      "display_url" : "whitehouse.gov\/blog\/2011\/07\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "97852395542953984",
  "text" : "Tonight, President Obama spoke in support of a bipartisan deal to reduce the deficit & avoid default. Full remarks: http:\/\/t.co\/s6TPjxX",
  "id" : 97852395542953984,
  "created_at" : "2011-08-01 02:13:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97838940375089152",
  "text" : "RT @VP: I'm proud of the President.  Persistence.  Compromise makes a comeback.\u2014VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97838219797868544",
    "text" : "I'm proud of the President.  Persistence.  Compromise makes a comeback.\u2014VP",
    "id" : 97838219797868544,
    "created_at" : "2011-08-01 01:17:04 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 97838940375089152,
  "created_at" : "2011-08-01 01:19:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97830163731058688",
  "text" : "POTUS: I want to urge members of both parties to do the right thing and support this deal with your votes over the next few days.",
  "id" : 97830163731058688,
  "created_at" : "2011-08-01 00:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97829542672089088",
  "text" : "POTUS: 2nd part \"establishes a bipartisan committee of Congress to report back by Nov with a proposal to further reduce the deficit\"",
  "id" : 97829542672089088,
  "created_at" : "2011-08-01 00:42:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97829299456978945",
  "text" : "POTUS: 1st part of this agreement would cut about $1 trillion in spending over the next 10 years",
  "id" : 97829299456978945,
  "created_at" : "2011-08-01 00:41:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97829229898633216",
  "text" : "POTUS: I want to announce that the leaders of both parties ... have reached an agreement that will reduce the deficit and avoid default",
  "id" : 97829229898633216,
  "created_at" : "2011-08-01 00:41:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/qKVzPav",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "97827344705785856",
  "text" : "President Obama makes a statement in the WH briefing room ~8:40EDT -  Watch: http:\/\/t.co\/qKVzPav",
  "id" : 97827344705785856,
  "created_at" : "2011-08-01 00:33:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97717032203718657",
  "text" : "RT @pfeiffer44: Despite all the reporting, no deal has been reached, there are still impt issues to work out, and a lot of bad info is f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97712395190943744",
    "text" : "Despite all the reporting, no deal has been reached, there are still impt issues to work out, and a lot of bad info is floating out there",
    "id" : 97712395190943744,
    "created_at" : "2011-07-31 16:57:05 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 97717032203718657,
  "created_at" : "2011-07-31 17:15:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97418195878674432",
  "text" : "RT @pfeiffer44: Just to pass their bill by a single vote, the House GOP had to include a measure that would require us to amend the Cons ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97397812530122752",
    "text" : "Just to pass their bill by a single vote, the House GOP had to include a measure that would require us to amend the Constitution or default",
    "id" : 97397812530122752,
    "created_at" : "2011-07-30 20:07:02 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 97418195878674432,
  "created_at" : "2011-07-30 21:28:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97418116459528192",
  "text" : "RT @pfeiffer44: RE GOP presser: 1) Both McConnell and Reid have said there was no agreement 2)House GOP couldnt even pass the bill they  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97397118477676545",
    "text" : "RE GOP presser: 1) Both McConnell and Reid have said there was no agreement 2)House GOP couldnt even pass the bill they think was agreed to",
    "id" : 97397118477676545,
    "created_at" : "2011-07-30 20:04:17 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 97418116459528192,
  "created_at" : "2011-07-30 21:27:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 14, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/dA9mN88",
      "expanded_url" : "http:\/\/youtu.be\/x_jj2ru91sU",
      "display_url" : "youtu.be\/x_jj2ru91sU"
    } ]
  },
  "geo" : { },
  "id_str" : "97344134666403840",
  "text" : "\"The time for #compromise on behalf of the American people is now.\" -President Obama. Weekly Address: http:\/\/t.co\/dA9mN88",
  "id" : 97344134666403840,
  "created_at" : "2011-07-30 16:33:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/VPwp48W",
      "expanded_url" : "http:\/\/bit.ly\/odvHiG",
      "display_url" : "bit.ly\/odvHiG"
    } ]
  },
  "geo" : { },
  "id_str" : "97338380890804225",
  "text" : "RT @jesseclee44: House GOP under Bush: \"If you owe debts, pay debts\" \"Sometimes you've got to govern around here\" http:\/\/t.co\/VPwp48W vi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThinkProgress",
        "screen_name" : "thinkprogress",
        "indices" : [ 121, 135 ],
        "id_str" : "55355654",
        "id" : 55355654
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 116 ],
        "url" : "http:\/\/t.co\/VPwp48W",
        "expanded_url" : "http:\/\/bit.ly\/odvHiG",
        "display_url" : "bit.ly\/odvHiG"
      } ]
    },
    "geo" : { },
    "id_str" : "97334831129694208",
    "text" : "House GOP under Bush: \"If you owe debts, pay debts\" \"Sometimes you've got to govern around here\" http:\/\/t.co\/VPwp48W via @thinkprogress",
    "id" : 97334831129694208,
    "created_at" : "2011-07-30 15:56:46 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 97338380890804225,
  "created_at" : "2011-07-30 16:10:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 18, 27 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97130294733320192",
  "text" : "RT @jesseclee44: .@PressSec: \"yet another political exercise is behind us, w\/ time dwindling, leaders need to start working together\" ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 1, 10 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 136 ],
        "url" : "http:\/\/t.co\/EcQL34P",
        "expanded_url" : "http:\/\/1.usa.gov\/p0Zb7j",
        "display_url" : "1.usa.gov\/p0Zb7j"
      } ]
    },
    "geo" : { },
    "id_str" : "97088356596465664",
    "text" : ".@PressSec: \"yet another political exercise is behind us, w\/ time dwindling, leaders need to start working together\" http:\/\/t.co\/EcQL34P",
    "id" : 97088356596465664,
    "created_at" : "2011-07-29 23:37:22 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 97130294733320192,
  "created_at" : "2011-07-30 02:24:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97083820427329536",
  "text" : "RT @pfeiffer44: Reminder: Under the Boehner bill, we will be doing this all over again during the holidays, but we would need 2\/3 of the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97082550333353984",
    "text" : "Reminder: Under the Boehner bill, we will be doing this all over again during the holidays, but we would need 2\/3 of the House or we default",
    "id" : 97082550333353984,
    "created_at" : "2011-07-29 23:14:18 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 97083820427329536,
  "created_at" : "2011-07-29 23:19:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 120 ],
      "url" : "http:\/\/t.co\/pkcZa5G",
      "expanded_url" : "http:\/\/wh.gov\/r5x",
      "display_url" : "wh.gov\/r5x"
    } ]
  },
  "geo" : { },
  "id_str" : "97082069540274176",
  "text" : "Governors, mayors & elected officials urge Congress to #compromise on behalf of the American people: http:\/\/t.co\/pkcZa5G",
  "id" : 97082069540274176,
  "created_at" : "2011-07-29 23:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Johnson",
      "screen_name" : "KJ_MayorJohnson",
      "indices" : [ 57, 73 ],
      "id_str" : "16621525",
      "id" : 16621525
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sacramento",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 110 ],
      "url" : "http:\/\/t.co\/pkcZa5G",
      "expanded_url" : "http:\/\/wh.gov\/r5x",
      "display_url" : "wh.gov\/r5x"
    } ]
  },
  "geo" : { },
  "id_str" : "97081161288912896",
  "text" : "\"Enough with the politics. It\u2019s time to get this done.\" -@KJ_MayorJohnson, #Sacramento, CA http:\/\/t.co\/pkcZa5G",
  "id" : 97081161288912896,
  "created_at" : "2011-07-29 23:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 14, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http:\/\/t.co\/lBgSZ1O",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/2\/K0UXnARjd3g",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "97067405636927488",
  "text" : "\"The time for #compromise on behalf of the American people is now\" -President Obama http:\/\/t.co\/lBgSZ1O",
  "id" : 97067405636927488,
  "created_at" : "2011-07-29 22:14:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97060254373789696",
  "text" : "RT @pfeiffer44: House getting ready to vote on DOA bill that would damage the economy. Will the House leadership finally be ready to com ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97058698647707649",
    "text" : "House getting ready to vote on DOA bill that would damage the economy. Will the House leadership finally be ready to compromise now?",
    "id" : 97058698647707649,
    "created_at" : "2011-07-29 21:39:31 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 97060254373789696,
  "created_at" : "2011-07-29 21:45:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97050005168336896",
  "text" : "Time flies when you're tweeting. Need to run. Thanks for the questions. -Brian",
  "id" : 97050005168336896,
  "created_at" : "2011-07-29 21:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Raab",
      "screen_name" : "Praab",
      "indices" : [ 1, 7 ],
      "id_str" : "15474430",
      "id" : 15474430
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97049841745666048",
  "text" : ".@Praab 50% v misleading, doesn't incl taxes workers pay. When incl payroll taxes, # falls to 23%. Lower if incl sales, state\/local #WHChat",
  "id" : 97049841745666048,
  "created_at" : "2011-07-29 21:04:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kev",
      "screen_name" : "Kevgenus",
      "indices" : [ 1, 10 ],
      "id_str" : "53520290",
      "id" : 53520290
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/S6J0Oxu",
      "expanded_url" : "http:\/\/www.cbo.gov\/ftpdocs\/89xx\/doc8916\/01-15-Econ_Stimulus.pdf",
      "display_url" : "cbo.gov\/ftpdocs\/89xx\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "97048559282696192",
  "text" : ".@Kevgenus That's why CBO & others say UI is extremely cost-effective econ support, see p. 22 here: http:\/\/t.co\/S6J0Oxu  #WHChat",
  "id" : 97048559282696192,
  "created_at" : "2011-07-29 20:59:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kev",
      "screen_name" : "Kevgenus",
      "indices" : [ 1, 10 ],
      "id_str" : "53520290",
      "id" : 53520290
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97048085150171136",
  "text" : ".@Kevgenus UI payments to workers looking for jobs puts money directly into the economy bc those struggling are most likely to spend #WHChat",
  "id" : 97048085150171136,
  "created_at" : "2011-07-29 20:57:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kev",
      "screen_name" : "Kevgenus",
      "indices" : [ 1, 10 ],
      "id_str" : "53520290",
      "id" : 53520290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97047928224481281",
  "text" : ".@Kevgenus ok, calling an audible..this one requires a couple tweets",
  "id" : 97047928224481281,
  "created_at" : "2011-07-29 20:56:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kev",
      "screen_name" : "Kevgenus",
      "indices" : [ 3, 12 ],
      "id_str" : "53520290",
      "id" : 53520290
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97047123681492992",
  "text" : "RT @Kevgenus: @whitehouse #WHchat how does UI add jobs? Ur paying people to not work, WTF man?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "97046283252019200",
    "geo" : { },
    "id_str" : "97046563255353344",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #WHchat how does UI add jobs? Ur paying people to not work, WTF man?",
    "id" : 97046563255353344,
    "in_reply_to_status_id" : 97046283252019200,
    "created_at" : "2011-07-29 20:51:18 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Kev",
      "screen_name" : "Kevgenus",
      "protected" : false,
      "id_str" : "53520290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634870810398711808\/HMIIjHlX_normal.jpg",
      "id" : 53520290,
      "verified" : false
    }
  },
  "id" : 97047123681492992,
  "created_at" : "2011-07-29 20:53:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 58 ],
      "url" : "http:\/\/t.co\/UxsnEcL",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/infographics\/us-national-debt",
      "display_url" : "whitehouse.gov\/infographics\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "97046721762304000",
  "text" : ".@jpe2209 good call, take a look here: http:\/\/t.co\/UxsnEcL #WHChat",
  "id" : 97046721762304000,
  "created_at" : "2011-07-29 20:51:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97046541893763072",
  "text" : "RT @jpe2209: When POTUS says debt ceiling is to cover \"bills already racked up by Congress,\" why not enumerate?  Iraq war, Part D, etc.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97044851350183936",
    "text" : "When POTUS says debt ceiling is to cover \"bills already racked up by Congress,\" why not enumerate?  Iraq war, Part D, etc.  #WHChat",
    "id" : 97044851350183936,
    "created_at" : "2011-07-29 20:44:30 +0000",
    "user" : {
      "name" : "JP Ellen",
      "screen_name" : "JPEllen44",
      "protected" : false,
      "id_str" : "22257560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2875138601\/3eab2730a33dee8e4dfadb39d2332cee_normal.png",
      "id" : 22257560,
      "verified" : false
    }
  },
  "id" : 97046541893763072,
  "created_at" : "2011-07-29 20:51:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Twomey",
      "screen_name" : "RunninCandidate",
      "indices" : [ 1, 17 ],
      "id_str" : "193318994",
      "id" : 193318994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97046283252019200",
  "text" : ".@RunninCandidate they're related; LT debt plan raises confidence, but need econ boost now w\/payroll tax cut, UI & infrastructure #WHChat",
  "id" : 97046283252019200,
  "created_at" : "2011-07-29 20:50:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnyx6",
      "indices" : [ 1, 9 ],
      "id_str" : "343455117",
      "id" : 343455117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97044593652150272",
  "text" : ".@johnyx6 good question, but it would make tiny dent and SPR needs to be protected for supply disruptions that threaten our economy #WHChat",
  "id" : 97044593652150272,
  "created_at" : "2011-07-29 20:43:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnyx6",
      "indices" : [ 3, 11 ],
      "id_str" : "343455117",
      "id" : 343455117
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97044309475463168",
  "text" : "RT @johnyx6: @whitehouse #WHChat Can we sell 250mil barrels of SPR @ 100 a barrel to pay off debt?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "97042714767527936",
    "geo" : { },
    "id_str" : "97044154374303744",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #WHChat Can we sell 250mil barrels of SPR @ 100 a barrel to pay off debt?",
    "id" : 97044154374303744,
    "in_reply_to_status_id" : 97042714767527936,
    "created_at" : "2011-07-29 20:41:44 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "John",
      "screen_name" : "johnyx6",
      "protected" : false,
      "id_str" : "343455117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3389227510\/5eecd2974d052249a88069a03208e964_normal.jpeg",
      "id" : 343455117,
      "verified" : false
    }
  },
  "id" : 97044309475463168,
  "created_at" : "2011-07-29 20:42:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steven beckett",
      "screen_name" : "sjlbeckett",
      "indices" : [ 1, 12 ],
      "id_str" : "70938438",
      "id" : 70938438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 81, 92 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97043745714876416",
  "text" : ".@sjlbeckett totally understand the frustration. We're pushing on all angles for #compromise and a reasonable solution here #WHChat",
  "id" : 97043745714876416,
  "created_at" : "2011-07-29 20:40:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "steven beckett",
      "screen_name" : "sjlbeckett",
      "indices" : [ 3, 14 ],
      "id_str" : "70938438",
      "id" : 70938438
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97043515141398528",
  "text" : "RT @sjlbeckett: @whitehouse this situation is very discouraging when will our politicians wakeup and work together? It'shard enough for  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97042929180360704",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse this situation is very discouraging when will our politicians wakeup and work together? It'shard enough for the people! #whchat",
    "id" : 97042929180360704,
    "created_at" : "2011-07-29 20:36:51 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "steven beckett",
      "screen_name" : "sjlbeckett",
      "protected" : false,
      "id_str" : "70938438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1347669306\/Steven_Jonathon_Lewis_Beckett_normal.jpeg",
      "id" : 70938438,
      "verified" : false
    }
  },
  "id" : 97043515141398528,
  "created_at" : "2011-07-29 20:39:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Bullock",
      "screen_name" : "MarcosBullock",
      "indices" : [ 1, 15 ],
      "id_str" : "139282864",
      "id" : 139282864
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97043384698540032",
  "text" : ".@MarcosBullock POTUS thinks we need more tightening in all areas of the budget - that has to include defense as well #WHChat",
  "id" : 97043384698540032,
  "created_at" : "2011-07-29 20:38:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcos Bullock",
      "screen_name" : "MarcosBullock",
      "indices" : [ 3, 17 ],
      "id_str" : "139282864",
      "id" : 139282864
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97043124135804928",
  "text" : "RT @MarcosBullock: @whitehouse Whys Pres threatening budget cuts everywhere but military presence in foreign continents? Wars worth tank ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "97040767972945920",
    "geo" : { },
    "id_str" : "97042839174782976",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Whys Pres threatening budget cuts everywhere but military presence in foreign continents? Wars worth tanking US economy? #WHchat",
    "id" : 97042839174782976,
    "in_reply_to_status_id" : 97040767972945920,
    "created_at" : "2011-07-29 20:36:30 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Marcos Bullock",
      "screen_name" : "MarcosBullock",
      "protected" : false,
      "id_str" : "139282864",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2758964247\/76bba6b0e361dfc2bc1a1f32db87da1c_normal.jpeg",
      "id" : 139282864,
      "verified" : false
    }
  },
  "id" : 97043124135804928,
  "created_at" : "2011-07-29 20:37:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave ingrum",
      "screen_name" : "brianshand",
      "indices" : [ 1, 12 ],
      "id_str" : "440505387",
      "id" : 440505387
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97042714767527936",
  "text" : ".@BrianSHand What POTUS wants = return high-income tax rates to Clinton-era levels, when wealthiest & middle class did quite well #WHChat",
  "id" : 97042714767527936,
  "created_at" : "2011-07-29 20:36:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave ingrum",
      "screen_name" : "brianshand",
      "indices" : [ 3, 14 ],
      "id_str" : "440505387",
      "id" : 440505387
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97042054068183040",
  "text" : "RT @BrianSHand: #WHchat Could you tell us how increasing taxes on those who already pay the most is fair?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97041834945150976",
    "text" : "#WHchat Could you tell us how increasing taxes on those who already pay the most is fair?",
    "id" : 97041834945150976,
    "created_at" : "2011-07-29 20:32:31 +0000",
    "user" : {
      "name" : "The Hand",
      "screen_name" : "TheHand77",
      "protected" : false,
      "id_str" : "88034359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502162754728230913\/q577GevU_normal.jpeg",
      "id" : 88034359,
      "verified" : false
    }
  },
  "id" : 97042054068183040,
  "created_at" : "2011-07-29 20:33:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregory R. Wood",
      "screen_name" : "TwtrWoodman",
      "indices" : [ 1, 13 ],
      "id_str" : "41357197",
      "id" : 41357197
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 52, 57 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97040767972945920",
  "text" : ".@TwtrWoodman under Clinton-era tax rates, saw 23+m #jobs and rising incomes; post-Bush tax cuts, saw weak period of job growth #WHChat",
  "id" : 97040767972945920,
  "created_at" : "2011-07-29 20:28:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/97040593879965696\/photo\/1",
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/xBTeC5K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AVjB5-8CIAITJgP.jpg",
      "id_str" : "97040593879965698",
      "id" : 97040593879965698,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AVjB5-8CIAITJgP.jpg",
      "sizes" : [ {
        "h" : 546,
        "resize" : "fit",
        "w" : 820
      }, {
        "h" : 546,
        "resize" : "fit",
        "w" : 820
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xBTeC5K"
    } ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 54, 59 ]
    }, {
      "text" : "whchat",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97040593879965696",
  "text" : "Pic: Brian Deese from NEC is back answering Qs on the #debt debate for WH Office Hours. Use #whchat to join the Q&A. http:\/\/t.co\/xBTeC5K",
  "id" : 97040593879965696,
  "created_at" : "2011-07-29 20:27:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Allen",
      "screen_name" : "allencw",
      "indices" : [ 1, 9 ],
      "id_str" : "14230401",
      "id" : 14230401
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http:\/\/t.co\/Nv66adm",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2011\/04\/13\/fact-sheet-presidents-framework-shared-prosperity-and-shared-fiscal-resp",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "97039954919686144",
  "text" : ".@allencw I'm sighing with you, man. You can disagree with it, but it's there (for a 4th time): http:\/\/t.co\/Nv66adm #WHChat",
  "id" : 97039954919686144,
  "created_at" : "2011-07-29 20:25:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lisalindo",
      "screen_name" : "lisalindo",
      "indices" : [ 1, 11 ],
      "id_str" : "16173008",
      "id" : 16173008
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 119, 124 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97039642183991296",
  "text" : ".@lisalindo emergency air traffic ctrl in place, but bc congress hasn't acted, 4k workers furloughed & 10ks construct. #jobs halted #WHChat",
  "id" : 97039642183991296,
  "created_at" : "2011-07-29 20:23:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lisalindo",
      "screen_name" : "lisalindo",
      "indices" : [ 3, 13 ],
      "id_str" : "16173008",
      "id" : 16173008
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97038871958786049",
  "text" : "RT @lisalindo: @Whitehouse #WHchat Dear Brian - is it true FAA funding has been blocked? Are they still watching the skies?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97038462913495040",
    "in_reply_to_user_id" : 30313925,
    "text" : "@Whitehouse #WHchat Dear Brian - is it true FAA funding has been blocked? Are they still watching the skies?",
    "id" : 97038462913495040,
    "created_at" : "2011-07-29 20:19:07 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "lisalindo",
      "screen_name" : "lisalindo",
      "protected" : false,
      "id_str" : "16173008",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000097023239\/e64c7b6ec919f597835207123687bd16_normal.jpeg",
      "id" : 16173008,
      "verified" : false
    }
  },
  "id" : 97038871958786049,
  "created_at" : "2011-07-29 20:20:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hilary wilson",
      "screen_name" : "hilaryrwilson",
      "indices" : [ 1, 15 ],
      "id_str" : "32265049",
      "id" : 32265049
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97038829860552705",
  "text" : ".@hilaryrwilson POTUS this AM said he'd be working through the wkd; we all will be 2. Gotta get it done, country cant afford not to #WHChat",
  "id" : 97038829860552705,
  "created_at" : "2011-07-29 20:20:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex P Keaton",
      "screen_name" : "I_Hate_Hippies",
      "indices" : [ 1, 16 ],
      "id_str" : "160358278",
      "id" : 160358278
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 56 ],
      "url" : "http:\/\/t.co\/Nv66adm",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2011\/04\/13\/fact-sheet-presidents-framework-shared-prosperity-and-shared-fiscal-resp",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    }, {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/CstTHmn",
      "expanded_url" : "http:\/\/www.cbo.gov\/doc.cfm?index=12353",
      "display_url" : "cbo.gov\/doc.cfm?index=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "97037918153080832",
  "text" : ".@I_Hate_Hippies For POTUS plan see: http:\/\/t.co\/Nv66adm. For specific details on Reid and Boehner, see: http:\/\/t.co\/CstTHmn #WHChat",
  "id" : 97037918153080832,
  "created_at" : "2011-07-29 20:16:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex P Keaton",
      "screen_name" : "I_Hate_Hippies",
      "indices" : [ 3, 18 ],
      "id_str" : "160358278",
      "id" : 160358278
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97037865447460864",
  "text" : "RT @I_Hate_Hippies: .@whitehouse Where is Obama's debt plan? Where is Reid's plan? Why have Ryan's and Boehner's plans been shot down wi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97036923704586241",
    "text" : ".@whitehouse Where is Obama's debt plan? Where is Reid's plan? Why have Ryan's and Boehner's plans been shot down without votes? #WHChat",
    "id" : 97036923704586241,
    "created_at" : "2011-07-29 20:13:00 +0000",
    "user" : {
      "name" : "Alex P Keaton",
      "screen_name" : "I_Hate_Hippies",
      "protected" : false,
      "id_str" : "160358278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787417020534972416\/Td0ujTHu_normal.jpg",
      "id" : 160358278,
      "verified" : false
    }
  },
  "id" : 97037865447460864,
  "created_at" : "2011-07-29 20:16:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 121, 132 ]
    }, {
      "text" : "WHCHat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97037037013700608",
  "text" : ".@Tremenda1530 recent economic crisis devastated 401k savings; just digging out now. Can't afford more uncertainty; need #compromise #WHCHat",
  "id" : 97037037013700608,
  "created_at" : "2011-07-29 20:13:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "401Ks",
      "indices" : [ 58, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97036521462431745",
  "text" : "RT @Tremenda1530: #WHChat if market goes down, what about #401Ks of so many who have little or no savings Question from Mr. Jay in McAllen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "401Ks",
        "indices" : [ 40, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97036303010504704",
    "text" : "#WHChat if market goes down, what about #401Ks of so many who have little or no savings Question from Mr. Jay in McAllen",
    "id" : 97036303010504704,
    "created_at" : "2011-07-29 20:10:32 +0000",
    "user" : {
      "name" : "Uvn America McAllen",
      "screen_name" : "UvnAmericaMCA",
      "protected" : false,
      "id_str" : "59520066",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3189578830\/d8381a83e0910aa1157b68883f559a5d_normal.png",
      "id" : 59520066,
      "verified" : false
    }
  },
  "id" : 97036521462431745,
  "created_at" : "2011-07-29 20:11:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Shermer",
      "screen_name" : "spreaditaround",
      "indices" : [ 1, 16 ],
      "id_str" : "105207162",
      "id" : 105207162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97036445562318848",
  "text" : ".@spreaditaround Made tough decisions already ie freezing federal pay; can do more eg selling surplus property, contracting reform #WHChat",
  "id" : 97036445562318848,
  "created_at" : "2011-07-29 20:11:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Shermer",
      "screen_name" : "spreaditaround",
      "indices" : [ 3, 18 ],
      "id_str" : "105207162",
      "id" : 105207162
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97035957953495040",
  "text" : "RT @spreaditaround: @whitehouse Why don't we hear about cutting overhead in Washington (govt salaries, needless govt spending, etc.) in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "97034786404696064",
    "geo" : { },
    "id_str" : "97035587177037825",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Why don't we hear about cutting overhead in Washington (govt salaries, needless govt spending, etc.) in these talks? #WHChat",
    "id" : 97035587177037825,
    "in_reply_to_status_id" : 97034786404696064,
    "created_at" : "2011-07-29 20:07:41 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Matt Shermer",
      "screen_name" : "spreaditaround",
      "protected" : false,
      "id_str" : "105207162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/647226911\/Cool20Image68_normal.jpg",
      "id" : 105207162,
      "verified" : false
    }
  },
  "id" : 97035957953495040,
  "created_at" : "2011-07-29 20:09:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97035726817984512",
  "text" : ".@GeoffBurr sorry if that was confusing - Brian Deese here, answering questions as part of White House office hours... #WHChat",
  "id" : 97035726817984512,
  "created_at" : "2011-07-29 20:08:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John McGrath",
      "screen_name" : "JP_McGrath",
      "indices" : [ 1, 12 ],
      "id_str" : "614528682",
      "id" : 614528682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97035449838747648",
  "text" : ".@JP_McGrath don't want to predict market precisely, but impact on interest rates, confidence, econ activity will all be very bad #WHChat",
  "id" : 97035449838747648,
  "created_at" : "2011-07-29 20:07:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 48, 55 ]
    }, {
      "text" : "p2",
      "indices" : [ 80, 83 ]
    }, {
      "text" : "tcot",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "debt",
      "indices" : [ 109, 114 ]
    }, {
      "text" : "compromise",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97035401461641216",
  "text" : "Looking forward to a broad range of ?'s in this #WHChat, so I hope we hear from #p2 & #tcot perspectives abt #debt & #compromise",
  "id" : 97035401461641216,
  "created_at" : "2011-07-29 20:06:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97034786404696064",
  "text" : "It's Brian, I am here now. Ready for your questions. #WHChat",
  "id" : 97034786404696064,
  "created_at" : "2011-07-29 20:04:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 90, 95 ]
    }, {
      "text" : "whchat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97025444741783552",
  "text" : "More Office Hours today -- NEC's Brian Deese will be here @ 4ET to answers more Qs on the #debt debate & economy. Ask now w\/ #whchat",
  "id" : 97025444741783552,
  "created_at" : "2011-07-29 19:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 118 ],
      "url" : "http:\/\/t.co\/kyFqdEM",
      "expanded_url" : "http:\/\/wh.gov\/rXR",
      "display_url" : "wh.gov\/rXR"
    } ]
  },
  "geo" : { },
  "id_str" : "97008879405244416",
  "text" : "INFOGRAPHIC: By 2025, all new cars & light trucks built in America will get 54.5 miles per gallon: http:\/\/t.co\/kyFqdEM",
  "id" : 97008879405244416,
  "created_at" : "2011-07-29 18:21:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 35, 46 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "New York Daily News",
      "screen_name" : "NYDailyNews",
      "indices" : [ 96, 108 ],
      "id_str" : "9763482",
      "id" : 9763482
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http:\/\/t.co\/G6BACwQ",
      "expanded_url" : "http:\/\/www.nydailynews.com\/tech_guide\/2011\/07\/29\/2011-07-29_power_to_the_tweeple_white_house_holds_twitter_office_hours_obama_tells_nation_t.html",
      "display_url" : "nydailynews.com\/tech_guide\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "97008304919810048",
  "text" : "RT @macon44: Power to the Tweeple: @WhiteHouse holds Twitter 'office hours' http:\/\/t.co\/G6BACwQ @nydailynews",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 22, 33 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "New York Daily News",
        "screen_name" : "NYDailyNews",
        "indices" : [ 83, 95 ],
        "id_str" : "9763482",
        "id" : 9763482
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 82 ],
        "url" : "http:\/\/t.co\/G6BACwQ",
        "expanded_url" : "http:\/\/www.nydailynews.com\/tech_guide\/2011\/07\/29\/2011-07-29_power_to_the_tweeple_white_house_holds_twitter_office_hours_obama_tells_nation_t.html",
        "display_url" : "nydailynews.com\/tech_guide\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "97006353347907584",
    "text" : "Power to the Tweeple: @WhiteHouse holds Twitter 'office hours' http:\/\/t.co\/G6BACwQ @nydailynews",
    "id" : 97006353347907584,
    "created_at" : "2011-07-29 18:11:31 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 97008304919810048,
  "created_at" : "2011-07-29 18:19:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaveAward",
      "indices" : [ 14, 24 ]
    }, {
      "text" : "gov20",
      "indices" : [ 112, 118 ]
    }, {
      "text" : "cuttingwaste",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97008278550220800",
  "text" : "RT @OMBPress: #SaveAward: 16,162 entries and counting. Fed employees: make your voices heard, http:\/\/wh.gov\/rIR #gov20 #cuttingwaste",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SaveAward",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "gov20",
        "indices" : [ 98, 104 ]
      }, {
        "text" : "cuttingwaste",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97007861527347201",
    "text" : "#SaveAward: 16,162 entries and counting. Fed employees: make your voices heard, http:\/\/wh.gov\/rIR #gov20 #cuttingwaste",
    "id" : 97007861527347201,
    "created_at" : "2011-07-29 18:17:31 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 97008278550220800,
  "created_at" : "2011-07-29 18:19:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/kyFqdEM",
      "expanded_url" : "http:\/\/wh.gov\/rXR",
      "display_url" : "wh.gov\/rXR"
    } ]
  },
  "geo" : { },
  "id_str" : "96980594478686208",
  "text" : "Obama announces new fuel economy standards to save consumers $, reduce oil dependence & protect the environment: http:\/\/t.co\/kyFqdEM",
  "id" : 96980594478686208,
  "created_at" : "2011-07-29 16:29:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 86, 97 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96970651499372544",
  "text" : "Thanks for all the questions, need to go back to working to get out of this mess with #compromise. Brian Deese will be back at 4pm. #WHchat",
  "id" : 96970651499372544,
  "created_at" : "2011-07-29 15:49:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Secular Southerner",
      "screen_name" : "SecularSouthern",
      "indices" : [ 1, 17 ],
      "id_str" : "2166734960",
      "id" : 2166734960
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96970281574342656",
  "text" : ".@SecularSouthern: any increase in interest rates is a tax increase on all. Would happen if we default or don't solve our debt. #WHchat",
  "id" : 96970281574342656,
  "created_at" : "2011-07-29 15:48:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Vega",
      "screen_name" : "LadyDititi",
      "indices" : [ 1, 12 ],
      "id_str" : "244839144",
      "id" : 244839144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96969831835897856",
  "text" : ".@LadyDititi: Yes, as banks repay goes to reduce the deficit. #WHchat",
  "id" : 96969831835897856,
  "created_at" : "2011-07-29 15:46:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Vega",
      "screen_name" : "LadyDititi",
      "indices" : [ 3, 14 ],
      "id_str" : "244839144",
      "id" : 244839144
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96969566881726464",
  "text" : "RT @LadyDititi: @whitehouse Was the TARP money you guys claimed was repaid, ever applied to bring down the deficit as was required by la ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 123, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96967893354430464",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Was the TARP money you guys claimed was repaid, ever applied to bring down the deficit as was required by law? #WHchat",
    "id" : 96967893354430464,
    "created_at" : "2011-07-29 15:38:42 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Diana Vega",
      "screen_name" : "LadyDititi",
      "protected" : false,
      "id_str" : "244839144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1566054901\/titi_pic_normal.jpg",
      "id" : 244839144,
      "verified" : false
    }
  },
  "id" : 96969566881726464,
  "created_at" : "2011-07-29 15:45:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/96969148088856576\/photo\/1",
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/uY1uYhc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AViA7SpCMAAdzAC.jpg",
      "id_str" : "96969148093050880",
      "id" : 96969148093050880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AViA7SpCMAAdzAC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 493
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uY1uYhc"
    } ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 50, 55 ]
    }, {
      "text" : "whchat",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96969148088856576",
  "text" : "Pic: Jason Furman from NEC is here answering your #debt debate Qs during WH Office Hours. Use #whchat to join the Q&A. http:\/\/t.co\/uY1uYhc",
  "id" : 96969148088856576,
  "created_at" : "2011-07-29 15:43:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Winslow",
      "screen_name" : "winslowkate",
      "indices" : [ 1, 13 ],
      "id_str" : "158496418",
      "id" : 158496418
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 46 ],
      "url" : "http:\/\/t.co\/3f8zqm4",
      "expanded_url" : "http:\/\/wh.gov\/rkc",
      "display_url" : "wh.gov\/rkc"
    }, {
      "indices" : [ 58, 77 ],
      "url" : "http:\/\/t.co\/KEeUjNQ",
      "expanded_url" : "http:\/\/www.cbo.gov\/doc.cfm?index=12338",
      "display_url" : "cbo.gov\/doc.cfm?index=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96968741111349249",
  "text" : ".@winslowkate: POTUS plan: http:\/\/t.co\/3f8zqm4 Reid plan: http:\/\/t.co\/KEeUjNQ & willing to talk to anyone in Congress re more plans. #WHchat",
  "id" : 96968741111349249,
  "created_at" : "2011-07-29 15:42:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Winslow",
      "screen_name" : "winslowkate",
      "indices" : [ 3, 15 ],
      "id_str" : "158496418",
      "id" : 158496418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96967931627442176",
  "text" : "RT @winslowkate: I'm trying to remember what the WH plan is. Dem plan? Can't recall seeing either one. Get off the blame train and get t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96964699719086080",
    "text" : "I'm trying to remember what the WH plan is. Dem plan? Can't recall seeing either one. Get off the blame train and get to work. #WHchat",
    "id" : 96964699719086080,
    "created_at" : "2011-07-29 15:26:00 +0000",
    "user" : {
      "name" : "Kate Winslow",
      "screen_name" : "winslowkate",
      "protected" : false,
      "id_str" : "158496418",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2080359627\/madmen_icon3_normal",
      "id" : 158496418,
      "verified" : false
    }
  },
  "id" : 96967931627442176,
  "created_at" : "2011-07-29 15:38:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lance E. Jones",
      "screen_name" : "BoiOneDer",
      "indices" : [ 1, 11 ],
      "id_str" : "22875170",
      "id" : 22875170
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 120, 131 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96967762865438720",
  "text" : ".@BoiOneDer: POTUS wants revenue from loopholes\/high-income, needed to protect middle class. But to solve Tuesday, need #compromise. #WHchat",
  "id" : 96967762865438720,
  "created_at" : "2011-07-29 15:38:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96966647881019393",
  "text" : ".@NutellaMarissa: If Congress forces default, not enough $ 4 obligations, Treasury working on contingency plans, none of them good. #WHchat",
  "id" : 96966647881019393,
  "created_at" : "2011-07-29 15:33:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Mann",
      "screen_name" : "normdprune",
      "indices" : [ 1, 12 ],
      "id_str" : "66050720",
      "id" : 66050720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 119, 130 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96966103003176960",
  "text" : ".@normdprune: Not about blame, about solns. Reid bill has no upfront revenue, trlns of cuts, & still willing 2 do more #compromise. #WHchat",
  "id" : 96966103003176960,
  "created_at" : "2011-07-29 15:31:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Mann",
      "screen_name" : "normdprune",
      "indices" : [ 3, 14 ],
      "id_str" : "66050720",
      "id" : 66050720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96965382820216832",
  "text" : "RT @normdprune: No good options. Treasury working on least terrible contingency plans for the unthinkable. POTUS must #compromise, not b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "compromise",
        "indices" : [ 102, 113 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96965064929714176",
    "text" : "No good options. Treasury working on least terrible contingency plans for the unthinkable. POTUS must #compromise, not blame Bush #WHchat",
    "id" : 96965064929714176,
    "created_at" : "2011-07-29 15:27:27 +0000",
    "user" : {
      "name" : "Ernest Mann",
      "screen_name" : "normdprune",
      "protected" : false,
      "id_str" : "66050720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/364701527\/BeachFlag-250-72_normal.jpg",
      "id" : 66050720,
      "verified" : false
    }
  },
  "id" : 96965382820216832,
  "created_at" : "2011-07-29 15:28:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "s slash",
      "screen_name" : "squiggleslash",
      "indices" : [ 1, 15 ],
      "id_str" : "19825325",
      "id" : 19825325
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96965255414026240",
  "text" : ".@squiggleslash: Love macroeconomics (seriously), our focus is phasing in cuts. But w\/ no action could have downgrade, bad for jobs. #WHchat",
  "id" : 96965255414026240,
  "created_at" : "2011-07-29 15:28:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 119, 130 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96964552691949568",
  "text" : ".@AtSilva147: No good options. Treasury working on least terrible contingency plans for the unthinkable. Congress must #compromise. #WHchat",
  "id" : 96964552691949568,
  "created_at" : "2011-07-29 15:25:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Russell",
      "screen_name" : "FerociousBeast",
      "indices" : [ 1, 16 ],
      "id_str" : "6125642",
      "id" : 6125642
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96963913169649664",
  "text" : ".@FerociousBeast: Yes, Prez Bush was first time cut taxes while raising war spending. Regardless, must work together now to solve. #WHchat",
  "id" : 96963913169649664,
  "created_at" : "2011-07-29 15:22:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Russell",
      "screen_name" : "FerociousBeast",
      "indices" : [ 3, 18 ],
      "id_str" : "6125642",
      "id" : 6125642
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Nick Berardi",
      "screen_name" : "nberardi",
      "indices" : [ 32, 41 ],
      "id_str" : "13967832",
      "id" : 13967832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96963561816985600",
  "text" : "RT @FerociousBeast: @whitehouse @nberardi Wasn't Iraq and Afghanistan war spending done under emergency appropriation not part of annual ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Nick Berardi",
        "screen_name" : "nberardi",
        "indices" : [ 12, 21 ],
        "id_str" : "13967832",
        "id" : 13967832
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96963133591130112",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse @nberardi Wasn't Iraq and Afghanistan war spending done under emergency appropriation not part of annual budget process? #WHchat",
    "id" : 96963133591130112,
    "created_at" : "2011-07-29 15:19:47 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "John Russell",
      "screen_name" : "FerociousBeast",
      "protected" : false,
      "id_str" : "6125642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/18804352\/sand_normal.jpg",
      "id" : 6125642,
      "verified" : false
    }
  },
  "id" : 96963561816985600,
  "created_at" : "2011-07-29 15:21:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucas LaRose",
      "screen_name" : "LucasLaRose",
      "indices" : [ 1, 13 ],
      "id_str" : "22971912",
      "id" : 22971912
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96963280584720384",
  "text" : ".@LucasLaRose: Not about Ds\/Rs winning, abt country not losing. All wld lose if limit not raised now or if we repeated this in Dec. #WHchat",
  "id" : 96963280584720384,
  "created_at" : "2011-07-29 15:20:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Berardi",
      "screen_name" : "nberardi",
      "indices" : [ 1, 10 ],
      "id_str" : "13967832",
      "id" : 13967832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 109, 120 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96962570363211777",
  "text" : ".@nberardi: POTUS submitted budgets every yr since 09 & fiscal plan in Apr. Issue is not lack of ideas, need #compromise to move fwd #WHchat",
  "id" : 96962570363211777,
  "created_at" : "2011-07-29 15:17:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Berardi",
      "screen_name" : "nberardi",
      "indices" : [ 3, 12 ],
      "id_str" : "13967832",
      "id" : 13967832
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96961984234401792",
  "text" : "RT @nberardi: @whitehouse what effect has it had on the economy that congress hasn't passed a budget in 800 days? #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96961572580229120",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse what effect has it had on the economy that congress hasn't passed a budget in 800 days? #WHchat",
    "id" : 96961572580229120,
    "created_at" : "2011-07-29 15:13:35 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Nick Berardi",
      "screen_name" : "nberardi",
      "protected" : false,
      "id_str" : "13967832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745013062424461313\/03iBVX-r_normal.jpg",
      "id" : 13967832,
      "verified" : false
    }
  },
  "id" : 96961984234401792,
  "created_at" : "2011-07-29 15:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Rodovsky",
      "screen_name" : "nrodovsky",
      "indices" : [ 1, 11 ],
      "id_str" : "16553897",
      "id" : 16553897
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 33, 44 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96961815946338304",
  "text" : ".@nrodovsky: This is why we need #compromise. You should not face needless risks because Congress cannot get us out of this mess. #WHchat",
  "id" : 96961815946338304,
  "created_at" : "2011-07-29 15:14:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nicole Rodovsky",
      "screen_name" : "nrodovsky",
      "indices" : [ 3, 13 ],
      "id_str" : "16553897",
      "id" : 16553897
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SSI",
      "indices" : [ 34, 38 ]
    }, {
      "text" : "SSDI",
      "indices" : [ 41, 46 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96961611713093635",
  "text" : "RT @nrodovsky: @whitehouse I'm on #SSI & #SSDI, & live in low income housing. Will I receive my checks in August? Will I have rent? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SSI",
        "indices" : [ 19, 23 ]
      }, {
        "text" : "SSDI",
        "indices" : [ 26, 31 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 117, 124 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96958876037021696",
    "geo" : { },
    "id_str" : "96959789539663872",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse I'm on #SSI & #SSDI, & live in low income housing. Will I receive my checks in August? Will I have rent? #WHChat",
    "id" : 96959789539663872,
    "in_reply_to_status_id" : 96958876037021696,
    "created_at" : "2011-07-29 15:06:29 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Nicole Rodovsky",
      "screen_name" : "nrodovsky",
      "protected" : false,
      "id_str" : "16553897",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385154020\/e5bc942a15583d6b171594e7f0674f34_normal.png",
      "id" : 16553897,
      "verified" : false
    }
  },
  "id" : 96961611713093635,
  "created_at" : "2011-07-29 15:13:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Normoyle",
      "screen_name" : "johnnormoyle",
      "indices" : [ 1, 14 ],
      "id_str" : "22525842",
      "id" : 22525842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96961328903749632",
  "text" : ".@johnnormoyle: We are listening. Congress will too. Keep the questions and comments coming. #WHchat",
  "id" : 96961328903749632,
  "created_at" : "2011-07-29 15:12:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Normoyle",
      "screen_name" : "johnnormoyle",
      "indices" : [ 3, 16 ],
      "id_str" : "22525842",
      "id" : 22525842
    }, {
      "name" : "Anil Dash",
      "screen_name" : "anildash",
      "indices" : [ 21, 30 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 67, 78 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96961114130231297",
  "text" : "RT @johnnormoyle: RT @anildash: The president urged us to tweet, & @whitehouse is actually listening -- you should reply to them and use ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anil Dash",
        "screen_name" : "anildash",
        "indices" : [ 3, 12 ],
        "id_str" : "36823",
        "id" : 36823
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 49, 60 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96959602758922240",
    "text" : "RT @anildash: The president urged us to tweet, & @whitehouse is actually listening -- you should reply to them and use #WHchat;",
    "id" : 96959602758922240,
    "created_at" : "2011-07-29 15:05:45 +0000",
    "user" : {
      "name" : "John Normoyle",
      "screen_name" : "johnnormoyle",
      "protected" : false,
      "id_str" : "22525842",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730508220943339522\/183faWCA_normal.jpg",
      "id" : 22525842,
      "verified" : false
    }
  },
  "id" : 96961114130231297,
  "created_at" : "2011-07-29 15:11:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kimclift",
      "screen_name" : "kimcliftrn",
      "indices" : [ 1, 12 ],
      "id_str" : "18515571",
      "id" : 18515571
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Compromise",
      "indices" : [ 14, 25 ]
    }, {
      "text" : "compromise",
      "indices" : [ 59, 70 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96960967321198592",
  "text" : ".@kimcliftrn: #Compromise should not be a dirty word. Need #compromise to avoid immediate crisis and solve the debt problem. #WHchat",
  "id" : 96960967321198592,
  "created_at" : "2011-07-29 15:11:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kimclift",
      "screen_name" : "kimcliftrn",
      "indices" : [ 3, 14 ],
      "id_str" : "18515571",
      "id" : 18515571
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96960843354345472",
  "text" : "RT @kimcliftrn: @whitehouse  Don't make deals with the devil #WHchat  It will come back and burn you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 45, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96958842209972224",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse  Don't make deals with the devil #WHchat  It will come back and burn you.",
    "id" : 96958842209972224,
    "created_at" : "2011-07-29 15:02:44 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "kimclift",
      "screen_name" : "kimcliftrn",
      "protected" : false,
      "id_str" : "18515571",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453596138340225024\/reKfATC7_normal.jpeg",
      "id" : 18515571,
      "verified" : false
    }
  },
  "id" : 96960843354345472,
  "created_at" : "2011-07-29 15:10:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 23, 34 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96960388096212992",
  "text" : ".@TexansVsHunger: Yes, @Whitehouse is sticking up for low-income programs. Your support helps strengthen our case. #WHchat",
  "id" : 96960388096212992,
  "created_at" : "2011-07-29 15:08:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 46, 57 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96960346601951232",
  "text" : "RT @TexansVsHunger: In convos w\/ Congress, is @whitehouse sticking up for low-income programs like SNAP, TEFAP etc? Poor families have s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 26, 37 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96958419797422080",
    "text" : "In convos w\/ Congress, is @whitehouse sticking up for low-income programs like SNAP, TEFAP etc? Poor families have suffered enough. #whchat",
    "id" : 96958419797422080,
    "created_at" : "2011-07-29 15:01:03 +0000",
    "user" : {
      "name" : "Feeding Texas",
      "screen_name" : "FeedingTexas",
      "protected" : false,
      "id_str" : "18216422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511872207031529472\/E0cHlV64_normal.jpeg",
      "id" : 18216422,
      "verified" : false
    }
  },
  "id" : 96960346601951232,
  "created_at" : "2011-07-29 15:08:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shea Levy",
      "screen_name" : "shlevy",
      "indices" : [ 1, 8 ],
      "id_str" : "19820964",
      "id" : 19820964
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96960018871631872",
  "text" : ".@shlevy: US nearly alone in having debt ceiling. Congress decided how much 2 spend. Decided debt limit. Must raise to pay bills. #WHchat",
  "id" : 96960018871631872,
  "created_at" : "2011-07-29 15:07:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shea Levy",
      "screen_name" : "shlevy",
      "indices" : [ 3, 10 ],
      "id_str" : "19820964",
      "id" : 19820964
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96959996834758656",
  "text" : "RT @shlevy: .@whitehouse Why have a debt ceiling at all if we always just raise it when we reach it? #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 89, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96958585375948800",
    "text" : ".@whitehouse Why have a debt ceiling at all if we always just raise it when we reach it? #WHchat",
    "id" : 96958585375948800,
    "created_at" : "2011-07-29 15:01:42 +0000",
    "user" : {
      "name" : "Shea Levy",
      "screen_name" : "shlevy",
      "protected" : false,
      "id_str" : "19820964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2857840080\/0deab094c9c3795c2002720a4d64a855_normal.jpeg",
      "id" : 19820964,
      "verified" : false
    }
  },
  "id" : 96959996834758656,
  "created_at" : "2011-07-29 15:07:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Graeber",
      "screen_name" : "dan_graeber",
      "indices" : [ 1, 13 ],
      "id_str" : "124009544",
      "id" : 124009544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96959340384239616",
  "text" : ".@dan_graeber: Easier to get to 216 with Ds and Rs than just Rs alone. Compromise should not be a \"weird rule\" #WHchat",
  "id" : 96959340384239616,
  "created_at" : "2011-07-29 15:04:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Graeber",
      "screen_name" : "dan_graeber",
      "indices" : [ 3, 15 ],
      "id_str" : "124009544",
      "id" : 124009544
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96959301054234624",
  "text" : "RT @dan_graeber: @whitehouse is there a way for the GOP to cut Tea Party out by some weird rule to get the vote through? #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96956766864150528",
    "geo" : { },
    "id_str" : "96957657428140033",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse is there a way for the GOP to cut Tea Party out by some weird rule to get the vote through? #WHchat",
    "id" : 96957657428140033,
    "in_reply_to_status_id" : 96956766864150528,
    "created_at" : "2011-07-29 14:58:01 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Daniel Graeber",
      "screen_name" : "dan_graeber",
      "protected" : false,
      "id_str" : "124009544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796342922086125569\/_R49oPkn_normal.jpg",
      "id" : 124009544,
      "verified" : true
    }
  },
  "id" : 96959301054234624,
  "created_at" : "2011-07-29 15:04:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Jennifer Preston ",
      "screen_name" : "nyt_jenpreston",
      "indices" : [ 14, 29 ],
      "id_str" : "851372762",
      "id" : 851372762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 66, 77 ]
    }, {
      "text" : "compromise",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96959258633056256",
  "text" : "RT @macon44: .@NYT_JenPreston People responding to POTUS shld use #compromise. As he said, it is \"time for #compromise on behalf of the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jennifer Preston ",
        "screen_name" : "nyt_jenpreston",
        "indices" : [ 1, 16 ],
        "id_str" : "851372762",
        "id" : 851372762
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "compromise",
        "indices" : [ 53, 64 ]
      }, {
        "text" : "compromise",
        "indices" : [ 94, 105 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96956904894504960",
    "geo" : { },
    "id_str" : "96958702287990784",
    "in_reply_to_user_id" : 37759047,
    "text" : ".@NYT_JenPreston People responding to POTUS shld use #compromise. As he said, it is \"time for #compromise on behalf of the American people\"",
    "id" : 96958702287990784,
    "in_reply_to_status_id" : 96956904894504960,
    "created_at" : "2011-07-29 15:02:10 +0000",
    "in_reply_to_screen_name" : "JenniferPreston",
    "in_reply_to_user_id_str" : "37759047",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 96959258633056256,
  "created_at" : "2011-07-29 15:04:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy P",
      "screen_name" : "CharlieAndMe",
      "indices" : [ 1, 14 ],
      "id_str" : "28974585",
      "id" : 28974585
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96958876037021696",
  "text" : ".@CharlieAndMe: POTUS working hard to extend unemployment insurance. If it expires, more than 5 million would lose benefits. #WHChat",
  "id" : 96958876037021696,
  "created_at" : "2011-07-29 15:02:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy P",
      "screen_name" : "CharlieAndMe",
      "indices" : [ 3, 16 ],
      "id_str" : "28974585",
      "id" : 28974585
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96958862317469697",
  "text" : "RT @CharlieAndMe: #WHchat It has been over a yr that Obama has done nothing to help the 99ers. Is he content leaving us to die off like  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96957222449463296",
    "text" : "#WHchat It has been over a yr that Obama has done nothing to help the 99ers. Is he content leaving us to die off like road kill? We vote too",
    "id" : 96957222449463296,
    "created_at" : "2011-07-29 14:56:17 +0000",
    "user" : {
      "name" : "Cindy P",
      "screen_name" : "CharlieAndMe",
      "protected" : false,
      "id_str" : "28974585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744250675375243265\/M_w-J3MX_normal.jpg",
      "id" : 28974585,
      "verified" : false
    }
  },
  "id" : 96958862317469697,
  "created_at" : "2011-07-29 15:02:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hapahaoleboy",
      "screen_name" : "hapahaoleboy",
      "indices" : [ 1, 14 ],
      "id_str" : "12093462",
      "id" : 12093462
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http:\/\/t.co\/VvXIunK",
      "expanded_url" : "http:\/\/wh.gov\/rBp",
      "display_url" : "wh.gov\/rBp"
    } ]
  },
  "geo" : { },
  "id_str" : "96957922680111104",
  "text" : ".@hapahaoleboy: Chk out our graphic http:\/\/t.co\/VvXIunK, tells how we got here. But here now, need to come together to solve. #WHchat",
  "id" : 96957922680111104,
  "created_at" : "2011-07-29 14:59:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T.C.Kamdar",
      "screen_name" : "tckamdar",
      "indices" : [ 3, 12 ],
      "id_str" : "19066128",
      "id" : 19066128
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96957433393582080",
  "text" : "RT @tckamdar: #WHChat It would be immeasurably useful to have easy to understand graphics of key stats & pts from both Republican & WH p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96903712609533952",
    "text" : "#WHChat It would be immeasurably useful to have easy to understand graphics of key stats & pts from both Republican & WH proposals",
    "id" : 96903712609533952,
    "created_at" : "2011-07-29 11:23:40 +0000",
    "user" : {
      "name" : "T.C.Kamdar",
      "screen_name" : "tckamdar",
      "protected" : false,
      "id_str" : "19066128",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1167124827\/Photo_cropped_on_2010-02-11_normal.jpg",
      "id" : 19066128,
      "verified" : false
    }
  },
  "id" : 96957433393582080,
  "created_at" : "2011-07-29 14:57:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96957143806246912",
  "text" : ".@FacesPhotag: Good question. Which I had an answer. D and R Congresses raised dozens of times for D and R Presidents. #WHchat",
  "id" : 96957143806246912,
  "created_at" : "2011-07-29 14:55:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96956766864150528",
  "text" : "Hi, it's Jason Furman back to answer your questions on the President's remarks this morning or anything else economic. Use #WHchat",
  "id" : 96956766864150528,
  "created_at" : "2011-07-29 14:54:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96953597090217984",
  "text" : "POTUS: Our administration will continue to work with Democrats and Republicans all weekend long until we find a reach a solution.",
  "id" : 96953597090217984,
  "created_at" : "2011-07-29 14:41:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96953435492065281",
  "text" : "POTUS: \"I asked the American people to make their voice heard in this debate, and the response was overwhelming.  So please ... keep it up.\"",
  "id" : 96953435492065281,
  "created_at" : "2011-07-29 14:41:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96953213630169088",
  "text" : "POTUS: \"The power to solve this is in our hands.\"",
  "id" : 96953213630169088,
  "created_at" : "2011-07-29 14:40:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96953109686923264",
  "text" : "POTUS: make no mistake ... a lower credit rating would result in a tax increase on everyone in the form of higher interest rates",
  "id" : 96953109686923264,
  "created_at" : "2011-07-29 14:39:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96953047674142720",
  "text" : "POTUS: For the first time ever, we could lose our country\u2019s AAA credit rating ... because we didn\u2019t have a AAA political system to match.",
  "id" : 96953047674142720,
  "created_at" : "2011-07-29 14:39:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96952891528589312",
  "text" : "POTUS: \"There are still plenty of ways out of this mess.  But we are almost out of time.\"",
  "id" : 96952891528589312,
  "created_at" : "2011-07-29 14:39:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96952470609215488",
  "text" : "POTUS: \"What\u2019s clear now is that any solution to avoid default must be bipartisan.\"",
  "id" : 96952470609215488,
  "created_at" : "2011-07-29 14:37:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 45, 50 ]
    }, {
      "text" : "whchat",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "96952298349150208",
  "text" : "Happening now: President Obama speaks on the #debt debate. Watch: http:\/\/t.co\/hOlVdV1 Discuss: #whchat (we'll be livetweeting here)",
  "id" : 96952298349150208,
  "created_at" : "2011-07-29 14:36:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "96945926081486850",
  "text" : "Update on Office Hours: 1st session w\/ NEC staff will begin after the President's statement @ 10:20 ET: http:\/\/t.co\/hOlVdV1 #whchat",
  "id" : 96945926081486850,
  "created_at" : "2011-07-29 14:11:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAVEAward",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96942203313717248",
  "text" : "RT @OMBPress: 15K ideas submitted in \u201911 #SAVEAward. Last day for fed employees to submit cost-cutting ideas: www.whitehouse.gov\/save-aw ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SAVEAward",
        "indices" : [ 27, 37 ]
      }, {
        "text" : "cuttingwaste",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96930043774779392",
    "text" : "15K ideas submitted in \u201911 #SAVEAward. Last day for fed employees to submit cost-cutting ideas: www.whitehouse.gov\/save-award. #cuttingwaste",
    "id" : 96930043774779392,
    "created_at" : "2011-07-29 13:08:17 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 96942203313717248,
  "created_at" : "2011-07-29 13:56:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 94 ],
      "url" : "http:\/\/t.co\/qKVzPav",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    }, {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/L9YHWZO",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/07\/26\/white-house-office-hours",
      "display_url" : "whitehouse.gov\/blog\/2011\/07\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96936290460762114",
  "text" : "10:20amEDT President Obama makes stmt on debt ceiling negotiations. Live @ http:\/\/t.co\/qKVzPav Use #WHChat to discuss http:\/\/t.co\/L9YHWZO",
  "id" : 96936290460762114,
  "created_at" : "2011-07-29 13:33:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 58, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http:\/\/t.co\/1NH9ICV",
      "expanded_url" : "http:\/\/wh.gov\/r8O",
      "display_url" : "wh.gov\/r8O"
    } ]
  },
  "geo" : { },
  "id_str" : "96685690405912576",
  "text" : "CEA Chairman Austan Goolsbee on the need for high-skilled #immigration reform to make our economy stronger: http:\/\/t.co\/1NH9ICV",
  "id" : 96685690405912576,
  "created_at" : "2011-07-28 20:57:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96667201016315904",
  "text" : "Gotta run, thank for all the questions. We'll see you again tomorrow -Brian",
  "id" : 96667201016315904,
  "created_at" : "2011-07-28 19:43:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley McCully",
      "screen_name" : "TXTrendyChick",
      "indices" : [ 1, 15 ],
      "id_str" : "65120302",
      "id" : 65120302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96667043671179264",
  "text" : ".@TXTrendyChick. Health reform reduced deficit by &gt; $1tr over next 2 decades; repealing it would raise deficit by the same amt #WHChat",
  "id" : 96667043671179264,
  "created_at" : "2011-07-28 19:43:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashley McCully",
      "screen_name" : "TXTrendyChick",
      "indices" : [ 3, 17 ],
      "id_str" : "65120302",
      "id" : 65120302
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96666831607169025",
  "text" : "RT @TXTrendyChick: @whitehouse If Obamacare, sorry, Health Care Reform was repealed, what would that do to the numbers? #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96665652231815168",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse If Obamacare, sorry, Health Care Reform was repealed, what would that do to the numbers? #whchat",
    "id" : 96665652231815168,
    "created_at" : "2011-07-28 19:37:42 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Ashley McCully",
      "screen_name" : "TXTrendyChick",
      "protected" : false,
      "id_str" : "65120302",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550752186959806465\/KnU4oBXT_normal.jpeg",
      "id" : 65120302,
      "verified" : false
    }
  },
  "id" : 96666831607169025,
  "created_at" : "2011-07-28 19:42:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Schmeling",
      "screen_name" : "Joeschmeling",
      "indices" : [ 1, 14 ],
      "id_str" : "954798240",
      "id" : 954798240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96666508188581888",
  "text" : ".@joeschmeling while don't agree w\/every aspect, hugely impt & responsible framework - balanced, bipart; kind of big plan we need #WHChat",
  "id" : 96666508188581888,
  "created_at" : "2011-07-28 19:41:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Schmeling",
      "screen_name" : "Joeschmeling",
      "indices" : [ 3, 16 ],
      "id_str" : "954798240",
      "id" : 954798240
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96665992096251904",
  "text" : "RT @joeschmeling: @whitehouse What is the administrations thoughts\/position on the Simpson-Bowles Debt Reduction Committee's recommendat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 123, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96665719588143104",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse What is the administrations thoughts\/position on the Simpson-Bowles Debt Reduction Committee's recommendations #WHChat",
    "id" : 96665719588143104,
    "created_at" : "2011-07-28 19:37:58 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "jinsd",
      "screen_name" : "joeinsd6",
      "protected" : false,
      "id_str" : "43334576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3321217053\/5d8380f704a24016e5aca120a9d65c2b_normal.jpeg",
      "id" : 43334576,
      "verified" : false
    }
  },
  "id" : 96665992096251904,
  "created_at" : "2011-07-28 19:39:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BonerInSweatpants",
      "screen_name" : "McJeager",
      "indices" : [ 1, 10 ],
      "id_str" : "341102097",
      "id" : 341102097
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96665906746372096",
  "text" : ".@mcjeager Higher interest rates to start. Default would drive up rates across the board, for mortgages, cars, student & biz loans #WHChat",
  "id" : 96665906746372096,
  "created_at" : "2011-07-28 19:38:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BonerInSweatpants",
      "screen_name" : "McJeager",
      "indices" : [ 3, 12 ],
      "id_str" : "341102097",
      "id" : 341102097
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96665471016898561",
  "text" : "RT @McJeager: @whitehouse I am trying to buy a house. If this deal can't be reached will it affect the housing market? #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96632067365928960",
    "geo" : { },
    "id_str" : "96644308983234560",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse I am trying to buy a house. If this deal can't be reached will it affect the housing market? #whchat",
    "id" : 96644308983234560,
    "in_reply_to_status_id" : 96632067365928960,
    "created_at" : "2011-07-28 18:12:53 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "BonerInSweatpants",
      "screen_name" : "McJeager",
      "protected" : false,
      "id_str" : "341102097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000320761386\/50fcf8c87b842a6e2e11e1afe45df90b_normal.jpeg",
      "id" : 341102097,
      "verified" : false
    }
  },
  "id" : 96665471016898561,
  "created_at" : "2011-07-28 19:36:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimberly Nelson",
      "screen_name" : "nelsonkjh",
      "indices" : [ 1, 11 ],
      "id_str" : "48123882",
      "id" : 48123882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96664994745290752",
  "text" : ".@nelsonkjh On will it fail? all 53 D senators oppose and several senate Rs oppose as well, so yes. #WHchat",
  "id" : 96664994745290752,
  "created_at" : "2011-07-28 19:35:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zev Mo",
      "screen_name" : "StrongDems",
      "indices" : [ 1, 12 ],
      "id_str" : "119749813",
      "id" : 119749813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96664348881195010",
  "text" : ".@StrongDems can't afford to make that mistake again. Need short-term support from payroll tax cut & to phase in any deficit deal #WHChat",
  "id" : 96664348881195010,
  "created_at" : "2011-07-28 19:32:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zev Mo",
      "screen_name" : "StrongDems",
      "indices" : [ 3, 14 ],
      "id_str" : "119749813",
      "id" : 119749813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 24, 31 ]
    }, {
      "text" : "p2",
      "indices" : [ 123, 126 ]
    }, {
      "text" : "DebtCeiling",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96663785330315264",
  "text" : "RT @StrongDems: Dearest #WHchat, Are we on track to repeat the same mistakes of 1937 when we invested less in the economy? #p2 #DebtCeiling",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 8, 15 ]
      }, {
        "text" : "p2",
        "indices" : [ 107, 110 ]
      }, {
        "text" : "DebtCeiling",
        "indices" : [ 111, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96663530387939328",
    "text" : "Dearest #WHchat, Are we on track to repeat the same mistakes of 1937 when we invested less in the economy? #p2 #DebtCeiling",
    "id" : 96663530387939328,
    "created_at" : "2011-07-28 19:29:16 +0000",
    "user" : {
      "name" : "Zev Mo",
      "screen_name" : "StrongDems",
      "protected" : false,
      "id_str" : "119749813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1467803428\/strongdems-logo-twitter_normal.png",
      "id" : 119749813,
      "verified" : false
    }
  },
  "id" : 96663785330315264,
  "created_at" : "2011-07-28 19:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96663687145861121",
  "text" : ".@SpencerAdams90 If you mean should we be tightening the defense budget, answer is yes, needs to be part of a balanced approach #WHChat",
  "id" : 96663687145861121,
  "created_at" : "2011-07-28 19:29:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roberto Grigolli",
      "screen_name" : "gugaf1SP",
      "indices" : [ 1, 10 ],
      "id_str" : "55926768",
      "id" : 55926768
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96663245867335681",
  "text" : ".@gugaf1SP: Obama's preference is $4t balanced plan. But Reid plan is a fair downpayment & lifts uncertainty weighing on our economy #WHChat",
  "id" : 96663245867335681,
  "created_at" : "2011-07-28 19:28:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roberto Grigolli",
      "screen_name" : "gugaf1SP",
      "indices" : [ 3, 12 ],
      "id_str" : "55926768",
      "id" : 55926768
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96663021597900800",
  "text" : "RT @gugaf1SP: #WHChat Does Obama supports Harry Reid's proposal? Is there an exact deal that he supports at the momment or none that hav ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96662280430813184",
    "text" : "#WHChat Does Obama supports Harry Reid's proposal? Is there an exact deal that he supports at the momment or none that have come fourth?",
    "id" : 96662280430813184,
    "created_at" : "2011-07-28 19:24:18 +0000",
    "user" : {
      "name" : "Roberto Grigolli",
      "screen_name" : "gugaf1SP",
      "protected" : false,
      "id_str" : "55926768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1460542722\/_39097252_guga_300x245afp_normal.jpg",
      "id" : 55926768,
      "verified" : false
    }
  },
  "id" : 96663021597900800,
  "created_at" : "2011-07-28 19:27:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C B Miller",
      "screen_name" : "Jamion",
      "indices" : [ 1, 8 ],
      "id_str" : "21519094",
      "id" : 21519094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96662778986762241",
  "text" : ".@Jamion fixing prblm is hugely impt; but keeping cloud of uncertainty over economy isn't smart. We can cut deficit w\/o hurting our econ",
  "id" : 96662778986762241,
  "created_at" : "2011-07-28 19:26:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C B Miller",
      "screen_name" : "Jamion",
      "indices" : [ 3, 10 ],
      "id_str" : "21519094",
      "id" : 21519094
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96662215708516352",
  "text" : "RT @Jamion: @whitehouse If you just keep raising the debt ceiling without actually fixing the issue isn't that just making it worse? #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 121, 128 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96661158907482112",
    "geo" : { },
    "id_str" : "96661933113081858",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse If you just keep raising the debt ceiling without actually fixing the issue isn't that just making it worse? #WHchat",
    "id" : 96661933113081858,
    "in_reply_to_status_id" : 96661158907482112,
    "created_at" : "2011-07-28 19:22:55 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "C B Miller",
      "screen_name" : "Jamion",
      "protected" : false,
      "id_str" : "21519094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/82882321\/GhostintheShell-StandAloneComplex-SolidStateSociety11_normal.jpg",
      "id" : 21519094,
      "verified" : false
    }
  },
  "id" : 96662215708516352,
  "created_at" : "2011-07-28 19:24:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nathan evans",
      "screen_name" : "nathan_evans",
      "indices" : [ 1, 14 ],
      "id_str" : "1915232430",
      "id" : 1915232430
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96661420967591936",
  "text" : ".@Nathan_Evans GREAT question. Unfortunately I don't know the answer #WHChat",
  "id" : 96661420967591936,
  "created_at" : "2011-07-28 19:20:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Bell",
      "screen_name" : "Life_is_2_Short",
      "indices" : [ 1, 17 ],
      "id_str" : "27977114",
      "id" : 27977114
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96661158907482112",
  "text" : ".@Life_is_2_Short Tough challenge. Need stronger job growth to help lt unemployed. POTUS fought to extend UI in Dec and will again.  #WHChat",
  "id" : 96661158907482112,
  "created_at" : "2011-07-28 19:19:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Bell",
      "screen_name" : "Life_is_2_Short",
      "indices" : [ 3, 19 ],
      "id_str" : "27977114",
      "id" : 27977114
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96660379429638144",
  "text" : "RT @Life_is_2_Short: What will be done concerning the 99ers? #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 40, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96660183358509056",
    "text" : "What will be done concerning the 99ers? #WHchat",
    "id" : 96660183358509056,
    "created_at" : "2011-07-28 19:15:58 +0000",
    "user" : {
      "name" : "Tom Bell",
      "screen_name" : "Life_is_2_Short",
      "protected" : false,
      "id_str" : "27977114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/349703423\/Test-1_normal.jpg",
      "id" : 27977114,
      "verified" : false
    }
  },
  "id" : 96660379429638144,
  "created_at" : "2011-07-28 19:16:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chelsey waters",
      "screen_name" : "chelseywaters",
      "indices" : [ 1, 15 ],
      "id_str" : "49063064",
      "id" : 49063064
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96660275461230592",
  "text" : ".@chelseywaters: when Senate votes it down it'll reconfirm what we know -- we're at stalemate, and need reasonable compromise #WHChat",
  "id" : 96660275461230592,
  "created_at" : "2011-07-28 19:16:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96660005612298240",
  "text" : ".@mikehoward51: we take in only 60 cents for every dollar we owe, so if debt ceiling isn't raised we can't meet all our obligations #WHChat",
  "id" : 96660005612298240,
  "created_at" : "2011-07-28 19:15:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96659380036042752",
  "text" : "Brian here. Sorry to be late. Ready to take your questions... #WHChat",
  "id" : 96659380036042752,
  "created_at" : "2011-07-28 19:12:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 98, 106 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 49, 54 ]
    }, {
      "text" : "whchat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http:\/\/t.co\/Aur4Weh",
      "expanded_url" : "http:\/\/storify.com\/whitehouse\/office-hours-with",
      "display_url" : "storify.com\/whitehouse\/off\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96657318112010240",
  "text" : "Deese will be here soon to answer more Qs on the #debt debate. Office Hours w\/ Furman just posted @Storify: http:\/\/t.co\/Aur4Weh #whchat",
  "id" : 96657318112010240,
  "created_at" : "2011-07-28 19:04:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96646949410844672",
  "text" : "RT @jesseclee44: Boehner 7\/28: \"sincere honest effort to end the crisis in a bipartisan way\" 7\/27: \"Obama hates it Harry Reid hates it N ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96639874756644864",
    "text" : "Boehner 7\/28: \"sincere honest effort to end the crisis in a bipartisan way\" 7\/27: \"Obama hates it Harry Reid hates it Nancy Pelosi hates it\"",
    "id" : 96639874756644864,
    "created_at" : "2011-07-28 17:55:16 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 96646949410844672,
  "created_at" : "2011-07-28 18:23:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96640543114805248",
  "text" : "Goodbye all, Jason Furman signing off, looking forward to coming back tomorrow. Stay tuned for new media star Brian Deese @ 3pm. #WHchat",
  "id" : 96640543114805248,
  "created_at" : "2011-07-28 17:57:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Devereaux",
      "screen_name" : "DerekDevereaux",
      "indices" : [ 1, 16 ],
      "id_str" : "27266051",
      "id" : 27266051
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96640065178054657",
  "text" : ".@DerekDevereaux: POTUS signed 17 small biz tax cuts, wants more. Closing corp loopholes can cut deficit, corp rates & sml biz taxes #WHchat",
  "id" : 96640065178054657,
  "created_at" : "2011-07-28 17:56:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Devereaux",
      "screen_name" : "DerekDevereaux",
      "indices" : [ 3, 18 ],
      "id_str" : "27266051",
      "id" : 27266051
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96640001848258560",
  "text" : "RT @DerekDevereaux: @whitehouse what about cutting corporate tax loopholes but offering tax credit 2 small businesses 2 spur job growth? ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 117, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96638787202981888",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse what about cutting corporate tax loopholes but offering tax credit 2 small businesses 2 spur job growth? #WHchat",
    "id" : 96638787202981888,
    "created_at" : "2011-07-28 17:50:56 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Derek Devereaux",
      "screen_name" : "DerekDevereaux",
      "protected" : false,
      "id_str" : "27266051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784561077380116482\/Z0wV6QdY_normal.jpg",
      "id" : 27266051,
      "verified" : false
    }
  },
  "id" : 96640001848258560,
  "created_at" : "2011-07-28 17:55:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wrtheuer",
      "screen_name" : "wrtheuer",
      "indices" : [ 1, 10 ],
      "id_str" : "15990260",
      "id" : 15990260
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 12, 20 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96639311151247360",
  "text" : ".@wrtheuer: @twitter, of course! Seriously, many on both sides engaged in honest, serious discussion of tough issues #WHchat",
  "id" : 96639311151247360,
  "created_at" : "2011-07-28 17:53:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wrtheuer",
      "screen_name" : "wrtheuer",
      "indices" : [ 3, 12 ],
      "id_str" : "15990260",
      "id" : 15990260
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96639048763977728",
  "text" : "RT @wrtheuer: @WhiteHouse  Director Furman, how do you engage an opposition for whom facts, precedent and evidence are ignored? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 114, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96638258636795904",
    "in_reply_to_user_id" : 30313925,
    "text" : "@WhiteHouse  Director Furman, how do you engage an opposition for whom facts, precedent and evidence are ignored? #WHChat",
    "id" : 96638258636795904,
    "created_at" : "2011-07-28 17:48:50 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "wrtheuer",
      "screen_name" : "wrtheuer",
      "protected" : false,
      "id_str" : "15990260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1150541253\/back_porch_normal.jpg",
      "id" : 15990260,
      "verified" : false
    }
  },
  "id" : 96639048763977728,
  "created_at" : "2011-07-28 17:51:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Lane",
      "screen_name" : "davidslane",
      "indices" : [ 1, 12 ],
      "id_str" : "47408587",
      "id" : 47408587
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96638329356943360",
  "text" : ".@davidslane: +23 mil jobs in 90s, returning to those rates 4 households above $250k would not hurt & by cutting deficit would help #WHchat",
  "id" : 96638329356943360,
  "created_at" : "2011-07-28 17:49:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Lane",
      "screen_name" : "davidslane",
      "indices" : [ 3, 14 ],
      "id_str" : "47408587",
      "id" : 47408587
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96638285950099456",
  "text" : "RT @davidslane: #WHchat Once and for all - end the argument - do tax cuts spur growth? Last 30 years suggest tax cuts didn't help. 80s,  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96634677422587904",
    "text" : "#WHchat Once and for all - end the argument - do tax cuts spur growth? Last 30 years suggest tax cuts didn't help. 80s, 90s had good growth.",
    "id" : 96634677422587904,
    "created_at" : "2011-07-28 17:34:37 +0000",
    "user" : {
      "name" : "David Lane",
      "screen_name" : "davidslane",
      "protected" : false,
      "id_str" : "47408587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1253666388\/davidLane_normal.jpg",
      "id" : 47408587,
      "verified" : false
    }
  },
  "id" : 96638285950099456,
  "created_at" : "2011-07-28 17:48:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/96637771883618304\/photo\/1",
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/Z4FS6rw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AVdTiqECIAEXWWq.jpg",
      "id_str" : "96637771883618305",
      "id" : 96637771883618305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AVdTiqECIAEXWWq.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Z4FS6rw"
    } ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 55, 60 ]
    }, {
      "text" : "whchat",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96637771883618304",
  "text" : "Pic: Jason Furman from NEC is here answering Qs on the #debt debate for WH Office Hours. Use #whchat to join the Q&A. http:\/\/t.co\/Z4FS6rw",
  "id" : 96637771883618304,
  "created_at" : "2011-07-28 17:46:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stagger Lee",
      "screen_name" : "cardinalsupremo",
      "indices" : [ 1, 17 ],
      "id_str" : "332146159",
      "id" : 332146159
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96637092955832320",
  "text" : ".@cardinalsupremo: still confident will solve by Tue. No good answers post-Tue, we're working on how to best manage the impossible #WHchat",
  "id" : 96637092955832320,
  "created_at" : "2011-07-28 17:44:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stagger Lee",
      "screen_name" : "cardinalsupremo",
      "indices" : [ 3, 19 ],
      "id_str" : "332146159",
      "id" : 332146159
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96636969337102337",
  "text" : "RT @cardinalsupremo: @whitehouse #WHchat What will you do if there is not an agreement by Tuesday?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96633744168992768",
    "geo" : { },
    "id_str" : "96636354326306817",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #WHchat What will you do if there is not an agreement by Tuesday?",
    "id" : 96636354326306817,
    "in_reply_to_status_id" : 96633744168992768,
    "created_at" : "2011-07-28 17:41:16 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Stagger Lee",
      "screen_name" : "cardinalsupremo",
      "protected" : false,
      "id_str" : "332146159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1433542793\/imagesCA9LYL2Y_normal.jpg",
      "id" : 332146159,
      "verified" : false
    }
  },
  "id" : 96636969337102337,
  "created_at" : "2011-07-28 17:43:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ERIKK\u2122",
      "screen_name" : "Erikk_the_Dane",
      "indices" : [ 1, 16 ],
      "id_str" : "87311092",
      "id" : 87311092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96636474178547884",
  "text" : ".@Erikk_the_Dane: POTUS agrees. But prob no time left for big tax\/spend reforms. Need to set the groundwork for a balanced approach. #WHchat",
  "id" : 96636474178547884,
  "created_at" : "2011-07-28 17:41:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ERIKK\u2122",
      "screen_name" : "Erikk_the_Dane",
      "indices" : [ 3, 18 ],
      "id_str" : "87311092",
      "id" : 87311092
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96636464993017856",
  "text" : "RT @Erikk_the_Dane: @whitehouse DON'T approve deal that asks NOTHING of the richest in America (richer now than ever & paying lowest tax ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96634108633030656",
    "geo" : { },
    "id_str" : "96635353703784448",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse DON'T approve deal that asks NOTHING of the richest in America (richer now than ever & paying lowest tax rate in 80 yrs) #WHchat",
    "id" : 96635353703784448,
    "in_reply_to_status_id" : 96634108633030656,
    "created_at" : "2011-07-28 17:37:18 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "ERIKK\u2122",
      "screen_name" : "Erikk_the_Dane",
      "protected" : false,
      "id_str" : "87311092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2643223184\/1693eb47d58cdf3ce150c013091bdc77_normal.jpeg",
      "id" : 87311092,
      "verified" : false
    }
  },
  "id" : 96636464993017856,
  "created_at" : "2011-07-28 17:41:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Sharkey",
      "screen_name" : "Ryan3262",
      "indices" : [ 1, 10 ],
      "id_str" : "1099285506",
      "id" : 1099285506
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96635742251515904",
  "text" : ".@ryan3262: don't want to raise taxes on 150 million American workers next year, would happen if we don't extend payroll tax cut #WHchat",
  "id" : 96635742251515904,
  "created_at" : "2011-07-28 17:38:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin kilpatrick",
      "screen_name" : "erin_kilpatrick",
      "indices" : [ 1, 17 ],
      "id_str" : "755163346022858752",
      "id" : 755163346022858752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/iz03jvc",
      "expanded_url" : "http:\/\/www.treasury.gov\/resource-center\/data-chart-center\/tic\/Documents\/mfh.txt",
      "display_url" : "treasury.gov\/resource-cente\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96635147947999233",
  "text" : ".@erin_kilpatrick: anyone w\/Treasuries. You prob do 2, through savings accts, other retirement. +frgn holders: http:\/\/t.co\/iz03jvc #WHchat",
  "id" : 96635147947999233,
  "created_at" : "2011-07-28 17:36:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Morris",
      "screen_name" : "JLMonkeyToes",
      "indices" : [ 1, 14 ],
      "id_str" : "174677975",
      "id" : 174677975
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96634108633030656",
  "text" : ".@JLMonkeyToes: Agree #WHchat",
  "id" : 96634108633030656,
  "created_at" : "2011-07-28 17:32:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Morris",
      "screen_name" : "JLMonkeyToes",
      "indices" : [ 3, 16 ],
      "id_str" : "174677975",
      "id" : 174677975
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96634095932674048",
  "text" : "RT @JLMonkeyToes: @whitehouse compromise a necessity, but is cutting back social safety nets wise while unemployment & economic disparit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96633467118436352",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse compromise a necessity, but is cutting back social safety nets wise while unemployment & economic disparity up? #WHchat",
    "id" : 96633467118436352,
    "created_at" : "2011-07-28 17:29:48 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Jessica Morris",
      "screen_name" : "JLMonkeyToes",
      "protected" : false,
      "id_str" : "174677975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1670187110\/image_normal.jpg",
      "id" : 174677975,
      "verified" : false
    }
  },
  "id" : 96634095932674048,
  "created_at" : "2011-07-28 17:32:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96633744168992768",
  "text" : ".@jpe2209: Thanks, my first time tweeting but sadly not my first time (or I fear my last) combatting misinformation #WHchat",
  "id" : 96633744168992768,
  "created_at" : "2011-07-28 17:30:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Skydogz",
      "screen_name" : "skydogz",
      "indices" : [ 25, 33 ],
      "id_str" : "49094229",
      "id" : 49094229
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96633639114244096",
  "text" : "RT @jpe2209: @whitehouse @skydogz pointing to facts like this when replying to questioner helps combat misinformation.  Great job #WHchat !",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Skydogz",
        "screen_name" : "skydogz",
        "indices" : [ 12, 20 ],
        "id_str" : "49094229",
        "id" : 49094229
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 117, 124 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96629758305107968",
    "geo" : { },
    "id_str" : "96632960404561920",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse @skydogz pointing to facts like this when replying to questioner helps combat misinformation.  Great job #WHchat !",
    "id" : 96632960404561920,
    "in_reply_to_status_id" : 96629758305107968,
    "created_at" : "2011-07-28 17:27:47 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "JP Ellen",
      "screen_name" : "JPEllen44",
      "protected" : false,
      "id_str" : "22257560",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2875138601\/3eab2730a33dee8e4dfadb39d2332cee_normal.png",
      "id" : 22257560,
      "verified" : false
    }
  },
  "id" : 96633639114244096,
  "created_at" : "2011-07-28 17:30:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Smith",
      "screen_name" : "smittyfuel",
      "indices" : [ 1, 12 ],
      "id_str" : "27495218",
      "id" : 27495218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96633314630311936",
  "text" : ".@smittyfuel: Often ask myself that, making numbers add up on my spreadsheet not hard. Need compromise from Congress #WHchat",
  "id" : 96633314630311936,
  "created_at" : "2011-07-28 17:29:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Smith",
      "screen_name" : "smittyfuel",
      "indices" : [ 3, 14 ],
      "id_str" : "27495218",
      "id" : 27495218
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96633307877474304",
  "text" : "RT @smittyfuel: @whitehouse It all seems so simple, then why is this taking so long?  Politics seem to be dragging America straight into ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96630356526104576",
    "geo" : { },
    "id_str" : "96631640419344385",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse It all seems so simple, then why is this taking so long?  Politics seem to be dragging America straight into the ground. #WHchat",
    "id" : 96631640419344385,
    "in_reply_to_status_id" : 96630356526104576,
    "created_at" : "2011-07-28 17:22:33 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "David Smith",
      "screen_name" : "smittyfuel",
      "protected" : false,
      "id_str" : "27495218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746947372941344768\/YEF0U9xE_normal.jpg",
      "id" : 27495218,
      "verified" : false
    }
  },
  "id" : 96633307877474304,
  "created_at" : "2011-07-28 17:29:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam L. Barr",
      "screen_name" : "adamlbarr",
      "indices" : [ 1, 11 ],
      "id_str" : "22383514",
      "id" : 22383514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96632640475631616",
  "text" : ".@adamlbarr: POTUS wants payroll tax cut, unemp insure extended, cannot withdraw from econ next yr. Spending cuts shld be phased in. #WHchat",
  "id" : 96632640475631616,
  "created_at" : "2011-07-28 17:26:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam L. Barr",
      "screen_name" : "adamlbarr",
      "indices" : [ 3, 13 ],
      "id_str" : "22383514",
      "id" : 22383514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96632597102329856",
  "text" : "RT @adamlbarr: Why are we so focused on cutting government spending, when we need to be stimulating the economy to fuel the recovery? #W ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96631644378763264",
    "text" : "Why are we so focused on cutting government spending, when we need to be stimulating the economy to fuel the recovery? #WHchat",
    "id" : 96631644378763264,
    "created_at" : "2011-07-28 17:22:34 +0000",
    "user" : {
      "name" : "Adam L. Barr",
      "screen_name" : "adamlbarr",
      "protected" : false,
      "id_str" : "22383514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2754567778\/77d8b7694edb5f235b1a188f1e019041_normal.png",
      "id" : 22383514,
      "verified" : false
    }
  },
  "id" : 96632597102329856,
  "created_at" : "2011-07-28 17:26:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "audhilly",
      "screen_name" : "audhilly",
      "indices" : [ 1, 10 ],
      "id_str" : "8069492",
      "id" : 8069492
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96632067365928960",
  "text" : ".@audhilly: long-term deal impt, no one wants to repeat this again over Xmas, critical period for the economy. Should solve now. #WHchat",
  "id" : 96632067365928960,
  "created_at" : "2011-07-28 17:24:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "audhilly",
      "screen_name" : "audhilly",
      "indices" : [ 3, 12 ],
      "id_str" : "8069492",
      "id" : 8069492
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96632055466704896",
  "text" : "RT @audhilly: @whitehouse #WHchat   Why not do short term deal and focus on tea party and educating public re Bush and deficit? Get a wo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96627066421788673",
    "geo" : { },
    "id_str" : "96630205090770945",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #WHchat   Why not do short term deal and focus on tea party and educating public re Bush and deficit? Get a workable congress?",
    "id" : 96630205090770945,
    "in_reply_to_status_id" : 96627066421788673,
    "created_at" : "2011-07-28 17:16:50 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "audhilly",
      "screen_name" : "audhilly",
      "protected" : false,
      "id_str" : "8069492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673166511603892224\/gf3Oxylw_normal.jpg",
      "id" : 8069492,
      "verified" : false
    }
  },
  "id" : 96632055466704896,
  "created_at" : "2011-07-28 17:24:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kilowat",
      "screen_name" : "kilowat",
      "indices" : [ 1, 9 ],
      "id_str" : "16456276",
      "id" : 16456276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96631247002025985",
  "text" : ".@kilowat: Impt that cuts are phased in over time, too fast\/deep will hurt  recovery & jobs. A credible, balanced plan will help. #WHchat",
  "id" : 96631247002025985,
  "created_at" : "2011-07-28 17:20:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kilowat",
      "screen_name" : "kilowat",
      "indices" : [ 3, 11 ],
      "id_str" : "16456276",
      "id" : 16456276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 84, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96631189477142528",
  "text" : "RT @kilowat: what will all of these cuts $$$ do to the economy in the years to come #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 71, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96629928874872832",
    "text" : "what will all of these cuts $$$ do to the economy in the years to come #WHchat",
    "id" : 96629928874872832,
    "created_at" : "2011-07-28 17:15:45 +0000",
    "user" : {
      "name" : "kilowat",
      "screen_name" : "kilowat",
      "protected" : false,
      "id_str" : "16456276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3182312031\/e976e1a10c685f2881e1c748a56d9188_normal.png",
      "id" : 16456276,
      "verified" : false
    }
  },
  "id" : 96631189477142528,
  "created_at" : "2011-07-28 17:20:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96630356526104576",
  "text" : ".@SenatorReyes44: Simple, cut spending + cut tax loopholes = lower deficit and debt. #WHchat",
  "id" : 96630356526104576,
  "created_at" : "2011-07-28 17:17:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Skydogz",
      "screen_name" : "skydogz",
      "indices" : [ 1, 9 ],
      "id_str" : "49094229",
      "id" : 49094229
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http:\/\/t.co\/3f8zqm4",
      "expanded_url" : "http:\/\/wh.gov\/rkc",
      "display_url" : "wh.gov\/rkc"
    }, {
      "indices" : [ 54, 73 ],
      "url" : "http:\/\/t.co\/KEeUjNQ",
      "expanded_url" : "http:\/\/www.cbo.gov\/doc.cfm?index=12338",
      "display_url" : "cbo.gov\/doc.cfm?index=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96629758305107968",
  "text" : ".@skydogz: POTUS plan: http:\/\/t.co\/3f8zqm4 Reid plan: http:\/\/t.co\/KEeUjNQ. Mos w\/ Ds & Rs talking. All know options, need compromise #WHchat",
  "id" : 96629758305107968,
  "created_at" : "2011-07-28 17:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96628517449646081",
  "text" : ".@mikehoward51: not meeting any of our obligations is a default. Would banks lend to a small biz that was delaying paying suppliers? #WHchat",
  "id" : 96628517449646081,
  "created_at" : "2011-07-28 17:10:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mae",
      "screen_name" : "Mae_tweet",
      "indices" : [ 1, 11 ],
      "id_str" : "185684366",
      "id" : 185684366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96628008080781312",
  "text" : ".@Mae_tweet: still a long way to go, but has been improvement; 16 straight mos of job growth & 2.2mill private sector jobs added #WHchat",
  "id" : 96628008080781312,
  "created_at" : "2011-07-28 17:08:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mae",
      "screen_name" : "Mae_tweet",
      "indices" : [ 3, 13 ],
      "id_str" : "185684366",
      "id" : 185684366
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 15, 22 ]
    }, {
      "text" : "debt",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96627548003381248",
  "text" : "RT @Mae_tweet: #whchat #debt @whitehouse Where are signs of a recovery for The US Economy?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "debt",
        "indices" : [ 8, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96590647926063104",
    "text" : "#whchat #debt @whitehouse Where are signs of a recovery for The US Economy?",
    "id" : 96590647926063104,
    "created_at" : "2011-07-28 14:39:39 +0000",
    "user" : {
      "name" : "Mae",
      "screen_name" : "Mae_tweet",
      "protected" : false,
      "id_str" : "185684366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696525129661153281\/mttKwmBL_normal.jpg",
      "id" : 185684366,
      "verified" : false
    }
  },
  "id" : 96627548003381248,
  "created_at" : "2011-07-28 17:06:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96627066421788673",
  "text" : "This is Jason Furman, I work on economic policy at the White House, happy to be here for office hours. Use #WHchat to ask Qs.",
  "id" : 96627066421788673,
  "created_at" : "2011-07-28 17:04:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96618882323857408",
  "text" : "RT @VP: Campaign to Cut Waste names Government Accountability and Transparency Board- tapping leaders to crack down on waste http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 136 ],
        "url" : "http:\/\/t.co\/H0N8vJz",
        "expanded_url" : "http:\/\/wh.gov\/r85",
        "display_url" : "wh.gov\/r85"
      } ]
    },
    "geo" : { },
    "id_str" : "96618798014148610",
    "text" : "Campaign to Cut Waste names Government Accountability and Transparency Board- tapping leaders to crack down on waste http:\/\/t.co\/H0N8vJz",
    "id" : 96618798014148610,
    "created_at" : "2011-07-28 16:31:31 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 96618882323857408,
  "created_at" : "2011-07-28 16:31:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    }, {
      "name" : "NYDN Opinion Team",
      "screen_name" : "NYDNOpinions",
      "indices" : [ 75, 88 ],
      "id_str" : "26496560",
      "id" : 26496560
    }, {
      "name" : "New York Daily News",
      "screen_name" : "NYDailyNews",
      "indices" : [ 98, 110 ],
      "id_str" : "9763482",
      "id" : 9763482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FAA",
      "indices" : [ 51, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/fv0l2Zi",
      "expanded_url" : "http:\/\/bit.ly\/oRUUqD",
      "display_url" : "bit.ly\/oRUUqD"
    } ]
  },
  "geo" : { },
  "id_str" : "96603756443090944",
  "text" : "RT @RayLaHood: Please read my opinion essay on the #FAA, cross-posted from @nydnopinions pages of @nydailynews http:\/\/t.co\/fv0l2Zi",
  "id" : 96603756443090944,
  "created_at" : "2011-07-28 15:31:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/gtvAxWV",
      "expanded_url" : "http:\/\/wh.gov\/rTr",
      "display_url" : "wh.gov\/rTr"
    } ]
  },
  "geo" : { },
  "id_str" : "96599447189991424",
  "text" : "120 student body presidents sign a letter to Obama, Boehner, Reid, McConnell & Pelosi on the #debt ceiling. Read it: http:\/\/t.co\/gtvAxWV",
  "id" : 96599447189991424,
  "created_at" : "2011-07-28 15:14:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96593419543117824",
  "text" : "RT @pfeiffer44: Happy Holidays America: Boehner plan would have the debt ceiling all over again during the holiday season, which is crit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96587730812809216",
    "text" : "Happy Holidays America: Boehner plan would have the debt ceiling all over again during the holiday season, which is critical for the economy",
    "id" : 96587730812809216,
    "created_at" : "2011-07-28 14:28:04 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 96593419543117824,
  "created_at" : "2011-07-28 14:50:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 4, 11 ]
    }, {
      "text" : "debt",
      "indices" : [ 34, 39 ]
    }, {
      "text" : "deficit",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96589351974207488",
  "text" : "Use #whchat to ask your Qs on the #debt, #deficit & economy. NEC staff will be here answering during Office Hours @ 1ET & 3ET.",
  "id" : 96589351974207488,
  "created_at" : "2011-07-28 14:34:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 62 ],
      "url" : "http:\/\/t.co\/VvXIunK",
      "expanded_url" : "http:\/\/wh.gov\/rBp",
      "display_url" : "wh.gov\/rBp"
    } ]
  },
  "geo" : { },
  "id_str" : "96578607438237696",
  "text" : "Q: How did we accumulate so much #debt? A: http:\/\/t.co\/VvXIunK",
  "id" : 96578607438237696,
  "created_at" : "2011-07-28 13:51:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webhosting Chat",
      "screen_name" : "WHChat",
      "indices" : [ 70, 77 ],
      "id_str" : "153947010",
      "id" : 153947010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 41, 46 ]
    }, {
      "text" : "deficit",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96577068724264960",
  "text" : "More WH Office Hours: Ask your Qs on the #debt, #deficit & economy w\/ @whchat. NEC staff will be here answering @ 1ET & 3ET -- ask away.",
  "id" : 96577068724264960,
  "created_at" : "2011-07-28 13:45:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96575331829420032",
  "text" : "RT @pfeiffer44: At some point, House leadership needs to focus on solving the problem so US doesn't default. Clock is ticking and they a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96394006476505088",
    "text" : "At some point, House leadership needs to focus on solving the problem so US doesn't default. Clock is ticking and they are hurting the econ",
    "id" : 96394006476505088,
    "created_at" : "2011-07-28 01:38:16 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 96575331829420032,
  "created_at" : "2011-07-28 13:38:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 28, 33 ]
    }, {
      "text" : "whchat",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 73 ],
      "url" : "http:\/\/t.co\/UneSwnz",
      "expanded_url" : "http:\/\/wh.gov\/r0d",
      "display_url" : "wh.gov\/r0d"
    }, {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/TDLuxQQ",
      "expanded_url" : "http:\/\/www.wh.gov\/officehours",
      "display_url" : "wh.gov\/officehours"
    } ]
  },
  "geo" : { },
  "id_str" : "96362341414875136",
  "text" : "Today's Office Hours on the #debt debate posted here: http:\/\/t.co\/UneSwnz Double up on #whchat tomorrow @ 1ET & 3ET: http:\/\/t.co\/TDLuxQQ",
  "id" : 96362341414875136,
  "created_at" : "2011-07-27 23:32:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 68, 79 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/BxShEPI",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=VVf17y0O4T0",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "96352489783308288",
  "text" : "RT @JoiningForces: President Obama welcomes Wounded Warriors to the @WhiteHouse for a game of basketball. Video: http:\/\/t.co\/BxShEPI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 49, 60 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 113 ],
        "url" : "http:\/\/t.co\/BxShEPI",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=VVf17y0O4T0",
        "display_url" : "youtube.com\/watch?feature=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "96352211688366080",
    "text" : "President Obama welcomes Wounded Warriors to the @WhiteHouse for a game of basketball. Video: http:\/\/t.co\/BxShEPI",
    "id" : 96352211688366080,
    "created_at" : "2011-07-27 22:52:12 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 96352489783308288,
  "created_at" : "2011-07-27 22:53:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "potinleftgrog1",
      "screen_name" : "Mayor_Smith",
      "indices" : [ 50, 62 ],
      "id_str" : "2982225435",
      "id" : 2982225435
    }, {
      "name" : "MesaAzgov",
      "screen_name" : "MesaAzgov",
      "indices" : [ 63, 73 ],
      "id_str" : "15646731",
      "id" : 15646731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/vUbvlKW",
      "expanded_url" : "http:\/\/wh.gov\/rBe",
      "display_url" : "wh.gov\/rBe"
    } ]
  },
  "geo" : { },
  "id_str" : "96343662316879872",
  "text" : "\"A balanced approach is what solves the problem\" -@Mayor_Smith @MesaAzgov on the #debt debate: http:\/\/t.co\/vUbvlKW",
  "id" : 96343662316879872,
  "created_at" : "2011-07-27 22:18:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 77, 88 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/vUbvlKW",
      "expanded_url" : "http:\/\/wh.gov\/rBe",
      "display_url" : "wh.gov\/rBe"
    } ]
  },
  "geo" : { },
  "id_str" : "96337363587960832",
  "text" : "\"Americans demand it, reason supports it & a prosperous future requires it.\u201D-@CoryBooker on a balanced approach: http:\/\/t.co\/vUbvlKW",
  "id" : 96337363587960832,
  "created_at" : "2011-07-27 21:53:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http:\/\/t.co\/VvXIunK",
      "expanded_url" : "http:\/\/wh.gov\/rBp",
      "display_url" : "wh.gov\/rBp"
    } ]
  },
  "geo" : { },
  "id_str" : "96334418565808130",
  "text" : "Wonder where our national debt comes from? Check out this infographic: http:\/\/t.co\/VvXIunK",
  "id" : 96334418565808130,
  "created_at" : "2011-07-27 21:41:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/ZQj8XeA",
      "expanded_url" : "http:\/\/www.wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "96293884367343616",
  "text" : "Thanks for joining WH Office Hours. Let us know how it went & what we can do better. Full Q&A will be on http:\/\/t.co\/ZQj8XeA later. #WHChat",
  "id" : 96293884367343616,
  "created_at" : "2011-07-27 19:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http:\/\/t.co\/TDLuxQQ",
      "expanded_url" : "http:\/\/www.wh.gov\/officehours",
      "display_url" : "wh.gov\/officehours"
    } ]
  },
  "geo" : { },
  "id_str" : "96291576699043841",
  "text" : "Thanks for all the great questions. Office Hours continue all week. http:\/\/t.co\/TDLuxQQ -Brian #WHChat",
  "id" : 96291576699043841,
  "created_at" : "2011-07-27 18:51:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Wiggs",
      "screen_name" : "wiggsd",
      "indices" : [ 0, 7 ],
      "id_str" : "23271945",
      "id" : 23271945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/ca31My7",
      "expanded_url" : "http:\/\/tinyurl.com\/y8ufsnp",
      "display_url" : "tinyurl.com\/y8ufsnp"
    } ]
  },
  "geo" : { },
  "id_str" : "96291538044329985",
  "in_reply_to_user_id" : 23271945,
  "text" : "@wiggsd Sorry to hear that. Fiscal policy is important, but can be dry sometimes. Here's something more fun: http:\/\/t.co\/ca31My7 #WHChat",
  "id" : 96291538044329985,
  "created_at" : "2011-07-27 18:51:06 +0000",
  "in_reply_to_screen_name" : "wiggsd",
  "in_reply_to_user_id_str" : "23271945",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Wiggs",
      "screen_name" : "wiggsd",
      "indices" : [ 3, 10 ],
      "id_str" : "23271945",
      "id" : 23271945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TCOT",
      "indices" : [ 89, 94 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96291132866179073",
  "text" : "RT @wiggsd: This WH correspondence briefing isn't nearly as entertaining as yesterday's. #TCOT #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TCOT",
        "indices" : [ 77, 82 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 83, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96288078137786369",
    "text" : "This WH correspondence briefing isn't nearly as entertaining as yesterday's. #TCOT #WHchat",
    "id" : 96288078137786369,
    "created_at" : "2011-07-27 18:37:21 +0000",
    "user" : {
      "name" : "David Wiggs",
      "screen_name" : "wiggsd",
      "protected" : false,
      "id_str" : "23271945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687860273026330624\/KGmGjo8E_normal.jpg",
      "id" : 23271945,
      "verified" : false
    }
  },
  "id" : 96291132866179073,
  "created_at" : "2011-07-27 18:49:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hapahaoleboy",
      "screen_name" : "hapahaoleboy",
      "indices" : [ 1, 14 ],
      "id_str" : "12093462",
      "id" : 12093462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96291086275854336",
  "text" : ".@hapahaoleboy: Done it before: every major bipartisan deficit reduction in recent history has included tough spending cuts and more revenue",
  "id" : 96291086275854336,
  "created_at" : "2011-07-27 18:49:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hapahaoleboy",
      "screen_name" : "hapahaoleboy",
      "indices" : [ 3, 16 ],
      "id_str" : "12093462",
      "id" : 12093462
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96289771088916480",
  "text" : "RT @hapahaoleboy: @whitehouse - Wouldn't it b common sense to look back @ the last time we had a surplus & see how it was accomplished?  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 118, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96289070455590913",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse - Wouldn't it b common sense to look back @ the last time we had a surplus & see how it was accomplished? #WHChat",
    "id" : 96289070455590913,
    "created_at" : "2011-07-27 18:41:18 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "hapahaoleboy",
      "screen_name" : "hapahaoleboy",
      "protected" : false,
      "id_str" : "12093462",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1748639048\/n526706597_1365478_3830185_normal.jpg",
      "id" : 12093462,
      "verified" : false
    }
  },
  "id" : 96289771088916480,
  "created_at" : "2011-07-27 18:44:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96289410622033920",
  "text" : ".@chrishowesss: default would drive up interest rates on college, home, car loans. Economy tough enough for new grads, cant make it worse",
  "id" : 96289410622033920,
  "created_at" : "2011-07-27 18:42:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon",
      "screen_name" : "Flyersfan79",
      "indices" : [ 1, 13 ],
      "id_str" : "110275598",
      "id" : 110275598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96288766871867392",
  "text" : ".@Flyersfan79: Restoring Clinton-era rates for top 2% of earners would avoid adding $800bn to the deficit. Not too much to ask. #WHChat",
  "id" : 96288766871867392,
  "created_at" : "2011-07-27 18:40:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon",
      "screen_name" : "Flyersfan79",
      "indices" : [ 3, 15 ],
      "id_str" : "110275598",
      "id" : 110275598
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96288334313291779",
  "text" : "RT @Flyersfan79: Is it even possible to get taxes back to Clinton era? Especially the top 1%? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96287780237352960",
    "text" : "Is it even possible to get taxes back to Clinton era? Especially the top 1%? #WHChat",
    "id" : 96287780237352960,
    "created_at" : "2011-07-27 18:36:10 +0000",
    "user" : {
      "name" : "Brandon",
      "screen_name" : "Flyersfan79",
      "protected" : false,
      "id_str" : "110275598",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791761704929505280\/Glm7I0GT_normal.jpg",
      "id" : 110275598,
      "verified" : false
    }
  },
  "id" : 96288334313291779,
  "created_at" : "2011-07-27 18:38:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Riv",
      "screen_name" : "ard0508",
      "indices" : [ 1, 9 ],
      "id_str" : "325875521",
      "id" : 325875521
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 111, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96287665921589248",
  "text" : ".@ard0508 ah - good catch - realize that some may not know what POTUS means - \"President of the United States\" #WHChat",
  "id" : 96287665921589248,
  "created_at" : "2011-07-27 18:35:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krissy",
      "screen_name" : "slytherinbunney",
      "indices" : [ 3, 19 ],
      "id_str" : "14870495",
      "id" : 14870495
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96287503249711104",
  "text" : "RT @slytherinbunney: @whitehouse Brian, why are both parties refusing to compromise, when people's lives are at stake? Is this a politic ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96284722514231296",
    "geo" : { },
    "id_str" : "96285808541175808",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Brian, why are both parties refusing to compromise, when people's lives are at stake? Is this a political game to them? #whchat",
    "id" : 96285808541175808,
    "in_reply_to_status_id" : 96284722514231296,
    "created_at" : "2011-07-27 18:28:20 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Krissy",
      "screen_name" : "slytherinbunney",
      "protected" : false,
      "id_str" : "14870495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3336326865\/c20634eaa67ea4d99a8ca94751c8f07e_normal.png",
      "id" : 14870495,
      "verified" : false
    }
  },
  "id" : 96287503249711104,
  "created_at" : "2011-07-27 18:35:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Riv",
      "screen_name" : "ard0508",
      "indices" : [ 3, 11 ],
      "id_str" : "325875521",
      "id" : 325875521
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96287431611002880",
  "text" : "RT @ard0508: @whitehouse What is POTUS? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 27, 34 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96285286971084800",
    "geo" : { },
    "id_str" : "96285525866057728",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse What is POTUS? #WHChat",
    "id" : 96285525866057728,
    "in_reply_to_status_id" : 96285286971084800,
    "created_at" : "2011-07-27 18:27:12 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Riv",
      "screen_name" : "ard0508",
      "protected" : false,
      "id_str" : "325875521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798206162143477760\/rlRyA8hP_normal.jpg",
      "id" : 325875521,
      "verified" : false
    }
  },
  "id" : 96287431611002880,
  "created_at" : "2011-07-27 18:34:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Krissy",
      "screen_name" : "slytherinbunney",
      "indices" : [ 1, 17 ],
      "id_str" : "14870495",
      "id" : 14870495
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96287103998103555",
  "text" : ".@slytherinbunney: We agree, this is about families & jobs & our economy. POTUS is ready to find common ground but need balance #WHChat",
  "id" : 96287103998103555,
  "created_at" : "2011-07-27 18:33:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suzanne Gypsy",
      "screen_name" : "suzannegypsy",
      "indices" : [ 1, 14 ],
      "id_str" : "303881556",
      "id" : 303881556
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96287014260965376",
  "text" : ".@suzannegypsy: Bc Congress hasn't acted, nearly 4k workers have been furloughed. #WHChat",
  "id" : 96287014260965376,
  "created_at" : "2011-07-27 18:33:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suzanne Gypsy",
      "screen_name" : "suzannegypsy",
      "indices" : [ 3, 16 ],
      "id_str" : "303881556",
      "id" : 303881556
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCHAT",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96286038909136896",
  "text" : "RT @suzannegypsy: @whitehouse . #WHCHAT What is the status of the FAA?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHCHAT",
        "indices" : [ 14, 21 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "96281625419202560",
    "geo" : { },
    "id_str" : "96284376458997760",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse . #WHCHAT What is the status of the FAA?",
    "id" : 96284376458997760,
    "in_reply_to_status_id" : 96281625419202560,
    "created_at" : "2011-07-27 18:22:38 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Suzanne Gypsy",
      "screen_name" : "suzannegypsy",
      "protected" : false,
      "id_str" : "303881556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772882248102187008\/bMP-_OvL_normal.jpg",
      "id" : 303881556,
      "verified" : false
    }
  },
  "id" : 96286038909136896,
  "created_at" : "2011-07-27 18:29:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD Green",
      "screen_name" : "JDGreen07",
      "indices" : [ 1, 11 ],
      "id_str" : "154571095",
      "id" : 154571095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 135, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96285286971084800",
  "text" : ".@JDGreen07: Foreign aid is &lt; 1% of the budget; need to make tough choices all around, on defense, domestic spending & entitlements #WHChat",
  "id" : 96285286971084800,
  "created_at" : "2011-07-27 18:26:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD Green",
      "screen_name" : "JDGreen07",
      "indices" : [ 3, 13 ],
      "id_str" : "154571095",
      "id" : 154571095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96285146130558977",
  "text" : "RT @JDGreen07: Why not Drop foreign aid by a significant amount, demand repayment of bailout money or levy fines. Loan out but not pay S ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96284442431209473",
    "text" : "Why not Drop foreign aid by a significant amount, demand repayment of bailout money or levy fines. Loan out but not pay SS or bills? #WHChat",
    "id" : 96284442431209473,
    "created_at" : "2011-07-27 18:22:54 +0000",
    "user" : {
      "name" : "JD Green",
      "screen_name" : "JDGreen07",
      "protected" : false,
      "id_str" : "154571095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605735008272154624\/u20zebk6_normal.jpg",
      "id" : 154571095,
      "verified" : false
    }
  },
  "id" : 96285146130558977,
  "created_at" : "2011-07-27 18:25:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/96284722514231296\/photo\/1",
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/qnJdilh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AVYScerCAAE37OC.jpg",
      "id_str" : "96284722514231297",
      "id" : 96284722514231297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AVYScerCAAE37OC.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qnJdilh"
    } ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 54, 59 ]
    }, {
      "text" : "whchat",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96284722514231296",
  "text" : "Brian Deese from NEC is here answering your Qs on the #debt debate during WH Office Hours. Use #whchat to join the Q&A. http:\/\/t.co\/qnJdilh",
  "id" : 96284722514231296,
  "created_at" : "2011-07-27 18:24:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Dyas",
      "screen_name" : "scottdyas",
      "indices" : [ 1, 11 ],
      "id_str" : "37826599",
      "id" : 37826599
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96284574203641858",
  "text" : ".@scottdyas broadening base isn't a conspiracy theory; means removing ineffective provisions like spec. breaks for corp jet owners #WHChat",
  "id" : 96284574203641858,
  "created_at" : "2011-07-27 18:23:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Seaborne",
      "screen_name" : "aseaborne",
      "indices" : [ 3, 13 ],
      "id_str" : "19464711",
      "id" : 19464711
    }, {
      "name" : "Matthew D. Frake",
      "screen_name" : "matthewfrake",
      "indices" : [ 49, 62 ],
      "id_str" : "132904676",
      "id" : 132904676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96284293420167171",
  "text" : "RT @aseaborne: Nope cutting funding cuts jobs.RT @matthewfrake: #whchat Do any debt ceiling plans factor in job creation for out of work ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew D. Frake",
        "screen_name" : "matthewfrake",
        "indices" : [ 34, 47 ],
        "id_str" : "132904676",
        "id" : 132904676
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 49, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96283301152686080",
    "text" : "Nope cutting funding cuts jobs.RT @matthewfrake: #whchat Do any debt ceiling plans factor in job creation for out of work Americans?",
    "id" : 96283301152686080,
    "created_at" : "2011-07-27 18:18:22 +0000",
    "user" : {
      "name" : "Alexandria Seaborne",
      "screen_name" : "aseaborne",
      "protected" : false,
      "id_str" : "19464711",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/682701918569799680\/3qVdv3Us_normal.jpg",
      "id" : 19464711,
      "verified" : false
    }
  },
  "id" : 96284293420167171,
  "created_at" : "2011-07-27 18:22:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Seaborne",
      "screen_name" : "aseaborne",
      "indices" : [ 1, 11 ],
      "id_str" : "19464711",
      "id" : 19464711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96283877789794304",
  "text" : ".@aseaborne: POTUS wants extended payroll tax cut & unemployment insurance now to help those struggling and to support the economy #WHChat",
  "id" : 96283877789794304,
  "created_at" : "2011-07-27 18:20:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Allen",
      "screen_name" : "allencw",
      "indices" : [ 1, 9 ],
      "id_str" : "14230401",
      "id" : 14230401
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96283397751717889",
  "text" : ".@allencw: Boehner plan is short term forces another debt limit vote in just a few months - that creates ongoing uncertainty #WHChat",
  "id" : 96283397751717889,
  "created_at" : "2011-07-27 18:18:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christy K Robinson",
      "screen_name" : "Editornado",
      "indices" : [ 3, 14 ],
      "id_str" : "52230699",
      "id" : 52230699
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96283086655983616",
  "text" : "RT @Editornado: #whchat Don't let Boehner, TP, et al say \"new taxes\" when it's a RESTORATION of taxes paid under their god Reagan. Resto ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96281395860738048",
    "text" : "#whchat Don't let Boehner, TP, et al say \"new taxes\" when it's a RESTORATION of taxes paid under their god Reagan. Restore=positive word.",
    "id" : 96281395860738048,
    "created_at" : "2011-07-27 18:10:48 +0000",
    "user" : {
      "name" : "Christy K Robinson",
      "screen_name" : "Editornado",
      "protected" : false,
      "id_str" : "52230699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786643227734478848\/ycohh2td_normal.jpg",
      "id" : 52230699,
      "verified" : false
    }
  },
  "id" : 96283086655983616,
  "created_at" : "2011-07-27 18:17:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florence Otaigbe",
      "screen_name" : "yoyoitsflo",
      "indices" : [ 1, 12 ],
      "id_str" : "338616349",
      "id" : 338616349
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96282953344221184",
  "text" : ".@yoyoitsflo: we're confident the answer is yes. Time for Congress to act. #WHChat",
  "id" : 96282953344221184,
  "created_at" : "2011-07-27 18:16:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Florence Otaigbe",
      "screen_name" : "yoyoitsflo",
      "indices" : [ 3, 14 ],
      "id_str" : "338616349",
      "id" : 338616349
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96282851108073472",
  "text" : "RT @yoyoitsflo: Is a deal likely to be reached before August 2? #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 48, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96282564674850816",
    "text" : "Is a deal likely to be reached before August 2? #whchat",
    "id" : 96282564674850816,
    "created_at" : "2011-07-27 18:15:26 +0000",
    "user" : {
      "name" : "Florence Otaigbe",
      "screen_name" : "yoyoitsflo",
      "protected" : false,
      "id_str" : "338616349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735476817314906112\/CPvWjtbX_normal.jpg",
      "id" : 338616349,
      "verified" : false
    }
  },
  "id" : 96282851108073472,
  "created_at" : "2011-07-27 18:16:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christy K Robinson",
      "screen_name" : "Editornado",
      "indices" : [ 1, 12 ],
      "id_str" : "52230699",
      "id" : 52230699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/2NnpyNh",
      "expanded_url" : "http:\/\/wh.gov\/rZi",
      "display_url" : "wh.gov\/rZi"
    } ]
  },
  "geo" : { },
  "id_str" : "96282643536154624",
  "text" : ".@Editornado Reagan: \u201CWould u rather reduce deficits...by raising revenue from those who r not now paying fair share...\" http:\/\/t.co\/2NnpyNh",
  "id" : 96282643536154624,
  "created_at" : "2011-07-27 18:15:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Sorensen",
      "screen_name" : "AndrewSorensen1",
      "indices" : [ 1, 17 ],
      "id_str" : "330353093",
      "id" : 330353093
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96281625419202560",
  "text" : ".@AndrewSorensen1: Boehner plan leaves cloud of uncertainty over  economy; Reid plan reduces the deficit and removes uncertainty #WHChat",
  "id" : 96281625419202560,
  "created_at" : "2011-07-27 18:11:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Sorensen",
      "screen_name" : "AndrewSorensen1",
      "indices" : [ 3, 19 ],
      "id_str" : "330353093",
      "id" : 330353093
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96281405679607808",
  "text" : "RT @AndrewSorensen1: #whchat what are the key differences on the Rep House and Dem Senate plans?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96280184856133632",
    "text" : "#whchat what are the key differences on the Rep House and Dem Senate plans?",
    "id" : 96280184856133632,
    "created_at" : "2011-07-27 18:05:59 +0000",
    "user" : {
      "name" : "Andrew Sorensen",
      "screen_name" : "AndrewSorensen1",
      "protected" : false,
      "id_str" : "330353093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788554165677125632\/4EXfIRHk_normal.jpg",
      "id" : 330353093,
      "verified" : false
    }
  },
  "id" : 96281405679607808,
  "created_at" : "2011-07-27 18:10:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monster Paws",
      "screen_name" : "WillAndras",
      "indices" : [ 1, 12 ],
      "id_str" : "257207865",
      "id" : 257207865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96280580714536961",
  "text" : ".@WillAndras: POTUS goal is $4T balanced plan, but Reid is responsible downpayment and compromise. #WHChat",
  "id" : 96280580714536961,
  "created_at" : "2011-07-27 18:07:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monster Paws",
      "screen_name" : "WillAndras",
      "indices" : [ 3, 14 ],
      "id_str" : "257207865",
      "id" : 257207865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96280337046454275",
  "text" : "RT @WillAndras: Does the president support Harry Reid's debt plan even w\/o revenue increases? #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 78, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96279709977026560",
    "text" : "Does the president support Harry Reid's debt plan even w\/o revenue increases? #whchat",
    "id" : 96279709977026560,
    "created_at" : "2011-07-27 18:04:06 +0000",
    "user" : {
      "name" : "Monster Paws",
      "screen_name" : "WillAndras",
      "protected" : false,
      "id_str" : "257207865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792573037610569728\/dO05EN6Y_normal.jpg",
      "id" : 257207865,
      "verified" : false
    }
  },
  "id" : 96280337046454275,
  "created_at" : "2011-07-27 18:06:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daniel b michel",
      "screen_name" : "danielbmichel1",
      "indices" : [ 1, 16 ],
      "id_str" : "287412740",
      "id" : 287412740
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/VvXIunK",
      "expanded_url" : "http:\/\/wh.gov\/rBp",
      "display_url" : "wh.gov\/rBp"
    } ]
  },
  "geo" : { },
  "id_str" : "96280056166481920",
  "text" : ".@danielbmichel1 diff b\/t savings projected for 2011 & actual debt = $12.7T. $1.4T is from wars in iraq & afghan. See http:\/\/t.co\/VvXIunK",
  "id" : 96280056166481920,
  "created_at" : "2011-07-27 18:05:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "daniel b michel",
      "screen_name" : "danielbmichel1",
      "indices" : [ 3, 18 ],
      "id_str" : "287412740",
      "id" : 287412740
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96279571355287553",
  "text" : "RT @danielbmichel1: #whchat What % of our accumulated debt is war spending?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96236474617446400",
    "text" : "#whchat What % of our accumulated debt is war spending?",
    "id" : 96236474617446400,
    "created_at" : "2011-07-27 15:12:18 +0000",
    "user" : {
      "name" : "daniel b michel",
      "screen_name" : "danielbmichel1",
      "protected" : false,
      "id_str" : "287412740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2817469760\/6c9a6a466536e4f900fa98f7156c87a8_normal.jpeg",
      "id" : 287412740,
      "verified" : false
    }
  },
  "id" : 96279571355287553,
  "created_at" : "2011-07-27 18:03:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96279306971529216",
  "text" : "Brian just got here -- we've got a lot of great Qs so far for the #whchat. Keep them coming! We'll get to as many as we can.",
  "id" : 96279306971529216,
  "created_at" : "2011-07-27 18:02:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 99, 104 ]
    }, {
      "text" : "deficit",
      "indices" : [ 107, 115 ]
    }, {
      "text" : "whchat",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96278867395878912",
  "text" : "WH Office Hours starting soon: Brian Deese, Obama's econ advisor, will be answering your Qs on the #debt & #deficit. Ask with #whchat.",
  "id" : 96278867395878912,
  "created_at" : "2011-07-27 18:00:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "whchat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96273277718245376",
  "text" : "Office Hours @ 2ET: Natl Econ Council Deputy Director will be here to answer YOUR Qs on the #debt debate. Ask & follow live: #whchat",
  "id" : 96273277718245376,
  "created_at" : "2011-07-27 17:38:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 3, 10 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96266670686994432",
  "text" : "RT @blog44: WH.gov: A Victory for Stem Cell Research and Patients http:\/\/goo.gl\/fb\/qBdUL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96260548013998081",
    "text" : "WH.gov: A Victory for Stem Cell Research and Patients http:\/\/goo.gl\/fb\/qBdUL",
    "id" : 96260548013998081,
    "created_at" : "2011-07-27 16:47:57 +0000",
    "user" : {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "protected" : false,
      "id_str" : "278776049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303743170\/Screen_shot_2011-04-07_at_7.54.18_PM_normal.png",
      "id" : 278776049,
      "verified" : true
    }
  },
  "id" : 96266670686994432,
  "created_at" : "2011-07-27 17:12:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAVEAward",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http:\/\/t.co\/11BNOaB",
      "expanded_url" : "http:\/\/wh.gov\/Save-Award",
      "display_url" : "wh.gov\/Save-Award"
    } ]
  },
  "geo" : { },
  "id_str" : "96249560212582401",
  "text" : "Just 3 days left for the #SAVEAward -- Federal Employees: Share your cost-saving ideas today: http:\/\/t.co\/11BNOaB",
  "id" : 96249560212582401,
  "created_at" : "2011-07-27 16:04:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 59, 66 ]
    }, {
      "text" : "debt",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/Nlqqktg",
      "expanded_url" : "http:\/\/wh.gov\/rZR",
      "display_url" : "wh.gov\/rZR"
    } ]
  },
  "geo" : { },
  "id_str" : "96235930599428096",
  "text" : "Happening @ 2ET: Brian Deese is back for Office Hours. Use #whchat to ask your Qs on the #debt debate now & follow live: http:\/\/t.co\/Nlqqktg",
  "id" : 96235930599428096,
  "created_at" : "2011-07-27 15:10:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http:\/\/t.co\/yxAy3dU",
      "expanded_url" : "http:\/\/wh.gov\/rKj",
      "display_url" : "wh.gov\/rKj"
    } ]
  },
  "geo" : { },
  "id_str" : "96029698177503232",
  "text" : "Check out the full #WHChat with NEC's Brian Deese here: http:\/\/t.co\/yxAy3dU & join us for our next installment of WH Office Hours tomorrow.",
  "id" : 96029698177503232,
  "created_at" : "2011-07-27 01:30:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 44, 59 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96011780735774721",
  "text" : "RT @OMBPress: Jack Lew on baselines and the @SpeakerBoehner plan: http:\/\/wh.gov\/rKY. We all have used Jan baseline throughout the talks. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 30, 45 ],
        "id_str" : "7713202",
        "id" : 7713202
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debt",
        "indices" : [ 123, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "96007551593889793",
    "text" : "Jack Lew on baselines and the @SpeakerBoehner plan: http:\/\/wh.gov\/rKY. We all have used Jan baseline throughout the talks. #debt",
    "id" : 96007551593889793,
    "created_at" : "2011-07-27 00:02:38 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 96011780735774721,
  "created_at" : "2011-07-27 00:19:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96011141096030208",
  "text" : "RT @macon44: Phone calls, emails, tweets - Americans respond to Pres Obama's speech (includes top 5 RT'd excerpts from speech) http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 133 ],
        "url" : "http:\/\/t.co\/ZYChQc5",
        "expanded_url" : "http:\/\/wh.gov\/rKx",
        "display_url" : "wh.gov\/rKx"
      } ]
    },
    "geo" : { },
    "id_str" : "96010721397186561",
    "text" : "Phone calls, emails, tweets - Americans respond to Pres Obama's speech (includes top 5 RT'd excerpts from speech) http:\/\/t.co\/ZYChQc5",
    "id" : 96010721397186561,
    "created_at" : "2011-07-27 00:15:14 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 96011141096030208,
  "created_at" : "2011-07-27 00:16:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Smelley",
      "screen_name" : "tsmelley",
      "indices" : [ 0, 9 ],
      "id_str" : "18050225",
      "id" : 18050225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96003364676042752",
  "geo" : { },
  "id_str" : "96004052260896768",
  "in_reply_to_user_id" : 18050225,
  "text" : "@tsmelley no problem (ps, roll tide!)",
  "id" : 96004052260896768,
  "in_reply_to_status_id" : 96003364676042752,
  "created_at" : "2011-07-26 23:48:44 +0000",
  "in_reply_to_screen_name" : "tsmelley",
  "in_reply_to_user_id_str" : "18050225",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Smelley",
      "screen_name" : "tsmelley",
      "indices" : [ 0, 9 ],
      "id_str" : "18050225",
      "id" : 18050225
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96000706636550144",
  "geo" : { },
  "id_str" : "96003057430691840",
  "in_reply_to_user_id" : 18050225,
  "text" : "@tsmelley good call",
  "id" : 96003057430691840,
  "in_reply_to_status_id" : 96000706636550144,
  "created_at" : "2011-07-26 23:44:47 +0000",
  "in_reply_to_screen_name" : "tsmelley",
  "in_reply_to_user_id_str" : "18050225",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 3, 10 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "96002601216258048",
  "text" : "RT @blog44: WH.gov: Deficit Crisis: State and Local Officials Call for a Balanced Approach http:\/\/goo.gl\/fb\/WTTbw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95995267060473857",
    "text" : "WH.gov: Deficit Crisis: State and Local Officials Call for a Balanced Approach http:\/\/goo.gl\/fb\/WTTbw",
    "id" : 95995267060473857,
    "created_at" : "2011-07-26 23:13:49 +0000",
    "user" : {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "protected" : false,
      "id_str" : "278776049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303743170\/Screen_shot_2011-04-07_at_7.54.18_PM_normal.png",
      "id" : 278776049,
      "verified" : true
    }
  },
  "id" : 96002601216258048,
  "created_at" : "2011-07-26 23:42:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/TDLuxQQ",
      "expanded_url" : "http:\/\/www.wh.gov\/officehours",
      "display_url" : "wh.gov\/officehours"
    } ]
  },
  "geo" : { },
  "id_str" : "95990190899867648",
  "text" : ".@FabriceDalenzo: Thx for the feedback. We're holding Office Hrs all wk w\/ some earlier time options. See full sched: http:\/\/t.co\/TDLuxQQ",
  "id" : 95990190899867648,
  "created_at" : "2011-07-26 22:53:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95980996192772096",
  "text" : "Thanks everyone for joining our 1st WH Office Hours. What'd you think of the #WHChat? Let us know how we can improve.",
  "id" : 95980996192772096,
  "created_at" : "2011-07-26 22:17:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grandma NO GMO",
      "screen_name" : "Kauairockchick",
      "indices" : [ 1, 16 ],
      "id_str" : "244417596",
      "id" : 244417596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 120 ],
      "url" : "http:\/\/t.co\/TDLuxQQ",
      "expanded_url" : "http:\/\/www.wh.gov\/officehours",
      "display_url" : "wh.gov\/officehours"
    } ]
  },
  "geo" : { },
  "id_str" : "95979087268544512",
  "text" : ".@Kauairockchick: someone who loves budget baselines too? Budget wonks unite. I'll be here all week: http:\/\/t.co\/TDLuxQQ  #WHChat",
  "id" : 95979087268544512,
  "created_at" : "2011-07-26 22:09:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/2NnpyNh",
      "expanded_url" : "http:\/\/wh.gov\/rZi",
      "display_url" : "wh.gov\/rZi"
    } ]
  },
  "geo" : { },
  "id_str" : "95978445565210625",
  "text" : ".@handel4ever: POTUS remains confident answer is yes - divided govt doesn't have to mean dysfunctional govt. See http:\/\/t.co\/2NnpyNh #WHChat",
  "id" : 95978445565210625,
  "created_at" : "2011-07-26 22:06:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95977446859472896",
  "text" : "RT @macon44: Shouts in the office when Deese figures out how to shrink his answer down to 140 - on the nose! #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 96, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95977070982742016",
    "text" : "Shouts in the office when Deese figures out how to shrink his answer down to 140 - on the nose! #WHChat",
    "id" : 95977070982742016,
    "created_at" : "2011-07-26 22:01:31 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 95977446859472896,
  "created_at" : "2011-07-26 22:03:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SportaDiva88",
      "screen_name" : "Lmachazel",
      "indices" : [ 1, 11 ],
      "id_str" : "30900551",
      "id" : 30900551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/2NnpyNh",
      "expanded_url" : "http:\/\/wh.gov\/rZi",
      "display_url" : "wh.gov\/rZi"
    } ]
  },
  "geo" : { },
  "id_str" : "95977317591027714",
  "text" : ".@Lmachazel: POTUS \"We can\u2019t allow the American people to become collateral damage to Washington\u2019s political warfare.\" http:\/\/t.co\/2NnpyNh",
  "id" : 95977317591027714,
  "created_at" : "2011-07-26 22:02:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Ward",
      "screen_name" : "tylerralphward",
      "indices" : [ 1, 16 ],
      "id_str" : "80596389",
      "id" : 80596389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95976781001146368",
  "text" : ".@tylerralphward must avoid default to avoid econ harm & job loss; POTUS wants payroll taxcut, unemployment ins. & more to grow jobs #WHChat",
  "id" : 95976781001146368,
  "created_at" : "2011-07-26 22:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikki Wilde",
      "screen_name" : "StoneAgeSally",
      "indices" : [ 1, 15 ],
      "id_str" : "225254476",
      "id" : 225254476
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95975434612776960",
  "text" : ".@StoneAgeSally: We pay $4bn\/yr to oil & gas co's in subsidies that don't help economy POTUS wants to use to reduce deficit instead #WHChat",
  "id" : 95975434612776960,
  "created_at" : "2011-07-26 21:55:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kewlblue",
      "screen_name" : "JKewlblue",
      "indices" : [ 1, 11 ],
      "id_str" : "330655129",
      "id" : 330655129
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95974327152947200",
  "text" : ".@JKewlblue: Many on right and left - incl Rs and Ds in Senate - support balanced approach. Need compromise from House Rs too. #WHChat",
  "id" : 95974327152947200,
  "created_at" : "2011-07-26 21:50:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D0NB0Y",
      "screen_name" : "hannahfranzen",
      "indices" : [ 1, 15 ],
      "id_str" : "2664917635",
      "id" : 2664917635
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95973703682228224",
  "text" : ".@hannahfranzen: default would mean a tax on all Americans by increasing interest rates for car, home, student sm biz loans, etc. #WHChat",
  "id" : 95973703682228224,
  "created_at" : "2011-07-26 21:48:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Reaney",
      "screen_name" : "SSReaney",
      "indices" : [ 1, 10 ],
      "id_str" : "82901787",
      "id" : 82901787
    }, {
      "name" : "Chris Marsh",
      "screen_name" : "cjmarsh725",
      "indices" : [ 11, 22 ],
      "id_str" : "342967089",
      "id" : 342967089
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/Nv66adm",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2011\/04\/13\/fact-sheet-presidents-framework-shared-prosperity-and-shared-fiscal-resp",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "95973146078875648",
  "text" : ".@SSReaney @cjmarsh725. Read POTUS's balanced $4t plan here: http:\/\/t.co\/Nv66adm #WHChat",
  "id" : 95973146078875648,
  "created_at" : "2011-07-26 21:45:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Anderson",
      "screen_name" : "progressvnproud",
      "indices" : [ 1, 17 ],
      "id_str" : "254352671",
      "id" : 254352671
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95972357461639168",
  "text" : ".@progressvnproud FAA shutdown = senseless econ harm: ~4k employees furloughed, construction halted nationwide. Congress must act #WHChat",
  "id" : 95972357461639168,
  "created_at" : "2011-07-26 21:42:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Marsh",
      "screen_name" : "cjmarsh725",
      "indices" : [ 1, 12 ],
      "id_str" : "342967089",
      "id" : 342967089
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http:\/\/t.co\/VvXIunK",
      "expanded_url" : "http:\/\/wh.gov\/rBp",
      "display_url" : "wh.gov\/rBp"
    } ]
  },
  "geo" : { },
  "id_str" : "95971466637606912",
  "text" : ".@cjmarsh725: Here you go, our debt challenge in one graphic. http:\/\/t.co\/VvXIunK. #WHChat",
  "id" : 95971466637606912,
  "created_at" : "2011-07-26 21:39:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Marsh",
      "screen_name" : "cjmarsh725",
      "indices" : [ 1, 12 ],
      "id_str" : "342967089",
      "id" : 342967089
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95970992987455488",
  "text" : ".@cjmarsh725: We are confident this will get done, but now is the time for action. For sake of economy, need common-sense compromise #WHChat",
  "id" : 95970992987455488,
  "created_at" : "2011-07-26 21:37:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Stoffer",
      "screen_name" : "EMT_stofferj",
      "indices" : [ 1, 14 ],
      "id_str" : "111261864",
      "id" : 111261864
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95970251690360832",
  "text" : ".@EMT_stofferj: sadly, no offramps exist. Only Congress can act to raise debt limit and remove uncertainty weighing on our economy #WHChat",
  "id" : 95970251690360832,
  "created_at" : "2011-07-26 21:34:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/95969952816840705\/photo\/1",
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/38zXbdh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AVT0KeMCQAA90XG.jpg",
      "id_str" : "95969952821035008",
      "id" : 95969952821035008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AVT0KeMCQAA90XG.jpg",
      "sizes" : [ {
        "h" : 3744,
        "resize" : "fit",
        "w" : 5616
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/38zXbdh"
    } ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95970046404341760",
  "text" : "RT @macon44: & here's another. FYI Brian Deese is Deputy Director of the National Economic Council #WHChat http:\/\/t.co\/38zXbdh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/95969952816840705\/photo\/1",
        "indices" : [ 94, 113 ],
        "url" : "http:\/\/t.co\/38zXbdh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AVT0KeMCQAA90XG.jpg",
        "id_str" : "95969952821035008",
        "id" : 95969952821035008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AVT0KeMCQAA90XG.jpg",
        "sizes" : [ {
          "h" : 3744,
          "resize" : "fit",
          "w" : 5616
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/38zXbdh"
      } ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 86, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95969952816840705",
    "text" : "& here's another. FYI Brian Deese is Deputy Director of the National Economic Council #WHChat http:\/\/t.co\/38zXbdh",
    "id" : 95969952816840705,
    "created_at" : "2011-07-26 21:33:15 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 95970046404341760,
  "created_at" : "2011-07-26 21:33:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sir GadgetVirtuoso",
      "screen_name" : "GadgetVirtuoso",
      "indices" : [ 1, 16 ],
      "id_str" : "759581",
      "id" : 759581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95969278142066689",
  "text" : ".@GadgetVirtuoso: Key reason we need balance, with revenue, defense & all on table, is w\/o, burden on prgms like medicare & SS = too great.",
  "id" : 95969278142066689,
  "created_at" : "2011-07-26 21:30:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "Chris_For",
      "indices" : [ 4, 14 ],
      "id_str" : "338650252",
      "id" : 338650252
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95967159028682752",
  "geo" : { },
  "id_str" : "95968466862997504",
  "in_reply_to_user_id" : 338650252,
  "text" : "thx @Chris_For POTUS plan would eliminate subsidies that don't help economy (e.g. oil&gas) while reforming tax system to promote growth",
  "id" : 95968466862997504,
  "in_reply_to_status_id" : 95967159028682752,
  "created_at" : "2011-07-26 21:27:20 +0000",
  "in_reply_to_screen_name" : "Chris_For",
  "in_reply_to_user_id_str" : "338650252",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "officehours",
      "indices" : [ 63, 75 ]
    }, {
      "text" : "whchat",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 106 ],
      "url" : "http:\/\/t.co\/uUM8vFO",
      "expanded_url" : "http:\/\/goo.gl\/L0EwB",
      "display_url" : "goo.gl\/L0EwB"
    } ]
  },
  "geo" : { },
  "id_str" : "95968099974643714",
  "text" : "RT @macon44: snapped a pic of Brian Deese answering ?'s during #officehours more info: http:\/\/t.co\/uUM8vFO follow #whchat http:\/\/t.co\/kV ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/95967961407426561\/photo\/1",
        "indices" : [ 109, 128 ],
        "url" : "http:\/\/t.co\/kVDj6x6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AVTyWjnCEAAcsKg.jpg",
        "id_str" : "95967961411620864",
        "id" : 95967961411620864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AVTyWjnCEAAcsKg.jpg",
        "sizes" : [ {
          "h" : 3744,
          "resize" : "fit",
          "w" : 5616
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kVDj6x6"
      } ],
      "hashtags" : [ {
        "text" : "officehours",
        "indices" : [ 50, 62 ]
      }, {
        "text" : "whchat",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 93 ],
        "url" : "http:\/\/t.co\/uUM8vFO",
        "expanded_url" : "http:\/\/goo.gl\/L0EwB",
        "display_url" : "goo.gl\/L0EwB"
      } ]
    },
    "geo" : { },
    "id_str" : "95967961407426561",
    "text" : "snapped a pic of Brian Deese answering ?'s during #officehours more info: http:\/\/t.co\/uUM8vFO follow #whchat http:\/\/t.co\/kVDj6x6",
    "id" : 95967961407426561,
    "created_at" : "2011-07-26 21:25:20 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 95968099974643714,
  "created_at" : "2011-07-26 21:25:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cathy Battle",
      "screen_name" : "hippie2u",
      "indices" : [ 1, 10 ],
      "id_str" : "124070040",
      "id" : 124070040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http:\/\/t.co\/VvXIunK",
      "expanded_url" : "http:\/\/wh.gov\/rBp",
      "display_url" : "wh.gov\/rBp"
    } ]
  },
  "in_reply_to_status_id_str" : "95965603038367744",
  "geo" : { },
  "id_str" : "95967221226024960",
  "in_reply_to_user_id" : 124070040,
  "text" : ".@hippie2u: Check out new chart on sources of the debt. http:\/\/t.co\/VvXIunK. #WHChat",
  "id" : 95967221226024960,
  "in_reply_to_status_id" : 95965603038367744,
  "created_at" : "2011-07-26 21:22:23 +0000",
  "in_reply_to_screen_name" : "hippie2u",
  "in_reply_to_user_id_str" : "124070040",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam S",
      "screen_name" : "RebelRepublican",
      "indices" : [ 1, 17 ],
      "id_str" : "176823985",
      "id" : 176823985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95916850365468672",
  "geo" : { },
  "id_str" : "95965709703720960",
  "in_reply_to_user_id" : 176823985,
  "text" : ".@RebelRepublican POTUS wants balanced $4T plan. House GOP balked. Reid plan = downpayment & compromise, removes uncertainty avoids default",
  "id" : 95965709703720960,
  "in_reply_to_status_id" : 95916850365468672,
  "created_at" : "2011-07-26 21:16:22 +0000",
  "in_reply_to_screen_name" : "RebelRepublican",
  "in_reply_to_user_id_str" : "176823985",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "gmo418",
      "screen_name" : "gmo418",
      "indices" : [ 1, 8 ],
      "id_str" : "21830205",
      "id" : 21830205
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "95916847039393792",
  "geo" : { },
  "id_str" : "95964357405577216",
  "in_reply_to_user_id" : 21830205,
  "text" : ".@gmo418: POTUS strategy is to cut deficit and debt over medium and long term, phased in to not jeopardize economic growth #WHChat",
  "id" : 95964357405577216,
  "in_reply_to_status_id" : 95916847039393792,
  "created_at" : "2011-07-26 21:11:00 +0000",
  "in_reply_to_screen_name" : "gmo418",
  "in_reply_to_user_id_str" : "21830205",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 111 ],
      "url" : "http:\/\/t.co\/TDLuxQQ",
      "expanded_url" : "http:\/\/www.wh.gov\/officehours",
      "display_url" : "wh.gov\/officehours"
    } ]
  },
  "geo" : { },
  "id_str" : "95963594767872000",
  "text" : "Brian is here -- we're kicking off our first WH Office Hours now. Ask your Qs with #WHChat. http:\/\/t.co\/TDLuxQQ",
  "id" : 95963594767872000,
  "created_at" : "2011-07-26 21:07:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/TDLuxQQ",
      "expanded_url" : "http:\/\/www.wh.gov\/officehours",
      "display_url" : "wh.gov\/officehours"
    } ]
  },
  "geo" : { },
  "id_str" : "95962829718433792",
  "text" : "Starting shortly: WH Office Hours w\/ Brian Deese, Economic Advisor to the President. Use #WHChat to ask your Qs. http:\/\/t.co\/TDLuxQQ",
  "id" : 95962829718433792,
  "created_at" : "2011-07-26 21:04:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 87 ],
      "url" : "http:\/\/t.co\/oIJA0wq",
      "expanded_url" : "http:\/\/wh.gov\/rBR",
      "display_url" : "wh.gov\/rBR"
    }, {
      "indices" : [ 99, 118 ],
      "url" : "http:\/\/t.co\/bCY57II",
      "expanded_url" : "http:\/\/wh.gov\/rBK",
      "display_url" : "wh.gov\/rBK"
    } ]
  },
  "geo" : { },
  "id_str" : "95954152848502784",
  "text" : "INFOGRAPHIC: Where does our national #debt come from? View graphic: http:\/\/t.co\/oIJA0wq Read blog: http:\/\/t.co\/bCY57II",
  "id" : 95954152848502784,
  "created_at" : "2011-07-26 20:30:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95929048496222209",
  "text" : "RT @letsmove: FLOTUS on McDonald's announcement \"These are positive steps toward the goal of solving the problem of childhood obesity\u201D h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 140 ],
        "url" : "http:\/\/t.co\/fbsBRxi",
        "expanded_url" : "http:\/\/www.letsmove.gov\/blog\/2011\/07\/26\/first-lady-everyone-has-role-play-making-america-healthier",
        "display_url" : "letsmove.gov\/blog\/2011\/07\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "95923109508562944",
    "text" : "FLOTUS on McDonald's announcement \"These are positive steps toward the goal of solving the problem of childhood obesity\u201D http:\/\/t.co\/fbsBRxi",
    "id" : 95923109508562944,
    "created_at" : "2011-07-26 18:27:06 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 95929048496222209,
  "created_at" : "2011-07-26 18:50:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristina Klausser",
      "screen_name" : "kklausser",
      "indices" : [ 1, 11 ],
      "id_str" : "15410898",
      "id" : 15410898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "debt",
      "indices" : [ 65, 70 ]
    }, {
      "text" : "deficit",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95916763102969856",
  "text" : ".@kklausser: You can start asking your Qs for the #WHChat on the #debt & #deficit now & we'll take more at 5 ET when Brian is here.",
  "id" : 95916763102969856,
  "created_at" : "2011-07-26 18:01:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 21, 28 ]
    }, {
      "text" : "debt",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/Nlqqktg",
      "expanded_url" : "http:\/\/wh.gov\/rZR",
      "display_url" : "wh.gov\/rZR"
    } ]
  },
  "geo" : { },
  "id_str" : "95915203832709120",
  "text" : "WH Office Hours: Use #WHChat to ask your Qs on Obama's speech & ongoing #debt debate. Starts today @ 5ET, full sched: http:\/\/t.co\/Nlqqktg",
  "id" : 95915203832709120,
  "created_at" : "2011-07-26 17:55:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deficit",
      "indices" : [ 66, 74 ]
    }, {
      "text" : "debt",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/Ju2uyiM",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/0\/O08VHT6TsRM",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "95891281573720064",
  "text" : "President Obama on a balanced & bipartisan approach to reduce the #deficit & put us on a path to pay down #debt. Video: http:\/\/t.co\/Ju2uyiM",
  "id" : 95891281573720064,
  "created_at" : "2011-07-26 16:20:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "villaraigosa",
      "screen_name" : "villaraigosa",
      "indices" : [ 20, 33 ],
      "id_str" : "796800025749688322",
      "id" : 796800025749688322
    }, {
      "name" : "Michael A. Nutter",
      "screen_name" : "Michael_Nutter",
      "indices" : [ 34, 49 ],
      "id_str" : "202790178",
      "id" : 202790178
    }, {
      "name" : "potinleftgrog1",
      "screen_name" : "Mayor_Smith",
      "indices" : [ 52, 64 ],
      "id_str" : "2982225435",
      "id" : 2982225435
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 94, 99 ]
    }, {
      "text" : "balancedapproach",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/kRqbajd",
      "expanded_url" : "http:\/\/www.politico.com\/news\/stories\/0711\/59894.html",
      "display_url" : "politico.com\/news\/stories\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "95854654549794816",
  "text" : "RT @macon44: Mayors @villaraigosa @Michael_Nutter & @Mayor_Smith write abt the need to act on #debt http:\/\/t.co\/kRqbajd #balancedapproach",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "villaraigosa",
        "screen_name" : "villaraigosa",
        "indices" : [ 7, 20 ],
        "id_str" : "796800025749688322",
        "id" : 796800025749688322
      }, {
        "name" : "Michael A. Nutter",
        "screen_name" : "Michael_Nutter",
        "indices" : [ 21, 36 ],
        "id_str" : "202790178",
        "id" : 202790178
      }, {
        "name" : "potinleftgrog1",
        "screen_name" : "Mayor_Smith",
        "indices" : [ 39, 51 ],
        "id_str" : "2982225435",
        "id" : 2982225435
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debt",
        "indices" : [ 81, 86 ]
      }, {
        "text" : "balancedapproach",
        "indices" : [ 107, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 106 ],
        "url" : "http:\/\/t.co\/kRqbajd",
        "expanded_url" : "http:\/\/www.politico.com\/news\/stories\/0711\/59894.html",
        "display_url" : "politico.com\/news\/stories\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "95853905413541888",
    "text" : "Mayors @villaraigosa @Michael_Nutter & @Mayor_Smith write abt the need to act on #debt http:\/\/t.co\/kRqbajd #balancedapproach",
    "id" : 95853905413541888,
    "created_at" : "2011-07-26 13:52:06 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 95854654549794816,
  "created_at" : "2011-07-26 13:55:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/soPk6tN",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/07\/25\/tonight-9-president-obama-addresses-nation",
      "display_url" : "whitehouse.gov\/blog\/2011\/07\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "95702627731509250",
  "text" : "Something new: @whitehouse staff begin regular \"Office hours\" tmrw @ 5pm ET to answer ?'s. Use #WHChat. More: http:\/\/t.co\/soPk6tN",
  "id" : 95702627731509250,
  "created_at" : "2011-07-26 03:50:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUS",
      "indices" : [ 17, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95679093290434560",
  "text" : "RT @PressSec: As #POTUS said, Americans are \"fed up with a town where compromise has become a dirty word.\" Rs & Ds need to come together ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUS",
        "indices" : [ 3, 9 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95677829471150081",
    "text" : "As #POTUS said, Americans are \"fed up with a town where compromise has become a dirty word.\" Rs & Ds need to come together, and act.",
    "id" : 95677829471150081,
    "created_at" : "2011-07-26 02:12:26 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 95679093290434560,
  "created_at" : "2011-07-26 02:17:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 120 ],
      "url" : "http:\/\/t.co\/ZQj8XeA",
      "expanded_url" : "http:\/\/www.wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "95664945835945985",
  "text" : "President Obama just finished his address to the nation -- the transcript & video will be up soon on http:\/\/t.co\/ZQj8XeA",
  "id" : 95664945835945985,
  "created_at" : "2011-07-26 01:21:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95664454984933377",
  "text" : "Let\u2019s seize this moment to show why the United States of America is still the greatest nation on Earth. -President Obama",
  "id" : 95664454984933377,
  "created_at" : "2011-07-26 01:19:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95663657320595456",
  "text" : "We remember the Americans who held this country together...who put aside pride & party to form a more perfect union.",
  "id" : 95663657320595456,
  "created_at" : "2011-07-26 01:16:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95663307855368192",
  "text" : "So I\u2019m asking you all to make your voice heard.  If you want a balanced approach to reducing the deficit, let your Member of Congress know.",
  "id" : 95663307855368192,
  "created_at" : "2011-07-26 01:14:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "95662719117692929",
  "text" : "\"We can\u2019t allow the American people to become collateral damage to Washington\u2019s political warfare.\" -President Obama http:\/\/t.co\/hOlVdV1",
  "id" : 95662719117692929,
  "created_at" : "2011-07-26 01:12:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "95661899626192896",
  "text" : "Today, many Republicans in the House refuse to consider this kind of balanced approach...we are left with a stalemate. http:\/\/t.co\/hOlVdV1",
  "id" : 95661899626192896,
  "created_at" : "2011-07-26 01:09:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95661413946765312",
  "text" : "Keep in mind that under a balanced approach, the 98% of Americans who make under $250,000 would see no tax increases at all. -Pres Obama",
  "id" : 95661413946765312,
  "created_at" : "2011-07-26 01:07:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "95660688600600576",
  "text" : "\"Let\u2019s live within our means by making serious, historic cuts in government spending.\" -President Obama http:\/\/t.co\/hOlVdV1",
  "id" : 95660688600600576,
  "created_at" : "2011-07-26 01:04:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "95659308427116544",
  "text" : "Watch President Obama's address to the nation at 9 ET on http:\/\/t.co\/hOlVdV1 & we'll be live tweeting here.",
  "id" : 95659308427116544,
  "created_at" : "2011-07-26 00:58:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deficit",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/9Agjyos",
      "expanded_url" : "http:\/\/wh.gov\/rW1",
      "display_url" : "wh.gov\/rW1"
    } ]
  },
  "geo" : { },
  "id_str" : "95639935008256000",
  "text" : "Live @ 9ET: Pres Obama will address the nation on the stalemate in Washington & the best approach to cut the #deficit. http:\/\/t.co\/9Agjyos",
  "id" : 95639935008256000,
  "created_at" : "2011-07-25 23:41:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 35, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95623252973592576",
  "text" : "RT @JoiningForces: Introducing the #JoiningForces Community Challenge to recognize those that are giving back to military families: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 16, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 132 ],
        "url" : "http:\/\/t.co\/VnQExtS",
        "expanded_url" : "http:\/\/joiningforces.challenge.gov\/",
        "display_url" : "joiningforces.challenge.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "95622779105320960",
    "text" : "Introducing the #JoiningForces Community Challenge to recognize those that are giving back to military families: http:\/\/t.co\/VnQExtS",
    "id" : 95622779105320960,
    "created_at" : "2011-07-25 22:33:41 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 95623252973592576,
  "created_at" : "2011-07-25 22:35:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95590789110964224",
  "text" : "RT @PressSec: POTUS to address nation, 9 pm tonight, re stalemate over avoiding default and the best approach to cutting deficits. Watch ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95590617853345793",
    "text" : "POTUS to address nation, 9 pm tonight, re stalemate over avoiding default and the best approach to cutting deficits. Watch @ wh.gov\/live.",
    "id" : 95590617853345793,
    "created_at" : "2011-07-25 20:25:53 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 95590789110964224,
  "created_at" : "2011-07-25 20:26:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SFGiants",
      "screen_name" : "SFGiants",
      "indices" : [ 69, 78 ],
      "id_str" : "43024351",
      "id" : 43024351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 111 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "95584756997160960",
  "text" : "Happening now: President Obama honors the 2010 World Series Champion @SFGiants. Watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 95584756997160960,
  "created_at" : "2011-07-25 20:02:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 1, 13 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/pszLHR4",
      "expanded_url" : "http:\/\/wh.gov\/rDI",
      "display_url" : "wh.gov\/rDI"
    } ]
  },
  "geo" : { },
  "id_str" : "95581534471462913",
  "text" : ".@SenatorReid's plan is a reasonable approach that should receive the support of both parties...ball is in their court. http:\/\/t.co\/pszLHR4",
  "id" : 95581534471462913,
  "created_at" : "2011-07-25 19:49:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 18, 27 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95574132917403648",
  "text" : "RT @jesseclee44: .@presssec: Reid plan is \"meaningful down payment\" on deficits, could continue work on closing loopholes for wealthiest ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 1, 10 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 139 ],
        "url" : "http:\/\/t.co\/7yDI4WC",
        "expanded_url" : "http:\/\/wh.gov\/rDI",
        "display_url" : "wh.gov\/rDI"
      } ]
    },
    "geo" : { },
    "id_str" : "95573617265491968",
    "text" : ".@presssec: Reid plan is \"meaningful down payment\" on deficits, could continue work on closing loopholes for wealthiest http:\/\/t.co\/7yDI4WC",
    "id" : 95573617265491968,
    "created_at" : "2011-07-25 19:18:20 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 95574132917403648,
  "created_at" : "2011-07-25 19:20:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95561210438762496",
  "text" : "RT @pfeiffer44: Stories saying that POTUS rejected a bipartisan proposal are false, Sen Reid never agreed to a short term deal per  @AJe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Jentleson",
        "screen_name" : "AJentleson",
        "indices" : [ 116, 127 ],
        "id_str" : "17466132",
        "id" : 17466132
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "95559946116153344",
    "text" : "Stories saying that POTUS rejected a bipartisan proposal are false, Sen Reid never agreed to a short term deal per  @AJentleson",
    "id" : 95559946116153344,
    "created_at" : "2011-07-25 18:24:01 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 95561210438762496,
  "created_at" : "2011-07-25 18:29:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SFGiants",
      "screen_name" : "SFGiants",
      "indices" : [ 48, 57 ],
      "id_str" : "43024351",
      "id" : 43024351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95556564735377408",
  "text" : "Today, the President honors World Series Champs @SFGiants on their victory & for giving back to their community. How are you giving back?",
  "id" : 95556564735377408,
  "created_at" : "2011-07-25 18:10:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Steve Benen",
      "screen_name" : "stevebenen",
      "indices" : [ 35, 46 ],
      "id_str" : "27511061",
      "id" : 27511061
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 89, 104 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95506209645404160",
  "text" : "RT @pfeiffer44: Great rundown from @stevebenen of the long list of reasonable deals that @SpeakerBoehner and the House GOP have rejected ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Benen",
        "screen_name" : "stevebenen",
        "indices" : [ 19, 30 ],
        "id_str" : "27511061",
        "id" : 27511061
      }, {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 73, 88 ],
        "id_str" : "7713202",
        "id" : 7713202
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 140 ],
        "url" : "http:\/\/t.co\/4wKd2kk",
        "expanded_url" : "http:\/\/bit.ly\/mYNDEP",
        "display_url" : "bit.ly\/mYNDEP"
      } ]
    },
    "geo" : { },
    "id_str" : "95503161183313920",
    "text" : "Great rundown from @stevebenen of the long list of reasonable deals that @SpeakerBoehner and the House GOP have rejected http:\/\/t.co\/4wKd2kk",
    "id" : 95503161183313920,
    "created_at" : "2011-07-25 14:38:22 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 95506209645404160,
  "created_at" : "2011-07-25 14:50:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 22, 37 ],
      "id_str" : "2467791",
      "id" : 2467791
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 74, 85 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whtweetup",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95486278480568321",
  "text" : "RT @macon44: Read the @washingtonpost article abt last week's #whtweetup: @WhiteHouse tries to stay connected with top \u2018tweeters\u2019 http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 9, 24 ],
        "id_str" : "2467791",
        "id" : 2467791
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 61, 72 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whtweetup",
        "indices" : [ 49, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 136 ],
        "url" : "http:\/\/t.co\/mX2GZ15",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/44\/post\/white-house-tries-to-stay-connected-with-top-tweeters\/2011\/07\/22\/gIQAyJJ6TI_blog.html#pagebreak",
        "display_url" : "washingtonpost.com\/blogs\/44\/post\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "95484473898045440",
    "text" : "Read the @washingtonpost article abt last week's #whtweetup: @WhiteHouse tries to stay connected with top \u2018tweeters\u2019 http:\/\/t.co\/mX2GZ15",
    "id" : 95484473898045440,
    "created_at" : "2011-07-25 13:24:07 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 95486278480568321,
  "created_at" : "2011-07-25 13:31:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 22, 33 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/PpHF0kk",
      "expanded_url" : "http:\/\/1.usa.gov\/pxVTEe",
      "display_url" : "1.usa.gov\/pxVTEe"
    } ]
  },
  "geo" : { },
  "id_str" : "95475285000060928",
  "text" : "RT @jesseclee44: From @pfeiffer44: \"Some Rs in Congress Once Argued Against Short-Term Solutions-They Were Right\" http:\/\/t.co\/PpHF0kk #p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 5, 16 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 117, 120 ]
      }, {
        "text" : "tcot",
        "indices" : [ 121, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 116 ],
        "url" : "http:\/\/t.co\/PpHF0kk",
        "expanded_url" : "http:\/\/1.usa.gov\/pxVTEe",
        "display_url" : "1.usa.gov\/pxVTEe"
      } ]
    },
    "geo" : { },
    "id_str" : "95467776831012864",
    "text" : "From @pfeiffer44: \"Some Rs in Congress Once Argued Against Short-Term Solutions-They Were Right\" http:\/\/t.co\/PpHF0kk #p2 #tcot",
    "id" : 95467776831012864,
    "created_at" : "2011-07-25 12:17:46 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 95475285000060928,
  "created_at" : "2011-07-25 12:47:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 23, 26 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deficit",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94786793823666176",
  "text" : "Today, the President & @VP Biden are meeting w\/ Congressional leadership @ the WH to cont to work out a #deficit deal & avoid default.",
  "id" : 94786793823666176,
  "created_at" : "2011-07-23 15:11:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/jg3vzD6",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/07\/22\/if-you-want-be-leader-then-you-got-lead-0",
      "display_url" : "whitehouse.gov\/blog\/2011\/07\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "94773911446757377",
  "text" : "\"If you want to be a leader, then you got to lead\" -President Obama on cutting the deficit. Full video of presser: http:\/\/t.co\/jg3vzD6",
  "id" : 94773911446757377,
  "created_at" : "2011-07-23 14:20:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/qZvhorH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=1IBTGcehElI&feature=channel_video_title",
      "display_url" : "youtube.com\/watch?v=1IBTGc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "94715931040817152",
  "text" : "Weekly address: President Obama on the urgency of Democrats & Republicans coming together to take a balanced approach: http:\/\/t.co\/qZvhorH",
  "id" : 94715931040817152,
  "created_at" : "2011-07-23 10:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 34, 37 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 46, 60 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "indices" : [ 67, 81 ],
      "id_str" : "28576135",
      "id" : 28576135
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94551159007744000",
  "text" : "Photo of the Day: The President & @VP meet w\/ @DeptofDefense Sec & @thejointstaff on #DADT repeal certification: http:\/\/twitpic.com\/5u871l",
  "id" : 94551159007744000,
  "created_at" : "2011-07-22 23:35:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/WcMwSEK",
      "expanded_url" : "http:\/\/wh.gov\/rTg",
      "display_url" : "wh.gov\/rTg"
    } ]
  },
  "geo" : { },
  "id_str" : "94544843707138048",
  "text" : "Getting Don't Ask, Don't Tell Done: Today President Obama signed a certification ending #DADT once & for all in 60 days: http:\/\/t.co\/WcMwSEK",
  "id" : 94544843707138048,
  "created_at" : "2011-07-22 23:10:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FAA",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/8rppEJt",
      "expanded_url" : "http:\/\/bit.ly\/o6GL9q",
      "display_url" : "bit.ly\/o6GL9q"
    } ]
  },
  "geo" : { },
  "id_str" : "94540220753645571",
  "text" : "RT @RayLaHood: I\u2019m very disappointed that Congress adjourned today without passing a clean extension of the #FAA bill.  http:\/\/t.co\/8rppEJt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FAA",
        "indices" : [ 93, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 124 ],
        "url" : "http:\/\/t.co\/8rppEJt",
        "expanded_url" : "http:\/\/bit.ly\/o6GL9q",
        "display_url" : "bit.ly\/o6GL9q"
      } ]
    },
    "geo" : { },
    "id_str" : "94539363999944704",
    "text" : "I\u2019m very disappointed that Congress adjourned today without passing a clean extension of the #FAA bill.  http:\/\/t.co\/8rppEJt",
    "id" : 94539363999944704,
    "created_at" : "2011-07-22 22:48:35 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 94540220753645571,
  "created_at" : "2011-07-22 22:51:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94536870452662272",
  "text" : "\"If you want to be a leader, then you\u2019ve got to lead.\" -President Obama on solving the deficit problem for the American people.",
  "id" : 94536870452662272,
  "created_at" : "2011-07-22 22:38:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "94534413215469568",
  "text" : "\"We're willing to make the tough cuts & take on the heat - but there's got to be balance in the process.\" -Pres Obama http:\/\/t.co\/hOlVdV1",
  "id" : 94534413215469568,
  "created_at" : "2011-07-22 22:28:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94533323115872256",
  "text" : "\"I\u2019ve gone out of my way to say both parties have to make compromises\" -President Obama on solving the nation\u2019s deficit problem.",
  "id" : 94533323115872256,
  "created_at" : "2011-07-22 22:24:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 91 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "94529996030357504",
  "text" : "\"We have now run out of time.\" -President Obama on the debt deal. Live: http:\/\/t.co\/hOlVdV1",
  "id" : 94529996030357504,
  "created_at" : "2011-07-22 22:11:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "94529571474505728",
  "text" : "\"This was an extraordinarily fair deal.\" -President Obama on the deficit  deal offered. Live now: http:\/\/t.co\/hOlVdV1",
  "id" : 94529571474505728,
  "created_at" : "2011-07-22 22:09:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 107 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "94527387143901187",
  "text" : "Starting soon: President Obama delivers a statement from the Briefing Room. Watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 94527387143901187,
  "created_at" : "2011-07-22 22:00:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Univ. of Maryland",
      "screen_name" : "UofMaryland",
      "indices" : [ 85, 97 ],
      "id_str" : "16129880",
      "id" : 16129880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 118 ],
      "url" : "http:\/\/t.co\/ptKbQAG",
      "expanded_url" : "http:\/\/wh.gov\/r2v",
      "display_url" : "wh.gov\/r2v"
    } ]
  },
  "geo" : { },
  "id_str" : "94475442861518848",
  "text" : "\"I'm willing to sign a plan that includes tough choices\" President Obama to students @UofMaryland: http:\/\/t.co\/ptKbQAG",
  "id" : 94475442861518848,
  "created_at" : "2011-07-22 18:34:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecDef",
      "indices" : [ 14, 21 ]
    }, {
      "text" : "Pentagon",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94464504280268802",
  "text" : "RT @VP: PHOTO:#SecDef Panetta delivers remarks at #Pentagon after being sworn in by VP earlier today (WH-photo David Lienemann) http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/94463973717581824\/photo\/1",
        "indices" : [ 120, 139 ],
        "url" : "http:\/\/t.co\/yH9pvox",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AU-ae82CIAEdNwu.jpg",
        "id_str" : "94463973717581825",
        "id" : 94463973717581825,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AU-ae82CIAEdNwu.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/yH9pvox"
      } ],
      "hashtags" : [ {
        "text" : "SecDef",
        "indices" : [ 6, 13 ]
      }, {
        "text" : "Pentagon",
        "indices" : [ 42, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94463973717581824",
    "text" : "PHOTO:#SecDef Panetta delivers remarks at #Pentagon after being sworn in by VP earlier today (WH-photo David Lienemann) http:\/\/t.co\/yH9pvox",
    "id" : 94463973717581824,
    "created_at" : "2011-07-22 17:49:01 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 94464504280268802,
  "created_at" : "2011-07-22 17:51:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whtweetup",
      "indices" : [ 56, 66 ]
    }, {
      "text" : "umdtownhall",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94454625679319040",
  "text" : "RT @GovernorOMalley: Glad I had a chance to stop by the #whtweetup after the #umdtownhall.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whtweetup",
        "indices" : [ 35, 45 ]
      }, {
        "text" : "umdtownhall",
        "indices" : [ 56, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94447290646937600",
    "text" : "Glad I had a chance to stop by the #whtweetup after the #umdtownhall.",
    "id" : 94447290646937600,
    "created_at" : "2011-07-22 16:42:43 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 94454625679319040,
  "created_at" : "2011-07-22 17:11:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Hughes, Psy.D",
      "screen_name" : "katpenwell",
      "indices" : [ 3, 14 ],
      "id_str" : "18801350",
      "id" : 18801350
    }, {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 23, 39 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http:\/\/t.co\/cPjb5No",
      "expanded_url" : "http:\/\/yfrog.com\/kkae4mdj",
      "display_url" : "yfrog.com\/kkae4mdj"
    } ]
  },
  "geo" : { },
  "id_str" : "94444997046317056",
  "text" : "RT @katpenwell: Thanks @GovernorOMalley for stopping by! #WHTweetup  http:\/\/t.co\/cPjb5No",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gov. Martin O'Malley",
        "screen_name" : "GovernorOMalley",
        "indices" : [ 7, 23 ],
        "id_str" : "3343532685",
        "id" : 3343532685
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 41, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 72 ],
        "url" : "http:\/\/t.co\/cPjb5No",
        "expanded_url" : "http:\/\/yfrog.com\/kkae4mdj",
        "display_url" : "yfrog.com\/kkae4mdj"
      } ]
    },
    "geo" : { },
    "id_str" : "94444381955829760",
    "text" : "Thanks @GovernorOMalley for stopping by! #WHTweetup  http:\/\/t.co\/cPjb5No",
    "id" : 94444381955829760,
    "created_at" : "2011-07-22 16:31:10 +0000",
    "user" : {
      "name" : "Kat Hughes, Psy.D",
      "screen_name" : "katpenwell",
      "protected" : false,
      "id_str" : "18801350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661345396841684994\/0GJBSAyg_normal.jpg",
      "id" : 18801350,
      "verified" : false
    }
  },
  "id" : 94444997046317056,
  "created_at" : "2011-07-22 16:33:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Golden",
      "screen_name" : "chrisgolden",
      "indices" : [ 3, 15 ],
      "id_str" : "15292471",
      "id" : 15292471
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 89, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94442967099637760",
  "text" : "RT @chrisgolden: .@whitehouse. Deputy Principal Press Secretary answers questions during #WHTweetup http:\/\/twitpic.com\/5u29fh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 72, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94441611282497536",
    "text" : ".@whitehouse. Deputy Principal Press Secretary answers questions during #WHTweetup http:\/\/twitpic.com\/5u29fh",
    "id" : 94441611282497536,
    "created_at" : "2011-07-22 16:20:09 +0000",
    "user" : {
      "name" : "Chris Golden",
      "screen_name" : "chrisgolden",
      "protected" : false,
      "id_str" : "15292471",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763850143275724800\/0Rztl6x-_normal.jpg",
      "id" : 15292471,
      "verified" : false
    }
  },
  "id" : 94442967099637760,
  "created_at" : "2011-07-22 16:25:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "indices" : [ 3, 13 ],
      "id_str" : "1175221",
      "id" : 1175221
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 90, 102 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHtweetup",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94439332974305280",
  "text" : "RT @digiphile: \"I am absolutely convinced that your generation will solve these problems\"-@BarackObama #WHtweetup http:\/\/instagr.am\/p\/IPfWF\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 75, 87 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHtweetup",
        "indices" : [ 88, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94438989527916545",
    "text" : "\"I am absolutely convinced that your generation will solve these problems\"-@BarackObama #WHtweetup http:\/\/instagr.am\/p\/IPfWF\/",
    "id" : 94438989527916545,
    "created_at" : "2011-07-22 16:09:44 +0000",
    "user" : {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "protected" : false,
      "id_str" : "1175221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787135485361684480\/smcj17ad_normal.jpg",
      "id" : 1175221,
      "verified" : true
    }
  },
  "id" : 94439332974305280,
  "created_at" : "2011-07-22 16:11:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jutha",
      "screen_name" : "adamjutha",
      "indices" : [ 3, 13 ],
      "id_str" : "186755793",
      "id" : 186755793
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94439230494867456",
  "text" : "RT @adamjutha: Obama: \"We've always emerged on the other side stronger, more unified... More tolerant.  You give me incredible hope.\" #W ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 119, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94438333148704768",
    "text" : "Obama: \"We've always emerged on the other side stronger, more unified... More tolerant.  You give me incredible hope.\" #WHTweetup",
    "id" : 94438333148704768,
    "created_at" : "2011-07-22 16:07:07 +0000",
    "user" : {
      "name" : "Adam Jutha",
      "screen_name" : "adamjutha",
      "protected" : false,
      "id_str" : "186755793",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000812571232\/4372129405c714684de8622033e098da_normal.jpeg",
      "id" : 186755793,
      "verified" : false
    }
  },
  "id" : 94439230494867456,
  "created_at" : "2011-07-22 16:10:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ONE",
      "screen_name" : "ONECampaign",
      "indices" : [ 24, 36 ],
      "id_str" : "16348549",
      "id" : 16348549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94438247954001921",
  "geo" : { },
  "id_str" : "94439187033489408",
  "in_reply_to_user_id" : 16348549,
  "text" : "Sorry gotta go thks for @ONECampaign appreciate all you do to engage the world keep it up. Thks everyone for joining us - GS",
  "id" : 94439187033489408,
  "in_reply_to_status_id" : 94438247954001921,
  "created_at" : "2011-07-22 16:10:31 +0000",
  "in_reply_to_screen_name" : "ONECampaign",
  "in_reply_to_user_id_str" : "16348549",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Lopez",
      "screen_name" : "jbondslopez",
      "indices" : [ 1, 13 ],
      "id_str" : "22117141",
      "id" : 22117141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94438716982038529",
  "text" : ".@jbondslopez. Great Q: transparency, transparency, transparency. Make sure govts accountable & citizens engaged\/empowered.",
  "id" : 94438716982038529,
  "created_at" : "2011-07-22 16:08:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Dumais",
      "screen_name" : "JRGGLASS",
      "indices" : [ 3, 12 ],
      "id_str" : "2249550353",
      "id" : 2249550353
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94438341201756160",
  "text" : "RT @JRGGlass: \"We don't have time to wait when it comes to putting people back to work\" -B.O. #WHTweetup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 80, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94437610218459136",
    "text" : "\"We don't have time to wait when it comes to putting people back to work\" -B.O. #WHTweetup",
    "id" : 94437610218459136,
    "created_at" : "2011-07-22 16:04:15 +0000",
    "user" : {
      "name" : "Rob Glass",
      "screen_name" : "JRobGlass",
      "protected" : false,
      "id_str" : "25147055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1405775586\/Glass_BOT_Debate_Thelmo_2011_normal.jpg",
      "id" : 25147055,
      "verified" : false
    }
  },
  "id" : 94438341201756160,
  "created_at" : "2011-07-22 16:07:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meghan Mize",
      "screen_name" : "MeghanMize",
      "indices" : [ 1, 12 ],
      "id_str" : "29055871",
      "id" : 29055871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94438019528011776",
  "text" : ".@MeghanMize. WH focused on getting best deal for American people & ensuring we maintain our leadership role in world",
  "id" : 94438019528011776,
  "created_at" : "2011-07-22 16:05:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94437809032667137",
  "text" : "RT @GovernorOMalley: We'll continue to invest in our #1 ranked schools bc we know that education is the key to winning the future.#umdto ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "umdtownhall",
        "indices" : [ 109, 121 ]
      }, {
        "text" : "Maryland",
        "indices" : [ 122, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94435404303970304",
    "text" : "We'll continue to invest in our #1 ranked schools bc we know that education is the key to winning the future.#umdtownhall #Maryland",
    "id" : 94435404303970304,
    "created_at" : "2011-07-22 15:55:29 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 94437809032667137,
  "created_at" : "2011-07-22 16:05:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sheilanix",
      "screen_name" : "sheilanix",
      "indices" : [ 1, 11 ],
      "id_str" : "16569925",
      "id" : 16569925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94436863875620864",
  "text" : ".@sheilanix Helps to tell stories, fill in background, highlight human part of development, show multi-dimensions of Africa",
  "id" : 94436863875620864,
  "created_at" : "2011-07-22 16:01:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94435619371089920",
  "text" : ".@Tubasaxa. Thru global health, food security, supt to UN orgs & NGOs. Big focus in Haiti & famine now.",
  "id" : 94435619371089920,
  "created_at" : "2011-07-22 15:56:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Mayle",
      "screen_name" : "EricMayle",
      "indices" : [ 1, 11 ],
      "id_str" : "45754779",
      "id" : 45754779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94434633499951105",
  "text" : ".@EricMayle Ramping up prevention;new efficiencies mean treatment $s go further; new donors in mix; other countries must keep commitments",
  "id" : 94434633499951105,
  "created_at" : "2011-07-22 15:52:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Fifer",
      "screen_name" : "CraigFifer",
      "indices" : [ 3, 14 ],
      "id_str" : "20121030",
      "id" : 20121030
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 22, 34 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94434180859043844",
  "text" : "RT @craigfifer: Pres. @BarackObama says compromise doesn't mean giving up convictions, says even Lincoln didn't get everything wanted fm ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 6, 18 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whtweetup",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94433378169917440",
    "text" : "Pres. @BarackObama says compromise doesn't mean giving up convictions, says even Lincoln didn't get everything wanted fm Em.Proc. #whtweetup",
    "id" : 94433378169917440,
    "created_at" : "2011-07-22 15:47:26 +0000",
    "user" : {
      "name" : "Craig Fifer",
      "screen_name" : "CraigFifer",
      "protected" : false,
      "id_str" : "20121030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470914777150001152\/WO8zdqG3_normal.jpeg",
      "id" : 20121030,
      "verified" : false
    }
  },
  "id" : 94434180859043844,
  "created_at" : "2011-07-22 15:50:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ONE",
      "screen_name" : "ONECampaign",
      "indices" : [ 1, 13 ],
      "id_str" : "16348549",
      "id" : 16348549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "94431360860688384",
  "geo" : { },
  "id_str" : "94432370563891200",
  "in_reply_to_user_id" : 16348549,
  "text" : ".@ONECampaign US is leading and leveraging other donors; ramping up response; confident American public will also once again step up",
  "id" : 94432370563891200,
  "in_reply_to_status_id" : 94431360860688384,
  "created_at" : "2011-07-22 15:43:26 +0000",
  "in_reply_to_screen_name" : "ONECampaign",
  "in_reply_to_user_id_str" : "16348549",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CARE (care.org)",
      "screen_name" : "CARE",
      "indices" : [ 1, 6 ],
      "id_str" : "16834046",
      "id" : 16834046
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94431144984051714",
  "text" : ".@CARE WH committed to robust Somalia emergency response. Doing 2 things: meet urgent needs & invest in food security for long term.",
  "id" : 94431144984051714,
  "created_at" : "2011-07-22 15:38:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ONE",
      "screen_name" : "ONECampaign",
      "indices" : [ 106, 118 ],
      "id_str" : "16348549",
      "id" : 16348549
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foreign",
      "indices" : [ 21, 29 ]
    }, {
      "text" : "development",
      "indices" : [ 38, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94430072873816064",
  "text" : "Twitter interview on #foreign aid and #development with WH\u2019s Gayle Smith is starting now. Send your Qs to @ONECampaign.",
  "id" : 94430072873816064,
  "created_at" : "2011-07-22 15:34:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ONE",
      "screen_name" : "ONECampaign",
      "indices" : [ 106, 118 ],
      "id_str" : "16348549",
      "id" : 16348549
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "foreign",
      "indices" : [ 21, 29 ]
    }, {
      "text" : "development",
      "indices" : [ 38, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94429916367560704",
  "text" : "Twitter interview on #foreign aid and #development with WH\u2019s Gayle Smith is starting now. Send your Qs to @ONECampaign.",
  "id" : 94429916367560704,
  "created_at" : "2011-07-22 15:33:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Univ. of Maryland",
      "screen_name" : "UofMaryland",
      "indices" : [ 14, 26 ],
      "id_str" : "16129880",
      "id" : 16129880
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "WHTweetup",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "94429181017980928",
  "text" : "Lots of folks @UofMaryland for Obama's Town Hall & #WHTweetup. Follow the discussion: #WHTweetup & watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 94429181017980928,
  "created_at" : "2011-07-22 15:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Springer",
      "screen_name" : "stephaniekays",
      "indices" : [ 3, 17 ],
      "id_str" : "19240173",
      "id" : 19240173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whtweetup",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94427288774508544",
  "text" : "RT @stephaniekays: \"In 2010, Americans chose a divided government. But they didn't choose a dysfunctional government.\" #whtweetup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whtweetup",
        "indices" : [ 100, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94426984939126784",
    "text" : "\"In 2010, Americans chose a divided government. But they didn't choose a dysfunctional government.\" #whtweetup",
    "id" : 94426984939126784,
    "created_at" : "2011-07-22 15:22:02 +0000",
    "user" : {
      "name" : "Stephanie Springer",
      "screen_name" : "stephaniekays",
      "protected" : false,
      "id_str" : "19240173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3688614406\/9c7c3b7c011b8f4165385101ecbc0f88_normal.jpeg",
      "id" : 19240173,
      "verified" : false
    }
  },
  "id" : 94427288774508544,
  "created_at" : "2011-07-22 15:23:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94424886331707392",
  "text" : "Both parties have a responsibility to solve it...if we don\u2019t solve the problem, every American will suffer.  -Obama on reducing the deficit",
  "id" : 94424886331707392,
  "created_at" : "2011-07-22 15:13:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Univ. of Maryland",
      "screen_name" : "UofMaryland",
      "indices" : [ 42, 54 ],
      "id_str" : "16129880",
      "id" : 16129880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 92 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "94422134297862145",
  "text" : "Just started: President Obama's Town Hall @UofMaryland. Watch live here: http:\/\/t.co\/hOlVdV1",
  "id" : 94422134297862145,
  "created_at" : "2011-07-22 15:02:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/zBecAER",
      "expanded_url" : "http:\/\/www.defense.gov\/live\/",
      "display_url" : "defense.gov\/live\/"
    } ]
  },
  "geo" : { },
  "id_str" : "94419928672768000",
  "text" : "RT @VP: Happening at 11 AM: VP will swear-in Defense Secretary Panetta at formal Pentagon ceremony. WATCH LIVE http:\/\/t.co\/zBecAER @Dept ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Dept of Defense",
        "screen_name" : "DeptofDefense",
        "indices" : [ 123, 137 ],
        "id_str" : "66369181",
        "id" : 66369181
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 122 ],
        "url" : "http:\/\/t.co\/zBecAER",
        "expanded_url" : "http:\/\/www.defense.gov\/live\/",
        "display_url" : "defense.gov\/live\/"
      } ]
    },
    "geo" : { },
    "id_str" : "94419790478839809",
    "text" : "Happening at 11 AM: VP will swear-in Defense Secretary Panetta at formal Pentagon ceremony. WATCH LIVE http:\/\/t.co\/zBecAER @DeptofDefense",
    "id" : 94419790478839809,
    "created_at" : "2011-07-22 14:53:26 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 94419928672768000,
  "created_at" : "2011-07-22 14:53:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ONE",
      "screen_name" : "ONECampaign",
      "indices" : [ 108, 120 ],
      "id_str" : "16348549",
      "id" : 16348549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/xRtpxOE",
      "expanded_url" : "http:\/\/wh.gov\/r47",
      "display_url" : "wh.gov\/r47"
    } ]
  },
  "geo" : { },
  "id_str" : "94410286697684994",
  "text" : "Happening @ 11:30 ET: Gayle Smith, WH Sr. Dir. for Dev. & Dem. will answer Qs on development & aid. Tweet Q @ONECampaign http:\/\/t.co\/xRtpxOE",
  "id" : 94410286697684994,
  "created_at" : "2011-07-22 14:15:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 41, 50 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http:\/\/t.co\/ApXkVsb",
      "expanded_url" : "http:\/\/www.usatoday.com\/news\/opinion\/forum\/2011-07-21-obama-debt-ceiling-debate_n.htm",
      "display_url" : "usatoday.com\/news\/opinion\/f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "94390786468216832",
  "text" : "Go 'big' on debt deal: President Obama's @USAToday editorial: http:\/\/t.co\/ApXkVsb",
  "id" : 94390786468216832,
  "created_at" : "2011-07-22 12:58:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ONE",
      "screen_name" : "ONECampaign",
      "indices" : [ 3, 15 ],
      "id_str" : "16348549",
      "id" : 16348549
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 59, 70 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "ONE",
      "screen_name" : "ONECampaign",
      "indices" : [ 86, 98 ],
      "id_str" : "16348549",
      "id" : 16348549
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "development",
      "indices" : [ 31, 43 ]
    }, {
      "text" : "aid",
      "indices" : [ 46, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94159363694006272",
  "text" : "RT @ONECampaign: Got a Q about #development & #aid for the @WhiteHouse? Tweet them to @ONECampaign now.\nhttp:\/\/bit.ly\/p5CmmR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/smallact.com\/\" rel=\"nofollow\"\u003ESMX:Thrive\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 42, 53 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "ONE",
        "screen_name" : "ONECampaign",
        "indices" : [ 69, 81 ],
        "id_str" : "16348549",
        "id" : 16348549
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "development",
        "indices" : [ 14, 26 ]
      }, {
        "text" : "aid",
        "indices" : [ 29, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94157336465252352",
    "text" : "Got a Q about #development & #aid for the @WhiteHouse? Tweet them to @ONECampaign now.\nhttp:\/\/bit.ly\/p5CmmR",
    "id" : 94157336465252352,
    "created_at" : "2011-07-21 21:30:33 +0000",
    "user" : {
      "name" : "ONE",
      "screen_name" : "ONECampaign",
      "protected" : false,
      "id_str" : "16348549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553288704454701057\/WPpw-ZK1_normal.jpeg",
      "id" : 16348549,
      "verified" : true
    }
  },
  "id" : 94159363694006272,
  "created_at" : "2011-07-21 21:38:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 104, 118 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94155181943558144",
  "text" : "RT @VP: VP will swear-in Secretary of Defense Leon Panetta in ceremony at Pentagon tomorrow at 11:00 AM @DeptofDefense",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Dept of Defense",
        "screen_name" : "DeptofDefense",
        "indices" : [ 96, 110 ],
        "id_str" : "66369181",
        "id" : 66369181
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94154620615659520",
    "text" : "VP will swear-in Secretary of Defense Leon Panetta in ceremony at Pentagon tomorrow at 11:00 AM @DeptofDefense",
    "id" : 94154620615659520,
    "created_at" : "2011-07-21 21:19:45 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 94155181943558144,
  "created_at" : "2011-07-21 21:21:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http:\/\/t.co\/jIP7KqD",
      "expanded_url" : "http:\/\/wh.gov\/rgB",
      "display_url" : "wh.gov\/rgB"
    } ]
  },
  "geo" : { },
  "id_str" : "94146791221637120",
  "text" : "One year later: What Wall Street Reform means for you: http:\/\/t.co\/jIP7KqD",
  "id" : 94146791221637120,
  "created_at" : "2011-07-21 20:48:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 83, 91 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94092102408998912",
  "text" : "RT @pfeiffer44: Wrong. POTUS pushing for biggest deal possible, but nothing new MT @nytimes: NYT NEWS ALERT: Obama and Boehner Close to  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 67, 75 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "94088906588430336",
    "text" : "Wrong. POTUS pushing for biggest deal possible, but nothing new MT @nytimes: NYT NEWS ALERT: Obama and Boehner Close to Major Budget Deal",
    "id" : 94088906588430336,
    "created_at" : "2011-07-21 16:58:38 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 94092102408998912,
  "created_at" : "2011-07-21 17:11:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/Q9GQE0R",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=OmUid7c50zo&feature=player_embedded",
      "display_url" : "youtube.com\/watch?v=OmUid7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "94086199181983744",
  "text" : "Watch President Obama's call to the crew manning the final voyage of the space shuttle Atlantis: http:\/\/t.co\/Q9GQE0R",
  "id" : 94086199181983744,
  "created_at" : "2011-07-21 16:47:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA HQ PHOTO",
      "screen_name" : "nasahqphoto",
      "indices" : [ 3, 15 ],
      "id_str" : "18164420",
      "id" : 18164420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94011939801415680",
  "text" : "RT @nasahqphoto: Atlantis touches down at Kennedy Space Center Check it out!! http:\/\/flic.kr\/p\/a5FASB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "93993236066078720",
    "text" : "Atlantis touches down at Kennedy Space Center Check it out!! http:\/\/flic.kr\/p\/a5FASB",
    "id" : 93993236066078720,
    "created_at" : "2011-07-21 10:38:28 +0000",
    "user" : {
      "name" : "NASA HQ PHOTO",
      "screen_name" : "nasahqphoto",
      "protected" : false,
      "id_str" : "18164420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67630775\/button_meatball_normal.png",
      "id" : 18164420,
      "verified" : true
    }
  },
  "id" : 94011939801415680,
  "created_at" : "2011-07-21 11:52:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 62, 67 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94011702957453312",
  "text" : "Glad to see Atlantis landed safely. Congrats to crew & all of @NASA. Excited about ushering in a bold new era of exploration in space.",
  "id" : 94011702957453312,
  "created_at" : "2011-07-21 11:51:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/lZRYUee",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/07\/20\/first-lady-michelle-obama-announces-commitments-expand-access-healthy-affordable-foo",
      "display_url" : "whitehouse.gov\/blog\/2011\/07\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "93833284743737344",
  "text" : "RT @letsmove: Earlier today the First Lady announced major commitments to help families increase access to healthy food: http:\/\/t.co\/lZRYUee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 126 ],
        "url" : "http:\/\/t.co\/lZRYUee",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/07\/20\/first-lady-michelle-obama-announces-commitments-expand-access-healthy-affordable-foo",
        "display_url" : "whitehouse.gov\/blog\/2011\/07\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "93826970202284032",
    "text" : "Earlier today the First Lady announced major commitments to help families increase access to healthy food: http:\/\/t.co\/lZRYUee",
    "id" : 93826970202284032,
    "created_at" : "2011-07-20 23:37:47 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 93833284743737344,
  "created_at" : "2011-07-21 00:02:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cuttingwaste",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/ipLFGzw",
      "expanded_url" : "http:\/\/wh.gov\/r1y",
      "display_url" : "wh.gov\/r1y"
    } ]
  },
  "geo" : { },
  "id_str" : "93766512623632384",
  "text" : "WH just announced plans to shut down 100s of duplicative data centers to save taxpayers billions: http:\/\/t.co\/ipLFGzw #cuttingwaste",
  "id" : 93766512623632384,
  "created_at" : "2011-07-20 19:37:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Univ. of Maryland",
      "screen_name" : "UofMaryland",
      "indices" : [ 95, 107 ],
      "id_str" : "16129880",
      "id" : 16129880
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/NNbRIL8",
      "expanded_url" : "http:\/\/www.wh.gov\/tweetup",
      "display_url" : "wh.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "93762970949140480",
  "text" : "Calling all DC, MD, VA Tweeps: Sign up for a chance to attend a #WHTweetup @ Obama's town hall @UofMaryland on 7\/22: http:\/\/t.co\/NNbRIL8",
  "id" : 93762970949140480,
  "created_at" : "2011-07-20 19:23:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93749756714696704",
  "text" : "RT @PressSec: UPDATE: The President will meet with Speaker Boehner and Majority Leader Cantor at the White House today at 5 pm.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "93748711456374784",
    "text" : "UPDATE: The President will meet with Speaker Boehner and Majority Leader Cantor at the White House today at 5 pm.",
    "id" : 93748711456374784,
    "created_at" : "2011-07-20 18:26:49 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 93749756714696704,
  "created_at" : "2011-07-20 18:30:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 131 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "93745915436871680",
  "text" : "RT @LetsMove: The First Lady makes an announcement on access to healthy, affordable food @ 2:15 ET. Watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 93745915436871680,
  "created_at" : "2011-07-20 18:15:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 27, 36 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "93723594483441664",
  "text" : "Happening now: Briefing by @PressSec Jay Carney. Watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 93723594483441664,
  "created_at" : "2011-07-20 16:47:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radian6",
      "screen_name" : "radian6",
      "indices" : [ 3, 11 ],
      "id_str" : "829530660",
      "id" : 829530660
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 38, 46 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 57, 68 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Salesforce",
      "screen_name" : "salesforce",
      "indices" : [ 116, 127 ],
      "id_str" : "33612317",
      "id" : 33612317
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObama",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93705808226947072",
  "text" : "RT @radian6: Be sure to check out the @Twitter Town Hall @whitehouse #AskObama Final Report http:\/\/bit.ly\/pkkZHw cc @salesforce",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.radian6.com\" rel=\"nofollow\"\u003ERadian6 \u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 25, 33 ],
        "id_str" : "783214",
        "id" : 783214
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 44, 55 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Salesforce",
        "screen_name" : "salesforce",
        "indices" : [ 103, 114 ],
        "id_str" : "33612317",
        "id" : 33612317
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskObama",
        "indices" : [ 56, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "93667536331227136",
    "text" : "Be sure to check out the @Twitter Town Hall @whitehouse #AskObama Final Report http:\/\/bit.ly\/pkkZHw cc @salesforce",
    "id" : 93667536331227136,
    "created_at" : "2011-07-20 13:04:15 +0000",
    "user" : {
      "name" : "Marketing Cloud",
      "screen_name" : "marketingcloud",
      "protected" : false,
      "id_str" : "9860432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722529950583140352\/mVUDo78h_normal.jpg",
      "id" : 9860432,
      "verified" : true
    }
  },
  "id" : 93705808226947072,
  "created_at" : "2011-07-20 15:36:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/RzJ5Y8J",
      "expanded_url" : "http:\/\/1.usa.gov\/mRFa9T",
      "display_url" : "1.usa.gov\/mRFa9T"
    } ]
  },
  "geo" : { },
  "id_str" : "93697872805117953",
  "text" : "\"We're in the 11th hour\" -President Obama on deficit talks. Video: http:\/\/t.co\/RzJ5Y8J",
  "id" : 93697872805117953,
  "created_at" : "2011-07-20 15:04:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Univ. of Maryland",
      "screen_name" : "UofMaryland",
      "indices" : [ 90, 102 ],
      "id_str" : "16129880",
      "id" : 16129880
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/HmR8mSl",
      "expanded_url" : "http:\/\/wh.gov\/1Ga",
      "display_url" : "wh.gov\/1Ga"
    } ]
  },
  "geo" : { },
  "id_str" : "93681917509124096",
  "text" : "Followers in DC, MD & VA: We're hosting our 2nd #WHTweetup at President Obama's town hall @UofMaryland on 7\/22. Sign up: http:\/\/t.co\/HmR8mSl",
  "id" : 93681917509124096,
  "created_at" : "2011-07-20 14:01:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 51, 55 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/PbKGiHy",
      "expanded_url" : "http:\/\/goo.gl\/nN9jv",
      "display_url" : "goo.gl\/nN9jv"
    } ]
  },
  "geo" : { },
  "id_str" : "93518792650530816",
  "text" : "RT @pfeiffer44: Sec Geithner's Op Ed in tomorrow's @WSJ \"A Dodd-Frank Retreat Deserves a Veto\" http:\/\/t.co\/PbKGiHy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 35, 39 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 98 ],
        "url" : "http:\/\/t.co\/PbKGiHy",
        "expanded_url" : "http:\/\/goo.gl\/nN9jv",
        "display_url" : "goo.gl\/nN9jv"
      } ]
    },
    "geo" : { },
    "id_str" : "93500579493588993",
    "text" : "Sec Geithner's Op Ed in tomorrow's @WSJ \"A Dodd-Frank Retreat Deserves a Veto\" http:\/\/t.co\/PbKGiHy",
    "id" : 93500579493588993,
    "created_at" : "2011-07-20 02:00:49 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 93518792650530816,
  "created_at" : "2011-07-20 03:13:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/DeTxDFT",
      "expanded_url" : "http:\/\/wh.gov\/r11",
      "display_url" : "wh.gov\/r11"
    } ]
  },
  "geo" : { },
  "id_str" : "93457089015447552",
  "text" : "President Obama is proud to support the Respect for Marriage Act: http:\/\/t.co\/DeTxDFT",
  "id" : 93457089015447552,
  "created_at" : "2011-07-19 23:08:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/TWEhdId",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/0\/k-bBzSvp3rY",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "93401247515807746",
  "text" : "\"We now are seeing the potential for a bipartisan consensus...\" -President Obama on debt ceiling talks. Video: http:\/\/t.co\/TWEhdId",
  "id" : 93401247515807746,
  "created_at" : "2011-07-19 19:26:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 58, 67 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 120 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "93374574657413120",
  "text" : "President Obama just gave an update on deficit talks, now @PressSec is taking questions. Watch here: http:\/\/t.co\/hOlVdV1",
  "id" : 93374574657413120,
  "created_at" : "2011-07-19 17:40:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93373355423567872",
  "text" : "RT @pfeiffer44: POTUS in the briefing room now discussing the deficit talks including the announcement from the Gang of 6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "93373244035444736",
    "text" : "POTUS in the briefing room now discussing the deficit talks including the announcement from the Gang of 6",
    "id" : 93373244035444736,
    "created_at" : "2011-07-19 17:34:50 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 93373355423567872,
  "created_at" : "2011-07-19 17:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 131 ],
      "url" : "http:\/\/t.co\/OW4LJrW",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "93371096325304321",
  "text" : "RT @jesseclee44: President Obama speaks at the top of the Press Secretary's daily briefing at 1:30, watch here: http:\/\/t.co\/OW4LJrW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 114 ],
        "url" : "http:\/\/t.co\/OW4LJrW",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "93370443200856064",
    "text" : "President Obama speaks at the top of the Press Secretary's daily briefing at 1:30, watch here: http:\/\/t.co\/OW4LJrW",
    "id" : 93370443200856064,
    "created_at" : "2011-07-19 17:23:43 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 93371096325304321,
  "created_at" : "2011-07-19 17:26:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WelcomeToTwitter",
      "indices" : [ 71, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 67 ],
      "url" : "http:\/\/t.co\/chSITRd",
      "expanded_url" : "http:\/\/wh.gov\/ray",
      "display_url" : "wh.gov\/ray"
    } ]
  },
  "geo" : { },
  "id_str" : "93306033933533184",
  "text" : "RT @OMBPress: Happy to be here. More on OMBlog: http:\/\/t.co\/chSITRd \/\/ #WelcomeToTwitter",
  "id" : 93306033933533184,
  "created_at" : "2011-07-19 13:07:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "93292961609170944",
  "text" : "RT @jesseclee44: Furman at WH.gov: GOP's \"duck dodge & dismantle\" would hurt recovery, competitiveness & be worse for seniors than Ryan  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 139 ],
        "url" : "http:\/\/t.co\/nm8gitH",
        "expanded_url" : "http:\/\/1.usa.gov\/ogccaj",
        "display_url" : "1.usa.gov\/ogccaj"
      } ]
    },
    "geo" : { },
    "id_str" : "93291894456582144",
    "text" : "Furman at WH.gov: GOP's \"duck dodge & dismantle\" would hurt recovery, competitiveness & be worse for seniors than Ryan  http:\/\/t.co\/nm8gitH",
    "id" : 93291894456582144,
    "created_at" : "2011-07-19 12:11:35 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 93292961609170944,
  "created_at" : "2011-07-19 12:15:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 95, 100 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/J77TX3T",
      "expanded_url" : "http:\/\/wh.gov\/ral",
      "display_url" : "wh.gov\/ral"
    } ]
  },
  "geo" : { },
  "id_str" : "93122463260614656",
  "text" : "Video: President Obama nominates Richard Cordray to lead Consumer Financial Protection Bureau (@CFPB): http:\/\/t.co\/J77TX3T",
  "id" : 93122463260614656,
  "created_at" : "2011-07-19 00:58:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 131 ],
      "url" : "http:\/\/t.co\/XbYQryc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9k-DCrhVQ3U&feature=player_embedded",
      "display_url" : "youtube.com\/watch?v=9k-DCr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "93027657440165888",
  "text" : "\"The most moving part of my trip.\" -The First Lady on meeting Nelson Mandela @ his home in South Africa. Video: http:\/\/t.co\/XbYQryc",
  "id" : 93027657440165888,
  "created_at" : "2011-07-18 18:41:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "93005378937298944",
  "text" : "Just started: President Obama nominates Richard Cordray as Consumer Financial Protection Bureau Director. Watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 93005378937298944,
  "created_at" : "2011-07-18 17:13:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 120 ],
      "url" : "http:\/\/t.co\/WY2Zr6f",
      "expanded_url" : "http:\/\/wh.gov\/rxa",
      "display_url" : "wh.gov\/rxa"
    } ]
  },
  "geo" : { },
  "id_str" : "92999364817068032",
  "text" : "\"We congratulate Nelson Mandela & honor his vision for a better world.\" -The President & First Lady: http:\/\/t.co\/WY2Zr6f",
  "id" : 92999364817068032,
  "created_at" : "2011-07-18 16:49:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 112, 117 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/6u1HAkB",
      "expanded_url" : "http:\/\/wh.gov\/rcG",
      "display_url" : "wh.gov\/rcG"
    } ]
  },
  "geo" : { },
  "id_str" : "92955977040666624",
  "text" : "Today, the President will announce his intent to nominate Richard Cordray to serve as the first Director of the @CFPB: http:\/\/t.co\/6u1HAkB",
  "id" : 92955977040666624,
  "created_at" : "2011-07-18 13:56:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/NEyFC7E",
      "expanded_url" : "http:\/\/bit.ly\/oUkYmU",
      "display_url" : "bit.ly\/oUkYmU"
    } ]
  },
  "geo" : { },
  "id_str" : "92684862905008128",
  "text" : "RT @petesouza: Photo of the Obama family watching the World Cup women's soccer game: http:\/\/t.co\/NEyFC7E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 89 ],
        "url" : "http:\/\/t.co\/NEyFC7E",
        "expanded_url" : "http:\/\/bit.ly\/oUkYmU",
        "display_url" : "bit.ly\/oUkYmU"
      } ]
    },
    "geo" : { },
    "id_str" : "92680023064059904",
    "text" : "Photo of the Obama family watching the World Cup women's soccer game: http:\/\/t.co\/NEyFC7E",
    "id" : 92680023064059904,
    "created_at" : "2011-07-17 19:40:14 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 92684862905008128,
  "created_at" : "2011-07-17 19:59:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USWNT",
      "indices" : [ 50, 56 ]
    }, {
      "text" : "TeamUSA",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92673231940628480",
  "text" : "RT @VP: I'm so glad Jill is there to cheer on the #USWNT today. We will both be rooting for you. Let's go #TeamUSA! - VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USWNT",
        "indices" : [ 42, 48 ]
      }, {
        "text" : "TeamUSA",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "92649574245744640",
    "text" : "I'm so glad Jill is there to cheer on the #USWNT today. We will both be rooting for you. Let's go #TeamUSA! - VP",
    "id" : 92649574245744640,
    "created_at" : "2011-07-17 17:39:14 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 92673231940628480,
  "created_at" : "2011-07-17 19:13:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USWNT",
      "indices" : [ 28, 34 ]
    }, {
      "text" : "WWC2011",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92641134718877696",
  "text" : "RT @VP: PHOTO: Dr. B thanks #USWNT for honoring USA w\/amazing #WWC2011 performance-wished them good luck from everyone back home http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/92638589791383553\/photo\/1",
        "indices" : [ 121, 140 ],
        "url" : "http:\/\/t.co\/2PSWuDn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AUkeTn0CMAIy50R.jpg",
        "id_str" : "92638589791383554",
        "id" : 92638589791383554,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AUkeTn0CMAIy50R.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/2PSWuDn"
      } ],
      "hashtags" : [ {
        "text" : "USWNT",
        "indices" : [ 20, 26 ]
      }, {
        "text" : "WWC2011",
        "indices" : [ 54, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "92638589791383553",
    "text" : "PHOTO: Dr. B thanks #USWNT for honoring USA w\/amazing #WWC2011 performance-wished them good luck from everyone back home http:\/\/t.co\/2PSWuDn",
    "id" : 92638589791383553,
    "created_at" : "2011-07-17 16:55:36 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 92641134718877696,
  "created_at" : "2011-07-17 17:05:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Soccer",
      "screen_name" : "ussoccer",
      "indices" : [ 108, 117 ],
      "id_str" : "7563792",
      "id" : 7563792
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WWC2011",
      "indices" : [ 14, 22 ]
    }, {
      "text" : "USWNT",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92622619962126336",
  "text" : "RT @VP: Final #WWC2011 game day is here; Dr. B, Chelsea C & delegation mtg w\/friends & family of #USWNT now @ussoccer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Soccer",
        "screen_name" : "ussoccer",
        "indices" : [ 100, 109 ],
        "id_str" : "7563792",
        "id" : 7563792
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WWC2011",
        "indices" : [ 6, 14 ]
      }, {
        "text" : "USWNT",
        "indices" : [ 89, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "92600906981457920",
    "text" : "Final #WWC2011 game day is here; Dr. B, Chelsea C & delegation mtg w\/friends & family of #USWNT now @ussoccer",
    "id" : 92600906981457920,
    "created_at" : "2011-07-17 14:25:51 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 92622619962126336,
  "created_at" : "2011-07-17 15:52:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dalai Lama",
      "screen_name" : "DalaiLama",
      "indices" : [ 29, 39 ],
      "id_str" : "20609518",
      "id" : 20609518
    }, {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 71, 81 ],
      "id_str" : "18215973",
      "id" : 18215973
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 99, 108 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/s6MGoaH",
      "expanded_url" : "http:\/\/wh.gov\/rcb",
      "display_url" : "wh.gov\/rcb"
    } ]
  },
  "geo" : { },
  "id_str" : "92620290173042688",
  "text" : "The President\u2019s meeting with @DalaiLama at the White House: Photo from @petesouza & statement from @PressSec: http:\/\/t.co\/s6MGoaH",
  "id" : 92620290173042688,
  "created_at" : "2011-07-17 15:42:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/JOIcWzL",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/1\/9GkKDhkM-hw",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "92221696597172225",
  "text" : "Your Weekly Address: President Obama on the importance of compromise & shared sacrifice to move our country forward: http:\/\/t.co\/JOIcWzL",
  "id" : 92221696597172225,
  "created_at" : "2011-07-16 13:19:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/0O06LpO",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/0\/BCsJ-24MdZc",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "92017426950127616",
  "text" : "Behind-the-scenes video: The President meets w\/ civil rights icon Ruby Bridges, views historic Rockwell painting @ WH: http:\/\/t.co\/0O06LpO",
  "id" : 92017426950127616,
  "created_at" : "2011-07-15 23:47:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/FcalLJ3",
      "expanded_url" : "http:\/\/bit.ly\/q6ZHwD",
      "display_url" : "bit.ly\/q6ZHwD"
    } ]
  },
  "geo" : { },
  "id_str" : "92008512149913601",
  "text" : "RT @petesouza: Historic: Pres Obama shows Ruby Bridges famous Rockwell painting of her on display at White House: http:\/\/t.co\/FcalLJ3",
  "id" : 92008512149913601,
  "created_at" : "2011-07-15 23:11:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "potinleftgrog1",
      "screen_name" : "Mayor_Smith",
      "indices" : [ 43, 55 ],
      "id_str" : "2982225435",
      "id" : 2982225435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/xp7k2jk",
      "expanded_url" : "http:\/\/wh.gov\/ri3",
      "display_url" : "wh.gov\/ri3"
    } ]
  },
  "geo" : { },
  "id_str" : "91979978400477185",
  "text" : "\"We need to get this issue resolved soon\" -@Mayor_Smith of Mesa, AZ. More Mayors talk debt negotiations: http:\/\/t.co\/xp7k2jk",
  "id" : 91979978400477185,
  "created_at" : "2011-07-15 21:18:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 50 ],
      "url" : "http:\/\/t.co\/1RiyAgV",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=CemfB_Z6elY&feature=player_embedded",
      "display_url" : "youtube.com\/watch?v=CemfB_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91975709240737792",
  "text" : "Compromise isn\u2019t a dirty word. http:\/\/t.co\/1RiyAgV",
  "id" : 91975709240737792,
  "created_at" : "2011-07-15 21:01:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 56 ],
      "url" : "http:\/\/t.co\/W2I3QS4",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=CemfB_Z6elY",
      "display_url" : "youtube.com\/watch?v=CemfB_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91959423198691329",
  "text" : "You don't get 100% of what you want. http:\/\/t.co\/W2I3QS4",
  "id" : 91959423198691329,
  "created_at" : "2011-07-15 19:56:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STS135",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91937062873341953",
  "text" : "RT @NASA: President Barack Obama speaks with the crews of #STS135 and the ISS from the Oval Office at the White House  http:\/\/twitpic.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STS135",
        "indices" : [ 48, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91929362823249920",
    "text" : "President Barack Obama speaks with the crews of #STS135 and the ISS from the Oval Office at the White House  http:\/\/twitpic.com\/5qm5ew",
    "id" : 91929362823249920,
    "created_at" : "2011-07-15 17:57:22 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 91937062873341953,
  "created_at" : "2011-07-15 18:27:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 88 ],
      "url" : "http:\/\/t.co\/S3wcBn4",
      "expanded_url" : "http:\/\/wh.gov\/r3W",
      "display_url" : "wh.gov\/r3W"
    } ]
  },
  "geo" : { },
  "id_str" : "91936966320463874",
  "text" : "Full video: President Obama's press conference on debt negotiations: http:\/\/t.co\/S3wcBn4",
  "id" : 91936966320463874,
  "created_at" : "2011-07-15 18:27:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 127, 132 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91907495630610434",
  "text" : "RT @whitehouseostp: Happening at 12:30 ET, President Obama speaks with the crews of Atlantis and Int'l Space Station ... Watch @NASA TV  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 107, 112 ],
        "id_str" : "11348282",
        "id" : 11348282
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 135 ],
        "url" : "http:\/\/t.co\/crGs6eE",
        "expanded_url" : "http:\/\/www.nasa.gov\/ntv",
        "display_url" : "nasa.gov\/ntv"
      } ]
    },
    "geo" : { },
    "id_str" : "91907097251414018",
    "text" : "Happening at 12:30 ET, President Obama speaks with the crews of Atlantis and Int'l Space Station ... Watch @NASA TV http:\/\/t.co\/crGs6eE",
    "id" : 91907097251414018,
    "created_at" : "2011-07-15 16:28:54 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 91907495630610434,
  "created_at" : "2011-07-15 16:30:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91894740987027456",
  "text" : "President Obama's press conference on reducing the deficit just ended -- stay tuned for full video on WhiteHouse.gov.",
  "id" : 91894740987027456,
  "created_at" : "2011-07-15 15:39:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91891913891905536",
  "text" : "\"I always have hope. I continue to have hope because of the American people.\" - Obama on a balanced approach to deficit reduction",
  "id" : 91891913891905536,
  "created_at" : "2011-07-15 15:28:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "91890505272668161",
  "text" : "\"The American people are sold. 80% of the American people support a balanced approach\" -Obama on deficit reduction: http:\/\/t.co\/hOlVdV1",
  "id" : 91890505272668161,
  "created_at" : "2011-07-15 15:22:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91886013399580672",
  "text" : "The President wants the biggest deal possible to reduce the deficit & will meet w\/ Congressional leaders every day until it gets done.",
  "id" : 91886013399580672,
  "created_at" : "2011-07-15 15:05:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "91884755074826242",
  "text" : "Happening now: President Obama is speaking on the status of efforts to find a balanced approach to deficit reduction: http:\/\/t.co\/hOlVdV1",
  "id" : 91884755074826242,
  "created_at" : "2011-07-15 15:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91878571622137856",
  "text" : "RT @VP: BREAKING: Dr. Jill Biden to lead presidential delegation to Women\u2019s World Cup Final in Germany Sun; go #TeamUSA!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 103, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91864741051514881",
    "text" : "BREAKING: Dr. Jill Biden to lead presidential delegation to Women\u2019s World Cup Final in Germany Sun; go #TeamUSA!",
    "id" : 91864741051514881,
    "created_at" : "2011-07-15 13:40:35 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 91878571622137856,
  "created_at" : "2011-07-15 14:35:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "91877677476233216",
  "text" : "11 ET: The President will speak on the status of efforts to find a balanced approach to deficit reduction. Watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 91877677476233216,
  "created_at" : "2011-07-15 14:31:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http:\/\/t.co\/9JRcNGI",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=OKC8GbrZqqM&feature=channel_video_title",
      "display_url" : "youtube.com\/watch?v=OKC8Gb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91870463986372609",
  "text" : "Fresh West Wing Week: Walk step by step with President Obama in \"Our Heroes Are All Around Us\": http:\/\/t.co\/9JRcNGI",
  "id" : 91870463986372609,
  "created_at" : "2011-07-15 14:03:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91644069205381120",
  "text" : "RT @pfeiffer44: President Obama will hold a press conference tomorrow at the WH at 11 AM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91643183708114944",
    "text" : "President Obama will hold a press conference tomorrow at the WH at 11 AM",
    "id" : 91643183708114944,
    "created_at" : "2011-07-14 23:00:12 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 91644069205381120,
  "created_at" : "2011-07-14 23:03:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "villaraigosa",
      "screen_name" : "villaraigosa",
      "indices" : [ 70, 83 ],
      "id_str" : "796800025749688322",
      "id" : 796800025749688322
    }, {
      "name" : "Michael A. Nutter",
      "screen_name" : "Michael_Nutter",
      "indices" : [ 84, 99 ],
      "id_str" : "202790178",
      "id" : 202790178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/xp7k2jk",
      "expanded_url" : "http:\/\/wh.gov\/ri3",
      "display_url" : "wh.gov\/ri3"
    } ]
  },
  "geo" : { },
  "id_str" : "91643008944054273",
  "text" : "Mayors call for a balanced approach to debt negotiations. Here's what @villaraigosa @Michael_Nutter & more are saying: http:\/\/t.co\/xp7k2jk",
  "id" : 91643008944054273,
  "created_at" : "2011-07-14 22:59:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 16, 28 ],
      "id_str" : "110541296",
      "id" : 110541296
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/ZeNuIDy",
      "expanded_url" : "http:\/\/wh.gov\/riC",
      "display_url" : "wh.gov\/riC"
    } ]
  },
  "geo" : { },
  "id_str" : "91639577177096195",
  "text" : "New report from @CommerceGov highlights the importance of science, tech, engineering & math education & jobs: http:\/\/t.co\/ZeNuIDy #STEM",
  "id" : 91639577177096195,
  "created_at" : "2011-07-14 22:45:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAVEAward",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/IPc4yhN",
      "expanded_url" : "http:\/\/wh.gov\/rln",
      "display_url" : "wh.gov\/rln"
    } ]
  },
  "geo" : { },
  "id_str" : "91603632822296576",
  "text" : "Announcing the 2011 #SAVEAward. Federal employees: Submit your ideas to cut waste & save taxpayer dollars: http:\/\/t.co\/IPc4yhN",
  "id" : 91603632822296576,
  "created_at" : "2011-07-14 20:23:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    }, {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/ASNAdvF",
      "expanded_url" : "https:\/\/www.disability.gov\/",
      "display_url" : "disability.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "91551676716171264",
  "text" : "Live @ 1ET: Open for questions on disability policy incl employment, health care & more. Watch: http:\/\/t.co\/hOlVdV1 or http:\/\/t.co\/ASNAdvF",
  "id" : 91551676716171264,
  "created_at" : "2011-07-14 16:56:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/tDHr7S2",
      "expanded_url" : "http:\/\/wh.gov\/rlD",
      "display_url" : "wh.gov\/rlD"
    } ]
  },
  "geo" : { },
  "id_str" : "91544797499768832",
  "text" : "RT @VP: VP op-ed in McClatchy Newspapers today: Delivering the Accountable Government that Taxpayers Deserve http:\/\/t.co\/tDHr7S2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 120 ],
        "url" : "http:\/\/t.co\/tDHr7S2",
        "expanded_url" : "http:\/\/wh.gov\/rlD",
        "display_url" : "wh.gov\/rlD"
      } ]
    },
    "geo" : { },
    "id_str" : "91543876011167745",
    "text" : "VP op-ed in McClatchy Newspapers today: Delivering the Accountable Government that Taxpayers Deserve http:\/\/t.co\/tDHr7S2",
    "id" : 91543876011167745,
    "created_at" : "2011-07-14 16:25:35 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 91544797499768832,
  "created_at" : "2011-07-14 16:29:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Disability.gov",
      "screen_name" : "Disabilitygov",
      "indices" : [ 62, 76 ],
      "id_str" : "21783950",
      "id" : 21783950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/1JhquXR",
      "expanded_url" : "http:\/\/wh.gov\/rl2",
      "display_url" : "wh.gov\/rl2"
    } ]
  },
  "geo" : { },
  "id_str" : "91534514911846400",
  "text" : "Open for Questions at 1 ET: Live Chat on Disability Policy w\/ @Disabilitygov. Send your Qs now, watch live later: http:\/\/t.co\/1JhquXR",
  "id" : 91534514911846400,
  "created_at" : "2011-07-14 15:48:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Univision 23 Miami",
      "screen_name" : "Univision23",
      "indices" : [ 50, 62 ],
      "id_str" : "52878788",
      "id" : 52878788
    }, {
      "name" : "Chicago Bulls",
      "screen_name" : "chicagobulls",
      "indices" : [ 87, 100 ],
      "id_str" : "16212685",
      "id" : 16212685
    }, {
      "name" : "Miami HEAT",
      "screen_name" : "MiamiHEAT",
      "indices" : [ 104, 114 ],
      "id_str" : "11026952",
      "id" : 11026952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/oHue5fd",
      "expanded_url" : "http:\/\/wh.gov\/rqp",
      "display_url" : "wh.gov\/rqp"
    } ]
  },
  "geo" : { },
  "id_str" : "91293418625572864",
  "text" : "Promise Kept: The President sends Chicago dogs to @Univision23 after a friendly bet on @ChicagoBulls vs @MiamiHEAT: http:\/\/t.co\/oHue5fd",
  "id" : 91293418625572864,
  "created_at" : "2011-07-13 23:50:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 23, 26 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apps",
      "indices" : [ 39, 44 ]
    }, {
      "text" : "abuse",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 79 ],
      "url" : "http:\/\/t.co\/4YiIVjH",
      "expanded_url" : "http:\/\/1.usa.gov\/qeMlWG",
      "display_url" : "1.usa.gov\/qeMlWG"
    } ]
  },
  "geo" : { },
  "id_str" : "91268524483428352",
  "text" : "RT @aneeshchopra: Join @VP\u2019s challenge #apps against #abuse http:\/\/t.co\/4YiIVjH Nearly 1\/5 young women report experiencing sexual asslt  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 5, 8 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "apps",
        "indices" : [ 21, 26 ]
      }, {
        "text" : "abuse",
        "indices" : [ 35, 41 ]
      }, {
        "text" : "preventassault",
        "indices" : [ 118, 133 ]
      }, {
        "text" : "devs",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 61 ],
        "url" : "http:\/\/t.co\/4YiIVjH",
        "expanded_url" : "http:\/\/1.usa.gov\/qeMlWG",
        "display_url" : "1.usa.gov\/qeMlWG"
      } ]
    },
    "geo" : { },
    "id_str" : "91259647624876033",
    "text" : "Join @VP\u2019s challenge #apps against #abuse http:\/\/t.co\/4YiIVjH Nearly 1\/5 young women report experiencing sexual asslt #preventassault #devs",
    "id" : 91259647624876033,
    "created_at" : "2011-07-13 21:36:10 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 91268524483428352,
  "created_at" : "2011-07-13 22:11:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 20, 35 ],
      "id_str" : "211921304",
      "id" : 211921304
    }, {
      "name" : "refinery29",
      "screen_name" : "Refinery29",
      "indices" : [ 60, 71 ],
      "id_str" : "19546942",
      "id" : 19546942
    }, {
      "name" : "We Moved!",
      "screen_name" : "giltgroupe",
      "indices" : [ 72, 83 ],
      "id_str" : "904425032",
      "id" : 904425032
    }, {
      "name" : "LivingSocial",
      "screen_name" : "LivingSocial",
      "indices" : [ 84, 97 ],
      "id_str" : "14773982",
      "id" : 14773982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "91253245216956416",
  "text" : "Young entrepreneurs @startupamerica panel (incl founders of @Refinery29 @GiltGroupe @LivingSocial) created over 7k jobs: http:\/\/t.co\/hOlVdV1",
  "id" : 91253245216956416,
  "created_at" : "2011-07-13 21:10:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 14, 29 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 107 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "91249641043132419",
  "text" : "Just started: @StartupAmerica young entrepreneurs panel at the White House. Watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 91249641043132419,
  "created_at" : "2011-07-13 20:56:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 3, 18 ],
      "id_str" : "211921304",
      "id" : 211921304
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 80, 91 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "buyyoung",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 112 ],
      "url" : "http:\/\/t.co\/uLEIs1K",
      "expanded_url" : "http:\/\/twitpic.com\/5poctr",
      "display_url" : "twitpic.com\/5poctr"
    } ]
  },
  "geo" : { },
  "id_str" : "91249233402937344",
  "text" : "RT @startupamerica: Room filling up fast at #buyyoung Young Entrepreneur Summit @whitehouse  http:\/\/t.co\/uLEIs1K Watch LIVE: http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 60, 71 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "buyyoung",
        "indices" : [ 24, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 92 ],
        "url" : "http:\/\/t.co\/uLEIs1K",
        "expanded_url" : "http:\/\/twitpic.com\/5poctr",
        "display_url" : "twitpic.com\/5poctr"
      }, {
        "indices" : [ 105, 124 ],
        "url" : "http:\/\/t.co\/hizcgeO",
        "expanded_url" : "http:\/\/ar.gy\/BuyYoung",
        "display_url" : "ar.gy\/BuyYoung"
      } ]
    },
    "geo" : { },
    "id_str" : "91248620615110656",
    "text" : "Room filling up fast at #buyyoung Young Entrepreneur Summit @whitehouse  http:\/\/t.co\/uLEIs1K Watch LIVE: http:\/\/t.co\/hizcgeO",
    "id" : 91248620615110656,
    "created_at" : "2011-07-13 20:52:21 +0000",
    "user" : {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "protected" : false,
      "id_str" : "211921304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1362197801\/120X120_ICON_normal.png",
      "id" : 211921304,
      "verified" : false
    }
  },
  "id" : 91249233402937344,
  "created_at" : "2011-07-13 20:54:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 16, 31 ],
      "id_str" : "211921304",
      "id" : 211921304
    }, {
      "name" : "WordPress",
      "screen_name" : "WordPress",
      "indices" : [ 70, 80 ],
      "id_str" : "685513",
      "id" : 685513
    }, {
      "name" : "H360 Capital",
      "screen_name" : "H360Capital",
      "indices" : [ 81, 93 ],
      "id_str" : "263990906",
      "id" : 263990906
    }, {
      "name" : "Lindy & Grundy Meats",
      "screen_name" : "LindyGrundy",
      "indices" : [ 94, 106 ],
      "id_str" : "142679936",
      "id" : 142679936
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuyYoung",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/FJaCwSE",
      "expanded_url" : "http:\/\/wh.gov\/1h7",
      "display_url" : "wh.gov\/1h7"
    } ]
  },
  "geo" : { },
  "id_str" : "91247499381182464",
  "text" : "Starting soon - @startupamerica panel w\/ #BuyYoung entrepreneurs incl @wordpress @H360Capital @LindyGrundy & more: http:\/\/t.co\/FJaCwSE",
  "id" : 91247499381182464,
  "created_at" : "2011-07-13 20:47:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 54, 61 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91235272255217664",
  "text" : "Photo of the Day: President Obama hugs grandmother of @USArmy SFC Petry before awarding him the Medal of Honor: http:\/\/twitpic.com\/5pnqxt",
  "id" : 91235272255217664,
  "created_at" : "2011-07-13 19:59:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 3, 18 ],
      "id_str" : "211921304",
      "id" : 211921304
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 42, 53 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuyYoung",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91220972094488577",
  "text" : "RT @startupamerica: Live at 4:30PM today: @WhiteHouse Interactive Session with #BuyYoung Entrepreneurs http:\/\/ar.gy\/TyK We'll be there!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reach.me\" rel=\"nofollow\"\u003EReach.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 22, 33 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BuyYoung",
        "indices" : [ 59, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91192448386207745",
    "text" : "Live at 4:30PM today: @WhiteHouse Interactive Session with #BuyYoung Entrepreneurs http:\/\/ar.gy\/TyK We'll be there!",
    "id" : 91192448386207745,
    "created_at" : "2011-07-13 17:09:08 +0000",
    "user" : {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "protected" : false,
      "id_str" : "211921304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1362197801\/120X120_ICON_normal.png",
      "id" : 211921304,
      "verified" : false
    }
  },
  "id" : 91220972094488577,
  "created_at" : "2011-07-13 19:02:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http:\/\/t.co\/bZzyF0K",
      "expanded_url" : "http:\/\/bit.ly\/nnAdHf",
      "display_url" : "bit.ly\/nnAdHf"
    } ]
  },
  "geo" : { },
  "id_str" : "91197188113309696",
  "text" : "RT @petesouza: Photo of potus mtg w Russian FM Lavrov:  http:\/\/t.co\/bZzyF0K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 60 ],
        "url" : "http:\/\/t.co\/bZzyF0K",
        "expanded_url" : "http:\/\/bit.ly\/nnAdHf",
        "display_url" : "bit.ly\/nnAdHf"
      } ]
    },
    "geo" : { },
    "id_str" : "91196763553271808",
    "text" : "Photo of potus mtg w Russian FM Lavrov:  http:\/\/t.co\/bZzyF0K",
    "id" : 91196763553271808,
    "created_at" : "2011-07-13 17:26:17 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 91197188113309696,
  "created_at" : "2011-07-13 17:27:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91195810041176064",
  "text" : "RT @VP: Just met w\/Cabinet re unacceptable violence against HS+college women; tasked agencies to mobilize all assets to attack this prob ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "91194129928830976",
    "text" : "Just met w\/Cabinet re unacceptable violence against HS+college women; tasked agencies to mobilize all assets to attack this problem - VP",
    "id" : 91194129928830976,
    "created_at" : "2011-07-13 17:15:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 91195810041176064,
  "created_at" : "2011-07-13 17:22:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http:\/\/t.co\/pUas8rh",
      "expanded_url" : "http:\/\/wh.gov\/1hJ",
      "display_url" : "wh.gov\/1hJ"
    } ]
  },
  "geo" : { },
  "id_str" : "91194799155200000",
  "text" : "Statement by the President on Attacks in Mumbai: http:\/\/t.co\/pUas8rh",
  "id" : 91194799155200000,
  "created_at" : "2011-07-13 17:18:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 27, 36 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "91190363288649728",
  "text" : "Happening Now: Briefing by @PressSec Jay Carney. Watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 91190363288649728,
  "created_at" : "2011-07-13 17:00:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http:\/\/t.co\/uLsbpyl",
      "expanded_url" : "http:\/\/go.usa.gov\/Blf",
      "display_url" : "go.usa.gov\/Blf"
    } ]
  },
  "geo" : { },
  "id_str" : "91188306854940674",
  "text" : "RT @ENERGY: House votes in favor of energy efficiency light bulb standards: http:\/\/t.co\/uLsbpyl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 83 ],
        "url" : "http:\/\/t.co\/uLsbpyl",
        "expanded_url" : "http:\/\/go.usa.gov\/Blf",
        "display_url" : "go.usa.gov\/Blf"
      } ]
    },
    "geo" : { },
    "id_str" : "91183655979978752",
    "text" : "House votes in favor of energy efficiency light bulb standards: http:\/\/t.co\/uLsbpyl",
    "id" : 91183655979978752,
    "created_at" : "2011-07-13 16:34:12 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 91188306854940674,
  "created_at" : "2011-07-13 16:52:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HIV",
      "indices" : [ 27, 31 ]
    }, {
      "text" : "AIDS",
      "indices" : [ 32, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http:\/\/t.co\/Xph2ywh",
      "expanded_url" : "http:\/\/wh.gov\/1hf",
      "display_url" : "wh.gov\/1hf"
    }, {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/O1CbW3k",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=57vbfb8AL4M&feature=player_embedded",
      "display_url" : "youtube.com\/watch?v=57vbfb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "91172723799228416",
  "text" : "President Obama's National #HIV #AIDS Strategy at One Year - Implementation Update: http:\/\/t.co\/Xph2ywh Video: http:\/\/t.co\/O1CbW3k",
  "id" : 91172723799228416,
  "created_at" : "2011-07-13 15:50:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/fDZpF77",
      "expanded_url" : "http:\/\/1.usa.gov\/qeMlWG",
      "display_url" : "1.usa.gov\/qeMlWG"
    } ]
  },
  "geo" : { },
  "id_str" : "91164796149432321",
  "text" : "RT @VP: App developers: help prevent youth sexual assault & dating violence-take the \u201CApps Against Abuse\u201D challenge http:\/\/t.co\/fDZpF77",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 127 ],
        "url" : "http:\/\/t.co\/fDZpF77",
        "expanded_url" : "http:\/\/1.usa.gov\/qeMlWG",
        "display_url" : "1.usa.gov\/qeMlWG"
      } ]
    },
    "geo" : { },
    "id_str" : "91155643481866240",
    "text" : "App developers: help prevent youth sexual assault & dating violence-take the \u201CApps Against Abuse\u201D challenge http:\/\/t.co\/fDZpF77",
    "id" : 91155643481866240,
    "created_at" : "2011-07-13 14:42:53 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 91164796149432321,
  "created_at" : "2011-07-13 15:19:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 80, 87 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/PjsrwMP",
      "expanded_url" : "http:\/\/wh.gov\/1hq",
      "display_url" : "wh.gov\/1hq"
    } ]
  },
  "geo" : { },
  "id_str" : "90926591743500288",
  "text" : "\"Our heroes are all around us.\" -President Obama awarding the Medal of Honor to @USArmy Sgt 1st Class Leroy Petry. http:\/\/t.co\/PjsrwMP",
  "id" : 90926591743500288,
  "created_at" : "2011-07-12 23:32:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GovNewMedia",
      "screen_name" : "GovNewMedia",
      "indices" : [ 3, 15 ],
      "id_str" : "197533538",
      "id" : 197533538
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dotgov",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90883957926793216",
  "text" : "RT @GovNewMedia: By The Numbers: There are 1759 SLDs within the #dotgov domain. 354 are redirects. See them all at http:\/\/explore.data.g ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dotgov",
        "indices" : [ 47, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90883251127853057",
    "text" : "By The Numbers: There are 1759 SLDs within the #dotgov domain. 354 are redirects. See them all at http:\/\/explore.data.gov\/d\/k9h8-e98h",
    "id" : 90883251127853057,
    "created_at" : "2011-07-12 20:40:30 +0000",
    "user" : {
      "name" : "DigitalGov",
      "screen_name" : "Digital_Gov",
      "protected" : false,
      "id_str" : "137454693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433356123433734146\/_6rZGH31_normal.jpeg",
      "id" : 137454693,
      "verified" : true
    }
  },
  "id" : 90883957926793216,
  "created_at" : "2011-07-12 20:43:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vivek Kundra",
      "screen_name" : "VivekKundra",
      "indices" : [ 70, 82 ],
      "id_str" : "16311483",
      "id" : 16311483
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 83, 91 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Sheila Campbell",
      "screen_name" : "sheiladcusa",
      "indices" : [ 94, 106 ],
      "id_str" : "19066394",
      "id" : 19066394
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dotgov",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "90876767782453248",
  "text" : "Lots of folks discussing #dotgov right now - join the conversation w\/ @VivekKundra @Macon44 & @sheiladcusa: http:\/\/t.co\/hOlVdV1",
  "id" : 90876767782453248,
  "created_at" : "2011-07-12 20:14:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dotgov",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "90874401414844416",
  "text" : "Happening now: Live chat on improving Federal websites. Ask your Qs with #dotgov & watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 90874401414844416,
  "created_at" : "2011-07-12 20:05:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 14, 22 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Sheila Campbell",
      "screen_name" : "sheiladcusa",
      "indices" : [ 23, 35 ],
      "id_str" : "19066394",
      "id" : 19066394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "90865426006941696",
  "text" : "4:00 ET: Join @Macon44 @sheiladcusa & CIO Vivek Kundra for a live chat on improving federal websites. Watch & engage: http:\/\/t.co\/hOlVdV1",
  "id" : 90865426006941696,
  "created_at" : "2011-07-12 19:29:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WoundedWarriors",
      "indices" : [ 90, 106 ]
    }, {
      "text" : "MOHPetry",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90852935633866752",
  "text" : "RT @USArmy: SFC Petry could have only focused on his own wounds, but today he helps other #WoundedWarriors, says the POTUS. #MOHPetry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WoundedWarriors",
        "indices" : [ 78, 94 ]
      }, {
        "text" : "MOHPetry",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90851948118548480",
    "text" : "SFC Petry could have only focused on his own wounds, but today he helps other #WoundedWarriors, says the POTUS. #MOHPetry",
    "id" : 90851948118548480,
    "created_at" : "2011-07-12 18:36:07 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 90852935633866752,
  "created_at" : "2011-07-12 18:40:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 38, 45 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MOHPetry",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "90847661321764865",
  "text" : "Happening Now: President Obama awards @USArmy Sgt 1st Class Leroy A Petry the Medal of Honor. Watch live: http:\/\/t.co\/hOlVdV1 #MOHPetry",
  "id" : 90847661321764865,
  "created_at" : "2011-07-12 18:19:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 117, 124 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90840647707271168",
  "text" : "RT @VP: VP will attend Medal of Honor Ceremony for Sgt. 1st Class Leroy Petry later today. Read his incredible story @USArmy, http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 109, 116 ],
        "id_str" : "8775672",
        "id" : 8775672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 137 ],
        "url" : "http:\/\/t.co\/bGWHb6q",
        "expanded_url" : "http:\/\/www.army.mil\/article\/58595\/",
        "display_url" : "army.mil\/article\/58595\/"
      } ]
    },
    "geo" : { },
    "id_str" : "90840239710539777",
    "text" : "VP will attend Medal of Honor Ceremony for Sgt. 1st Class Leroy Petry later today. Read his incredible story @USArmy, http:\/\/t.co\/bGWHb6q",
    "id" : 90840239710539777,
    "created_at" : "2011-07-12 17:49:35 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 90840647707271168,
  "created_at" : "2011-07-12 17:51:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori Garver",
      "screen_name" : "Lori_Garver",
      "indices" : [ 3, 15 ],
      "id_str" : "119897041",
      "id" : 119897041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90840413950312448",
  "text" : "RT @Lori_Garver: Admin. Bolden just said in House Sci. Comm. hearing: \u201CToday\u2019s kids will not fly on the shuttle but they will walk on Mars\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90800350168227840",
    "text" : "Admin. Bolden just said in House Sci. Comm. hearing: \u201CToday\u2019s kids will not fly on the shuttle but they will walk on Mars\u201D",
    "id" : 90800350168227840,
    "created_at" : "2011-07-12 15:11:05 +0000",
    "user" : {
      "name" : "Lori Garver",
      "screen_name" : "Lori_Garver",
      "protected" : false,
      "id_str" : "119897041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451202442550857728\/qUOKA0ZH_normal.jpeg",
      "id" : 119897041,
      "verified" : false
    }
  },
  "id" : 90840413950312448,
  "created_at" : "2011-07-12 17:50:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "military",
      "indices" : [ 83, 92 ]
    }, {
      "text" : "MOHPetry",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90824363321987072",
  "text" : "RT @USArmy: Sgt. 1st Class Leroy Petry is receiving the nation's highest award for #military valor. View #MOHPetry photos http:\/\/goo.gl\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "military",
        "indices" : [ 71, 80 ]
      }, {
        "text" : "MOHPetry",
        "indices" : [ 93, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "90816452726243329",
    "text" : "Sgt. 1st Class Leroy Petry is receiving the nation's highest award for #military valor. View #MOHPetry photos http:\/\/goo.gl\/UQ75H",
    "id" : 90816452726243329,
    "created_at" : "2011-07-12 16:15:04 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 90824363321987072,
  "created_at" : "2011-07-12 16:46:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/QLMDIOG",
      "expanded_url" : "http:\/\/wh.gov\/1Sq",
      "display_url" : "wh.gov\/1Sq"
    } ]
  },
  "geo" : { },
  "id_str" : "90569450025254912",
  "text" : "\"If not now, when?\u201D -President Obama on tackling our debt & deficit. Highlights from the press conference: http:\/\/t.co\/QLMDIOG",
  "id" : 90569450025254912,
  "created_at" : "2011-07-11 23:53:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dotgov",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/xz3ezUw",
      "expanded_url" : "http:\/\/wh.gov\/1J7",
      "display_url" : "wh.gov\/1J7"
    } ]
  },
  "geo" : { },
  "id_str" : "90539516036784128",
  "text" : "Open for Questions: Live chat on improving federal websites. Ask your Qs now w\/ #dotgov & tune in live tomorrow: http:\/\/t.co\/xz3ezUw",
  "id" : 90539516036784128,
  "created_at" : "2011-07-11 21:54:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 111 ],
      "url" : "http:\/\/t.co\/sy1q7NT",
      "expanded_url" : "http:\/\/wh.gov\/1JU",
      "display_url" : "wh.gov\/1JU"
    } ]
  },
  "geo" : { },
  "id_str" : "90510143850168320",
  "text" : "Video: President Obama's news conference on reducing the deficit & meeting our obligations: http:\/\/t.co\/sy1q7NT",
  "id" : 90510143850168320,
  "created_at" : "2011-07-11 19:57:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/sy1q7NT",
      "expanded_url" : "http:\/\/wh.gov\/1JU",
      "display_url" : "wh.gov\/1JU"
    } ]
  },
  "geo" : { },
  "id_str" : "90486888766517248",
  "text" : "\"We might as well do it now - pull off the Band-Aid; eat our peas.\" -President Obama on deficit reduction. Video: http:\/\/t.co\/sy1q7NT",
  "id" : 90486888766517248,
  "created_at" : "2011-07-11 18:25:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 92 ],
      "url" : "http:\/\/t.co\/NOBjwZE",
      "expanded_url" : "http:\/\/www.wh.gov\/live\/",
      "display_url" : "wh.gov\/live\/"
    } ]
  },
  "geo" : { },
  "id_str" : "90438891840077824",
  "text" : "Just started: President Obama is holding a press conference. Watch Live: http:\/\/t.co\/NOBjwZE",
  "id" : 90438891840077824,
  "created_at" : "2011-07-11 15:14:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "90433799996981251",
  "text" : "Watch Live @ 11 ET: President Obama speaks on the status of efforts to find a Balanced approach to deficit reduction: http:\/\/t.co\/hOlVdV1",
  "id" : 90433799996981251,
  "created_at" : "2011-07-11 14:54:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 18, 21 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90179567792304128",
  "text" : "President Obama & @VP are meeting w\/ Congressional Leadership in the Cabinet Rm now to discuss a balanced approach to deficit reduction.",
  "id" : 90179567792304128,
  "created_at" : "2011-07-10 22:04:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 108 ],
      "url" : "http:\/\/t.co\/sgKvrhn",
      "expanded_url" : "http:\/\/bit.ly\/eEHO2T",
      "display_url" : "bit.ly\/eEHO2T"
    } ]
  },
  "geo" : { },
  "id_str" : "89781663474782208",
  "text" : "A classic West Wing Week from the historic referendum in Sudan: \"Dispatches from Sudan\": http:\/\/t.co\/sgKvrhn",
  "id" : 89781663474782208,
  "created_at" : "2011-07-09 19:43:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House History",
      "screen_name" : "WhiteHouseHstry",
      "indices" : [ 3, 19 ],
      "id_str" : "106448460",
      "id" : 106448460
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BettyFord",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/RYJCRYg",
      "expanded_url" : "http:\/\/bit.ly\/r5XtY8",
      "display_url" : "bit.ly\/r5XtY8"
    } ]
  },
  "geo" : { },
  "id_str" : "89771908433838080",
  "text" : "RT @WhiteHouseHstry: When #BettyFord lived in the White House, she filled it with lilies, her favorite flower http:\/\/t.co\/RYJCRYg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BettyFord",
        "indices" : [ 5, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 108 ],
        "url" : "http:\/\/t.co\/RYJCRYg",
        "expanded_url" : "http:\/\/bit.ly\/r5XtY8",
        "display_url" : "bit.ly\/r5XtY8"
      } ]
    },
    "geo" : { },
    "id_str" : "89747536302182401",
    "text" : "When #BettyFord lived in the White House, she filled it with lilies, her favorite flower http:\/\/t.co\/RYJCRYg",
    "id" : 89747536302182401,
    "created_at" : "2011-07-09 17:27:34 +0000",
    "user" : {
      "name" : "White House History",
      "screen_name" : "WhiteHouseHstry",
      "protected" : false,
      "id_str" : "106448460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1877740109\/twittericonenlarged_normal.jpg",
      "id" : 106448460,
      "verified" : true
    }
  },
  "id" : 89771908433838080,
  "created_at" : "2011-07-09 19:04:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 32, 35 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/Sd2zH6H",
      "expanded_url" : "http:\/\/1.usa.gov\/oltvG3",
      "display_url" : "1.usa.gov\/oltvG3"
    } ]
  },
  "geo" : { },
  "id_str" : "89770505925705728",
  "text" : "Statements by President Obama & @VP on the passing of Betty Ford: http:\/\/t.co\/Sd2zH6H",
  "id" : 89770505925705728,
  "created_at" : "2011-07-09 18:58:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SouthSudan",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/jNKuYvj",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2011\/07\/09\/statement-president-barack-obama-recognition-republic-south-sudan",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89739558408830976",
  "text" : "Today marks another step forward in Africa\u2019s long journey toward opportunity, democracy & justice -Obama on #SouthSudan http:\/\/t.co\/jNKuYvj",
  "id" : 89739558408830976,
  "created_at" : "2011-07-09 16:55:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/JFxhQcN",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=RgV3L75fBF8&feature=channel_video_title",
      "display_url" : "youtube.com\/watch?v=RgV3L7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89684790437089281",
  "text" : "\"I even sent my first live tweet as President\" -Obama in weekly address on working together to meet fiscal challenges: http:\/\/t.co\/JFxhQcN",
  "id" : 89684790437089281,
  "created_at" : "2011-07-09 13:18:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89472752360226816",
  "text" : "Photo of the Day: President Obama w\/ staff in the Oval after meeting w\/ Congressional Leadership: http:\/\/twitpic.com\/5n7srw",
  "id" : 89472752360226816,
  "created_at" : "2011-07-08 23:15:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STS135",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89469573828575233",
  "text" : "RT @NASA: President Obama's statement on today's successful #STS135 launch and America's future in space http:\/\/go.nasa.gov\/rtynsG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STS135",
        "indices" : [ 50, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "89410916923346944",
    "text" : "President Obama's statement on today's successful #STS135 launch and America's future in space http:\/\/go.nasa.gov\/rtynsG",
    "id" : 89410916923346944,
    "created_at" : "2011-07-08 19:09:58 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 89469573828575233,
  "created_at" : "2011-07-08 23:03:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Arc",
      "screen_name" : "TheArcUS",
      "indices" : [ 21, 30 ],
      "id_str" : "23791417",
      "id" : 23791417
    }, {
      "name" : "MomsRising",
      "screen_name" : "MomsRising",
      "indices" : [ 31, 42 ],
      "id_str" : "15174710",
      "id" : 15174710
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 88, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/DvFw45T",
      "expanded_url" : "http:\/\/wh.gov\/1th",
      "display_url" : "wh.gov\/1th"
    } ]
  },
  "geo" : { },
  "id_str" : "89461192636108800",
  "text" : "WH officials meet w\/ @TheArcUS @MomsRising & Family Voices on Medicaid - more than just #s, about American families: http:\/\/t.co\/DvFw45T",
  "id" : 89461192636108800,
  "created_at" : "2011-07-08 22:29:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YoungAfrica",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/7BfRJbS",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/07\/08\/travels-first-lady-remarkable-journey-africa",
      "display_url" : "whitehouse.gov\/blog\/2011\/07\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89437954900111360",
  "text" : "Video: Travel with First Lady Michelle Obama to South Africa & Botswana for a visit focused on #YoungAfrica: http:\/\/t.co\/7BfRJbS",
  "id" : 89437954900111360,
  "created_at" : "2011-07-08 20:57:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDEB6\uD83C\uDFFDjack",
      "screen_name" : "jack",
      "indices" : [ 29, 34 ],
      "id_str" : "12",
      "id" : 12
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89416559717646337",
  "text" : "Behind-the-scenes video with @jack after the 1st Twitter @townhall at the White House: http:\/\/twitpic.com\/5n4y4x",
  "id" : 89416559717646337,
  "created_at" : "2011-07-08 19:32:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 102, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/bgcYjZF",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/07\/08\/getting-american-people-security-and-opportunity-they-deserve",
      "display_url" : "whitehouse.gov\/blog\/2011\/07\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89411206133202945",
  "text" : "What matters most is getting Americans the security they deserve. Video: President Obama on June jobs #s: http:\/\/t.co\/bgcYjZF",
  "id" : 89411206133202945,
  "created_at" : "2011-07-08 19:11:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 103, 110 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fueleconomy",
      "indices" : [ 37, 49 ]
    }, {
      "text" : "fueleconomy",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/LjUjIJO",
      "expanded_url" : "http:\/\/go.usa.gov\/ZVI",
      "display_url" : "go.usa.gov\/ZVI"
    } ]
  },
  "geo" : { },
  "id_str" : "89352538935140353",
  "text" : "RT @ENERGY: Is your car reaching its #fueleconomy potential? http:\/\/t.co\/LjUjIJO Ask our expert! Tweet @energy #fueleconomy with your Q\u2019 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Energy Department",
        "screen_name" : "ENERGY",
        "indices" : [ 91, 98 ],
        "id_str" : "166252256",
        "id" : 166252256
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fueleconomy",
        "indices" : [ 25, 37 ]
      }, {
        "text" : "fueleconomy",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 68 ],
        "url" : "http:\/\/t.co\/LjUjIJO",
        "expanded_url" : "http:\/\/go.usa.gov\/ZVI",
        "display_url" : "go.usa.gov\/ZVI"
      } ]
    },
    "geo" : { },
    "id_str" : "89326774932094976",
    "text" : "Is your car reaching its #fueleconomy potential? http:\/\/t.co\/LjUjIJO Ask our expert! Tweet @energy #fueleconomy with your Q\u2019s. TODAY 1PM ET",
    "id" : 89326774932094976,
    "created_at" : "2011-07-08 13:35:37 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 89352538935140353,
  "created_at" : "2011-07-08 15:18:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "89349451931582464",
  "text" : "Just started: President Obama Speaks on Monthly Job Numbers: http:\/\/t.co\/hOlVdV1",
  "id" : 89349451931582464,
  "created_at" : "2011-07-08 15:05:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "89340955408347136",
  "text" : "10:35 ET: President Obama speaks on this month's job numbers from the Rose Garden. Watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 89340955408347136,
  "created_at" : "2011-07-08 14:31:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 107 ],
      "url" : "http:\/\/t.co\/MBy4msQ",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/0\/emkgt11VLyA",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "89328777737404416",
  "text" : "Go behind the scenes with President Obama in a fresh West Wing Week, \"Ready to Tweet!\": http:\/\/t.co\/MBy4msQ",
  "id" : 89328777737404416,
  "created_at" : "2011-07-08 13:43:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/iqqx1iE",
      "expanded_url" : "http:\/\/wh.gov\/1eD",
      "display_url" : "wh.gov\/1eD"
    } ]
  },
  "geo" : { },
  "id_str" : "89101482141564928",
  "text" : "\"Nothing is agreed to until everything is agreed to\" -Obama on finding a balanced approach to deficit reduction: http:\/\/t.co\/iqqx1iE",
  "id" : 89101482141564928,
  "created_at" : "2011-07-07 22:40:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89070775952343040",
  "text" : "Photo of the Day: President Obama tweets a question during the Twitter @townhall in the East Room http:\/\/twitpic.com\/5mo2q1",
  "id" : 89070775952343040,
  "created_at" : "2011-07-07 20:38:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    }, {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 29, 37 ],
      "id_str" : "232193350",
      "id" : 232193350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Youth",
      "indices" : [ 62, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/7PHzJ8K",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "89020307997855744",
  "text" : "RT @USAID: Starting shortly: @RajShah takes your questions on #Youth in development.  Join us at http:\/\/t.co\/7PHzJ8K  Tweet Q's using #u ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Raj Shah",
        "screen_name" : "rajshah",
        "indices" : [ 18, 26 ],
        "id_str" : "232193350",
        "id" : 232193350
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Youth",
        "indices" : [ 51, 57 ]
      }, {
        "text" : "usaidyouth",
        "indices" : [ 123, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 105 ],
        "url" : "http:\/\/t.co\/7PHzJ8K",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "89019754496532481",
    "text" : "Starting shortly: @RajShah takes your questions on #Youth in development.  Join us at http:\/\/t.co\/7PHzJ8K  Tweet Q's using #usaidyouth",
    "id" : 89019754496532481,
    "created_at" : "2011-07-07 17:15:38 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 89020307997855744,
  "created_at" : "2011-07-07 17:17:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89010034209599489",
  "text" : "RT @pfeiffer44: New Administration effort to give unemployed homeowners some relief on their mortgage while they look for work. http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 131 ],
        "url" : "http:\/\/t.co\/pTP15I5",
        "expanded_url" : "http:\/\/goo.gl\/m00W4",
        "display_url" : "goo.gl\/m00W4"
      } ]
    },
    "geo" : { },
    "id_str" : "89008743018270720",
    "text" : "New Administration effort to give unemployed homeowners some relief on their mortgage while they look for work. http:\/\/t.co\/pTP15I5",
    "id" : 89008743018270720,
    "created_at" : "2011-07-07 16:31:52 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 89010034209599489,
  "created_at" : "2011-07-07 16:37:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "89001457147330560",
  "text" : "Thanks everyone for sending your questions for Brian -- we'll post the full Twitter Q&A on WhiteHouse.gov later.",
  "id" : 89001457147330560,
  "created_at" : "2011-07-07 16:02:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CarryOn",
      "screen_name" : "nerakyerac",
      "indices" : [ 1, 12 ],
      "id_str" : "19337527",
      "id" : 19337527
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88997704046358528",
  "geo" : { },
  "id_str" : "89000233815638016",
  "in_reply_to_user_id" : 19337527,
  "text" : ".@nerakyerac impt point: focusing on long-term deficit reduction plan w revenues will help support, not undercut, short-term jobs & growth",
  "id" : 89000233815638016,
  "in_reply_to_status_id" : 88997704046358528,
  "created_at" : "2011-07-07 15:58:03 +0000",
  "in_reply_to_screen_name" : "nerakyerac",
  "in_reply_to_user_id_str" : "19337527",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lionel Gentry",
      "screen_name" : "tomoe08a",
      "indices" : [ 1, 10 ],
      "id_str" : "127520441",
      "id" : 127520441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88992358691123201",
  "geo" : { },
  "id_str" : "88998454428303362",
  "in_reply_to_user_id" : 127520441,
  "text" : ".@tomoe08a Oil is 1 ex of special breaks that don't help our economy. By eliminating we can reduce deficit & afford pro-growth investment",
  "id" : 88998454428303362,
  "in_reply_to_status_id" : 88992358691123201,
  "created_at" : "2011-07-07 15:50:59 +0000",
  "in_reply_to_screen_name" : "tomoe08a",
  "in_reply_to_user_id_str" : "127520441",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BunnyVulture",
      "screen_name" : "BunnyVulture",
      "indices" : [ 1, 14 ],
      "id_str" : "65079146",
      "id" : 65079146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/vB0Rs78",
      "expanded_url" : "http:\/\/www.usatoday.com\/money\/economy\/housing\/2011-07-06-help-for-unemployed-homeowners_n.htm",
      "display_url" : "usatoday.com\/money\/economy\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "88674372210008064",
  "geo" : { },
  "id_str" : "88995190693576704",
  "in_reply_to_user_id" : 65079146,
  "text" : ".@BunnyVulture Admin policies helped keep mortgage rates low & families in homes. But POTUS is doing more - news today: http:\/\/t.co\/vB0Rs78",
  "id" : 88995190693576704,
  "in_reply_to_status_id" : 88674372210008064,
  "created_at" : "2011-07-07 15:38:01 +0000",
  "in_reply_to_screen_name" : "BunnyVulture",
  "in_reply_to_user_id_str" : "65079146",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObama",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/K6vKPa3",
      "expanded_url" : "http:\/\/yfrog.com\/kgbsidj",
      "display_url" : "yfrog.com\/kgbsidj"
    } ]
  },
  "geo" : { },
  "id_str" : "88993826177433601",
  "text" : "Happening now: Brian Deese, Obama's econ advisor, is answering your Qs sent via #AskObama & more on Twitter. http:\/\/t.co\/K6vKPa3",
  "id" : 88993826177433601,
  "created_at" : "2011-07-07 15:32:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexander O'Riordan",
      "screen_name" : "alexanderoriord",
      "indices" : [ 1, 17 ],
      "id_str" : "164522104",
      "id" : 164522104
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88990408738213888",
  "geo" : { },
  "id_str" : "88992171847458816",
  "in_reply_to_user_id" : 164522104,
  "text" : ".@alexanderoriord POTUS secured historic increase in Pell & $2500 college tax cut. Fighting to keep college affordable; key to econ future",
  "id" : 88992171847458816,
  "in_reply_to_status_id" : 88990408738213888,
  "created_at" : "2011-07-07 15:26:01 +0000",
  "in_reply_to_screen_name" : "alexanderoriord",
  "in_reply_to_user_id_str" : "164522104",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fer3",
      "screen_name" : "Frmaza",
      "indices" : [ 1, 8 ],
      "id_str" : "144527487",
      "id" : 144527487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88989050656129025",
  "geo" : { },
  "id_str" : "88990473896738816",
  "in_reply_to_user_id" : 144527487,
  "text" : ".@Frmaza: For 200+ years US has responsibly paid its bills. Hitting debt ceiling would have devastating economic impact; must be avoided.",
  "id" : 88990473896738816,
  "in_reply_to_status_id" : 88989050656129025,
  "created_at" : "2011-07-07 15:19:17 +0000",
  "in_reply_to_screen_name" : "Frmaza",
  "in_reply_to_user_id_str" : "144527487",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prem Ranganath",
      "screen_name" : "pgranganath",
      "indices" : [ 1, 13 ],
      "id_str" : "194601803",
      "id" : 194601803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/WFa6pME",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2011\/06\/08\/president-obama-and-skills-americas-future-partners-announce-initiatives",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "88596931579883520",
  "geo" : { },
  "id_str" : "88989137876692992",
  "in_reply_to_user_id" : 194601803,
  "text" : ".@pgranganath: govt can help match employer needs w training programs. Ex: new POTUS manufacturing training partnership http:\/\/t.co\/WFa6pME",
  "id" : 88989137876692992,
  "in_reply_to_status_id" : 88596931579883520,
  "created_at" : "2011-07-07 15:13:58 +0000",
  "in_reply_to_screen_name" : "pgranganath",
  "in_reply_to_user_id_str" : "194601803",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Will Wilkinson",
      "screen_name" : "willwilkinson",
      "indices" : [ 1, 15 ],
      "id_str" : "2568461",
      "id" : 2568461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88684584857911296",
  "geo" : { },
  "id_str" : "88987818965204995",
  "in_reply_to_user_id" : 2568461,
  "text" : ".@willwilkinson: One example: allowing Bush high income tax cuts to expire would save $1 trillion. Important part of balanced solution.",
  "id" : 88987818965204995,
  "in_reply_to_status_id" : 88684584857911296,
  "created_at" : "2011-07-07 15:08:44 +0000",
  "in_reply_to_screen_name" : "willwilkinson",
  "in_reply_to_user_id_str" : "2568461",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88987159679336448",
  "text" : "Twitter chat on the economy & jobs with Brian Deese is starting now. Keep sending us your Qs.",
  "id" : 88987159679336448,
  "created_at" : "2011-07-07 15:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AnnCensky",
      "screen_name" : "AnnCensky",
      "indices" : [ 1, 11 ],
      "id_str" : "2493055044",
      "id" : 2493055044
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 100, 111 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "88983939385016320",
  "geo" : { },
  "id_str" : "88985442497736705",
  "in_reply_to_user_id" : 216799530,
  "text" : ".@AnnCensky - Brian Deese's responses to questions on the economy & jobs will be in tweet form from @whitehouse. Starting soon...",
  "id" : 88985442497736705,
  "in_reply_to_status_id" : 88983939385016320,
  "created_at" : "2011-07-07 14:59:17 +0000",
  "in_reply_to_screen_name" : "AnnalynKurtz",
  "in_reply_to_user_id_str" : "216799530",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88977773514862592",
  "text" : "Have more Qs on the economy & jobs? Send them our way. Brian Deese, Obama's Economic Advisor, will be here @ 11ET to answer.",
  "id" : 88977773514862592,
  "created_at" : "2011-07-07 14:28:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObama",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88971990899245056",
  "text" : "Happening at 11 ET: Brian Deese, the President's Economic Advisor, will answer more Qs on the economy & jobs submitted via #AskObama.",
  "id" : 88971990899245056,
  "created_at" : "2011-07-07 14:05:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 94 ],
      "url" : "http:\/\/t.co\/i45AGYg",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/0\/5cuboYUaUCU",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "88957998747226112",
  "text" : "President Obama makes history as the first President to live tweet. Video: http:\/\/t.co\/i45AGYg",
  "id" : 88957998747226112,
  "created_at" : "2011-07-07 13:10:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObama",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88742957720666112",
  "text" : "Lots of great Qs via #AskObama - Brian Deese, Economic Advisor to the President, will answer more tomorrow on Twitter. Stay tuned.",
  "id" : 88742957720666112,
  "created_at" : "2011-07-06 22:55:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObama",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88733612618424320",
  "text" : "MT @twitterglobalpr: @townhall stats: 169,395 #AskObama Tweets. Hot topics: Jobs (23%) Budget (18%) Taxes (18%) & Education (11%).",
  "id" : 88733612618424320,
  "created_at" : "2011-07-06 22:18:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDEB6\uD83C\uDFFDjack",
      "screen_name" : "jack",
      "indices" : [ 3, 8 ],
      "id_str" : "12",
      "id" : 12
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jack\/status\/88696289839169536\/photo\/1",
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/GsVAtj2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ATsczkECQAAvk9o.jpg",
      "id_str" : "88696289843363840",
      "id" : 88696289843363840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ATsczkECQAAvk9o.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GsVAtj2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88713321339027456",
  "text" : "RT @jack: At the @whitehouse tweetup! Great selection of Twitter users from all over the country. http:\/\/t.co\/GsVAtj2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 7, 18 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jack\/status\/88696289839169536\/photo\/1",
        "indices" : [ 88, 107 ],
        "url" : "http:\/\/t.co\/GsVAtj2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ATsczkECQAAvk9o.jpg",
        "id_str" : "88696289843363840",
        "id" : 88696289843363840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ATsczkECQAAvk9o.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/GsVAtj2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88696289839169536",
    "text" : "At the @whitehouse tweetup! Great selection of Twitter users from all over the country. http:\/\/t.co\/GsVAtj2",
    "id" : 88696289839169536,
    "created_at" : "2011-07-06 19:50:18 +0000",
    "user" : {
      "name" : "\uD83D\uDEB6\uD83C\uDFFDjack",
      "screen_name" : "jack",
      "protected" : false,
      "id_str" : "12",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768529565966667776\/WScYY_cq_normal.jpg",
      "id" : 12,
      "verified" : true
    }
  },
  "id" : 88713321339027456,
  "created_at" : "2011-07-06 20:57:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 53, 61 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "\uD83D\uDEB6\uD83C\uDFFDjack",
      "screen_name" : "jack",
      "indices" : [ 66, 71 ],
      "id_str" : "12",
      "id" : 12
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHtweetup",
      "indices" : [ 75, 85 ]
    }, {
      "text" : "AskObama",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88699652152635392",
  "text" : "RT @aneeshchopra: First official tweet - Now joining @macon44 and @jack at #WHtweetup following #AskObama townhall",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "former Macon44",
        "screen_name" : "macon44",
        "indices" : [ 35, 43 ],
        "id_str" : "776593497122082820",
        "id" : 776593497122082820
      }, {
        "name" : "\uD83D\uDEB6\uD83C\uDFFDjack",
        "screen_name" : "jack",
        "indices" : [ 48, 53 ],
        "id_str" : "12",
        "id" : 12
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHtweetup",
        "indices" : [ 57, 67 ]
      }, {
        "text" : "AskObama",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88690798023024641",
    "text" : "First official tweet - Now joining @macon44 and @jack at #WHtweetup following #AskObama townhall",
    "id" : 88690798023024641,
    "created_at" : "2011-07-06 19:28:28 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 88699652152635392,
  "created_at" : "2011-07-06 20:03:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDEB6\uD83C\uDFFDjack",
      "screen_name" : "jack",
      "indices" : [ 1, 6 ],
      "id_str" : "12",
      "id" : 12
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 7, 15 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 20, 33 ],
      "id_str" : "121539516",
      "id" : 121539516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88698466368364544",
  "text" : ".@jack @macon44 and @aneeshchopra  at our first #WHTweetup.",
  "id" : 88698466368364544,
  "created_at" : "2011-07-06 19:58:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88687345062260737",
  "text" : "[Event has concluded, whole event will be available to watch later at wh.gov\/video - thanks for joining!]",
  "id" : 88687345062260737,
  "created_at" : "2011-07-06 19:14:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88686457769836544",
  "text" : "Obama: We need commitment to our individualism, creativity, idiosyncrasies- but also to each other. Need to invest in future as always have.",
  "id" : 88686457769836544,
  "created_at" : "2011-07-06 19:11:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88685931153981440",
  "text" : "Some welfare programs poorly designed, but not biggest driver of debt. Many struggling now need support, looking to get them back to work",
  "id" : 88685931153981440,
  "created_at" : "2011-07-06 19:09:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88684881491668992",
  "text" : "Obama: Defense budget can be cut, must be done gradually and responsibly. So big that modest changes can help lots w\/ other programs like Ed",
  "id" : 88684881491668992,
  "created_at" : "2011-07-06 19:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http:\/\/t.co\/qKVzPav",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "88684482042925057",
  "text" : "[Questions can be viewed via @townhall, watch at http:\/\/t.co\/qKVzPav ]",
  "id" : 88684482042925057,
  "created_at" : "2011-07-06 19:03:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "becky kazansky\u02D9\u2006\u035C\u029F\u02D9",
      "screen_name" : "pondswimmer",
      "indices" : [ 3, 15 ],
      "id_str" : "42300484",
      "id" : 42300484
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whtweetup",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88684295585140737",
  "text" : "RT @pondswimmer: #whtweetup members pointing at\/commenting on the mass relevance designed data visualizations w geo distribution of ques ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whtweetup",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88683537166901249",
    "text" : "#whtweetup members pointing at\/commenting on the mass relevance designed data visualizations w geo distribution of questions.",
    "id" : 88683537166901249,
    "created_at" : "2011-07-06 18:59:37 +0000",
    "user" : {
      "name" : "becky kazansky\u02D9\u2006\u035C\u029F\u02D9",
      "screen_name" : "pondswimmer",
      "protected" : false,
      "id_str" : "42300484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785422869035683840\/VZu-KxTN_normal.jpg",
      "id" : 42300484,
      "verified" : false
    }
  },
  "id" : 88684295585140737,
  "created_at" : "2011-07-06 19:02:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88684296390455296",
  "text" : "Obama: Facts are that a modest increase in taxes for wealthiest doesn't hurt economy; 90s boom, 2000s slowed. Not like we haven't tested.",
  "id" : 88684296390455296,
  "created_at" : "2011-07-06 19:02:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88683868953116672",
  "text" : "Obama: Foreign aid tiny part of budget, can be a \"force multiplier\" in areas around the world, big security benefit for relatively small $",
  "id" : 88683868953116672,
  "created_at" : "2011-07-06 19:00:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88683591814479873",
  "text" : "Obama: Progress on defense contracting; War on Drugs - need to go after kingpins, more prevention; support campaign finance & agribiz reform",
  "id" : 88683591814479873,
  "created_at" : "2011-07-06 18:59:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/kfwZFEp",
      "expanded_url" : "http:\/\/yfrog.com\/khm9gtj",
      "display_url" : "yfrog.com\/khm9gtj"
    } ]
  },
  "geo" : { },
  "id_str" : "88683403003703296",
  "text" : "President Obama hears your responses at the Twitter @townhall in the East Room. Live on wh.gov\/live http:\/\/t.co\/kfwZFEp",
  "id" : 88683403003703296,
  "created_at" : "2011-07-06 18:59:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88682870612312065",
  "text" : "Obama: Continues to support space exploration, but rather than just continue same thing, let's invest in tech advances for \"next horizon\"",
  "id" : 88682870612312065,
  "created_at" : "2011-07-06 18:56:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88682370953265152",
  "text" : "Obama: Make permanent Bush tax cuts for low\/middle earners who are struggling, solve debt issue with smart, balanced, common sense approach",
  "id" : 88682370953265152,
  "created_at" : "2011-07-06 18:54:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88681710228738048",
  "text" : "Obama on \"supporting the troops\" via oil independence: Good 4 economy, good 4 security, good 4 planet. No serious energy policy in decades",
  "id" : 88681710228738048,
  "created_at" : "2011-07-06 18:52:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88681021037494273",
  "text" : "Obama: We've pushed \"more reform, more vigorously\" than previous Administrations, don't just need investments, need reform",
  "id" : 88681021037494273,
  "created_at" : "2011-07-06 18:49:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88680797233618945",
  "text" : "Obama: \"Every time we've made a public investment in education, it's paid off many times over...we've got to get our priorities straight\"",
  "id" : 88680797233618945,
  "created_at" : "2011-07-06 18:48:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88680565137620994",
  "text" : "Obama: Sorting through who owns what in housing market is tough, so is finding arrangement that works to keep people in homes, still working",
  "id" : 88680565137620994,
  "created_at" : "2011-07-06 18:47:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lieselolson",
      "screen_name" : "lieselolson",
      "indices" : [ 3, 15 ],
      "id_str" : "18945676",
      "id" : 18945676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88680300137291776",
  "text" : "RT @lieselolson: It's amazing being in this room. So many people, even more history. #WHTweetup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 68, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88680156151025664",
    "text" : "It's amazing being in this room. So many people, even more history. #WHTweetup",
    "id" : 88680156151025664,
    "created_at" : "2011-07-06 18:46:11 +0000",
    "user" : {
      "name" : "lieselolson",
      "screen_name" : "lieselolson",
      "protected" : false,
      "id_str" : "18945676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1286607491\/179439_195262473833753_100000500056707_685831_1308134_n_normal.JPG",
      "id" : 18945676,
      "verified" : false
    }
  },
  "id" : 88680300137291776,
  "created_at" : "2011-07-06 18:46:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http:\/\/t.co\/qKVzPav",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "88680019932626946",
  "text" : "[Questions can be viewed via @townhall, watch at http:\/\/t.co\/qKVzPav ]",
  "id" : 88680019932626946,
  "created_at" : "2011-07-06 18:45:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88679673139179520",
  "text" : "Obama: ...but having oil cos close loopholes, wealthiest like him go back to Clinton rates better than gutting Head Start, Medicare etc",
  "id" : 88679673139179520,
  "created_at" : "2011-07-06 18:44:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObama",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/W8ZcjcT",
      "expanded_url" : "http:\/\/yfrog.com\/ki4y7uvj",
      "display_url" : "yfrog.com\/ki4y7uvj"
    } ]
  },
  "geo" : { },
  "id_str" : "88679513013231616",
  "text" : "President Obama is answering your questions now on the economy and jobs. #AskObama and watch live on wh.gov\/live http:\/\/t.co\/W8ZcjcT",
  "id" : 88679513013231616,
  "created_at" : "2011-07-06 18:43:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88679484923985920",
  "text" : "Obama: Tax rates lower than they have been under previous Presidents...",
  "id" : 88679484923985920,
  "created_at" : "2011-07-06 18:43:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88678771380596737",
  "text" : "Obama: ...More important, US default can't be threat for protection of tax loopholes for very richest Americans",
  "id" : 88678771380596737,
  "created_at" : "2011-07-06 18:40:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88678420443181056",
  "text" : "Obama: Disagrees w\/ premise that Rs would've agreed to debt ceiling hike in November, got help for economy & struggling Americans in deal...",
  "id" : 88678420443181056,
  "created_at" : "2011-07-06 18:39:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/yUpc9oa",
      "expanded_url" : "http:\/\/yfrog.com\/kes47qj",
      "display_url" : "yfrog.com\/kes47qj"
    } ]
  },
  "geo" : { },
  "id_str" : "88678065630216192",
  "text" : "#WHTweetup participants watching the Twitter @townhall with President Obama. Happening now on wh.gov\/live http:\/\/t.co\/yUpc9oa",
  "id" : 88678065630216192,
  "created_at" : "2011-07-06 18:37:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88677900496273408",
  "text" : "Obama: We'd like to combine a tax incentive for hiring veterans w\/ a campaign to urge businesses to do the right thing on their own",
  "id" : 88677900496273408,
  "created_at" : "2011-07-06 18:37:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88677536611057664",
  "text" : "Obama on #smallbiz: Passed many tax cuts and incentive for small business, looking for other ways to make capital available, more",
  "id" : 88677536611057664,
  "created_at" : "2011-07-06 18:35:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88677239583031296",
  "text" : "Obama: ...Going to keep trying on things like smart grid & other infrastructure jobs opportunities where there hasn't been cooperation",
  "id" : 88677239583031296,
  "created_at" : "2011-07-06 18:34:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88676941531590656",
  "text" : "Obama responds to @johnboehner: Tax cuts & other measures Rs opposed helped growth, so did some cooperative initiatives...",
  "id" : 88676941531590656,
  "created_at" : "2011-07-06 18:33:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88675914841468928",
  "text" : "Obama on homeowners under water: Have made some progress, but more needed, looking at options",
  "id" : 88675914841468928,
  "created_at" : "2011-07-06 18:29:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88675181953957890",
  "text" : "Obama: ...all of us will have to make adjustments for 21st Century, but principle of collective bargaining must be protected",
  "id" : 88675181953957890,
  "created_at" : "2011-07-06 18:26:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88674949958598658",
  "text" : "Obama: Collective bargaining responsible for so many benefits\/ protections we take for granted on the job...",
  "id" : 88674949958598658,
  "created_at" : "2011-07-06 18:25:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88674540191891456",
  "text" : "Obama: Biggest clean energy investments in history, on track for massive increase in market share in advanced car batteries, much more",
  "id" : 88674540191891456,
  "created_at" : "2011-07-06 18:23:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88674077602086913",
  "text" : "Obama: ...For that reason and others, we need immigration reform that is comprehensive",
  "id" : 88674077602086913,
  "created_at" : "2011-07-06 18:22:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88673919179034625",
  "text" : "Obama: Working w\/ biz, others, on ways to streamline visas so we don't educate people then make them leave to compete against us...",
  "id" : 88673919179034625,
  "created_at" : "2011-07-06 18:21:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88673571253137408",
  "text" : "Obama: Folks \"shouldn't be toying with\" debt limit; on 14th Amendment, we shouldn't even get there, Congress must act",
  "id" : 88673571253137408,
  "created_at" : "2011-07-06 18:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88672983761162240",
  "text" : "Obama on higher ed: We reformed student loans to help students not banks; talking w\/ universities to bring down costs, promote needed skills",
  "id" : 88672983761162240,
  "created_at" : "2011-07-06 18:17:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http:\/\/t.co\/qKVzPav",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "88672491714781185",
  "text" : "[Questions can be viewed via @townhall, watch at http:\/\/t.co\/qKVzPav ]",
  "id" : 88672491714781185,
  "created_at" : "2011-07-06 18:15:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88672122431479808",
  "text" : "Obama: ...Need investment in education & infrastructure for both",
  "id" : 88672122431479808,
  "created_at" : "2011-07-06 18:14:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88671932865716224",
  "text" : "Obama on tech vs manufacturing for recovery: not either\/or, need tech for innovation, manufacturing to make the innovations...",
  "id" : 88671932865716224,
  "created_at" : "2011-07-06 18:13:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88671512894246913",
  "text" : "Obama on what he'd have done dif. on economy: Explain more fully depth of recession, prepare people for tough decisions, better on housing",
  "id" : 88671512894246913,
  "created_at" : "2011-07-06 18:11:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88670359720697856",
  "text" : "in order to reduce the deficit,what costs would you cut and what investments would you keep - bo",
  "id" : 88670359720697856,
  "created_at" : "2011-07-06 18:07:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88668422635921408",
  "text" : "Townhall starting shortly - watch at askobama.twitter.com",
  "id" : 88668422635921408,
  "created_at" : "2011-07-06 17:59:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/96XtXf1",
      "expanded_url" : "https:\/\/twitter.com\/#!\/whitehouse\/twitter-townhall-tweetup",
      "display_url" : "twitter.com\/#!\/whitehouse\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "88653401377878016",
  "text" : "1 hour until the Twitter @townhall. Here's the list of #WHTweetup participants to follow during the event: http:\/\/t.co\/96XtXf1",
  "id" : 88653401377878016,
  "created_at" : "2011-07-06 16:59:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askObama",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88647711921930240",
  "text" : "RT @pfeiffer44: Great to see so many folks discussing the #askObama townhall across the ideological spectrum, feels like what twitter wa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askObama",
        "indices" : [ 42, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "88644164958437376",
    "text" : "Great to see so many folks discussing the #askObama townhall across the ideological spectrum, feels like what twitter was made for",
    "id" : 88644164958437376,
    "created_at" : "2011-07-06 16:23:10 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 88647711921930240,
  "created_at" : "2011-07-06 16:37:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/LZBQ0p3",
      "expanded_url" : "http:\/\/wh.gov\/17t",
      "display_url" : "wh.gov\/17t"
    } ]
  },
  "geo" : { },
  "id_str" : "88634156208242688",
  "text" : "We're all a-Twitter today: 1st Twitter @townhall at the White House, 1st #WHTweetup. http:\/\/t.co\/LZBQ0p3",
  "id" : 88634156208242688,
  "created_at" : "2011-07-06 15:43:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObama",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88606431435173888",
  "text" : "#AskObama your questions on the economy and jobs & watch the first Twitter @townhall at the White House today at 2pm ET.",
  "id" : 88606431435173888,
  "created_at" : "2011-07-06 13:53:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObama",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/Uk04H97",
      "expanded_url" : "https:\/\/askobama.twitter.com",
      "display_url" : "askobama.twitter.com"
    } ]
  },
  "geo" : { },
  "id_str" : "88374764716032000",
  "text" : "What will you #AskObama? Tomorrow the President will answer your Qs on the economy & jobs in a Twitter @townhall: http:\/\/t.co\/Uk04H97",
  "id" : 88374764716032000,
  "created_at" : "2011-07-05 22:32:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Kotecki Vest",
      "screen_name" : "QueenofSpain",
      "indices" : [ 52, 65 ],
      "id_str" : "7234682",
      "id" : 7234682
    }, {
      "name" : "keumok",
      "screen_name" : "js9805",
      "indices" : [ 66, 73 ],
      "id_str" : "3253557295",
      "id" : 3253557295
    }, {
      "name" : "becky kazansky\u02D9\u2006\u035C\u029F\u02D9",
      "screen_name" : "pondswimmer",
      "indices" : [ 74, 86 ],
      "id_str" : "42300484",
      "id" : 42300484
    }, {
      "name" : "\u0412\u0438\u0446\u0435\u043D\u0442\u044C\u0435\u0432 \u0411\u043E\u0440\u0438\u0441\u043B\u0430\u0432",
      "screen_name" : "KT_Little",
      "indices" : [ 104, 114 ],
      "id_str" : "2833613674",
      "id" : 2833613674
    }, {
      "name" : "\uD83D\uDEB6\uD83C\uDFFDjack",
      "screen_name" : "jack",
      "indices" : [ 115, 120 ],
      "id_str" : "12",
      "id" : 12
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 29, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88353395504713728",
  "text" : "Looking forward to our first #WHTweetup tomorrow w\/ @QueenofSpain @js9805 @pondswimmer @DShai_Hendricks @KT_Little @jack & more",
  "id" : 88353395504713728,
  "created_at" : "2011-07-05 21:07:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "88349030589014017",
  "text" : "Happening Now: President Obama speaks on the status of efforts to find a balanced approach to deficit reduction: http:\/\/t.co\/hOlVdV1",
  "id" : 88349030589014017,
  "created_at" : "2011-07-05 20:50:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 32, 40 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askobama",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88327087215226881",
  "text" : "RT @macon44: latest update from @twitter about tomorrow's #askobama @townhall http:\/\/t.co\/1AksQTl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 19, 27 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askobama",
        "indices" : [ 45, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 84 ],
        "url" : "http:\/\/t.co\/1AksQTl",
        "expanded_url" : "http:\/\/goo.gl\/UyA9T",
        "display_url" : "goo.gl\/UyA9T"
      } ]
    },
    "geo" : { },
    "id_str" : "88325950063915009",
    "text" : "latest update from @twitter about tomorrow's #askobama @townhall http:\/\/t.co\/1AksQTl",
    "id" : 88325950063915009,
    "created_at" : "2011-07-05 19:18:42 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 88327087215226881,
  "created_at" : "2011-07-05 19:23:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDEB6\uD83C\uDFFDjack",
      "screen_name" : "jack",
      "indices" : [ 3, 8 ],
      "id_str" : "12",
      "id" : 12
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObama",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/iX8ACtN",
      "expanded_url" : "https:\/\/AskObama.twitter.com",
      "display_url" : "AskObama.twitter.com"
    } ]
  },
  "geo" : { },
  "id_str" : "88279877861646336",
  "text" : "RT @jack: Have a question for the President? Tweet yours with #AskObama and we'll read them to him tomorrow: http:\/\/t.co\/iX8ACtN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskObama",
        "indices" : [ 52, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 118 ],
        "url" : "http:\/\/t.co\/iX8ACtN",
        "expanded_url" : "https:\/\/AskObama.twitter.com",
        "display_url" : "AskObama.twitter.com"
      } ]
    },
    "geo" : { },
    "id_str" : "88259420512985088",
    "text" : "Have a question for the President? Tweet yours with #AskObama and we'll read them to him tomorrow: http:\/\/t.co\/iX8ACtN",
    "id" : 88259420512985088,
    "created_at" : "2011-07-05 14:54:20 +0000",
    "user" : {
      "name" : "\uD83D\uDEB6\uD83C\uDFFDjack",
      "screen_name" : "jack",
      "protected" : false,
      "id_str" : "12",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768529565966667776\/WScYY_cq_normal.jpg",
      "id" : 12,
      "verified" : true
    }
  },
  "id" : 88279877861646336,
  "created_at" : "2011-07-05 16:15:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/ojfnGld",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/0\/voL8R670qM4",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "88279238536478720",
  "text" : "Behind-the-scenes video: Independence Day celebration with President Obama & military families at the White House: http:\/\/t.co\/ojfnGld",
  "id" : 88279238536478720,
  "created_at" : "2011-07-05 16:13:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/jhrBb1s",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/0\/Sv45bz1-gSQ",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "88063985777258496",
  "text" : "Video: President Obama welcomes military families to the White House for an Independence Day Celebration: http:\/\/t.co\/jhrBb1s",
  "id" : 88063985777258496,
  "created_at" : "2011-07-05 01:57:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 118 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "88054602225815552",
  "text" : "National capital fireworks show just started. Great view from the balcony of the White House here: http:\/\/t.co\/hOlVdV1",
  "id" : 88054602225815552,
  "created_at" : "2011-07-05 01:20:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "happy4thofjuly",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88020438495674368",
  "text" : "#happy4thofjuly from the White House. Watch the celebration @ 8:15 ET on www.wh.gov\/live. Don't miss this: http:\/\/twitpic.com\/5lb0km",
  "id" : 88020438495674368,
  "created_at" : "2011-07-04 23:04:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "88011495899807744",
  "text" : "Happening Now: President Obama speaks at 4th of July celebration with military families on the South Lawn: http:\/\/t.co\/hOlVdV1",
  "id" : 88011495899807744,
  "created_at" : "2011-07-04 22:29:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos Lee",
      "screen_name" : "amoslee",
      "indices" : [ 3, 11 ],
      "id_str" : "16033565",
      "id" : 16033565
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 28, 39 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "USO",
      "screen_name" : "the_USO",
      "indices" : [ 47, 55 ],
      "id_str" : "36681590",
      "id" : 36681590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "88006269348229120",
  "text" : "RT @amoslee: Sound checking @whitehouse before @the_USO July 4th Celebration. You can steam the performance on whitehouse.gov... http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 15, 26 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "USO",
        "screen_name" : "the_USO",
        "indices" : [ 34, 42 ],
        "id_str" : "36681590",
        "id" : 36681590
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87945049815515137",
    "text" : "Sound checking @whitehouse before @the_USO July 4th Celebration. You can steam the performance on whitehouse.gov... http:\/\/fb.me\/102UkTfnR",
    "id" : 87945049815515137,
    "created_at" : "2011-07-04 18:05:08 +0000",
    "user" : {
      "name" : "Amos Lee",
      "screen_name" : "amoslee",
      "protected" : false,
      "id_str" : "16033565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751426679420190720\/SwtDNMaG_normal.jpg",
      "id" : 16033565,
      "verified" : true
    }
  },
  "id" : 88006269348229120,
  "created_at" : "2011-07-04 22:08:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USO",
      "screen_name" : "the_USO",
      "indices" : [ 65, 73 ],
      "id_str" : "36681590",
      "id" : 36681590
    }, {
      "name" : "train",
      "screen_name" : "train",
      "indices" : [ 84, 90 ],
      "id_str" : "2463721",
      "id" : 2463721
    }, {
      "name" : "Amos Lee",
      "screen_name" : "amoslee",
      "indices" : [ 93, 101 ],
      "id_str" : "16033565",
      "id" : 16033565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/mhPZGTF",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/07\/04\/celebrate-fourth-july-whitehousegov",
      "display_url" : "whitehouse.gov\/blog\/2011\/07\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "87950096242712576",
  "text" : "Celebrate the 4th w\/ the First Family & military families. Watch @the_USO show feat @Train & @amoslee, fireworks, more: http:\/\/t.co\/mhPZGTF",
  "id" : 87950096242712576,
  "created_at" : "2011-07-04 18:25:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87898792694779904",
  "text" : "RT @VP: VP & Dr. B hope you take time to think about our troops & military families this Independence Day, Happy 4th from OVP! @JoiningF ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 119, 133 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87898514549518336",
    "text" : "VP & Dr. B hope you take time to think about our troops & military families this Independence Day, Happy 4th from OVP! @JoiningForces",
    "id" : 87898514549518336,
    "created_at" : "2011-07-04 15:00:13 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 87898792694779904,
  "created_at" : "2011-07-04 15:01:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87884213298278401",
  "text" : "RT @JoiningForces: Happy Independence Day! The First Lady's message on honoring those in uniform & giving back to military families: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 133 ],
        "url" : "http:\/\/t.co\/ZCzanKI",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/07\/04\/what-you-can-do-support-military-families",
        "display_url" : "whitehouse.gov\/blog\/2011\/07\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "87883138558210048",
    "text" : "Happy Independence Day! The First Lady's message on honoring those in uniform & giving back to military families: http:\/\/t.co\/ZCzanKI",
    "id" : 87883138558210048,
    "created_at" : "2011-07-04 13:59:07 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 87884213298278401,
  "created_at" : "2011-07-04 14:03:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDEB6\uD83C\uDFFDjack",
      "screen_name" : "jack",
      "indices" : [ 3, 8 ],
      "id_str" : "12",
      "id" : 12
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 73, 84 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86892484252270592",
  "text" : "RT @jack: A key aspect of a democracy is a common venue to question. The @WhiteHouse is using Twitter as that venue on 7\/6: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 63, 74 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 133 ],
        "url" : "http:\/\/t.co\/OITafxa",
        "expanded_url" : "https:\/\/askobama.twitter.com\/",
        "display_url" : "askobama.twitter.com"
      } ]
    },
    "geo" : { },
    "id_str" : "86503801716080641",
    "text" : "A key aspect of a democracy is a common venue to question. The @WhiteHouse is using Twitter as that venue on 7\/6: http:\/\/t.co\/OITafxa",
    "id" : 86503801716080641,
    "created_at" : "2011-06-30 18:38:08 +0000",
    "user" : {
      "name" : "\uD83D\uDEB6\uD83C\uDFFDjack",
      "screen_name" : "jack",
      "protected" : false,
      "id_str" : "12",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768529565966667776\/WScYY_cq_normal.jpg",
      "id" : 12,
      "verified" : true
    }
  },
  "id" : 86892484252270592,
  "created_at" : "2011-07-01 20:22:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/UbaJW94",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/07\/01\/president-obama-drops-community-leaders-briefing",
      "display_url" : "whitehouse.gov\/blog\/2011\/07\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "86880634039050240",
  "text" : "Video: President Obama drops in on community leaders briefing, recalls his time working on the South Side of Chicago: http:\/\/t.co\/UbaJW94",
  "id" : 86880634039050240,
  "created_at" : "2011-07-01 19:35:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/dikOD7b",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=vbHMtl3o4pU&feature=channel_video_title",
      "display_url" : "youtube.com\/watch?v=vbHMtl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "86817386799443969",
  "text" : "West Wing Week: In \"Magic Mountains & Volcanoes\" visit a manufacturing plant in Iowa, stop by a news conference, pet Bo: http:\/\/t.co\/dikOD7b",
  "id" : 86817386799443969,
  "created_at" : "2011-07-01 15:24:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]