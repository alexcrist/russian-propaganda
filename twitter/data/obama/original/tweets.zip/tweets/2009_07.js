Grailbird.data.tweets_2009_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Disability.gov",
      "screen_name" : "Disabilitygov",
      "indices" : [ 0, 14 ],
      "id_str" : "21783950",
      "id" : 21783950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "disabilitygov",
      "indices" : [ 95, 109 ]
    }, {
      "text" : "gov20",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3054160800",
  "in_reply_to_user_id" : 21783950,
  "text" : "@Disabilitygov wants feedback about its new website. Take a look & share: http:\/\/bit.ly\/3cMTCa #disabilitygov #gov20",
  "id" : 3054160800,
  "created_at" : "2009-07-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Disabilitygov",
  "in_reply_to_user_id_str" : "21783950",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan G. Komen",
      "screen_name" : "KomenfortheCure",
      "indices" : [ 73, 89 ],
      "id_str" : "1528384508",
      "id" : 1528384508
    }, {
      "name" : "Count Income",
      "screen_name" : "billiejking",
      "indices" : [ 92, 104 ],
      "id_str" : "2195603383",
      "id" : 2195603383
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHMOF",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2933846149",
  "text" : "16 to receive top civilian honor incl. Robinson @RealizingRights Brinker @komenforthecure & @BillieJKing http:\/\/bit.ly\/Ei8oL #WHMOF",
  "id" : 2933846149,
  "created_at" : "2009-07-30 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2909981407",
  "text" : "On tap: Two Obama town halls at a High School in NC & a Kroger in VA  - new specifics on what health reform means to you",
  "id" : 2909981407,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2909995008",
  "text" : "On tap addendum: 1500 questions on reform from small biz folks at LinkedIn, 3:00 CEA Chair Romer answers in chat via WH & FB",
  "id" : 2909995008,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hicp",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2911798457",
  "text" : "What\u2019s In It For You?  8 fundamental health insurance consumer protections, get the word out.    http:\/\/bit.ly\/VidAN #hicp",
  "id" : 2911798457,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hicp",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2912622896",
  "text" : "View or embed the 8 fundamental health insurance consumer protections via Slideshare http:\/\/bit.ly\/fn2vT #hicp",
  "id" : 2912622896,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hicp",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2913932262",
  "text" : "Tell us why these 8 h\/c insurance consumer protections (http:\/\/bit.ly\/VidAN) matter to you & we\u2019ll RT some of the best #hicp",
  "id" : 2913932262,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garry Stetser",
      "screen_name" : "GarryStetser",
      "indices" : [ 3, 16 ],
      "id_str" : "24190129",
      "id" : 24190129
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hicp",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2914239045",
  "text" : "RT @GarryStetser: They matter because personal situations & health conditions change over time, & people should not be penalized ... #hicp",
  "id" : 2914239045,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Peters",
      "screen_name" : "jeremypeters",
      "indices" : [ 3, 16 ],
      "id_str" : "9332762",
      "id" : 9332762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hicp",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2914302959",
  "text" : "RT @jeremypeters: These protections will ensure I can afford, find, & keep quality care from now (age 29) on, no matter the situation. #hicp",
  "id" : 2914302959,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Maggard",
      "screen_name" : "mattmaggard",
      "indices" : [ 3, 15 ],
      "id_str" : "7572662",
      "id" : 7572662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hicp",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2914375574",
  "text" : "RT @mattmaggard: these h\/c protections allow workers more freedom 2 change jobs & start new businesses w\/o fear of losing coverage #hicp",
  "id" : 2914375574,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandra Salzer",
      "screen_name" : "sandrasalzer",
      "indices" : [ 3, 16 ],
      "id_str" : "19266467",
      "id" : 19266467
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hicp",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2914470880",
  "text" : "RT @sandrasalzer: These protections ensure my family won't be bankrupted because I had cancer #hicp",
  "id" : 2914470880,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruth Ness",
      "screen_name" : "Tenness",
      "indices" : [ 3, 11 ],
      "id_str" : "23873443",
      "id" : 23873443
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hicp",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2914659088",
  "text" : "RT @Tenness: My family's coverage doubled because of my preexisting condition.  Unacceptable.  Coverage is poor despite high cost! #hicp",
  "id" : 2914659088,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2914740020",
  "text" : ": CEA Chair Romer answers questions from small biz folks solicited by Obama. Watch\/discuss\/engage http:\/\/bit.ly\/tCHXt",
  "id" : 2914740020,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDC80",
      "screen_name" : "ballookey",
      "indices" : [ 3, 13 ],
      "id_str" : "843271",
      "id" : 843271
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hicp",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2914909801",
  "text" : "RT @ballookey: If the ins. companies had to play by these rules, that would solve 95% of the problems I have right now. #hicp",
  "id" : 2914909801,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "weishin",
      "screen_name" : "weishin",
      "indices" : [ 3, 11 ],
      "id_str" : "16289892",
      "id" : 16289892
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hicp",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2915761391",
  "text" : "RT @weishin: As a doctor, I won't have to worry about patients not getting screening tests because it's not covered by insurance. #hicp",
  "id" : 2915761391,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Blevins",
      "screen_name" : "TravelerBill",
      "indices" : [ 7, 20 ],
      "id_str" : "18813704",
      "id" : 18813704
    }, {
      "name" : "Jonathan Roberts",
      "screen_name" : "DJonRoberts",
      "indices" : [ 21, 33 ],
      "id_str" : "59006947",
      "id" : 59006947
    }, {
      "name" : "Jim KalogerosChattan",
      "screen_name" : "monkcat",
      "indices" : [ 35, 43 ],
      "id_str" : "60746015",
      "id" : 60746015
    }, {
      "name" : "Bill Strong",
      "screen_name" : "billstrong",
      "indices" : [ 44, 55 ],
      "id_str" : "14083889",
      "id" : 14083889
    }, {
      "name" : "A Vicious Frieze",
      "screen_name" : "completelydark",
      "indices" : [ 56, 71 ],
      "id_str" : "39671383",
      "id" : 39671383
    }, {
      "name" : "Moi",
      "screen_name" : "nbboston",
      "indices" : [ 72, 81 ],
      "id_str" : "22513204",
      "id" : 22513204
    }, {
      "name" : "SummerofSolutions TX",
      "screen_name" : "TXSolutionaries",
      "indices" : [ 82, 98 ],
      "id_str" : "49717136",
      "id" : 49717136
    }, {
      "name" : "weishin",
      "screen_name" : "weishin",
      "indices" : [ 99, 107 ],
      "id_str" : "16289892",
      "id" : 16289892
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hicp",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2916362496",
  "text" : "Thanks @travelerbill @DJonRoberts  @monkcat @billstrong @completelydark @nbboston @TXSolutionaries @weishin http:\/\/bit.ly\/1dbXq1  #hicp",
  "id" : 2916362496,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2889848960",
  "text" : "On tap: AARP tele-town hall on health care reform 1:30; Afternoon meetings w\/ U.S.-China dialogue participants",
  "id" : 2889848960,
  "created_at" : "2009-07-28 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2893443545",
  "text" : "Obama AARP tele-town hall on health care reform around 1:30, watch & chat through Facebook http:\/\/bit.ly\/tCHXt",
  "id" : 2893443545,
  "created_at" : "2009-07-28 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "State Department",
      "screen_name" : "DipNote",
      "indices" : [ 3, 11 ],
      "id_str" : "124623393",
      "id" : 124623393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2897951228",
  "text" : "RT @dipnote: New Blog Post: Secretary Clinton Recaps Her Travel to India, Thailand http:\/\/bit.ly\/ixYFe",
  "id" : 2897951228,
  "created_at" : "2009-07-28 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2870151080",
  "text" : "Small business owner or employee? Obama asks for your questions on health reform via WH site and LinkedIn http:\/\/bit.ly\/34bAJL",
  "id" : 2870151080,
  "created_at" : "2009-07-27 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2870413286",
  "text" : "Cookies: Discuss.  http:\/\/bit.ly\/12GX0h",
  "id" : 2870413286,
  "created_at" : "2009-07-27 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2870776229",
  "text" : "White House Twitter-block mystery solved: http:\/\/bit.ly\/gV9Xe",
  "id" : 2870776229,
  "created_at" : "2009-07-27 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2874012553",
  "text" : "Next White House twitter mystery: How quickly can we reach 1,000,000 followers?",
  "id" : 2874012553,
  "created_at" : "2009-07-27 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2874179791",
  "text" : "Obama on China: \u201CPursuit of power among nations must no longer be seen as a zero-sum game\u201D Progress must be shared http:\/\/bit.ly\/15jahJ",
  "id" : 2874179791,
  "created_at" : "2009-07-27 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2842761675",
  "text" : "For the wonky: Peter Orszag's blog post on the latest CBO health care news http:\/\/bit.ly\/elUQz",
  "id" : 2842761675,
  "created_at" : "2009-07-25 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2842779765",
  "text" : "For the not-so-wonky: new Flickr gallery from the First Family\u2019s trip to Russia, Italy and Ghana http:\/\/bit.ly\/4Gh7t0",
  "id" : 2842779765,
  "created_at" : "2009-07-25 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2819629679",
  "text" : "On tap: Announcing \u201CRace to the Top\u201D http:\/\/bit.ly\/SCONa; 1:45 Chat with Sec. Sebelius on reform; 5:30 19th Anniv. Of ADA",
  "id" : 2819629679,
  "created_at" : "2009-07-24 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2822285748",
  "text" : "Watch\/ Engage\/ Discuss: HHS Secretary Sebelius takes your questions live on health reform via FB at 1:45 http:\/\/bit.ly\/tCHXt",
  "id" : 2822285748,
  "created_at" : "2009-07-24 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2826470689",
  "text" : "Streaming any minute: Obama Proclamation on the 19th Anniversary of the Americans with Disabilities Act http:\/\/bit.ly\/GOZOt",
  "id" : 2826470689,
  "created_at" : "2009-07-24 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthreform",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2788208570",
  "text" : "President Obama\u2019s news conference starts now. Watch live and chat with others via FB @ http:\/\/bit.ly\/Damkn or use #healthreform",
  "id" : 2788208570,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthreform",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2788730689",
  "text" : "\u201CWe inherited an enormous deficit \u2026 but health care reform is not going to add to that burden, it is designed to lower it\u201D #healthreform",
  "id" : 2788730689,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthreform",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2790132626",
  "text" : "Full video of President Obama's news conference on health insurance reform: http:\/\/bit.ly\/KmxIG #healthreform",
  "id" : 2790132626,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2799884817",
  "text" : "On tap: Obama town hall in Cleveland 2:10; Chat with Health Reform Director Nancy-Ann DeParle (take 2) at 3:00",
  "id" : 2799884817,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2783077148",
  "text" : "Orszag\u2019s major speech in NYC on economy, health reform http:\/\/bit.ly\/CAxiw",
  "id" : 2783077148,
  "created_at" : "2009-07-22 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2786446136",
  "text" : "Obama tonight on health insurance reform: \u201C\u2019What\u2019s in this for me?\u2019 \u2026Tonight I want to answer those questions\u201D 8:00 PM EDT",
  "id" : 2786446136,
  "created_at" : "2009-07-22 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2758352946",
  "text" : "On tap: Obama on health reform 1:05; Chat w\/ Health Reform Director DeParle 2:30; Country music celebration 7:30",
  "id" : 2758352946,
  "created_at" : "2009-07-21 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2760443763",
  "text" : "Streaming momentarily: Obama keeps fighting on health reform, watch live http:\/\/bit.ly\/GOZOt",
  "id" : 2760443763,
  "created_at" : "2009-07-21 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2762486849",
  "text" : "Health reform chat update: Nancy-Ann DeParle in important meeting, building consensus \u2013 chat postponed",
  "id" : 2762486849,
  "created_at" : "2009-07-21 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2767277383",
  "text" : "7:30 Country music in the WH: Charley Pride, Brad Paisley, Alison Krauss.  Watch live & chat w\/ other fans http:\/\/bit.ly\/tCHXt",
  "id" : 2767277383,
  "created_at" : "2009-07-21 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2739587252",
  "text" : "Teaching transparency on Recovery projects \u2013 watch live, read the powerpoint http:\/\/bit.ly\/W1ILt",
  "id" : 2739587252,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2740253503",
  "text" : "A bookmark for the ages - National Archives photostream: http:\/\/bit.ly\/19JIBU",
  "id" : 2740253503,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2742579520",
  "text" : "Obama \u201CThis isn\u2019t about me. This isn\u2019t about politics. This is about a health care system that is breaking America\u2019s families\u201D",
  "id" : 2742579520,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2742621815",
  "text" : "Update: Primetime presidential news conference @ White House on Weds 7\/22 moved to 8PM EDT & will be live @ WhiteHouse.gov",
  "id" : 2742621815,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2743086071",
  "text" : "RT @NASA: Moon landing 40th, a spacewalk, and (just now) 100,000 Twitter followers -- it's a big day here at NASA. Thanks everyone!",
  "id" : 2743086071,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2706599374",
  "text" : "Weekly Address: President answers \u201Cspecial interests and their agents in Congress\u201D on health care reform http:\/\/bit.ly\/wa4mx",
  "id" : 2706599374,
  "created_at" : "2009-07-18 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2690561942",
  "text" : "Soccer & Service - All American. Behind the scenes w\/ MLS Champs Columbus Crew at the WH. United We Serve. http:\/\/bit.ly\/Lv9vQ",
  "id" : 2690561942,
  "created_at" : "2009-07-17 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2692241320",
  "text" : "\u201CIf we refuse to be burdened by the old obstacles and old suspicions\u201D Backstage w\/ the President in Russia http:\/\/bit.ly\/6nXgc",
  "id" : 2692241320,
  "created_at" : "2009-07-17 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2694220521",
  "text" : "President\u2019s statement on health care, streaming any minute: http:\/\/bit.ly\/GOZOt",
  "id" : 2694220521,
  "created_at" : "2009-07-17 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2694756439",
  "text" : "You heard it here first: Primetime presidential news conference at the White House, Wed. 7\/22 @ 9PM EDT",
  "id" : 2694756439,
  "created_at" : "2009-07-17 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2688140583",
  "text" : "Sen. Lugar (R-IN): \u201CJudge Sotomayor is clearly qualified\u2026 a judicial temperament \u2026 I will vote to confirm\u201D http:\/\/bit.ly\/DSUwL",
  "id" : 2688140583,
  "created_at" : "2009-07-17 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2689950588",
  "text" : "Vivek Kundra & IT Dashboard, FTW: http:\/\/bit.ly\/sy2Q8",
  "id" : 2689950588,
  "created_at" : "2009-07-17 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2669405766",
  "text" : "Behind the scenes with President Obama in Ghana - see what it was like on the ground, beautiful: http:\/\/bit.ly\/8vEA4",
  "id" : 2669405766,
  "created_at" : "2009-07-16 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "indices" : [ 111, 127 ],
      "id_str" : "17961886",
      "id" : 17961886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2643314180",
  "text" : "Watch Presidents Obama, Bush 43, Clinton, Bush 41 & Carter promote service and join them: http:\/\/bit.ly\/45Ttj6 @nationalservice",
  "id" : 2643314180,
  "created_at" : "2009-07-15 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2651695340",
  "text" : "On tap: More health reform momentum at 1:05 - \"Don't bet against us.\"  For fun, an interview w\/ Bob Costas http:\/\/bit.ly\/g0LhV",
  "id" : 2651695340,
  "created_at" : "2009-07-15 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2654487949",
  "text" : "President: \u201CDeferring reform is nothing more than defending the status quo,\u201D opponents need to look at what they\u2019re defending",
  "id" : 2654487949,
  "created_at" : "2009-07-15 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2659348198",
  "text" : "The President and Willie Mays talked history on Air Force One flying to the All-Star game.  Watch it: http:\/\/bit.ly\/WPunE",
  "id" : 2659348198,
  "created_at" : "2009-07-15 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2659598719",
  "text" : "Clinton: \u201CTo all sides: You can\u2019t claim to be sending messages of peace until you also act against the cultures of hate\u201D http:\/\/bit.ly\/ogOAk",
  "id" : 2659598719,
  "created_at" : "2009-07-15 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2632460364",
  "text" : "On tap: Meeting now w\/ PM of the Netherlands; 3:40 speech on community colleges in MI; First pitch at MLB All-Star Game tonight",
  "id" : 2632460364,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GobiernoUSA.gov",
      "screen_name" : "GobiernoUSA",
      "indices" : [ 3, 15 ],
      "id_str" : "14287409",
      "id" : 14287409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2638009522",
  "text" : "RT @GobiernoUSA: Ahorra dinero con estos consejos para conservar energ\u00EDa en el hogar: http:\/\/bit.ly\/NwoJB",
  "id" : 2638009522,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GobiernoUSA.gov",
      "screen_name" : "GobiernoUSA",
      "indices" : [ 3, 15 ],
      "id_str" : "14287409",
      "id" : 14287409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2638223140",
  "text" : "RT @GobiernoUSA: Las declaraciones iniciales de la Jueza Sotomayor http:\/\/bit.ly\/NwoJB (video of Sotomayor's opening statement)",
  "id" : 2638223140,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2614377243",
  "text" : "On tap: Surgeon General announced 11:40, Sotomayor hearings now, President speaks at Urban and Metropolitan Policy Roundtable",
  "id" : 2614377243,
  "created_at" : "2009-07-13 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2617149245",
  "text" : "Judge Sotomayor\u2019s opening statement at 1:30. Tune in to any cable news network or watch it streamed: http:\/\/bit.ly\/fhfXx",
  "id" : 2617149245,
  "created_at" : "2009-07-13 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2617960791",
  "text" : "Important Council of Economic Advisers report \u201CJobs of the Future\u201D; Watch\/Discuss\/Engage w\/ CEA Chair Romer http:\/\/bit.ly\/DkxkV",
  "id" : 2617960791,
  "created_at" : "2009-07-13 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583013720",
  "text" : "Coming soon at around 8:40am ET this morning: live tweets of the President's speech in Ghana",
  "id" : 2583013720,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583190130",
  "text" : "It's an honor to be in Accra & to speak to the reps of the people of Ghana. I am proud this is my 1st visit to sub-Saharan Africa as Pres.",
  "id" : 2583190130,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583200511",
  "text" : "The 21st century will be shaped by what happens not just in Rome or Moscow or Washington, but by what happens in Accra as well.",
  "id" : 2583200511,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583245743",
  "text" : "For just as it is important to emerge from the control of another nation, it is even more important to build one\u2019s own.",
  "id" : 2583245743,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583262867",
  "text" : "Focus on 4 areas critical to the future of Africa & the dvlpg world: democracy; opportunity; health; & peaceful resolution of conflict",
  "id" : 2583262867,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583270523",
  "text" : "governments that respect the will of their own people are more prosperous, more stable, and more successful than governments that do not.",
  "id" : 2583270523,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583299665",
  "text" : "Africa doesn\u2019t need strongmen, it needs strong institutions.",
  "id" : 2583299665,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583319645",
  "text" : "With better governance, I have no doubt that Africa holds the promise of a broader base for prosperity",
  "id" : 2583319645,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583365042",
  "text" : "Africans have to make responsible choices that prevent the spread of disease - promoting public health in their communities & countries.",
  "id" : 2583365042,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583370244",
  "text" : "America will support these efforts through a comprehensive, global health strategy.",
  "id" : 2583370244,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583390019",
  "text" : "Africa\u2019s diversity should be a source of strength, not a cause for division",
  "id" : 2583390019,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583393597",
  "text" : "We must stand up to inhumanity in our midst. It is never justifiable to target innocents in the name of ideology.",
  "id" : 2583393597,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583437041",
  "text" : "I am particularly speaking to the young people.. Here is what you must know: the world will be what you make of it.",
  "id" : 2583437041,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583440619",
  "text" : "I can promise you this: America will be with you every step of the way. As a partner. As a friend.",
  "id" : 2583440619,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2583443342",
  "text" : "Freedom is your inheritance. Now, it is your responsibility to build upon freedom\u2019s foundation.",
  "id" : 2583443342,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2572474322",
  "text" : "Photo essay: President Obama and the Pope http:\/\/bit.ly\/14CcCA",
  "id" : 2572474322,
  "created_at" : "2009-07-10 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamaghana",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2574401270",
  "text" : "This week, the President received thousands of messages from across Africa. Learn more: http:\/\/bit.ly\/tT4tP #obamaghana",
  "id" : 2574401270,
  "created_at" : "2009-07-10 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FluGov",
      "screen_name" : "FluGov",
      "indices" : [ 36, 43 ],
      "id_str" : "44777959",
      "id" : 44777959
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "h1n1",
      "indices" : [ 44, 49 ]
    }, {
      "text" : "09fs",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2550290695",
  "text" : "HHS is live-tweeting the Flu Summit @flugov #h1n1 #09fs",
  "id" : 2550290695,
  "created_at" : "2009-07-09 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "h1n1",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2551068110",
  "text" : "HHS is announcing a flu prevention PSA contest. To learn more, go to http:\/\/bit.ly\/flupsa or www.flu.gov #h1n1",
  "id" : 2551068110,
  "created_at" : "2009-07-09 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2533058538",
  "text" : "Streaming now: Major health care announcement from Biden and hospital industry reps http:\/\/bit.ly\/GOZOt",
  "id" : 2533058538,
  "created_at" : "2009-07-08 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamaghana",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2536098681",
  "text" : "Ghana Preview: President spoke to AllAfrica.com on aid, investment & tech before major speech http:\/\/bit.ly\/eIe08 #obamaghana",
  "id" : 2536098681,
  "created_at" : "2009-07-08 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2515953220",
  "text" : "President spoke at New School in Moscow, read in English and Russian, see more photos http:\/\/bit.ly\/Xs6Xd",
  "id" : 2515953220,
  "created_at" : "2009-07-07 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHsafefood",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2518016520",
  "text" : "On Tap: Food Safety \u2013 Biden now; Watch, Discuss, Engage w\/ Sebelius & Vilsack in FB chat 2:20 http:\/\/bit.ly\/hSr1F #WHsafefood",
  "id" : 2518016520,
  "created_at" : "2009-07-07 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2500932765",
  "text" : "Reset in Russia: read the President\u2019s remarks, see the progress (and photos) http:\/\/bit.ly\/14Ve70",
  "id" : 2500932765,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamaghana",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2502499739",
  "text" : "Later this week, the President goes to Ghana. Learn about ways to participate: http:\/\/bit.ly\/O4H4m #obamaghana",
  "id" : 2502499739,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2475559309",
  "text" : "Lucky enough to have (or be stuck at) a computer? Check the USO concert and fireworks with us http:\/\/bit.ly\/GOZOt",
  "id" : 2475559309,
  "created_at" : "2009-07-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2438282720",
  "text" : "On tap: For President - JOBS; Health Care meeting on primary care live-stream chat 2:00; &lt;48 hrs for Open Gov Recs http:\/\/bit.ly\/18gnOC",
  "id" : 2438282720,
  "created_at" : "2009-07-02 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2440544219",
  "text" : "2:00 - Watch, Discuss, Engage: Health Care Stakeholder Discussion on Primary Care.  At Facebook: http:\/\/bit.ly\/tCHXt",
  "id" : 2440544219,
  "created_at" : "2009-07-02 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2442023072",
  "text" : "Behind the Scenes: President Obama tapes for his audio-animatronic debut in Disney's Hall of Presidents  http:\/\/bit.ly\/1FvmB",
  "id" : 2442023072,
  "created_at" : "2009-07-02 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]