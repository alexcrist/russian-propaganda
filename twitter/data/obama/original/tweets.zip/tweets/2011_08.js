Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 85, 92 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "James E. Clyburn",
      "screen_name" : "Clyburn",
      "indices" : [ 99, 107 ],
      "id_str" : "188019606",
      "id" : 188019606
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/rl0P15l",
      "expanded_url" : "http:\/\/go.usa.gov\/03y",
      "display_url" : "go.usa.gov\/03y"
    } ]
  },
  "geo" : { },
  "id_str" : "109044816989532160",
  "text" : "#smallbiz = the backbone of our economy & the cornerstone of our community. WH joins @ENERGY Sec & @Clyburn @ SC summit http:\/\/t.co\/rl0P15l",
  "id" : 109044816989532160,
  "created_at" : "2011-08-31 23:28:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "City of Saint Paul",
      "screen_name" : "cityofsaintpaul",
      "indices" : [ 88, 104 ],
      "id_str" : "37032310",
      "id" : 37032310
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/109030751256850433\/photo\/1",
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/0vg4oaz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AYNa4_7CMAAoU8w.jpg",
      "id_str" : "109030751265239040",
      "id" : 109030751265239040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AYNa4_7CMAAoU8w.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0vg4oaz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109030751256850433",
  "text" : "Photo of the Day: President Obama signs a hand as he greets people along a rope line in @cityofsaintpaul, MN: http:\/\/t.co\/0vg4oaz",
  "id" : 109030751256850433,
  "created_at" : "2011-08-31 22:32:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 10, 20 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/1RDOpuu",
      "expanded_url" : "http:\/\/go.usa.gov\/03x",
      "display_url" : "go.usa.gov\/03x"
    } ]
  },
  "geo" : { },
  "id_str" : "109009073793540096",
  "text" : "Secretary @RayLaHood: President Obama calls on Congress to pass transportation measures to protect #jobs: http:\/\/t.co\/1RDOpuu",
  "id" : 109009073793540096,
  "created_at" : "2011-08-31 21:06:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "May Devers",
      "screen_name" : "JustinNOAA",
      "indices" : [ 3, 14 ],
      "id_str" : "4377747975",
      "id" : 4377747975
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Irene",
      "indices" : [ 28, 34 ]
    }, {
      "text" : "NOAA",
      "indices" : [ 56, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 98 ],
      "url" : "http:\/\/t.co\/YflRYnK",
      "expanded_url" : "http:\/\/bit.ly\/onckIk",
      "display_url" : "bit.ly\/onckIk"
    } ]
  },
  "geo" : { },
  "id_str" : "109004504476819456",
  "text" : "RT @JustinNOAA: Video shows #Irene's path & accuracy of #NOAA's track forecast http:\/\/t.co\/YflRYnK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Irene",
        "indices" : [ 12, 18 ]
      }, {
        "text" : "NOAA",
        "indices" : [ 40, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 82 ],
        "url" : "http:\/\/t.co\/YflRYnK",
        "expanded_url" : "http:\/\/bit.ly\/onckIk",
        "display_url" : "bit.ly\/onckIk"
      } ]
    },
    "geo" : { },
    "id_str" : "109003359293415425",
    "text" : "Video shows #Irene's path & accuracy of #NOAA's track forecast http:\/\/t.co\/YflRYnK",
    "id" : 109003359293415425,
    "created_at" : "2011-08-31 20:43:20 +0000",
    "user" : {
      "name" : "NOAA Communications",
      "screen_name" : "NOAAComms",
      "protected" : false,
      "id_str" : "29774968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1891632163\/noaa_grey_normal.jpg",
      "id" : 29774968,
      "verified" : true
    }
  },
  "id" : 109004504476819456,
  "created_at" : "2011-08-31 20:47:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobscouncil",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 131 ],
      "url" : "http:\/\/t.co\/3LGuFYS",
      "expanded_url" : "http:\/\/go.usa.gov\/0lB",
      "display_url" : "go.usa.gov\/0lB"
    } ]
  },
  "geo" : { },
  "id_str" : "108976861194895360",
  "text" : "Ask Obama\u2019s Jobs Council a Q about America\u2019s engineer shortage using #jobscouncil & watch the event live now at http:\/\/t.co\/3LGuFYS",
  "id" : 108976861194895360,
  "created_at" : "2011-08-31 18:58:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Portland State",
      "screen_name" : "Portland_State",
      "indices" : [ 71, 86 ],
      "id_str" : "22589282",
      "id" : 22589282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobscouncil",
      "indices" : [ 31, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/IGc2afS",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "108964299988402176",
  "text" : "Happening now: The President\u2019s #jobscouncil listening & action session @Portland_State. Watch live: http:\/\/t.co\/IGc2afS",
  "id" : 108964299988402176,
  "created_at" : "2011-08-31 18:08:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobscouncil",
      "indices" : [ 28, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/3LGuFYS",
      "expanded_url" : "http:\/\/go.usa.gov\/0lB",
      "display_url" : "go.usa.gov\/0lB"
    } ]
  },
  "geo" : { },
  "id_str" : "108954045208727552",
  "text" : "Have Qs for the President's #jobscouncil? Today's mtg focuses on our engineering shortage. Ask here & watch @ 2ET: http:\/\/t.co\/3LGuFYS",
  "id" : 108954045208727552,
  "created_at" : "2011-08-31 17:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 25, 31 ]
    }, {
      "text" : "Congress",
      "indices" : [ 37, 46 ]
    }, {
      "text" : "transportation",
      "indices" : [ 55, 70 ]
    }, {
      "text" : "jobs",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/VYs3u83",
      "expanded_url" : "http:\/\/bit.ly\/nBkbzT",
      "display_url" : "bit.ly\/nBkbzT"
    } ]
  },
  "geo" : { },
  "id_str" : "108946818745901057",
  "text" : "RT @RayLaHood: President #Obama asks #Congress to pass #transportation measures, protect #jobs http:\/\/t.co\/VYs3u83",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 10, 16 ]
      }, {
        "text" : "Congress",
        "indices" : [ 22, 31 ]
      }, {
        "text" : "transportation",
        "indices" : [ 40, 55 ]
      }, {
        "text" : "jobs",
        "indices" : [ 74, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 99 ],
        "url" : "http:\/\/t.co\/VYs3u83",
        "expanded_url" : "http:\/\/bit.ly\/nBkbzT",
        "display_url" : "bit.ly\/nBkbzT"
      } ]
    },
    "geo" : { },
    "id_str" : "108946417678159872",
    "text" : "President #Obama asks #Congress to pass #transportation measures, protect #jobs http:\/\/t.co\/VYs3u83",
    "id" : 108946417678159872,
    "created_at" : "2011-08-31 16:57:04 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 108946818745901057,
  "created_at" : "2011-08-31 16:58:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108935271264960512",
  "text" : "RT @pfeiffer44: POTUS has requested a Joint Session of Congress at 8 PM on 9\/7 to lay out his plan to create jobs, grow the economy, and ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "108930879065300992",
    "text" : "POTUS has requested a Joint Session of Congress at 8 PM on 9\/7 to lay out his plan to create jobs, grow the economy, and reduce the deficit",
    "id" : 108930879065300992,
    "created_at" : "2011-08-31 15:55:20 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 108935271264960512,
  "created_at" : "2011-08-31 16:12:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108916541713682432",
  "text" : "RT @OMBPress: 2012 Mid-Session Review will be released tomorrow. Look for it at www.budget.gov. #budget",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "budget",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "108913277790208000",
    "text" : "2012 Mid-Session Review will be released tomorrow. Look for it at www.budget.gov. #budget",
    "id" : 108913277790208000,
    "created_at" : "2011-08-31 14:45:23 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 108916541713682432,
  "created_at" : "2011-08-31 14:58:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108915291928535041",
  "text" : "RT @jesseclee44: Obama: \"10 years ago our nation\u2019s infrastructure was ranked 6th globally. Today it\u2019s 23rd. We invest half as much\u2026as we ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "108914920761999360",
    "text" : "Obama: \"10 years ago our nation\u2019s infrastructure was ranked 6th globally. Today it\u2019s 23rd. We invest half as much\u2026as we did 50 years ago\"",
    "id" : 108914920761999360,
    "created_at" : "2011-08-31 14:51:55 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 108915291928535041,
  "created_at" : "2011-08-31 14:53:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/Wql9hJp",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "108913406165254144",
  "text" : "Happening now: President Obama calls on Congress to pass a clean extension of the Surface Transportation Bill. Watch: http:\/\/t.co\/Wql9hJp",
  "id" : 108913406165254144,
  "created_at" : "2011-08-31 14:45:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The American Legion",
      "screen_name" : "AmericanLegion",
      "indices" : [ 67, 82 ],
      "id_str" : "27048645",
      "id" : 27048645
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/108668896646668288\/photo\/1",
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/bkVmqcx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AYIRyScCIAAqgvN.jpg",
      "id_str" : "108668896650862592",
      "id" : 108668896650862592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AYIRyScCIAAqgvN.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1440,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1440,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/bkVmqcx"
    } ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/rYnj228",
      "expanded_url" : "http:\/\/go.usa.gov\/kSZ",
      "display_url" : "go.usa.gov\/kSZ"
    } ]
  },
  "geo" : { },
  "id_str" : "108668896646668288",
  "text" : "\"America will never leave your side\" -President Obama to #veterans @AmericanLegion conf in MN: http:\/\/t.co\/rYnj228 http:\/\/t.co\/bkVmqcx",
  "id" : 108668896646668288,
  "created_at" : "2011-08-30 22:34:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0644\u062E\u0627\u0631\u062C\u064A\u0629 \u0627\u0644\u0623\u0645\u0631\u064A\u0643\u064A\u0629",
      "screen_name" : "USAbilAraby",
      "indices" : [ 3, 15 ],
      "id_str" : "249409411",
      "id" : 249409411
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108629570827194369",
  "text" : "RT @USAbilAraby: \u0628\u064A\u0646\u0645\u0627 \u064A\u0634\u0627\u0631\u0641 \u0634\u0647\u0631\u0631\u0645\u0636\u0627\u0646 \u0639\u0644\u0649 \u0627\u0644\u0646\u0647\u0627\u064A\u0629 \u0646\u0628\u0639\u062B \u0628\u0623\u0637\u064A\u0628 \u062A\u062D\u064A\u0627\u062A\u0646\u0627 \u0628\u0639\u0637\u0644\u0629 \u0645\u0628\u0627\u0631\u0643\u0629 \u0627\u0644\u0649 \u0627\u0644\u0645\u062C\u062A\u0645\u0639\u0627\u062A \u0627\u0644\u0645\u0633\u0644\u0645\u0629 \u062D\u0648\u0644 \u0627\u0644\u0639\u0627\u0644\u0645 \u0639\u064A\u062F \u0645\u0628\u0627\u0631\u0643 #Obama #Ram ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 108, 114 ]
      }, {
        "text" : "Ramadan",
        "indices" : [ 115, 123 ]
      }, {
        "text" : "EidMubarak",
        "indices" : [ 124, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "108620641145593856",
    "text" : "\u0628\u064A\u0646\u0645\u0627 \u064A\u0634\u0627\u0631\u0641 \u0634\u0647\u0631\u0631\u0645\u0636\u0627\u0646 \u0639\u0644\u0649 \u0627\u0644\u0646\u0647\u0627\u064A\u0629 \u0646\u0628\u0639\u062B \u0628\u0623\u0637\u064A\u0628 \u062A\u062D\u064A\u0627\u062A\u0646\u0627 \u0628\u0639\u0637\u0644\u0629 \u0645\u0628\u0627\u0631\u0643\u0629 \u0627\u0644\u0649 \u0627\u0644\u0645\u062C\u062A\u0645\u0639\u0627\u062A \u0627\u0644\u0645\u0633\u0644\u0645\u0629 \u062D\u0648\u0644 \u0627\u0644\u0639\u0627\u0644\u0645 \u0639\u064A\u062F \u0645\u0628\u0627\u0631\u0643 #Obama #Ramadan #EidMubarak",
    "id" : 108620641145593856,
    "created_at" : "2011-08-30 19:22:33 +0000",
    "user" : {
      "name" : "\u0627\u0644\u062E\u0627\u0631\u062C\u064A\u0629 \u0627\u0644\u0623\u0645\u0631\u064A\u0643\u064A\u0629",
      "screen_name" : "USAbilAraby",
      "protected" : false,
      "id_str" : "249409411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551745952730451968\/hpIBWtgZ_normal.png",
      "id" : 249409411,
      "verified" : true
    }
  },
  "id" : 108629570827194369,
  "created_at" : "2011-08-30 19:58:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ramadan",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/IwafmQq",
      "expanded_url" : "http:\/\/go.usa.gov\/kJU",
      "display_url" : "go.usa.gov\/kJU"
    } ]
  },
  "geo" : { },
  "id_str" : "108629425544888320",
  "text" : "Pres Obama: As #Ramadan ends, we send our best wishes for a blessed holiday to Muslim communities around the world: http:\/\/t.co\/IwafmQq",
  "id" : 108629425544888320,
  "created_at" : "2011-08-30 19:57:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The American Legion",
      "screen_name" : "AmericanLegion",
      "indices" : [ 3, 18 ],
      "id_str" : "27048645",
      "id" : 27048645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LegionConv",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 115 ],
      "url" : "http:\/\/t.co\/WImhHVa",
      "expanded_url" : "http:\/\/amlg.nl\/qmrzSj",
      "display_url" : "amlg.nl\/qmrzSj"
    } ]
  },
  "geo" : { },
  "id_str" : "108612935307366400",
  "text" : "RT @AmericanLegion: Obama: Veteran benefits won't be slashed (Legion news story on his address) http:\/\/t.co\/WImhHVa #LegionConv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LegionConv",
        "indices" : [ 96, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 95 ],
        "url" : "http:\/\/t.co\/WImhHVa",
        "expanded_url" : "http:\/\/amlg.nl\/qmrzSj",
        "display_url" : "amlg.nl\/qmrzSj"
      } ]
    },
    "geo" : { },
    "id_str" : "108604856822022144",
    "text" : "Obama: Veteran benefits won't be slashed (Legion news story on his address) http:\/\/t.co\/WImhHVa #LegionConv",
    "id" : 108604856822022144,
    "created_at" : "2011-08-30 18:19:50 +0000",
    "user" : {
      "name" : "The American Legion",
      "screen_name" : "AmericanLegion",
      "protected" : false,
      "id_str" : "27048645",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2229926640\/myLegion_normal.jpg",
      "id" : 27048645,
      "verified" : true
    }
  },
  "id" : 108612935307366400,
  "created_at" : "2011-08-30 18:51:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BacktoSchool",
      "indices" : [ 87, 100 ]
    }, {
      "text" : "EDTour11",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/1mdjzBA",
      "expanded_url" : "http:\/\/go.usa.gov\/kuO",
      "display_url" : "go.usa.gov\/kuO"
    } ]
  },
  "geo" : { },
  "id_str" : "108601402028343296",
  "text" : "RT @arneduncan: Suggestions for my road trip playlist? ED Announces \"Ed & the Economy\" #BacktoSchool Bus Tour http:\/\/t.co\/1mdjzBA #EDTour11",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BacktoSchool",
        "indices" : [ 71, 84 ]
      }, {
        "text" : "EDTour11",
        "indices" : [ 114, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 113 ],
        "url" : "http:\/\/t.co\/1mdjzBA",
        "expanded_url" : "http:\/\/go.usa.gov\/kuO",
        "display_url" : "go.usa.gov\/kuO"
      } ]
    },
    "geo" : { },
    "id_str" : "108599497348755456",
    "text" : "Suggestions for my road trip playlist? ED Announces \"Ed & the Economy\" #BacktoSchool Bus Tour http:\/\/t.co\/1mdjzBA #EDTour11",
    "id" : 108599497348755456,
    "created_at" : "2011-08-30 17:58:32 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 108601402028343296,
  "created_at" : "2011-08-30 18:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hurricane",
      "indices" : [ 96, 106 ]
    }, {
      "text" : "Irene",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108571804104278016",
  "text" : "Today Admin officials travel to CT, NJ, NC, VT & VA to survey recovery & response efforts after #Hurricane #Irene & meet w\/ local officials.",
  "id" : 108571804104278016,
  "created_at" : "2011-08-30 16:08:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/108545902087643136\/photo\/1",
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/XbKG7aX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AYGh7EBCIAEX4LV.jpg",
      "id_str" : "108545902096031745",
      "id" : 108545902096031745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AYGh7EBCIAEX4LV.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XbKG7aX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http:\/\/t.co\/2ssXw61",
      "expanded_url" : "http:\/\/go.usa.gov\/kzb",
      "display_url" : "go.usa.gov\/kzb"
    } ]
  },
  "geo" : { },
  "id_str" : "108545902087643136",
  "text" : "Photo of the Day: President Obama & Alan Krueger leave Oval before  announcement (http:\/\/t.co\/2ssXw61) in Rose Garden: http:\/\/t.co\/XbKG7aX",
  "id" : 108545902087643136,
  "created_at" : "2011-08-30 14:25:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http:\/\/t.co\/nXe6f1F",
      "expanded_url" : "http:\/\/m.fema.gov",
      "display_url" : "m.fema.gov"
    }, {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/Rj1QAjC",
      "expanded_url" : "http:\/\/mobile.weather.gov",
      "display_url" : "mobile.weather.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "108307633043279872",
  "text" : "RT @fema: Resources on your phone: Disaster safety tips http:\/\/t.co\/nXe6f1F. Severe weather watches\/warnings http:\/\/t.co\/Rj1QAjC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 65 ],
        "url" : "http:\/\/t.co\/nXe6f1F",
        "expanded_url" : "http:\/\/m.fema.gov",
        "display_url" : "m.fema.gov"
      }, {
        "indices" : [ 99, 118 ],
        "url" : "http:\/\/t.co\/Rj1QAjC",
        "expanded_url" : "http:\/\/mobile.weather.gov",
        "display_url" : "mobile.weather.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "108307091449593856",
    "text" : "Resources on your phone: Disaster safety tips http:\/\/t.co\/nXe6f1F. Severe weather watches\/warnings http:\/\/t.co\/Rj1QAjC",
    "id" : 108307091449593856,
    "created_at" : "2011-08-29 22:36:37 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 108307633043279872,
  "created_at" : "2011-08-29 22:38:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hurricane",
      "indices" : [ 23, 33 ]
    }, {
      "text" : "Katrina",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/dOPyTOa",
      "expanded_url" : "http:\/\/go.usa.gov\/keR",
      "display_url" : "go.usa.gov\/keR"
    } ]
  },
  "geo" : { },
  "id_str" : "108301969013219328",
  "text" : "Obama on 6 yr anniv of #Hurricane #Katrina: This Administration will stand by those communities until the work is done: http:\/\/t.co\/dOPyTOa",
  "id" : 108301969013219328,
  "created_at" : "2011-08-29 22:16:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/a7Lxqqn",
      "expanded_url" : "http:\/\/go.usa.gov\/ke4",
      "display_url" : "go.usa.gov\/ke4"
    } ]
  },
  "geo" : { },
  "id_str" : "108295405132972032",
  "text" : "Video: President Obama nominates Alan Krueger, one of the nation\u2019s leading economists, to chair the CEA: http:\/\/t.co\/a7Lxqqn",
  "id" : 108295405132972032,
  "created_at" : "2011-08-29 21:50:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "indices" : [ 3, 9 ],
      "id_str" : "15460572",
      "id" : 15460572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 52 ],
      "url" : "http:\/\/t.co\/AE1Cydk",
      "expanded_url" : "http:\/\/www.wh.gov\/ondcp",
      "display_url" : "wh.gov\/ondcp"
    } ]
  },
  "geo" : { },
  "id_str" : "108271005201481728",
  "text" : "RT @ONDCP: Visit our new website http:\/\/t.co\/AE1Cydk for Administration info on substance abuse prevention, criminal justice reform & more.",
  "id" : 108271005201481728,
  "created_at" : "2011-08-29 20:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/IK2JvRh",
      "expanded_url" : "http:\/\/1.usa.gov\/radnAB",
      "display_url" : "1.usa.gov\/radnAB"
    } ]
  },
  "geo" : { },
  "id_str" : "108245189730115584",
  "text" : "RT @VP: VP had a great trip to Asia; check out full coverage of his time in China, Mongolia and Japan http:\/\/t.co\/IK2JvRh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 113 ],
        "url" : "http:\/\/t.co\/IK2JvRh",
        "expanded_url" : "http:\/\/1.usa.gov\/radnAB",
        "display_url" : "1.usa.gov\/radnAB"
      } ]
    },
    "geo" : { },
    "id_str" : "108244549687717888",
    "text" : "VP had a great trip to Asia; check out full coverage of his time in China, Mongolia and Japan http:\/\/t.co\/IK2JvRh",
    "id" : 108244549687717888,
    "created_at" : "2011-08-29 18:28:06 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 108245189730115584,
  "created_at" : "2011-08-29 18:30:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA.gov",
      "screen_name" : "USAgov",
      "indices" : [ 42, 49 ],
      "id_str" : "14074515",
      "id" : 14074515
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/Kg8yGN6",
      "expanded_url" : "http:\/\/1.usa.gov\/nZieQU",
      "display_url" : "1.usa.gov\/nZieQU"
    } ]
  },
  "geo" : { },
  "id_str" : "108241645199302656",
  "text" : "As part of Obama's Campaign to Cut Waste, @USAgov takes a fresh look at .gov web strategy & wants your ideas: http:\/\/t.co\/Kg8yGN6",
  "id" : 108241645199302656,
  "created_at" : "2011-08-29 18:16:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countrybeforeparty",
      "indices" : [ 44, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108194057502720000",
  "text" : "\"My hope and expectation is that we can put #countrybeforeparty & get something done for the American people.\" -President Obama",
  "id" : 108194057502720000,
  "created_at" : "2011-08-29 15:07:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hurricane",
      "indices" : [ 41, 51 ]
    }, {
      "text" : "Irene",
      "indices" : [ 52, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 112 ],
      "url" : "http:\/\/t.co\/IGc2afS",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "108192654810021891",
  "text" : "Happening now: President Obama speaks on #Hurricane #Irene & makes a personnel announcement: http:\/\/t.co\/IGc2afS",
  "id" : 108192654810021891,
  "created_at" : "2011-08-29 15:01:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/1gWG5vz",
      "expanded_url" : "http:\/\/on.wsj.com\/rnXmw9",
      "display_url" : "on.wsj.com\/rnXmw9"
    } ]
  },
  "geo" : { },
  "id_str" : "108185426140991491",
  "text" : "RT @jesseclee44: WSJ write-up on Alan Krueger for CEA Chairman worth a read: http:\/\/t.co\/1gWG5vz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 79 ],
        "url" : "http:\/\/t.co\/1gWG5vz",
        "expanded_url" : "http:\/\/on.wsj.com\/rnXmw9",
        "display_url" : "on.wsj.com\/rnXmw9"
      } ]
    },
    "geo" : { },
    "id_str" : "108181923775524864",
    "text" : "WSJ write-up on Alan Krueger for CEA Chairman worth a read: http:\/\/t.co\/1gWG5vz",
    "id" : 108181923775524864,
    "created_at" : "2011-08-29 14:19:15 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 108185426140991491,
  "created_at" : "2011-08-29 14:33:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/Wql9hJp",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "108174941953855488",
  "text" : "Today, President Obama will nominate Alan Krueger to lead the Council of Economic Advisers. Watch live @ 11ET: http:\/\/t.co\/Wql9hJp",
  "id" : 108174941953855488,
  "created_at" : "2011-08-29 13:51:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/pQF41T9",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "107920203618324482",
  "text" : "Happening now: President Obama speaks on Hurricane Irene from the Rose Garden. Watch it live at: http:\/\/t.co\/pQF41T9",
  "id" : 107920203618324482,
  "created_at" : "2011-08-28 20:59:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hurricane",
      "indices" : [ 63, 73 ]
    }, {
      "text" : "Irene",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107900537902612481",
  "text" : "Today at 5 pm EDT: President Obama will deliver a statement on #Hurricane #Irene from the Rose Garden",
  "id" : 107900537902612481,
  "created_at" : "2011-08-28 19:41:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/107551865947963392\/photo\/1",
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/f2MYhoU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AX4Z2i0CQAA1y6H.jpg",
      "id_str" : "107551865952157696",
      "id" : 107551865952157696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AX4Z2i0CQAA1y6H.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 858,
        "resize" : "fit",
        "w" : 1526
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/f2MYhoU"
    } ],
    "hashtags" : [ {
      "text" : "Hurricane",
      "indices" : [ 94, 104 ]
    }, {
      "text" : "Irene",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107551865947963392",
  "text" : "PHOTO: President Obama visits the National Response Coordination Center @ FEMA HQ's today for #Hurricane #Irene update http:\/\/t.co\/f2MYhoU",
  "id" : 107551865947963392,
  "created_at" : "2011-08-27 20:35:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "American Red Cross",
      "screen_name" : "RedCross",
      "indices" : [ 14, 23 ],
      "id_str" : "6519522",
      "id" : 6519522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "irene",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107547396036239360",
  "text" : "RT @SBAgov: RT@RedCross Heading to a shelter? Bring clothes, pillows, blankets, meds, hygiene items & important documents. #irene",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "American Red Cross",
        "screen_name" : "RedCross",
        "indices" : [ 2, 11 ],
        "id_str" : "6519522",
        "id" : 6519522
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "irene",
        "indices" : [ 111, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "107544663484936192",
    "text" : "RT@RedCross Heading to a shelter? Bring clothes, pillows, blankets, meds, hygiene items & important documents. #irene",
    "id" : 107544663484936192,
    "created_at" : "2011-08-27 20:07:00 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 107547396036239360,
  "created_at" : "2011-08-27 20:17:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Irene",
      "indices" : [ 56, 62 ]
    }, {
      "text" : "MDHurricane",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 83 ],
      "url" : "http:\/\/t.co\/tjFXbOH",
      "expanded_url" : "http:\/\/1.usa.gov\/g33xmq",
      "display_url" : "1.usa.gov\/g33xmq"
    } ]
  },
  "geo" : { },
  "id_str" : "107483553046081536",
  "text" : "RT @mema_feeds: Here's a good checklist of supplies for #Irene. http:\/\/t.co\/tjFXbOH Be prepared. #MDHurricane",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Irene",
        "indices" : [ 40, 46 ]
      }, {
        "text" : "MDHurricane",
        "indices" : [ 81, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 67 ],
        "url" : "http:\/\/t.co\/tjFXbOH",
        "expanded_url" : "http:\/\/1.usa.gov\/g33xmq",
        "display_url" : "1.usa.gov\/g33xmq"
      } ]
    },
    "geo" : { },
    "id_str" : "107437265969614850",
    "text" : "Here's a good checklist of supplies for #Irene. http:\/\/t.co\/tjFXbOH Be prepared. #MDHurricane",
    "id" : 107437265969614850,
    "created_at" : "2011-08-27 13:00:14 +0000",
    "user" : {
      "name" : "MDMEMA",
      "screen_name" : "MDMEMA",
      "protected" : false,
      "id_str" : "16999795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795612311696314368\/L2BRBTLv_normal.jpg",
      "id" : 16999795,
      "verified" : true
    }
  },
  "id" : 107483553046081536,
  "created_at" : "2011-08-27 16:04:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHSJournal",
      "screen_name" : "DHSJournal",
      "indices" : [ 3, 14 ],
      "id_str" : "376234273",
      "id" : 376234273
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 77, 82 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107482354871840769",
  "text" : "RT @DHSJournal: Search for a shelter: Text SHELTER + your ZIP code to 43362 (@FEMA).",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FEMA",
        "screen_name" : "fema",
        "indices" : [ 61, 66 ],
        "id_str" : "16669075",
        "id" : 16669075
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "107438396019982336",
    "text" : "Search for a shelter: Text SHELTER + your ZIP code to 43362 (@FEMA).",
    "id" : 107438396019982336,
    "created_at" : "2011-08-27 13:04:44 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 107482354871840769,
  "created_at" : "2011-08-27 15:59:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/TDIHHxj",
      "expanded_url" : "http:\/\/youtu.be\/M3VP--sfNBY",
      "display_url" : "youtu.be\/M3VP--sfNBY"
    } ]
  },
  "geo" : { },
  "id_str" : "107453995462828032",
  "text" : "Weekly Address: President Obama pays tribute to first responders, in particular those who lost their lives on 9\/11. http:\/\/t.co\/TDIHHxj",
  "id" : 107453995462828032,
  "created_at" : "2011-08-27 14:06:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 117, 122 ],
      "id_str" : "16669075",
      "id" : 16669075
    }, {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 125, 137 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hurricane",
      "indices" : [ 5, 15 ]
    }, {
      "text" : "Irene",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 61 ],
      "url" : "http:\/\/t.co\/hBgX8hq",
      "expanded_url" : "http:\/\/ready.gov",
      "display_url" : "ready.gov"
    }, {
      "indices" : [ 64, 83 ],
      "url" : "http:\/\/t.co\/jM1cDJQ",
      "expanded_url" : "http:\/\/listo.gov",
      "display_url" : "listo.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "107221405573189632",
  "text" : "Find #Hurricane #Irene preparation tips @ http:\/\/t.co\/hBgX8hq & http:\/\/t.co\/jM1cDJQ. For latest storm updates follow @fema & @CraigatFEMA",
  "id" : 107221405573189632,
  "created_at" : "2011-08-26 22:42:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/5T2Wz3Q",
      "expanded_url" : "http:\/\/wh.gov\/Y9q",
      "display_url" : "wh.gov\/Y9q"
    } ]
  },
  "geo" : { },
  "id_str" : "107195472355139584",
  "text" : "Sunday's MLK Memorial dedication was postponed, but don\u2019t miss Maya Angelou\u2019s new poem written for the event: http:\/\/t.co\/5T2Wz3Q",
  "id" : 107195472355139584,
  "created_at" : "2011-08-26 20:59:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/HU7xTdG",
      "expanded_url" : "http:\/\/wh.gov\/Y87",
      "display_url" : "wh.gov\/Y87"
    } ]
  },
  "geo" : { },
  "id_str" : "107173930145550336",
  "text" : "POTUS on Women\u2019s Equality Day: Celebrate the achievements of women & recommit ourselves to the goal of gender equality http:\/\/t.co\/HU7xTdG",
  "id" : 107173930145550336,
  "created_at" : "2011-08-26 19:33:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 49, 52 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dcquake",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/dKRVhBG",
      "expanded_url" : "http:\/\/youtu.be\/ZbnyA_8AegI",
      "display_url" : "youtu.be\/ZbnyA_8AegI"
    } ]
  },
  "geo" : { },
  "id_str" : "107156114466017280",
  "text" : "New West Wing Week: Mailbag Summer Edition 2011: @VP in China, #dcquake dramatic reenactment and your Q\u2019s answered http:\/\/t.co\/dKRVhBG",
  "id" : 107156114466017280,
  "created_at" : "2011-08-26 18:23:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hurricane",
      "indices" : [ 9, 19 ]
    }, {
      "text" : "Irene",
      "indices" : [ 20, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/848Pmih",
      "expanded_url" : "http:\/\/1.usa.gov\/roWu8f",
      "display_url" : "1.usa.gov\/roWu8f"
    } ]
  },
  "geo" : { },
  "id_str" : "107124110999560192",
  "text" : "POTUS on #Hurricane #Irene: \u201CTo sum up: all indications point to this being a historic hurricane.\u201D Full statement: http:\/\/t.co\/848Pmih",
  "id" : 107124110999560192,
  "created_at" : "2011-08-26 16:15:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hurricane",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107112959188283392",
  "text" : "President Obama: \u201CThe federal government has spent the better part of the last week working...to see to it that we\u2019re prepared.\" #Hurricane",
  "id" : 107112959188283392,
  "created_at" : "2011-08-26 15:31:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Irene",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107112558498021376",
  "text" : "POTUS: \u201CTake this storm seriously; listen to your state & local officials; & if you\u2019re given an evacuation order, please follow it.\u201D #Irene",
  "id" : 107112558498021376,
  "created_at" : "2011-08-26 15:29:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hurricane",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107112414981529600",
  "text" : "\u201CI cannot stress this highly enough: if you are in the projected path of this #hurricane, take precautions now\u201D \u2013President Obama",
  "id" : 107112414981529600,
  "created_at" : "2011-08-26 15:29:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hurricane",
      "indices" : [ 52, 62 ]
    }, {
      "text" : "Irene",
      "indices" : [ 63, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/pQF41T9",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "107112174706622464",
  "text" : "Happening Now: President Obama makes a statement on #Hurricane #Irene from Martha\u2019s Vineyard. Listen to live audio at: http:\/\/t.co\/pQF41T9",
  "id" : 107112174706622464,
  "created_at" : "2011-08-26 15:28:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Irene",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107090482496159745",
  "text" : "RT @pfeiffer44: POTUS will make a statement on hurricane #Irene at 1130 AM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Irene",
        "indices" : [ 41, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "107075662891847681",
    "text" : "POTUS will make a statement on hurricane #Irene at 1130 AM",
    "id" : 107075662891847681,
    "created_at" : "2011-08-26 13:03:22 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 107090482496159745,
  "created_at" : "2011-08-26 14:02:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USGS",
      "screen_name" : "USGS",
      "indices" : [ 71, 76 ],
      "id_str" : "14505838",
      "id" : 14505838
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "earthquake",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/yV6aVdF",
      "expanded_url" : "http:\/\/go.usa.gov\/kGy",
      "display_url" : "go.usa.gov\/kGy"
    } ]
  },
  "geo" : { },
  "id_str" : "107084836350599168",
  "text" : "Join a live chat today at 11 am EDT on the east coast #earthquake with @USGS scientist. Ask Q\u2019s and watch live at: http:\/\/t.co\/yV6aVdF",
  "id" : 107084836350599168,
  "created_at" : "2011-08-26 13:39:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 7, 12 ],
      "id_str" : "16669075",
      "id" : 16669075
    }, {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 17, 29 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Irene",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106757757981556736",
  "text" : "Follow @FEMA and @CraigatFEMA for preparation tips and the latest updates on Hurricane #Irene",
  "id" : 106757757981556736,
  "created_at" : "2011-08-25 16:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "USA TODAY's The Oval",
      "screen_name" : "TheOval",
      "indices" : [ 97, 105 ],
      "id_str" : "18026148",
      "id" : 18026148
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 106, 109 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/dsfEcSd",
      "expanded_url" : "http:\/\/usat.ly\/ptMl3e",
      "display_url" : "usat.ly\/ptMl3e"
    } ]
  },
  "geo" : { },
  "id_str" : "106741995241869312",
  "text" : "RT @OMBPress: USA Today on CBO: Obama's 2009 stimulus is still boosting jobs http:\/\/t.co\/dsfEcSd @TheOval @VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USA TODAY's The Oval",
        "screen_name" : "TheOval",
        "indices" : [ 83, 91 ],
        "id_str" : "18026148",
        "id" : 18026148
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 92, 95 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 82 ],
        "url" : "http:\/\/t.co\/dsfEcSd",
        "expanded_url" : "http:\/\/usat.ly\/ptMl3e",
        "display_url" : "usat.ly\/ptMl3e"
      } ]
    },
    "geo" : { },
    "id_str" : "106741849238142976",
    "text" : "USA Today on CBO: Obama's 2009 stimulus is still boosting jobs http:\/\/t.co\/dsfEcSd @TheOval @VP",
    "id" : 106741849238142976,
    "created_at" : "2011-08-25 14:56:54 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 106741995241869312,
  "created_at" : "2011-08-25 14:57:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/goa8yBX",
      "expanded_url" : "http:\/\/1.usa.gov\/blUvBo",
      "display_url" : "1.usa.gov\/blUvBo"
    } ]
  },
  "geo" : { },
  "id_str" : "106484531401469952",
  "text" : "Can\u2019t get enough of 'First Dog' Bo? Here's a slide show featuring the current resident of the White House dog house: http:\/\/t.co\/goa8yBX",
  "id" : 106484531401469952,
  "created_at" : "2011-08-24 21:54:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/106468331325886467\/photo\/1",
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/oNfR4Yc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AXpAYh0CEAAhOQy.jpg",
      "id_str" : "106468331334275072",
      "id" : 106468331334275072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXpAYh0CEAAhOQy.jpg",
      "sizes" : [ {
        "h" : 451,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 676
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oNfR4Yc"
    } ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106468331325886467",
  "text" : "Photo of the Day: President Obama on the phone w\/ French President Nicholas Sarkozy discussing the situation in #Libya: http:\/\/t.co\/oNfR4Yc",
  "id" : 106468331325886467,
  "created_at" : "2011-08-24 20:50:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/SY5CTU6",
      "expanded_url" : "http:\/\/1.usa.gov\/r1oOZo",
      "display_url" : "1.usa.gov\/r1oOZo"
    } ]
  },
  "geo" : { },
  "id_str" : "106447401845395457",
  "text" : "In the path of Hurricane Irene? Check out these resources and learn about steps business can take to be prepared: http:\/\/t.co\/SY5CTU6",
  "id" : 106447401845395457,
  "created_at" : "2011-08-24 19:26:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 11, 21 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/Jhmg5gA",
      "expanded_url" : "http:\/\/bit.ly\/qNU8NZ",
      "display_url" : "bit.ly\/qNU8NZ"
    } ]
  },
  "geo" : { },
  "id_str" : "106426036346040320",
  "text" : "Photo from @petesouza in Martha's Vineyard: President Obama meets with Brian Deese of the National Economic Council: http:\/\/t.co\/Jhmg5gA",
  "id" : 106426036346040320,
  "created_at" : "2011-08-24 18:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskArne",
      "indices" : [ 35, 43 ]
    }, {
      "text" : "AskArne",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/SyGLtHx",
      "expanded_url" : "http:\/\/bit.ly\/qsCmYM",
      "display_url" : "bit.ly\/qsCmYM"
    } ]
  },
  "geo" : { },
  "id_str" : "106416627117076480",
  "text" : "RT @usedgov: Starting momentarily: #AskArne Town Hall. Submit questions via #AskArne & Watch LIVE http:\/\/t.co\/SyGLtHx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskArne",
        "indices" : [ 22, 30 ]
      }, {
        "text" : "AskArne",
        "indices" : [ 63, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 104 ],
        "url" : "http:\/\/t.co\/SyGLtHx",
        "expanded_url" : "http:\/\/bit.ly\/qsCmYM",
        "display_url" : "bit.ly\/qsCmYM"
      } ]
    },
    "geo" : { },
    "id_str" : "106415530684071937",
    "text" : "Starting momentarily: #AskArne Town Hall. Submit questions via #AskArne & Watch LIVE http:\/\/t.co\/SyGLtHx",
    "id" : 106415530684071937,
    "created_at" : "2011-08-24 17:20:14 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 106416627117076480,
  "created_at" : "2011-08-24 17:24:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/TxLlKdX",
      "expanded_url" : "http:\/\/1.usa.gov\/nlJMqk",
      "display_url" : "1.usa.gov\/nlJMqk"
    } ]
  },
  "geo" : { },
  "id_str" : "106394499990814721",
  "text" : "Puppies, cats, ponies and raccoons? Check out our photo gallery of the pets who have called the White House home: http:\/\/t.co\/TxLlKdX",
  "id" : 106394499990814721,
  "created_at" : "2011-08-24 15:56:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskArne",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http:\/\/t.co\/pBUMrjG",
      "expanded_url" : "http:\/\/go.usa.gov\/kPH",
      "display_url" : "go.usa.gov\/kPH"
    } ]
  },
  "geo" : { },
  "id_str" : "106379436026372097",
  "text" : "RT @arneduncan: Great ?s coming in for today's #AskArne Town Hall. Keep them coming & tune in at 1:30 pm ET http:\/\/t.co\/pBUMrjG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskArne",
        "indices" : [ 31, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 111 ],
        "url" : "http:\/\/t.co\/pBUMrjG",
        "expanded_url" : "http:\/\/go.usa.gov\/kPH",
        "display_url" : "go.usa.gov\/kPH"
      } ]
    },
    "geo" : { },
    "id_str" : "106370142216265728",
    "text" : "Great ?s coming in for today's #AskArne Town Hall. Keep them coming & tune in at 1:30 pm ET http:\/\/t.co\/pBUMrjG",
    "id" : 106370142216265728,
    "created_at" : "2011-08-24 14:19:52 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 106379436026372097,
  "created_at" : "2011-08-24 14:56:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHSJournal",
      "screen_name" : "DHSJournal",
      "indices" : [ 3, 14 ],
      "id_str" : "376234273",
      "id" : 376234273
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DHSJournal\/status\/106349725049032705\/photo\/1",
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/ZaDNHGn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AXnUgvACEAAUvAm.png",
      "id_str" : "106349725057421312",
      "id" : 106349725057421312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXnUgvACEAAUvAm.png",
      "sizes" : [ {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 895
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 895
      } ],
      "display_url" : "pic.twitter.com\/ZaDNHGn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 112 ],
      "url" : "http:\/\/t.co\/xWt2pbO",
      "expanded_url" : "http:\/\/1.usa.gov\/aexSC",
      "display_url" : "1.usa.gov\/aexSC"
    } ]
  },
  "geo" : { },
  "id_str" : "106352715155775491",
  "text" : "RT @DHSJournal: Hurricane Irene 8AM Update. East Coast: Get A Kit. Make A Plan. Be Informed. http:\/\/t.co\/xWt2pbO http:\/\/t.co\/ZaDNHGn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DHSJournal\/status\/106349725049032705\/photo\/1",
        "indices" : [ 97, 116 ],
        "url" : "http:\/\/t.co\/ZaDNHGn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AXnUgvACEAAUvAm.png",
        "id_str" : "106349725057421312",
        "id" : 106349725057421312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXnUgvACEAAUvAm.png",
        "sizes" : [ {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 895
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 895
        } ],
        "display_url" : "pic.twitter.com\/ZaDNHGn"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 96 ],
        "url" : "http:\/\/t.co\/xWt2pbO",
        "expanded_url" : "http:\/\/1.usa.gov\/aexSC",
        "display_url" : "1.usa.gov\/aexSC"
      } ]
    },
    "geo" : { },
    "id_str" : "106349725049032705",
    "text" : "Hurricane Irene 8AM Update. East Coast: Get A Kit. Make A Plan. Be Informed. http:\/\/t.co\/xWt2pbO http:\/\/t.co\/ZaDNHGn",
    "id" : 106349725049032705,
    "created_at" : "2011-08-24 12:58:46 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 106352715155775491,
  "created_at" : "2011-08-24 13:10:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 7, 10 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/106343736304349184\/photo\/1",
      "indices" : [ 64, 83 ],
      "url" : "http:\/\/t.co\/YnZl2lH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AXnPEJLCMAAZbh-.jpg",
      "id_str" : "106343736308543488",
      "id" : 106343736308543488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXnPEJLCMAAZbh-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/YnZl2lH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106350090934951936",
  "text" : "Photo: @VP Joe Biden speaks to troops @ Yokota Air Base, Japan: http:\/\/t.co\/YnZl2lH",
  "id" : 106350090934951936,
  "created_at" : "2011-08-24 13:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 7, 19 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dcquake",
      "indices" : [ 23, 31 ]
    }, {
      "text" : "Hurricane",
      "indices" : [ 34, 44 ]
    }, {
      "text" : "Irene",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/D0Djvgv",
      "expanded_url" : "http:\/\/1.usa.gov\/nGnHHH",
      "display_url" : "1.usa.gov\/nGnHHH"
    } ]
  },
  "geo" : { },
  "id_str" : "106128111732654081",
  "text" : "Video: @CraigatFEMA on #dcquake & #Hurricane #Irene. Emergencies can strike anywhere & without warning. Be prepared: http:\/\/t.co\/D0Djvgv",
  "id" : 106128111732654081,
  "created_at" : "2011-08-23 22:18:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 47, 52 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DCQuake",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http:\/\/t.co\/vgOmqkn",
      "expanded_url" : "http:\/\/1.usa.gov\/pRa7WI",
      "display_url" : "1.usa.gov\/pRa7WI"
    }, {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/Gay0Zgz",
      "expanded_url" : "http:\/\/bit.ly\/ruhJVw",
      "display_url" : "bit.ly\/ruhJVw"
    } ]
  },
  "geo" : { },
  "id_str" : "106098923579510784",
  "text" : "#DCQuake serves as a reminder to get prepared. @fema on what to do during\/after: http:\/\/t.co\/vgOmqkn & statement: http:\/\/t.co\/Gay0Zgz",
  "id" : 106098923579510784,
  "created_at" : "2011-08-23 20:22:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHSJournal",
      "screen_name" : "DHSJournal",
      "indices" : [ 3, 14 ],
      "id_str" : "376234273",
      "id" : 376234273
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 88, 96 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106080314610286592",
  "text" : "RT @DHSJournal: Quake: Tell friends\/family you are OK via text, email and social media (@twitter & facebook.com). Avoid calls.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 72, 80 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106076003671097344",
    "text" : "Quake: Tell friends\/family you are OK via text, email and social media (@twitter & facebook.com). Avoid calls.",
    "id" : 106076003671097344,
    "created_at" : "2011-08-23 18:51:04 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 106080314610286592,
  "created_at" : "2011-08-23 19:08:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 3, 15 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Va",
      "indices" : [ 17, 20 ]
    }, {
      "text" : "earthquake",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/9h2dqR8",
      "expanded_url" : "http:\/\/earthquake.usgs.gov\/earthquakes\/pager\/events\/us\/c0005ild\/",
      "display_url" : "earthquake.usgs.gov\/earthquakes\/pa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "106075460252872704",
  "text" : "RT @CraigatFEMA: #Va #earthquake PAGER - M 5.9 - Virgina\nhttp:\/\/t.co\/9h2dqR8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Va",
        "indices" : [ 0, 3 ]
      }, {
        "text" : "earthquake",
        "indices" : [ 4, 15 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 59 ],
        "url" : "http:\/\/t.co\/9h2dqR8",
        "expanded_url" : "http:\/\/earthquake.usgs.gov\/earthquakes\/pager\/events\/us\/c0005ild\/",
        "display_url" : "earthquake.usgs.gov\/earthquakes\/pa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "106074154733801472",
    "text" : "#Va #earthquake PAGER - M 5.9 - Virgina\nhttp:\/\/t.co\/9h2dqR8",
    "id" : 106074154733801472,
    "created_at" : "2011-08-23 18:43:43 +0000",
    "user" : {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "protected" : false,
      "id_str" : "67378554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522052690138763264\/isW58OSG_normal.jpeg",
      "id" : 67378554,
      "verified" : true
    }
  },
  "id" : 106075460252872704,
  "created_at" : "2011-08-23 18:48:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/106006514938036224\/photo\/1",
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/rFpk0z8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AXicXRtCQAA3m80.jpg",
      "id_str" : "106006514946424832",
      "id" : 106006514946424832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXicXRtCQAA3m80.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rFpk0z8"
    } ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106006514938036224",
  "text" : "Photo of the Day: Reflected in a mirror, Obama conducts a call w\/ natl security staff on #Libya from Chilmark, MA: http:\/\/t.co\/rFpk0z8",
  "id" : 106006514938036224,
  "created_at" : "2011-08-23 14:14:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/105979805362688001\/photo\/1",
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/Yfd4GWg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AXiEEkxCEAAKuUP.jpg",
      "id_str" : "105979805366882304",
      "id" : 105979805366882304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXiEEkxCEAAKuUP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/Yfd4GWg"
    } ],
    "hashtags" : [ {
      "text" : "VPinAsia",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105986202850701312",
  "text" : "RT @VP: PHOTO: VP talks to survivors of the Japanese Tsunami at  \na temporary housing center in Natori, Japan. #VPinAsia http:\/\/t.co\/Yfd4GWg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/105979805362688001\/photo\/1",
        "indices" : [ 113, 132 ],
        "url" : "http:\/\/t.co\/Yfd4GWg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AXiEEkxCEAAKuUP.jpg",
        "id_str" : "105979805366882304",
        "id" : 105979805366882304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXiEEkxCEAAKuUP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/Yfd4GWg"
      } ],
      "hashtags" : [ {
        "text" : "VPinAsia",
        "indices" : [ 103, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105979805362688001",
    "text" : "PHOTO: VP talks to survivors of the Japanese Tsunami at  \na temporary housing center in Natori, Japan. #VPinAsia http:\/\/t.co\/Yfd4GWg",
    "id" : 105979805362688001,
    "created_at" : "2011-08-23 12:28:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 105986202850701312,
  "created_at" : "2011-08-23 12:54:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/fq5FpQJ",
      "expanded_url" : "http:\/\/1.usa.gov\/nueUvD",
      "display_url" : "1.usa.gov\/nueUvD"
    } ]
  },
  "geo" : { },
  "id_str" : "105824350950785024",
  "text" : "President Obama: The Qaddafi regime is coming to an end & the future of #Libya is in the hands of its people: http:\/\/t.co\/fq5FpQJ",
  "id" : 105824350950785024,
  "created_at" : "2011-08-23 02:11:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/105764608224145408\/photo\/1",
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/f6W5ry7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AXfAWc9CMAAyQJe.jpg",
      "id_str" : "105764608228339712",
      "id" : 105764608228339712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXfAWc9CMAAyQJe.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/f6W5ry7"
    } ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 32, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 106 ],
      "url" : "http:\/\/t.co\/fq5FpQJ",
      "expanded_url" : "http:\/\/1.usa.gov\/nueUvD",
      "display_url" : "1.usa.gov\/nueUvD"
    } ]
  },
  "geo" : { },
  "id_str" : "105764608224145408",
  "text" : "President Obama: \"The future of #Libya is in the hands of its people.\" Full statement: http:\/\/t.co\/fq5FpQJ http:\/\/t.co\/f6W5ry7",
  "id" : 105764608224145408,
  "created_at" : "2011-08-22 22:13:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0644\u062E\u0627\u0631\u062C\u064A\u0629 \u0627\u0644\u0623\u0645\u0631\u064A\u0643\u064A\u0629",
      "screen_name" : "USAbilAraby",
      "indices" : [ 3, 15 ],
      "id_str" : "249409411",
      "id" : 249409411
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 98, 104 ]
    }, {
      "text" : "Libya",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105760244113743872",
  "text" : "RT @USAbilAraby: \u0627\u0644\u0631\u0626\u064A\u0633 \u0623\u0648\u0628\u0627\u0645\u0627: \u0627\u0646 \u0646\u0638\u0627\u0645 \u0627\u0644\u0642\u0630\u0627\u0641\u064A \u0642\u062F \u0642\u0631\u0628\u062A \u0646\u0647\u0627\u064A\u062A\u0647 \u0648\u0627\u0646 \u0645\u0633\u062A\u0642\u0628\u0644 \u0644\u064A\u0628\u064A\u0627 \u0641\u064A \u064A\u062F\u0627\u0644\u0634\u0639\u0628 \u0627\u0644\u0644\u064A\u0628\u064A #Obama #Libya",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 81, 87 ]
      }, {
        "text" : "Libya",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105734208433045504",
    "text" : "\u0627\u0644\u0631\u0626\u064A\u0633 \u0623\u0648\u0628\u0627\u0645\u0627: \u0627\u0646 \u0646\u0638\u0627\u0645 \u0627\u0644\u0642\u0630\u0627\u0641\u064A \u0642\u062F \u0642\u0631\u0628\u062A \u0646\u0647\u0627\u064A\u062A\u0647 \u0648\u0627\u0646 \u0645\u0633\u062A\u0642\u0628\u0644 \u0644\u064A\u0628\u064A\u0627 \u0641\u064A \u064A\u062F\u0627\u0644\u0634\u0639\u0628 \u0627\u0644\u0644\u064A\u0628\u064A #Obama #Libya",
    "id" : 105734208433045504,
    "created_at" : "2011-08-22 20:12:54 +0000",
    "user" : {
      "name" : "\u0627\u0644\u062E\u0627\u0631\u062C\u064A\u0629 \u0627\u0644\u0623\u0645\u0631\u064A\u0643\u064A\u0629",
      "screen_name" : "USAbilAraby",
      "protected" : false,
      "id_str" : "249409411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551745952730451968\/hpIBWtgZ_normal.png",
      "id" : 249409411,
      "verified" : true
    }
  },
  "id" : 105760244113743872,
  "created_at" : "2011-08-22 21:56:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 1, 11 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Illinois",
      "indices" : [ 23, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/giRSq3g",
      "expanded_url" : "http:\/\/1.usa.gov\/ooinIM",
      "display_url" : "1.usa.gov\/ooinIM"
    } ]
  },
  "geo" : { },
  "id_str" : "105758291061256192",
  "text" : ".@RayLaHood visits the #Illinois State Fair: livestock competitions, giant butter cow, roundtable discussion: http:\/\/t.co\/giRSq3g",
  "id" : 105758291061256192,
  "created_at" : "2011-08-22 21:48:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hurricane",
      "indices" : [ 34, 44 ]
    }, {
      "text" : "Irene",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/17ACyU4",
      "expanded_url" : "http:\/\/go.usa.gov\/kIq",
      "display_url" : "go.usa.gov\/kIq"
    } ]
  },
  "geo" : { },
  "id_str" : "105737345684357120",
  "text" : "RT @fema: Aug 22: Video update on #hurricane #Irene \u2013 What we\u2019re doing, & where to find info on getting prepared http:\/\/t.co\/17ACyU4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hurricane",
        "indices" : [ 24, 34 ]
      }, {
        "text" : "Irene",
        "indices" : [ 35, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 122 ],
        "url" : "http:\/\/t.co\/17ACyU4",
        "expanded_url" : "http:\/\/go.usa.gov\/kIq",
        "display_url" : "go.usa.gov\/kIq"
      } ]
    },
    "geo" : { },
    "id_str" : "105702998872817664",
    "text" : "Aug 22: Video update on #hurricane #Irene \u2013 What we\u2019re doing, & where to find info on getting prepared http:\/\/t.co\/17ACyU4",
    "id" : 105702998872817664,
    "created_at" : "2011-08-22 18:08:53 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 105737345684357120,
  "created_at" : "2011-08-22 20:25:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/Ou73KOF",
      "expanded_url" : "http:\/\/1.usa.gov\/pClwQm",
      "display_url" : "1.usa.gov\/pClwQm"
    } ]
  },
  "geo" : { },
  "id_str" : "105731132779266048",
  "text" : "\"Finally, the Libyan people: Your courage & character have been unbreakable in the face of a tyrant\" -Pres Obama http:\/\/t.co\/Ou73KOF",
  "id" : 105731132779266048,
  "created_at" : "2011-08-22 20:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105729506316263424",
  "text" : "President Obama on #Libya: The Qaddafi regime is coming to an end, and the future of Libya is in the hands of its people.",
  "id" : 105729506316263424,
  "created_at" : "2011-08-22 19:54:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 90 ],
      "url" : "http:\/\/t.co\/Uiy95hC",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "105706890385817600",
  "text" : "Happening now: President Obama makes a statement on Libya. Live audio: http:\/\/t.co\/Uiy95hC",
  "id" : 105706890385817600,
  "created_at" : "2011-08-22 18:24:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "U.S. FDA",
      "screen_name" : "US_FDA",
      "indices" : [ 101, 108 ],
      "id_str" : "208120290",
      "id" : 208120290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http:\/\/t.co\/hPG2B3K",
      "expanded_url" : "http:\/\/go.usa.gov\/k8F",
      "display_url" : "go.usa.gov\/k8F"
    } ]
  },
  "geo" : { },
  "id_str" : "105663124719403010",
  "text" : "RT @SBAgov: New blog from Administrator Mills on FDA programs for entrepreneurs: http:\/\/t.co\/hPG2B3K @US_FDA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. FDA",
        "screen_name" : "US_FDA",
        "indices" : [ 89, 96 ],
        "id_str" : "208120290",
        "id" : 208120290
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 88 ],
        "url" : "http:\/\/t.co\/hPG2B3K",
        "expanded_url" : "http:\/\/go.usa.gov\/k8F",
        "display_url" : "go.usa.gov\/k8F"
      } ]
    },
    "geo" : { },
    "id_str" : "105655487231574016",
    "text" : "New blog from Administrator Mills on FDA programs for entrepreneurs: http:\/\/t.co\/hPG2B3K @US_FDA",
    "id" : 105655487231574016,
    "created_at" : "2011-08-22 15:00:05 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 105663124719403010,
  "created_at" : "2011-08-22 15:30:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/GRm8yCK",
      "expanded_url" : "http:\/\/1.usa.gov\/pdG5XP",
      "display_url" : "1.usa.gov\/pdG5XP"
    } ]
  },
  "geo" : { },
  "id_str" : "105640844106792962",
  "text" : "\"The future of #Libya is now in the hands of the Libyan people.\" -President Obama - Full statement: http:\/\/t.co\/GRm8yCK",
  "id" : 105640844106792962,
  "created_at" : "2011-08-22 14:01:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countrybeforeparty",
      "indices" : [ 114, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http:\/\/t.co\/XIpvzO5",
      "expanded_url" : "http:\/\/youtu.be\/vIiZOTCwhNY",
      "display_url" : "youtu.be\/vIiZOTCwhNY"
    } ]
  },
  "geo" : { },
  "id_str" : "105431832492904449",
  "text" : "\"If we can come together, there\u2019s no stopping the United States of America\" -President Obama: http:\/\/t.co\/XIpvzO5 #countrybeforeparty",
  "id" : 105431832492904449,
  "created_at" : "2011-08-22 00:11:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countrybeforeparty",
      "indices" : [ 82, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/XIpvzO5",
      "expanded_url" : "http:\/\/youtu.be\/vIiZOTCwhNY",
      "display_url" : "youtu.be\/vIiZOTCwhNY"
    } ]
  },
  "geo" : { },
  "id_str" : "105301660254998528",
  "text" : "President Obama speaks on getting America back to work & calls on Congress to put #countrybeforeparty from Alpha, IL: http:\/\/t.co\/XIpvzO5",
  "id" : 105301660254998528,
  "created_at" : "2011-08-21 15:34:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VPinAsia",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105296687521742850",
  "text" : "RT @VP: Hope my visit can serve as a step toward those goals and toward strengthening our bond. -- VP #VPinAsia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VPinAsia",
        "indices" : [ 94, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "105119485916229633",
    "text" : "Hope my visit can serve as a step toward those goals and toward strengthening our bond. -- VP #VPinAsia",
    "id" : 105119485916229633,
    "created_at" : "2011-08-21 03:30:13 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 105296687521742850,
  "created_at" : "2011-08-21 15:14:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VPinAsia",
      "indices" : [ 53, 62 ]
    }, {
      "text" : "immigration",
      "indices" : [ 64, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/6QFbOWR",
      "expanded_url" : "http:\/\/1.usa.gov\/pSK5sT",
      "display_url" : "1.usa.gov\/pSK5sT"
    } ]
  },
  "geo" : { },
  "id_str" : "104679903038939136",
  "text" : "WH Weekly Wrap Up: On the Road -- a rural road trip, #VPinAsia, #immigration update, Super Bowl champs & more: http:\/\/t.co\/6QFbOWR",
  "id" : 104679903038939136,
  "created_at" : "2011-08-19 22:23:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 73 ],
      "url" : "http:\/\/t.co\/ZCq5P2t",
      "expanded_url" : "http:\/\/1.usa.gov\/nrogPO",
      "display_url" : "1.usa.gov\/nrogPO"
    }, {
      "indices" : [ 99, 118 ],
      "url" : "http:\/\/t.co\/PeXb7Dc",
      "expanded_url" : "http:\/\/www.wh.gov\/internships",
      "display_url" : "wh.gov\/internships"
    } ]
  },
  "geo" : { },
  "id_str" : "104647498689294337",
  "text" : "White House Internship Program -- Blog on experience: http:\/\/t.co\/ZCq5P2t Spring 2012 application: http:\/\/t.co\/PeXb7Dc",
  "id" : 104647498689294337,
  "created_at" : "2011-08-19 20:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http:\/\/t.co\/t5886r2",
      "expanded_url" : "https:\/\/bit.ly\/rjNroo",
      "display_url" : "bit.ly\/rjNroo"
    } ]
  },
  "geo" : { },
  "id_str" : "104643376456007680",
  "text" : "RT @petesouza: New behind-the-scenes photos of the Prez and First Lady from July: http:\/\/t.co\/t5886r2",
  "id" : 104643376456007680,
  "created_at" : "2011-08-19 19:58:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Gregg Koger",
      "screen_name" : "SusanGKoger",
      "indices" : [ 46, 58 ],
      "id_str" : "14926116",
      "id" : 14926116
    }, {
      "name" : "Sitting Around",
      "screen_name" : "sittingaroundco",
      "indices" : [ 59, 75 ],
      "id_str" : "230509175",
      "id" : 230509175
    }, {
      "name" : "DevilWash",
      "screen_name" : "DevilWash",
      "indices" : [ 76, 86 ],
      "id_str" : "26601402",
      "id" : 26601402
    }, {
      "name" : "Kwanza Fisher",
      "screen_name" : "KwanzaTweets",
      "indices" : [ 103, 116 ],
      "id_str" : "181994318",
      "id" : 181994318
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    }, {
      "text" : "WHChamps",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104618029115117568",
  "text" : "#FF #WHChamps of Change: Young Entrepreneurs: @susangkoger @sittingaroundco @devilwash @toryablanchard @KwanzaTweets @dropthechalk",
  "id" : 104618029115117568,
  "created_at" : "2011-08-19 18:17:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fourOsix",
      "screen_name" : "fourosix",
      "indices" : [ 46, 55 ],
      "id_str" : "31290648",
      "id" : 31290648
    }, {
      "name" : "Venture for America",
      "screen_name" : "venture4america",
      "indices" : [ 56, 72 ],
      "id_str" : "109937844",
      "id" : 109937844
    }, {
      "name" : "Josh Linkner",
      "screen_name" : "joshlinkner",
      "indices" : [ 73, 85 ],
      "id_str" : "41119709",
      "id" : 41119709
    }, {
      "name" : "Jennifer Donogh",
      "screen_name" : "jenniferdonogh",
      "indices" : [ 86, 101 ],
      "id_str" : "15923638",
      "id" : 15923638
    }, {
      "name" : "margorita sivaeva",
      "screen_name" : "MargoritaS",
      "indices" : [ 102, 113 ],
      "id_str" : "545013512",
      "id" : 545013512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    }, {
      "text" : "WHChamps",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/uBakhyE",
      "expanded_url" : "http:\/\/1.usa.gov\/p6LO0A",
      "display_url" : "1.usa.gov\/p6LO0A"
    } ]
  },
  "geo" : { },
  "id_str" : "104616733804986368",
  "text" : "#FF #WHChamps of Change: Young Entrepreneurs: @fourosix @venture4america @joshlinkner @jenniferdonogh @marGOritas http:\/\/t.co\/uBakhyE",
  "id" : 104616733804986368,
  "created_at" : "2011-08-19 18:12:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 12, 15 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VPinAsia",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/ydyBMd4",
      "expanded_url" : "http:\/\/youtu.be\/4kLBd8lwJDo",
      "display_url" : "youtu.be\/4kLBd8lwJDo"
    } ]
  },
  "geo" : { },
  "id_str" : "104605099770388480",
  "text" : "Watch this: @VP Joe Biden talks about his meetings in China: http:\/\/t.co\/ydyBMd4 #VPinAsia",
  "id" : 104605099770388480,
  "created_at" : "2011-08-19 17:26:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA darFarsi",
      "screen_name" : "USAdarFarsi",
      "indices" : [ 3, 15 ],
      "id_str" : "251633354",
      "id" : 251633354
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 115, 126 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104599239144898560",
  "text" : "RT @USAdarFarsi: \u0627\u0648\u0628\u0627\u0645\u0627: \u0648\u0642\u062A \u0622\u0646 \u0627\u0633\u062A \u06A9\u0647 \u0645\u0631\u062F\u0645 \u0633\u0648\u0631\u06CC\u0647 \u0622\u06CC\u0646\u062F\u0647 \u062E\u0648\u062F \u0631\u0627 \u0631\u0642\u0645 \u0628\u0632\u0646\u0646\u062F \u0648 \u0645\u0627 \u0647\u0645\u0686\u0646\u0627\u0646 \u0645\u062D\u06A9\u0645 \u062F\u0631\u06A9\u0646\u0627\u0631\u0622\u0646\u0647\u0627 \u062E\u0648\u0627\u0647\u06CC\u0645 \u0627\u06CC\u0633\u062A\u0627\u062F @whitehouse #Syria ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 98, 109 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 110, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 136 ],
        "url" : "http:\/\/t.co\/iAK61rm",
        "expanded_url" : "http:\/\/goo.gl\/JleQK",
        "display_url" : "goo.gl\/JleQK"
      } ]
    },
    "geo" : { },
    "id_str" : "104213428108918785",
    "text" : "\u0627\u0648\u0628\u0627\u0645\u0627: \u0648\u0642\u062A \u0622\u0646 \u0627\u0633\u062A \u06A9\u0647 \u0645\u0631\u062F\u0645 \u0633\u0648\u0631\u06CC\u0647 \u0622\u06CC\u0646\u062F\u0647 \u062E\u0648\u062F \u0631\u0627 \u0631\u0642\u0645 \u0628\u0632\u0646\u0646\u062F \u0648 \u0645\u0627 \u0647\u0645\u0686\u0646\u0627\u0646 \u0645\u062D\u06A9\u0645 \u062F\u0631\u06A9\u0646\u0627\u0631\u0622\u0646\u0647\u0627 \u062E\u0648\u0627\u0647\u06CC\u0645 \u0627\u06CC\u0633\u062A\u0627\u062F @whitehouse #Syria http:\/\/t.co\/iAK61rm",
    "id" : 104213428108918785,
    "created_at" : "2011-08-18 15:29:52 +0000",
    "user" : {
      "name" : "USA darFarsi",
      "screen_name" : "USAdarFarsi",
      "protected" : false,
      "id_str" : "251633354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476387055849594880\/bhbFFBzR_normal.jpeg",
      "id" : 251633354,
      "verified" : true
    }
  },
  "id" : 104599239144898560,
  "created_at" : "2011-08-19 17:02:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Green Bay Packers",
      "screen_name" : "packers",
      "indices" : [ 35, 43 ],
      "id_str" : "35865630",
      "id" : 35865630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Minnesota",
      "indices" : [ 85, 95 ]
    }, {
      "text" : "Iowa",
      "indices" : [ 96, 101 ]
    }, {
      "text" : "Illinois",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/ZZV5G3d",
      "expanded_url" : "http:\/\/youtu.be\/r8LsvlVD8dE",
      "display_url" : "youtu.be\/r8LsvlVD8dE"
    } ]
  },
  "geo" : { },
  "id_str" : "104583894778642433",
  "text" : "New West Wing Week: Obama welcomes @packers to the WH & embarks on a bus tour across #Minnesota #Iowa & #Illinois: http:\/\/t.co\/ZZV5G3d",
  "id" : 104583894778642433,
  "created_at" : "2011-08-19 16:01:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104578386692812800",
  "text" : "RT @jesseclee44: Infographic: Avg wait for circuit judge confirmation post-committee: Bush 29 days, Obama 151. Much more: http:\/\/t.co\/WF ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jesseclee44\/status\/104575920676945921\/photo\/1",
        "indices" : [ 105, 124 ],
        "url" : "http:\/\/t.co\/WFkh2Xf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AXOHPuxCQAEvZfx.jpg",
        "id_str" : "104575920681140225",
        "id" : 104575920681140225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXOHPuxCQAEvZfx.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 195
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 586
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 343
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 586
        } ],
        "display_url" : "pic.twitter.com\/WFkh2Xf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104575920676945921",
    "text" : "Infographic: Avg wait for circuit judge confirmation post-committee: Bush 29 days, Obama 151. Much more: http:\/\/t.co\/WFkh2Xf",
    "id" : 104575920676945921,
    "created_at" : "2011-08-19 15:30:17 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 104578386692812800,
  "created_at" : "2011-08-19 15:40:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 3, 18 ],
      "id_str" : "211921304",
      "id" : 211921304
    }, {
      "name" : "IncMagazine",
      "screen_name" : "IncMagazine",
      "indices" : [ 29, 41 ],
      "id_str" : "476158046",
      "id" : 476158046
    }, {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 46, 53 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startupamerica",
      "indices" : [ 89, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104560032733077504",
  "text" : "RT @startupamerica: Q&A with @IncMagazine and @SBAgov Chief Karen Mills http:\/\/ar.gy\/XnC #startupamerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reach.me\" rel=\"nofollow\"\u003EReach.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IncMagazine",
        "screen_name" : "IncMagazine",
        "indices" : [ 9, 21 ],
        "id_str" : "476158046",
        "id" : 476158046
      }, {
        "name" : "SBA",
        "screen_name" : "SBAgov",
        "indices" : [ 26, 33 ],
        "id_str" : "153149305",
        "id" : 153149305
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "startupamerica",
        "indices" : [ 69, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104558326750253056",
    "text" : "Q&A with @IncMagazine and @SBAgov Chief Karen Mills http:\/\/ar.gy\/XnC #startupamerica",
    "id" : 104558326750253056,
    "created_at" : "2011-08-19 14:20:22 +0000",
    "user" : {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "protected" : false,
      "id_str" : "211921304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1362197801\/120X120_ICON_normal.png",
      "id" : 211921304,
      "verified" : false
    }
  },
  "id" : 104560032733077504,
  "created_at" : "2011-08-19 14:27:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104293200998567937",
  "text" : "Your input really matters to us; there is a lot of work ahead to implement these laws well and to pass a reform that works. Thanks - Cecilia",
  "id" : 104293200998567937,
  "created_at" : "2011-08-18 20:46:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FELIPE BELTRAN",
      "screen_name" : "WBCHAMPION1",
      "indices" : [ 1, 13 ],
      "id_str" : "364664893",
      "id" : 364664893
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104292942923046912",
  "text" : ".@WBCHAMPION1 There is no general process for work permits.  Some people whose deportations are suspended may qualify, some may not. #whchat",
  "id" : 104292942923046912,
  "created_at" : "2011-08-18 20:45:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Ortega",
      "screen_name" : "MattOrtega",
      "indices" : [ 1, 12 ],
      "id_str" : "6751172",
      "id" : 6751172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 60, 72 ]
    }, {
      "text" : "whchat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/9hk66qN",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/rss_viewer\/immigration_blueprint.pdf",
      "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104292031337201664",
  "text" : ".@MattOrtega Totally agree. The real solution is passing an #immigration reform. We need partners in Congress! http:\/\/t.co\/9hk66qN #whchat",
  "id" : 104292031337201664,
  "created_at" : "2011-08-18 20:42:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Ortega",
      "screen_name" : "MattOrtega",
      "indices" : [ 3, 14 ],
      "id_str" : "6751172",
      "id" : 6751172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104291434525495297",
  "text" : "RT @MattOrtega: 300k reviews is nothing to sneeze at. \"Progress but not enough.\" Others can't even see that and just exclaim \"outrage!\"  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 120, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104290623825248256",
    "text" : "300k reviews is nothing to sneeze at. \"Progress but not enough.\" Others can't even see that and just exclaim \"outrage!\" #whchat",
    "id" : 104290623825248256,
    "created_at" : "2011-08-18 20:36:37 +0000",
    "user" : {
      "name" : "Matt Ortega",
      "screen_name" : "MattOrtega",
      "protected" : false,
      "id_str" : "6751172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607997342915117057\/8_0ohfFp_normal.png",
      "id" : 6751172,
      "verified" : false
    }
  },
  "id" : 104291434525495297,
  "created_at" : "2011-08-18 20:39:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javier Morillo",
      "screen_name" : "javimorillo",
      "indices" : [ 1, 13 ],
      "id_str" : "14482396",
      "id" : 14482396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104291181860622336",
  "text" : ".@javimorillo They adopted a strategy and it is having impact. ICE has increased criminal deportations 70%. This will help focus further.",
  "id" : 104291181860622336,
  "created_at" : "2011-08-18 20:38:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Javier Morillo",
      "screen_name" : "javimorillo",
      "indices" : [ 3, 15 ],
      "id_str" : "14482396",
      "id" : 14482396
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104290648445825025",
  "text" : "RT @javimorillo: @whitehouse Do you have confidence ICE will implement new administration policy? #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 81, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104289719885639680",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Do you have confidence ICE will implement new administration policy? #whchat",
    "id" : 104289719885639680,
    "created_at" : "2011-08-18 20:33:01 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Javier Morillo",
      "screen_name" : "javimorillo",
      "protected" : false,
      "id_str" : "14482396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729181368454774784\/RanQ90oD_normal.jpg",
      "id" : 14482396,
      "verified" : false
    }
  },
  "id" : 104290648445825025,
  "created_at" : "2011-08-18 20:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose E Vera",
      "screen_name" : "jvera15",
      "indices" : [ 1, 9 ],
      "id_str" : "20955170",
      "id" : 20955170
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DREAM",
      "indices" : [ 129, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104290454710927360",
  "text" : ".@jvera15 If they are low priority, it decreases the likelihood that they end up in deportation proceedings. The real fix is the #DREAM Act.",
  "id" : 104290454710927360,
  "created_at" : "2011-08-18 20:35:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose E Vera",
      "screen_name" : "jvera15",
      "indices" : [ 3, 11 ],
      "id_str" : "20955170",
      "id" : 20955170
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DREAMACT",
      "indices" : [ 52, 61 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104290072777601024",
  "text" : "RT @jvera15: So this new policy changes nothing for #DREAMACT students that are not in deportation proceedings? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DREAMACT",
        "indices" : [ 39, 48 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104288679828275201",
    "text" : "So this new policy changes nothing for #DREAMACT students that are not in deportation proceedings? #WHChat",
    "id" : 104288679828275201,
    "created_at" : "2011-08-18 20:28:53 +0000",
    "user" : {
      "name" : "Jose E Vera",
      "screen_name" : "jvera15",
      "protected" : false,
      "id_str" : "20955170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719712824566501376\/Lc1ked0f_normal.jpg",
      "id" : 20955170,
      "verified" : false
    }
  },
  "id" : 104290072777601024,
  "created_at" : "2011-08-18 20:34:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nerdrassil",
      "screen_name" : "writegray",
      "indices" : [ 1, 11 ],
      "id_str" : "70813707",
      "id" : 70813707
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/RcJQsaU",
      "expanded_url" : "http:\/\/www.ice.gov\/doclib\/secure-communities\/pdf\/prosecutorial-discretion-memo.pdf",
      "display_url" : "ice.gov\/doclib\/secure-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "104289737774342144",
  "text" : ".@writegray: You can see the priorities DHS is using to clear out the caseload here: http:\/\/t.co\/RcJQsaU #whchat",
  "id" : 104289737774342144,
  "created_at" : "2011-08-18 20:33:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104288861919772672",
  "text" : "@Ivan_Garcia_214: To make any changes like that, we need partners in Congress to help us reform the #immigration law - a priority for us.",
  "id" : 104288861919772672,
  "created_at" : "2011-08-18 20:29:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Antonio Vargas",
      "screen_name" : "joseiswriting",
      "indices" : [ 1, 15 ],
      "id_str" : "15956067",
      "id" : 15956067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104288064230268929",
  "text" : ".@joseiswriting (2of2) impt to understand there's no affirmative process for people to apply for. For that we need imm reform in Congress.",
  "id" : 104288064230268929,
  "created_at" : "2011-08-18 20:26:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Antonio Vargas",
      "screen_name" : "joseiswriting",
      "indices" : [ 1, 15 ],
      "id_str" : "15956067",
      "id" : 15956067
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104287782654066689",
  "text" : ".@joseiswriting: (1 of 2) We're clearing out the caseload to make room for high priority cases & keeping low priorities out of the caseload.",
  "id" : 104287782654066689,
  "created_at" : "2011-08-18 20:25:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jose Antonio Vargas",
      "screen_name" : "joseiswriting",
      "indices" : [ 3, 17 ],
      "id_str" : "15956067",
      "id" : 15956067
    }, {
      "name" : "Define American",
      "screen_name" : "DefineAmerican",
      "indices" : [ 125, 140 ],
      "id_str" : "297042983",
      "id" : 297042983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 100, 112 ]
    }, {
      "text" : "dreamact",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104287114727923712",
  "text" : "RT @joseiswriting: question: so you'd have to be in deportation proceeding to get temporary status? #immigration, #dreamact, @defineamerican",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Define American",
        "screen_name" : "DefineAmerican",
        "indices" : [ 106, 121 ],
        "id_str" : "297042983",
        "id" : 297042983
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigration",
        "indices" : [ 81, 93 ]
      }, {
        "text" : "dreamact",
        "indices" : [ 95, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104284697529552896",
    "text" : "question: so you'd have to be in deportation proceeding to get temporary status? #immigration, #dreamact, @defineamerican",
    "id" : 104284697529552896,
    "created_at" : "2011-08-18 20:13:04 +0000",
    "user" : {
      "name" : "Jose Antonio Vargas",
      "screen_name" : "joseiswriting",
      "protected" : false,
      "id_str" : "15956067",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757233757313048576\/1M_uZ0ss_normal.jpg",
      "id" : 15956067,
      "verified" : true
    }
  },
  "id" : 104287114727923712,
  "created_at" : "2011-08-18 20:22:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Michael McLeod",
      "screen_name" : "CMichaelMcLeod",
      "indices" : [ 1, 16 ],
      "id_str" : "341794240",
      "id" : 341794240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104286805557383168",
  "text" : ".@CMichaelMcLeod: Couldn't agree more; today's news doesn't provide permanent status for anyone. We need partners in Congress & a bill.",
  "id" : 104286805557383168,
  "created_at" : "2011-08-18 20:21:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104286090680221696",
  "text" : "This is Cecilia, ready to answer questions #whchat",
  "id" : 104286090680221696,
  "created_at" : "2011-08-18 20:18:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 56, 68 ]
    }, {
      "text" : "whchat",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/ZUV2GQJ",
      "expanded_url" : "http:\/\/1.usa.gov\/qLPiIM",
      "display_url" : "1.usa.gov\/qLPiIM"
    } ]
  },
  "geo" : { },
  "id_str" : "104274001613946880",
  "text" : "Office Hours @ 4:15ET: Cecilia Mu\u00F1oz answers your Qs on #immigration update to focus resources - ask w\/ #whchat: http:\/\/t.co\/ZUV2GQJ",
  "id" : 104274001613946880,
  "created_at" : "2011-08-18 19:30:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Immigration",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "whchat",
      "indices" : [ 127, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 94 ],
      "url" : "http:\/\/t.co\/ZUV2GQJ",
      "expanded_url" : "http:\/\/1.usa.gov\/qLPiIM",
      "display_url" : "1.usa.gov\/qLPiIM"
    } ]
  },
  "geo" : { },
  "id_str" : "104272099195109376",
  "text" : "#Immigration update: maximizing public safety & better focusing resources: http:\/\/t.co\/ZUV2GQJ Have Qs on new strategy? Ask w\/ #whchat",
  "id" : 104272099195109376,
  "created_at" : "2011-08-18 19:23:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/104209687632814080\/photo\/1",
      "indices" : [ 108, 127 ],
      "url" : "http:\/\/t.co\/zrhxjjX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AXI6KKXCIAA46A2.jpg",
      "id_str" : "104209687637008384",
      "id" : 104209687637008384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXI6KKXCIAA46A2.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zrhxjjX"
    } ],
    "hashtags" : [ {
      "text" : "Illinois",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104209687632814080",
  "text" : "Photo of the Day: President Obama about to catch a football w\/ the Galesburg High School team in #Illinois: http:\/\/t.co\/zrhxjjX",
  "id" : 104209687632814080,
  "created_at" : "2011-08-18 15:15:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/vlQjbmb",
      "expanded_url" : "http:\/\/1.usa.gov\/nrtNRYP3",
      "display_url" : "1.usa.gov\/nrtNRYP3"
    } ]
  },
  "geo" : { },
  "id_str" : "104191526988550144",
  "text" : "Obama: It is time for the Syrian people to determine their own destiny & we will continue to stand firmly on their side http:\/\/t.co\/vlQjbmb",
  "id" : 104191526988550144,
  "created_at" : "2011-08-18 14:02:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "syria",
      "indices" : [ 127, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/5W1vEP3",
      "expanded_url" : "http:\/\/1.usa.gov\/qRmgLQ",
      "display_url" : "1.usa.gov\/qRmgLQ"
    } ]
  },
  "geo" : { },
  "id_str" : "104186235836309504",
  "text" : "President Obama: \"For the sake of the Syrian people, the time has come for President Assad to step aside.\" http:\/\/t.co\/5W1vEP3 #syria",
  "id" : 104186235836309504,
  "created_at" : "2011-08-18 13:41:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Amb Gary Locke",
      "screen_name" : "AmbLocke",
      "indices" : [ 64, 73 ],
      "id_str" : "76936279",
      "id" : 76936279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104181339972050944",
  "text" : "RT @VP: PHOTO: After mtg w\/Chinese VP Xi, VP Biden had lunch w\/ @AmbLocke @ Chao Ganr, restaurant near Drum&Bell Tower Beijing http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amb Gary Locke",
        "screen_name" : "AmbLocke",
        "indices" : [ 56, 65 ],
        "id_str" : "76936279",
        "id" : 76936279
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/104129222045474816\/photo\/1",
        "indices" : [ 119, 138 ],
        "url" : "http:\/\/t.co\/q3DSbyY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AXHw-csCIAA18-n.jpg",
        "id_str" : "104129222049669120",
        "id" : 104129222049669120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXHw-csCIAA18-n.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/q3DSbyY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104129222045474816",
    "text" : "PHOTO: After mtg w\/Chinese VP Xi, VP Biden had lunch w\/ @AmbLocke @ Chao Ganr, restaurant near Drum&Bell Tower Beijing http:\/\/t.co\/q3DSbyY",
    "id" : 104129222045474816,
    "created_at" : "2011-08-18 09:55:16 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 104181339972050944,
  "created_at" : "2011-08-18 13:22:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/103981300196708352\/photo\/1",
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/HVwOKOf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AXFqcQ3CEAARVnj.png",
      "id_str" : "103981300200902656",
      "id" : 103981300200902656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXFqcQ3CEAARVnj.png",
      "sizes" : [ {
        "h" : 187,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 100,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 187,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 177,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HVwOKOf"
    } ],
    "hashtags" : [ {
      "text" : "whweb",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103984441126420480",
  "text" : "RT @macon44: new feature asks website visitors for feedback about how wh.gov can improve; we keep an eye on #whweb too http:\/\/t.co\/HVwOKOf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/103981300196708352\/photo\/1",
        "indices" : [ 106, 125 ],
        "url" : "http:\/\/t.co\/HVwOKOf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AXFqcQ3CEAARVnj.png",
        "id_str" : "103981300200902656",
        "id" : 103981300200902656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXFqcQ3CEAARVnj.png",
        "sizes" : [ {
          "h" : 187,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 100,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 187,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HVwOKOf"
      } ],
      "hashtags" : [ {
        "text" : "whweb",
        "indices" : [ 95, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103981300196708352",
    "text" : "new feature asks website visitors for feedback about how wh.gov can improve; we keep an eye on #whweb too http:\/\/t.co\/HVwOKOf",
    "id" : 103981300196708352,
    "created_at" : "2011-08-18 00:07:28 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 103984441126420480,
  "created_at" : "2011-08-18 00:19:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 29, 40 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 53, 62 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countrybeforeparty",
      "indices" : [ 8, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/LCIoveV",
      "expanded_url" : "http:\/\/1.usa.gov\/qI0T44",
      "display_url" : "1.usa.gov\/qI0T44"
    } ]
  },
  "geo" : { },
  "id_str" : "103979391691919360",
  "text" : "Putting #countrybeforeparty: @pfeiffer44 responds to @USATODAY op-ed by Republicans in Congress: http:\/\/t.co\/LCIoveV",
  "id" : 103979391691919360,
  "created_at" : "2011-08-17 23:59:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "economy",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 105 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    }, {
      "indices" : [ 112, 131 ],
      "url" : "http:\/\/t.co\/RFX8sAu",
      "expanded_url" : "https:\/\/apps.facebook.com\/whitehouselive\/",
      "display_url" : "apps.facebook.com\/whitehouselive\/"
    } ]
  },
  "geo" : { },
  "id_str" : "103947442579443712",
  "text" : "Happening now: President Obama's town hall on the #economy in Alpha, IL. Watch on wh: http:\/\/t.co\/hOlVdV1 & fb: http:\/\/t.co\/RFX8sAu",
  "id" : 103947442579443712,
  "created_at" : "2011-08-17 21:52:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103942451584188416",
  "text" : "RT @HHSGov: Having trouble understanding your coverage? Soon, you will have a new tool that gives you clear info about your plan. http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 137 ],
        "url" : "http:\/\/t.co\/ZPGud5e",
        "expanded_url" : "http:\/\/1.usa.gov\/oVQdEB",
        "display_url" : "1.usa.gov\/oVQdEB"
      } ]
    },
    "geo" : { },
    "id_str" : "103857977219485696",
    "text" : "Having trouble understanding your coverage? Soon, you will have a new tool that gives you clear info about your plan. http:\/\/t.co\/ZPGud5e",
    "id" : 103857977219485696,
    "created_at" : "2011-08-17 15:57:26 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 103942451584188416,
  "created_at" : "2011-08-17 21:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "economy",
      "indices" : [ 69, 77 ]
    }, {
      "text" : "Illinois",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "103921317375524864",
  "text" : "Happening @ 4:30ET: President Obama holds a town hall meeting on the #economy in Alpha, #Illinois. Watch: http:\/\/t.co\/hOlVdV1",
  "id" : 103921317375524864,
  "created_at" : "2011-08-17 20:09:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "economy",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/dqUPQNt",
      "expanded_url" : "http:\/\/1.usa.gov\/oVcNvf",
      "display_url" : "1.usa.gov\/oVcNvf"
    } ]
  },
  "geo" : { },
  "id_str" : "103910508364705792",
  "text" : "Photo Gallery: President Obama's bus tour on the #economy so far. See days 1 & 2 through MN & IA: http:\/\/t.co\/dqUPQNt",
  "id" : 103910508364705792,
  "created_at" : "2011-08-17 19:26:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Mission to the UN",
      "screen_name" : "USUN",
      "indices" : [ 3, 8 ],
      "id_str" : "249677516",
      "id" : 249677516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 131 ],
      "url" : "http:\/\/t.co\/Ctyoq2A",
      "expanded_url" : "http:\/\/bit.ly\/mRnraj",
      "display_url" : "bit.ly\/mRnraj"
    } ]
  },
  "geo" : { },
  "id_str" : "103891012400844800",
  "text" : "RT @USUN: World Humanitarian Day is Friday August 19. Volunteer your knowledge, skills and ideas to help others http:\/\/t.co\/Ctyoq2A  #WH ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHD2011",
        "indices" : [ 123, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 121 ],
        "url" : "http:\/\/t.co\/Ctyoq2A",
        "expanded_url" : "http:\/\/bit.ly\/mRnraj",
        "display_url" : "bit.ly\/mRnraj"
      } ]
    },
    "geo" : { },
    "id_str" : "103881539812728832",
    "text" : "World Humanitarian Day is Friday August 19. Volunteer your knowledge, skills and ideas to help others http:\/\/t.co\/Ctyoq2A  #WHD2011",
    "id" : 103881539812728832,
    "created_at" : "2011-08-17 17:31:03 +0000",
    "user" : {
      "name" : "US Mission to the UN",
      "screen_name" : "USUN",
      "protected" : false,
      "id_str" : "249677516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616236749149241345\/Dm-anuiC_normal.jpg",
      "id" : 249677516,
      "verified" : true
    }
  },
  "id" : 103891012400844800,
  "created_at" : "2011-08-17 18:08:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    }, {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/RFX8sAu",
      "expanded_url" : "https:\/\/apps.facebook.com\/whitehouselive\/",
      "display_url" : "apps.facebook.com\/whitehouselive\/"
    } ]
  },
  "geo" : { },
  "id_str" : "103869544594014208",
  "text" : "Starting soon: President Obama's town hall meeting in IL. Watch here: http:\/\/t.co\/hOlVdV1 & on Facebook: http:\/\/t.co\/RFX8sAu",
  "id" : 103869544594014208,
  "created_at" : "2011-08-17 16:43:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/BW9zIEa",
      "expanded_url" : "http:\/\/1.usa.gov\/oOqcrU",
      "display_url" : "1.usa.gov\/oOqcrU"
    } ]
  },
  "geo" : { },
  "id_str" : "103861233685508097",
  "text" : "On the last day of his rural tour, President Obama heads to Atkinson, Illinois to meet w\/ locals on the economy: http:\/\/t.co\/BW9zIEa",
  "id" : 103861233685508097,
  "created_at" : "2011-08-17 16:10:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Amb Gary Locke",
      "screen_name" : "AmbLocke",
      "indices" : [ 13, 22 ],
      "id_str" : "76936279",
      "id" : 76936279
    }, {
      "name" : "Georgetown Univ.",
      "screen_name" : "Georgetown",
      "indices" : [ 28, 39 ],
      "id_str" : "7856542",
      "id" : 7856542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103858519916294144",
  "text" : "RT @VP: VP & @AmbLocke wish @Georgetown Hoyas good luck before game vs Shanxi Brave Dragons @ Olympic Sports Center in Beijing http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amb Gary Locke",
        "screen_name" : "AmbLocke",
        "indices" : [ 5, 14 ],
        "id_str" : "76936279",
        "id" : 76936279
      }, {
        "name" : "Georgetown Univ.",
        "screen_name" : "Georgetown",
        "indices" : [ 20, 31 ],
        "id_str" : "7856542",
        "id" : 7856542
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/103856528406220800\/photo\/1",
        "indices" : [ 119, 138 ],
        "url" : "http:\/\/t.co\/ojfpLJY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AXD49luCEAAgO41.jpg",
        "id_str" : "103856528410415104",
        "id" : 103856528410415104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXD49luCEAAgO41.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/ojfpLJY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103856528406220800",
    "text" : "VP & @AmbLocke wish @Georgetown Hoyas good luck before game vs Shanxi Brave Dragons @ Olympic Sports Center in Beijing http:\/\/t.co\/ojfpLJY",
    "id" : 103856528406220800,
    "created_at" : "2011-08-17 15:51:41 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 103858519916294144,
  "created_at" : "2011-08-17 15:59:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/103849918141177856\/photo\/1",
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/35T241F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AXDy80jCIAIw0nk.jpg",
      "id_str" : "103849918141177858",
      "id" : 103849918141177858,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AXDy80jCIAIw0nk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 644
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 644
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/35T241F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103849918141177856",
  "text" : "Photo of the Day: The President talks w\/ people, meets golden retriever @ local antique shop in Le Claire, Iowa: http:\/\/t.co\/35T241F",
  "id" : 103849918141177856,
  "created_at" : "2011-08-17 15:25:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103827940093067265",
  "text" : "RT @pfeiffer44: After Labor Day, POTUS will unveil a pkg of meaningful, new initiatives to grow the economy and create jobs, will push C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103825331261149184",
    "text" : "After Labor Day, POTUS will unveil a pkg of meaningful, new initiatives to grow the economy and create jobs, will push Congress to act",
    "id" : 103825331261149184,
    "created_at" : "2011-08-17 13:47:42 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 103827940093067265,
  "created_at" : "2011-08-17 13:58:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http:\/\/t.co\/CkeBQIq",
      "expanded_url" : "http:\/\/bit.ly\/qeayTZ",
      "display_url" : "bit.ly\/qeayTZ"
    }, {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/V3m6tcy",
      "expanded_url" : "http:\/\/1.usa.gov\/qJYqO7",
      "display_url" : "1.usa.gov\/qJYqO7"
    } ]
  },
  "geo" : { },
  "id_str" : "103600545830420481",
  "text" : "RT @macon44: \"Sometimes there are days in Washington that will drive you crazy...\" http:\/\/t.co\/CkeBQIq http:\/\/t.co\/V3m6tcy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 89 ],
        "url" : "http:\/\/t.co\/CkeBQIq",
        "expanded_url" : "http:\/\/bit.ly\/qeayTZ",
        "display_url" : "bit.ly\/qeayTZ"
      }, {
        "indices" : [ 90, 109 ],
        "url" : "http:\/\/t.co\/V3m6tcy",
        "expanded_url" : "http:\/\/1.usa.gov\/qJYqO7",
        "display_url" : "1.usa.gov\/qJYqO7"
      } ]
    },
    "geo" : { },
    "id_str" : "103598595357417472",
    "text" : "\"Sometimes there are days in Washington that will drive you crazy...\" http:\/\/t.co\/CkeBQIq http:\/\/t.co\/V3m6tcy",
    "id" : 103598595357417472,
    "created_at" : "2011-08-16 22:46:44 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 103600545830420481,
  "created_at" : "2011-08-16 22:54:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 7, 10 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/tnsFn6k",
      "expanded_url" : "http:\/\/1.usa.gov\/nmaNPx",
      "display_url" : "1.usa.gov\/nmaNPx"
    } ]
  },
  "geo" : { },
  "id_str" : "103587063550590978",
  "text" : "Today, @VP Biden departed for Beijing -- the 1st stop on a 9-day Asia tour incl Mongolia & Japan. Follow his trip: http:\/\/t.co\/tnsFn6k",
  "id" : 103587063550590978,
  "created_at" : "2011-08-16 22:00:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 1, 6 ],
      "id_str" : "61853389",
      "id" : 61853389
    }, {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 21, 28 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/BDW3l1V",
      "expanded_url" : "http:\/\/1.usa.gov\/nFOP0m",
      "display_url" : "1.usa.gov\/nFOP0m"
    } ]
  },
  "geo" : { },
  "id_str" : "103573339603349504",
  "text" : ".@USDA Sec Vilsack & @SBAgov Admin Mills on new initiatives to strengthen the rural economy & create jobs: http:\/\/t.co\/BDW3l1V",
  "id" : 103573339603349504,
  "created_at" : "2011-08-16 21:06:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "103553294156300288",
  "text" : "Happening now: President Obama speaks at WH Rural Economic Forum closing session in Peosta, Iowa: http:\/\/t.co\/hOlVdV1",
  "id" : 103553294156300288,
  "created_at" : "2011-08-16 19:46:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SBAgov\/status\/103532410175619072\/photo\/1",
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/YeSDERl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AW_SLbNCAAEIsrh.jpg",
      "id_str" : "103532410175619073",
      "id" : 103532410175619073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AW_SLbNCAAEIsrh.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/YeSDERl"
    } ],
    "hashtags" : [ {
      "text" : "Peosta",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 105 ],
      "url" : "http:\/\/t.co\/PLURGFe",
      "expanded_url" : "http:\/\/go.usa.gov\/kcU",
      "display_url" : "go.usa.gov\/kcU"
    } ]
  },
  "geo" : { },
  "id_str" : "103532667928190976",
  "text" : "RT @SBAgov: So what are SBA Admin Mills & President Obama doing today in #Peosta, IA? http:\/\/t.co\/PLURGFe http:\/\/t.co\/YeSDERl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SBAgov\/status\/103532410175619072\/photo\/1",
        "indices" : [ 94, 113 ],
        "url" : "http:\/\/t.co\/YeSDERl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AW_SLbNCAAEIsrh.jpg",
        "id_str" : "103532410175619073",
        "id" : 103532410175619073,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AW_SLbNCAAEIsrh.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/YeSDERl"
      } ],
      "hashtags" : [ {
        "text" : "Peosta",
        "indices" : [ 61, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 93 ],
        "url" : "http:\/\/t.co\/PLURGFe",
        "expanded_url" : "http:\/\/go.usa.gov\/kcU",
        "display_url" : "go.usa.gov\/kcU"
      } ]
    },
    "geo" : { },
    "id_str" : "103532410175619072",
    "text" : "So what are SBA Admin Mills & President Obama doing today in #Peosta, IA? http:\/\/t.co\/PLURGFe http:\/\/t.co\/YeSDERl",
    "id" : 103532410175619072,
    "created_at" : "2011-08-16 18:23:45 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 103532667928190976,
  "created_at" : "2011-08-16 18:24:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "103512575207145472",
  "text" : "Happening now: President Obama opens the WH Rural Economic Forum @ NE Iowa Community College in Peosta: http:\/\/t.co\/hOlVdV1",
  "id" : 103512575207145472,
  "created_at" : "2011-08-16 17:04:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 56, 59 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103506686626631680",
  "text" : "RT @VP: VP is wheels up en route Beijing; stay tuned to @VP for updates & coverage of VP's 9-day trip to China, Mongolia and Japan; #VPi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 48, 51 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VPinAsia",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "103504474198388736",
    "text" : "VP is wheels up en route Beijing; stay tuned to @VP for updates & coverage of VP's 9-day trip to China, Mongolia and Japan; #VPinAsia",
    "id" : 103504474198388736,
    "created_at" : "2011-08-16 16:32:44 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 103506686626631680,
  "created_at" : "2011-08-16 16:41:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/103501893195661312\/photo\/1",
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/s3cotoj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AW-2bGnCAAAhy2p.jpg",
      "id_str" : "103501893199855616",
      "id" : 103501893199855616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AW-2bGnCAAAhy2p.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/s3cotoj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103501893195661312",
  "text" : "Photo of the Day: President Obama waves from the bus in Decorah, Iowa during Midwest economic tour: http:\/\/t.co\/s3cotoj",
  "id" : 103501893195661312,
  "created_at" : "2011-08-16 16:22:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/he8xYx8",
      "expanded_url" : "http:\/\/1.usa.gov\/nt2rte",
      "display_url" : "1.usa.gov\/nt2rte"
    } ]
  },
  "geo" : { },
  "id_str" : "103479618824179712",
  "text" : "This morning, President Obama's economic bus tour pulls into Peosta, Iowa for the WH Rural Economic Forum: http:\/\/t.co\/he8xYx8",
  "id" : 103479618824179712,
  "created_at" : "2011-08-16 14:53:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 3, 14 ],
      "id_str" : "14120151",
      "id" : 14120151
    }, {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 27, 38 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "103261894806212608",
  "text" : "RT @foursquare: Welcome to @foursquare, President Obama! Follow him on foursquare to see where he's checking in and leaving tips: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Foursquare",
        "screen_name" : "Foursquare",
        "indices" : [ 11, 22 ],
        "id_str" : "14120151",
        "id" : 14120151
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 133 ],
        "url" : "http:\/\/t.co\/BRREVsS",
        "expanded_url" : "http:\/\/4sq.com\/WHon4SQ",
        "display_url" : "4sq.com\/WHon4SQ"
      } ]
    },
    "geo" : { },
    "id_str" : "103251340234469376",
    "text" : "Welcome to @foursquare, President Obama! Follow him on foursquare to see where he's checking in and leaving tips: http:\/\/t.co\/BRREVsS",
    "id" : 103251340234469376,
    "created_at" : "2011-08-15 23:46:52 +0000",
    "user" : {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "protected" : false,
      "id_str" : "14120151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776115264291307520\/q5Tp332e_normal.jpg",
      "id" : 14120151,
      "verified" : true
    }
  },
  "id" : 103261894806212608,
  "created_at" : "2011-08-16 00:28:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 11, 22 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 26, 37 ],
      "id_str" : "14120151",
      "id" : 14120151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/NJVv6vf",
      "expanded_url" : "http:\/\/1.usa.gov\/nck3PF",
      "display_url" : "1.usa.gov\/nck3PF"
    } ]
  },
  "geo" : { },
  "id_str" : "103255578507345920",
  "text" : "Announcing @whitehouse on @foursquare: Find tips, keep up w\/ Obama's bus tour, check-in. Follow us: http:\/\/t.co\/NJVv6vf",
  "id" : 103255578507345920,
  "created_at" : "2011-08-16 00:03:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 106 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "103229299867385856",
  "text" : "Happening now: President Obama holds a town hall meeting in Decorah, Iowa. Watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 103229299867385856,
  "created_at" : "2011-08-15 22:19:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 69 ],
      "url" : "http:\/\/t.co\/d9hBMzm",
      "expanded_url" : "http:\/\/1.usa.gov\/pzsHMs",
      "display_url" : "1.usa.gov\/pzsHMs"
    }, {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/oDhbvz5",
      "expanded_url" : "https:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "103222795693072385",
  "text" : "2nd stop on the economic bus tour: Decorah, Iowa: http:\/\/t.co\/d9hBMzm Watch Obama's town hall live @ 6:15ET: http:\/\/t.co\/oDhbvz5",
  "id" : 103222795693072385,
  "created_at" : "2011-08-15 21:53:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 84, 92 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/IejiBd3",
      "expanded_url" : "http:\/\/nyti.ms\/qzo7dr",
      "display_url" : "nyti.ms\/qzo7dr"
    } ]
  },
  "geo" : { },
  "id_str" : "103182675170426880",
  "text" : "In today's town hall in Cannon Falls, MN, President Obama discussed Warren Buffet's @nytimes op-ed: http:\/\/t.co\/IejiBd3",
  "id" : 103182675170426880,
  "created_at" : "2011-08-15 19:14:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "103151389726867456",
  "text" : "Happening now: President Obama holds a Town Hall Meeting in\nCannon Falls, Minnesota. Watch live: http:\/\/t.co\/hOlVdV1",
  "id" : 103151389726867456,
  "created_at" : "2011-08-15 17:09:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bustour",
      "indices" : [ 59, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http:\/\/t.co\/xILK5PN",
      "expanded_url" : "http:\/\/1.usa.gov\/phBCHt",
      "display_url" : "1.usa.gov\/phBCHt"
    }, {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/Zedc7Fs",
      "expanded_url" : "http:\/\/twitpic.com\/66lwdg",
      "display_url" : "twitpic.com\/66lwdg"
    } ]
  },
  "geo" : { },
  "id_str" : "103145384213364736",
  "text" : "Tune in to President Obama's Town Halls during his Midwest #bustour. Live sched: http:\/\/t.co\/xILK5PN Map: http:\/\/t.co\/Zedc7Fs",
  "id" : 103145384213364736,
  "created_at" : "2011-08-15 16:45:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bustour",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http:\/\/t.co\/7Q3biFZ",
      "expanded_url" : "http:\/\/1.usa.gov\/pDi7Mv",
      "display_url" : "1.usa.gov\/pDi7Mv"
    } ]
  },
  "geo" : { },
  "id_str" : "103111223494721537",
  "text" : "President Obama kicks off the economic #bustour in Cannon Falls, Minnesota: http:\/\/t.co\/7Q3biFZ",
  "id" : 103111223494721537,
  "created_at" : "2011-08-15 14:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Green Bay Packers",
      "screen_name" : "packers",
      "indices" : [ 46, 54 ],
      "id_str" : "35865630",
      "id" : 35865630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http:\/\/t.co\/Rw9qHUP",
      "expanded_url" : "http:\/\/1.usa.gov\/mOJatk",
      "display_url" : "1.usa.gov\/mOJatk"
    } ]
  },
  "geo" : { },
  "id_str" : "102853835743170561",
  "text" : "President Obama welcomed Super Bowl XLV Champ @Packers to the White House. Video: http:\/\/t.co\/Rw9qHUP",
  "id" : 102853835743170561,
  "created_at" : "2011-08-14 21:27:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countrybeforeparty",
      "indices" : [ 118, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/IqY6rMm",
      "expanded_url" : "http:\/\/youtu.be\/seIZB6qQEWY",
      "display_url" : "youtu.be\/seIZB6qQEWY"
    } ]
  },
  "geo" : { },
  "id_str" : "102811687048065024",
  "text" : "\"There\u2019s nothing wrong w\/ our country, there is something wrong w\/ our politics\" -President Obama http:\/\/t.co\/IqY6rMm #countrybeforeparty",
  "id" : 102811687048065024,
  "created_at" : "2011-08-14 18:39:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countrybeforeparty",
      "indices" : [ 115, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/IqY6rMm",
      "expanded_url" : "http:\/\/youtu.be\/seIZB6qQEWY",
      "display_url" : "youtu.be\/seIZB6qQEWY"
    } ]
  },
  "geo" : { },
  "id_str" : "102356616820703232",
  "text" : "President Obama believes the American people deserve more than political brinksmanship. Video: http:\/\/t.co\/IqY6rMm #countrybeforeparty",
  "id" : 102356616820703232,
  "created_at" : "2011-08-13 12:31:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/iJyZHEn",
      "expanded_url" : "http:\/\/wh.gov\/reH",
      "display_url" : "wh.gov\/reH"
    } ]
  },
  "geo" : { },
  "id_str" : "102149352545460224",
  "text" : "Weekly Wrap Up: Common Sense Solutions - a quick look back at what happened this week on WhiteHouse.gov: http:\/\/t.co\/iJyZHEn",
  "id" : 102149352545460224,
  "created_at" : "2011-08-12 22:47:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 23, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102101282365509632",
  "text" : "RT @jesseclee44: WH on #hcr: 4 courts found Constitutional, \"strongly disagree w\/ this decision and we are confident it will not stand\"  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcr",
        "indices" : [ 6, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 138 ],
        "url" : "http:\/\/t.co\/acCTLqt",
        "expanded_url" : "http:\/\/wh.gov\/rek",
        "display_url" : "wh.gov\/rek"
      } ]
    },
    "geo" : { },
    "id_str" : "102093982389112832",
    "text" : "WH on #hcr: 4 courts found Constitutional, \"strongly disagree w\/ this decision and we are confident it will not stand\" http:\/\/t.co\/acCTLqt",
    "id" : 102093982389112832,
    "created_at" : "2011-08-12 19:07:56 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 102101282365509632,
  "created_at" : "2011-08-12 19:36:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 3, 11 ],
      "id_str" : "232193350",
      "id" : 232193350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youth",
      "indices" : [ 68, 74 ]
    }, {
      "text" : "youth11",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102094385000361984",
  "text" : "RT @RajShah: Recognizing 2011 Intl Youth Day. What issues matter to #youth in the developing world? Check out http:\/\/t.co\/vEyCknu #youth11",
  "id" : 102094385000361984,
  "created_at" : "2011-08-12 19:09:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Green Bay Packers",
      "screen_name" : "packers",
      "indices" : [ 42, 50 ],
      "id_str" : "35865630",
      "id" : 35865630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/Uiy95hC",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "102066532145840129",
  "text" : "Obama welcomes Super Bowl Champ Green Bay @Packers to the WH to honor their victory & community service. Watch @ 2:35ET http:\/\/t.co\/Uiy95hC",
  "id" : 102066532145840129,
  "created_at" : "2011-08-12 17:18:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MORE Magazine",
      "screen_name" : "MoreMag",
      "indices" : [ 99, 107 ],
      "id_str" : "19774073",
      "id" : 19774073
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Somalia",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "Famine",
      "indices" : [ 9, 16 ]
    }, {
      "text" : "Kenya",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/iTmsIZs",
      "expanded_url" : "http:\/\/bit.ly\/ozhL85",
      "display_url" : "bit.ly\/ozhL85"
    } ]
  },
  "geo" : { },
  "id_str" : "102050705505927169",
  "text" : "#Somalia #Famine: The Lives We Can Save - Comms Director to Dr. Jill Biden reflects on #Kenya trip @moremag: http:\/\/t.co\/iTmsIZs",
  "id" : 102050705505927169,
  "created_at" : "2011-08-12 16:15:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/JqEhYlG",
      "expanded_url" : "http:\/\/youtu.be\/l79jMsjJM5k",
      "display_url" : "youtu.be\/l79jMsjJM5k"
    } ]
  },
  "geo" : { },
  "id_str" : "102014324570198016",
  "text" : "New West Wing Week: Obama announces new initiatives to put vets back to work, new fuel economy standards & more: http:\/\/t.co\/JqEhYlG",
  "id" : 102014324570198016,
  "created_at" : "2011-08-12 13:51:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countrybeforeparty",
      "indices" : [ 92, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101815724024139776",
  "text" : "Today, President Obama called on Congress to \"put country ahead of party.\" RT if you agree. #countrybeforeparty",
  "id" : 101815724024139776,
  "created_at" : "2011-08-12 00:42:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countrybeforeparty",
      "indices" : [ 102, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http:\/\/t.co\/4rZPQa0",
      "expanded_url" : "http:\/\/wh.gov\/rMB",
      "display_url" : "wh.gov\/rMB"
    } ]
  },
  "geo" : { },
  "id_str" : "101777355479064576",
  "text" : "President Obama: \u201CThere\u2019s something wrong with our politics that we need to fix.\u201D http:\/\/t.co\/4rZPQa0 #countrybeforeparty",
  "id" : 101777355479064576,
  "created_at" : "2011-08-11 22:09:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CountrybeforeParty",
      "indices" : [ 97, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101746410046763008",
  "text" : "President Obama called on Congress to \"put country ahead of party\" today in MI. RT if you agree. #CountrybeforeParty",
  "id" : 101746410046763008,
  "created_at" : "2011-08-11 20:06:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Holland",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "Michigan",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101733913419984896",
  "text" : "\"If we can come together \u2013 if we can find common ground \u2013 there is no stopping this country.\" -President Obama in #Holland, #Michigan",
  "id" : 101733913419984896,
  "created_at" : "2011-08-11 19:17:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101732649361616896",
  "text" : "RT @pfeiffer44: POTUS on Congress:The last thing we need is Congress spending more time arguing in DC...They need to spend time out here ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101732027702845442",
    "text" : "POTUS on Congress:The last thing we need is Congress spending more time arguing in DC...They need to spend time out here listening to you",
    "id" : 101732027702845442,
    "created_at" : "2011-08-11 19:09:40 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 101732649361616896,
  "created_at" : "2011-08-11 19:12:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101729800670023680",
  "text" : "RT @pfeiffer44: POTUS in MI: I\u2019ve said it before. I will say it again: Don\u2019t ever bet against the American worker. Don\u2019t ever bet agains ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101728828367437825",
    "text" : "POTUS in MI: I\u2019ve said it before. I will say it again: Don\u2019t ever bet against the American worker. Don\u2019t ever bet against American ingenuity",
    "id" : 101728828367437825,
    "created_at" : "2011-08-11 18:56:57 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 101729800670023680,
  "created_at" : "2011-08-11 19:00:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101714967446822912",
  "text" : "RT @jesseclee44: Obama at advanced battery factory in MI. Fuel effic. standards + investments in advanced vehicle manufacturing=US jobs: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 139 ],
        "url" : "http:\/\/t.co\/Utue1w2",
        "expanded_url" : "http:\/\/wh.gov\/rLh",
        "display_url" : "wh.gov\/rLh"
      } ]
    },
    "geo" : { },
    "id_str" : "101714293262778368",
    "text" : "Obama at advanced battery factory in MI. Fuel effic. standards + investments in advanced vehicle manufacturing=US jobs: http:\/\/t.co\/Utue1w2",
    "id" : 101714293262778368,
    "created_at" : "2011-08-11 17:59:11 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 101714967446822912,
  "created_at" : "2011-08-11 18:01:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ramadan",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/nEx64C5",
      "expanded_url" : "http:\/\/wh.gov\/rLJ",
      "display_url" : "wh.gov\/rLJ"
    } ]
  },
  "geo" : { },
  "id_str" : "101714643252281344",
  "text" : "President Obama hosts an Iftar dinner at the White House to celebrate #Ramadan. Video & remarks: http:\/\/t.co\/nEx64C5",
  "id" : 101714643252281344,
  "created_at" : "2011-08-11 18:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Frist, M.D.",
      "screen_name" : "bfrist",
      "indices" : [ 17, 24 ],
      "id_str" : "5660532",
      "id" : 5660532
    }, {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 27, 35 ],
      "id_str" : "232193350",
      "id" : 232193350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kenya",
      "indices" : [ 66, 72 ]
    }, {
      "text" : "HornofAfrica",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/xMgGik1",
      "expanded_url" : "http:\/\/youtu.be\/CxoL2HOn4XU",
      "display_url" : "youtu.be\/CxoL2HOn4XU"
    } ]
  },
  "geo" : { },
  "id_str" : "101665951094812673",
  "text" : "Video: Dr. Biden @bfrist & @rajshah visit Dadaab refugee camps in #Kenya, highlight need for aid in #HornofAfrica: http:\/\/t.co\/xMgGik1",
  "id" : 101665951094812673,
  "created_at" : "2011-08-11 14:47:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 4, 17 ],
      "id_str" : "121539516",
      "id" : 121539516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/7b0VE2u",
      "expanded_url" : "http:\/\/wh.gov\/rLD",
      "display_url" : "wh.gov\/rLD"
    } ]
  },
  "geo" : { },
  "id_str" : "101650050438008833",
  "text" : "CTO @aneeshchopra on job creation via immigrant entrepreneurship, Silicon Valley's open ecosystem, So-Lo-Mo industry: http:\/\/t.co\/7b0VE2u",
  "id" : 101650050438008833,
  "created_at" : "2011-08-11 13:43:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ramadan",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 119 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "101451968194682880",
  "text" : "Happening Now: President Obama hosts an Iftar dinner celebrating #Ramadan in the State Dining Room: http:\/\/t.co\/hOlVdV1",
  "id" : 101451968194682880,
  "created_at" : "2011-08-11 00:36:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Africa",
      "indices" : [ 27, 34 ]
    }, {
      "text" : "Kenya",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http:\/\/t.co\/fyaJTN2",
      "expanded_url" : "http:\/\/wh.gov\/r6s",
      "display_url" : "wh.gov\/r6s"
    }, {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/sgWJYjF",
      "expanded_url" : "http:\/\/youtu.be\/zsWjvt6lScA",
      "display_url" : "youtu.be\/zsWjvt6lScA"
    } ]
  },
  "geo" : { },
  "id_str" : "101397548727672832",
  "text" : "The humanitarian crisis in #Africa & how you can help: http:\/\/t.co\/fyaJTN2 Video of Dr. Jill Biden's trip to #Kenya: http:\/\/t.co\/sgWJYjF",
  "id" : 101397548727672832,
  "created_at" : "2011-08-10 21:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HornofAfrica",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 112 ],
      "url" : "http:\/\/t.co\/QYKuTmj",
      "expanded_url" : "http:\/\/go.usa.gov\/KAz",
      "display_url" : "go.usa.gov\/KAz"
    } ]
  },
  "geo" : { },
  "id_str" : "101335474060275712",
  "text" : "RT @StateDept: More than 12.4 million people need emergency assistance in the #HornofAfrica: http:\/\/t.co\/QYKuTmj | How you can help: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HornofAfrica",
        "indices" : [ 63, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 97 ],
        "url" : "http:\/\/t.co\/QYKuTmj",
        "expanded_url" : "http:\/\/go.usa.gov\/KAz",
        "display_url" : "go.usa.gov\/KAz"
      }, {
        "indices" : [ 118, 137 ],
        "url" : "http:\/\/t.co\/1IOYUGu",
        "expanded_url" : "http:\/\/go.usa.gov\/KAu",
        "display_url" : "go.usa.gov\/KAu"
      } ]
    },
    "geo" : { },
    "id_str" : "101334118897430528",
    "text" : "More than 12.4 million people need emergency assistance in the #HornofAfrica: http:\/\/t.co\/QYKuTmj | How you can help: http:\/\/t.co\/1IOYUGu",
    "id" : 101334118897430528,
    "created_at" : "2011-08-10 16:48:31 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 101335474060275712,
  "created_at" : "2011-08-10 16:53:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Frist, M.D.",
      "screen_name" : "bfrist",
      "indices" : [ 26, 33 ],
      "id_str" : "5660532",
      "id" : 5660532
    }, {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 36, 44 ],
      "id_str" : "232193350",
      "id" : 232193350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HornofAfrica",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/T2TTJzJ",
      "expanded_url" : "http:\/\/wh.gov\/rsy",
      "display_url" : "wh.gov\/rsy"
    } ]
  },
  "geo" : { },
  "id_str" : "101332231531921409",
  "text" : "Photo Gallery: Dr. Biden, @bfrist & @rajshah visit Dadaab refugee camps, highlight need for aid in the #HornofAfrica: http:\/\/t.co\/T2TTJzJ",
  "id" : 101332231531921409,
  "created_at" : "2011-08-10 16:41:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Afghanistan",
      "indices" : [ 93, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101287399098822656",
  "text" : "Obama salutes in a ceremony at Dover AFB for the dignified transfer of personnel who died in #Afghanistan on 8\/6: http:\/\/twitpic.com\/63wu06",
  "id" : 101287399098822656,
  "created_at" : "2011-08-10 13:42:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 110 ],
      "url" : "http:\/\/t.co\/OE3lfaj",
      "expanded_url" : "http:\/\/wh.gov\/lxp",
      "display_url" : "wh.gov\/lxp"
    } ]
  },
  "geo" : { },
  "id_str" : "101062476099104769",
  "text" : "Get email updates from President Obama & other senior officials. Sign up & stay connected: http:\/\/t.co\/OE3lfaj",
  "id" : 101062476099104769,
  "created_at" : "2011-08-09 22:49:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 121, 132 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101025733173985280",
  "text" : "RT @SBAgov: SBA's Marie Johns recently talked w\/ 25 #smallbiz leaders. See the issues they voiced: http:\/\/go.usa.gov\/Kwz @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 109, 120 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smallbiz",
        "indices" : [ 40, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101019949799186432",
    "text" : "SBA's Marie Johns recently talked w\/ 25 #smallbiz leaders. See the issues they voiced: http:\/\/go.usa.gov\/Kwz @whitehouse",
    "id" : 101019949799186432,
    "created_at" : "2011-08-09 20:00:07 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 101025733173985280,
  "created_at" : "2011-08-09 20:23:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 25, 35 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http:\/\/t.co\/uQammSr",
      "expanded_url" : "http:\/\/wh.gov\/rsX",
      "display_url" : "wh.gov\/rsX"
    } ]
  },
  "geo" : { },
  "id_str" : "101018279954485250",
  "text" : "Transportation Secretary @RayLaHood: $50 Billion in fuel savings a \"significant win\" for trucking industry: http:\/\/t.co\/uQammSr",
  "id" : 101018279954485250,
  "created_at" : "2011-08-09 19:53:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HornofAfrica",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 107 ],
      "url" : "http:\/\/t.co\/4smSZjq",
      "expanded_url" : "http:\/\/www.usaid.gov\/hornofafrica",
      "display_url" : "usaid.gov\/hornofafrica"
    } ]
  },
  "geo" : { },
  "id_str" : "101012774972428288",
  "text" : "RT @USAID: Learn about how the U.S. is responding to the crisis in the #HornofAfrica at http:\/\/t.co\/4smSZjq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HornofAfrica",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 96 ],
        "url" : "http:\/\/t.co\/4smSZjq",
        "expanded_url" : "http:\/\/www.usaid.gov\/hornofafrica",
        "display_url" : "usaid.gov\/hornofafrica"
      } ]
    },
    "geo" : { },
    "id_str" : "101012371035795457",
    "text" : "Learn about how the U.S. is responding to the crisis in the #HornofAfrica at http:\/\/t.co\/4smSZjq",
    "id" : 101012371035795457,
    "created_at" : "2011-08-09 19:30:00 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 101012774972428288,
  "created_at" : "2011-08-09 19:31:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/Cbm0wA4",
      "expanded_url" : "http:\/\/wh.gov\/rA9",
      "display_url" : "wh.gov\/rA9"
    } ]
  },
  "geo" : { },
  "id_str" : "100991192212316164",
  "text" : "\"Our problems are eminently solvable\": President Obama outlines steps to help propel our economy forward: http:\/\/t.co\/Cbm0wA4",
  "id" : 100991192212316164,
  "created_at" : "2011-08-09 18:05:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    }, {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 43, 51 ],
      "id_str" : "232193350",
      "id" : 232193350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HornofAfrica",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http:\/\/t.co\/3PZUqyi",
      "expanded_url" : "http:\/\/go.usa.gov\/Kwi",
      "display_url" : "go.usa.gov\/Kwi"
    } ]
  },
  "geo" : { },
  "id_str" : "100969924779966464",
  "text" : "RT @USAID: A blog from USAID Administrator @Rajshah from the Dadaab Refugee Complex http:\/\/t.co\/3PZUqyi #HornofAfrica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Raj Shah",
        "screen_name" : "rajshah",
        "indices" : [ 32, 40 ],
        "id_str" : "232193350",
        "id" : 232193350
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HornofAfrica",
        "indices" : [ 93, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 92 ],
        "url" : "http:\/\/t.co\/3PZUqyi",
        "expanded_url" : "http:\/\/go.usa.gov\/Kwi",
        "display_url" : "go.usa.gov\/Kwi"
      } ]
    },
    "geo" : { },
    "id_str" : "100948610635677696",
    "text" : "A blog from USAID Administrator @Rajshah from the Dadaab Refugee Complex http:\/\/t.co\/3PZUqyi #HornofAfrica",
    "id" : 100948610635677696,
    "created_at" : "2011-08-09 15:16:38 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 100969924779966464,
  "created_at" : "2011-08-09 16:41:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oil",
      "indices" : [ 17, 21 ]
    }, {
      "text" : "fuel",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/2GCnVBK",
      "expanded_url" : "http:\/\/wh.gov\/rof",
      "display_url" : "wh.gov\/rof"
    } ]
  },
  "geo" : { },
  "id_str" : "100947495256981505",
  "text" : "WH announces new #oil savings standards for heavy duty trucks & buses - saves $50B in #fuel costs, 500M barrels of oil: http:\/\/t.co\/2GCnVBK",
  "id" : 100947495256981505,
  "created_at" : "2011-08-09 15:12:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 3, 15 ],
      "id_str" : "59204932",
      "id" : 59204932
    }, {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "indices" : [ 32, 48 ],
      "id_str" : "17961886",
      "id" : 17961886
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "data",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "VIA2011",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100934268317995008",
  "text" : "RT @ServeDotGov: New #data from @nationalservice in Volunteering in America report. How'd your state do? http:\/\/go.usa.gov\/KI6 #VIA2011",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNCS",
        "screen_name" : "NationalService",
        "indices" : [ 15, 31 ],
        "id_str" : "17961886",
        "id" : 17961886
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "data",
        "indices" : [ 4, 9 ]
      }, {
        "text" : "VIA2011",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100930610738118656",
    "text" : "New #data from @nationalservice in Volunteering in America report. How'd your state do? http:\/\/go.usa.gov\/KI6 #VIA2011",
    "id" : 100930610738118656,
    "created_at" : "2011-08-09 14:05:07 +0000",
    "user" : {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "protected" : false,
      "id_str" : "59204932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1119135330\/serve_normal.JPG",
      "id" : 59204932,
      "verified" : true
    }
  },
  "id" : 100934268317995008,
  "created_at" : "2011-08-09 14:19:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100926791446835200",
  "text" : "President Obama on bipartisan, commonsense steps to strengthen the economy. Video: http:\/\/wh.gov\/r7z Pic: http:\/\/twitpic.com\/63fv64",
  "id" : 100926791446835200,
  "created_at" : "2011-08-09 13:49:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100699147979591680",
  "text" : "Photo of the Day: President Obama walks across the South Lawn of the White House: http:\/\/twitpic.com\/6359rj",
  "id" : 100699147979591680,
  "created_at" : "2011-08-08 22:45:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gov20",
      "indices" : [ 111, 117 ]
    }, {
      "text" : "cuttingwaste",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 110 ],
      "url" : "http:\/\/t.co\/ebKnODG",
      "expanded_url" : "http:\/\/wh.gov\/rAK",
      "display_url" : "wh.gov\/rAK"
    } ]
  },
  "geo" : { },
  "id_str" : "100698038695247873",
  "text" : "RT @OMBPress: OMBlog: New Federal CIO VanRoekel posts on the Changing Role of Federal CIOs http:\/\/t.co\/ebKnODG #gov20 #cuttingwaste",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gov20",
        "indices" : [ 97, 103 ]
      }, {
        "text" : "cuttingwaste",
        "indices" : [ 104, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 96 ],
        "url" : "http:\/\/t.co\/ebKnODG",
        "expanded_url" : "http:\/\/wh.gov\/rAK",
        "display_url" : "wh.gov\/rAK"
      } ]
    },
    "geo" : { },
    "id_str" : "100697614445580289",
    "text" : "OMBlog: New Federal CIO VanRoekel posts on the Changing Role of Federal CIOs http:\/\/t.co\/ebKnODG #gov20 #cuttingwaste",
    "id" : 100697614445580289,
    "created_at" : "2011-08-08 22:39:16 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 100698038695247873,
  "created_at" : "2011-08-08 22:40:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http:\/\/t.co\/hT1Ubsg",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/08\/08\/president-obama-our-problems-are-eminently-solvable",
      "display_url" : "whitehouse.gov\/blog\/2011\/08\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "100696246297169920",
  "text" : "President Obama: \"Our problems are eminently solvable.\" More on Obama's proposals to jumpstart the economy: http:\/\/t.co\/hT1Ubsg",
  "id" : 100696246297169920,
  "created_at" : "2011-08-08 22:33:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 80, 91 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NCLB",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/8wGwshy",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/08\/08\/providing-our-schools-relief-no-child-left-behind?utm_source=wh.gov&utm_medium=shorturl&utm_campaign=shorturl",
      "display_url" : "whitehouse.gov\/blog\/2011\/08\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "100679920707059712",
  "text" : "#NCLB is \"forcing states into one-size-fits-all solutions that just don\u2019t work\" @arneduncan on relief for schools: http:\/\/t.co\/8wGwshy",
  "id" : 100679920707059712,
  "created_at" : "2011-08-08 21:28:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USPTO",
      "screen_name" : "uspto",
      "indices" : [ 3, 9 ],
      "id_str" : "16057477",
      "id" : 16057477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ohio",
      "indices" : [ 45, 50 ]
    }, {
      "text" : "patent",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/0qLk6Rx",
      "expanded_url" : "http:\/\/1.usa.gov\/p1j3k0",
      "display_url" : "1.usa.gov\/p1j3k0"
    } ]
  },
  "geo" : { },
  "id_str" : "100674680951803904",
  "text" : "RT @uspto: 100 years ago today, F. Holton of #Ohio got 'round to an invention & scored #patent no. 1,000,000. http:\/\/t.co\/0qLk6Rx #8mill ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ohio",
        "indices" : [ 34, 39 ]
      }, {
        "text" : "patent",
        "indices" : [ 76, 83 ]
      }, {
        "text" : "8million",
        "indices" : [ 119, 128 ]
      }, {
        "text" : "history",
        "indices" : [ 129, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 118 ],
        "url" : "http:\/\/t.co\/0qLk6Rx",
        "expanded_url" : "http:\/\/1.usa.gov\/p1j3k0",
        "display_url" : "1.usa.gov\/p1j3k0"
      } ]
    },
    "geo" : { },
    "id_str" : "100662383273443328",
    "text" : "100 years ago today, F. Holton of #Ohio got 'round to an invention & scored #patent no. 1,000,000. http:\/\/t.co\/0qLk6Rx #8million #history",
    "id" : 100662383273443328,
    "created_at" : "2011-08-08 20:19:17 +0000",
    "user" : {
      "name" : "USPTO",
      "screen_name" : "uspto",
      "protected" : false,
      "id_str" : "16057477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684014734937559040\/WhfNiuZx_normal.png",
      "id" : 16057477,
      "verified" : true
    }
  },
  "id" : 100674680951803904,
  "created_at" : "2011-08-08 21:08:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AAA",
      "indices" : [ 57, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 98 ],
      "url" : "http:\/\/t.co\/RFEMyxM",
      "expanded_url" : "http:\/\/youtu.be\/HmMMHjD7yEs",
      "display_url" : "youtu.be\/HmMMHjD7yEs"
    } ]
  },
  "geo" : { },
  "id_str" : "100666164232982528",
  "text" : "President Obama: \"We\u2019ve always been and always will be a #AAA country.\" Video: http:\/\/t.co\/RFEMyxM",
  "id" : 100666164232982528,
  "created_at" : "2011-08-08 20:34:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/rTfUpw7",
      "expanded_url" : "http:\/\/www.wh.gov\/internship",
      "display_url" : "wh.gov\/internship"
    } ]
  },
  "geo" : { },
  "id_str" : "100639841183739904",
  "text" : "Now accepting applications for the White House Internship program. Learn more & apply for Spring 2012: http:\/\/t.co\/rTfUpw7",
  "id" : 100639841183739904,
  "created_at" : "2011-08-08 18:49:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 17, 25 ],
      "id_str" : "232193350",
      "id" : 232193350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "famine",
      "indices" : [ 42, 49 ]
    }, {
      "text" : "Kenya",
      "indices" : [ 76, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100633259892948992",
  "text" : "Dr. Jill Biden & @rajshah visit w\/ Somali #famine victims @ refugee camp in #Kenya. Blog: http:\/\/wh.gov\/rfu Pic: http:\/\/twitpic.com\/6324x2",
  "id" : 100633259892948992,
  "created_at" : "2011-08-08 18:23:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 100 ],
      "url" : "http:\/\/t.co\/ZQj8XeA",
      "expanded_url" : "http:\/\/www.wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "100628232725995520",
  "text" : "President Obama\u2019s remarks just concluded. Full video & remarks will be posted on http:\/\/t.co\/ZQj8XeA soon.",
  "id" : 100628232725995520,
  "created_at" : "2011-08-08 18:03:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100628145086005248",
  "text" : "\"Our responsibility is to ensure that their legacy is an America that reflects their courage, commitment & sense of common purpose.\" -Obama",
  "id" : 100628145086005248,
  "created_at" : "2011-08-08 18:03:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100628051792105472",
  "text" : "\"Now is also a time to reflect on those we lost, and the sacrifices of all who serve \u2013 as well as their families.\" -President Obama",
  "id" : 100628051792105472,
  "created_at" : "2011-08-08 18:02:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Afghanistan",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100627830882304001",
  "text" : "Obama on loss in #Afghanistan: \"A stark reminder of the risks that our men & women in uniform take every day on behalf of their county\"",
  "id" : 100627830882304001,
  "created_at" : "2011-08-08 18:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100627792923865089",
  "text" : "\"It\u2019s because of their perseverance & their courage & their willingness to shoulder the burdens we face \u2013 together, as one nation.\" \u2013Obama",
  "id" : 100627792923865089,
  "created_at" : "2011-08-08 18:01:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100627611507634176",
  "text" : "\"Ultimately, the reason I am still so hopeful about our future...is because of the American people.\" -President Obama",
  "id" : 100627611507634176,
  "created_at" : "2011-08-08 18:01:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100627479026339840",
  "text" : "RT @jesseclee44: Obama: \"if Congress fails to extend the payroll tax cuts & unemployment insurance...it could mean 1 million fewer jobs  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100627275741011968",
    "text" : "Obama: \"if Congress fails to extend the payroll tax cuts & unemployment insurance...it could mean 1 million fewer jobs & 1\/2% less growth\"",
    "id" : 100627275741011968,
    "created_at" : "2011-08-08 17:59:46 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 100627479026339840,
  "created_at" : "2011-08-08 18:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100627425418944512",
  "text" : "\"No matter what some agency may say about our credit, we always have been and always will a Triple A country.\" -President Obama",
  "id" : 100627425418944512,
  "created_at" : "2011-08-08 18:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100626924333826049",
  "text" : "\"We should extend the payroll tax cut as soon as possible, so that workers have more money in their paychecks next year.\" -President Obama",
  "id" : 100626924333826049,
  "created_at" : "2011-08-08 17:58:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100626752631615488",
  "text" : "\"The most immediate concern of most Americans is jobs & the slow pace of recovery coming out of the worst recession in our lifetimes\" -Obama",
  "id" : 100626752631615488,
  "created_at" : "2011-08-08 17:57:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100626541570048000",
  "text" : "RT @pfeiffer44: POTUS: \"Warren Buffett, who knows a thing or two about good investments, said \u201CIf there were a quadruple-A rating, I\u2019d g ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100626356957749248",
    "text" : "POTUS: \"Warren Buffett, who knows a thing or two about good investments, said \u201CIf there were a quadruple-A rating, I\u2019d give the U.S. that.\u201D",
    "id" : 100626356957749248,
    "created_at" : "2011-08-08 17:56:07 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 100626541570048000,
  "created_at" : "2011-08-08 17:56:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100626513552089088",
  "text" : "Obama on the problem: Lack of political will in Washington...refusal to put what\u2019s best for the country ahead of self-interest or ideology.",
  "id" : 100626513552089088,
  "created_at" : "2011-08-08 17:56:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100626352033632256",
  "text" : "\"Making these reforms doesn\u2019t require any radical steps. What it does require is common sense & #compromise.\" -President Obama",
  "id" : 100626352033632256,
  "created_at" : "2011-08-08 17:56:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100626228146487296",
  "text" : "Obama: Need to combine spending cuts w\/ tax code reform that asks wealthiest to pay fair share & modest adjustments to health care programs.",
  "id" : 100626228146487296,
  "created_at" : "2011-08-08 17:55:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100626004338413569",
  "text" : "\"Our problems are solvable. And we know what we have to do to solve them.\" -President Obama",
  "id" : 100626004338413569,
  "created_at" : "2011-08-08 17:54:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100625775111315456",
  "text" : "\"We didn\u2019t need a rating agency to tell us that the gridlock in Washington over the last several months has not been constructive.\" -Obama",
  "id" : 100625775111315456,
  "created_at" : "2011-08-08 17:53:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "100625520789692416",
  "text" : "Happening now: President Obama delivers a statement to the press. Watch live: http:\/\/t.co\/hOlVdV1 & we\u2019ll be tweeting excerpts here.",
  "id" : 100625520789692416,
  "created_at" : "2011-08-08 17:52:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 3, 11 ],
      "id_str" : "232193350",
      "id" : 232193350
    }, {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 14, 29 ],
      "id_str" : "14511951",
      "id" : 14511951
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kenya",
      "indices" : [ 45, 51 ]
    }, {
      "text" : "Dadaab",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100593609614688256",
  "text" : "RT @rajshah: .@HuffingtonPost on our trip to #Kenya, #Dadaab: Dr. Biden says situation is \"dire,\" \"but hope if ppl pay attention.\" http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Huffington Post",
        "screen_name" : "HuffingtonPost",
        "indices" : [ 1, 16 ],
        "id_str" : "14511951",
        "id" : 14511951
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kenya",
        "indices" : [ 32, 38 ]
      }, {
        "text" : "Dadaab",
        "indices" : [ 40, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 137 ],
        "url" : "http:\/\/t.co\/3UB2vgy",
        "expanded_url" : "http:\/\/huff.to\/n09yQa",
        "display_url" : "huff.to\/n09yQa"
      } ]
    },
    "geo" : { },
    "id_str" : "100592132234031104",
    "text" : ".@HuffingtonPost on our trip to #Kenya, #Dadaab: Dr. Biden says situation is \"dire,\" \"but hope if ppl pay attention.\" http:\/\/t.co\/3UB2vgy",
    "id" : 100592132234031104,
    "created_at" : "2011-08-08 15:40:07 +0000",
    "user" : {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "protected" : false,
      "id_str" : "232193350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486242763227152384\/vse4PX_j_normal.jpeg",
      "id" : 232193350,
      "verified" : true
    }
  },
  "id" : 100593609614688256,
  "created_at" : "2011-08-08 15:46:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "100583347939577856",
  "text" : "President Obama will deliver a statement to the press @ 1:00 EDT. Tune in live: http:\/\/t.co\/hOlVdV1",
  "id" : 100583347939577856,
  "created_at" : "2011-08-08 15:05:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Bill Frist, M.D.",
      "screen_name" : "bfrist",
      "indices" : [ 29, 36 ],
      "id_str" : "5660532",
      "id" : 5660532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/N74hiUX",
      "expanded_url" : "http:\/\/1.usa.gov\/qLDI5W",
      "display_url" : "1.usa.gov\/qLDI5W"
    } ]
  },
  "geo" : { },
  "id_str" : "100575702922956800",
  "text" : "RT @VP: PHOTO: Dr. B and Sen @bfrist visit with women and children at the Dadaab Refuge Complex in Kenya http:\/\/t.co\/N74hiUX http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Frist, M.D.",
        "screen_name" : "bfrist",
        "indices" : [ 21, 28 ],
        "id_str" : "5660532",
        "id" : 5660532
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/100519854519484416\/photo\/1",
        "indices" : [ 117, 136 ],
        "url" : "http:\/\/t.co\/cspUjw8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AWUeRm3CAAAoJr8.jpg",
        "id_str" : "100519854523678720",
        "id" : 100519854523678720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AWUeRm3CAAAoJr8.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/cspUjw8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 116 ],
        "url" : "http:\/\/t.co\/N74hiUX",
        "expanded_url" : "http:\/\/1.usa.gov\/qLDI5W",
        "display_url" : "1.usa.gov\/qLDI5W"
      } ]
    },
    "geo" : { },
    "id_str" : "100519854519484416",
    "text" : "PHOTO: Dr. B and Sen @bfrist visit with women and children at the Dadaab Refuge Complex in Kenya http:\/\/t.co\/N74hiUX http:\/\/t.co\/cspUjw8",
    "id" : 100519854519484416,
    "created_at" : "2011-08-08 10:52:55 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 100575702922956800,
  "created_at" : "2011-08-08 14:34:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hornofafrica",
      "indices" : [ 23, 36 ]
    }, {
      "text" : "famine",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100575692261048321",
  "text" : "RT @VP: Dr. B visit to #hornofafrica underscores US commitment to working w\/govts, people of region & int'l community to help #famine vi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hornofafrica",
        "indices" : [ 15, 28 ]
      }, {
        "text" : "famine",
        "indices" : [ 118, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "100437740549713920",
    "text" : "Dr. B visit to #hornofafrica underscores US commitment to working w\/govts, people of region & int'l community to help #famine victims",
    "id" : 100437740549713920,
    "created_at" : "2011-08-08 05:26:38 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 100575692261048321,
  "created_at" : "2011-08-08 14:34:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Afghanistan",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/nmkGvYe",
      "expanded_url" : "http:\/\/flic.kr\/p\/aavBKs",
      "display_url" : "flic.kr\/p\/aavBKs"
    }, {
      "indices" : [ 99, 118 ],
      "url" : "http:\/\/t.co\/IwdPDQg",
      "expanded_url" : "http:\/\/1.usa.gov\/nNEAwN",
      "display_url" : "1.usa.gov\/nNEAwN"
    } ]
  },
  "geo" : { },
  "id_str" : "100236207463735296",
  "text" : "Photo: President Obama is briefed on the tragedy in #Afghanistan: http:\/\/t.co\/nmkGvYe & statement: http:\/\/t.co\/IwdPDQg",
  "id" : 100236207463735296,
  "created_at" : "2011-08-07 16:05:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/x67VMv1",
      "expanded_url" : "http:\/\/bit.ly\/nXXINw",
      "display_url" : "bit.ly\/nXXINw"
    } ]
  },
  "geo" : { },
  "id_str" : "100224028157022208",
  "text" : "President Obama calls on Ds & Rs to work together to grow the economy & get Americans back to work. Weekly Address: http:\/\/t.co\/x67VMv1",
  "id" : 100224028157022208,
  "created_at" : "2011-08-07 15:17:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99914278529802240",
  "text" : "RT @pfeiffer44: Buffet on Fox Business: \"In Omaha, the U.S. is still Triple A. In fact, if there were a quadruple A rating. I'd give the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "99884615770177536",
    "text" : "Buffet on Fox Business: \"In Omaha, the U.S. is still Triple A. In fact, if there were a quadruple A rating. I'd give the U.S. that.\"",
    "id" : 99884615770177536,
    "created_at" : "2011-08-06 16:48:42 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 99914278529802240,
  "created_at" : "2011-08-06 18:46:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99878600379072512",
  "text" : "\"At this difficult hour, all Americans are united in support of our men and women in uniform\" -President Obama on casualties in Afghanistan",
  "id" : 99878600379072512,
  "created_at" : "2011-08-06 16:24:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    }, {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 27, 41 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Americans",
      "indices" : [ 87, 97 ]
    }, {
      "text" : "Military",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/cUhNrFR",
      "expanded_url" : "http:\/\/1.usa.gov\/mStojE",
      "display_url" : "1.usa.gov\/mStojE"
    } ]
  },
  "geo" : { },
  "id_str" : "99875411944677376",
  "text" : "RT @USArmy: Statement from @DeptofDefense Secretary about the loss of many outstanding #Americans in uniform: http:\/\/t.co\/cUhNrFR #Military",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Dept of Defense",
        "screen_name" : "DeptofDefense",
        "indices" : [ 15, 29 ],
        "id_str" : "66369181",
        "id" : 66369181
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Americans",
        "indices" : [ 75, 85 ]
      }, {
        "text" : "Military",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 117 ],
        "url" : "http:\/\/t.co\/cUhNrFR",
        "expanded_url" : "http:\/\/1.usa.gov\/mStojE",
        "display_url" : "1.usa.gov\/mStojE"
      } ]
    },
    "geo" : { },
    "id_str" : "99860570563555328",
    "text" : "Statement from @DeptofDefense Secretary about the loss of many outstanding #Americans in uniform: http:\/\/t.co\/cUhNrFR #Military",
    "id" : 99860570563555328,
    "created_at" : "2011-08-06 15:13:10 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 99875411944677376,
  "created_at" : "2011-08-06 16:12:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/nbnPbpZ",
      "expanded_url" : "http:\/\/wh.gov\/rw0",
      "display_url" : "wh.gov\/rw0"
    } ]
  },
  "geo" : { },
  "id_str" : "99561423478333440",
  "text" : "Tell us: What do new policies enabling immigrant entrepreneurship mean to you? Reply w\/ your response. More info at: http:\/\/t.co\/nbnPbpZ",
  "id" : 99561423478333440,
  "created_at" : "2011-08-05 19:24:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 3, 10 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99550766796247040",
  "text" : "RT @USNavy: POTUS talks importance of vet job transition & civ wrk force opportunities while visiting Wash Navy Yard http:\/\/ow.ly\/5WiD7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "99542068044627968",
    "text" : "POTUS talks importance of vet job transition & civ wrk force opportunities while visiting Wash Navy Yard http:\/\/ow.ly\/5WiD7",
    "id" : 99542068044627968,
    "created_at" : "2011-08-05 18:07:33 +0000",
    "user" : {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "protected" : false,
      "id_str" : "54885400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785776641066708992\/nEqdAKde_normal.jpg",
      "id" : 54885400,
      "verified" : true
    }
  },
  "id" : 99550766796247040,
  "created_at" : "2011-08-05 18:42:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FAA",
      "indices" : [ 27, 31 ]
    }, {
      "text" : "Obama",
      "indices" : [ 51, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99530848470188032",
  "text" : "RT @RayLaHood: Thrilled by #FAA extension; as Pres #Obama said, \"We can't let Washington politics hamper our recovery\"  http:\/\/bit.ly\/npsc5f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FAA",
        "indices" : [ 12, 16 ]
      }, {
        "text" : "Obama",
        "indices" : [ 36, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "99500762920521728",
    "text" : "Thrilled by #FAA extension; as Pres #Obama said, \"We can't let Washington politics hamper our recovery\"  http:\/\/bit.ly\/npsc5f",
    "id" : 99500762920521728,
    "created_at" : "2011-08-05 15:23:25 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 99530848470188032,
  "created_at" : "2011-08-05 17:22:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 30, 41 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 42, 54 ],
      "id_str" : "16789970",
      "id" : 16789970
    }, {
      "name" : "Kay Bailey Hutchison",
      "screen_name" : "kaybaileyhutch",
      "indices" : [ 55, 70 ],
      "id_str" : "133439172",
      "id" : 133439172
    }, {
      "name" : "Jay Rockefeller",
      "screen_name" : "senrockefeller",
      "indices" : [ 71, 86 ],
      "id_str" : "707596397076475904",
      "id" : 707596397076475904
    }, {
      "name" : "The FAA",
      "screen_name" : "FAANews",
      "indices" : [ 87, 95 ],
      "id_str" : "160946337",
      "id" : 160946337
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ffs",
      "indices" : [ 25, 29 ]
    }, {
      "text" : "FAA",
      "indices" : [ 114, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99530734276067328",
  "text" : "RT @RayLaHood: Thx to my #ffs @whitehouse @senatorreid @kaybaileyhutch @SenRockefeller @FAANews for their work on #FAA extension  http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 15, 26 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Senator Harry Reid",
        "screen_name" : "SenatorReid",
        "indices" : [ 27, 39 ],
        "id_str" : "16789970",
        "id" : 16789970
      }, {
        "name" : "Kay Bailey Hutchison",
        "screen_name" : "kaybaileyhutch",
        "indices" : [ 40, 55 ],
        "id_str" : "133439172",
        "id" : 133439172
      }, {
        "name" : "Jay Rockefeller",
        "screen_name" : "senrockefeller",
        "indices" : [ 56, 71 ],
        "id_str" : "707596397076475904",
        "id" : 707596397076475904
      }, {
        "name" : "The FAA",
        "screen_name" : "FAANews",
        "indices" : [ 72, 80 ],
        "id_str" : "160946337",
        "id" : 160946337
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ffs",
        "indices" : [ 10, 14 ]
      }, {
        "text" : "FAA",
        "indices" : [ 99, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "99521314322259968",
    "text" : "Thx to my #ffs @whitehouse @senatorreid @kaybaileyhutch @SenRockefeller @FAANews for their work on #FAA extension  http:\/\/bit.ly\/npsc5f",
    "id" : 99521314322259968,
    "created_at" : "2011-08-05 16:45:05 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 99530734276067328,
  "created_at" : "2011-08-05 17:22:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99497219685752833",
  "text" : "RT @JoiningForces: Coming Up: President Obama discusses the Administration's work to prepare our nation's veterans for the workforce...  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "99492008208502784",
    "text" : "Coming Up: President Obama discusses the Administration's work to prepare our nation's veterans for the workforce... http:\/\/fb.me\/P3HCjene",
    "id" : 99492008208502784,
    "created_at" : "2011-08-05 14:48:37 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 99497219685752833,
  "created_at" : "2011-08-05 15:09:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99223836863631361",
  "text" : "Photo of the Day: President Obama has lunch w\/ advisors who worked on #debt negotiations @ local burger joint: http:\/\/twitpic.com\/60y1z6",
  "id" : 99223836863631361,
  "created_at" : "2011-08-04 21:03:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99201180915343360",
  "text" : "RT @VP: Happy birthday Mr. President; here\u2019s to 50 years young \u2013 VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "99199962700718080",
    "text" : "Happy birthday Mr. President; here\u2019s to 50 years young \u2013 VP",
    "id" : 99199962700718080,
    "created_at" : "2011-08-04 19:28:08 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 99201180915343360,
  "created_at" : "2011-08-04 19:32:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 105, 115 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 116, 130 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "deficit",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/ezfaMV8",
      "expanded_url" : "http:\/\/wh.gov\/rVT",
      "display_url" : "wh.gov\/rVT"
    } ]
  },
  "geo" : { },
  "id_str" : "99192915779264512",
  "text" : "RT @OMBPress: OMBlog: Jack Lew walks through security spending in the #deficit deal. http:\/\/t.co\/ezfaMV8 @StateDept @DeptofDefense",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 91, 101 ],
        "id_str" : "9624742",
        "id" : 9624742
      }, {
        "name" : "U.S. Dept of Defense",
        "screen_name" : "DeptofDefense",
        "indices" : [ 102, 116 ],
        "id_str" : "66369181",
        "id" : 66369181
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "deficit",
        "indices" : [ 56, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 90 ],
        "url" : "http:\/\/t.co\/ezfaMV8",
        "expanded_url" : "http:\/\/wh.gov\/rVT",
        "display_url" : "wh.gov\/rVT"
      } ]
    },
    "geo" : { },
    "id_str" : "99179656057589760",
    "text" : "OMBlog: Jack Lew walks through security spending in the #deficit deal. http:\/\/t.co\/ezfaMV8 @StateDept @DeptofDefense",
    "id" : 99179656057589760,
    "created_at" : "2011-08-04 18:07:27 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 99192915779264512,
  "created_at" : "2011-08-04 19:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "compromise",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 59 ],
      "url" : "http:\/\/t.co\/5A7p6Z6",
      "expanded_url" : "http:\/\/wh.gov\/ryA",
      "display_url" : "wh.gov\/ryA"
    }, {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/4AncX2q",
      "expanded_url" : "http:\/\/twitpic.com\/60tb4p",
      "display_url" : "twitpic.com\/60tb4p"
    } ]
  },
  "geo" : { },
  "id_str" : "99192586790637568",
  "text" : "Myths & facts on the #debt #compromise: http:\/\/t.co\/5A7p6Z6 Infographic on the deal & what's to come: http:\/\/t.co\/4AncX2q",
  "id" : 99192586790637568,
  "created_at" : "2011-08-04 18:58:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 122, 133 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99139720621199360",
  "text" : "RT @macon44: Congrats to Steve VanRoekel our new federal CIO! Will miss Vivek, but thrilled for this new force for change @whitehouse ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 109, 120 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 140 ],
        "url" : "http:\/\/t.co\/OuwfkcZ",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/08\/04\/transitions",
        "display_url" : "whitehouse.gov\/blog\/2011\/08\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "99138011878526976",
    "text" : "Congrats to Steve VanRoekel our new federal CIO! Will miss Vivek, but thrilled for this new force for change @whitehouse http:\/\/t.co\/OuwfkcZ",
    "id" : 99138011878526976,
    "created_at" : "2011-08-04 15:21:58 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 99139720621199360,
  "created_at" : "2011-08-04 15:28:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "indices" : [ 3, 17 ],
      "id_str" : "28576135",
      "id" : 28576135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99134894499835904",
  "text" : "RT @thejointstaff: Happy 221st birthday US Coast Guard. America is safer and more secure because of you. Read my full msg @http:\/\/tinyur ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "99133118690246658",
    "text" : "Happy 221st birthday US Coast Guard. America is safer and more secure because of you. Read my full msg @http:\/\/tinyurl.com\/3ms4gjp.",
    "id" : 99133118690246658,
    "created_at" : "2011-08-04 15:02:31 +0000",
    "user" : {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "protected" : false,
      "id_str" : "28576135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459045440063672320\/SOEE5LHU_normal.png",
      "id" : 28576135,
      "verified" : true
    }
  },
  "id" : 99134894499835904,
  "created_at" : "2011-08-04 15:09:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 28, 33 ]
    }, {
      "text" : "compromise",
      "indices" : [ 34, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99134449521926145",
  "text" : "INFOGRAPHIC: The bipartisan #debt #compromise explained in 3 steps (full size: http:\/\/wh.gov\/rmO) http:\/\/twitpic.com\/60tb4p",
  "id" : 99134449521926145,
  "created_at" : "2011-08-04 15:07:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 91 ],
      "url" : "http:\/\/t.co\/WY4dJhS",
      "expanded_url" : "http:\/\/n.pr\/qXc4qi",
      "display_url" : "n.pr\/qXc4qi"
    } ]
  },
  "geo" : { },
  "id_str" : "99115083543740416",
  "text" : "RT @jesseclee44: NPR \"Obama Gets High Marks For Diversifying The Bench\" http:\/\/t.co\/WY4dJhS Roll Call \"Diversity Comes to Judiciary\" htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 136, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 74 ],
        "url" : "http:\/\/t.co\/WY4dJhS",
        "expanded_url" : "http:\/\/n.pr\/qXc4qi",
        "display_url" : "n.pr\/qXc4qi"
      }, {
        "indices" : [ 116, 135 ],
        "url" : "http:\/\/t.co\/cMgneyW",
        "expanded_url" : "http:\/\/bit.ly\/pi4n0T",
        "display_url" : "bit.ly\/pi4n0T"
      } ]
    },
    "geo" : { },
    "id_str" : "99113562303238144",
    "text" : "NPR \"Obama Gets High Marks For Diversifying The Bench\" http:\/\/t.co\/WY4dJhS Roll Call \"Diversity Comes to Judiciary\" http:\/\/t.co\/cMgneyW #p2",
    "id" : 99113562303238144,
    "created_at" : "2011-08-04 13:44:49 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 99115083543740416,
  "created_at" : "2011-08-04 13:50:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/jfdfWmS",
      "expanded_url" : "http:\/\/wh.gov\/ry8",
      "display_url" : "wh.gov\/ry8"
    } ]
  },
  "geo" : { },
  "id_str" : "99113259780669440",
  "text" : "Rep Ryan offered an interesting take on the President\u2019s leadership on the debt & deficit. See claims & our responses: http:\/\/t.co\/jfdfWmS",
  "id" : 99113259780669440,
  "created_at" : "2011-08-04 13:43:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 104, 115 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHWeb",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http:\/\/t.co\/yf1d2Oq",
      "expanded_url" : "http:\/\/wh.gov\/ryD",
      "display_url" : "wh.gov\/ryD"
    } ]
  },
  "geo" : { },
  "id_str" : "98904940667338752",
  "text" : "Today's WH Office Hours on the debt compromise here: http:\/\/t.co\/yf1d2Oq Use #WHWeb to give feedback on @WhiteHouse & the online program.",
  "id" : 98904940667338752,
  "created_at" : "2011-08-03 23:55:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FAA",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/N8PpiFZ",
      "expanded_url" : "http:\/\/wh.gov\/rmF",
      "display_url" : "wh.gov\/rmF"
    } ]
  },
  "geo" : { },
  "id_str" : "98874945106481152",
  "text" : "\"I\u2019m urging the House & the Senate to take care of this\" -President Obama on the #FAA stalemate: http:\/\/t.co\/N8PpiFZ",
  "id" : 98874945106481152,
  "created_at" : "2011-08-03 21:56:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHWeb",
      "indices" : [ 53, 59 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98857023248146432",
  "text" : "Bye for now. Hopefully informative. Send feedback to #WHWeb -Brian #WHChat",
  "id" : 98857023248146432,
  "created_at" : "2011-08-03 20:45:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Stevens",
      "screen_name" : "LeftyTWS15",
      "indices" : [ 1, 12 ],
      "id_str" : "191187878",
      "id" : 191187878
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98856474121478144",
  "text" : ".@LeftyTWS15 intransigence. Congress can solve this problem, and solve it today. Since '07 they've done so 20 times. #WHChat",
  "id" : 98856474121478144,
  "created_at" : "2011-08-03 20:43:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Taylor Stevens",
      "screen_name" : "LeftyTWS15",
      "indices" : [ 3, 14 ],
      "id_str" : "191187878",
      "id" : 191187878
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98856137662795776",
  "text" : "RT @LeftyTWS15: #WHChat what's the hold up on the FAA contract?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98855353961291776",
    "text" : "#WHChat what's the hold up on the FAA contract?",
    "id" : 98855353961291776,
    "created_at" : "2011-08-03 20:38:47 +0000",
    "user" : {
      "name" : "Taylor Stevens",
      "screen_name" : "LeftyTWS15",
      "protected" : false,
      "id_str" : "191187878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614105593499021312\/xkxRbM-S_normal.jpg",
      "id" : 191187878,
      "verified" : false
    }
  },
  "id" : 98856137662795776,
  "created_at" : "2011-08-03 20:41:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98855992355336192",
  "text" : ".@pfarr86 grad students can still access subsidized loans and defer payments. Modest changes help fund college access for millions #WHChat",
  "id" : 98855992355336192,
  "created_at" : "2011-08-03 20:41:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 27, 42 ],
      "id_str" : "14511951",
      "id" : 14511951
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98855124599967745",
  "text" : "RT @pfarr86: @whitehouse a @HuffingtonPost article says that grad students are hit hard by the debt deal. Can you comment on that?#whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Huffington Post",
        "screen_name" : "HuffingtonPost",
        "indices" : [ 14, 29 ],
        "id_str" : "14511951",
        "id" : 14511951
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 117, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98854899185500160",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse a @HuffingtonPost article says that grad students are hit hard by the debt deal. Can you comment on that?#whchat",
    "id" : 98854899185500160,
    "created_at" : "2011-08-03 20:36:59 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Michael Pfarr",
      "screen_name" : "mikepfarr",
      "protected" : false,
      "id_str" : "309167672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797224290282274816\/oluMoR19_normal.jpg",
      "id" : 309167672,
      "verified" : false
    }
  },
  "id" : 98855124599967745,
  "created_at" : "2011-08-03 20:37:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elyse Matson SLP",
      "screen_name" : "leesy45",
      "indices" : [ 1, 9 ],
      "id_str" : "85471817",
      "id" : 85471817
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98854895658086401",
  "text" : ".@leesy45 invstmts like education are key; deal allows us to protect them. But potus thinks most fortunate also need to contribute #WHChat",
  "id" : 98854895658086401,
  "created_at" : "2011-08-03 20:36:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elyse Matson SLP",
      "screen_name" : "leesy45",
      "indices" : [ 3, 11 ],
      "id_str" : "85471817",
      "id" : 85471817
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98854116784226304",
  "text" : "RT @leesy45: #WHChat what can Obama do to decrease the widening gap b\/ t rich and poor? This deal appears to only make it worse.  thx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98850733755084800",
    "text" : "#WHChat what can Obama do to decrease the widening gap b\/ t rich and poor? This deal appears to only make it worse.  thx",
    "id" : 98850733755084800,
    "created_at" : "2011-08-03 20:20:26 +0000",
    "user" : {
      "name" : "Elyse Matson SLP",
      "screen_name" : "leesy45",
      "protected" : false,
      "id_str" : "85471817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1507860456\/2yWcP5X1_normal",
      "id" : 85471817,
      "verified" : false
    }
  },
  "id" : 98854116784226304,
  "created_at" : "2011-08-03 20:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Battle4america",
      "screen_name" : "Battle4America",
      "indices" : [ 1, 16 ],
      "id_str" : "160797722",
      "id" : 160797722
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 106 ],
      "url" : "http:\/\/t.co\/RIWXEig",
      "expanded_url" : "http:\/\/www.treasury.gov\/press-center\/press-releases\/Pages\/tg1268.aspx",
      "display_url" : "treasury.gov\/press-center\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98853138206965760",
  "text" : ".@Battle4America good timing, check out the Treasury's announcement from just this AM: http:\/\/t.co\/RIWXEig #WHChat",
  "id" : 98853138206965760,
  "created_at" : "2011-08-03 20:29:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Battle4america",
      "screen_name" : "Battle4America",
      "indices" : [ 3, 18 ],
      "id_str" : "160797722",
      "id" : 160797722
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98852935986987008",
  "text" : "RT @Battle4America: #WHChat What will the president do to get small banks lending again?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98851641968689152",
    "text" : "#WHChat What will the president do to get small banks lending again?",
    "id" : 98851641968689152,
    "created_at" : "2011-08-03 20:24:02 +0000",
    "user" : {
      "name" : "Battle4america",
      "screen_name" : "Battle4America",
      "protected" : false,
      "id_str" : "160797722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684600925621649408\/aCnF0c1j_normal.jpg",
      "id" : 160797722,
      "verified" : false
    }
  },
  "id" : 98852935986987008,
  "created_at" : "2011-08-03 20:29:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joann DeLanoy",
      "screen_name" : "JoannDeLanoy",
      "indices" : [ 1, 14 ],
      "id_str" : "81139759",
      "id" : 81139759
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98852766251880448",
  "text" : ".@JoannDeLanoy in debt deal, POTUS fought for $17bn to ensure full Pell Grant increase, will help 9m students, $5500\/yr for college #WHChat",
  "id" : 98852766251880448,
  "created_at" : "2011-08-03 20:28:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joann DeLanoy",
      "screen_name" : "JoannDeLanoy",
      "indices" : [ 3, 16 ],
      "id_str" : "81139759",
      "id" : 81139759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98852391402733568",
  "text" : "RT @JoannDeLanoy: How are students being screwed this time? No one ever mentions that growing issue..apparently the US doesn't really va ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98851115109584897",
    "text" : "How are students being screwed this time? No one ever mentions that growing issue..apparently the US doesn't really value education #WHchat",
    "id" : 98851115109584897,
    "created_at" : "2011-08-03 20:21:57 +0000",
    "user" : {
      "name" : "Joann DeLanoy",
      "screen_name" : "JoannDeLanoy",
      "protected" : false,
      "id_str" : "81139759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3435580000\/e908d70e44408cde3ebf0b586f9e0e69_normal.jpeg",
      "id" : 81139759,
      "verified" : false
    }
  },
  "id" : 98852391402733568,
  "created_at" : "2011-08-03 20:27:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Blevins",
      "screen_name" : "TravelerBill",
      "indices" : [ 1, 14 ],
      "id_str" : "18813704",
      "id" : 18813704
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98852115937624064",
  "text" : ".@travelerbill when they've refused, we've repurposed $$s to states that are ready willing and able to put them to use #WHChat",
  "id" : 98852115937624064,
  "created_at" : "2011-08-03 20:25:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Blevins",
      "screen_name" : "TravelerBill",
      "indices" : [ 3, 16 ],
      "id_str" : "18813704",
      "id" : 18813704
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98851945841827840",
  "text" : "RT @travelerbill: @whitehouse Any plans for infrastructure improvmnts in the near future.  I kno its up to the states, what if they refu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "98820134046679040",
    "geo" : { },
    "id_str" : "98851627468988416",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Any plans for infrastructure improvmnts in the near future.  I kno its up to the states, what if they refuse Fed $$?? #WHChat",
    "id" : 98851627468988416,
    "in_reply_to_status_id" : 98820134046679040,
    "created_at" : "2011-08-03 20:23:59 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Bill Blevins",
      "screen_name" : "TravelerBill",
      "protected" : false,
      "id_str" : "18813704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641620834000470017\/lEGJMMV1_normal.jpg",
      "id" : 18813704,
      "verified" : false
    }
  },
  "id" : 98851945841827840,
  "created_at" : "2011-08-03 20:25:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thom Daugherty",
      "screen_name" : "ThomDaugherty",
      "indices" : [ 1, 15 ],
      "id_str" : "19303424",
      "id" : 19303424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http:\/\/t.co\/6fhJ7Sf",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2011\/07\/29\/remarks-president-fuel-efficiency-standards",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98851801092198400",
  "text" : ".@ThomDaugherty (2 of 2) just last week, POTUS announced historic agreement on natl fuel economy standards (http:\/\/t.co\/6fhJ7Sf) #WHChat",
  "id" : 98851801092198400,
  "created_at" : "2011-08-03 20:24:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thom Daugherty",
      "screen_name" : "ThomDaugherty",
      "indices" : [ 1, 15 ],
      "id_str" : "19303424",
      "id" : 19303424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/F7JFiiX",
      "expanded_url" : "http:\/\/www.fra.dot.gov\/rpd\/passenger\/2243.shtml",
      "display_url" : "fra.dot.gov\/rpd\/passenger\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98851341518118912",
  "text" : ".@ThomDaugherty (1 of 2) short answer: yes. POTUS HS rail program is moving forward (http:\/\/t.co\/F7JFiiX) and...",
  "id" : 98851341518118912,
  "created_at" : "2011-08-03 20:22:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thom Daugherty",
      "screen_name" : "ThomDaugherty",
      "indices" : [ 3, 17 ],
      "id_str" : "19303424",
      "id" : 19303424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98851088840671233",
  "text" : "RT @ThomDaugherty: Does the President still believe in a grand vision for bringing Highspeed Rail and Clean Energy to the U.S?. @Whiteho ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 109, 120 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 121, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98850617719656449",
    "text" : "Does the President still believe in a grand vision for bringing Highspeed Rail and Clean Energy to the U.S?. @Whitehouse #WHChat",
    "id" : 98850617719656449,
    "created_at" : "2011-08-03 20:19:58 +0000",
    "user" : {
      "name" : "Thom Daugherty",
      "screen_name" : "ThomDaugherty",
      "protected" : false,
      "id_str" : "19303424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/698005370099249152\/U6qcbMkK_normal.jpg",
      "id" : 19303424,
      "verified" : false
    }
  },
  "id" : 98851088840671233,
  "created_at" : "2011-08-03 20:21:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsten",
      "screen_name" : "KirstenWhitlock",
      "indices" : [ 1, 17 ],
      "id_str" : "166265111",
      "id" : 166265111
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98850700439732224",
  "text" : ".@KirstenWhitlock most impt is laying foundation 4 strong priv sector job growth; best govt role is w incentives; smart investments #WHChat",
  "id" : 98850700439732224,
  "created_at" : "2011-08-03 20:20:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98849953375461376",
  "text" : "RT @smalltowngrl93: #WHChat has any president and his family ever slid around the whitehouse in their socks?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98848727443308544",
    "text" : "#WHChat has any president and his family ever slid around the whitehouse in their socks?",
    "id" : 98848727443308544,
    "created_at" : "2011-08-03 20:12:27 +0000",
    "user" : {
      "name" : "Kelsey Higgins",
      "screen_name" : "khiggins93",
      "protected" : false,
      "id_str" : "271079965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751409778715426817\/kLwVITbZ_normal.jpg",
      "id" : 271079965,
      "verified" : false
    }
  },
  "id" : 98849953375461376,
  "created_at" : "2011-08-03 20:17:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhChat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98849869598425088",
  "text" : ".@smalltowngrl93 Don't know about presidents but I have been known to go shoeless at work from time to time. Not, w\/ potus, mind you #WhChat",
  "id" : 98849869598425088,
  "created_at" : "2011-08-03 20:17:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Epstein",
      "screen_name" : "epstein_laura",
      "indices" : [ 1, 15 ],
      "id_str" : "325165126",
      "id" : 325165126
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98848899472687104",
  "text" : ".@epstein_laura immediate steps: extend payroll tax cut worth ~$1k for typical family, unemployment insurance & infrastructure bank #WHChat",
  "id" : 98848899472687104,
  "created_at" : "2011-08-03 20:13:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Epstein",
      "screen_name" : "epstein_laura",
      "indices" : [ 3, 17 ],
      "id_str" : "325165126",
      "id" : 325165126
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "unemployment",
      "indices" : [ 102, 115 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98848493745078272",
  "text" : "RT @epstein_laura: @whitehouse What specific measures will Obama take or promote in order to decrease #unemployment? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "unemployment",
        "indices" : [ 83, 96 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 98, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98848022666035200",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse What specific measures will Obama take or promote in order to decrease #unemployment? #WHChat",
    "id" : 98848022666035200,
    "created_at" : "2011-08-03 20:09:39 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Laura Epstein",
      "screen_name" : "epstein_laura",
      "protected" : false,
      "id_str" : "325165126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771360942017970176\/wAl7rM02_normal.jpg",
      "id" : 325165126,
      "verified" : false
    }
  },
  "id" : 98848493745078272,
  "created_at" : "2011-08-03 20:11:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OVW",
      "screen_name" : "MinortyMajority",
      "indices" : [ 1, 17 ],
      "id_str" : "20727126",
      "id" : 20727126
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 45, 50 ]
    }, {
      "text" : "FAA",
      "indices" : [ 78, 82 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98848361058275329",
  "text" : ".@MinortyMajority Congress must act, 10ks of #jobs in the balance. Short term #FAA ext can be done today w\/o them returning to DC #WHChat",
  "id" : 98848361058275329,
  "created_at" : "2011-08-03 20:11:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OVW",
      "screen_name" : "MinortyMajority",
      "indices" : [ 3, 19 ],
      "id_str" : "20727126",
      "id" : 20727126
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 33, 40 ]
    }, {
      "text" : "FAA",
      "indices" : [ 41, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98847740833972225",
  "text" : "RT @MinortyMajority: @whitehouse #WHChat #FAA why don't you threaten to shutdown airports because of lack of FAA funding.  Time to play  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 12, 19 ]
      }, {
        "text" : "FAA",
        "indices" : [ 20, 24 ]
      }, {
        "text" : "Hardball",
        "indices" : [ 115, 124 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "98820134046679040",
    "geo" : { },
    "id_str" : "98823832328089600",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #WHChat #FAA why don't you threaten to shutdown airports because of lack of FAA funding.  Time to play #Hardball!",
    "id" : 98823832328089600,
    "in_reply_to_status_id" : 98820134046679040,
    "created_at" : "2011-08-03 18:33:32 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "OVW",
      "screen_name" : "MinortyMajority",
      "protected" : false,
      "id_str" : "20727126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477291828211773440\/8GH2ZspQ_normal.jpeg",
      "id" : 20727126,
      "verified" : false
    }
  },
  "id" : 98847740833972225,
  "created_at" : "2011-08-03 20:08:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98847482053799936",
  "text" : "Hi all, I'm here and ready to answer your questions. -Brian #WHChat",
  "id" : 98847482053799936,
  "created_at" : "2011-08-03 20:07:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98846967022624768",
  "text" : "Brian Deese from the National Economic Council will be here soon for Office Hours. Use #whchat to ask your ?s on the debt compromise.",
  "id" : 98846967022624768,
  "created_at" : "2011-08-03 20:05:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 24, 31 ]
    }, {
      "text" : "debt",
      "indices" : [ 54, 59 ]
    }, {
      "text" : "compromise",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98820134046679040",
  "text" : "Office Hours today: Use #WHChat to ask your Qs on the #debt #compromise & economy. Obama's econ advisor will be here @ 4ET to answer.",
  "id" : 98820134046679040,
  "created_at" : "2011-08-03 18:18:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 26, 37 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 40, 51 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 59, 67 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/C4VjnKa",
      "expanded_url" : "http:\/\/bit.ly\/qszO7x",
      "display_url" : "bit.ly\/qszO7x"
    } ]
  },
  "geo" : { },
  "id_str" : "98814807062478848",
  "text" : "RT @macon44: Now reading: @whitehouse's @Pfeiffer44 on how @Twitter pressured Congress to act on debt ceiling bill : http:\/\/t.co\/C4VjnKa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 13, 24 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 27, 38 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      }, {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 46, 54 ],
        "id_str" : "783214",
        "id" : 783214
      }, {
        "name" : "CBS News",
        "screen_name" : "CBSNews",
        "indices" : [ 124, 132 ],
        "id_str" : "15012486",
        "id" : 15012486
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 123 ],
        "url" : "http:\/\/t.co\/C4VjnKa",
        "expanded_url" : "http:\/\/bit.ly\/qszO7x",
        "display_url" : "bit.ly\/qszO7x"
      } ]
    },
    "geo" : { },
    "id_str" : "98814113148452864",
    "text" : "Now reading: @whitehouse's @Pfeiffer44 on how @Twitter pressured Congress to act on debt ceiling bill : http:\/\/t.co\/C4VjnKa @CBSNews",
    "id" : 98814113148452864,
    "created_at" : "2011-08-03 17:54:55 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 98814807062478848,
  "created_at" : "2011-08-03 17:57:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FAA",
      "indices" : [ 21, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98778281800773632",
  "text" : "RT @pfeiffer44 4,000 #FAA workers & 70,000 construction workers are out of work in Aug bc they are ensared in a political fight goo.gl\/iNZB3",
  "id" : 98778281800773632,
  "created_at" : "2011-08-03 15:32:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 86, 93 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/U5bljOH",
      "expanded_url" : "http:\/\/1.usa.gov\/oWiZWb",
      "display_url" : "1.usa.gov\/oWiZWb"
    } ]
  },
  "geo" : { },
  "id_str" : "98775117609451520",
  "text" : "The SBA 100: 100 small businesses that have created at least 100 jobs since receiving @SBAgov assistance. http:\/\/t.co\/U5bljOH",
  "id" : 98775117609451520,
  "created_at" : "2011-08-03 15:19:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 121, 131 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/nqIVQBC",
      "expanded_url" : "http:\/\/wh.gov\/rPS",
      "display_url" : "wh.gov\/rPS"
    } ]
  },
  "geo" : { },
  "id_str" : "98754303044485120",
  "text" : "Photo Slideshow: Go behind the scenes at the White House during the debt & deficit negotiations: http:\/\/t.co\/nqIVQBC cc: @petesouza",
  "id" : 98754303044485120,
  "created_at" : "2011-08-03 13:57:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/PeXb7Dc",
      "expanded_url" : "http:\/\/www.wh.gov\/internships",
      "display_url" : "wh.gov\/internships"
    } ]
  },
  "geo" : { },
  "id_str" : "98748402476646401",
  "text" : "The White House Internship -- application period for Spring '12 is now open. Learn more & apply: http:\/\/t.co\/PeXb7Dc",
  "id" : 98748402476646401,
  "created_at" : "2011-08-03 13:33:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98541026695847936",
  "text" : "Photo of the Day: President Obama works on his remarks on the debt compromise (video: http:\/\/wh.gov\/rPR) Pic: http:\/\/twitpic.com\/6026fx",
  "id" : 98541026695847936,
  "created_at" : "2011-08-02 23:49:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 101, 108 ]
    }, {
      "text" : "WHWeb",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/cGGixIf",
      "expanded_url" : "http:\/\/wh.gov\/rEI",
      "display_url" : "wh.gov\/rEI"
    } ]
  },
  "geo" : { },
  "id_str" : "98536569291550720",
  "text" : "Today's Office Hours on the debt compromise posted here: http:\/\/t.co\/cGGixIf What do you think about #WHChat? Give us feedback w\/ #WHWeb",
  "id" : 98536569291550720,
  "created_at" : "2011-08-02 23:32:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/dPJGr0m",
      "expanded_url" : "http:\/\/twitpic.com\/6011a2",
      "display_url" : "twitpic.com\/6011a2"
    } ]
  },
  "geo" : { },
  "id_str" : "98521879492575233",
  "text" : "RT @NASA: President Obama looks at a photo presented to him while meeting with the crew of the Space Shuttle Endeavour http:\/\/t.co\/dPJGr0m",
  "id" : 98521879492575233,
  "created_at" : "2011-08-02 22:33:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4pm",
      "screen_name" : "4pm",
      "indices" : [ 114, 118 ],
      "id_str" : "16623843",
      "id" : 16623843
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98498903011360768",
  "text" : "Been great answering your questions, apologies for the hundreds my fingers not quick enough for, Brian Deese back @4pm tomorrow, #WHchat",
  "id" : 98498903011360768,
  "created_at" : "2011-08-02 21:02:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Puppy mom",
      "screen_name" : "PWelu",
      "indices" : [ 3, 9 ],
      "id_str" : "330398768",
      "id" : 330398768
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 11, 22 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98498402316337152",
  "text" : "RT @PWelu: @whitehouse  What if R's put people on that block revenue #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98497830154547200",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse  What if R's put people on that block revenue #WHchat",
    "id" : 98497830154547200,
    "created_at" : "2011-08-02 20:58:07 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Puppy mom",
      "screen_name" : "PWelu",
      "protected" : false,
      "id_str" : "330398768",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797777283683680257\/ndWJS5eM_normal.jpg",
      "id" : 330398768,
      "verified" : false
    }
  },
  "id" : 98498402316337152,
  "created_at" : "2011-08-02 21:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hiram Abiff",
      "screen_name" : "SCNAK45",
      "indices" : [ 1, 9 ],
      "id_str" : "214507554",
      "id" : 214507554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98497988162367488",
  "text" : ".@SCNAK45: Debt ceiling increase pays for past bills. This new law also cuts future spending, brings down future debt. #WHchat",
  "id" : 98497988162367488,
  "created_at" : "2011-08-02 20:58:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Kline",
      "screen_name" : "kline_m",
      "indices" : [ 1, 9 ],
      "id_str" : "305035216",
      "id" : 305035216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98497574125842432",
  "text" : ".@kline_m: This deal includes new $$ for Pell. Our Budgets have shown you can increase investment while cutting wasteful spending. #WHchat",
  "id" : 98497574125842432,
  "created_at" : "2011-08-02 20:57:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Kline",
      "screen_name" : "kline_m",
      "indices" : [ 3, 11 ],
      "id_str" : "305035216",
      "id" : 305035216
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98497232856301568",
  "text" : "RT @kline_m: @whitehouse Where will POTUS get $$$ for innovation & infrastructure & education THIS YEAR if $1T in cuts are coming? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 118, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98496595930267648",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Where will POTUS get $$$ for innovation & infrastructure & education THIS YEAR if $1T in cuts are coming? #WHChat",
    "id" : 98496595930267648,
    "created_at" : "2011-08-02 20:53:13 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Michael Kline",
      "screen_name" : "kline_m",
      "protected" : false,
      "id_str" : "305035216",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757781759576518657\/A7XjKTF2_normal.jpg",
      "id" : 305035216,
      "verified" : false
    }
  },
  "id" : 98497232856301568,
  "created_at" : "2011-08-02 20:55:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98496649151791106",
  "text" : ".@mattblainkimble: $1T in deficit reduction a meaningful downpayment. Much more needs 2 b done. Deal sets up structure 4 more action #WHchat",
  "id" : 98496649151791106,
  "created_at" : "2011-08-02 20:53:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98496301666275328",
  "text" : "RT @mattblainkimble: @whitehouse Do you agree with the comments that this deal does not address the actual issues, & if so will the comm ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98495765042823168",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Do you agree with the comments that this deal does not address the actual issues, & if so will the committee solve them? #whchat",
    "id" : 98495765042823168,
    "created_at" : "2011-08-02 20:49:55 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Matthew Kimble",
      "screen_name" : "mattblain25",
      "protected" : false,
      "id_str" : "265852536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464082043333124097\/oetKO_wK_normal.jpeg",
      "id" : 265852536,
      "verified" : false
    }
  },
  "id" : 98496301666275328,
  "created_at" : "2011-08-02 20:52:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Dobolina",
      "screen_name" : "bobdobolina",
      "indices" : [ 1, 13 ],
      "id_str" : "1714842710",
      "id" : 1714842710
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98496101082079232",
  "text" : ".@bobdobolina: Tax cuts expire after 2012. If necessary, POTUS can use veto pen to prevent $1T added deficit from tax cuts for rich #WHchat",
  "id" : 98496101082079232,
  "created_at" : "2011-08-02 20:51:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "C. Michael McLeod",
      "screen_name" : "CMichaelMcLeod",
      "indices" : [ 1, 16 ],
      "id_str" : "341794240",
      "id" : 341794240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98495132764090368",
  "text" : ".@CMichaelMcLeod: We want tax reform, not a one-time break for a few corporations. American companies have $1T+ in US already #WHchat",
  "id" : 98495132764090368,
  "created_at" : "2011-08-02 20:47:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kanav",
      "screen_name" : "kanavjain",
      "indices" : [ 1, 11 ],
      "id_str" : "760675458786570240",
      "id" : 760675458786570240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHWeb",
      "indices" : [ 69, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98495044734029825",
  "text" : ".@kanavjain: Thanks -- we're always looking for ways to improve. Use #WHWeb to send feedback on Office Hours & the online program.",
  "id" : 98495044734029825,
  "created_at" : "2011-08-02 20:47:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kanav",
      "screen_name" : "kanavjain",
      "indices" : [ 3, 13 ],
      "id_str" : "760675458786570240",
      "id" : 760675458786570240
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98494524770369536",
  "text" : "RT @kanavjain: Really impressed with this #WHchat thing going on. Keep it up.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 27, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98494050113560576",
    "text" : "Really impressed with this #WHchat thing going on. Keep it up.",
    "id" : 98494050113560576,
    "created_at" : "2011-08-02 20:43:06 +0000",
    "user" : {
      "name" : "Bread SF",
      "screen_name" : "breadsf",
      "protected" : false,
      "id_str" : "14509772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783830826496634881\/RfiKXHdu_normal.jpg",
      "id" : 14509772,
      "verified" : false
    }
  },
  "id" : 98494524770369536,
  "created_at" : "2011-08-02 20:44:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Think Gooder Nasty",
      "screen_name" : "StillJohnCA",
      "indices" : [ 1, 13 ],
      "id_str" : "292560045",
      "id" : 292560045
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98494372680708096",
  "text" : ".@StillJohnCA: Yes #WHchat",
  "id" : 98494372680708096,
  "created_at" : "2011-08-02 20:44:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Think Gooder Nasty",
      "screen_name" : "StillJohnCA",
      "indices" : [ 3, 15 ],
      "id_str" : "292560045",
      "id" : 292560045
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "lindahk",
      "screen_name" : "lindahk",
      "indices" : [ 29, 37 ],
      "id_str" : "17912294",
      "id" : 17912294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98494231559159809",
  "text" : "RT @StillJohnCA: @whitehouse @lindahk Thank you!  We didn't close the loopholes with THIS deal.  We can still close them later?  Yes?  # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "lindahk",
        "screen_name" : "lindahk",
        "indices" : [ 12, 20 ],
        "id_str" : "17912294",
        "id" : 17912294
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 118, 125 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "98493551394045952",
    "geo" : { },
    "id_str" : "98493980555227136",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse @lindahk Thank you!  We didn't close the loopholes with THIS deal.  We can still close them later?  Yes?  #whchat",
    "id" : 98493980555227136,
    "in_reply_to_status_id" : 98493551394045952,
    "created_at" : "2011-08-02 20:42:49 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Think Gooder Nasty",
      "screen_name" : "StillJohnCA",
      "protected" : false,
      "id_str" : "292560045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792596546982338560\/6FZAR7CN_normal.jpg",
      "id" : 292560045,
      "verified" : false
    }
  },
  "id" : 98494231559159809,
  "created_at" : "2011-08-02 20:43:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98494088197840896",
  "text" : ".@booth088: Yes, Congress must pass Committee bill and POTUS must sign. But legislation stops filibusters and other delays. #WHchat",
  "id" : 98494088197840896,
  "created_at" : "2011-08-02 20:43:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98493863144062976",
  "text" : "RT @booth088: @whitehouse Does what is approved by the committee need to then pass both chambers and be signed by the president?? #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 116, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98493058110332928",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Does what is approved by the committee need to then pass both chambers and be signed by the president?? #whchat",
    "id" : 98493058110332928,
    "created_at" : "2011-08-02 20:39:09 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Aaron Booth",
      "screen_name" : "ActorAaronBooth",
      "protected" : false,
      "id_str" : "39421059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796944670899240960\/0l2jvSG__normal.jpg",
      "id" : 39421059,
      "verified" : false
    }
  },
  "id" : 98493863144062976,
  "created_at" : "2011-08-02 20:42:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lindahk",
      "screen_name" : "lindahk",
      "indices" : [ 1, 9 ],
      "id_str" : "17912294",
      "id" : 17912294
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98493551394045952",
  "text" : ".@lindahk: Yes. And reforms to critical spending programs too. #WHchat",
  "id" : 98493551394045952,
  "created_at" : "2011-08-02 20:41:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lindahk",
      "screen_name" : "lindahk",
      "indices" : [ 3, 11 ],
      "id_str" : "17912294",
      "id" : 17912294
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98493416094171136",
  "text" : "RT @lindahk: @whitehouse when will POTUS begin round 2 fight to reform tax code\/eliminate wealth perks for balanced plan?  #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98493243544707073",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse when will POTUS begin round 2 fight to reform tax code\/eliminate wealth perks for balanced plan?  #whchat",
    "id" : 98493243544707073,
    "created_at" : "2011-08-02 20:39:53 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "lindahk",
      "screen_name" : "lindahk",
      "protected" : false,
      "id_str" : "17912294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791395554106441729\/bxhn5noJ_normal.jpg",
      "id" : 17912294,
      "verified" : false
    }
  },
  "id" : 98493416094171136,
  "created_at" : "2011-08-02 20:40:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/98493295403077632\/photo\/1",
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/2LwHKWt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AV3rIV2CEAAjrxd.jpg",
      "id_str" : "98493295407271936",
      "id" : 98493295407271936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AV3rIV2CEAAjrxd.jpg",
      "sizes" : [ {
        "h" : 395,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2LwHKWt"
    } ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 56, 61 ]
    }, {
      "text" : "whchat",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98493295403077632",
  "text" : "Pic: Jason Furman from NEC is back answering Q\u2019s on the #debt deal for WH Office Hours. Use #whchat to join the Q&A. http:\/\/t.co\/2LwHKWt",
  "id" : 98493295403077632,
  "created_at" : "2011-08-02 20:40:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98493189610143744",
  "text" : ".@KiserRoll: With 9% unemployment, can't afford uncertainty. For long run, need investment, innovation, infrastructure, education. #WHchat",
  "id" : 98493189610143744,
  "created_at" : "2011-08-02 20:39:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lizzie Cain",
      "screen_name" : "lizzie_cain",
      "indices" : [ 1, 13 ],
      "id_str" : "125985019",
      "id" : 125985019
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98492611827994624",
  "text" : ".@lizzie_cain: This agreement sets spending levels for security and nonsecurity for the next fiscal year. Should make process easier #WHchat",
  "id" : 98492611827994624,
  "created_at" : "2011-08-02 20:37:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lizzie Cain",
      "screen_name" : "lizzie_cain",
      "indices" : [ 3, 15 ],
      "id_str" : "125985019",
      "id" : 125985019
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98492293568401408",
  "text" : "RT @lizzie_cain: @whitehouse Federal fiscal year ends in 60 days. Should we prepare for another year of shutdown threats and last-minute ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98491924771635200",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Federal fiscal year ends in 60 days. Should we prepare for another year of shutdown threats and last-minute CRs? #whchat",
    "id" : 98491924771635200,
    "created_at" : "2011-08-02 20:34:39 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Lizzie Cain",
      "screen_name" : "lizzie_cain",
      "protected" : false,
      "id_str" : "125985019",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542505092151132162\/NLcE5rL6_normal.jpeg",
      "id" : 125985019,
      "verified" : false
    }
  },
  "id" : 98492293568401408,
  "created_at" : "2011-08-02 20:36:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spencer Welch",
      "screen_name" : "SpencerGWelch",
      "indices" : [ 1, 15 ],
      "id_str" : "765034835966472192",
      "id" : 765034835966472192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98492137905201152",
  "text" : ".@SpencerGWelch: Yes, bipartisan committee can propose spending or revenue. Everything on table. POTUS pushing for balanced approach #WHchat",
  "id" : 98492137905201152,
  "created_at" : "2011-08-02 20:35:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McLeod",
      "screen_name" : "Ryan__McLeod",
      "indices" : [ 1, 14 ],
      "id_str" : "89575091",
      "id" : 89575091
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98491680709292033",
  "text" : ".@Ryan__McLeod: POTUS called on Congress on FAA in his remarks today, terrible to leave with 1000s on furlough and investments cut #WHchat",
  "id" : 98491680709292033,
  "created_at" : "2011-08-02 20:33:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kayakyakr",
      "screen_name" : "kayakyakr",
      "indices" : [ 3, 13 ],
      "id_str" : "13652622",
      "id" : 13652622
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 104, 115 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98491474177556480",
  "text" : "RT @kayakyakr: Ha, fair enough, knew it needed a long answer when I asked. Hope you can get it done! RT @whitehouse: rest more than 140  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twittergadget.com\" rel=\"nofollow\"\u003EtGadget\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 89, 100 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98491041090506752",
    "text" : "Ha, fair enough, knew it needed a long answer when I asked. Hope you can get it done! RT @whitehouse: rest more than 140 chars #WHchat",
    "id" : 98491041090506752,
    "created_at" : "2011-08-02 20:31:08 +0000",
    "user" : {
      "name" : "kayakyakr",
      "screen_name" : "kayakyakr",
      "protected" : false,
      "id_str" : "13652622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1562300977\/yakyak_normal.png",
      "id" : 13652622,
      "verified" : false
    }
  },
  "id" : 98491474177556480,
  "created_at" : "2011-08-02 20:32:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McLeod",
      "screen_name" : "Ryan__McLeod",
      "indices" : [ 3, 16 ],
      "id_str" : "89575091",
      "id" : 89575091
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98491245550252033",
  "text" : "RT @Ryan__McLeod: #WHchat what's up with FAA? We're losing $1.2 billion in tax revenue while Congress vacations, and the airlines are po ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98490712835887104",
    "text" : "#WHchat what's up with FAA? We're losing $1.2 billion in tax revenue while Congress vacations, and the airlines are pocketing it.",
    "id" : 98490712835887104,
    "created_at" : "2011-08-02 20:29:50 +0000",
    "user" : {
      "name" : "Ryan McLeod",
      "screen_name" : "Ryan__McLeod",
      "protected" : false,
      "id_str" : "89575091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/483189545026850816\/UphQfbo9_normal.jpeg",
      "id" : 89575091,
      "verified" : false
    }
  },
  "id" : 98491245550252033,
  "created_at" : "2011-08-02 20:31:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Jackson",
      "screen_name" : "joshuaj13",
      "indices" : [ 1, 11 ],
      "id_str" : "55983507",
      "id" : 55983507
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98491028805394433",
  "text" : ".@joshuaj13: This deal will help by removing cloud of uncertainty. But much more to do, especially on jobs. #WHchat",
  "id" : 98491028805394433,
  "created_at" : "2011-08-02 20:31:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Jackson",
      "screen_name" : "joshuaj13",
      "indices" : [ 3, 13 ],
      "id_str" : "55983507",
      "id" : 55983507
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 41, 46 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98490859904958465",
  "text" : "RT @joshuaj13: @whitehouse How will this #debt deal help this econmy? REPLY!?(: #WHChat.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debt",
        "indices" : [ 26, 31 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "98479832270245888",
    "geo" : { },
    "id_str" : "98480974286946304",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse How will this #debt deal help this econmy? REPLY!?(: #WHChat.",
    "id" : 98480974286946304,
    "in_reply_to_status_id" : 98479832270245888,
    "created_at" : "2011-08-02 19:51:08 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Joshua Jackson",
      "screen_name" : "joshuaj13",
      "protected" : false,
      "id_str" : "55983507",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1650317035\/7e2f2f2d-e7e1-4de6-9838-a1c363c10cea_normal.png",
      "id" : 55983507,
      "verified" : false
    }
  },
  "id" : 98490859904958465,
  "created_at" : "2011-08-02 20:30:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sibsNY",
      "screen_name" : "SibsNY",
      "indices" : [ 1, 8 ],
      "id_str" : "338111416",
      "id" : 338111416
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98490528672395264",
  "text" : ".@SibsNY: Medicaid not cut by this agreement. Not in the initial about $1 trillion of deficit reduction. Not in the trigger. #WHchat",
  "id" : 98490528672395264,
  "created_at" : "2011-08-02 20:29:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kayakyakr",
      "screen_name" : "kayakyakr",
      "indices" : [ 1, 11 ],
      "id_str" : "13652622",
      "id" : 13652622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 102, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98490068087476224",
  "text" : ".@kayakyakr: Simpler, better for growth, progressive, rest of details are more than 140 characters... #WHchat",
  "id" : 98490068087476224,
  "created_at" : "2011-08-02 20:27:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sibsNY",
      "screen_name" : "SibsNY",
      "indices" : [ 3, 10 ],
      "id_str" : "338111416",
      "id" : 338111416
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98490033924882433",
  "text" : "RT @SibsNY: #whchat Medicaid supports the quality of life for those w\/dvlpmental disabilities. How is Medicaid affected by this new deal?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98489699664007168",
    "text" : "#whchat Medicaid supports the quality of life for those w\/dvlpmental disabilities. How is Medicaid affected by this new deal?",
    "id" : 98489699664007168,
    "created_at" : "2011-08-02 20:25:48 +0000",
    "user" : {
      "name" : "sibsNY",
      "screen_name" : "SibsNY",
      "protected" : false,
      "id_str" : "338111416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1474842606\/logo4_normal.PNG",
      "id" : 338111416,
      "verified" : false
    }
  },
  "id" : 98490033924882433,
  "created_at" : "2011-08-02 20:27:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kayakyakr",
      "screen_name" : "kayakyakr",
      "indices" : [ 3, 13 ],
      "id_str" : "13652622",
      "id" : 13652622
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98489849828487168",
  "text" : "RT @kayakyakr: Dream situation, Jason, what would your ideal tax reform look like? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twittergadget.com\" rel=\"nofollow\"\u003EtGadget\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98483322501611520",
    "text" : "Dream situation, Jason, what would your ideal tax reform look like? #WHChat",
    "id" : 98483322501611520,
    "created_at" : "2011-08-02 20:00:28 +0000",
    "user" : {
      "name" : "kayakyakr",
      "screen_name" : "kayakyakr",
      "protected" : false,
      "id_str" : "13652622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1562300977\/yakyak_normal.png",
      "id" : 13652622,
      "verified" : false
    }
  },
  "id" : 98489849828487168,
  "created_at" : "2011-08-02 20:26:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Smith",
      "screen_name" : "jasonasmith",
      "indices" : [ 1, 13 ],
      "id_str" : "11742782",
      "id" : 11742782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98488980512845825",
  "text" : ".@jasonasmith Triggers are 2 motivate supercommittee, if it succeeds doesn't happen. Cuts r 50-50 defense & nondefense, motivate all #WHchat",
  "id" : 98488980512845825,
  "created_at" : "2011-08-02 20:22:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Smith",
      "screen_name" : "jasonasmith",
      "indices" : [ 3, 15 ],
      "id_str" : "11742782",
      "id" : 11742782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98488235939999744",
  "text" : "RT @jasonasmith: Are the \"triggered cuts\" from \"super congress\" failure basically what the TeaParty GOP wanted in the first place? #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 114, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98487186160222208",
    "text" : "Are the \"triggered cuts\" from \"super congress\" failure basically what the TeaParty GOP wanted in the first place? #WHchat",
    "id" : 98487186160222208,
    "created_at" : "2011-08-02 20:15:49 +0000",
    "user" : {
      "name" : "Jason Smith",
      "screen_name" : "jasonasmith",
      "protected" : false,
      "id_str" : "11742782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1815906920\/School_Pic_2_normal.jpg",
      "id" : 11742782,
      "verified" : false
    }
  },
  "id" : 98488235939999744,
  "created_at" : "2011-08-02 20:19:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "c culbertson",
      "screen_name" : "charlee1114",
      "indices" : [ 1, 13 ],
      "id_str" : "173237798",
      "id" : 173237798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98488194164723712",
  "text" : ".@charlee1114: Each Congressional leader (Boehner, Reid, Pelosi, McConnell) appoints 3, so = Ds & Rs. Law says appts within 14 days #WHchat",
  "id" : 98488194164723712,
  "created_at" : "2011-08-02 20:19:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StabbyCerberus",
      "screen_name" : "StabbyCerberus",
      "indices" : [ 1, 16 ],
      "id_str" : "224687867",
      "id" : 224687867
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98487561328148480",
  "text" : ".@StabbyCerberus: WH economic team not taking the week off, working hard on jobs ideas, also building on this deficit downpayment #WHchat",
  "id" : 98487561328148480,
  "created_at" : "2011-08-02 20:17:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StabbyCerberus",
      "screen_name" : "StabbyCerberus",
      "indices" : [ 3, 18 ],
      "id_str" : "224687867",
      "id" : 224687867
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98487145379012608",
  "text" : "RT @StabbyCerberus: @whitehouse Since this is a done deal for the moment, could we please take the rest of the week off from hearing any ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "98479832270245888",
    "geo" : { },
    "id_str" : "98481893498040322",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Since this is a done deal for the moment, could we please take the rest of the week off from hearing anymore about it? #WHChat",
    "id" : 98481893498040322,
    "in_reply_to_status_id" : 98479832270245888,
    "created_at" : "2011-08-02 19:54:47 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "StabbyCerberus",
      "screen_name" : "StabbyCerberus",
      "protected" : false,
      "id_str" : "224687867",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1259870501\/Cerberus_normal.jpg",
      "id" : 224687867,
      "verified" : false
    }
  },
  "id" : 98487145379012608,
  "created_at" : "2011-08-02 20:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karin",
      "screen_name" : "kkyarb",
      "indices" : [ 1, 8 ],
      "id_str" : "211529834",
      "id" : 211529834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98486998582575105",
  "text" : ".@kkyarb: Cuts phased in over time, critical protections for Pell, but need more on jobs: payroll tax cut, UI, infrastructure #WHchat",
  "id" : 98486998582575105,
  "created_at" : "2011-08-02 20:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karin",
      "screen_name" : "kkyarb",
      "indices" : [ 3, 10 ],
      "id_str" : "211529834",
      "id" : 211529834
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98486639457869824",
  "text" : "RT @kkyarb: @whitehouse Why the heck are we cutting when history shows that only will drive us further into a depression?  #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98480860281581569",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Why the heck are we cutting when history shows that only will drive us further into a depression?  #whchat",
    "id" : 98480860281581569,
    "created_at" : "2011-08-02 19:50:41 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Karin",
      "screen_name" : "kkyarb",
      "protected" : false,
      "id_str" : "211529834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1831757330\/evilmonster_normal.jpg",
      "id" : 211529834,
      "verified" : false
    }
  },
  "id" : 98486639457869824,
  "created_at" : "2011-08-02 20:13:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 30, 41 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98486572189622274",
  "text" : ".@So1omonW1se: No. Both sides #compromise. Rs did not get Medicare vouchers, $1.2T of Medicaid cuts, & over $100b of food stamp cuts #WHchat",
  "id" : 98486572189622274,
  "created_at" : "2011-08-02 20:13:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98486169448353792",
  "text" : "RT @So1omonW1se: @whitehouse Why did the President and all the Democrats cave and give Republicans 98% of what they wanted? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "98475366749974529",
    "geo" : { },
    "id_str" : "98481103752544256",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Why did the President and all the Democrats cave and give Republicans 98% of what they wanted? #WHChat",
    "id" : 98481103752544256,
    "in_reply_to_status_id" : 98475366749974529,
    "created_at" : "2011-08-02 19:51:39 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Aaron Jones",
      "screen_name" : "Aaron_Jones_Jr",
      "protected" : false,
      "id_str" : "327677162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695512399428718592\/AxxsGtVx_normal.jpg",
      "id" : 327677162,
      "verified" : false
    }
  },
  "id" : 98486169448353792,
  "created_at" : "2011-08-02 20:11:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Broz",
      "screen_name" : "brozm1990",
      "indices" : [ 1, 11 ],
      "id_str" : "150474094",
      "id" : 150474094
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 45, 56 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98486036908351488",
  "text" : ".@brozm1990: The American people won in this #compromise. Sets up a second stage and we'll be pushing for balanced deficit reduction #WHchat",
  "id" : 98486036908351488,
  "created_at" : "2011-08-02 20:11:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Broz",
      "screen_name" : "brozm1990",
      "indices" : [ 3, 13 ],
      "id_str" : "150474094",
      "id" : 150474094
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98485652433272832",
  "text" : "RT @brozm1990: Did any of the tax loopholes for the rich get closed or did they win this debt deal? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 85, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98483896332722176",
    "text" : "Did any of the tax loopholes for the rich get closed or did they win this debt deal? #WHChat",
    "id" : 98483896332722176,
    "created_at" : "2011-08-02 20:02:45 +0000",
    "user" : {
      "name" : "Michael Broz",
      "screen_name" : "brozm1990",
      "protected" : false,
      "id_str" : "150474094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795010496265154560\/x4BM4mHt_normal.jpg",
      "id" : 150474094,
      "verified" : false
    }
  },
  "id" : 98485652433272832,
  "created_at" : "2011-08-02 20:09:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98485544165711872",
  "text" : "Hello, Jason Furman here and looking forward to your questions, #WHchat.",
  "id" : 98485544165711872,
  "created_at" : "2011-08-02 20:09:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 93, 98 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98479832270245888",
  "text" : "Office Hours w\/ Obama's economic advisor Jason Furman start @ 4ET. Ask your questions on the #debt deal & economy w\/ #WHChat.",
  "id" : 98479832270245888,
  "created_at" : "2011-08-02 19:46:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 32, 37 ]
    }, {
      "text" : "compromise",
      "indices" : [ 38, 49 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 70 ],
      "url" : "http:\/\/t.co\/yxppepY",
      "expanded_url" : "http:\/\/wh.gov\/rPR",
      "display_url" : "wh.gov\/rPR"
    } ]
  },
  "geo" : { },
  "id_str" : "98475366749974529",
  "text" : "Video: Obama's statement on the #debt #compromise: http:\/\/t.co\/yxppepY Have Q's? #WHChat w\/ WH economist Jason Furman starts @ 4ET.",
  "id" : 98475366749974529,
  "created_at" : "2011-08-02 19:28:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 46, 59 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 60, 70 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "John Doerr",
      "screen_name" : "johndoerr",
      "indices" : [ 71, 81 ],
      "id_str" : "22255654",
      "id" : 22255654
    }, {
      "name" : "Sheryl Sandberg",
      "screen_name" : "sherylsandberg",
      "indices" : [ 82, 97 ],
      "id_str" : "19506790",
      "id" : 19506790
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsCouncil",
      "indices" : [ 28, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/RFX8sAu",
      "expanded_url" : "https:\/\/apps.facebook.com\/whitehouselive\/",
      "display_url" : "apps.facebook.com\/whitehouselive\/"
    } ]
  },
  "geo" : { },
  "id_str" : "98458790004916224",
  "text" : "Have Qs for the President's #JobsCouncil? Ask @AneeshChopra @SteveCase @johndoerr @sherylsandberg on Facebook: http:\/\/t.co\/RFX8sAu",
  "id" : 98458790004916224,
  "created_at" : "2011-08-02 18:22:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98457219699441665",
  "text" : "RT @pfeiffer44: FYI: POTUS just signed the deficit reduction legislation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98454145178140672",
    "text" : "FYI: POTUS just signed the deficit reduction legislation.",
    "id" : 98454145178140672,
    "created_at" : "2011-08-02 18:04:32 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 98457219699441665,
  "created_at" : "2011-08-02 18:16:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsCouncil",
      "indices" : [ 27, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 107 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    }, {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/RFX8sAu",
      "expanded_url" : "https:\/\/apps.facebook.com\/whitehouselive\/",
      "display_url" : "apps.facebook.com\/whitehouselive\/"
    } ]
  },
  "geo" : { },
  "id_str" : "98444488934043648",
  "text" : "Happening Now: President\u2019s #JobsCouncil listening & action session in Palo Alto. Watch: http:\/\/t.co\/hOlVdV1 Discuss: http:\/\/t.co\/RFX8sAu",
  "id" : 98444488934043648,
  "created_at" : "2011-08-02 17:26:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 35, 40 ]
    }, {
      "text" : "compromise",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/ZQj8XeA",
      "expanded_url" : "http:\/\/www.wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "98441556486389760",
  "text" : "President Obama\u2019s statement on the #debt #compromise just concluded. Full remarks & video will be up soon on http:\/\/t.co\/ZQj8XeA",
  "id" : 98441556486389760,
  "created_at" : "2011-08-02 17:14:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98441484143038464",
  "text" : "POTUS: We\u2019ve got to do everything in our power to grow this economy & put America back to work.",
  "id" : 98441484143038464,
  "created_at" : "2011-08-02 17:14:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FAA",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98441090646028289",
  "text" : "POTUS: It\u2019s another Washington-inflicted wound on America & Congress needs to break that impasse now so folks can get back to work. #FAA",
  "id" : 98441090646028289,
  "created_at" : "2011-08-02 17:12:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aviation",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98441023235162113",
  "text" : "POTUS: Another stalemate in Congress right now involving our #aviation industry which has...put the jobs of tens of thousands of...at risk",
  "id" : 98441023235162113,
  "created_at" : "2011-08-02 17:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98440772042489857",
  "text" : "POTUS: We can cut the red tape that stops too many inventors & entrepreneurs from quickly turning new ideas into thriving businesses.",
  "id" : 98440772042489857,
  "created_at" : "2011-08-02 17:11:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98440705764106240",
  "text" : "POTUS: We need to begin by extending tax cuts for middle class families so that you have more money in your paychecks next year.",
  "id" : 98440705764106240,
  "created_at" : "2011-08-02 17:11:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98440557394800640",
  "text" : "RT @jesseclee44: Obama: \"uncertainty surrounding the raising of the debt ceiling\u2026more impediment to the full recovery we need\u2026we could h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98440419653849088",
    "text" : "Obama: \"uncertainty surrounding the raising of the debt ceiling\u2026more impediment to the full recovery we need\u2026we could have avoided entirely\"",
    "id" : 98440419653849088,
    "created_at" : "2011-08-02 17:09:59 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 98440557394800640,
  "created_at" : "2011-08-02 17:10:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98440437500608512",
  "text" : "POTUS: So, voters may have chosen divided government, but they sure didn\u2019t vote for dysfunctional government.",
  "id" : 98440437500608512,
  "created_at" : "2011-08-02 17:10:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98440054548074496",
  "text" : "POTUS: I\u2019ll continue to fight for what the American people care most about: new #jobs, higher wages & faster economic growth.",
  "id" : 98440054548074496,
  "created_at" : "2011-08-02 17:08:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98439861513621505",
  "text" : "POTUS: We can\u2019t balance the #budget on the backs of the very people who have borne the brunt of this recession.",
  "id" : 98439861513621505,
  "created_at" : "2011-08-02 17:07:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98439819260211200",
  "text" : "POTUS: It means getting rid of...tax loopholes that help billionaires pay a lower tax rate than teachers & nurses.",
  "id" : 98439819260211200,
  "created_at" : "2011-08-02 17:07:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98439708920655875",
  "text" : "POTUS: You can\u2019t close the deficit w\/ just spending cuts, we\u2019ll need a balanced approach where everything\u2019s on the table.",
  "id" : 98439708920655875,
  "created_at" : "2011-08-02 17:07:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98439566956040192",
  "text" : "POTUS: This #compromise guarantees more than $2 trillion in deficit reduction\u2026an important first step",
  "id" : 98439566956040192,
  "created_at" : "2011-08-02 17:06:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "compromise",
      "indices" : [ 35, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98439526548119552",
  "text" : "POTUS: Congress has now approved a #compromise to reduce the deficit & avert a default that would have devastated our economy.",
  "id" : 98439526548119552,
  "created_at" : "2011-08-02 17:06:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "98439490661646336",
  "text" : "Happening now: President Obama delivers a statement on the #debt deal. Watch live: http:\/\/t.co\/hOlVdV1 (we\u2019ll be live-tweeting here)",
  "id" : 98439490661646336,
  "created_at" : "2011-08-02 17:06:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98434897085075456",
  "text" : "RT @pfeiffer44: Compromise deficit deal has now passed House and Senate, POTUS will sign as soon as it gets to the White House",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98434425100042240",
    "text" : "Compromise deficit deal has now passed House and Senate, POTUS will sign as soon as it gets to the White House",
    "id" : 98434425100042240,
    "created_at" : "2011-08-02 16:46:10 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 98434897085075456,
  "created_at" : "2011-08-02 16:48:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 25, 34 ]
    }, {
      "text" : "transit",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98406560820232192",
  "text" : "RT @RayLaHood: America\u2019s #veterans and their families deserve convenient access to #transit services http:\/\/bit.ly\/pqC2Es",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "veterans",
        "indices" : [ 10, 19 ]
      }, {
        "text" : "transit",
        "indices" : [ 68, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98406211967397888",
    "text" : "America\u2019s #veterans and their families deserve convenient access to #transit services http:\/\/bit.ly\/pqC2Es",
    "id" : 98406211967397888,
    "created_at" : "2011-08-02 14:54:03 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 98406560820232192,
  "created_at" : "2011-08-02 14:55:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 71, 76 ]
    }, {
      "text" : "compromise",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "98401681028562944",
  "text" : "President Obama will deliver a statement after the Senate votes on the #debt #compromise. Watch live @ 12:15 ET: http:\/\/t.co\/hOlVdV1",
  "id" : 98401681028562944,
  "created_at" : "2011-08-02 14:36:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http:\/\/t.co\/VUlXIuq",
      "expanded_url" : "http:\/\/tinyurl.com\/3hps3ur",
      "display_url" : "tinyurl.com\/3hps3ur"
    } ]
  },
  "geo" : { },
  "id_str" : "98386660718424064",
  "text" : "RT @petesouza: Photo of potus mtg w US Amb to Syria: http:\/\/t.co\/VUlXIuq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 57 ],
        "url" : "http:\/\/t.co\/VUlXIuq",
        "expanded_url" : "http:\/\/tinyurl.com\/3hps3ur",
        "display_url" : "tinyurl.com\/3hps3ur"
      } ]
    },
    "geo" : { },
    "id_str" : "98120085574647808",
    "text" : "Photo of potus mtg w US Amb to Syria: http:\/\/t.co\/VUlXIuq",
    "id" : 98120085574647808,
    "created_at" : "2011-08-01 19:57:06 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 98386660718424064,
  "created_at" : "2011-08-02 13:36:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 40, 45 ]
    }, {
      "text" : "whchat",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 92 ],
      "url" : "http:\/\/t.co\/kZAAJ7D",
      "expanded_url" : "http:\/\/wh.gov\/rQd",
      "display_url" : "wh.gov\/rQd"
    } ]
  },
  "geo" : { },
  "id_str" : "98230226638749696",
  "text" : "Missed today's Office Hours? Q&A on the #debt deal & economy is up here: http:\/\/t.co\/kZAAJ7D Join us for another #whchat tomorrow @ 4ET.",
  "id" : 98230226638749696,
  "created_at" : "2011-08-02 03:14:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vivek Kundra",
      "screen_name" : "VivekKundra",
      "indices" : [ 3, 15 ],
      "id_str" : "16311483",
      "id" : 16311483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98216778458599425",
  "text" : "RT @VivekKundra: Serving our country as US CIO -- an honor and experience of a lifetime! My exit interview with Fortune. http:\/\/ow.ly\/5SFJC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98199623050600448",
    "text" : "Serving our country as US CIO -- an honor and experience of a lifetime! My exit interview with Fortune. http:\/\/ow.ly\/5SFJC",
    "id" : 98199623050600448,
    "created_at" : "2011-08-02 01:13:09 +0000",
    "user" : {
      "name" : "Vivek Kundra",
      "screen_name" : "VivekKundra",
      "protected" : false,
      "id_str" : "16311483",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1478371205\/n678648509_926138_647_normal.jpg",
      "id" : 16311483,
      "verified" : true
    }
  },
  "id" : 98216778458599425,
  "created_at" : "2011-08-02 02:21:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep_Giffords",
      "screen_name" : "Rep_Giffords",
      "indices" : [ 3, 16 ],
      "id_str" : "2484571640",
      "id" : 2484571640
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Capitol",
      "indices" : [ 22, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98172322439102465",
  "text" : "RT @Rep_Giffords: The #Capitol looks beautiful and I am honored to be at work tonight.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Capitol",
        "indices" : [ 4, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98169302674452480",
    "text" : "The #Capitol looks beautiful and I am honored to be at work tonight.",
    "id" : 98169302674452480,
    "created_at" : "2011-08-01 23:12:40 +0000",
    "user" : {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "protected" : false,
      "id_str" : "44177383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738723616485978117\/G9V0XAhU_normal.jpg",
      "id" : 44177383,
      "verified" : true
    }
  },
  "id" : 98172322439102465,
  "created_at" : "2011-08-01 23:24:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98171510501552128",
  "text" : "RT @VP: Came up to the House to say hi to Gabby and to thank Leader Pelosi.--- VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98171323221671936",
    "text" : "Came up to the House to say hi to Gabby and to thank Leader Pelosi.--- VP",
    "id" : 98171323221671936,
    "created_at" : "2011-08-01 23:20:42 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 98171510501552128,
  "created_at" : "2011-08-01 23:21:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep_Giffords",
      "screen_name" : "Rep_Giffords",
      "indices" : [ 3, 16 ],
      "id_str" : "2484571640",
      "id" : 2484571640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98168700317863936",
  "text" : "RT @Rep_Giffords: Gabrielle has returned to Washington to support a bipartisan bill to prevent economic crisis. Turn on C-SPAN now: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 133 ],
        "url" : "http:\/\/t.co\/ddhmVMB",
        "expanded_url" : "http:\/\/j.mp\/hmYxTM",
        "display_url" : "j.mp\/hmYxTM"
      } ]
    },
    "geo" : { },
    "id_str" : "98163913664892928",
    "text" : "Gabrielle has returned to Washington to support a bipartisan bill to prevent economic crisis. Turn on C-SPAN now: http:\/\/t.co\/ddhmVMB",
    "id" : 98163913664892928,
    "created_at" : "2011-08-01 22:51:15 +0000",
    "user" : {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "protected" : false,
      "id_str" : "44177383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738723616485978117\/G9V0XAhU_normal.jpg",
      "id" : 44177383,
      "verified" : true
    }
  },
  "id" : 98168700317863936,
  "created_at" : "2011-08-01 23:10:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 1, 8 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/GVkz2F2",
      "expanded_url" : "http:\/\/wh.gov\/rQD",
      "display_url" : "wh.gov\/rQD"
    } ]
  },
  "geo" : { },
  "id_str" : "98163728398286849",
  "text" : ".@HHSGov Sec Sebelius announces new guidelines for women\u2019s preventive services to help ensure quality healthcare: http:\/\/t.co\/GVkz2F2",
  "id" : 98163728398286849,
  "created_at" : "2011-08-01 22:50:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 87, 98 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 37, 44 ]
    }, {
      "text" : "whweb",
      "indices" : [ 50, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98159290845638656",
  "text" : "RT @macon44: Have feedback about the #whchat? Use #whweb to share your ideas about how @whitehouse can improve our online engagement",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 74, 85 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 24, 31 ]
      }, {
        "text" : "whweb",
        "indices" : [ 37, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98158738288017409",
    "text" : "Have feedback about the #whchat? Use #whweb to share your ideas about how @whitehouse can improve our online engagement",
    "id" : 98158738288017409,
    "created_at" : "2011-08-01 22:30:41 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 98159290845638656,
  "created_at" : "2011-08-01 22:32:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CSPAN",
      "screen_name" : "cspan",
      "indices" : [ 38, 44 ],
      "id_str" : "15675138",
      "id" : 15675138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98154596857430016",
  "text" : "House about to vote. Gotta go turn on @CSPAN. We'll be back tomorrow -Brian #WHChat",
  "id" : 98154596857430016,
  "created_at" : "2011-08-01 22:14:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 49 ],
      "url" : "http:\/\/t.co\/J2jr6xO",
      "expanded_url" : "http:\/\/emlab.berkeley.edu\/~card\/papers\/njmin-aer.pdf",
      "display_url" : "emlab.berkeley.edu\/~card\/papers\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98154033453338624",
  "text" : ".@RayKurilla sorry here it is http:\/\/t.co\/J2jr6xO",
  "id" : 98154033453338624,
  "created_at" : "2011-08-01 22:11:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98153892021415936",
  "text" : "RT @RayKurilla: @whitehouse link don't work #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 28, 35 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "98152327332106240",
    "geo" : { },
    "id_str" : "98153265421746176",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse link don't work #whchat",
    "id" : 98153265421746176,
    "in_reply_to_status_id" : 98152327332106240,
    "created_at" : "2011-08-01 22:08:56 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Uhohhotdog Gaming",
      "screen_name" : "uhohgames",
      "protected" : false,
      "id_str" : "66787038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788335569226960896\/kPmYtN_V_normal.jpg",
      "id" : 66787038,
      "verified" : false
    }
  },
  "id" : 98153892021415936,
  "created_at" : "2011-08-01 22:11:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliott",
      "screen_name" : "elliott_ep",
      "indices" : [ 1, 12 ],
      "id_str" : "56021009",
      "id" : 56021009
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98153393033461760",
  "text" : ".@elliott_ep potus drew a line on long-term ext to remove cloud of default. Rs demanded short term, but gave way. impt win 4 economy #WHChat",
  "id" : 98153393033461760,
  "created_at" : "2011-08-01 22:09:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elliott",
      "screen_name" : "elliott_ep",
      "indices" : [ 3, 14 ],
      "id_str" : "56021009",
      "id" : 56021009
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98152544076972032",
  "text" : "RT @elliott_ep: @whitehouse Does POTUS have the spine to use that veto pen? It looks like he's just going to do whatever GOP wants anywa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobileways.de\/gravity\" rel=\"nofollow\"\u003EGravity\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 122, 129 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "98150492508667904",
    "geo" : { },
    "id_str" : "98152094942494720",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Does POTUS have the spine to use that veto pen? It looks like he's just going to do whatever GOP wants anyway #WHchat",
    "id" : 98152094942494720,
    "in_reply_to_status_id" : 98150492508667904,
    "created_at" : "2011-08-01 22:04:17 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Elliott",
      "screen_name" : "elliott_ep",
      "protected" : false,
      "id_str" : "56021009",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/369334217\/eeep_normal.jpg",
      "id" : 56021009,
      "verified" : false
    }
  },
  "id" : 98152544076972032,
  "created_at" : "2011-08-01 22:06:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brennan Buxkemper",
      "screen_name" : "BrenBux",
      "indices" : [ 1, 9 ],
      "id_str" : "58537428",
      "id" : 58537428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/9JSzYSe",
      "expanded_url" : "http:\/\/www.emlab.berkeley.edu\/~card\/papers\/njmin-aer.pdf",
      "display_url" : "emlab.berkeley.edu\/~card\/papers\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98152327332106240",
  "text" : ".@BrenBux best data says no, min wage doesn't deter low-wage hiring. My former coworker Alan Krueger makes case here: http:\/\/t.co\/9JSzYSe",
  "id" : 98152327332106240,
  "created_at" : "2011-08-01 22:05:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brennan Buxkemper",
      "screen_name" : "BrenBux",
      "indices" : [ 3, 11 ],
      "id_str" : "58537428",
      "id" : 58537428
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98151275572641792",
  "text" : "RT @BrenBux: Does having a minimum wage law carry more of a detriment to the country? Ours is high compared to China's. #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98150364657885187",
    "text" : "Does having a minimum wage law carry more of a detriment to the country? Ours is high compared to China's. #WHChat",
    "id" : 98150364657885187,
    "created_at" : "2011-08-01 21:57:25 +0000",
    "user" : {
      "name" : "Brennan Buxkemper",
      "screen_name" : "BrenBux",
      "protected" : false,
      "id_str" : "58537428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3625171362\/7424eb6074a5320a8023c25c34adfaad_normal.jpeg",
      "id" : 58537428,
      "verified" : false
    }
  },
  "id" : 98151275572641792,
  "created_at" : "2011-08-01 22:01:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Clifton Whitley",
      "screen_name" : "CliftonR",
      "indices" : [ 1, 10 ],
      "id_str" : "35824051",
      "id" : 35824051
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98150492508667904",
  "text" : ".@CliftonR YouthBuild is great, others too. give ladders for kids to overcome odds. balanced caps give rm to keep invstmts like this #WHChat",
  "id" : 98150492508667904,
  "created_at" : "2011-08-01 21:57:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98149501948280832",
  "text" : ".@FordMalone joking aside, level of citizen engagement over the past week has been v important in the debate #WHChat",
  "id" : 98149501948280832,
  "created_at" : "2011-08-01 21:53:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex",
      "screen_name" : "alexlionh",
      "indices" : [ 1, 11 ],
      "id_str" : "172947906",
      "id" : 172947906
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98147906103689216",
  "text" : ".@alexlionh No. And on backup, potus has veto pen. #WHChat",
  "id" : 98147906103689216,
  "created_at" : "2011-08-01 21:47:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex",
      "screen_name" : "alexlionh",
      "indices" : [ 3, 13 ],
      "id_str" : "172947906",
      "id" : 172947906
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98147547423576064",
  "text" : "RT @alexlionh: Does the language of the compromise handcuff the WH's power to rollback upper bracket tax cuts? If so what is the Pres' b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98147164601065473",
    "text" : "Does the language of the compromise handcuff the WH's power to rollback upper bracket tax cuts? If so what is the Pres' backup plan? #WHChat",
    "id" : 98147164601065473,
    "created_at" : "2011-08-01 21:44:42 +0000",
    "user" : {
      "name" : "Alex",
      "screen_name" : "alexlionh",
      "protected" : false,
      "id_str" : "172947906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722600884870475776\/IoRtNiSw_normal.jpg",
      "id" : 172947906,
      "verified" : false
    }
  },
  "id" : 98147547423576064,
  "created_at" : "2011-08-01 21:46:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyCALLmeDUTCH",
      "screen_name" : "AllaboutDutch",
      "indices" : [ 1, 15 ],
      "id_str" : "121854689",
      "id" : 121854689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98147255068008449",
  "text" : ".@AllaboutDutch potus focus is jobs. avoiding default removes econ headwind, but we need more: payroll tax cut, UI & infrastructure #WHChat",
  "id" : 98147255068008449,
  "created_at" : "2011-08-01 21:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theyCALLmeDUTCH",
      "screen_name" : "AllaboutDutch",
      "indices" : [ 3, 17 ],
      "id_str" : "121854689",
      "id" : 121854689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whChat",
      "indices" : [ 19, 26 ]
    }, {
      "text" : "jobs",
      "indices" : [ 54, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98146378261344256",
  "text" : "RT @AllaboutDutch: #whChat \"These dudes dont care abt #jobs..they have not brought up one jobs bill since they took control..all they ca ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whChat",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "jobs",
        "indices" : [ 35, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98145799912960000",
    "text" : "#whChat \"These dudes dont care abt #jobs..they have not brought up one jobs bill since they took control..all they care abt is social issues",
    "id" : 98145799912960000,
    "created_at" : "2011-08-01 21:39:16 +0000",
    "user" : {
      "name" : "theyCALLmeDUTCH",
      "screen_name" : "AllaboutDutch",
      "protected" : false,
      "id_str" : "121854689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761363089690390528\/N2iVhja3_normal.jpg",
      "id" : 121854689,
      "verified" : false
    }
  },
  "id" : 98146378261344256,
  "created_at" : "2011-08-01 21:41:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98146121637040128",
  "text" : ".@dolupduk first round is balanced spending cuts; 2d round committee will consider revenues and other spending reform #WHChat",
  "id" : 98146121637040128,
  "created_at" : "2011-08-01 21:40:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jackman",
      "screen_name" : "davidcjackman",
      "indices" : [ 1, 15 ],
      "id_str" : "95144256",
      "id" : 95144256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98145578696974336",
  "text" : ".@davidcjackman (1 of 2) As for the American people? That's why I'm here...you tell me",
  "id" : 98145578696974336,
  "created_at" : "2011-08-01 21:38:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Jackman",
      "screen_name" : "davidcjackman",
      "indices" : [ 1, 15 ],
      "id_str" : "95144256",
      "id" : 95144256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98145107525648386",
  "text" : ".@davidcjackman (1 of 2) been long haul but we're optimistic re deal & putting default uncertainty behind us. #WHChat",
  "id" : 98145107525648386,
  "created_at" : "2011-08-01 21:36:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JanettThinks",
      "screen_name" : "JanettThinks",
      "indices" : [ 1, 14 ],
      "id_str" : "73286371",
      "id" : 73286371
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98143699241938944",
  "text" : ".@JanettThinks deal lifts uncertainty of default weighing on economy & phases cuts in. But need more for jobs & will push going fwd #WHChat",
  "id" : 98143699241938944,
  "created_at" : "2011-08-01 21:30:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JanettThinks",
      "screen_name" : "JanettThinks",
      "indices" : [ 3, 16 ],
      "id_str" : "73286371",
      "id" : 73286371
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "JOBS",
      "indices" : [ 39, 44 ]
    }, {
      "text" : "debt",
      "indices" : [ 55, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98142864596414464",
  "text" : "RT @JanettThinks: #whchat The US needs #JOBS. Does the #debt deal kill or create jobs for those unmentioned people without them?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "JOBS",
        "indices" : [ 21, 26 ]
      }, {
        "text" : "debt",
        "indices" : [ 37, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98140137938096128",
    "text" : "#whchat The US needs #JOBS. Does the #debt deal kill or create jobs for those unmentioned people without them?",
    "id" : 98140137938096128,
    "created_at" : "2011-08-01 21:16:46 +0000",
    "user" : {
      "name" : "JanettThinks",
      "screen_name" : "JanettThinks",
      "protected" : false,
      "id_str" : "73286371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1212253601\/black-eagle_normal.jpg",
      "id" : 73286371,
      "verified" : false
    }
  },
  "id" : 98142864596414464,
  "created_at" : "2011-08-01 21:27:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/98142851887673344\/photo\/1",
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/dYQ6GWu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AVysZ2BCMAIO3x2.jpg",
      "id_str" : "98142851891867650",
      "id" : 98142851891867650,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AVysZ2BCMAIO3x2.jpg",
      "sizes" : [ {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 584
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 584
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 584
      } ],
      "display_url" : "pic.twitter.com\/dYQ6GWu"
    } ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "whchat",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98142851887673344",
  "text" : "Pic: Brian Deese from NEC is back answering your Qs on the #debt deal for WH Office Hours. Use #whchat to join the Q&A. http:\/\/t.co\/dYQ6GWu",
  "id" : 98142851887673344,
  "created_at" : "2011-08-01 21:27:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam S",
      "screen_name" : "RebelRepublican",
      "indices" : [ 1, 17 ],
      "id_str" : "176823985",
      "id" : 176823985
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98141981334716416",
  "text" : ".@RebelRepublican (1 of 2) committee will consider balanced deficit plans; trigger will force everyone to the table... #WHChat",
  "id" : 98141981334716416,
  "created_at" : "2011-08-01 21:24:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam S",
      "screen_name" : "RebelRepublican",
      "indices" : [ 3, 19 ],
      "id_str" : "176823985",
      "id" : 176823985
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sharedsacrifice",
      "indices" : [ 33, 49 ]
    }, {
      "text" : "taxloopholes",
      "indices" : [ 63, 76 ]
    }, {
      "text" : "corporatewelfare",
      "indices" : [ 81, 98 ]
    }, {
      "text" : "GOP",
      "indices" : [ 122, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98141715805896704",
  "text" : "RT @RebelRepublican: Explain why #sharedsacrifice doesnt close #taxloopholes\/end #corporatewelfare? Why should we believe #GOP will hono ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sharedsacrifice",
        "indices" : [ 12, 28 ]
      }, {
        "text" : "taxloopholes",
        "indices" : [ 42, 55 ]
      }, {
        "text" : "corporatewelfare",
        "indices" : [ 60, 77 ]
      }, {
        "text" : "GOP",
        "indices" : [ 101, 105 ]
      }, {
        "text" : "whchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98140710540296192",
    "text" : "Explain why #sharedsacrifice doesnt close #taxloopholes\/end #corporatewelfare? Why should we believe #GOP will honor this agreement? #whchat",
    "id" : 98140710540296192,
    "created_at" : "2011-08-01 21:19:03 +0000",
    "user" : {
      "name" : "Sam S",
      "screen_name" : "RebelRepublican",
      "protected" : false,
      "id_str" : "176823985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1108730552\/Chicken_crossing_road_normal.jpg",
      "id" : 176823985,
      "verified" : false
    }
  },
  "id" : 98141715805896704,
  "created_at" : "2011-08-01 21:23:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veekas Shrivastava",
      "screen_name" : "Veekas",
      "indices" : [ 3, 10 ],
      "id_str" : "15126830",
      "id" : 15126830
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98141321939795970",
  "text" : "RT @Veekas: @whitehouse #WHChat: Even though the deal is done, did all this damage long-term confidence in Treasury bills & dollar?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "98137950738579457",
    "geo" : { },
    "id_str" : "98139699306176513",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #WHChat: Even though the deal is done, did all this damage long-term confidence in Treasury bills & dollar?",
    "id" : 98139699306176513,
    "in_reply_to_status_id" : 98137950738579457,
    "created_at" : "2011-08-01 21:15:02 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Veekas Shrivastava",
      "screen_name" : "Veekas",
      "protected" : false,
      "id_str" : "15126830",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728397754641195008\/QM2SOgtO_normal.jpg",
      "id" : 15126830,
      "verified" : false
    }
  },
  "id" : 98141321939795970,
  "created_at" : "2011-08-01 21:21:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veekas Shrivastava",
      "screen_name" : "Veekas",
      "indices" : [ 1, 8 ],
      "id_str" : "15126830",
      "id" : 15126830
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98140984919076864",
  "text" : ".@Veekas uncertainty has hurt recently; but most impt is avoiding default & removing the cloud of uncertainty through 2013. #WHChat",
  "id" : 98140984919076864,
  "created_at" : "2011-08-01 21:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Allen",
      "screen_name" : "allencw",
      "indices" : [ 1, 9 ],
      "id_str" : "14230401",
      "id" : 14230401
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98139732348899328",
  "geo" : { },
  "id_str" : "98140103049871360",
  "in_reply_to_user_id" : 14230401,
  "text" : ".@allencw @thegreatbobo fair enough. #WHChat",
  "id" : 98140103049871360,
  "in_reply_to_status_id" : 98139732348899328,
  "created_at" : "2011-08-01 21:16:38 +0000",
  "in_reply_to_screen_name" : "allencw",
  "in_reply_to_user_id_str" : "14230401",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Thomas McGarry",
      "screen_name" : "McGarrysGhost",
      "indices" : [ 1, 15 ],
      "id_str" : "489977878",
      "id" : 489977878
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "98130467399802880",
  "geo" : { },
  "id_str" : "98139885067698176",
  "in_reply_to_user_id" : 61868624,
  "text" : ".@McGarrysGhost 1: it is given special fillibuster-proof fast track; avoids gaming; 2: threat of balanced trigger will force action #WHChat",
  "id" : 98139885067698176,
  "in_reply_to_status_id" : 98130467399802880,
  "created_at" : "2011-08-01 21:15:46 +0000",
  "in_reply_to_screen_name" : "LeoMcGarry",
  "in_reply_to_user_id_str" : "61868624",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Thomas McGarry",
      "screen_name" : "McGarrysGhost",
      "indices" : [ 3, 17 ],
      "id_str" : "489977878",
      "id" : 489977878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98139155132973056",
  "text" : "RT @McGarrysGhost: Please explain why the new Congressional commission created in this deal would succeed where Simpson-Bowles & Gang of ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98130467399802880",
    "text" : "Please explain why the new Congressional commission created in this deal would succeed where Simpson-Bowles & Gang of Six failed. #WHchat",
    "id" : 98130467399802880,
    "created_at" : "2011-08-01 20:38:21 +0000",
    "user" : {
      "name" : "Leo Thomas McGarry",
      "screen_name" : "LeoMcGarry",
      "protected" : false,
      "id_str" : "61868624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1117898389\/leo_normal.jpg",
      "id" : 61868624,
      "verified" : false
    }
  },
  "id" : 98139155132973056,
  "created_at" : "2011-08-01 21:12:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98138955710599168",
  "text" : ".@thegreatbobo: great thing about our democracy -- future congresses are bound unless they pass and potus signs a new law. #whchat",
  "id" : 98138955710599168,
  "created_at" : "2011-08-01 21:12:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98138558619066370",
  "text" : ".@jasonppoland: 1st downpayment is $1T over 10yrs; w\/fast track process to achieve addtl $1.5 T. But phased-in to avoid econ harm #whchat",
  "id" : 98138558619066370,
  "created_at" : "2011-08-01 21:10:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurial",
      "screen_name" : "kikaihime",
      "indices" : [ 1, 11 ],
      "id_str" : "1077768379",
      "id" : 1077768379
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/foJxG2d",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/fact-sheet-victory-bipartisan-compromise-economy-american-people",
      "display_url" : "whitehouse.gov\/fact-sheet-vic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98137950738579457",
  "text" : ".@kikaihime: deal has $17 billion over two years to protect historic pell grant increase for 9m students, see: http:\/\/t.co\/foJxG2d  #whchat",
  "id" : 98137950738579457,
  "created_at" : "2011-08-01 21:08:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98137518486192129",
  "text" : "Hey, it's Brian. I'm here, ready for questions. #WHChat",
  "id" : 98137518486192129,
  "created_at" : "2011-08-01 21:06:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 51, 62 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 27, 34 ]
    }, {
      "text" : "WHWeb",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http:\/\/t.co\/3aiUmKV",
      "expanded_url" : "http:\/\/1.usa.gov\/pEbT39",
      "display_url" : "1.usa.gov\/pEbT39"
    } ]
  },
  "geo" : { },
  "id_str" : "98124726748188673",
  "text" : "RT @macon44: Cool stats on #WHChat - 1 Week Later: @WhiteHouse Office Hours http:\/\/t.co\/3aiUmKV & find out what the new #WHWeb hashtag means",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 38, 49 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 14, 21 ]
      }, {
        "text" : "WHWeb",
        "indices" : [ 107, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 82 ],
        "url" : "http:\/\/t.co\/3aiUmKV",
        "expanded_url" : "http:\/\/1.usa.gov\/pEbT39",
        "display_url" : "1.usa.gov\/pEbT39"
      } ]
    },
    "geo" : { },
    "id_str" : "98123889116323842",
    "text" : "Cool stats on #WHChat - 1 Week Later: @WhiteHouse Office Hours http:\/\/t.co\/3aiUmKV & find out what the new #WHWeb hashtag means",
    "id" : 98123889116323842,
    "created_at" : "2011-08-01 20:12:12 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 98124726748188673,
  "created_at" : "2011-08-01 20:15:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98124126258073600",
  "text" : "RT @jesseclee44: \"Baselines & Balance\" NEC Dir. Gene Sperling on how budget deal sets stage for balanced deficit reduction: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 126 ],
        "url" : "http:\/\/t.co\/3ikfjgd",
        "expanded_url" : "http:\/\/wh.gov\/rQC",
        "display_url" : "wh.gov\/rQC"
      } ]
    },
    "geo" : { },
    "id_str" : "98124027591270400",
    "text" : "\"Baselines & Balance\" NEC Dir. Gene Sperling on how budget deal sets stage for balanced deficit reduction: http:\/\/t.co\/3ikfjgd",
    "id" : 98124027591270400,
    "created_at" : "2011-08-01 20:12:45 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 98124126258073600,
  "created_at" : "2011-08-01 20:13:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 22, 27 ]
    }, {
      "text" : "whchat",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98114430402953217",
  "text" : "Have questions on the #debt deal? Ask us with #whchat. Brian Deese, econ advisor to the President, will be here @ 5ET for Office Hours.",
  "id" : 98114430402953217,
  "created_at" : "2011-08-01 19:34:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Case Foundation",
      "screen_name" : "CaseFoundation",
      "indices" : [ 3, 18 ],
      "id_str" : "17539739",
      "id" : 17539739
    }, {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 39, 49 ],
      "id_str" : "6708952",
      "id" : 6708952
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsCouncil",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98089292148129792",
  "text" : "RT @CaseFoundation: Your chance to ask @SteveCase & other members of the Presidents #JobsCouncil about high-growth entrepreneurship: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Case",
        "screen_name" : "SteveCase",
        "indices" : [ 19, 29 ],
        "id_str" : "6708952",
        "id" : 6708952
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsCouncil",
        "indices" : [ 64, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98045333099122689",
    "text" : "Your chance to ask @SteveCase & other members of the Presidents #JobsCouncil about high-growth entrepreneurship: http:\/\/ow.ly\/5S6PK",
    "id" : 98045333099122689,
    "created_at" : "2011-08-01 15:00:03 +0000",
    "user" : {
      "name" : "Case Foundation",
      "screen_name" : "CaseFoundation",
      "protected" : false,
      "id_str" : "17539739",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471770118196711425\/ijq_4k09_normal.jpeg",
      "id" : 17539739,
      "verified" : true
    }
  },
  "id" : 98089292148129792,
  "created_at" : "2011-08-01 17:54:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsCouncil",
      "indices" : [ 54, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/2RG5V1b",
      "expanded_url" : "http:\/\/www.linkedin.com\/groups\/What-are-Your-Questions-President-2199632%2ES%2E64205723?qid=1d86a33b-773c-423e-9dff-e960a5a49712&goback=%2Egmp_2199632",
      "display_url" : "linkedin.com\/groups\/What-ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98089224577888256",
  "text" : "What are your questions\/ comments for the President's #JobsCouncil on job creation for innovative companies? http:\/\/t.co\/2RG5V1b",
  "id" : 98089224577888256,
  "created_at" : "2011-08-01 17:54:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 1, 8 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 29, 42 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 68, 83 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/6f2XWvb",
      "expanded_url" : "http:\/\/wh.gov\/rn3",
      "display_url" : "wh.gov\/rn3"
    } ]
  },
  "geo" : { },
  "id_str" : "98083345396801536",
  "text" : ".@SBAgov Admin Karen Mills & @AneeshChopra on the first 180 days of @StartupAmerica: http:\/\/t.co\/6f2XWvb",
  "id" : 98083345396801536,
  "created_at" : "2011-08-01 17:31:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98043381422374912",
  "text" : "RT @pfeiffer44: Nice to look out the window this morning and see the clouds of default that has been hanging over economy for months beg ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98033204317011968",
    "text" : "Nice to look out the window this morning and see the clouds of default that has been hanging over economy for months beginning to part",
    "id" : 98033204317011968,
    "created_at" : "2011-08-01 14:11:51 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 98043381422374912,
  "created_at" : "2011-08-01 14:52:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DebtCeiling",
      "indices" : [ 114, 126 ]
    }, {
      "text" : "compromise",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98042101857660929",
  "text" : "RT @VP: This morning, the VP will attend the Democratic caucus meetings in the House and the Senate to talk about #DebtCeiling #compromise.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DebtCeiling",
        "indices" : [ 106, 118 ]
      }, {
        "text" : "compromise",
        "indices" : [ 119, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "98026601635258368",
    "text" : "This morning, the VP will attend the Democratic caucus meetings in the House and the Senate to talk about #DebtCeiling #compromise.",
    "id" : 98026601635258368,
    "created_at" : "2011-08-01 13:45:37 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 98042101857660929,
  "created_at" : "2011-08-01 14:47:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 60, 70 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "Sheryl Sandberg",
      "screen_name" : "sherylsandberg",
      "indices" : [ 71, 86 ],
      "id_str" : "19506790",
      "id" : 19506790
    }, {
      "name" : "John Doerr",
      "screen_name" : "johndoerr",
      "indices" : [ 87, 97 ],
      "id_str" : "22255654",
      "id" : 22255654
    }, {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 107, 116 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/2RG5V1b",
      "expanded_url" : "http:\/\/www.linkedin.com\/groups\/What-are-Your-Questions-President-2199632%2ES%2E64205723?qid=1d86a33b-773c-423e-9dff-e960a5a49712&goback=%2Egmp_2199632",
      "display_url" : "linkedin.com\/groups\/What-ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98028060246417408",
  "text" : "What are your Qs for the President\u2019s Council on Jobs? (incl @SteveCase @sherylsandberg @johndoerr) Tell us @LinkedIn: http:\/\/t.co\/2RG5V1b",
  "id" : 98028060246417408,
  "created_at" : "2011-08-01 13:51:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debt",
      "indices" : [ 46, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/MZQxxQH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Zm4k73OukzM&feature=share",
      "display_url" : "youtube.com\/watch?v=Zm4k73\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "98019360358150144",
  "text" : "Video: President Obama announces a bipartisan #debt deal that will reduce the deficit & avoid default: http:\/\/t.co\/MZQxxQH",
  "id" : 98019360358150144,
  "created_at" : "2011-08-01 13:16:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]