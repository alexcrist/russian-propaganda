Grailbird.data.tweets_2016_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 41, 50 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/737790647592202243\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/wWPuCLJclC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj0oh4dUoAcLAHk.jpg",
      "id_str" : "737790476514795527",
      "id" : 737790476514795527,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj0oh4dUoAcLAHk.jpg",
      "sizes" : [ {
        "h" : 440,
        "resize" : "fit",
        "w" : 1581
      }, {
        "h" : 95,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 285,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wWPuCLJclC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/zBMegfbT5T",
      "expanded_url" : "http:\/\/go.wh.gov\/ZWXNau",
      "display_url" : "go.wh.gov\/ZWXNau"
    } ]
  },
  "geo" : { },
  "id_str" : "737790647592202243",
  "text" : "\"@POTUS continually reworked his speech\"\u2014@rhodes44 reflects on a historic trip to Hiroshima. https:\/\/t.co\/zBMegfbT5T https:\/\/t.co\/wWPuCLJclC",
  "id" : 737790647592202243,
  "created_at" : "2016-05-31 23:39:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NCAA",
      "screen_name" : "NCAA",
      "indices" : [ 80, 85 ],
      "id_str" : "31122496",
      "id" : 31122496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/eZhMCXu9Tj",
      "expanded_url" : "http:\/\/snpy.tv\/1RKe5IZ",
      "display_url" : "snpy.tv\/1RKe5IZ"
    } ]
  },
  "geo" : { },
  "id_str" : "737750413512835073",
  "text" : "\"This is a team for the ages, on and off the court.\" \u2014@POTUS welcoming the 2016 @NCAA Champion Villanova Wildcats https:\/\/t.co\/eZhMCXu9Tj",
  "id" : 737750413512835073,
  "created_at" : "2016-05-31 20:59:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Villanova Athletics",
      "screen_name" : "NovaAthletics",
      "indices" : [ 116, 130 ],
      "id_str" : "65372643",
      "id" : 65372643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737743210060107776",
  "text" : "\u201CThis is a team for the ages, on and off the court. Their grades rank in the top 10 percent nationally.\u201D \u2014@POTUS on @NovaAthletics Wildcats",
  "id" : 737743210060107776,
  "created_at" : "2016-05-31 20:31:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NCAA",
      "screen_name" : "NCAA",
      "indices" : [ 40, 45 ],
      "id_str" : "31122496",
      "id" : 31122496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/ZgBpOxzjCw",
      "expanded_url" : "http:\/\/go.wh.gov\/U9xcXx",
      "display_url" : "go.wh.gov\/U9xcXx"
    } ]
  },
  "geo" : { },
  "id_str" : "737741199151398913",
  "text" : "Happening now: @POTUS welcomes the 2016 @NCAA Champion Villanova Wildcats to the White House \u2192 https:\/\/t.co\/ZgBpOxzjCw",
  "id" : 737741199151398913,
  "created_at" : "2016-05-31 20:23:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/737738635328540672\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/PvkNtag5sC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjz4faZVEAAKVP-.jpg",
      "id_str" : "737737657527111680",
      "id" : 737737657527111680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjz4faZVEAAKVP-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PvkNtag5sC"
    } ],
    "hashtags" : [ {
      "text" : "HurricaneSeason",
      "indices" : [ 96, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/Q7B4sGwqnV",
      "expanded_url" : "http:\/\/Ready.gov",
      "display_url" : "Ready.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "737738635328540672",
  "text" : "\u201CI would encourage every American...to stay vigilant, to check https:\/\/t.co\/Q7B4sGwqnV\u201D \u2014@POTUS #HurricaneSeason https:\/\/t.co\/PvkNtag5sC",
  "id" : 737738635328540672,
  "created_at" : "2016-05-31 20:12:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OTrule",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737716049282375682",
  "text" : "RT @LaborSec: There's no freedom in working for free. 2.3 million college graduates benefit from the meaningful update to #OTrule. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OTrule",
        "indices" : [ 108, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/MElr0RwYfw",
        "expanded_url" : "http:\/\/www.nytimes.com\/2016\/05\/30\/opinion\/update-of-overtime-rules.html?ref=opinion&_r=1",
        "display_url" : "nytimes.com\/2016\/05\/30\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "737678743620177920",
    "text" : "There's no freedom in working for free. 2.3 million college graduates benefit from the meaningful update to #OTrule. https:\/\/t.co\/MElr0RwYfw",
    "id" : 737678743620177920,
    "created_at" : "2016-05-31 16:14:52 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 737716049282375682,
  "created_at" : "2016-05-31 18:43:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737706450202591232",
  "text" : "RT @FactsOnClimate: Hurricane season is near! Be ready:\nMake a plan \u2713\nHave an emergency supply kit\u2713\nKnow your evacuation zone\u2713\n\n \u2192 https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/8pRjWgEneh",
        "expanded_url" : "http:\/\/go.wh.gov\/TDuSeT",
        "display_url" : "go.wh.gov\/TDuSeT"
      } ]
    },
    "geo" : { },
    "id_str" : "737692515323650049",
    "text" : "Hurricane season is near! Be ready:\nMake a plan \u2713\nHave an emergency supply kit\u2713\nKnow your evacuation zone\u2713\n\n \u2192 https:\/\/t.co\/8pRjWgEneh",
    "id" : 737692515323650049,
    "created_at" : "2016-05-31 17:09:35 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 737706450202591232,
  "created_at" : "2016-05-31 18:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/737359447442362368\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/UNmjIArK09",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjuFPjgUUAASZ-o.jpg",
      "id_str" : "737329466280529920",
      "id" : 737329466280529920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjuFPjgUUAASZ-o.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      } ],
      "display_url" : "pic.twitter.com\/UNmjIArK09"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737359447442362368",
  "text" : "\"Here, at Arlington, the deafening sounds of combat have given way to the silence of these sacred hills.\" \u2014@POTUS https:\/\/t.co\/UNmjIArK09",
  "id" : 737359447442362368,
  "created_at" : "2016-05-30 19:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/nqtitvB6Ro",
      "expanded_url" : "http:\/\/snpy.tv\/1qXssE3",
      "display_url" : "snpy.tv\/1qXssE3"
    } ]
  },
  "geo" : { },
  "id_str" : "737350439239221248",
  "text" : "\u201CHere, at Arlington, the deafening sounds of combat have given way to the silence of these sacred hills.\u201D \u2014@POTUS https:\/\/t.co\/nqtitvB6Ro",
  "id" : 737350439239221248,
  "created_at" : "2016-05-30 18:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay2016",
      "indices" : [ 90, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/fXU6ozGL8E",
      "expanded_url" : "http:\/\/go.wh.gov\/MemorialDay",
      "display_url" : "go.wh.gov\/MemorialDay"
    }, {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/NeknQ6zV22",
      "expanded_url" : "http:\/\/snpy.tv\/1Z8u5KA",
      "display_url" : "snpy.tv\/1Z8u5KA"
    } ]
  },
  "geo" : { },
  "id_str" : "737325225121972224",
  "text" : "Watch as @POTUS lays a wreath at the Tomb of the Unknown Soldier: https:\/\/t.co\/fXU6ozGL8E #MemorialDay2016 https:\/\/t.co\/NeknQ6zV22",
  "id" : 737325225121972224,
  "created_at" : "2016-05-30 16:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/xjCRqJIl1T",
      "expanded_url" : "http:\/\/snpy.tv\/1TSLrLC",
      "display_url" : "snpy.tv\/1TSLrLC"
    } ]
  },
  "geo" : { },
  "id_str" : "737320254448095232",
  "text" : "\u201CA nation reveals itself not only by the people it produces, but by those it remembers.\u201D \u2014@POTUS on #MemorialDay https:\/\/t.co\/xjCRqJIl1T",
  "id" : 737320254448095232,
  "created_at" : "2016-05-30 16:30:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay2016",
      "indices" : [ 83, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/nqtitvB6Ro",
      "expanded_url" : "http:\/\/snpy.tv\/1qXssE3",
      "display_url" : "snpy.tv\/1qXssE3"
    } ]
  },
  "geo" : { },
  "id_str" : "737313901407150081",
  "text" : "Today we pay our respects, as Americans, to those who gave their lives for us all. #MemorialDay2016 https:\/\/t.co\/nqtitvB6Ro",
  "id" : 737313901407150081,
  "created_at" : "2016-05-30 16:05:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/nqtitvSIfY",
      "expanded_url" : "http:\/\/snpy.tv\/1qXssE3",
      "display_url" : "snpy.tv\/1qXssE3"
    } ]
  },
  "geo" : { },
  "id_str" : "737310729125146624",
  "text" : "\"It is our responsibility, our obligation, to fill that silence with our love and support and gratitude\u201D \u2014@POTUS https:\/\/t.co\/nqtitvSIfY",
  "id" : 737310729125146624,
  "created_at" : "2016-05-30 15:52:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay2016",
      "indices" : [ 100, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737309051747471361",
  "text" : "\u201CA nation reveals itself not only by the people it produces, but by those it remembers.\u201D \u2014@POTUS on #MemorialDay2016",
  "id" : 737309051747471361,
  "created_at" : "2016-05-30 15:45:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737307389888737280",
  "text" : "\u201CMy fellow Americans, today and every day, listen to the stories these Gold Star families and veterans have to tell.\u201D \u2014@POTUS #MemorialDay",
  "id" : 737307389888737280,
  "created_at" : "2016-05-30 15:39:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737306898303754242",
  "text" : "\u201CPresident Kennedy told us that a nation reveals itself not only by the people it produces, but by those it remembers.\u201D \u2014@POTUS #MemorialDay",
  "id" : 737306898303754242,
  "created_at" : "2016-05-30 15:37:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737306749477212165",
  "text" : "RT @WHLive: \"It is our responsibility, our obligation, to fill that silence with our love and support and gratitude\u201D  \u2014@POTUS #MemorialDay2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 107, 113 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MemorialDay2016",
        "indices" : [ 114, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737306636709154816",
    "text" : "\"It is our responsibility, our obligation, to fill that silence with our love and support and gratitude\u201D  \u2014@POTUS #MemorialDay2016",
    "id" : 737306636709154816,
    "created_at" : "2016-05-30 15:36:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 737306749477212165,
  "created_at" : "2016-05-30 15:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/fXU6ozYmxe",
      "expanded_url" : "http:\/\/go.wh.gov\/MemorialDay",
      "display_url" : "go.wh.gov\/MemorialDay"
    } ]
  },
  "geo" : { },
  "id_str" : "737306403673649152",
  "text" : "\u201CAs Commander-in-Chief, I have no greater responsibility than leading our men and women in uniform\u201D \u2014@POTUS: https:\/\/t.co\/fXU6ozYmxe",
  "id" : 737306403673649152,
  "created_at" : "2016-05-30 15:35:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737305918069735424",
  "text" : "\"The Americans who rest here, and their families\u2026ask of us today only one thing in return: that we remember them.\" \u2014@POTUS on #MemorialDay",
  "id" : 737305918069735424,
  "created_at" : "2016-05-30 15:33:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/737305651869847553\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/gRqJPfG3HI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjtvkLqVAAA9Vlj.jpg",
      "id_str" : "737305631401508864",
      "id" : 737305631401508864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjtvkLqVAAA9Vlj.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2333,
        "resize" : "fit",
        "w" : 3500
      } ],
      "display_url" : "pic.twitter.com\/gRqJPfG3HI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737305651869847553",
  "text" : "\u201CHere, at Arlington, the deafening sounds of combat have given way to the silence of these sacred hills.\u201D \u2014@POTUS https:\/\/t.co\/gRqJPfG3HI",
  "id" : 737305651869847553,
  "created_at" : "2016-05-30 15:32:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737305421564809216",
  "text" : "\u201CI am honored to be with you once again as we pay our respects, as Americans, to those who gave their lives for us all\u201D \u2014@POTUS #MemorialDay",
  "id" : 737305421564809216,
  "created_at" : "2016-05-30 15:31:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/737300784992264193\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/nbfVa9Ew4J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjtp-ryUUAQxV5L.jpg",
      "id_str" : "737299489631784964",
      "id" : 737299489631784964,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjtp-ryUUAQxV5L.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/nbfVa9Ew4J"
    } ],
    "hashtags" : [ {
      "text" : "MemorialDay2016",
      "indices" : [ 38, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/fXU6ozGL8E",
      "expanded_url" : "http:\/\/go.wh.gov\/MemorialDay",
      "display_url" : "go.wh.gov\/MemorialDay"
    } ]
  },
  "geo" : { },
  "id_str" : "737300784992264193",
  "text" : "Watch live: President Obama speaks on #MemorialDay2016 at Arlington National Cemetery \u2192 https:\/\/t.co\/fXU6ozGL8E https:\/\/t.co\/nbfVa9Ew4J",
  "id" : 737300784992264193,
  "created_at" : "2016-05-30 15:13:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay2016",
      "indices" : [ 104, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/fXU6ozGL8E",
      "expanded_url" : "http:\/\/go.wh.gov\/MemorialDay",
      "display_url" : "go.wh.gov\/MemorialDay"
    } ]
  },
  "geo" : { },
  "id_str" : "737292940154785792",
  "text" : "Today at 11am ET, watch @POTUS lay a wreath at the Tomb of the Unknown Soldier: https:\/\/t.co\/fXU6ozGL8E #MemorialDay2016",
  "id" : 737292940154785792,
  "created_at" : "2016-05-30 14:41:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737270063355596800",
  "text" : "RT @POTUS: This Memorial Day, I hope you'll join me in acts of remembrance. The debt we owe our fallen heroes is one we can never truly rep\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "737267478661730304",
    "text" : "This Memorial Day, I hope you'll join me in acts of remembrance. The debt we owe our fallen heroes is one we can never truly repay.",
    "id" : 737267478661730304,
    "created_at" : "2016-05-30 13:00:39 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 737270063355596800,
  "created_at" : "2016-05-30 13:10:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/cbfqtYeBou",
      "expanded_url" : "http:\/\/snpy.tv\/1slnEcM",
      "display_url" : "snpy.tv\/1slnEcM"
    } ]
  },
  "geo" : { },
  "id_str" : "737108349888561152",
  "text" : "\"Since that fateful day, we have made choices that give us hope.\" \u2014@POTUS at the Hiroshima Peace Memorial https:\/\/t.co\/cbfqtYeBou",
  "id" : 737108349888561152,
  "created_at" : "2016-05-30 02:28:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/IGGC02mUwZ",
      "expanded_url" : "http:\/\/go.wh.gov\/j8oMiN",
      "display_url" : "go.wh.gov\/j8oMiN"
    } ]
  },
  "geo" : { },
  "id_str" : "737064741865017344",
  "text" : "\"Our responsibility to remember is something we can live up to every day of the year.\" \u2014@POTUS on #MemorialDay: https:\/\/t.co\/IGGC02mUwZ",
  "id" : 737064741865017344,
  "created_at" : "2016-05-29 23:35:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/AYnt5gMfNM",
      "expanded_url" : "http:\/\/snpy.tv\/1RDcpkl",
      "display_url" : "snpy.tv\/1RDcpkl"
    } ]
  },
  "geo" : { },
  "id_str" : "737047020070920192",
  "text" : "4 cities in 5 days: Get a behind-the-scenes look at @POTUS's whirlwind trip to Vietnam and Japan. https:\/\/t.co\/AYnt5gMfNM",
  "id" : 737047020070920192,
  "created_at" : "2016-05-29 22:24:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/IGGC02mUwZ",
      "expanded_url" : "http:\/\/go.wh.gov\/j8oMiN",
      "display_url" : "go.wh.gov\/j8oMiN"
    } ]
  },
  "geo" : { },
  "id_str" : "737019460255502337",
  "text" : "\"Send a care package to our troops overseas, volunteer to make a wounded warrior\u2019s day a little easier.\" \u2014@POTUS: https:\/\/t.co\/IGGC02mUwZ",
  "id" : 737019460255502337,
  "created_at" : "2016-05-29 20:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDayWeekend",
      "indices" : [ 6, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/IGGC02mUwZ",
      "expanded_url" : "http:\/\/go.wh.gov\/j8oMiN",
      "display_url" : "go.wh.gov\/j8oMiN"
    } ]
  },
  "geo" : { },
  "id_str" : "737010728788320257",
  "text" : "\"This #MemorialDayWeekend, I hope you\u2019ll join me in acts of remembrance.\" \u2014@POTUS: https:\/\/t.co\/IGGC02mUwZ",
  "id" : 737010728788320257,
  "created_at" : "2016-05-29 20:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736999570610212864",
  "text" : "RT @SCOTUSnom: \"When the bad things happen\u2014it can be a tremendous solace to get outside yourself. To focus on helping someone else.\"  \u2014Judg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736979580586741760",
    "text" : "\"When the bad things happen\u2014it can be a tremendous solace to get outside yourself. To focus on helping someone else.\"  \u2014Judge Garland",
    "id" : 736979580586741760,
    "created_at" : "2016-05-29 17:56:39 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 736999570610212864,
  "created_at" : "2016-05-29 19:16:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/IGGC02mUwZ",
      "expanded_url" : "http:\/\/go.wh.gov\/j8oMiN",
      "display_url" : "go.wh.gov\/j8oMiN"
    } ]
  },
  "geo" : { },
  "id_str" : "736995664446398464",
  "text" : "\"It\u2019s up to the rest of us to live our lives in a way that\u2019s worthy of these sacrifices.\" \u2014@POTUS on #MemorialDay: https:\/\/t.co\/IGGC02mUwZ",
  "id" : 736995664446398464,
  "created_at" : "2016-05-29 19:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/IGGC02EvVz",
      "expanded_url" : "http:\/\/go.wh.gov\/j8oMiN",
      "display_url" : "go.wh.gov\/j8oMiN"
    } ]
  },
  "geo" : { },
  "id_str" : "736973857857409025",
  "text" : "\"As Commander-in-Chief, I have no more solemn obligation than leading our men and women in uniform.\" \u2014@POTUS: https:\/\/t.co\/IGGC02EvVz",
  "id" : 736973857857409025,
  "created_at" : "2016-05-29 17:33:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/ta4ag8A0Ci",
      "expanded_url" : "http:\/\/go.wh.gov\/bC5qia",
      "display_url" : "go.wh.gov\/bC5qia"
    } ]
  },
  "geo" : { },
  "id_str" : "736946306942308352",
  "text" : "RT @SCOTUSnom: It's graduation day at Niles West High School! Watch Judge Garland speak live at 1pm ET: https:\/\/t.co\/ta4ag8A0Ci https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SCOTUSnom\/status\/736945840313401344\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/so1NhRr8H0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjooHXAUoAEdOiE.jpg",
        "id_str" : "736945595928059905",
        "id" : 736945595928059905,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjooHXAUoAEdOiE.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 760,
          "resize" : "fit",
          "w" : 1349
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/so1NhRr8H0"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/ta4ag8A0Ci",
        "expanded_url" : "http:\/\/go.wh.gov\/bC5qia",
        "display_url" : "go.wh.gov\/bC5qia"
      } ]
    },
    "geo" : { },
    "id_str" : "736945840313401344",
    "text" : "It's graduation day at Niles West High School! Watch Judge Garland speak live at 1pm ET: https:\/\/t.co\/ta4ag8A0Ci https:\/\/t.co\/so1NhRr8H0",
    "id" : 736945840313401344,
    "created_at" : "2016-05-29 15:42:34 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 736946306942308352,
  "created_at" : "2016-05-29 15:44:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/IGGC02mUwZ",
      "expanded_url" : "http:\/\/go.wh.gov\/j8oMiN",
      "display_url" : "go.wh.gov\/j8oMiN"
    } ]
  },
  "geo" : { },
  "id_str" : "736680709117513730",
  "text" : "\"We stop to reflect with gratitude on the sacrifice of generations who made us more prosperous and free.\" \u2014@POTUS: https:\/\/t.co\/IGGC02mUwZ",
  "id" : 736680709117513730,
  "created_at" : "2016-05-28 22:09:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 1, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/IGGC02mUwZ",
      "expanded_url" : "http:\/\/go.wh.gov\/j8oMiN",
      "display_url" : "go.wh.gov\/j8oMiN"
    } ]
  },
  "geo" : { },
  "id_str" : "736650520702504961",
  "text" : "\"#MemorialDay, which we\u2019ll observe Monday, is...the day we remember those who never made it home.\" \u2014@POTUS: https:\/\/t.co\/IGGC02mUwZ",
  "id" : 736650520702504961,
  "created_at" : "2016-05-28 20:09:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/IGGC02mUwZ",
      "expanded_url" : "http:\/\/go.wh.gov\/j8oMiN",
      "display_url" : "go.wh.gov\/j8oMiN"
    } ]
  },
  "geo" : { },
  "id_str" : "736620326734336003",
  "text" : "\"Right now, there are American troops serving in harm\u2019s way and standing sentry around the world.\" \u2014@POTUS: https:\/\/t.co\/IGGC02mUwZ",
  "id" : 736620326734336003,
  "created_at" : "2016-05-28 18:09:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDayWeekend",
      "indices" : [ 25, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/IGGC02EvVz",
      "expanded_url" : "http:\/\/go.wh.gov\/j8oMiN",
      "display_url" : "go.wh.gov\/j8oMiN"
    } ]
  },
  "geo" : { },
  "id_str" : "736590127330406400",
  "text" : "Watch @POTUS commemorate #MemorialDayWeekend with a tribute to our fallen heroes: https:\/\/t.co\/IGGC02EvVz",
  "id" : 736590127330406400,
  "created_at" : "2016-05-28 16:09:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Stars and Stripes",
      "screen_name" : "starsandstripes",
      "indices" : [ 98, 114 ],
      "id_str" : "9130702",
      "id" : 9130702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDayWeekend",
      "indices" : [ 16, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/CknBWucixP",
      "expanded_url" : "http:\/\/www.stripes.com\/q-a-with-president-barack-obama-1.411876",
      "display_url" : "stripes.com\/q-a-with-presi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736321405512474624",
  "text" : "RT @NSC44: This #MemorialDayWeekend, read @POTUS' interview about strength of our armed forces in @starsandstripes: https:\/\/t.co\/CknBWucixP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 31, 37 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Stars and Stripes",
        "screen_name" : "starsandstripes",
        "indices" : [ 87, 103 ],
        "id_str" : "9130702",
        "id" : 9130702
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MemorialDayWeekend",
        "indices" : [ 5, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/CknBWucixP",
        "expanded_url" : "http:\/\/www.stripes.com\/q-a-with-president-barack-obama-1.411876",
        "display_url" : "stripes.com\/q-a-with-presi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "736301179483738112",
    "text" : "This #MemorialDayWeekend, read @POTUS' interview about strength of our armed forces in @starsandstripes: https:\/\/t.co\/CknBWucixP",
    "id" : 736301179483738112,
    "created_at" : "2016-05-27 21:00:55 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 736321405512474624,
  "created_at" : "2016-05-27 22:21:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/736307475620724736\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/taxj17GuYi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjfi4EYVEAEEmj2.jpg",
      "id_str" : "736306516974702593",
      "id" : 736306516974702593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjfi4EYVEAEEmj2.jpg",
      "sizes" : [ {
        "h" : 326,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 678
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 678
      } ],
      "display_url" : "pic.twitter.com\/taxj17GuYi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736307475620724736",
  "text" : "\"To know Cassandra Butts was to know someone who made you want to be better.\" \u2014@POTUS: https:\/\/t.co\/taxj17GuYi",
  "id" : 736307475620724736,
  "created_at" : "2016-05-27 21:25:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "G7",
      "screen_name" : "g7",
      "indices" : [ 48, 51 ],
      "id_str" : "3191500397",
      "id" : 3191500397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/HgxjWO1LCH",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/05\/27\/fact-sheet-g-7-summit-ise-shima-japan",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736283419701825536",
  "text" : "RT @AmbassadorRice: Just concluded a productive @G7 summit in Japan. Here\u2019s what we\u2019ve been working on: https:\/\/t.co\/HgxjWO1LCH https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "G7",
        "screen_name" : "g7",
        "indices" : [ 28, 31 ],
        "id_str" : "3191500397",
        "id" : 3191500397
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmbassadorRice\/status\/736279135794827264\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/IidN5HRNxJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjfJ8GtUYAEteB_.jpg",
        "id_str" : "736279098528391169",
        "id" : 736279098528391169,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjfJ8GtUYAEteB_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 395,
          "resize" : "fit",
          "w" : 598
        } ],
        "display_url" : "pic.twitter.com\/IidN5HRNxJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/HgxjWO1LCH",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/05\/27\/fact-sheet-g-7-summit-ise-shima-japan",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "736279135794827264",
    "text" : "Just concluded a productive @G7 summit in Japan. Here\u2019s what we\u2019ve been working on: https:\/\/t.co\/HgxjWO1LCH https:\/\/t.co\/IidN5HRNxJ",
    "id" : 736279135794827264,
    "created_at" : "2016-05-27 19:33:20 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 736283419701825536,
  "created_at" : "2016-05-27 19:50:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/V8FvufNocu",
      "expanded_url" : "http:\/\/snpy.tv\/1TMFQ9y",
      "display_url" : "snpy.tv\/1TMFQ9y"
    } ]
  },
  "geo" : { },
  "id_str" : "736277081294675968",
  "text" : "Today, @POTUS became the first sitting U.S. President to visit Hiroshima. https:\/\/t.co\/V8FvufNocu",
  "id" : 736277081294675968,
  "created_at" : "2016-05-27 19:25:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/qLPoNEHX3J",
      "expanded_url" : "http:\/\/snpy.tv\/1TMHmsa",
      "display_url" : "snpy.tv\/1TMHmsa"
    } ]
  },
  "geo" : { },
  "id_str" : "736271890340323328",
  "text" : "\"We come to ponder a terrible force unleashed in a not so distant past.\" \u2014@POTUS at Hiroshima https:\/\/t.co\/qLPoNEHX3J",
  "id" : 736271890340323328,
  "created_at" : "2016-05-27 19:04:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Betsy Hodges",
      "screen_name" : "MayorHodges",
      "indices" : [ 38, 50 ],
      "id_str" : "118719917",
      "id" : 118719917
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736266986985033728",
  "text" : "RT @vj44: Just called to congratulate @MayorHodges on taking the #LeadOnLeave. Great to see Minneapolis understand the importance of #Worki\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Betsy Hodges",
        "screen_name" : "MayorHodges",
        "indices" : [ 28, 40 ],
        "id_str" : "118719917",
        "id" : 118719917
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 55, 67 ]
      }, {
        "text" : "WorkingFamilies",
        "indices" : [ 123, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "736261433680363522",
    "text" : "Just called to congratulate @MayorHodges on taking the #LeadOnLeave. Great to see Minneapolis understand the importance of #WorkingFamilies!",
    "id" : 736261433680363522,
    "created_at" : "2016-05-27 18:22:59 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 736266986985033728,
  "created_at" : "2016-05-27 18:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/OTvxyfT1jE",
      "expanded_url" : "http:\/\/go.wh.gov\/HiroshimaLetters",
      "display_url" : "go.wh.gov\/HiroshimaLette\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "736226109935767552",
  "text" : "An army doctor wrote home after Hiroshima.\nHis son sent the letters to @POTUS.\nRead the President's response today: https:\/\/t.co\/OTvxyfT1jE",
  "id" : 736226109935767552,
  "created_at" : "2016-05-27 16:02:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 36, 42 ],
      "id_str" : "33696409",
      "id" : 33696409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736217826021810176",
  "text" : "RT @PressSec: Posting my answers on @Quora to your great questions that came in over the past couple of days, check them out here: https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quora",
        "screen_name" : "Quora",
        "indices" : [ 22, 28 ],
        "id_str" : "33696409",
        "id" : 33696409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/L7RAIfJMjM",
        "expanded_url" : "https:\/\/www.quora.com\/session\/Josh-Earnest\/1",
        "display_url" : "quora.com\/session\/Josh-E\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "736216848224686081",
    "text" : "Posting my answers on @Quora to your great questions that came in over the past couple of days, check them out here: https:\/\/t.co\/L7RAIfJMjM",
    "id" : 736216848224686081,
    "created_at" : "2016-05-27 15:25:49 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 736217826021810176,
  "created_at" : "2016-05-27 15:29:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/kQX3OXEfmF",
      "expanded_url" : "http:\/\/snpy.tv\/1TMHmsa",
      "display_url" : "snpy.tv\/1TMHmsa"
    } ]
  },
  "geo" : { },
  "id_str" : "736198064147468289",
  "text" : "RT @rhodes44: Today @POTUS became the first sitting US President to visit Hiroshima. Here's what he said: https:\/\/t.co\/kQX3OXEfmF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/kQX3OXEfmF",
        "expanded_url" : "http:\/\/snpy.tv\/1TMHmsa",
        "display_url" : "snpy.tv\/1TMHmsa"
      } ]
    },
    "geo" : { },
    "id_str" : "736195008223551488",
    "text" : "Today @POTUS became the first sitting US President to visit Hiroshima. Here's what he said: https:\/\/t.co\/kQX3OXEfmF",
    "id" : 736195008223551488,
    "created_at" : "2016-05-27 13:59:02 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 736198064147468289,
  "created_at" : "2016-05-27 14:11:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "\u5B89\u500D\u664B\u4E09",
      "screen_name" : "AbeShinzo",
      "indices" : [ 32, 42 ],
      "id_str" : "468122115",
      "id" : 468122115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/V8FvufNocu",
      "expanded_url" : "http:\/\/snpy.tv\/1TMFQ9y",
      "display_url" : "snpy.tv\/1TMFQ9y"
    } ]
  },
  "geo" : { },
  "id_str" : "736123641406971904",
  "text" : "Watch @POTUS and Prime Minister @AbeShinzo of Japan lay wreaths at the Peace Memorial in Hiroshima. https:\/\/t.co\/V8FvufNocu",
  "id" : 736123641406971904,
  "created_at" : "2016-05-27 09:15:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/qLPoNEqlF9",
      "expanded_url" : "http:\/\/snpy.tv\/1TMHmsa",
      "display_url" : "snpy.tv\/1TMHmsa"
    } ]
  },
  "geo" : { },
  "id_str" : "736120843328098304",
  "text" : "\"We are not bound ... to repeat the mistakes of the past. We can learn. We can choose.\" \u2014@POTUS speaks at Hiroshima. https:\/\/t.co\/qLPoNEqlF9",
  "id" : 736120843328098304,
  "created_at" : "2016-05-27 09:04:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735967479772512256",
  "text" : "RT @SCOTUSnom: \"Eight is not a good number.\" \u2014Justice Ruth Bader Ginsburg agrees we need a fully functioning Supreme Court: https:\/\/t.co\/Cl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/Cl2mHn0NF5",
        "expanded_url" : "https:\/\/www.yahoo.com\/news\/ginsburg-having-only-8-justices-hamstrings-supreme-court-200525028.html",
        "display_url" : "yahoo.com\/news\/ginsburg-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735966327559618561",
    "text" : "\"Eight is not a good number.\" \u2014Justice Ruth Bader Ginsburg agrees we need a fully functioning Supreme Court: https:\/\/t.co\/Cl2mHn0NF5",
    "id" : 735966327559618561,
    "created_at" : "2016-05-26 22:50:20 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 735967479772512256,
  "created_at" : "2016-05-26 22:54:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/K8yHcQjS7K",
      "expanded_url" : "http:\/\/go.wh.gov\/gbdjXc",
      "display_url" : "go.wh.gov\/gbdjXc"
    } ]
  },
  "geo" : { },
  "id_str" : "735939288857247747",
  "text" : "\u201CEvery time I go to the U.S., I\u2019m spoiled for choice\u2026That\u2019s how it should be here.\" \u2014Entrepreneur in Malaysia: https:\/\/t.co\/K8yHcQjS7K",
  "id" : 735939288857247747,
  "created_at" : "2016-05-26 21:02:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "SFIS_BRAVES",
      "screen_name" : "SFIS_Braves",
      "indices" : [ 46, 58 ],
      "id_str" : "382672168",
      "id" : 382672168
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 112, 124 ]
    }, {
      "text" : "GenI",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/PxlbF9VKr1",
      "expanded_url" : "http:\/\/livestream.com\/sfis\/graduation",
      "display_url" : "livestream.com\/sfis\/graduation"
    } ]
  },
  "geo" : { },
  "id_str" : "735931455600230400",
  "text" : "RT @FLOTUS: Watch the First Lady speak to the @SFIS_Braves Class of 2016 in New Mexico: https:\/\/t.co\/PxlbF9VKr1 #ReachHigher #GenI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SFIS_BRAVES",
        "screen_name" : "SFIS_Braves",
        "indices" : [ 34, 46 ],
        "id_str" : "382672168",
        "id" : 382672168
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 100, 112 ]
      }, {
        "text" : "GenI",
        "indices" : [ 113, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/PxlbF9VKr1",
        "expanded_url" : "http:\/\/livestream.com\/sfis\/graduation",
        "display_url" : "livestream.com\/sfis\/graduation"
      } ]
    },
    "geo" : { },
    "id_str" : "735931289551941633",
    "text" : "Watch the First Lady speak to the @SFIS_Braves Class of 2016 in New Mexico: https:\/\/t.co\/PxlbF9VKr1 #ReachHigher #GenI",
    "id" : 735931289551941633,
    "created_at" : "2016-05-26 20:31:07 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 735931455600230400,
  "created_at" : "2016-05-26 20:31:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/A2HcJ2KCIQ",
      "expanded_url" : "http:\/\/blog.ed.gov\/?p=23384&preview=true",
      "display_url" : "blog.ed.gov\/?p=23384&previ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735927001593356288",
  "text" : "RT @usedgov: Today we're sharing a set of proposed regulations to provide clarity around accountability https:\/\/t.co\/A2HcJ2KCIQ https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/735826358358712320\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/QSZj21x49v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjYrt8gWkAAgWYB.jpg",
        "id_str" : "735823657457586176",
        "id" : 735823657457586176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjYrt8gWkAAgWYB.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/QSZj21x49v"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/A2HcJ2KCIQ",
        "expanded_url" : "http:\/\/blog.ed.gov\/?p=23384&preview=true",
        "display_url" : "blog.ed.gov\/?p=23384&previ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735826358358712320",
    "text" : "Today we're sharing a set of proposed regulations to provide clarity around accountability https:\/\/t.co\/A2HcJ2KCIQ https:\/\/t.co\/QSZj21x49v",
    "id" : 735826358358712320,
    "created_at" : "2016-05-26 13:34:09 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 735927001593356288,
  "created_at" : "2016-05-26 20:14:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "SFIS_BRAVES",
      "screen_name" : "SFIS_Braves",
      "indices" : [ 48, 60 ],
      "id_str" : "382672168",
      "id" : 382672168
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/735918511826968576\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/QxBnkMTw9j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjaB-jtUUAEvkNZ.jpg",
      "id_str" : "735918500858843137",
      "id" : 735918500858843137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjaB-jtUUAEvkNZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1931,
        "resize" : "fit",
        "w" : 1931
      } ],
      "display_url" : "pic.twitter.com\/QxBnkMTw9j"
    } ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735923645562785792",
  "text" : "RT @FLOTUS: Meet the extraordinary graduates of @SFIS_Braves! The Class of 2016 is ready to #ReachHigher! https:\/\/t.co\/QxBnkMTw9j",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SFIS_BRAVES",
        "screen_name" : "SFIS_Braves",
        "indices" : [ 36, 48 ],
        "id_str" : "382672168",
        "id" : 382672168
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/735918511826968576\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/QxBnkMTw9j",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjaB-jtUUAEvkNZ.jpg",
        "id_str" : "735918500858843137",
        "id" : 735918500858843137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjaB-jtUUAEvkNZ.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1931,
          "resize" : "fit",
          "w" : 1931
        } ],
        "display_url" : "pic.twitter.com\/QxBnkMTw9j"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 80, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735918511826968576",
    "text" : "Meet the extraordinary graduates of @SFIS_Braves! The Class of 2016 is ready to #ReachHigher! https:\/\/t.co\/QxBnkMTw9j",
    "id" : 735918511826968576,
    "created_at" : "2016-05-26 19:40:20 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 735923645562785792,
  "created_at" : "2016-05-26 20:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/K8yHcQjS7K",
      "expanded_url" : "http:\/\/go.wh.gov\/gbdjXc",
      "display_url" : "go.wh.gov\/gbdjXc"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/P9clq0Ei5f",
      "expanded_url" : "http:\/\/snpy.tv\/1TCUuN0",
      "display_url" : "snpy.tv\/1TCUuN0"
    } ]
  },
  "geo" : { },
  "id_str" : "735922031942864896",
  "text" : "From craft beer to kitchen decor, trade with America is essential to small business abroad: https:\/\/t.co\/K8yHcQjS7K https:\/\/t.co\/P9clq0Ei5f",
  "id" : 735922031942864896,
  "created_at" : "2016-05-26 19:54:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 60, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/K8yHcQjS7K",
      "expanded_url" : "http:\/\/go.wh.gov\/gbdjXc",
      "display_url" : "go.wh.gov\/gbdjXc"
    }, {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/z7th59HoaX",
      "expanded_url" : "http:\/\/snpy.tv\/1WnaSqS",
      "display_url" : "snpy.tv\/1WnaSqS"
    } ]
  },
  "geo" : { },
  "id_str" : "735909963357401089",
  "text" : "Watch Malaysian small business owners explain why they sell #MadeInAmerica goods: https:\/\/t.co\/K8yHcQjS7K https:\/\/t.co\/z7th59HoaX",
  "id" : 735909963357401089,
  "created_at" : "2016-05-26 19:06:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 35, 41 ],
      "id_str" : "33696409",
      "id" : 33696409
    }, {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 45, 55 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735850893795545088",
  "text" : "RT @PressSec: I'm taking qs now on @Quora on @SCOTUSnom, #Zika &amp; other topics so send yours my way by 11:00am ET tomorrow https:\/\/t.co\/L7RA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quora",
        "screen_name" : "Quora",
        "indices" : [ 21, 27 ],
        "id_str" : "33696409",
        "id" : 33696409
      }, {
        "name" : "SCOTUS Nomination",
        "screen_name" : "SCOTUSnom",
        "indices" : [ 31, 41 ],
        "id_str" : "708072909114318848",
        "id" : 708072909114318848
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 43, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/L7RAIfsaVc",
        "expanded_url" : "https:\/\/www.quora.com\/session\/Josh-Earnest\/1",
        "display_url" : "quora.com\/session\/Josh-E\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735842888811040769",
    "text" : "I'm taking qs now on @Quora on @SCOTUSnom, #Zika &amp; other topics so send yours my way by 11:00am ET tomorrow https:\/\/t.co\/L7RAIfsaVc",
    "id" : 735842888811040769,
    "created_at" : "2016-05-26 14:39:50 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 735850893795545088,
  "created_at" : "2016-05-26 15:11:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/E0PIm2pcV6",
      "expanded_url" : "http:\/\/snpy.tv\/20GyJ39",
      "display_url" : "snpy.tv\/20GyJ39"
    } ]
  },
  "geo" : { },
  "id_str" : "735847052781834240",
  "text" : "Watch @POTUS's interpreter in Vietnam share what the President's visit meant to him &amp; the country where he was born: https:\/\/t.co\/E0PIm2pcV6",
  "id" : 735847052781834240,
  "created_at" : "2016-05-26 14:56:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735581888287477760",
  "text" : "RT @SCOTUSnom: .@POTUS's Supreme Court nominee has waited longer for a hearing than it's taken recent justices to get confirmed. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCOTUSnom\/status\/735575348100747264\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/XBym2R03w7",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjVJTBLXIAQt5Wb.jpg",
        "id_str" : "735574705227374596",
        "id" : 735574705227374596,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjVJTBLXIAQt5Wb.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 302,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 171,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 515,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XBym2R03w7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735575348100747264",
    "text" : ".@POTUS's Supreme Court nominee has waited longer for a hearing than it's taken recent justices to get confirmed. https:\/\/t.co\/XBym2R03w7",
    "id" : 735575348100747264,
    "created_at" : "2016-05-25 20:56:43 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 735581888287477760,
  "created_at" : "2016-05-25 21:22:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/p91FHdtP6j",
      "expanded_url" : "http:\/\/snpy.tv\/1qK0Yl1",
      "display_url" : "snpy.tv\/1qK0Yl1"
    } ]
  },
  "geo" : { },
  "id_str" : "735579635153534976",
  "text" : "Watch as @POTUS takes a question from a Vietnamese rapper on the importance of promoting the arts: https:\/\/t.co\/p91FHdtP6j",
  "id" : 735579635153534976,
  "created_at" : "2016-05-25 21:13:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/zqebceWFP9",
      "expanded_url" : "http:\/\/go.wh.gov\/xgHJj3",
      "display_url" : "go.wh.gov\/xgHJj3"
    } ]
  },
  "geo" : { },
  "id_str" : "735578033361408000",
  "text" : "Author Viet Thanh Nguyen was born to parents who fled the Vietnam War. Read his thoughts on our past with Vietnam: https:\/\/t.co\/zqebceWFP9",
  "id" : 735578033361408000,
  "created_at" : "2016-05-25 21:07:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 19, 22 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CancerMoonshot",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/6wI8vHhdyR",
      "expanded_url" : "http:\/\/go.wh.gov\/Join-the-Moonshot",
      "display_url" : "go.wh.gov\/Join-the-Moons\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "735564190404874240",
  "text" : "RT @VPLive: Today, @VP asked hundreds of Americans to host local #CancerMoonshot summits. Join them: https:\/\/t.co\/6wI8vHhdyR https:\/\/t.co\/k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 7, 10 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/735564124642414592\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/kPJ1r0cQbs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjU_rGcW0AAqyvH.jpg",
        "id_str" : "735564123841417216",
        "id" : 735564123841417216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjU_rGcW0AAqyvH.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kPJ1r0cQbs"
      } ],
      "hashtags" : [ {
        "text" : "CancerMoonshot",
        "indices" : [ 53, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/6wI8vHhdyR",
        "expanded_url" : "http:\/\/go.wh.gov\/Join-the-Moonshot",
        "display_url" : "go.wh.gov\/Join-the-Moons\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "735564124642414592",
    "text" : "Today, @VP asked hundreds of Americans to host local #CancerMoonshot summits. Join them: https:\/\/t.co\/6wI8vHhdyR https:\/\/t.co\/kPJ1r0cQbs",
    "id" : 735564124642414592,
    "created_at" : "2016-05-25 20:12:08 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 735564190404874240,
  "created_at" : "2016-05-25 20:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 40, 51 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Turnaround Arts",
      "screen_name" : "TurnaroundArts",
      "indices" : [ 71, 86 ],
      "id_str" : "552856411",
      "id" : 552856411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/d17tb57X9Y",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "735546348330754048",
  "text" : "RT @FLOTUS: It's Talent Show day at the @WhiteHouse! Join us live with @TurnaroundArts at 4pm ET: https:\/\/t.co\/d17tb57X9Y https:\/\/t.co\/QCMv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 28, 39 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Turnaround Arts",
        "screen_name" : "TurnaroundArts",
        "indices" : [ 59, 74 ],
        "id_str" : "552856411",
        "id" : 552856411
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/735545996168421376\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/QCMvzeKtvi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjUvJCUUUAAbNEb.jpg",
        "id_str" : "735545946432360448",
        "id" : 735545946432360448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjUvJCUUUAAbNEb.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        } ],
        "display_url" : "pic.twitter.com\/QCMvzeKtvi"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/d17tb57X9Y",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "735545996168421376",
    "text" : "It's Talent Show day at the @WhiteHouse! Join us live with @TurnaroundArts at 4pm ET: https:\/\/t.co\/d17tb57X9Y https:\/\/t.co\/QCMvzeKtvi",
    "id" : 735545996168421376,
    "created_at" : "2016-05-25 19:00:05 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 735546348330754048,
  "created_at" : "2016-05-25 19:01:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/zqebceWFP9",
      "expanded_url" : "http:\/\/go.wh.gov\/xgHJj3",
      "display_url" : "go.wh.gov\/xgHJj3"
    } ]
  },
  "geo" : { },
  "id_str" : "735507278837755904",
  "text" : "Vietnamese-American author Viet Thanh Nguyen shares his thoughts on @POTUS's recent trip to Vietnam: https:\/\/t.co\/zqebceWFP9",
  "id" : 735507278837755904,
  "created_at" : "2016-05-25 16:26:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 5, 11 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/N11atWOhJI",
      "expanded_url" : "http:\/\/snpy.tv\/1RoGfZL",
      "display_url" : "snpy.tv\/1RoGfZL"
    } ]
  },
  "geo" : { },
  "id_str" : "735501955578003456",
  "text" : "When @POTUS went to Elkhart in 2009, it was reeling from the recession. Next week, he'll highlight its recovery: https:\/\/t.co\/N11atWOhJI",
  "id" : 735501955578003456,
  "created_at" : "2016-05-25 16:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/735495441371009024\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/YL7IsytFaD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjUBDFIUgAAONg6.jpg",
      "id_str" : "735495266573254656",
      "id" : 735495266573254656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjUBDFIUgAAONg6.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YL7IsytFaD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/IlwRRslPrg",
      "expanded_url" : "http:\/\/go.wh.gov\/Elkhart",
      "display_url" : "go.wh.gov\/Elkhart"
    } ]
  },
  "geo" : { },
  "id_str" : "735495441371009024",
  "text" : "Next Wed., @POTUS will return to Elkhart, Indiana\u2014the site of his first trip as President: https:\/\/t.co\/IlwRRslPrg https:\/\/t.co\/YL7IsytFaD",
  "id" : 735495441371009024,
  "created_at" : "2016-05-25 15:39:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/UyKWqkfljE",
      "expanded_url" : "http:\/\/go.wh.gov\/Bd4kga",
      "display_url" : "go.wh.gov\/Bd4kga"
    } ]
  },
  "geo" : { },
  "id_str" : "735468691723321346",
  "text" : "RT @WHLive: Tune in: @POTUS holds a press conference in Shima City, Japan \u2192 https:\/\/t.co\/UyKWqkfljE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 9, 15 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/UyKWqkfljE",
        "expanded_url" : "http:\/\/go.wh.gov\/Bd4kga",
        "display_url" : "go.wh.gov\/Bd4kga"
      } ]
    },
    "geo" : { },
    "id_str" : "735467384358744065",
    "text" : "Tune in: @POTUS holds a press conference in Shima City, Japan \u2192 https:\/\/t.co\/UyKWqkfljE",
    "id" : 735467384358744065,
    "created_at" : "2016-05-25 13:47:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 735468691723321346,
  "created_at" : "2016-05-25 13:52:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 51, 57 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/735284603166986246\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/UXLLkJGNru",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CjQ_ndWUUAAd-ov.jpg",
      "id_str" : "735282586293915648",
      "id" : 735282586293915648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CjQ_ndWUUAAd-ov.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UXLLkJGNru"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/IlwRRs4e2G",
      "expanded_url" : "http:\/\/go.wh.gov\/Elkhart",
      "display_url" : "go.wh.gov\/Elkhart"
    } ]
  },
  "geo" : { },
  "id_str" : "735284603166986246",
  "text" : "This is what progress looks like. \n\n7 years later, @POTUS will return to Elkhart, Indiana: https:\/\/t.co\/IlwRRs4e2G https:\/\/t.co\/UXLLkJGNru",
  "id" : 735284603166986246,
  "created_at" : "2016-05-25 01:41:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/IlwRRs4e2G",
      "expanded_url" : "http:\/\/go.wh.gov\/Elkhart",
      "display_url" : "go.wh.gov\/Elkhart"
    } ]
  },
  "geo" : { },
  "id_str" : "735280847163523072",
  "text" : "\"The story of Elkhart's recovery is the story of America's recovery.\" \u2014@POTUS on why he's going back to Elkhart, IN: https:\/\/t.co\/IlwRRs4e2G",
  "id" : 735280847163523072,
  "created_at" : "2016-05-25 01:26:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/N11atWwGSa",
      "expanded_url" : "http:\/\/snpy.tv\/1RoGfZL",
      "display_url" : "snpy.tv\/1RoGfZL"
    } ]
  },
  "geo" : { },
  "id_str" : "735274383510507520",
  "text" : "BREAKING: @POTUS is returning to Elkhart, Indiana\u2014the first city he visited as president. Here's why: https:\/\/t.co\/N11atWwGSa",
  "id" : 735274383510507520,
  "created_at" : "2016-05-25 01:00:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "Senate Republicans",
      "screen_name" : "SenateGOP",
      "indices" : [ 35, 45 ],
      "id_str" : "14344823",
      "id" : 14344823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735228270925512704",
  "text" : "RT @SCOTUSnom: Young Iowans to the @SenateGOP: \u201CWhy do you play politics with decisions that could affect the rest of my life?\u201D https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senate Republicans",
        "screen_name" : "SenateGOP",
        "indices" : [ 20, 30 ],
        "id_str" : "14344823",
        "id" : 14344823
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/OAeerUCX72",
        "expanded_url" : "http:\/\/go.wh.gov\/KwMGGP",
        "display_url" : "go.wh.gov\/KwMGGP"
      } ]
    },
    "geo" : { },
    "id_str" : "735226392598609920",
    "text" : "Young Iowans to the @SenateGOP: \u201CWhy do you play politics with decisions that could affect the rest of my life?\u201D https:\/\/t.co\/OAeerUCX72",
    "id" : 735226392598609920,
    "created_at" : "2016-05-24 21:50:06 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 735228270925512704,
  "created_at" : "2016-05-24 21:57:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 27, 30 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 96, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735197058374750208",
  "text" : "RT @VPLive: Happening now: @VP is speaking to state and local officials about what we can do to #StopGunViolence. Watch here: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 15, 18 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 84, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/dQbwazb3ZC",
        "expanded_url" : "http:\/\/WH.gov\/Live",
        "display_url" : "WH.gov\/Live"
      } ]
    },
    "geo" : { },
    "id_str" : "735194842515415040",
    "text" : "Happening now: @VP is speaking to state and local officials about what we can do to #StopGunViolence. Watch here: https:\/\/t.co\/dQbwazb3ZC",
    "id" : 735194842515415040,
    "created_at" : "2016-05-24 19:44:44 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 735197058374750208,
  "created_at" : "2016-05-24 19:53:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vietnam",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/SDldDf5H7c",
      "expanded_url" : "http:\/\/snpy.tv\/1s7dexk",
      "display_url" : "snpy.tv\/1s7dexk"
    } ]
  },
  "geo" : { },
  "id_str" : "735180992181243905",
  "text" : "RT @NSC44: \u201CA different future is possible when we refuse to be prisoners of the past\u201D-@POTUS in #Vietnam\nhttps:\/\/t.co\/SDldDf5H7c",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 76, 82 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Vietnam",
        "indices" : [ 86, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/SDldDf5H7c",
        "expanded_url" : "http:\/\/snpy.tv\/1s7dexk",
        "display_url" : "snpy.tv\/1s7dexk"
      } ]
    },
    "geo" : { },
    "id_str" : "735177772893491204",
    "text" : "\u201CA different future is possible when we refuse to be prisoners of the past\u201D-@POTUS in #Vietnam\nhttps:\/\/t.co\/SDldDf5H7c",
    "id" : 735177772893491204,
    "created_at" : "2016-05-24 18:36:54 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 735180992181243905,
  "created_at" : "2016-05-24 18:49:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/fbq55RnSVm",
      "expanded_url" : "http:\/\/snpy.tv\/1Wfxqti",
      "display_url" : "snpy.tv\/1Wfxqti"
    } ]
  },
  "geo" : { },
  "id_str" : "735140797822173184",
  "text" : "\"We also remember the longer history between Vietnamese and Americans that is too often overlooked.\" \u2014@POTUS https:\/\/t.co\/fbq55RnSVm",
  "id" : 735140797822173184,
  "created_at" : "2016-05-24 16:09:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/uXkoIh9PBE",
      "expanded_url" : "http:\/\/snpy.tv\/1s7dexk",
      "display_url" : "snpy.tv\/1s7dexk"
    } ]
  },
  "geo" : { },
  "id_str" : "735126998343782402",
  "text" : "\"Now we can say something that was once unimaginable:  Today, Vietnam and the United States are partners.\" \u2014@POTUS https:\/\/t.co\/uXkoIh9PBE",
  "id" : 735126998343782402,
  "created_at" : "2016-05-24 15:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/7OKYvW2ofq",
      "expanded_url" : "http:\/\/snpy.tv\/1TKhWLJ",
      "display_url" : "snpy.tv\/1TKhWLJ"
    } ]
  },
  "geo" : { },
  "id_str" : "735122710330630148",
  "text" : "\"Vietnam has achieved enormous progress, and today the world can see the strides you have made\" \u2014@POTUS  https:\/\/t.co\/7OKYvW2ofq",
  "id" : 735122710330630148,
  "created_at" : "2016-05-24 14:58:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/flRt0FKyOH",
      "expanded_url" : "http:\/\/snpy.tv\/1XQZrqQ",
      "display_url" : "snpy.tv\/1XQZrqQ"
    } ]
  },
  "geo" : { },
  "id_str" : "735119456364466177",
  "text" : "\"Our veterans and families of the fallen still ache for the friends and loved ones they lost.\" \u2014@POTUS in Vietnam https:\/\/t.co\/flRt0FKyOH",
  "id" : 735119456364466177,
  "created_at" : "2016-05-24 14:45:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/flRt0FKyOH",
      "expanded_url" : "http:\/\/snpy.tv\/1XQZrqQ",
      "display_url" : "snpy.tv\/1XQZrqQ"
    } ]
  },
  "geo" : { },
  "id_str" : "735116732499533825",
  "text" : "\"I come here mindful of the past, mindful of our difficult history, but focused on the future\" \u2014@POTUS in Vietnam   https:\/\/t.co\/flRt0FKyOH",
  "id" : 735116732499533825,
  "created_at" : "2016-05-24 14:34:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodtrouble",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735114225710829568",
  "text" : "RT @repjohnlewis: 55 years ago today, I was arrested in the Jackson, MS bus station for using a \"whites-only\" restroom. #goodtrouble https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/repjohnlewis\/status\/735101117223297026\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/v8zeqfVl75",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjOakhmWEAAK4ky.jpg",
        "id_str" : "735101116476690432",
        "id" : 735101116476690432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjOakhmWEAAK4ky.jpg",
        "sizes" : [ {
          "h" : 614,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 614,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/v8zeqfVl75"
      } ],
      "hashtags" : [ {
        "text" : "goodtrouble",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "735101117223297026",
    "text" : "55 years ago today, I was arrested in the Jackson, MS bus station for using a \"whites-only\" restroom. #goodtrouble https:\/\/t.co\/v8zeqfVl75",
    "id" : 735101117223297026,
    "created_at" : "2016-05-24 13:32:18 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 735114225710829568,
  "created_at" : "2016-05-24 14:24:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 6, 15 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/FKr9OeuX1b",
      "expanded_url" : "http:\/\/go.wh.gov\/Vietnam",
      "display_url" : "go.wh.gov\/Vietnam"
    }, {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/U7RShKORKA",
      "expanded_url" : "http:\/\/snpy.tv\/1TJK8yo",
      "display_url" : "snpy.tv\/1TJK8yo"
    } ]
  },
  "geo" : { },
  "id_str" : "735086087056433152",
  "text" : "Watch @Rhodes44 on why @POTUS is in Vietnam this week \u2192 https:\/\/t.co\/FKr9OeuX1b https:\/\/t.co\/U7RShKORKA",
  "id" : 735086087056433152,
  "created_at" : "2016-05-24 12:32:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/734884793154834432\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/WnSKlQ34L2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjLVxbbWUAETbCI.jpg",
      "id_str" : "734884734367584257",
      "id" : 734884734367584257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjLVxbbWUAETbCI.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WnSKlQ34L2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734884793154834432",
  "text" : "We've now seen 68 days of Senate Republicans blocking @POTUS's Supreme Court nominee\u2014this is next-level obstruction. https:\/\/t.co\/WnSKlQ34L2",
  "id" : 734884793154834432,
  "created_at" : "2016-05-23 23:12:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/xWNI4XoQrt",
      "expanded_url" : "http:\/\/snpy.tv\/1RkFdhE",
      "display_url" : "snpy.tv\/1RkFdhE"
    } ]
  },
  "geo" : { },
  "id_str" : "734836590053232640",
  "text" : ".@POTUS announces lift on longstanding lethal weapons ban in Vietnam: https:\/\/t.co\/xWNI4XoQrt",
  "id" : 734836590053232640,
  "created_at" : "2016-05-23 20:01:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldTurtleDay",
      "indices" : [ 75, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/jxk9u7Y4mj",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/656a6721-d997-4e3a-8927-40852bddd594",
      "display_url" : "amp.twimg.com\/v\/656a6721-d99\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734821927722721280",
  "text" : "RT @Interior: From open ocean to inland desert, turtles are awesome! Happy #WorldTurtleDay\nhttps:\/\/t.co\/jxk9u7Y4mj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldTurtleDay",
        "indices" : [ 61, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/jxk9u7Y4mj",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/656a6721-d997-4e3a-8927-40852bddd594",
        "display_url" : "amp.twimg.com\/v\/656a6721-d99\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "734767083255259136",
    "text" : "From open ocean to inland desert, turtles are awesome! Happy #WorldTurtleDay\nhttps:\/\/t.co\/jxk9u7Y4mj",
    "id" : 734767083255259136,
    "created_at" : "2016-05-23 15:24:58 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 734821927722721280,
  "created_at" : "2016-05-23 19:02:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 41, 47 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJob",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734820588758437888",
  "text" : "RT @SCOTUSnom: Today marks 68 days since @POTUS announced his Supreme Court nominee.\n\nSenate Republicans, #DoYourJob. https:\/\/t.co\/zKHbhopr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 26, 32 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCOTUSnom\/status\/734764952095993857\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/zKHbhoprPv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjJoqBIW0AQjtvk.jpg",
        "id_str" : "734764760282091524",
        "id" : 734764760282091524,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjJoqBIW0AQjtvk.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zKHbhoprPv"
      } ],
      "hashtags" : [ {
        "text" : "DoYourJob",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "734764952095993857",
    "text" : "Today marks 68 days since @POTUS announced his Supreme Court nominee.\n\nSenate Republicans, #DoYourJob. https:\/\/t.co\/zKHbhoprPv",
    "id" : 734764952095993857,
    "created_at" : "2016-05-23 15:16:30 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 734820588758437888,
  "created_at" : "2016-05-23 18:57:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ParisAgreement",
      "indices" : [ 50, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734817491990548480",
  "text" : "RT @Deese44: Today Vietnam announced it will join #ParisAgreement in '16, joining nearly 40 countries &amp; &gt; 50% of global emissions https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ParisAgreement",
        "indices" : [ 37, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 124, 147 ],
        "url" : "https:\/\/t.co\/fDC8Ff56E0",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/05\/23\/joint-statement-between-united-states-america-and-socialist-republic",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "734807083120398336",
    "text" : "Today Vietnam announced it will join #ParisAgreement in '16, joining nearly 40 countries &amp; &gt; 50% of global emissions https:\/\/t.co\/fDC8Ff56E0",
    "id" : 734807083120398336,
    "created_at" : "2016-05-23 18:03:55 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 734817491990548480,
  "created_at" : "2016-05-23 18:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Bourdain",
      "screen_name" : "Bourdain",
      "indices" : [ 3, 12 ],
      "id_str" : "14353392",
      "id" : 14353392
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Bourdain\/status\/734772293830737920\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/KgC3VIEPQr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjJvf0sUoAEjXej.jpg",
      "id_str" : "734772281725984769",
      "id" : 734772281725984769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjJvf0sUoAEjXej.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/KgC3VIEPQr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734797635438153729",
  "text" : "RT @Bourdain: Low plastic stool,  cheap but delicious noodles, cold Hanoi beer. https:\/\/t.co\/KgC3VIEPQr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Bourdain\/status\/734772293830737920\/photo\/1",
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/KgC3VIEPQr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjJvf0sUoAEjXej.jpg",
        "id_str" : "734772281725984769",
        "id" : 734772281725984769,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjJvf0sUoAEjXej.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/KgC3VIEPQr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "734772293830737920",
    "text" : "Low plastic stool,  cheap but delicious noodles, cold Hanoi beer. https:\/\/t.co\/KgC3VIEPQr",
    "id" : 734772293830737920,
    "created_at" : "2016-05-23 15:45:40 +0000",
    "user" : {
      "name" : "Anthony Bourdain",
      "screen_name" : "Bourdain",
      "protected" : false,
      "id_str" : "14353392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/597095222129074178\/COl1Zyl1_normal.jpg",
      "id" : 14353392,
      "verified" : true
    }
  },
  "id" : 734797635438153729,
  "created_at" : "2016-05-23 17:26:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/mDNNBHMql3",
      "expanded_url" : "http:\/\/snpy.tv\/1XNoZ84",
      "display_url" : "snpy.tv\/1XNoZ84"
    } ]
  },
  "geo" : { },
  "id_str" : "734790772411621377",
  "text" : "\"We will continue to speak out on behalf of human rights that we believe are universal\" \u2014@POTUS in Vietnam https:\/\/t.co\/mDNNBHMql3",
  "id" : 734790772411621377,
  "created_at" : "2016-05-23 16:59:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/8zfB6AfTX6",
      "expanded_url" : "http:\/\/snpy.tv\/1RkFaSS",
      "display_url" : "snpy.tv\/1RkFaSS"
    } ]
  },
  "geo" : { },
  "id_str" : "734787272076234752",
  "text" : "\"We believe the people of this region should live in security, prosperity and dignity.\" \u2014@POTUS in Vietnam   https:\/\/t.co\/8zfB6AfTX6",
  "id" : 734787272076234752,
  "created_at" : "2016-05-23 16:45:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ge2YvfxYn2",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/05\/23\/fact-sheet-united-states-vietnam-relations",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734783567310520322",
  "text" : "RT @AmbassadorRice: Lifting the lethal weapons embargo opens another chapter in growing US-Vietnam relations: https:\/\/t.co\/ge2YvfxYn2 https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmbassadorRice\/status\/734773244104843264\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/wkTAdRBeIc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjJwPC6UgAAknfb.jpg",
        "id_str" : "734773092996644864",
        "id" : 734773092996644864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjJwPC6UgAAknfb.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/wkTAdRBeIc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/ge2YvfxYn2",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/05\/23\/fact-sheet-united-states-vietnam-relations",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "734773244104843264",
    "text" : "Lifting the lethal weapons embargo opens another chapter in growing US-Vietnam relations: https:\/\/t.co\/ge2YvfxYn2 https:\/\/t.co\/wkTAdRBeIc",
    "id" : 734773244104843264,
    "created_at" : "2016-05-23 15:49:27 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 734783567310520322,
  "created_at" : "2016-05-23 16:30:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaInVietnam",
      "indices" : [ 89, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/xWNI4X7fzV",
      "expanded_url" : "http:\/\/snpy.tv\/1RkFdhE",
      "display_url" : "snpy.tv\/1RkFdhE"
    } ]
  },
  "geo" : { },
  "id_str" : "734782103255187456",
  "text" : "\"The U.S. is fully lifting the ban on the sale of military equipment to Vietnam\" \u2014@POTUS #ObamaInVietnam   https:\/\/t.co\/xWNI4X7fzV",
  "id" : 734782103255187456,
  "created_at" : "2016-05-23 16:24:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaInVietnam",
      "indices" : [ 108, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/9IHLAHhU52",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/05\/23\/fact-sheet-united-states-vietnam-relations",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "734779967888887810",
  "text" : "RT @NSC44: The US and Vietnam are deepening relations across issues. Get the facts: https:\/\/t.co\/9IHLAHhU52\n#ObamaInVietnam https:\/\/t.co\/Au\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/734772868437835776\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/AukbWhijxD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjJwB4qWYAAfxnb.jpg",
        "id_str" : "734772866907004928",
        "id" : 734772866907004928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjJwB4qWYAAfxnb.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/AukbWhijxD"
      } ],
      "hashtags" : [ {
        "text" : "ObamaInVietnam",
        "indices" : [ 97, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/9IHLAHhU52",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/05\/23\/fact-sheet-united-states-vietnam-relations",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "734772868437835776",
    "text" : "The US and Vietnam are deepening relations across issues. Get the facts: https:\/\/t.co\/9IHLAHhU52\n#ObamaInVietnam https:\/\/t.co\/AukbWhijxD",
    "id" : 734772868437835776,
    "created_at" : "2016-05-23 15:47:57 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 734779967888887810,
  "created_at" : "2016-05-23 16:16:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Anthony Bourdain",
      "screen_name" : "Bourdain",
      "indices" : [ 57, 66 ],
      "id_str" : "14353392",
      "id" : 14353392
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/734764844042293249\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/z1XgbMlp9J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjJnxMfWEAE0UOY.jpg",
      "id_str" : "734763784078757889",
      "id" : 734763784078757889,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjJnxMfWEAE0UOY.jpg",
      "sizes" : [ {
        "h" : 1062,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 1007,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 590,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/z1XgbMlp9J"
    } ],
    "hashtags" : [ {
      "text" : "Hanoi",
      "indices" : [ 87, 93 ]
    }, {
      "text" : "VietnamVisit",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734764844042293249",
  "text" : "Sneak peek: Today @POTUS sat down with @PartsUnkownCNN's @Bourdain during his visit to #Hanoi. #VietnamVisit https:\/\/t.co\/z1XgbMlp9J",
  "id" : 734764844042293249,
  "created_at" : "2016-05-23 15:16:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/734754575543107585\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/uWC0t7C9Mw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjJfTn9W0AIsyKv.jpg",
      "id_str" : "734754479963295746",
      "id" : 734754479963295746,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjJfTn9W0AIsyKv.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uWC0t7C9Mw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/3A1mkoMoYD",
      "expanded_url" : "http:\/\/go.wh.gov\/Vietnam",
      "display_url" : "go.wh.gov\/Vietnam"
    } ]
  },
  "geo" : { },
  "id_str" : "734758114726170624",
  "text" : "RT @rhodes44: .@POTUS is the 3rd U.S. president to visit Vietnam in just over 20 years: https:\/\/t.co\/3A1mkoMoYD https:\/\/t.co\/uWC0t7C9Mw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/734754575543107585\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/uWC0t7C9Mw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjJfTn9W0AIsyKv.jpg",
        "id_str" : "734754479963295746",
        "id" : 734754479963295746,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjJfTn9W0AIsyKv.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/uWC0t7C9Mw"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/3A1mkoMoYD",
        "expanded_url" : "http:\/\/go.wh.gov\/Vietnam",
        "display_url" : "go.wh.gov\/Vietnam"
      } ]
    },
    "geo" : { },
    "id_str" : "734754575543107585",
    "text" : ".@POTUS is the 3rd U.S. president to visit Vietnam in just over 20 years: https:\/\/t.co\/3A1mkoMoYD https:\/\/t.co\/uWC0t7C9Mw",
    "id" : 734754575543107585,
    "created_at" : "2016-05-23 14:35:16 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 734758114726170624,
  "created_at" : "2016-05-23 14:49:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Parts Unknown",
      "screen_name" : "PartsUnknownCNN",
      "indices" : [ 3, 19 ],
      "id_str" : "930223086",
      "id" : 930223086
    }, {
      "name" : "Anthony Bourdain",
      "screen_name" : "Bourdain",
      "indices" : [ 22, 31 ],
      "id_str" : "14353392",
      "id" : 14353392
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 49, 55 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PartsUnknown",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734753828705341441",
  "text" : "RT @PartsUnknownCNN: .@Bourdain to have dinner w\/@POTUS tonight in Hanoi, Vietnam. Their conversation will be in #PartsUnknown in Sept! htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anthony Bourdain",
        "screen_name" : "Bourdain",
        "indices" : [ 1, 10 ],
        "id_str" : "14353392",
        "id" : 14353392
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 28, 34 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PartsUnknownCNN\/status\/734739649428660225\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/OaOX2F4xW7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CjJR0R2WUAAtb3o.jpg",
        "id_str" : "734739647801217024",
        "id" : 734739647801217024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjJR0R2WUAAtb3o.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 569,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 862,
          "resize" : "fit",
          "w" : 1552
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OaOX2F4xW7"
      } ],
      "hashtags" : [ {
        "text" : "PartsUnknown",
        "indices" : [ 92, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "734739649428660225",
    "text" : ".@Bourdain to have dinner w\/@POTUS tonight in Hanoi, Vietnam. Their conversation will be in #PartsUnknown in Sept! https:\/\/t.co\/OaOX2F4xW7",
    "id" : 734739649428660225,
    "created_at" : "2016-05-23 13:35:57 +0000",
    "user" : {
      "name" : "Parts Unknown",
      "screen_name" : "PartsUnknownCNN",
      "protected" : false,
      "id_str" : "930223086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732247121387257862\/K-4gy5rR_normal.jpg",
      "id" : 930223086,
      "verified" : true
    }
  },
  "id" : 734753828705341441,
  "created_at" : "2016-05-23 14:32:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/VlcJt9ioZB",
      "expanded_url" : "http:\/\/go.wh.gov\/ugsUpV",
      "display_url" : "go.wh.gov\/ugsUpV"
    } ]
  },
  "geo" : { },
  "id_str" : "734619959721111553",
  "text" : "Watch @POTUS hold a press conference with President Quang of Vietnam: https:\/\/t.co\/VlcJt9ioZB",
  "id" : 734619959721111553,
  "created_at" : "2016-05-23 05:40:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "WH Internship",
      "screen_name" : "WHInternship",
      "indices" : [ 80, 93 ],
      "id_str" : "4530405972",
      "id" : 4530405972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/aTUFb1mxpC",
      "expanded_url" : "http:\/\/go.wh.gov\/E1bCC3",
      "display_url" : "go.wh.gov\/E1bCC3"
    } ]
  },
  "geo" : { },
  "id_str" : "734571073606291457",
  "text" : "\"You really can make a difference.\" \u2014@POTUS to the outgoing spring class of the @WHInternship program: https:\/\/t.co\/aTUFb1mxpC",
  "id" : 734571073606291457,
  "created_at" : "2016-05-23 02:26:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Rutgers University",
      "screen_name" : "RutgersU",
      "indices" : [ 26, 35 ],
      "id_str" : "19272796",
      "id" : 19272796
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 53, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/VnSypa97qb",
      "expanded_url" : "http:\/\/snpy.tv\/20oj0p6",
      "display_url" : "snpy.tv\/20oj0p6"
    } ]
  },
  "geo" : { },
  "id_str" : "734542906804035584",
  "text" : "Watch @POTUS speak to the @RutgersU Class of 2016 in #WestWingWeek: https:\/\/t.co\/VnSypa97qb",
  "id" : 734542906804035584,
  "created_at" : "2016-05-23 00:34:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "734470111260758017",
  "text" : "RT @Denis44: Sound advice for Congress on Zika from someone who did good work on Ebola: \"Early detection, early response.\u201D \nhttps:\/\/t.co\/vf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/vfDsEAWetT",
        "expanded_url" : "https:\/\/www.washingtonpost.com\/opinions\/zika-is-coming-but-were-far-from-ready\/2016\/05\/21\/380ec54e-1dc3-11e6-9c81-4be1c14fb8c8_story.html",
        "display_url" : "washingtonpost.com\/opinions\/zika-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "734454022762024960",
    "text" : "Sound advice for Congress on Zika from someone who did good work on Ebola: \"Early detection, early response.\u201D \nhttps:\/\/t.co\/vfDsEAWetT",
    "id" : 734454022762024960,
    "created_at" : "2016-05-22 18:40:59 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 734470111260758017,
  "created_at" : "2016-05-22 19:44:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/h2rqrD71n4",
      "expanded_url" : "http:\/\/go.wh.gov\/zkZRtT",
      "display_url" : "go.wh.gov\/zkZRtT"
    }, {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/MXw1SmVqv3",
      "expanded_url" : "http:\/\/go.wh.gov\/zUUAQb",
      "display_url" : "go.wh.gov\/zUUAQb"
    } ]
  },
  "geo" : { },
  "id_str" : "734420666640896000",
  "text" : "Here's why @POTUS made a cameo on one of Cuba's biggest comedy shows:  https:\/\/t.co\/h2rqrD71n4 https:\/\/t.co\/MXw1SmVqv3",
  "id" : 734420666640896000,
  "created_at" : "2016-05-22 16:28:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/fwDsYkIM4r",
      "expanded_url" : "http:\/\/go.wh.gov\/2g6qoS",
      "display_url" : "go.wh.gov\/2g6qoS"
    } ]
  },
  "geo" : { },
  "id_str" : "734080832025985026",
  "text" : "\"This week, my Administration took a step to help more workers get the overtime pay they\u2019ve earned.\" \u2014@POTUS: https:\/\/t.co\/fwDsYkIM4r",
  "id" : 734080832025985026,
  "created_at" : "2016-05-21 17:58:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/fwDsYkIM4r",
      "expanded_url" : "http:\/\/go.wh.gov\/2g6qoS",
      "display_url" : "go.wh.gov\/2g6qoS"
    } ]
  },
  "geo" : { },
  "id_str" : "734065742652395520",
  "text" : "\"Only seven percent of full-time salaried workers are eligible for overtime based on their income.\" \u2014@POTUS: https:\/\/t.co\/fwDsYkIM4r",
  "id" : 734065742652395520,
  "created_at" : "2016-05-21 16:58:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/fwDsYkIM4r",
      "expanded_url" : "http:\/\/go.wh.gov\/2g6qoS",
      "display_url" : "go.wh.gov\/2g6qoS"
    } ]
  },
  "geo" : { },
  "id_str" : "734050391189426178",
  "text" : "\"For all the changes we\u2019ve seen in our economy, our overtime rules have only been updated once since the 1970s.\" https:\/\/t.co\/fwDsYkIM4r",
  "id" : 734050391189426178,
  "created_at" : "2016-05-21 15:57:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/fwDsYkIM4r",
      "expanded_url" : "http:\/\/go.wh.gov\/2g6qoS",
      "display_url" : "go.wh.gov\/2g6qoS"
    } ]
  },
  "geo" : { },
  "id_str" : "734034818090962946",
  "text" : "\"Things like the 40-hour workweek and overtime are two of the most basic pillars of a middle class life.\" \u2014@POTUS: https:\/\/t.co\/fwDsYkIM4r",
  "id" : 734034818090962946,
  "created_at" : "2016-05-21 14:55:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 42, 55 ],
      "id_str" : "426909329",
      "id" : 426909329
    }, {
      "name" : "anthony fauci",
      "screen_name" : "anthonyfauci",
      "indices" : [ 62, 75 ],
      "id_str" : "119040125",
      "id" : 119040125
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/RzXhEdbQJR",
      "expanded_url" : "http:\/\/snpy.tv\/1XFwM84",
      "display_url" : "snpy.tv\/1XFwM84"
    } ]
  },
  "geo" : { },
  "id_str" : "733761745232203776",
  "text" : "\"We have a narrow window of opportunity\" \u2014@DrFriedenCDC &amp; @AnthonyFauci share why Congress must act on #Zika now: https:\/\/t.co\/RzXhEdbQJR",
  "id" : 733761745232203776,
  "created_at" : "2016-05-20 20:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/733726581571522560\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/jWiN1OVF5v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci6w2C4XIAEV3vx.jpg",
      "id_str" : "733718231840661505",
      "id" : 733718231840661505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci6w2C4XIAEV3vx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jWiN1OVF5v"
    } ],
    "hashtags" : [ {
      "text" : "WildlifeWin",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/ETnqhpGKPX",
      "expanded_url" : "http:\/\/go.wh.gov\/WildlifeWins",
      "display_url" : "go.wh.gov\/WildlifeWins"
    } ]
  },
  "geo" : { },
  "id_str" : "733726581571522560",
  "text" : "We've got 99 wins for wildlife and a black bear is one \u2192 https:\/\/t.co\/ETnqhpGKPX  #WildlifeWin https:\/\/t.co\/jWiN1OVF5v",
  "id" : 733726581571522560,
  "created_at" : "2016-05-20 18:30:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/733720215221993472\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/6fKzUvTotM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci6weGtWUAAvMC-.jpg",
      "id_str" : "733717820551352320",
      "id" : 733717820551352320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci6weGtWUAAvMC-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6fKzUvTotM"
    } ],
    "hashtags" : [ {
      "text" : "EndangeredSpeciesDay",
      "indices" : [ 5, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/ETnqhpGKPX",
      "expanded_url" : "http:\/\/go.wh.gov\/WildlifeWins",
      "display_url" : "go.wh.gov\/WildlifeWins"
    } ]
  },
  "geo" : { },
  "id_str" : "733720215221993472",
  "text" : "This #EndangeredSpeciesDay, see what @POTUS has done to save our country's wildlife \u2192 https:\/\/t.co\/ETnqhpGKPX https:\/\/t.co\/6fKzUvTotM",
  "id" : 733720215221993472,
  "created_at" : "2016-05-20 18:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/uBpzMGgJpO",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/56a3cf37-fd01-4c37-a57c-3ec140cf856a",
      "display_url" : "amp.twimg.com\/v\/56a3cf37-fd0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733716047073665024",
  "text" : "RT @VP: Got to do two things I love this week: Eat some ice cream, and make sure our workers get paid fairly.\nhttps:\/\/t.co\/uBpzMGgJpO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/uBpzMGgJpO",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/56a3cf37-fd01-4c37-a57c-3ec140cf856a",
        "display_url" : "amp.twimg.com\/v\/56a3cf37-fd0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733715601630232576",
    "text" : "Got to do two things I love this week: Eat some ice cream, and make sure our workers get paid fairly.\nhttps:\/\/t.co\/uBpzMGgJpO",
    "id" : 733715601630232576,
    "created_at" : "2016-05-20 17:46:45 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 733716047073665024,
  "created_at" : "2016-05-20 17:48:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 31, 37 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerJobs",
      "indices" : [ 10, 21 ]
    }, {
      "text" : "SummerOpportunityProject",
      "indices" : [ 75, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/uHQnamj5Cz",
      "expanded_url" : "http:\/\/summerlearning.org",
      "display_url" : "summerlearning.org"
    } ]
  },
  "geo" : { },
  "id_str" : "733709353354596353",
  "text" : "RT @vj44: #SummerJobs is a top @POTUS priority. This year, we launched the #SummerOpportunityProject: https:\/\/t.co\/uHQnamj5Cz. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 21, 27 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SummerJobs",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "SummerOpportunityProject",
        "indices" : [ 65, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/uHQnamj5Cz",
        "expanded_url" : "http:\/\/summerlearning.org",
        "display_url" : "summerlearning.org"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Z4bMUBZmKf",
        "expanded_url" : "https:\/\/twitter.com\/genprogress\/status\/733677128571576320",
        "display_url" : "twitter.com\/genprogress\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733705779472179200",
    "text" : "#SummerJobs is a top @POTUS priority. This year, we launched the #SummerOpportunityProject: https:\/\/t.co\/uHQnamj5Cz. https:\/\/t.co\/Z4bMUBZmKf",
    "id" : 733705779472179200,
    "created_at" : "2016-05-20 17:07:44 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 733709353354596353,
  "created_at" : "2016-05-20 17:21:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "U.S. FDA",
      "screen_name" : "US_FDA",
      "indices" : [ 19, 26 ],
      "id_str" : "208120290",
      "id" : 208120290
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NutritionFacts",
      "indices" : [ 41, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733681310493999105",
  "text" : "RT @FLOTUS: Today, @US_FDA unveils a new #NutritionFacts label that gives families information they need to make healthy choices https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. FDA",
        "screen_name" : "US_FDA",
        "indices" : [ 7, 14 ],
        "id_str" : "208120290",
        "id" : 208120290
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/733673874760441856\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/AST9p5dK7z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci6IgD1WsAI7ycx.jpg",
        "id_str" : "733673873674252290",
        "id" : 733673873674252290,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci6IgD1WsAI7ycx.jpg",
        "sizes" : [ {
          "h" : 1757,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 1285,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 753,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/AST9p5dK7z"
      } ],
      "hashtags" : [ {
        "text" : "NutritionFacts",
        "indices" : [ 29, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733673874760441856",
    "text" : "Today, @US_FDA unveils a new #NutritionFacts label that gives families information they need to make healthy choices https:\/\/t.co\/AST9p5dK7z",
    "id" : 733673874760441856,
    "created_at" : "2016-05-20 15:00:57 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 733681310493999105,
  "created_at" : "2016-05-20 15:30:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WildlifeWin",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/R66Uf21KzF",
      "expanded_url" : "http:\/\/on.doi.gov\/1NxegMV",
      "display_url" : "on.doi.gov\/1NxegMV"
    } ]
  },
  "geo" : { },
  "id_str" : "733669015193669632",
  "text" : "RT @Interior: What do these cute, slimey, big, tiny, fuzzy, feathered animals have in common? #WildlifeWin https:\/\/t.co\/R66Uf21KzF https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/733379610952536065\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/XaIPfObY55",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci183pLWUAAaB5V.jpg",
        "id_str" : "733379609719361536",
        "id" : 733379609719361536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci183pLWUAAaB5V.jpg",
        "sizes" : [ {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1499,
          "resize" : "fit",
          "w" : 2235
        }, {
          "h" : 687,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XaIPfObY55"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/733379610952536065\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/XaIPfObY55",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci183GoXAAIJC2o.jpg",
        "id_str" : "733379600445800450",
        "id" : 733379600445800450,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci183GoXAAIJC2o.jpg",
        "sizes" : [ {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XaIPfObY55"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/733379610952536065\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/XaIPfObY55",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci183SgWEAAaQoU.jpg",
        "id_str" : "733379603633410048",
        "id" : 733379603633410048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci183SgWEAAaQoU.jpg",
        "sizes" : [ {
          "h" : 427,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1138,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 728,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XaIPfObY55"
      } ],
      "hashtags" : [ {
        "text" : "WildlifeWin",
        "indices" : [ 80, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/R66Uf21KzF",
        "expanded_url" : "http:\/\/on.doi.gov\/1NxegMV",
        "display_url" : "on.doi.gov\/1NxegMV"
      } ]
    },
    "geo" : { },
    "id_str" : "733379610952536065",
    "text" : "What do these cute, slimey, big, tiny, fuzzy, feathered animals have in common? #WildlifeWin https:\/\/t.co\/R66Uf21KzF https:\/\/t.co\/XaIPfObY55",
    "id" : 733379610952536065,
    "created_at" : "2016-05-19 19:31:39 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 733669015193669632,
  "created_at" : "2016-05-20 14:41:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/733660684697866241\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/WVjUxWMC6f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci58gR1XEAAdQeU.jpg",
      "id_str" : "733660683292839936",
      "id" : 733660683292839936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci58gR1XEAAdQeU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WVjUxWMC6f"
    } ],
    "hashtags" : [ {
      "text" : "WildlifeWin",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/p9KCRG9jmJ",
      "expanded_url" : "http:\/\/go.wh.gov\/WildlifeWin",
      "display_url" : "go.wh.gov\/WildlifeWin"
    } ]
  },
  "geo" : { },
  "id_str" : "733661679255314433",
  "text" : "RT @FactsOnClimate: Under @POTUS, we've had 99 wins for wildlife. Count 'em \u2192 https:\/\/t.co\/p9KCRG9jmJ #WildlifeWin https:\/\/t.co\/WVjUxWMC6f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/733660684697866241\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/WVjUxWMC6f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci58gR1XEAAdQeU.jpg",
        "id_str" : "733660683292839936",
        "id" : 733660683292839936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci58gR1XEAAdQeU.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/WVjUxWMC6f"
      } ],
      "hashtags" : [ {
        "text" : "WildlifeWin",
        "indices" : [ 82, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/p9KCRG9jmJ",
        "expanded_url" : "http:\/\/go.wh.gov\/WildlifeWin",
        "display_url" : "go.wh.gov\/WildlifeWin"
      } ]
    },
    "geo" : { },
    "id_str" : "733660684697866241",
    "text" : "Under @POTUS, we've had 99 wins for wildlife. Count 'em \u2192 https:\/\/t.co\/p9KCRG9jmJ #WildlifeWin https:\/\/t.co\/WVjUxWMC6f",
    "id" : 733660684697866241,
    "created_at" : "2016-05-20 14:08:32 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 733661679255314433,
  "created_at" : "2016-05-20 14:12:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 106, 115 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/733477903552393217\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/oJ4P4Ok4P4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ci3WFKvUUAApKf0.jpg",
      "id_str" : "733477698601766912",
      "id" : 733477698601766912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ci3WFKvUUAApKf0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 111,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 678
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 678
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oJ4P4Ok4P4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733477903552393217",
  "text" : "\"The U.S. stands ready to provide our full support and resources to the Governments of Egypt and France\" \u2014@PressSec: https:\/\/t.co\/oJ4P4Ok4P4",
  "id" : 733477903552393217,
  "created_at" : "2016-05-20 02:02:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Colby College",
      "screen_name" : "ColbyCollege",
      "indices" : [ 38, 51 ],
      "id_str" : "15937898",
      "id" : 15937898
    }, {
      "name" : "NMH School",
      "screen_name" : "NMHschool",
      "indices" : [ 56, 66 ],
      "id_str" : "19081488",
      "id" : 19081488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Graduation",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733421673865584640",
  "text" : "RT @vj44: I'm addressing graduates at @ColbyCollege and @NMHSchool this weekend! Qs on graduating &amp; summer jobs? Ask with #Graduation by 1p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Colby College",
        "screen_name" : "ColbyCollege",
        "indices" : [ 28, 41 ],
        "id_str" : "15937898",
        "id" : 15937898
      }, {
        "name" : "NMH School",
        "screen_name" : "NMHschool",
        "indices" : [ 46, 56 ],
        "id_str" : "19081488",
        "id" : 19081488
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Graduation",
        "indices" : [ 116, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "733404616725925889",
    "text" : "I'm addressing graduates at @ColbyCollege and @NMHSchool this weekend! Qs on graduating &amp; summer jobs? Ask with #Graduation by 1pm tomorrow",
    "id" : 733404616725925889,
    "created_at" : "2016-05-19 21:11:01 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 733421673865584640,
  "created_at" : "2016-05-19 22:18:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/733385754232139777\/photo\/1",
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/CTntVwug0o",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci2CayuXIAM0cT-.jpg",
      "id_str" : "733385711135694851",
      "id" : 733385711135694851,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Ci2CayuXIAM0cT-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/CTntVwug0o"
    } ],
    "hashtags" : [ {
      "text" : "ScienceRocks",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/ajqkTzKkj1",
      "expanded_url" : "http:\/\/go.wh.gov\/KidScienceAdvisors",
      "display_url" : "go.wh.gov\/KidScienceAdvi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733385754232139777",
  "text" : "#ScienceRocks https:\/\/t.co\/ajqkTzKkj1 https:\/\/t.co\/CTntVwug0o",
  "id" : 733385754232139777,
  "created_at" : "2016-05-19 19:56:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/BpzpZcMIHv",
      "expanded_url" : "http:\/\/snpy.tv\/27EG3BA",
      "display_url" : "snpy.tv\/27EG3BA"
    } ]
  },
  "geo" : { },
  "id_str" : "733374820101066753",
  "text" : "Astronomy Night \u2713\nHack-a-thon \u2713\nCode-a-thon \u2713\nScience Fair \u2713\nMaker Faire \u2713\n\n\"Science rocks.\"  \nhttps:\/\/t.co\/BpzpZcMIHv",
  "id" : 733374820101066753,
  "created_at" : "2016-05-19 19:12:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/BpzpZcMIHv",
      "expanded_url" : "http:\/\/snpy.tv\/27EG3BA",
      "display_url" : "snpy.tv\/27EG3BA"
    } ]
  },
  "geo" : { },
  "id_str" : "733372960560537600",
  "text" : "\"One nine-year-old named Jacob Leggette turned the tables and suggested we needed to start a kids' advisory\" \u2014@POTUS https:\/\/t.co\/BpzpZcMIHv",
  "id" : 733372960560537600,
  "created_at" : "2016-05-19 19:05:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEMmedals",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733369961939341312",
  "text" : "\u201CAmerica\u2019s astonishing progress in science and technology has countless revolutionary discoveries within our reach.\u201D \u2014@POTUS #STEMmedals",
  "id" : 733369961939341312,
  "created_at" : "2016-05-19 18:53:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/2NID8NMaoD",
      "expanded_url" : "http:\/\/snpy.tv\/1TmwJJ2",
      "display_url" : "snpy.tv\/1TmwJJ2"
    } ]
  },
  "geo" : { },
  "id_str" : "733368546651213826",
  "text" : "\u201CToday, I can announce that we are launching a \u2018Kid Science Advisors\u2019 campaign for young scientists and innovators\" https:\/\/t.co\/2NID8NMaoD",
  "id" : 733368546651213826,
  "created_at" : "2016-05-19 18:47:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEMmedals",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/NogeTvTspt",
      "expanded_url" : "http:\/\/go.wh.gov\/tpDANC",
      "display_url" : "go.wh.gov\/tpDANC"
    } ]
  },
  "geo" : { },
  "id_str" : "733367818545160192",
  "text" : "Watch as @POTUS presents our nation\u2019s highest honor for scientific and technological achievement \u2192 https:\/\/t.co\/NogeTvTspt #STEMmedals",
  "id" : 733367818545160192,
  "created_at" : "2016-05-19 18:44:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/ajqkTzKkj1",
      "expanded_url" : "http:\/\/go.wh.gov\/KidScienceAdvisors",
      "display_url" : "go.wh.gov\/KidScienceAdvi\u2026"
    }, {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/2NID8NMaoD",
      "expanded_url" : "http:\/\/snpy.tv\/1TmwJJ2",
      "display_url" : "snpy.tv\/1TmwJJ2"
    } ]
  },
  "geo" : { },
  "id_str" : "733360759518994433",
  "text" : "Calling all kid scientists: @POTUS wants to hear from you \u2192 https:\/\/t.co\/ajqkTzKkj1 https:\/\/t.co\/2NID8NMaoD",
  "id" : 733360759518994433,
  "created_at" : "2016-05-19 18:16:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733351020961484800",
  "text" : "RT @vj44: 56% of Americans who benefit from overtime expansion are women. Check out my article on @POTUS overtime regulations https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 88, 94 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/1pVe9i8s10",
        "expanded_url" : "http:\/\/huff.to\/1TrFh4P",
        "display_url" : "huff.to\/1TrFh4P"
      } ]
    },
    "geo" : { },
    "id_str" : "733345014613413888",
    "text" : "56% of Americans who benefit from overtime expansion are women. Check out my article on @POTUS overtime regulations https:\/\/t.co\/1pVe9i8s10",
    "id" : 733345014613413888,
    "created_at" : "2016-05-19 17:14:11 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 733351020961484800,
  "created_at" : "2016-05-19 17:38:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Anderson",
      "screen_name" : "Charlie44",
      "indices" : [ 3, 13 ],
      "id_str" : "4796005523",
      "id" : 4796005523
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 50, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/E4L0H8rFwP",
      "expanded_url" : "http:\/\/thehill.com\/policy\/finance\/trade\/280430-pacific-trade-pact-would-boost-growth-jobs-and-incomes",
      "display_url" : "thehill.com\/policy\/finance\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733330721729851392",
  "text" : "RT @Charlie44: Every credible econ analysis shows #TPP would:\n\u2191 U.S. Exports\n\u2191 U.S. Growth\n\u2191 U.S. Incomes\nMore here: https:\/\/t.co\/E4L0H8rFwP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 35, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/E4L0H8rFwP",
        "expanded_url" : "http:\/\/thehill.com\/policy\/finance\/trade\/280430-pacific-trade-pact-would-boost-growth-jobs-and-incomes",
        "display_url" : "thehill.com\/policy\/finance\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "733321765028401153",
    "text" : "Every credible econ analysis shows #TPP would:\n\u2191 U.S. Exports\n\u2191 U.S. Growth\n\u2191 U.S. Incomes\nMore here: https:\/\/t.co\/E4L0H8rFwP",
    "id" : 733321765028401153,
    "created_at" : "2016-05-19 15:41:47 +0000",
    "user" : {
      "name" : "Charlie Anderson",
      "screen_name" : "Charlie44",
      "protected" : false,
      "id_str" : "4796005523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689598827691520000\/6gRd26qn_normal.jpg",
      "id" : 4796005523,
      "verified" : true
    }
  },
  "id" : 733330721729851392,
  "created_at" : "2016-05-19 16:17:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 72, 81 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "overtime",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PNxtVNMRir",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/f30401e8-6ae1-4acd-8d69-a47cc03baec3",
      "display_url" : "amp.twimg.com\/v\/f30401e8-6ae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "733043257307893760",
  "text" : "If you work more, you should get paid more. It's that simple. LIsten to @LaborSec explain the new #overtime update:  https:\/\/t.co\/PNxtVNMRir",
  "id" : 733043257307893760,
  "created_at" : "2016-05-18 21:15:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/733036542373953536\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/uJSjdHbArc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CixE2AKUgAA9vXB.jpg",
      "id_str" : "733036533901459456",
      "id" : 733036533901459456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CixE2AKUgAA9vXB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/uJSjdHbArc"
    } ],
    "hashtags" : [ {
      "text" : "overtime",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/J4K6m3B6t5",
      "expanded_url" : "http:\/\/go.wh.gov\/Overtime",
      "display_url" : "go.wh.gov\/Overtime"
    } ]
  },
  "geo" : { },
  "id_str" : "733036542373953536",
  "text" : "FACT: 56% of Americans who will benefit from #overtime expansion are women. https:\/\/t.co\/J4K6m3B6t5 https:\/\/t.co\/uJSjdHbArc",
  "id" : 733036542373953536,
  "created_at" : "2016-05-18 20:48:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/733019076470132736\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/10oESPdLer",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ciw05bFUoAE3OEt.jpg",
      "id_str" : "733019000481816577",
      "id" : 733019000481816577,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ciw05bFUoAE3OEt.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/10oESPdLer"
    } ],
    "hashtags" : [ {
      "text" : "overtime",
      "indices" : [ 32, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/J4K6m3jvBx",
      "expanded_url" : "http:\/\/go.wh.gov\/Overtime",
      "display_url" : "go.wh.gov\/Overtime"
    } ]
  },
  "geo" : { },
  "id_str" : "733019076470132736",
  "text" : ".@POTUS is taking a big step on #overtime protections to help grow middle-class paychecks \u2192\nhttps:\/\/t.co\/J4K6m3jvBx https:\/\/t.co\/10oESPdLer",
  "id" : 733019076470132736,
  "created_at" : "2016-05-18 19:39:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/733010628101742593\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/Xk8seLmpjs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiwtHW5WEAA2VYT.jpg",
      "id_str" : "733010443782983680",
      "id" : 733010443782983680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiwtHW5WEAA2VYT.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Xk8seLmpjs"
    } ],
    "hashtags" : [ {
      "text" : "overtime",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/J4K6m3jvBx",
      "expanded_url" : "http:\/\/go.wh.gov\/Overtime",
      "display_url" : "go.wh.gov\/Overtime"
    } ]
  },
  "geo" : { },
  "id_str" : "733010628101742593",
  "text" : "FACT: 2.5 million children will see at least one parent benefit from #overtime updates. https:\/\/t.co\/J4K6m3jvBx https:\/\/t.co\/Xk8seLmpjs",
  "id" : 733010628101742593,
  "created_at" : "2016-05-18 19:05:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "overtime",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/PNxtVNvgqT",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/f30401e8-6ae1-4acd-8d69-a47cc03baec3",
      "display_url" : "amp.twimg.com\/v\/f30401e8-6ae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732996441120120832",
  "text" : "Today we're updating and strengthening #overtime pay rules to make sure millions more Americans are paid fairly. https:\/\/t.co\/PNxtVNvgqT",
  "id" : 732996441120120832,
  "created_at" : "2016-05-18 18:09:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OTRule",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732995442376642560",
  "text" : "RT @VP: If you're working overtime, you should get paid for it. Fair and square. That's the spirit behind today's #OTRule: https:\/\/t.co\/Ml3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OTRule",
        "indices" : [ 106, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/Ml3yMyOU8m",
        "expanded_url" : "http:\/\/go.wh.gov\/4Lj4EH",
        "display_url" : "go.wh.gov\/4Lj4EH"
      } ]
    },
    "geo" : { },
    "id_str" : "732994627045871617",
    "text" : "If you're working overtime, you should get paid for it. Fair and square. That's the spirit behind today's #OTRule: https:\/\/t.co\/Ml3yMyOU8m",
    "id" : 732994627045871617,
    "created_at" : "2016-05-18 18:01:52 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 732995442376642560,
  "created_at" : "2016-05-18 18:05:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/6EnjaIvje4",
      "expanded_url" : "http:\/\/go.wh.gov\/DraUZc",
      "display_url" : "go.wh.gov\/DraUZc"
    } ]
  },
  "geo" : { },
  "id_str" : "732960110742372352",
  "text" : "RT @FactsOnClimate: The increased risk of wildfires effects our homes and our safety. @POTUS is taking action \u2192 https:\/\/t.co\/6EnjaIvje4 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 66, 72 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/732959152226467846\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/jTHFMINFTt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Civ-dtdUUAEjLcq.jpg",
        "id_str" : "732959150750060545",
        "id" : 732959150750060545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Civ-dtdUUAEjLcq.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jTHFMINFTt"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/6EnjaIvje4",
        "expanded_url" : "http:\/\/go.wh.gov\/DraUZc",
        "display_url" : "go.wh.gov\/DraUZc"
      } ]
    },
    "geo" : { },
    "id_str" : "732959152226467846",
    "text" : "The increased risk of wildfires effects our homes and our safety. @POTUS is taking action \u2192 https:\/\/t.co\/6EnjaIvje4 https:\/\/t.co\/jTHFMINFTt",
    "id" : 732959152226467846,
    "created_at" : "2016-05-18 15:40:54 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 732960110742372352,
  "created_at" : "2016-05-18 15:44:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OTrule",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/yXfrwsJNyy",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/f30401e8-6ae1-4acd-8d69-a47cc03baec3",
      "display_url" : "amp.twimg.com\/v\/f30401e8-6ae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732929643280470016",
  "text" : "RT @USDOL: How does our new #OTrule work? Your questions answered:\nhttps:\/\/t.co\/yXfrwsJNyy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OTrule",
        "indices" : [ 17, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/yXfrwsJNyy",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/f30401e8-6ae1-4acd-8d69-a47cc03baec3",
        "display_url" : "amp.twimg.com\/v\/f30401e8-6ae\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732916490647658496",
    "text" : "How does our new #OTrule work? Your questions answered:\nhttps:\/\/t.co\/yXfrwsJNyy",
    "id" : 732916490647658496,
    "created_at" : "2016-05-18 12:51:22 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 732929643280470016,
  "created_at" : "2016-05-18 13:43:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Eric Fanning",
      "screen_name" : "SECARMY",
      "indices" : [ 84, 92 ],
      "id_str" : "4377108801",
      "id" : 4377108801
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 94, 101 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732740129706631168",
  "text" : "RT @vj44: Congratulations to Eric Fanning, confirmed by the Senate today as our new @SECARMY! @USArmy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eric Fanning",
        "screen_name" : "SECARMY",
        "indices" : [ 74, 82 ],
        "id_str" : "4377108801",
        "id" : 4377108801
      }, {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 84, 91 ],
        "id_str" : "8775672",
        "id" : 8775672
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732735251693350912",
    "text" : "Congratulations to Eric Fanning, confirmed by the Senate today as our new @SECARMY! @USArmy",
    "id" : 732735251693350912,
    "created_at" : "2016-05-18 00:51:12 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 732740129706631168,
  "created_at" : "2016-05-18 01:10:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/732734934901764100\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/acNZFJTGb6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cisygc5XEAI4Qgi.jpg",
      "id_str" : "732734897471819778",
      "id" : 732734897471819778,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cisygc5XEAI4Qgi.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/acNZFJTGb6"
    } ],
    "hashtags" : [ {
      "text" : "overtime",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/J4K6m3jvBx",
      "expanded_url" : "http:\/\/go.wh.gov\/Overtime",
      "display_url" : "go.wh.gov\/Overtime"
    } ]
  },
  "geo" : { },
  "id_str" : "732734934901764100",
  "text" : ".@POTUS is taking action to make 4.2 million more Americans eligible for #overtime pay: https:\/\/t.co\/J4K6m3jvBx https:\/\/t.co\/acNZFJTGb6",
  "id" : 732734934901764100,
  "created_at" : "2016-05-18 00:49:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OTrule",
      "indices" : [ 44, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/pQdtUGWAWo",
      "expanded_url" : "http:\/\/www.dol.gov\/overtime",
      "display_url" : "dol.gov\/overtime"
    } ]
  },
  "geo" : { },
  "id_str" : "732728355791986688",
  "text" : "RT @USDOL: Stay tuned! We publish our final #OTrule tomorrow &amp; millions of workers will benefit. https:\/\/t.co\/pQdtUGWAWo https:\/\/t.co\/5L1Vk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/732722429504724992\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/5L1VkPUity",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CisnKs0W0AAXkvh.jpg",
        "id_str" : "732722429160771584",
        "id" : 732722429160771584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CisnKs0W0AAXkvh.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/5L1VkPUity"
      } ],
      "hashtags" : [ {
        "text" : "OTrule",
        "indices" : [ 33, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/pQdtUGWAWo",
        "expanded_url" : "http:\/\/www.dol.gov\/overtime",
        "display_url" : "dol.gov\/overtime"
      } ]
    },
    "geo" : { },
    "id_str" : "732722429504724992",
    "text" : "Stay tuned! We publish our final #OTrule tomorrow &amp; millions of workers will benefit. https:\/\/t.co\/pQdtUGWAWo https:\/\/t.co\/5L1VkPUity",
    "id" : 732722429504724992,
    "created_at" : "2016-05-18 00:00:15 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 732728355791986688,
  "created_at" : "2016-05-18 00:23:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/732726598512828416\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/fHZlfyzGmC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CisqfyTUoAEV3Pd.jpg",
      "id_str" : "732726089944965121",
      "id" : 732726089944965121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CisqfyTUoAEV3Pd.jpg",
      "sizes" : [ {
        "h" : 603,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 616
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fHZlfyzGmC"
    } ],
    "hashtags" : [ {
      "text" : "overtime",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/R78XeeSNq9",
      "expanded_url" : "http:\/\/go.wh.gov\/oZizEg",
      "display_url" : "go.wh.gov\/oZizEg"
    } ]
  },
  "geo" : { },
  "id_str" : "732726598512828416",
  "text" : "BREAKING: @POTUS is taking an important step on #overtime to ensure your work is rewarded \u2192 https:\/\/t.co\/R78XeeSNq9 https:\/\/t.co\/fHZlfyzGmC",
  "id" : 732726598512828416,
  "created_at" : "2016-05-18 00:16:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 14, 21 ],
      "id_str" : "146569971",
      "id" : 146569971
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/732674716683505665\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/OKe6eDSDNx",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cir7nXnWgAEXz8N.jpg",
      "id_str" : "732674543173664769",
      "id" : 732674543173664769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cir7nXnWgAEXz8N.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OKe6eDSDNx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/p1HSXVFEYJ",
      "expanded_url" : "http:\/\/1.usa.gov\/201H9li",
      "display_url" : "1.usa.gov\/201H9li"
    } ]
  },
  "geo" : { },
  "id_str" : "732674716683505665",
  "text" : "Big news from @CDCgov: More than 90% of Americans have health coverage for the first time: https:\/\/t.co\/p1HSXVFEYJ https:\/\/t.co\/OKe6eDSDNx",
  "id" : 732674716683505665,
  "created_at" : "2016-05-17 20:50:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/JXxk3qX3nq",
      "expanded_url" : "http:\/\/go.wh.gov\/doJp62",
      "display_url" : "go.wh.gov\/doJp62"
    } ]
  },
  "geo" : { },
  "id_str" : "732584140344791041",
  "text" : "Watch @POTUS thank 13 public safety officers for displaying exceptional courage in protecting others from harm: https:\/\/t.co\/JXxk3qX3nq",
  "id" : 732584140344791041,
  "created_at" : "2016-05-17 14:50:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/732576108395298816\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/OGYpGRB9Nj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiqhwKiXIAU5XnO.jpg",
      "id_str" : "732575738235396101",
      "id" : 732575738235396101,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiqhwKiXIAU5XnO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OGYpGRB9Nj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732576108395298816",
  "text" : "\"Our nation is committed to the principle that all people should be treated fairly and with respect.\" \u2014@POTUS https:\/\/t.co\/OGYpGRB9Nj",
  "id" : 732576108395298816,
  "created_at" : "2016-05-17 14:18:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJob",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/490NFPGeQ0",
      "expanded_url" : "http:\/\/snpy.tv\/1qop30D",
      "display_url" : "snpy.tv\/1qop30D"
    } ]
  },
  "geo" : { },
  "id_str" : "732300882897866755",
  "text" : "It's the Senate's constitutional obligation to give Judge Garland a hearing or a vote. #DoYourJob https:\/\/t.co\/490NFPGeQ0",
  "id" : 732300882897866755,
  "created_at" : "2016-05-16 20:05:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732300278943367170",
  "text" : "RT @SCOTUSnom: \"There's no part of our lives that aren't touched by the rules that the Supreme Court puts forward.\" \u2014@POTUS #SCOTUS https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 102, 108 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/l6hFaeYaT2",
        "expanded_url" : "http:\/\/snpy.tv\/1OxhOPf",
        "display_url" : "snpy.tv\/1OxhOPf"
      } ]
    },
    "geo" : { },
    "id_str" : "732299271383351296",
    "text" : "\"There's no part of our lives that aren't touched by the rules that the Supreme Court puts forward.\" \u2014@POTUS #SCOTUS https:\/\/t.co\/l6hFaeYaT2",
    "id" : 732299271383351296,
    "created_at" : "2016-05-16 19:58:46 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 732300278943367170,
  "created_at" : "2016-05-16 20:02:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 77, 87 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Y6y0jtT8zs",
      "expanded_url" : "http:\/\/go.wh.gov\/BuzzfeedLive",
      "display_url" : "go.wh.gov\/BuzzfeedLive"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/9aidzjs98U",
      "expanded_url" : "http:\/\/snpy.tv\/1OxhOPf",
      "display_url" : "snpy.tv\/1OxhOPf"
    } ]
  },
  "geo" : { },
  "id_str" : "732297398630944768",
  "text" : "\"Even Republicans compliment him and say he's a great judge.\" \u2014@POTUS on his @SCOTUSnom: https:\/\/t.co\/Y6y0jtT8zs   https:\/\/t.co\/9aidzjs98U",
  "id" : 732297398630944768,
  "created_at" : "2016-05-16 19:51:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/732287823827611653\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/J9vRREjjFf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CimbztRWwAAWMm3.jpg",
      "id_str" : "732287727052439552",
      "id" : 732287727052439552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CimbztRWwAAWMm3.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/J9vRREjjFf"
    } ],
    "hashtags" : [ {
      "text" : "DoYourJob",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732287823827611653",
  "text" : "\u201CI\u2019ve carried out my constitutional duty.\u201D \u2014@POTUS\n\nIt's time for the Senate to do theirs. #DoYourJob https:\/\/t.co\/J9vRREjjFf",
  "id" : 732287823827611653,
  "created_at" : "2016-05-16 19:13:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 41, 50 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BuzzFeed\/status\/732216675324575744\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/JzDmzxKy6H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CilbL6LWkAAsrq-.jpg",
      "id_str" : "732216674577977344",
      "id" : 732216674577977344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CilbL6LWkAAsrq-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 990,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 990,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JzDmzxKy6H"
    } ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/Y6y0jtT8zs",
      "expanded_url" : "http:\/\/go.wh.gov\/BuzzfeedLive",
      "display_url" : "go.wh.gov\/BuzzfeedLive"
    } ]
  },
  "geo" : { },
  "id_str" : "732282946292465665",
  "text" : "Happening now: @POTUS talks #SCOTUS with @Buzzfeed live on Facebook \u2192 https:\/\/t.co\/Y6y0jtT8zs https:\/\/t.co\/JzDmzxKy6H",
  "id" : 732282946292465665,
  "created_at" : "2016-05-16 18:53:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Notre Dame",
      "screen_name" : "NotreDame",
      "indices" : [ 19, 29 ],
      "id_str" : "6507762",
      "id" : 6507762
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/732274239030611968\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/47qehw3lBB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CimPikHWkAA1zjI.jpg",
      "id_str" : "732274238397255680",
      "id" : 732274238397255680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CimPikHWkAA1zjI.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1632,
        "resize" : "fit",
        "w" : 1224
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/47qehw3lBB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732280734841364480",
  "text" : "RT @VP: Thank you, @NotreDame, for the honor of a lifetime. Graduates: Play like a champion every day. https:\/\/t.co\/47qehw3lBB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Notre Dame",
        "screen_name" : "NotreDame",
        "indices" : [ 11, 21 ],
        "id_str" : "6507762",
        "id" : 6507762
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/732274239030611968\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/47qehw3lBB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CimPikHWkAA1zjI.jpg",
        "id_str" : "732274238397255680",
        "id" : 732274238397255680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CimPikHWkAA1zjI.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1632,
          "resize" : "fit",
          "w" : 1224
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/47qehw3lBB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732274239030611968",
    "text" : "Thank you, @NotreDame, for the honor of a lifetime. Graduates: Play like a champion every day. https:\/\/t.co\/47qehw3lBB",
    "id" : 732274239030611968,
    "created_at" : "2016-05-16 18:19:18 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 732280734841364480,
  "created_at" : "2016-05-16 18:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 60, 69 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BuzzFeed\/status\/732216675324575744\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/JzDmzy28Yf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CilbL6LWkAAsrq-.jpg",
      "id_str" : "732216674577977344",
      "id" : 732216674577977344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CilbL6LWkAAsrq-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 990,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 990,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JzDmzy28Yf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Y6y0jtBxaS",
      "expanded_url" : "http:\/\/go.wh.gov\/BuzzfeedLive",
      "display_url" : "go.wh.gov\/BuzzfeedLive"
    } ]
  },
  "geo" : { },
  "id_str" : "732275693967396864",
  "text" : "Tune in at 2:50pm ET as @POTUS sits down for his first live @Facebook interview \u2192 https:\/\/t.co\/Y6y0jtBxaS https:\/\/t.co\/JzDmzy28Yf",
  "id" : 732275693967396864,
  "created_at" : "2016-05-16 18:25:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/uUtlxvBwyY",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/in-photos-official-visit-of-nordic-leaders-48e714c33be2#.v7zjteei5",
      "display_url" : "medium.com\/@WhiteHouse\/in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "732273412006137861",
  "text" : "RT @NSC44: Last week @POTUS hosted his counterparts from 5 Nordic countries. Exclusive photos here: https:\/\/t.co\/uUtlxvBwyY https:\/\/t.co\/d0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/732273105784045568\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/d0u9fX1axQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CimOdzNVAAAXuFC.jpg",
        "id_str" : "732273057037877248",
        "id" : 732273057037877248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CimOdzNVAAAXuFC.jpg",
        "sizes" : [ {
          "h" : 165,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 497,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 763,
          "resize" : "fit",
          "w" : 1571
        } ],
        "display_url" : "pic.twitter.com\/d0u9fX1axQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/uUtlxvBwyY",
        "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/in-photos-official-visit-of-nordic-leaders-48e714c33be2#.v7zjteei5",
        "display_url" : "medium.com\/@WhiteHouse\/in\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "732273105784045568",
    "text" : "Last week @POTUS hosted his counterparts from 5 Nordic countries. Exclusive photos here: https:\/\/t.co\/uUtlxvBwyY https:\/\/t.co\/d0u9fX1axQ",
    "id" : 732273105784045568,
    "created_at" : "2016-05-16 18:14:48 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 732273412006137861,
  "created_at" : "2016-05-16 18:16:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732266373926133760",
  "text" : "RT @POTUS: Today, I join all Americans in honoring 13 officers who went beyond the call of duty to save the lives of strangers. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/732266263528001537\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/OufzQ70ovH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CimIBfWXIAALZ2o.jpg",
        "id_str" : "732265973600952320",
        "id" : 732265973600952320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CimIBfWXIAALZ2o.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OufzQ70ovH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732266263528001537",
    "text" : "Today, I join all Americans in honoring 13 officers who went beyond the call of duty to save the lives of strangers. https:\/\/t.co\/OufzQ70ovH",
    "id" : 732266263528001537,
    "created_at" : "2016-05-16 17:47:36 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 732266373926133760,
  "created_at" : "2016-05-16 17:48:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Geidner",
      "screen_name" : "chrisgeidner",
      "indices" : [ 3, 16 ],
      "id_str" : "22891564",
      "id" : 22891564
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732264440725266432",
  "text" : "RT @chrisgeidner: Ready to go! Watch me interview @POTUS live about #SCOTUS &amp; his nominee at 2:50 pm Eastern on Facebook &amp; YouTube! https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 32, 38 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chrisgeidner\/status\/732258614811860992\/photo\/1",
        "indices" : [ 122, 145 ],
        "url" : "https:\/\/t.co\/YBYpkCrPU2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CimBT3KVAAAid6S.jpg",
        "id_str" : "732258592649183232",
        "id" : 732258592649183232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CimBT3KVAAAid6S.jpg",
        "sizes" : [ {
          "h" : 937,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 937,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/YBYpkCrPU2"
      } ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 50, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732258614811860992",
    "text" : "Ready to go! Watch me interview @POTUS live about #SCOTUS &amp; his nominee at 2:50 pm Eastern on Facebook &amp; YouTube! https:\/\/t.co\/YBYpkCrPU2",
    "id" : 732258614811860992,
    "created_at" : "2016-05-16 17:17:13 +0000",
    "user" : {
      "name" : "Chris Geidner",
      "screen_name" : "chrisgeidner",
      "protected" : false,
      "id_str" : "22891564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796263999444754432\/fj-gCOX3_normal.jpg",
      "id" : 22891564,
      "verified" : true
    }
  },
  "id" : 732264440725266432,
  "created_at" : "2016-05-16 17:40:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 40, 46 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfValor",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/fUWV1zkpnV",
      "expanded_url" : "http:\/\/snpy.tv\/1siozdA",
      "display_url" : "snpy.tv\/1siozdA"
    } ]
  },
  "geo" : { },
  "id_str" : "732239391557455872",
  "text" : "\"This is an award none of them sought\" \u2014@POTUS on the 13 officers awarded with the #MedalOfValor https:\/\/t.co\/fUWV1zkpnV",
  "id" : 732239391557455872,
  "created_at" : "2016-05-16 16:00:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfValor",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/2yPQR4avTx",
      "expanded_url" : "http:\/\/snpy.tv\/1V6b6Bp",
      "display_url" : "snpy.tv\/1V6b6Bp"
    } ]
  },
  "geo" : { },
  "id_str" : "732235575105708032",
  "text" : "\"Every day, so many of our public safety officers wear a badge of honor.\" \u2014@POTUS  awarding the #MedalOfValor  https:\/\/t.co\/2yPQR4avTx",
  "id" : 732235575105708032,
  "created_at" : "2016-05-16 15:45:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfValor",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732233882578395136",
  "text" : "\"Our nation has a responsibility to support those who serve and protect us and keep our streets safe.\"  \u2014@POTUS #MedalOfValor",
  "id" : 732233882578395136,
  "created_at" : "2016-05-16 15:38:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732233466633408512",
  "text" : "RT @WHLive: \"The men and women who run toward danger remind us with your courage and humility what the highest form of citizenship looks li\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 133, 139 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732233161527136256",
    "text" : "\"The men and women who run toward danger remind us with your courage and humility what the highest form of citizenship looks like.\" \u2014@POTUS",
    "id" : 732233161527136256,
    "created_at" : "2016-05-16 15:36:04 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 732233466633408512,
  "created_at" : "2016-05-16 15:37:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfValor",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732233090408566786",
  "text" : "\"It\u2019s because of your courage\u2014 often unseen\u2014that the rest of us can go about living our lives like it\u2019s any other day\" \u2014@POTUS #MedalOfValor",
  "id" : 732233090408566786,
  "created_at" : "2016-05-16 15:35:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfValor",
      "indices" : [ 56, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732232325547888640",
  "text" : "\u201CThe public safety officers we recognize today with the #MedalOfValor found courage not in search of recognition, but instinctively\u201D \u2014@POTUS",
  "id" : 732232325547888640,
  "created_at" : "2016-05-16 15:32:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfValor",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732232118970023937",
  "text" : "\u201CIt\u2019s been said that perfect valor is doing without witnesses what you would do if the whole world were watching.\u201D \u2014@POTUS #MedalOfValor",
  "id" : 732232118970023937,
  "created_at" : "2016-05-16 15:31:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfValor",
      "indices" : [ 36, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/3Bqv8dDG16",
      "expanded_url" : "http:\/\/go.wh.gov\/pFVR1f",
      "display_url" : "go.wh.gov\/pFVR1f"
    } ]
  },
  "geo" : { },
  "id_str" : "732231724017520645",
  "text" : "Happening now: @POTUS speaks at the #MedalOfValor Ceremony \u2192 https:\/\/t.co\/3Bqv8dDG16",
  "id" : 732231724017520645,
  "created_at" : "2016-05-16 15:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 3, 12 ],
      "id_str" : "5695632",
      "id" : 5695632
    }, {
      "name" : "Chris Geidner",
      "screen_name" : "chrisgeidner",
      "indices" : [ 40, 53 ],
      "id_str" : "22891564",
      "id" : 22891564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732223308352094209",
  "text" : "RT @BuzzFeed: Tune in this afternoon as @chrisgeidner interviews President Obama live from the White House on FB Live and YouTube! https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Geidner",
        "screen_name" : "chrisgeidner",
        "indices" : [ 26, 39 ],
        "id_str" : "22891564",
        "id" : 22891564
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BuzzFeed\/status\/732216675324575744\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/qOSxfJGPNw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CilbL6LWkAAsrq-.jpg",
        "id_str" : "732216674577977344",
        "id" : 732216674577977344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CilbL6LWkAAsrq-.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 990,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 990,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/qOSxfJGPNw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "732216675324575744",
    "text" : "Tune in this afternoon as @chrisgeidner interviews President Obama live from the White House on FB Live and YouTube! https:\/\/t.co\/qOSxfJGPNw",
    "id" : 732216675324575744,
    "created_at" : "2016-05-16 14:30:33 +0000",
    "user" : {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "protected" : false,
      "id_str" : "5695632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687767655214891008\/n9pHVYUl_normal.png",
      "id" : 5695632,
      "verified" : true
    }
  },
  "id" : 732223308352094209,
  "created_at" : "2016-05-16 14:56:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 51, 57 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 76, 85 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 63, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/fNEn0V5YtO",
      "expanded_url" : "http:\/\/bzfd.it\/1Ow5M92",
      "display_url" : "bzfd.it\/1Ow5M92"
    } ]
  },
  "geo" : { },
  "id_str" : "732220318576717826",
  "text" : "RT @SCOTUSnom: Tune in today at 2:50pm ET to catch @POTUS talk #SCOTUS with @BuzzFeed live on Facebook \u2192 https:\/\/t.co\/fNEn0V5YtO https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 36, 42 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "BuzzFeed",
        "screen_name" : "BuzzFeed",
        "indices" : [ 61, 70 ],
        "id_str" : "5695632",
        "id" : 5695632
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SCOTUSnom\/status\/732220097369018368\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/fEwIq7zV4N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CildzIGUoAAfz1Y.jpg",
        "id_str" : "732219547353128960",
        "id" : 732219547353128960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CildzIGUoAAfz1Y.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/fEwIq7zV4N"
      } ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 48, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/fNEn0V5YtO",
        "expanded_url" : "http:\/\/bzfd.it\/1Ow5M92",
        "display_url" : "bzfd.it\/1Ow5M92"
      } ]
    },
    "geo" : { },
    "id_str" : "732220097369018368",
    "text" : "Tune in today at 2:50pm ET to catch @POTUS talk #SCOTUS with @BuzzFeed live on Facebook \u2192 https:\/\/t.co\/fNEn0V5YtO https:\/\/t.co\/fEwIq7zV4N",
    "id" : 732220097369018368,
    "created_at" : "2016-05-16 14:44:09 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 732220318576717826,
  "created_at" : "2016-05-16 14:45:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opioid",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/03MRcKBJoa",
      "expanded_url" : "http:\/\/snpy.tv\/1TdPG3U",
      "display_url" : "snpy.tv\/1TdPG3U"
    } ]
  },
  "geo" : { },
  "id_str" : "731967649903583232",
  "text" : "\"When we talk about #opioid abuse as the public health problem it is, more people will seek the help they need.\"  https:\/\/t.co\/03MRcKBJoa",
  "id" : 731967649903583232,
  "created_at" : "2016-05-15 22:01:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Under The Gun",
      "screen_name" : "UnderTheGunDoc",
      "indices" : [ 63, 78 ],
      "id_str" : "3168078271",
      "id" : 3168078271
    }, {
      "name" : "Katie Couric",
      "screen_name" : "katiecouric",
      "indices" : [ 115, 127 ],
      "id_str" : "18812301",
      "id" : 18812301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/WLxg8dQLSp",
      "expanded_url" : "http:\/\/epix.com",
      "display_url" : "epix.com"
    } ]
  },
  "geo" : { },
  "id_str" : "731952709440442368",
  "text" : "RT @vj44: Tune in tonight at 8:00pm to watch the powerful film @UnderTheGunDoc for free on https:\/\/t.co\/WLxg8dQLSp @katiecouric",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Under The Gun",
        "screen_name" : "UnderTheGunDoc",
        "indices" : [ 53, 68 ],
        "id_str" : "3168078271",
        "id" : 3168078271
      }, {
        "name" : "Katie Couric",
        "screen_name" : "katiecouric",
        "indices" : [ 105, 117 ],
        "id_str" : "18812301",
        "id" : 18812301
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/WLxg8dQLSp",
        "expanded_url" : "http:\/\/epix.com",
        "display_url" : "epix.com"
      } ]
    },
    "geo" : { },
    "id_str" : "731937900988932096",
    "text" : "Tune in tonight at 8:00pm to watch the powerful film @UnderTheGunDoc for free on https:\/\/t.co\/WLxg8dQLSp @katiecouric",
    "id" : 731937900988932096,
    "created_at" : "2016-05-15 20:02:49 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 731952709440442368,
  "created_at" : "2016-05-15 21:01:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macklemore",
      "screen_name" : "macklemore",
      "indices" : [ 108, 119 ],
      "id_str" : "18159470",
      "id" : 18159470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/03MRcKBJoa",
      "expanded_url" : "http:\/\/snpy.tv\/1TdPG3U",
      "display_url" : "snpy.tv\/1TdPG3U"
    } ]
  },
  "geo" : { },
  "id_str" : "731940987904221184",
  "text" : "\"Shame &amp; the stigma associated with the disease keeps too many people from seeking the help they need\" \u2014@Macklemore  https:\/\/t.co\/03MRcKBJoa",
  "id" : 731940987904221184,
  "created_at" : "2016-05-15 20:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/731929722083401728\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/HesU0gBFGa",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CihAbTNUYAA3ZD2.jpg",
      "id_str" : "731905777204486144",
      "id" : 731905777204486144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CihAbTNUYAA3ZD2.jpg",
      "sizes" : [ {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HesU0gBFGa"
    } ],
    "hashtags" : [ {
      "text" : "opioid",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/q866JwDYlH",
      "expanded_url" : "http:\/\/go.wh.gov\/qXkwvo",
      "display_url" : "go.wh.gov\/qXkwvo"
    } ]
  },
  "geo" : { },
  "id_str" : "731929722083401728",
  "text" : "FACT: Deaths from #opioid overdoses have tripled since 2000 \u2192 https:\/\/t.co\/q866JwDYlH https:\/\/t.co\/HesU0gBFGa",
  "id" : 731929722083401728,
  "created_at" : "2016-05-15 19:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/03MRcKBJoa",
      "expanded_url" : "http:\/\/snpy.tv\/1TdPG3U",
      "display_url" : "snpy.tv\/1TdPG3U"
    } ]
  },
  "geo" : { },
  "id_str" : "731918342202613760",
  "text" : "\"On top of funding, doctors also need more training about the power of the pain medication they prescribe\" \u2014@POTUS  https:\/\/t.co\/03MRcKBJoa",
  "id" : 731918342202613760,
  "created_at" : "2016-05-15 18:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RU250Grad",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/f7hnpmUQ8o",
      "expanded_url" : "http:\/\/snpy.tv\/1sf3sc8",
      "display_url" : "snpy.tv\/1sf3sc8"
    } ]
  },
  "geo" : { },
  "id_str" : "731912556856659968",
  "text" : "\"Progress doesn\u2019t travel a straight line, but instead zigs and zags in fits and starts.\u201D \u2014@POTUS #RU250Grad https:\/\/t.co\/f7hnpmUQ8o",
  "id" : 731912556856659968,
  "created_at" : "2016-05-15 18:22:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Rutgers University",
      "screen_name" : "RutgersU",
      "indices" : [ 97, 106 ],
      "id_str" : "19272796",
      "id" : 19272796
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RU250Grad",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731899261537787905",
  "text" : "\u201CLet me be as clear as I can be, in politics and in life, ignorance is not a virtue.\u201D \u2014@POTUS at @RutgersU #RU250Grad",
  "id" : 731899261537787905,
  "created_at" : "2016-05-15 17:29:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/1xfcJ9zAae",
      "expanded_url" : "http:\/\/go.wh.gov\/XS3Rfi",
      "display_url" : "go.wh.gov\/XS3Rfi"
    } ]
  },
  "geo" : { },
  "id_str" : "731898014487347200",
  "text" : "\u201CTo help ourselves, we have to help others\u2014not pull up the drawbridge and try to keep the world out\u201D \u2014@POTUS: https:\/\/t.co\/1xfcJ9zAae",
  "id" : 731898014487347200,
  "created_at" : "2016-05-15 17:24:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731897051282186240",
  "text" : "\"More women are in the workforce...although it\u2019s long past time we passed laws to make sure that women get equal pay for equal work\u201D \u2014@POTUS",
  "id" : 731897051282186240,
  "created_at" : "2016-05-15 17:20:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Rutgers University",
      "screen_name" : "RutgersU",
      "indices" : [ 100, 109 ],
      "id_str" : "19272796",
      "id" : 19272796
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RU250Grad",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731895179108618240",
  "text" : "\"Progress doesn\u2019t travel a straight line, but instead zigs and zags in fits and starts.\u201D \u2014@POTUS at @RutgersU #RU250Grad",
  "id" : 731895179108618240,
  "created_at" : "2016-05-15 17:13:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RU250Grad",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731893936269168641",
  "text" : "RT @WHLive: \"Thank you for the honor of joining you for the 250th anniversary of this remarkable institution.\" \u2014@POTUS #RU250Grad",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 100, 106 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RU250Grad",
        "indices" : [ 107, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731893813535506432",
    "text" : "\"Thank you for the honor of joining you for the 250th anniversary of this remarkable institution.\" \u2014@POTUS #RU250Grad",
    "id" : 731893813535506432,
    "created_at" : "2016-05-15 17:07:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 731893936269168641,
  "created_at" : "2016-05-15 17:08:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Rutgers University",
      "screen_name" : "RutgersU",
      "indices" : [ 64, 73 ],
      "id_str" : "19272796",
      "id" : 19272796
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Rutgers250",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/1xfcJ9hZiG",
      "expanded_url" : "http:\/\/go.wh.gov\/XS3Rfi",
      "display_url" : "go.wh.gov\/XS3Rfi"
    } ]
  },
  "geo" : { },
  "id_str" : "731892734278111232",
  "text" : "Happening now: Watch @POTUS deliver the commencement address at @RutgersU \u2192 https:\/\/t.co\/1xfcJ9hZiG #Rutgers250",
  "id" : 731892734278111232,
  "created_at" : "2016-05-15 17:03:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Nova",
      "screen_name" : "novaaccess",
      "indices" : [ 86, 97 ],
      "id_str" : "783412670007357442",
      "id" : 783412670007357442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/Mg2EVH5EZj",
      "expanded_url" : "https:\/\/instagram.com\/p\/BFaMLXhE7xw\/",
      "display_url" : "instagram.com\/p\/BFaMLXhE7xw\/"
    } ]
  },
  "geo" : { },
  "id_str" : "731881961581477889",
  "text" : "RT @DrBiden: Dr. Biden just delivered her last commencement address as Second Lady at @NovaAccess. https:\/\/t.co\/Mg2EVH5EZj https:\/\/t.co\/rgB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nova",
        "screen_name" : "novaaccess",
        "indices" : [ 73, 84 ],
        "id_str" : "783412670007357442",
        "id" : 783412670007357442
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/731665891142840321\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/rgBoLfKbEL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CidmPHNUkAEFnDX.jpg",
        "id_str" : "731665874289987585",
        "id" : 731665874289987585,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CidmPHNUkAEFnDX.jpg",
        "sizes" : [ {
          "h" : 998,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rgBoLfKbEL"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/Mg2EVH5EZj",
        "expanded_url" : "https:\/\/instagram.com\/p\/BFaMLXhE7xw\/",
        "display_url" : "instagram.com\/p\/BFaMLXhE7xw\/"
      } ]
    },
    "geo" : { },
    "id_str" : "731665891142840321",
    "text" : "Dr. Biden just delivered her last commencement address as Second Lady at @NovaAccess. https:\/\/t.co\/Mg2EVH5EZj https:\/\/t.co\/rgBoLfKbEL",
    "id" : 731665891142840321,
    "created_at" : "2016-05-15 02:01:56 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 731881961581477889,
  "created_at" : "2016-05-15 16:20:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 44, 51 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NordicVisit",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/7uHwaHWSXc",
      "expanded_url" : "http:\/\/snpy.tv\/1qkOUGB",
      "display_url" : "snpy.tv\/1qkOUGB"
    } ]
  },
  "geo" : { },
  "id_str" : "731623914858643456",
  "text" : "Take a look behind the scenes as @POTUS and @FLOTUS arrive at the Nordic State Dinner. #NordicVisit https:\/\/t.co\/7uHwaHWSXc",
  "id" : 731623914858643456,
  "created_at" : "2016-05-14 23:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/03MRcKBJoa",
      "expanded_url" : "http:\/\/snpy.tv\/1TdPG3U",
      "display_url" : "snpy.tv\/1TdPG3U"
    } ]
  },
  "geo" : { },
  "id_str" : "731615486375387136",
  "text" : "\"Just talking about this crisis isn\u2019t enough\u2014we need to get treatment to more people who need it.\" \u2014@POTUS https:\/\/t.co\/03MRcKBJoa",
  "id" : 731615486375387136,
  "created_at" : "2016-05-14 22:41:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed News",
      "screen_name" : "BuzzFeedNews",
      "indices" : [ 3, 16 ],
      "id_str" : "1020058453",
      "id" : 1020058453
    }, {
      "name" : "BuzzFeed News",
      "screen_name" : "BuzzFeedNews",
      "indices" : [ 19, 32 ],
      "id_str" : "1020058453",
      "id" : 1020058453
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BuzzFeedNews\/status\/731529765321117696\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/FsyQHFxNr4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CibofaQWEAAU0Sj.jpg",
      "id_str" : "731527615815749632",
      "id" : 731527615815749632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CibofaQWEAAU0Sj.jpg",
      "sizes" : [ {
        "h" : 623,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 566
      } ],
      "display_url" : "pic.twitter.com\/FsyQHFxNr4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731577253272772612",
  "text" : "RT @BuzzFeedNews: .@BuzzFeedNews will interview President Obama live on Monday about his Supreme Court nominee https:\/\/t.co\/FsyQHFxNr4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BuzzFeed News",
        "screen_name" : "BuzzFeedNews",
        "indices" : [ 1, 14 ],
        "id_str" : "1020058453",
        "id" : 1020058453
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BuzzFeedNews\/status\/731529765321117696\/photo\/1",
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/FsyQHFxNr4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CibofaQWEAAU0Sj.jpg",
        "id_str" : "731527615815749632",
        "id" : 731527615815749632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CibofaQWEAAU0Sj.jpg",
        "sizes" : [ {
          "h" : 623,
          "resize" : "fit",
          "w" : 566
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 566
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 566
        } ],
        "display_url" : "pic.twitter.com\/FsyQHFxNr4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731529765321117696",
    "text" : ".@BuzzFeedNews will interview President Obama live on Monday about his Supreme Court nominee https:\/\/t.co\/FsyQHFxNr4",
    "id" : 731529765321117696,
    "created_at" : "2016-05-14 17:01:01 +0000",
    "user" : {
      "name" : "BuzzFeed News",
      "screen_name" : "BuzzFeedNews",
      "protected" : false,
      "id_str" : "1020058453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796353157576138752\/H2xr-NkC_normal.jpg",
      "id" : 1020058453,
      "verified" : true
    }
  },
  "id" : 731577253272772612,
  "created_at" : "2016-05-14 20:09:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/35Zfbeu3gR",
      "expanded_url" : "http:\/\/snpy.tv\/1s8Xny1",
      "display_url" : "snpy.tv\/1s8Xny1"
    } ]
  },
  "geo" : { },
  "id_str" : "731537174110167042",
  "text" : "\"Addiction doesn\u2019t always start in some dark alley\u2014it often starts in a medicine cabinet.\" \u2014@POTUS on addiction https:\/\/t.co\/35Zfbeu3gR",
  "id" : 731537174110167042,
  "created_at" : "2016-05-14 17:30:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/731523133862092800\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/JFpJjyfDN6",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CibkHb1UgAEiNQg.jpg",
      "id_str" : "731522805875900417",
      "id" : 731522805875900417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CibkHb1UgAEiNQg.jpg",
      "sizes" : [ {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JFpJjyfDN6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/q866JwDYlH",
      "expanded_url" : "http:\/\/go.wh.gov\/qXkwvo",
      "display_url" : "go.wh.gov\/qXkwvo"
    } ]
  },
  "geo" : { },
  "id_str" : "731523133862092800",
  "text" : "\"Drug overdoses now take more lives every year than traffic accidents.\" \u2014@POTUS:  https:\/\/t.co\/q866JwDYlH https:\/\/t.co\/JFpJjyfDN6",
  "id" : 731523133862092800,
  "created_at" : "2016-05-14 16:34:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macklemore",
      "screen_name" : "macklemore",
      "indices" : [ 81, 92 ],
      "id_str" : "18159470",
      "id" : 18159470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/35Zfbeu3gR",
      "expanded_url" : "http:\/\/snpy.tv\/1s8Xny1",
      "display_url" : "snpy.tv\/1s8Xny1"
    } ]
  },
  "geo" : { },
  "id_str" : "731506946709196800",
  "text" : "\"Hey, everybody. I\u2019m here with President Obama because I take this personally.\" \u2014@Macklemore on addiction:  https:\/\/t.co\/35Zfbeu3gR",
  "id" : 731506946709196800,
  "created_at" : "2016-05-14 15:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Macklemore",
      "screen_name" : "macklemore",
      "indices" : [ 22, 33 ],
      "id_str" : "18159470",
      "id" : 18159470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/35Zfbeu3gR",
      "expanded_url" : "http:\/\/snpy.tv\/1s8Xny1",
      "display_url" : "snpy.tv\/1s8Xny1"
    } ]
  },
  "geo" : { },
  "id_str" : "731499489068900352",
  "text" : ".@POTUS teams up with @Macklemore to discuss a disease that affects far too many Americans: addiction. https:\/\/t.co\/35Zfbeu3gR",
  "id" : 731499489068900352,
  "created_at" : "2016-05-14 15:00:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macklemore",
      "screen_name" : "macklemore",
      "indices" : [ 44, 55 ],
      "id_str" : "18159470",
      "id" : 18159470
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 59, 65 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/q866Jwmnu9",
      "expanded_url" : "http:\/\/go.wh.gov\/qXkwvo",
      "display_url" : "go.wh.gov\/qXkwvo"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/35Zfbecspj",
      "expanded_url" : "http:\/\/snpy.tv\/1s8Xny1",
      "display_url" : "snpy.tv\/1s8Xny1"
    } ]
  },
  "geo" : { },
  "id_str" : "731489275288682496",
  "text" : "\"I\u2019ve got a special guest with me this week\u2014@macklemore.\" \u2014@POTUS in his weekly address: https:\/\/t.co\/q866Jwmnu9 https:\/\/t.co\/35Zfbecspj",
  "id" : 731489275288682496,
  "created_at" : "2016-05-14 14:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Howard University",
      "screen_name" : "HowardU",
      "indices" : [ 102, 110 ],
      "id_str" : "27147528",
      "id" : 27147528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/RWA670JtcH",
      "expanded_url" : "http:\/\/snpy.tv\/1s8izUP",
      "display_url" : "snpy.tv\/1s8izUP"
    } ]
  },
  "geo" : { },
  "id_str" : "731253575280697344",
  "text" : "\u201CA little phrase that I\u2019ve found handy these last 8 years: Yes We Can.\" \u2014@POTUS's advice this week to @HowardU grads https:\/\/t.co\/RWA670JtcH",
  "id" : 731253575280697344,
  "created_at" : "2016-05-13 22:43:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 20, 29 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NordicVisit",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/qwd1XysB9p",
      "expanded_url" : "http:\/\/snpy.tv\/1XpE1AK",
      "display_url" : "snpy.tv\/1XpE1AK"
    } ]
  },
  "geo" : { },
  "id_str" : "731230638066536448",
  "text" : "Add \"WhiteHouse\" on @Snapchat for a behind-the-scenes look at the #NordicVisit: https:\/\/t.co\/qwd1XysB9p",
  "id" : 731230638066536448,
  "created_at" : "2016-05-13 21:12:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensHealth",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731205716929855490",
  "text" : "RT @vj44: Welcome to my weekly office hours!! Today's topic is #WomensHealth. Thanks to the Affordable Care Act women are receiving better\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomensHealth",
        "indices" : [ 53, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731202211863236612",
    "text" : "Welcome to my weekly office hours!! Today's topic is #WomensHealth. Thanks to the Affordable Care Act women are receiving better healthcare.",
    "id" : 731202211863236612,
    "created_at" : "2016-05-13 19:19:27 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 731205716929855490,
  "created_at" : "2016-05-13 19:33:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SELF Magazine",
      "screen_name" : "SELFmagazine",
      "indices" : [ 3, 16 ],
      "id_str" : "23798922",
      "id" : 23798922
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 49, 54 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensHealth",
      "indices" : [ 74, 87 ]
    }, {
      "text" : "NWHW",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731184183507353600",
  "text" : "RT @SELFmagazine: Today at 3:15 p.m. you can ask @VJ44 ANY question about #WomensHealth! Knowledge is power \uD83D\uDC4A #NWHW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 31, 36 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomensHealth",
        "indices" : [ 56, 69 ]
      }, {
        "text" : "NWHW",
        "indices" : [ 92, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731171417383944192",
    "text" : "Today at 3:15 p.m. you can ask @VJ44 ANY question about #WomensHealth! Knowledge is power \uD83D\uDC4A #NWHW",
    "id" : 731171417383944192,
    "created_at" : "2016-05-13 17:17:05 +0000",
    "user" : {
      "name" : "SELF Magazine",
      "screen_name" : "SELFmagazine",
      "protected" : false,
      "id_str" : "23798922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743468120044634113\/e1CkbyMn_normal.jpg",
      "id" : 23798922,
      "verified" : true
    }
  },
  "id" : 731184183507353600,
  "created_at" : "2016-05-13 18:07:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NordicVisit",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731181590076870656",
  "text" : "RT @NSC44: Today @WhiteHouse, @POTUS welcomed the leaders of Denmark, Finland, Iceland, Norway, and Sweden. #NordicVisit \nhttps:\/\/t.co\/CM2o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 6, 17 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 19, 25 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NordicVisit",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/CM2oLwNf1C",
        "expanded_url" : "http:\/\/snpy.tv\/1s5UDl3",
        "display_url" : "snpy.tv\/1s5UDl3"
      } ]
    },
    "geo" : { },
    "id_str" : "731179581374398464",
    "text" : "Today @WhiteHouse, @POTUS welcomed the leaders of Denmark, Finland, Iceland, Norway, and Sweden. #NordicVisit \nhttps:\/\/t.co\/CM2oLwNf1C",
    "id" : 731179581374398464,
    "created_at" : "2016-05-13 17:49:31 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 731181590076870656,
  "created_at" : "2016-05-13 17:57:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Syracuse Law",
      "screen_name" : "SUCollegeofLaw",
      "indices" : [ 35, 50 ],
      "id_str" : "23800426",
      "id" : 23800426
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlashbackFriday",
      "indices" : [ 12, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/c2AVLYwyUq",
      "expanded_url" : "http:\/\/go.wh.gov\/VP-in-Syracuse",
      "display_url" : "go.wh.gov\/VP-in-Syracuse"
    } ]
  },
  "geo" : { },
  "id_str" : "731135190819586048",
  "text" : "RT @VPLive: #FlashbackFriday: This @SUCollegeofLaw '68 grad will deliver the commencement address today: https:\/\/t.co\/c2AVLYwyUq https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Syracuse Law",
        "screen_name" : "SUCollegeofLaw",
        "indices" : [ 23, 38 ],
        "id_str" : "23800426",
        "id" : 23800426
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/731133395284025344\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/HqryXuUOzy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiWB8r-W0AAcIGL.jpg",
        "id_str" : "731133394113974272",
        "id" : 731133394113974272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiWB8r-W0AAcIGL.jpg",
        "sizes" : [ {
          "h" : 687,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1207,
          "resize" : "fit",
          "w" : 1800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HqryXuUOzy"
      } ],
      "hashtags" : [ {
        "text" : "FlashbackFriday",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/c2AVLYwyUq",
        "expanded_url" : "http:\/\/go.wh.gov\/VP-in-Syracuse",
        "display_url" : "go.wh.gov\/VP-in-Syracuse"
      } ]
    },
    "geo" : { },
    "id_str" : "731133395284025344",
    "text" : "#FlashbackFriday: This @SUCollegeofLaw '68 grad will deliver the commencement address today: https:\/\/t.co\/c2AVLYwyUq https:\/\/t.co\/HqryXuUOzy",
    "id" : 731133395284025344,
    "created_at" : "2016-05-13 14:45:59 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 731135190819586048,
  "created_at" : "2016-05-13 14:53:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "SELF Magazine",
      "screen_name" : "SELFmagazine",
      "indices" : [ 118, 131 ],
      "id_str" : "23798922",
      "id" : 23798922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensHealth",
      "indices" : [ 38, 51 ]
    }, {
      "text" : "NWHW",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731123644643065856",
  "text" : "RT @vj44: This is a week to celebrate #WomensHealth! Qs on what we're doing to help? Ask with #NWHW. I'll answer with @SELFmagazine at 3:15\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SELF Magazine",
        "screen_name" : "SELFmagazine",
        "indices" : [ 108, 121 ],
        "id_str" : "23798922",
        "id" : 23798922
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomensHealth",
        "indices" : [ 28, 41 ]
      }, {
        "text" : "NWHW",
        "indices" : [ 84, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "731107408269967360",
    "text" : "This is a week to celebrate #WomensHealth! Qs on what we're doing to help? Ask with #NWHW. I'll answer with @SELFmagazine at 3:15pm ET",
    "id" : 731107408269967360,
    "created_at" : "2016-05-13 13:02:44 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 731123644643065856,
  "created_at" : "2016-05-13 14:07:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NordicVisit",
      "indices" : [ 87, 99 ]
    }, {
      "text" : "NordicUSAsummit",
      "indices" : [ 100, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/upBtWJ1tK9",
      "expanded_url" : "http:\/\/snpy.tv\/1s5UDl3",
      "display_url" : "snpy.tv\/1s5UDl3"
    } ]
  },
  "geo" : { },
  "id_str" : "731118800192557056",
  "text" : "\u201CWe are honored to welcome, not one nation, but five\u2014our great Nordic friends\u201D \u2014@POTUS #NordicVisit #NordicUSAsummit https:\/\/t.co\/upBtWJ1tK9",
  "id" : 731118800192557056,
  "created_at" : "2016-05-13 13:48:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NordicVisit",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "731113983609057280",
  "text" : "\"This is also a special day for the millions of Americans who proudly trace their ancestry to the Nordic countries\" \u2014@POTUS #NordicVisit",
  "id" : 731113983609057280,
  "created_at" : "2016-05-13 13:28:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NordicVisit",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/7DoFN57F96",
      "expanded_url" : "http:\/\/go.wh.gov\/NordicVisit",
      "display_url" : "go.wh.gov\/NordicVisit"
    } ]
  },
  "geo" : { },
  "id_str" : "731113297773248513",
  "text" : "\u201CWe are honored to welcome, not one nation, but five\u2014our great Nordic friends and partners.\u201D \u2014@POTUS:  https:\/\/t.co\/7DoFN57F96 #NordicVisit",
  "id" : 731113297773248513,
  "created_at" : "2016-05-13 13:26:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/7DoFN57F96",
      "expanded_url" : "http:\/\/go.wh.gov\/NordicVisit",
      "display_url" : "go.wh.gov\/NordicVisit"
    } ]
  },
  "geo" : { },
  "id_str" : "731105022583406592",
  "text" : "Watch at 9am ET: @POTUS welcomes the President of Finland and Prime Ministers of Norway, Sweden, Denmark &amp; Iceland \u2192 https:\/\/t.co\/7DoFN57F96",
  "id" : 731105022583406592,
  "created_at" : "2016-05-13 12:53:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Macklemore",
      "screen_name" : "macklemore",
      "indices" : [ 3, 14 ],
      "id_str" : "18159470",
      "id" : 18159470
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 33, 44 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "MTV",
      "screen_name" : "MTV",
      "indices" : [ 50, 54 ],
      "id_str" : "2367911",
      "id" : 2367911
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730910816111894528",
  "text" : "RT @macklemore: Honored to be at @WhiteHouse with @MTV to talk to @POTUS about opioid  addiction. Really excited for this project. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 17, 28 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "MTV",
        "screen_name" : "MTV",
        "indices" : [ 34, 38 ],
        "id_str" : "2367911",
        "id" : 2367911
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 50, 56 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/macklemore\/status\/730896033157255168\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/feb7AfoHqn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiSqEYmUkAES4Hn.jpg",
        "id_str" : "730896031840243713",
        "id" : 730896031840243713,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiSqEYmUkAES4Hn.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2333,
          "resize" : "fit",
          "w" : 3500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/feb7AfoHqn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730896033157255168",
    "text" : "Honored to be at @WhiteHouse with @MTV to talk to @POTUS about opioid  addiction. Really excited for this project. https:\/\/t.co\/feb7AfoHqn",
    "id" : 730896033157255168,
    "created_at" : "2016-05-12 23:02:48 +0000",
    "user" : {
      "name" : "Macklemore",
      "screen_name" : "macklemore",
      "protected" : false,
      "id_str" : "18159470",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785934991817445377\/a1y-3oro_normal.jpg",
      "id" : 18159470,
      "verified" : true
    }
  },
  "id" : 730910816111894528,
  "created_at" : "2016-05-13 00:01:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/r05XQfFFb7",
      "expanded_url" : "http:\/\/go.wh.gov\/aUrzBc",
      "display_url" : "go.wh.gov\/aUrzBc"
    } ]
  },
  "geo" : { },
  "id_str" : "730893317416882176",
  "text" : "\"He is the fairest, most impartial person I know.\" Judge Garland's former clerks reflect on who he was as a boss: https:\/\/t.co\/r05XQfFFb7",
  "id" : 730893317416882176,
  "created_at" : "2016-05-12 22:52:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/iYAWMpYGKm",
      "expanded_url" : "http:\/\/go.wh.gov\/XrmnZU",
      "display_url" : "go.wh.gov\/XrmnZU"
    } ]
  },
  "geo" : { },
  "id_str" : "730855419283947520",
  "text" : "RT @FactsOnClimate: .@POTUS is taking historic action to reduce methane emissions. Here's how \u2192  https:\/\/t.co\/iYAWMpYGKm #ActOnClimate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/iYAWMpYGKm",
        "expanded_url" : "http:\/\/go.wh.gov\/XrmnZU",
        "display_url" : "go.wh.gov\/XrmnZU"
      } ]
    },
    "geo" : { },
    "id_str" : "730855203679969282",
    "text" : ".@POTUS is taking historic action to reduce methane emissions. Here's how \u2192  https:\/\/t.co\/iYAWMpYGKm #ActOnClimate",
    "id" : 730855203679969282,
    "created_at" : "2016-05-12 20:20:33 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 730855419283947520,
  "created_at" : "2016-05-12 20:21:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/730791176316407808\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/4n4yWlZqp6",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiRChOhUgAAhoL4.jpg",
      "id_str" : "730782178141831168",
      "id" : 730782178141831168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiRChOhUgAAhoL4.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4n4yWlZqp6"
    } ],
    "hashtags" : [ {
      "text" : "ZikaVirus",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/4Xw449EFpX",
      "expanded_url" : "http:\/\/go.wh.gov\/Zika",
      "display_url" : "go.wh.gov\/Zika"
    } ]
  },
  "geo" : { },
  "id_str" : "730791176316407808",
  "text" : "Why Congress needs to act so state and local leaders can prevent the spread of #ZikaVirus: https:\/\/t.co\/4Xw449EFpX https:\/\/t.co\/4n4yWlZqp6",
  "id" : 730791176316407808,
  "created_at" : "2016-05-12 16:06:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/730785903631687680\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/AVJ7feT6Qj",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiRCGPaUoAQTK9O.jpg",
      "id_str" : "730781714524446724",
      "id" : 730781714524446724,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiRCGPaUoAQTK9O.jpg",
      "sizes" : [ {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AVJ7feT6Qj"
    } ],
    "hashtags" : [ {
      "text" : "ZikaVirus",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/4Xw449EFpX",
      "expanded_url" : "http:\/\/go.wh.gov\/Zika",
      "display_url" : "go.wh.gov\/Zika"
    } ]
  },
  "geo" : { },
  "id_str" : "730785903631687680",
  "text" : "Why Americans need Republican Members of Congress to act on #ZikaVirus funding\u2014now: https:\/\/t.co\/4Xw449EFpX https:\/\/t.co\/AVJ7feT6Qj",
  "id" : 730785903631687680,
  "created_at" : "2016-05-12 15:45:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/vflEfVtPXS",
      "expanded_url" : "http:\/\/go.wh.gov\/aUrzBc",
      "display_url" : "go.wh.gov\/aUrzBc"
    } ]
  },
  "geo" : { },
  "id_str" : "730780433735094272",
  "text" : "RT @SCOTUSnom: READ THIS: Judge Garland's former clerks reflect on who he was as a boss \u2192 https:\/\/t.co\/vflEfVtPXS #SCOTUS https:\/\/t.co\/dj4x\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCOTUSnom\/status\/730778981792800768\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/dj4xEvq3dr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiQ-IdDUYAEYmGM.jpg",
        "id_str" : "730777354499284993",
        "id" : 730777354499284993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiQ-IdDUYAEYmGM.jpg",
        "sizes" : [ {
          "h" : 223,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 691,
          "resize" : "fit",
          "w" : 1054
        } ],
        "display_url" : "pic.twitter.com\/dj4xEvq3dr"
      } ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/vflEfVtPXS",
        "expanded_url" : "http:\/\/go.wh.gov\/aUrzBc",
        "display_url" : "go.wh.gov\/aUrzBc"
      } ]
    },
    "geo" : { },
    "id_str" : "730778981792800768",
    "text" : "READ THIS: Judge Garland's former clerks reflect on who he was as a boss \u2192 https:\/\/t.co\/vflEfVtPXS #SCOTUS https:\/\/t.co\/dj4xEvq3dr",
    "id" : 730778981792800768,
    "created_at" : "2016-05-12 15:17:41 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 730780433735094272,
  "created_at" : "2016-05-12 15:23:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Anderson",
      "screen_name" : "Charlie44",
      "indices" : [ 3, 13 ],
      "id_str" : "4796005523",
      "id" : 4796005523
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 87, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730528143673425920",
  "text" : "RT @Charlie44: .@POTUS signed law today protecting trade secrets. Congress should pass #TPP to defend U.S. innovation overseas too. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Charlie44\/status\/730527629519011840\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/5kiNVsVU2W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiNbAfbU4AEn9g3.jpg",
        "id_str" : "730527628558393345",
        "id" : 730527628558393345,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiNbAfbU4AEn9g3.jpg",
        "sizes" : [ {
          "h" : 216,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1781,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/5kiNVsVU2W"
      } ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 72, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730527629519011840",
    "text" : ".@POTUS signed law today protecting trade secrets. Congress should pass #TPP to defend U.S. innovation overseas too. https:\/\/t.co\/5kiNVsVU2W",
    "id" : 730527629519011840,
    "created_at" : "2016-05-11 22:38:54 +0000",
    "user" : {
      "name" : "Charlie Anderson",
      "screen_name" : "Charlie44",
      "protected" : false,
      "id_str" : "4796005523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689598827691520000\/6gRd26qn_normal.jpg",
      "id" : 4796005523,
      "verified" : true
    }
  },
  "id" : 730528143673425920,
  "created_at" : "2016-05-11 22:40:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730521921184534528",
  "text" : "RT @Denis44: Rs &amp; Ds, House &amp; Senate as POTUS signs a bill. Why not same picture for TPP, CJR, funds for Zika, opioids, Flint? https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/730521724509249536\/photo\/1",
        "indices" : [ 122, 145 ],
        "url" : "https:\/\/t.co\/AUbygzeniF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiNVownUgAEC5cY.jpg",
        "id_str" : "730521723297103873",
        "id" : 730521723297103873,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiNVownUgAEC5cY.jpg",
        "sizes" : [ {
          "h" : 216,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 651,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1781,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/AUbygzeniF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730521724509249536",
    "text" : "Rs &amp; Ds, House &amp; Senate as POTUS signs a bill. Why not same picture for TPP, CJR, funds for Zika, opioids, Flint? https:\/\/t.co\/AUbygzeniF",
    "id" : 730521724509249536,
    "created_at" : "2016-05-11 22:15:26 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 730521921184534528,
  "created_at" : "2016-05-11 22:16:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 92, 95 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoyfulRevolution",
      "indices" : [ 59, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730499603137757188",
  "text" : "RT @VPLive: A surprise @POTUS video played at last night's #JoyfulRevolution Gala, honoring @VP's work to end domestic violence.\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 80, 83 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoyfulRevolution",
        "indices" : [ 47, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/zsGrS3XEC3",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/4dcb03df-1e9e-428d-a813-6f611266b864",
        "display_url" : "amp.twimg.com\/v\/4dcb03df-1e9\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730485811104243713",
    "text" : "A surprise @POTUS video played at last night's #JoyfulRevolution Gala, honoring @VP's work to end domestic violence.\nhttps:\/\/t.co\/zsGrS3XEC3",
    "id" : 730485811104243713,
    "created_at" : "2016-05-11 19:52:43 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 730499603137757188,
  "created_at" : "2016-05-11 20:47:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/730494574507008000\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/Ii6Qtf0W2T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiM84b2VEAAGQMh.jpg",
      "id_str" : "730494504810123264",
      "id" : 730494504810123264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiM84b2VEAAGQMh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ii6Qtf0W2T"
    } ],
    "hashtags" : [ {
      "text" : "ZikaVirus",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/G900peFaXT",
      "expanded_url" : "http:\/\/go.wh.gov\/zika",
      "display_url" : "go.wh.gov\/zika"
    } ]
  },
  "geo" : { },
  "id_str" : "730494574507008000",
  "text" : "Here's what @POTUS asked Congress to provide to combat the #ZikaVirus\u20142 months ago: https:\/\/t.co\/G900peFaXT https:\/\/t.co\/Ii6Qtf0W2T",
  "id" : 730494574507008000,
  "created_at" : "2016-05-11 20:27:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cook",
      "screen_name" : "PentagonPresSec",
      "indices" : [ 3, 19 ],
      "id_str" : "335996055",
      "id" : 335996055
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 88, 95 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "DIUx",
      "screen_name" : "DIU_x",
      "indices" : [ 107, 113 ],
      "id_str" : "3412894191",
      "id" : 3412894191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecDef",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/elA2k86yGH",
      "expanded_url" : "https:\/\/medium.com\/@SecDef\/3c9438e76214",
      "display_url" : "medium.com\/@SecDef\/3c9438\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730489489324388352",
  "text" : "RT @PentagonPresSec: What's next for DoD's first startup?#SecDef explains in his latest @medium post about @DIU_x https:\/\/t.co\/elA2k86yGH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 67, 74 ],
        "id_str" : "571202103",
        "id" : 571202103
      }, {
        "name" : "DIUx",
        "screen_name" : "DIU_x",
        "indices" : [ 86, 92 ],
        "id_str" : "3412894191",
        "id" : 3412894191
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecDef",
        "indices" : [ 36, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/elA2k86yGH",
        "expanded_url" : "https:\/\/medium.com\/@SecDef\/3c9438e76214",
        "display_url" : "medium.com\/@SecDef\/3c9438\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730451859421331456",
    "text" : "What's next for DoD's first startup?#SecDef explains in his latest @medium post about @DIU_x https:\/\/t.co\/elA2k86yGH",
    "id" : 730451859421331456,
    "created_at" : "2016-05-11 17:37:49 +0000",
    "user" : {
      "name" : "Peter Cook",
      "screen_name" : "PentagonPresSec",
      "protected" : false,
      "id_str" : "335996055",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622845115057332225\/gZiug-pi_normal.jpg",
      "id" : 335996055,
      "verified" : true
    }
  },
  "id" : 730489489324388352,
  "created_at" : "2016-05-11 20:07:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/730476186669744128\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/haL9dM8chb",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiMsMxcVEAAI1ov.jpg",
      "id_str" : "730476162506362880",
      "id" : 730476162506362880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiMsMxcVEAAI1ov.jpg",
      "sizes" : [ {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/haL9dM8chb"
    } ],
    "hashtags" : [ {
      "text" : "ZikaVirus",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/4Xw449EFpX",
      "expanded_url" : "http:\/\/go.wh.gov\/Zika",
      "display_url" : "go.wh.gov\/Zika"
    } ]
  },
  "geo" : { },
  "id_str" : "730476186669744128",
  "text" : "Congress can't wait until October to pass #ZikaVirus funding @POTUS proposed in February. https:\/\/t.co\/4Xw449EFpX https:\/\/t.co\/haL9dM8chb",
  "id" : 730476186669744128,
  "created_at" : "2016-05-11 19:14:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Markey",
      "screen_name" : "SenMarkey",
      "indices" : [ 3, 13 ],
      "id_str" : "21406834",
      "id" : 21406834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ZikaVirus",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730470790697762816",
  "text" : "RT @SenMarkey: Senate Republicans are refusing to deal w threat of the #ZikaVirus. We need funding now to protect public health https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenMarkey\/status\/730429287296180227\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/BnKBvCH4qR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiLz_BUWsAAgBw8.jpg",
        "id_str" : "730414353598558208",
        "id" : 730414353598558208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiLz_BUWsAAgBw8.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BnKBvCH4qR"
      } ],
      "hashtags" : [ {
        "text" : "ZikaVirus",
        "indices" : [ 56, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "730429287296180227",
    "text" : "Senate Republicans are refusing to deal w threat of the #ZikaVirus. We need funding now to protect public health https:\/\/t.co\/BnKBvCH4qR",
    "id" : 730429287296180227,
    "created_at" : "2016-05-11 16:08:07 +0000",
    "user" : {
      "name" : "Ed Markey",
      "screen_name" : "SenMarkey",
      "protected" : false,
      "id_str" : "21406834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739889609262411780\/qDeJ7rdE_normal.jpg",
      "id" : 21406834,
      "verified" : true
    }
  },
  "id" : 730470790697762816,
  "created_at" : "2016-05-11 18:53:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 1, 17 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ZikaVirus",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/4Xw449WgOx",
      "expanded_url" : "http:\/\/go.wh.gov\/Zika",
      "display_url" : "go.wh.gov\/Zika"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/0FB9IDTkvc",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/a69ac437-3ecc-4d0a-b64d-536e2f78b4cd",
      "display_url" : "amp.twimg.com\/v\/a69ac437-3ec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730464001822490625",
  "text" : ".@Surgeon_General breaks down what you need to know to protect yourself from the #ZikaVirus: https:\/\/t.co\/4Xw449WgOx https:\/\/t.co\/0FB9IDTkvc",
  "id" : 730464001822490625,
  "created_at" : "2016-05-11 18:26:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 28, 34 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "Heidi Murkoff",
      "screen_name" : "HeidiMurkoff",
      "indices" : [ 50, 63 ],
      "id_str" : "179083387",
      "id" : 179083387
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730458004944998400",
  "text" : "RT @NSC44: Today at 3pm ET, @NSC44's Amy Pope and @HeidiMurkoff will answer your ?'s on Zika. Send your questions with #Zika.  https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WH National Security",
        "screen_name" : "NSC44",
        "indices" : [ 17, 23 ],
        "id_str" : "369245377",
        "id" : 369245377
      }, {
        "name" : "Heidi Murkoff",
        "screen_name" : "HeidiMurkoff",
        "indices" : [ 39, 52 ],
        "id_str" : "179083387",
        "id" : 179083387
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 108, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/NpUfYOitR7",
        "expanded_url" : "http:\/\/wte.to\/gRVG3TG",
        "display_url" : "wte.to\/gRVG3TG"
      } ]
    },
    "geo" : { },
    "id_str" : "730456831860973568",
    "text" : "Today at 3pm ET, @NSC44's Amy Pope and @HeidiMurkoff will answer your ?'s on Zika. Send your questions with #Zika.  https:\/\/t.co\/NpUfYOitR7",
    "id" : 730456831860973568,
    "created_at" : "2016-05-11 17:57:34 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 730458004944998400,
  "created_at" : "2016-05-11 18:02:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/730449263038205953\/photo\/1",
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/nwlMGgFjAu",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiMTq4PWkAAEmks.jpg",
      "id_str" : "730449191936364544",
      "id" : 730449191936364544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiMTq4PWkAAEmks.jpg",
      "sizes" : [ {
        "h" : 674,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nwlMGgFjAu"
    } ],
    "hashtags" : [ {
      "text" : "ZikaVirus",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/G900peFaXT",
      "expanded_url" : "http:\/\/go.wh.gov\/zika",
      "display_url" : "go.wh.gov\/zika"
    } ]
  },
  "geo" : { },
  "id_str" : "730449263038205953",
  "text" : "#ZikaVirus is an emergency. Congress should treat it as one &amp; pass @POTUS's funding request: https:\/\/t.co\/G900peFaXT https:\/\/t.co\/nwlMGgFjAu",
  "id" : 730449263038205953,
  "created_at" : "2016-05-11 17:27:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ATTN:",
      "screen_name" : "attn",
      "indices" : [ 3, 8 ],
      "id_str" : "214112621",
      "id" : 214112621
    }, {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 69, 85 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/81xRXEO3MV",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/a69ac437-3ecc-4d0a-b64d-536e2f78b4cd",
      "display_url" : "amp.twimg.com\/v\/a69ac437-3ec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730420718719008768",
  "text" : "RT @attn: Here are 3 ways to protect yourself from the Zika virus. - @Surgeon_General\nhttps:\/\/t.co\/81xRXEO3MV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Surgeon General",
        "screen_name" : "Surgeon_General",
        "indices" : [ 59, 75 ],
        "id_str" : "455024343",
        "id" : 455024343
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/81xRXEO3MV",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/a69ac437-3ecc-4d0a-b64d-536e2f78b4cd",
        "display_url" : "amp.twimg.com\/v\/a69ac437-3ec\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730412913438007296",
    "text" : "Here are 3 ways to protect yourself from the Zika virus. - @Surgeon_General\nhttps:\/\/t.co\/81xRXEO3MV",
    "id" : 730412913438007296,
    "created_at" : "2016-05-11 15:03:03 +0000",
    "user" : {
      "name" : "ATTN:",
      "screen_name" : "attn",
      "protected" : false,
      "id_str" : "214112621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616387650560389120\/7dI5Ky0i_normal.jpg",
      "id" : 214112621,
      "verified" : true
    }
  },
  "id" : 730420718719008768,
  "created_at" : "2016-05-11 15:34:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "What To Expect",
      "screen_name" : "WhatToExpect",
      "indices" : [ 3, 16 ],
      "id_str" : "19308735",
      "id" : 19308735
    }, {
      "name" : "Heidi Murkoff",
      "screen_name" : "HeidiMurkoff",
      "indices" : [ 49, 62 ],
      "id_str" : "179083387",
      "id" : 179083387
    }, {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 113, 119 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 27, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730404303702216705",
  "text" : "RT @WhatToExpect: Join the #Zika Twitter chat w\/ @HeidiMurkoff &amp; Amy Pope, deputy homeland security advisor, @NSC44 TODAY at 3 pm ET. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Heidi Murkoff",
        "screen_name" : "HeidiMurkoff",
        "indices" : [ 31, 44 ],
        "id_str" : "179083387",
        "id" : 179083387
      }, {
        "name" : "WH National Security",
        "screen_name" : "NSC44",
        "indices" : [ 95, 101 ],
        "id_str" : "369245377",
        "id" : 369245377
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 9, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/F2ELe6UhDx",
        "expanded_url" : "http:\/\/wte.to\/QBKZ8Qi",
        "display_url" : "wte.to\/QBKZ8Qi"
      } ]
    },
    "geo" : { },
    "id_str" : "730362504279396352",
    "text" : "Join the #Zika Twitter chat w\/ @HeidiMurkoff &amp; Amy Pope, deputy homeland security advisor, @NSC44 TODAY at 3 pm ET. https:\/\/t.co\/F2ELe6UhDx",
    "id" : 730362504279396352,
    "created_at" : "2016-05-11 11:42:45 +0000",
    "user" : {
      "name" : "What To Expect",
      "screen_name" : "WhatToExpect",
      "protected" : false,
      "id_str" : "19308735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696749772875689984\/MiEthlBQ_normal.png",
      "id" : 19308735,
      "verified" : false
    }
  },
  "id" : 730404303702216705,
  "created_at" : "2016-05-11 14:28:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730402091114627073",
  "text" : "RT @PressSec: Fighting Zika is about protecting pregnant women, it is time for Congress to pass requests for #Zika funding now https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 95, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/6BZbZUGrUA",
        "expanded_url" : "http:\/\/www.npr.org\/2016\/05\/11\/477607408\/fighting-zika-is-about-protecting-pregnant-women-fauci-says",
        "display_url" : "npr.org\/2016\/05\/11\/477\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730395027969589249",
    "text" : "Fighting Zika is about protecting pregnant women, it is time for Congress to pass requests for #Zika funding now https:\/\/t.co\/6BZbZUGrUA",
    "id" : 730395027969589249,
    "created_at" : "2016-05-11 13:51:59 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 730402091114627073,
  "created_at" : "2016-05-11 14:20:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "UConn Women's Hoops",
      "screen_name" : "UConnWBB",
      "indices" : [ 52, 61 ],
      "id_str" : "242785840",
      "id" : 242785840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/lebXAS5Klq",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/4d4d5d22-f6a1-4e7f-8856-f44587812124",
      "display_url" : "amp.twimg.com\/v\/4d4d5d22-f6a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730215538685681664",
  "text" : "\"What do you think? Stylin', huh?\" \u2014@POTUS with the @UConnWBB champs after receiving a gift from the team\nhttps:\/\/t.co\/lebXAS5Klq",
  "id" : 730215538685681664,
  "created_at" : "2016-05-11 01:58:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ifVfHcqkA9",
      "expanded_url" : "http:\/\/snpy.tv\/23sSD7l",
      "display_url" : "snpy.tv\/23sSD7l"
    } ]
  },
  "geo" : { },
  "id_str" : "730106331084955648",
  "text" : "\u201CWhen I called Coach Auriemma to congratulate him...I told him we\u2019d have his room ready for him when he got here\u201D https:\/\/t.co\/ifVfHcqkA9",
  "id" : 730106331084955648,
  "created_at" : "2016-05-10 18:44:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NCAA",
      "screen_name" : "NCAA",
      "indices" : [ 101, 106 ],
      "id_str" : "31122496",
      "id" : 31122496
    }, {
      "name" : "UConn Women's Hoops",
      "screen_name" : "UConnWBB",
      "indices" : [ 114, 123 ],
      "id_str" : "242785840",
      "id" : 242785840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730106055498174464",
  "text" : "\u201CFor the fourth year in a row, give it up for the NCAA Champion UCONN Huskies!\u201D \u2014@POTUS honoring the @NCAA champs @UConnWBB",
  "id" : 730106055498174464,
  "created_at" : "2016-05-10 18:43:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "UConn Women's Hoops",
      "screen_name" : "UConnWBB",
      "indices" : [ 68, 77 ],
      "id_str" : "242785840",
      "id" : 242785840
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UConnNation",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/pVFLa2q71B",
      "expanded_url" : "http:\/\/go.wh.gov\/j34uFy",
      "display_url" : "go.wh.gov\/j34uFy"
    } ]
  },
  "geo" : { },
  "id_str" : "730105476927524864",
  "text" : "Watch live: @POTUS honors the 2016 NCAA Women's Basketball Champion @UConnWBB \u2192 https:\/\/t.co\/pVFLa2q71B  #UConnNation",
  "id" : 730105476927524864,
  "created_at" : "2016-05-10 18:41:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "ChuckGrassley",
      "screen_name" : "ChuckGrassley",
      "indices" : [ 86, 100 ],
      "id_str" : "10615232",
      "id" : 10615232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/01zuyMxfuu",
      "expanded_url" : "http:\/\/go.wh.gov\/Questionnaire",
      "display_url" : "go.wh.gov\/Questionnaire"
    } ]
  },
  "geo" : { },
  "id_str" : "730065559568715778",
  "text" : "RT @SCOTUSnom: Judge Garland did his job &amp; filled out his questionnaire. Time for @ChuckGrassley to do his: https:\/\/t.co\/01zuyMxfuu https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ChuckGrassley",
        "screen_name" : "ChuckGrassley",
        "indices" : [ 71, 85 ],
        "id_str" : "10615232",
        "id" : 10615232
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCOTUSnom\/status\/730063785537372160\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/Mp1DapmEOr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiG1IMwVAAAe3Bg.jpg",
        "id_str" : "730063767078240256",
        "id" : 730063767078240256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiG1IMwVAAAe3Bg.jpg",
        "sizes" : [ {
          "h" : 711,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1944,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 417,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 236,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Mp1DapmEOr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/01zuyMxfuu",
        "expanded_url" : "http:\/\/go.wh.gov\/Questionnaire",
        "display_url" : "go.wh.gov\/Questionnaire"
      } ]
    },
    "geo" : { },
    "id_str" : "730063785537372160",
    "text" : "Judge Garland did his job &amp; filled out his questionnaire. Time for @ChuckGrassley to do his: https:\/\/t.co\/01zuyMxfuu https:\/\/t.co\/Mp1DapmEOr",
    "id" : 730063785537372160,
    "created_at" : "2016-05-10 15:55:45 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 730065559568715778,
  "created_at" : "2016-05-10 16:02:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "WH Internship",
      "screen_name" : "WHInternship",
      "indices" : [ 54, 67 ],
      "id_str" : "4530405972",
      "id" : 4530405972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/3v4rErZwLF",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/43f6fdf7-894c-43c1-8faa-7ea3117ac88a",
      "display_url" : "amp.twimg.com\/v\/43f6fdf7-894\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730062575560314881",
  "text" : "Watch @POTUS give advice to the outgoing class of the @WHInternship program:\nhttps:\/\/t.co\/3v4rErZwLF",
  "id" : 730062575560314881,
  "created_at" : "2016-05-10 15:50:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "\u5B89\u500D\u664B\u4E09",
      "screen_name" : "AbeShinzo",
      "indices" : [ 67, 77 ],
      "id_str" : "468122115",
      "id" : 468122115
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/730042944485494785\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/ejM0tLl7k6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiGh-ohUYAA9lk2.jpg",
      "id_str" : "730042712011857920",
      "id" : 730042712011857920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiGh-ohUYAA9lk2.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ejM0tLl7k6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/2OsOLAaKZC",
      "expanded_url" : "http:\/\/go.wh.gov\/6HWzv1",
      "display_url" : "go.wh.gov\/6HWzv1"
    } ]
  },
  "geo" : { },
  "id_str" : "730042944485494785",
  "text" : "Here's why @POTUS will visit Hiroshima with Japan's Prime Minister @AbeShinzo: https:\/\/t.co\/2OsOLAaKZC https:\/\/t.co\/ejM0tLl7k6",
  "id" : 730042944485494785,
  "created_at" : "2016-05-10 14:32:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/730025750577831936\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/Z2mh87dzSs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiGSjSDVEAAyW1w.jpg",
      "id_str" : "730025749449609216",
      "id" : 730025749449609216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiGSjSDVEAAyW1w.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Z2mh87dzSs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/2OsOLAslRa",
      "expanded_url" : "http:\/\/go.wh.gov\/6HWzv1",
      "display_url" : "go.wh.gov\/6HWzv1"
    } ]
  },
  "geo" : { },
  "id_str" : "730025750577831936",
  "text" : "BREAKING: @POTUS will be the first sitting U.S. President to visit Hiroshima on May 27 \u2192 https:\/\/t.co\/2OsOLAslRa https:\/\/t.co\/Z2mh87dzSs",
  "id" : 730025750577831936,
  "created_at" : "2016-05-10 13:24:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/myP3vgmtwJ",
      "expanded_url" : "https:\/\/medium.com\/@rhodes44\/the-first-sitting-u-s-president-to-visit-hiroshima-1992461baf4c#.88zbg9mtg",
      "display_url" : "medium.com\/@rhodes44\/the-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "730010772227510272",
  "text" : "RT @rhodes44: On May 27, @POTUS will visit the Hiroshima Peace Memorial Park. Here's what the visit means: https:\/\/t.co\/myP3vgmtwJ https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/730007847547756544\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/vMY7VbCY3z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiGCOZ_VEAEjK48.jpg",
        "id_str" : "730007798617018369",
        "id" : 730007798617018369,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiGCOZ_VEAEjK48.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/vMY7VbCY3z"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/myP3vgmtwJ",
        "expanded_url" : "https:\/\/medium.com\/@rhodes44\/the-first-sitting-u-s-president-to-visit-hiroshima-1992461baf4c#.88zbg9mtg",
        "display_url" : "medium.com\/@rhodes44\/the-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "730007847547756544",
    "text" : "On May 27, @POTUS will visit the Hiroshima Peace Memorial Park. Here's what the visit means: https:\/\/t.co\/myP3vgmtwJ https:\/\/t.co\/vMY7VbCY3z",
    "id" : 730007847547756544,
    "created_at" : "2016-05-10 12:13:28 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 730010772227510272,
  "created_at" : "2016-05-10 12:25:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NC State University",
      "screen_name" : "NCState",
      "indices" : [ 71, 79 ],
      "id_str" : "487624974",
      "id" : 487624974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/5VxhGuAx8o",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/b976e8f5-9a3d-4c81-99a7-4b75fcfc18cf",
      "display_url" : "amp.twimg.com\/v\/b976e8f5-9a3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729820887705231360",
  "text" : "\"All of us remember that game.\"\n33 years later, @POTUS honors the 1983 @NCState basketball champs.\nhttps:\/\/t.co\/5VxhGuAx8o",
  "id" : 729820887705231360,
  "created_at" : "2016-05-09 23:50:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    }, {
      "name" : "NWS Tornado",
      "screen_name" : "NWStornado",
      "indices" : [ 39, 50 ],
      "id_str" : "2544227706",
      "id" : 2544227706
    }, {
      "name" : "NWS Norman",
      "screen_name" : "NWSNorman",
      "indices" : [ 51, 61 ],
      "id_str" : "303994581",
      "id" : 303994581
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "okwx",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/HHE3KNFDOL",
      "expanded_url" : "http:\/\/www.ready.gov\/tornadoes",
      "display_url" : "ready.gov\/tornadoes"
    } ]
  },
  "geo" : { },
  "id_str" : "729804305654501376",
  "text" : "RT @fema: #okwx: for \uD83C\uDF2A updates, follow @NWStornado @NWSNorman. Listen to local officials. Be safe. https:\/\/t.co\/HHE3KNFDOL https:\/\/t.co\/Owp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NWS Tornado",
        "screen_name" : "NWStornado",
        "indices" : [ 29, 40 ],
        "id_str" : "2544227706",
        "id" : 2544227706
      }, {
        "name" : "NWS Norman",
        "screen_name" : "NWSNorman",
        "indices" : [ 41, 51 ],
        "id_str" : "303994581",
        "id" : 303994581
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fema\/status\/729800429979238400\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/OwpJ4X0tdP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiDFnxwWEAAdr6R.jpg",
        "id_str" : "729800426795700224",
        "id" : 729800426795700224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiDFnxwWEAAdr6R.jpg",
        "sizes" : [ {
          "h" : 205,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 616,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 616,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/OwpJ4X0tdP"
      } ],
      "hashtags" : [ {
        "text" : "okwx",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/HHE3KNFDOL",
        "expanded_url" : "http:\/\/www.ready.gov\/tornadoes",
        "display_url" : "ready.gov\/tornadoes"
      } ]
    },
    "geo" : { },
    "id_str" : "729800429979238400",
    "text" : "#okwx: for \uD83C\uDF2A updates, follow @NWStornado @NWSNorman. Listen to local officials. Be safe. https:\/\/t.co\/HHE3KNFDOL https:\/\/t.co\/OwpJ4X0tdP",
    "id" : 729800429979238400,
    "created_at" : "2016-05-09 22:29:16 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 729804305654501376,
  "created_at" : "2016-05-09 22:44:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Jeopardy!",
      "screen_name" : "Jeopardy",
      "indices" : [ 22, 31 ],
      "id_str" : "52554306",
      "id" : 52554306
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/729795554834825216\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/UAzY6HM1Zw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiDBLFUVEAEZthK.jpg",
      "id_str" : "729795535784185857",
      "id" : 729795535784185857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiDBLFUVEAEZthK.jpg",
      "sizes" : [ {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1362,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UAzY6HM1Zw"
    } ],
    "hashtags" : [ {
      "text" : "TeacherTournament",
      "indices" : [ 48, 66 ]
    }, {
      "text" : "ThankATeacher",
      "indices" : [ 68, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/D5dLxP2BPM",
      "expanded_url" : "https:\/\/instagram.com\/p\/BFM9_UrE7_m\/",
      "display_url" : "instagram.com\/p\/BFM9_UrE7_m\/"
    } ]
  },
  "geo" : { },
  "id_str" : "729796277433729024",
  "text" : "RT @DrBiden: Who's on @Jeopardy tonight for the #TeacherTournament? #ThankATeacher https:\/\/t.co\/D5dLxP2BPM https:\/\/t.co\/UAzY6HM1Zw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jeopardy!",
        "screen_name" : "Jeopardy",
        "indices" : [ 9, 18 ],
        "id_str" : "52554306",
        "id" : 52554306
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/729795554834825216\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/UAzY6HM1Zw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiDBLFUVEAEZthK.jpg",
        "id_str" : "729795535784185857",
        "id" : 729795535784185857,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiDBLFUVEAEZthK.jpg",
        "sizes" : [ {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1362,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/UAzY6HM1Zw"
      } ],
      "hashtags" : [ {
        "text" : "TeacherTournament",
        "indices" : [ 35, 53 ]
      }, {
        "text" : "ThankATeacher",
        "indices" : [ 55, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/D5dLxP2BPM",
        "expanded_url" : "https:\/\/instagram.com\/p\/BFM9_UrE7_m\/",
        "display_url" : "instagram.com\/p\/BFM9_UrE7_m\/"
      } ]
    },
    "geo" : { },
    "id_str" : "729795554834825216",
    "text" : "Who's on @Jeopardy tonight for the #TeacherTournament? #ThankATeacher https:\/\/t.co\/D5dLxP2BPM https:\/\/t.co\/UAzY6HM1Zw",
    "id" : 729795554834825216,
    "created_at" : "2016-05-09 22:09:53 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 729796277433729024,
  "created_at" : "2016-05-09 22:12:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "indices" : [ 3, 15 ],
      "id_str" : "293131808",
      "id" : 293131808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729759288420388867",
  "text" : "RT @PattyMurray: Even with more than 1000 reported cases of Zika in the U.S., Republican leaders have refused to act. https:\/\/t.co\/vGATByr0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ZikaVirus",
        "indices" : [ 125, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/vGATByr0MY",
        "expanded_url" : "https:\/\/medium.com\/@PattyMurray\/why-im-issuing-a-call-to-action-on-zika-29996e469b23#.6n6rzah2l",
        "display_url" : "medium.com\/@PattyMurray\/w\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729684480248696832",
    "text" : "Even with more than 1000 reported cases of Zika in the U.S., Republican leaders have refused to act. https:\/\/t.co\/vGATByr0MY #ZikaVirus",
    "id" : 729684480248696832,
    "created_at" : "2016-05-09 14:48:31 +0000",
    "user" : {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "protected" : false,
      "id_str" : "293131808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430384292917555200\/ULj2LMsW_normal.jpeg",
      "id" : 293131808,
      "verified" : true
    }
  },
  "id" : 729759288420388867,
  "created_at" : "2016-05-09 19:45:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senate Republicans",
      "screen_name" : "SenateGOP",
      "indices" : [ 29, 39 ],
      "id_str" : "14344823",
      "id" : 14344823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "DoYourJob",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/CMCXbCC5sV",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/7344acc3-b4f3-4b9e-ab46-2d869b2ec73c",
      "display_url" : "amp.twimg.com\/v\/7344acc3-b4f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729756680855105536",
  "text" : "A majority of Americans want @SenateGOP to hold a #SCOTUS hearing for one simple reason: It's their job. #DoYourJob https:\/\/t.co\/CMCXbCC5sV",
  "id" : 729756680855105536,
  "created_at" : "2016-05-09 19:35:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/729745346906087424\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/c4efZe3v5X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiCThpAVIAAajdM.jpg",
      "id_str" : "729745345786224640",
      "id" : 729745345786224640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiCThpAVIAAajdM.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/c4efZe3v5X"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/TFWPdFbeBM",
      "expanded_url" : "http:\/\/on.doi.gov\/1Oc7VXg",
      "display_url" : "on.doi.gov\/1Oc7VXg"
    } ]
  },
  "geo" : { },
  "id_str" : "729747690893025284",
  "text" : "RT @Interior: Say hello to our new national mammal: The American bison https:\/\/t.co\/TFWPdFbeBM\nPic by Rich Keen https:\/\/t.co\/c4efZe3v5X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/729745346906087424\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/c4efZe3v5X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiCThpAVIAAajdM.jpg",
        "id_str" : "729745345786224640",
        "id" : 729745345786224640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiCThpAVIAAajdM.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 257,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/c4efZe3v5X"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/TFWPdFbeBM",
        "expanded_url" : "http:\/\/on.doi.gov\/1Oc7VXg",
        "display_url" : "on.doi.gov\/1Oc7VXg"
      } ]
    },
    "geo" : { },
    "id_str" : "729745346906087424",
    "text" : "Say hello to our new national mammal: The American bison https:\/\/t.co\/TFWPdFbeBM\nPic by Rich Keen https:\/\/t.co\/c4efZe3v5X",
    "id" : 729745346906087424,
    "created_at" : "2016-05-09 18:50:23 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 729747690893025284,
  "created_at" : "2016-05-09 18:59:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UnitedStateofWomen",
      "screen_name" : "USWomen2016",
      "indices" : [ 3, 15 ],
      "id_str" : "4795344505",
      "id" : 4795344505
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USWomen2016\/status\/729727479166971905\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/5A1WJ38UlE",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiCDRoDUYAEEPI6.jpg",
      "id_str" : "729727478466371585",
      "id" : 729727478466371585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiCDRoDUYAEEPI6.jpg",
      "sizes" : [ {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/5A1WJ38UlE"
    } ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 48, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/ntkjgHHPOm",
      "expanded_url" : "http:\/\/bit.ly\/1NxjyYt",
      "display_url" : "bit.ly\/1NxjyYt"
    } ]
  },
  "geo" : { },
  "id_str" : "729729059924627456",
  "text" : "RT @USWomen2016: Here's your chance to join the #StateOfWomen summit in DC \u2192 https:\/\/t.co\/ntkjgHHPOm https:\/\/t.co\/5A1WJ38UlE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USWomen2016\/status\/729727479166971905\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/5A1WJ38UlE",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CiCDRoDUYAEEPI6.jpg",
        "id_str" : "729727478466371585",
        "id" : 729727478466371585,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CiCDRoDUYAEEPI6.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/5A1WJ38UlE"
      } ],
      "hashtags" : [ {
        "text" : "StateOfWomen",
        "indices" : [ 31, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/ntkjgHHPOm",
        "expanded_url" : "http:\/\/bit.ly\/1NxjyYt",
        "display_url" : "bit.ly\/1NxjyYt"
      } ]
    },
    "geo" : { },
    "id_str" : "729727479166971905",
    "text" : "Here's your chance to join the #StateOfWomen summit in DC \u2192 https:\/\/t.co\/ntkjgHHPOm https:\/\/t.co\/5A1WJ38UlE",
    "id" : 729727479166971905,
    "created_at" : "2016-05-09 17:39:23 +0000",
    "user" : {
      "name" : "UnitedStateofWomen",
      "screen_name" : "USWomen2016",
      "protected" : false,
      "id_str" : "4795344505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692985821901754368\/5UoBC1W1_normal.png",
      "id" : 4795344505,
      "verified" : true
    }
  },
  "id" : 729729059924627456,
  "created_at" : "2016-05-09 17:45:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senate Republicans",
      "screen_name" : "SenateGOP",
      "indices" : [ 32, 42 ],
      "id_str" : "14344823",
      "id" : 14344823
    }, {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 88, 98 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJob",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/CMCXbCku4l",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/7344acc3-b4f3-4b9e-ab46-2d869b2ec73c",
      "display_url" : "amp.twimg.com\/v\/7344acc3-b4f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729725179396378625",
  "text" : "54 days and counting: When will @SenateGOP fulfill their constitutional duty &amp; give @SCOTUSnom a hearing? #DoYourJob https:\/\/t.co\/CMCXbCku4l",
  "id" : 729725179396378625,
  "created_at" : "2016-05-09 17:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 18, 28 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJob",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/CMCXbCC5sV",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/7344acc3-b4f3-4b9e-ab46-2d869b2ec73c",
      "display_url" : "amp.twimg.com\/v\/7344acc3-b4f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "729708573601738752",
  "text" : "Since 1875, every @SCOTUSnom has received a hearing or a vote\u2014until now. This is unprecedented. #DoYourJob https:\/\/t.co\/CMCXbCC5sV",
  "id" : 729708573601738752,
  "created_at" : "2016-05-09 16:24:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 41, 47 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Senate Republicans",
      "screen_name" : "SenateGOP",
      "indices" : [ 120, 130 ],
      "id_str" : "14344823",
      "id" : 14344823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJob",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729694447160676352",
  "text" : "RT @SCOTUSnom: 54 days have passed since @POTUS announced his Supreme Court nominee. It's well past time to #DoYourJob, @SenateGOP.\nhttps:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 26, 32 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Senate Republicans",
        "screen_name" : "SenateGOP",
        "indices" : [ 105, 115 ],
        "id_str" : "14344823",
        "id" : 14344823
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoYourJob",
        "indices" : [ 93, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ZYxDOTwCVT",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/7344acc3-b4f3-4b9e-ab46-2d869b2ec73c",
        "display_url" : "amp.twimg.com\/v\/7344acc3-b4f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729693902022680577",
    "text" : "54 days have passed since @POTUS announced his Supreme Court nominee. It's well past time to #DoYourJob, @SenateGOP.\nhttps:\/\/t.co\/ZYxDOTwCVT",
    "id" : 729693902022680577,
    "created_at" : "2016-05-09 15:25:57 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 729694447160676352,
  "created_at" : "2016-05-09 15:28:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "Senate Republicans",
      "screen_name" : "SenateGOP",
      "indices" : [ 44, 54 ],
      "id_str" : "14344823",
      "id" : 14344823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 65, 72 ]
    }, {
      "text" : "DoYourJob",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729690564959047680",
  "text" : "RT @SCOTUSnom: A majority of Americans want @SenateGop to hold a #SCOTUS hearing for one simple reason: It's their job. #DoYourJob\nhttps:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senate Republicans",
        "screen_name" : "SenateGOP",
        "indices" : [ 29, 39 ],
        "id_str" : "14344823",
        "id" : 14344823
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 50, 57 ]
      }, {
        "text" : "DoYourJob",
        "indices" : [ 105, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/gnT4Ft1oDC",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/3f22dcf0-5d03-495c-b255-bafe40caa3cb",
        "display_url" : "amp.twimg.com\/v\/3f22dcf0-5d0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729689177332142083",
    "text" : "A majority of Americans want @SenateGop to hold a #SCOTUS hearing for one simple reason: It's their job. #DoYourJob\nhttps:\/\/t.co\/gnT4Ft1oDC",
    "id" : 729689177332142083,
    "created_at" : "2016-05-09 15:07:11 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 729690564959047680,
  "created_at" : "2016-05-09 15:12:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    }, {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 33, 42 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729675592048607232",
  "text" : "RT @Denis44: Thoughtful piece by @rhodes44 on how we used facts 2 defend Iran Deal. Now, Iran verifiably can't get nuclear weapon https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Rhodes",
        "screen_name" : "rhodes44",
        "indices" : [ 20, 29 ],
        "id_str" : "249722522",
        "id" : 249722522
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/3jeSh5hmtT",
        "expanded_url" : "https:\/\/medium.com\/@rhodes44\/how-we-advocated-for-the-iran-deal-55e927fa9de5#.1ltcp189z",
        "display_url" : "medium.com\/@rhodes44\/how-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "729668930822770688",
    "text" : "Thoughtful piece by @rhodes44 on how we used facts 2 defend Iran Deal. Now, Iran verifiably can't get nuclear weapon https:\/\/t.co\/3jeSh5hmtT",
    "id" : 729668930822770688,
    "created_at" : "2016-05-09 13:46:44 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 729675592048607232,
  "created_at" : "2016-05-09 14:13:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/0v2IMwJcio",
      "expanded_url" : "http:\/\/go.wh.gov\/Weekly",
      "display_url" : "go.wh.gov\/Weekly"
    } ]
  },
  "geo" : { },
  "id_str" : "729390430010281984",
  "text" : "\"Let\u2019s make sure we show that gratitude and appreciation through acts of respect\"\u2014@POTUS on #MothersDay https:\/\/t.co\/0v2IMwJcio",
  "id" : 729390430010281984,
  "created_at" : "2016-05-08 19:20:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 111, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 146 ],
      "url" : "https:\/\/t.co\/0v2IMwJcio",
      "expanded_url" : "http:\/\/go.wh.gov\/Weekly",
      "display_url" : "go.wh.gov\/Weekly"
    } ]
  },
  "geo" : { },
  "id_str" : "729380369686880256",
  "text" : "\"Biological moms, adoptive moms, &amp; foster moms; single moms, grandmothers...aunts &amp; mentors\"\u2014@POTUS on #MothersDay https:\/\/t.co\/0v2IMwJcio",
  "id" : 729380369686880256,
  "created_at" : "2016-05-08 18:40:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/0v2IMwJcio",
      "expanded_url" : "http:\/\/go.wh.gov\/Weekly",
      "display_url" : "go.wh.gov\/Weekly"
    } ]
  },
  "geo" : { },
  "id_str" : "729370390036811776",
  "text" : "Watch as @POTUS wishes all moms a happy Mother's Day: https:\/\/t.co\/0v2IMwJcio",
  "id" : 729370390036811776,
  "created_at" : "2016-05-08 18:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/0v2IMwJcio",
      "expanded_url" : "http:\/\/go.wh.gov\/Weekly",
      "display_url" : "go.wh.gov\/Weekly"
    } ]
  },
  "geo" : { },
  "id_str" : "729355321022423041",
  "text" : "\"I hope you\u2019ll also take a moment to say thank you to the women in your life who love you\"\u2014@POTUS on Mother's Day https:\/\/t.co\/0v2IMwJcio",
  "id" : 729355321022423041,
  "created_at" : "2016-05-08 17:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/0v2IMwJcio",
      "expanded_url" : "http:\/\/go.wh.gov\/Weekly",
      "display_url" : "go.wh.gov\/Weekly"
    } ]
  },
  "geo" : { },
  "id_str" : "729345143875080192",
  "text" : "\"I\u2019m lucky to have incredible women who help me raise, love, and look after our girls.\"\u2014@POTUS on Mother's Day https:\/\/t.co\/0v2IMwJcio",
  "id" : 729345143875080192,
  "created_at" : "2016-05-08 16:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DiaperGap",
      "indices" : [ 89, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/8OKw5bPnaT",
      "expanded_url" : "http:\/\/go.wh.gov\/Ycsoy2",
      "display_url" : "go.wh.gov\/Ycsoy2"
    } ]
  },
  "geo" : { },
  "id_str" : "729340269439524864",
  "text" : "\"No mother or father should have to worry about keeping their baby clean\" \u2014@POTUS on the #DiaperGap: https:\/\/t.co\/8OKw5bPnaT",
  "id" : 729340269439524864,
  "created_at" : "2016-05-08 16:00:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/729316513149157376\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/wqBg716OB4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch8NXryUoAQ2M2b.jpg",
      "id_str" : "729316365199253508",
      "id" : 729316365199253508,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch8NXryUoAQ2M2b.jpg",
      "sizes" : [ {
        "h" : 698,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 698,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 698,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wqBg716OB4"
    } ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/EluhUFxxfq",
      "expanded_url" : "http:\/\/go.wh.gov\/SfVTCL",
      "display_url" : "go.wh.gov\/SfVTCL"
    } ]
  },
  "geo" : { },
  "id_str" : "729316513149157376",
  "text" : "\"No one deserves thanks more than our moms.\" Read @POTUS's message on #MothersDay: https:\/\/t.co\/EluhUFxxfq https:\/\/t.co\/wqBg716OB4",
  "id" : 729316513149157376,
  "created_at" : "2016-05-08 14:26:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Q3tuMIivJy",
      "expanded_url" : "http:\/\/snpy.tv\/1Xdt1GH",
      "display_url" : "snpy.tv\/1Xdt1GH"
    } ]
  },
  "geo" : { },
  "id_str" : "729297495323385856",
  "text" : "\u201CLet\u2019s give mothers the respect they deserve, give all women the equality they deserve\"\u2014@POTUS on #MothersDay https:\/\/t.co\/Q3tuMIivJy",
  "id" : 729297495323385856,
  "created_at" : "2016-05-08 13:10:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/0v2IMwJcio",
      "expanded_url" : "http:\/\/go.wh.gov\/Weekly",
      "display_url" : "go.wh.gov\/Weekly"
    } ]
  },
  "geo" : { },
  "id_str" : "729063288420454403",
  "text" : "\"I hope that on this Mother\u2019s Day, we\u2019ll recommit ourselves to doing more\"\u2014@POTUS ahead of #MothersDay https:\/\/t.co\/0v2IMwJcio",
  "id" : 729063288420454403,
  "created_at" : "2016-05-07 21:40:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Howard University",
      "screen_name" : "HowardU",
      "indices" : [ 43, 51 ],
      "id_str" : "27147528",
      "id" : 27147528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HowardU16",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/kS8pLimfRz",
      "expanded_url" : "http:\/\/snpy.tv\/1TuPbOA",
      "display_url" : "snpy.tv\/1TuPbOA"
    } ]
  },
  "geo" : { },
  "id_str" : "728996091950141440",
  "text" : "\"Yes We Can.\"\nWatch @POTUS's advice to the @HowardU Class of 2016. #HowardU16 https:\/\/t.co\/kS8pLimfRz",
  "id" : 728996091950141440,
  "created_at" : "2016-05-07 17:13:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Howard University",
      "screen_name" : "HowardU",
      "indices" : [ 54, 62 ],
      "id_str" : "27147528",
      "id" : 27147528
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728986507026022400\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/rlwyU3RxEh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch3hXPpUUAAvZFs.jpg",
      "id_str" : "728986504156958720",
      "id" : 728986504156958720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch3hXPpUUAAvZFs.jpg",
      "sizes" : [ {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 745,
        "resize" : "fit",
        "w" : 1440
      } ],
      "display_url" : "pic.twitter.com\/rlwyU3RxEh"
    } ],
    "hashtags" : [ {
      "text" : "HowardU16",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728986507026022400",
  "text" : "\"Yes We Can.\" \u2014@POTUS to the 2016 graduating class of @HowardU #HowardU16 https:\/\/t.co\/rlwyU3RxEh",
  "id" : 728986507026022400,
  "created_at" : "2016-05-07 16:35:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728984892034387968",
  "text" : "\"Change is the effort of committed citizens who hitch their wagons to something bigger than themselves, and fight for it every single day.\"",
  "id" : 728984892034387968,
  "created_at" : "2016-05-07 16:28:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Howard University",
      "screen_name" : "HowardU",
      "indices" : [ 3, 11 ],
      "id_str" : "27147528",
      "id" : 27147528
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HowardU16",
      "indices" : [ 114, 124 ]
    }, {
      "text" : "ObamaHU16",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728982774326104064",
  "text" : "RT @HowardU: \"You don't have to risk your life to cast a ballot; other people already did that for you.\" --@POTUS #HowardU16 #ObamaHU16",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 94, 100 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HowardU16",
        "indices" : [ 101, 111 ]
      }, {
        "text" : "ObamaHU16",
        "indices" : [ 112, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728982211916136449",
    "text" : "\"You don't have to risk your life to cast a ballot; other people already did that for you.\" --@POTUS #HowardU16 #ObamaHU16",
    "id" : 728982211916136449,
    "created_at" : "2016-05-07 16:17:57 +0000",
    "user" : {
      "name" : "Howard University",
      "screen_name" : "HowardU",
      "protected" : false,
      "id_str" : "27147528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744934705343102976\/S8BLLdP0_normal.jpg",
      "id" : 27147528,
      "verified" : true
    }
  },
  "id" : 728982774326104064,
  "created_at" : "2016-05-07 16:20:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728982559099629574",
  "text" : "\"That\u2019s how we change our politics: By electing people at every level who are representative of and accountable to us.\" \u2014@POTUS on voting",
  "id" : 728982559099629574,
  "created_at" : "2016-05-07 16:19:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728981715885162496\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/93hKwx2DMb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch3c-P-WMAAT3hF.jpg",
      "id_str" : "728981676701921280",
      "id" : 728981676701921280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch3c-P-WMAAT3hF.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/93hKwx2DMb"
    } ],
    "hashtags" : [ {
      "text" : "HowardU16",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728981715885162496",
  "text" : "\"50 years after the Voting Rights Act, there are still too many barriers to vote.\" \u2014@POTUS #HowardU16 https:\/\/t.co\/93hKwx2DMb",
  "id" : 728981715885162496,
  "created_at" : "2016-05-07 16:15:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HowardU16",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728980860054188032",
  "text" : "\"We must expand our moral imaginations to understand and empathize with all people who are struggling.\" \u2014@POTUS #HowardU16",
  "id" : 728980860054188032,
  "created_at" : "2016-05-07 16:12:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 138, 144 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728980417269878784",
  "text" : "\"Remember the tie that does bind us as African Americans: That is is our particular awareness of injustice, unfairness, &amp; struggle.\" \u2014@POTUS",
  "id" : 728980417269878784,
  "created_at" : "2016-05-07 16:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Af-Am Ed",
      "screen_name" : "AfAmEducation",
      "indices" : [ 3, 17 ],
      "id_str" : "1307544762",
      "id" : 1307544762
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AfAmEducation\/status\/728979347504246787\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/6ohgFYNYpN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch3a2QiW0AA68Q6.jpg",
      "id_str" : "728979340390748160",
      "id" : 728979340390748160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch3a2QiW0AA68Q6.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6ohgFYNYpN"
    } ],
    "hashtags" : [ {
      "text" : "HowardU16",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728979517419753472",
  "text" : "RT @AfAmEducation: \"Be confident in your heritage. Be confident in your Blackness.\" @POTUS #HowardU16 https:\/\/t.co\/6ohgFYNYpN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 65, 71 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AfAmEducation\/status\/728979347504246787\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/6ohgFYNYpN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch3a2QiW0AA68Q6.jpg",
        "id_str" : "728979340390748160",
        "id" : 728979340390748160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch3a2QiW0AA68Q6.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6ohgFYNYpN"
      } ],
      "hashtags" : [ {
        "text" : "HowardU16",
        "indices" : [ 72, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728979347504246787",
    "text" : "\"Be confident in your heritage. Be confident in your Blackness.\" @POTUS #HowardU16 https:\/\/t.co\/6ohgFYNYpN",
    "id" : 728979347504246787,
    "created_at" : "2016-05-07 16:06:34 +0000",
    "user" : {
      "name" : "White House Af-Am Ed",
      "screen_name" : "AfAmEducation",
      "protected" : false,
      "id_str" : "1307544762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000011763795\/f54a0a4f637a5c56ed25c2b71a865393_normal.jpeg",
      "id" : 1307544762,
      "verified" : true
    }
  },
  "id" : 728979517419753472,
  "created_at" : "2016-05-07 16:07:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HowardU16",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728979087323242497",
  "text" : "\"The truth is that your generation is better positioned than any before you to meet those challenges.\" \u2014@POTUS to the class of #HowardU16",
  "id" : 728979087323242497,
  "created_at" : "2016-05-07 16:05:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728978782128877569\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/8JJ5VtmsKW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch3aS5xWUAEnQKx.jpg",
      "id_str" : "728978732984193025",
      "id" : 728978732984193025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch3aS5xWUAEnQKx.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8JJ5VtmsKW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728978782128877569",
  "text" : "\"Too many black boys and girls pass through a pipeline from underfunded schools to overcrowded jails.\" \u2014@POTUS https:\/\/t.co\/8JJ5VtmsKW",
  "id" : 728978782128877569,
  "created_at" : "2016-05-07 16:04:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HowardU16",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728978368524365824",
  "text" : "\"There\u2019s still so much more work to do, so many more miles to travel, and America needs you to gladly take up that work.\" \u2014@POTUS #HowardU16",
  "id" : 728978368524365824,
  "created_at" : "2016-05-07 16:02:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 41, 47 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Howard University",
      "screen_name" : "HowardU",
      "indices" : [ 68, 76 ],
      "id_str" : "27147528",
      "id" : 27147528
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728974913810386944\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/rYiEnOBb6Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch3WSswWwAEP1hF.jpg",
      "id_str" : "728974331443855361",
      "id" : 728974331443855361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch3WSswWwAEP1hF.jpg",
      "sizes" : [ {
        "h" : 181,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1435
      }, {
        "h" : 319,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/rYiEnOBb6Z"
    } ],
    "hashtags" : [ {
      "text" : "HowardU16",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728974913810386944",
  "text" : "\"Congratulations to the Class of 2016!\" \u2014@POTUS to the graduates of @HowardU #HowardU16 https:\/\/t.co\/rYiEnOBb6Z",
  "id" : 728974913810386944,
  "created_at" : "2016-05-07 15:48:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Howard University",
      "screen_name" : "HowardU",
      "indices" : [ 54, 62 ],
      "id_str" : "27147528",
      "id" : 27147528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/yArc9fhnru",
      "expanded_url" : "http:\/\/go.wh.gov\/UPWtB7",
      "display_url" : "go.wh.gov\/UPWtB7"
    } ]
  },
  "geo" : { },
  "id_str" : "728956828780920833",
  "text" : "Watch @POTUS deliver the 2016 commencement address at @HowardU \u2192 https:\/\/t.co\/yArc9fhnru",
  "id" : 728956828780920833,
  "created_at" : "2016-05-07 14:37:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeacherAppreciationWeek",
      "indices" : [ 74, 98 ]
    }, {
      "text" : "ThankATeacher",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Hhb9QIiJ74",
      "expanded_url" : "http:\/\/snpy.tv\/1q4vm9k",
      "display_url" : "snpy.tv\/1q4vm9k"
    } ]
  },
  "geo" : { },
  "id_str" : "728725513158676480",
  "text" : "\"I was a pretty good teacher.\"\nWatch @POTUS meet the Teacher of the Year. #TeacherAppreciationWeek #ThankATeacher https:\/\/t.co\/Hhb9QIiJ74",
  "id" : 728725513158676480,
  "created_at" : "2016-05-06 23:17:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/QQFUQ4w3zh",
      "expanded_url" : "http:\/\/go.wh.gov\/AntiCorruption",
      "display_url" : "go.wh.gov\/AntiCorruption"
    } ]
  },
  "geo" : { },
  "id_str" : "728723042801623040",
  "text" : "If you've heard of the Panama Papers, you should see the steps @POTUS took today to combat financial corruption: https:\/\/t.co\/QQFUQ4w3zh",
  "id" : 728723042801623040,
  "created_at" : "2016-05-06 23:08:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/728708013649891328\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/x3J7CMj14d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChzkDNgUkAEwc14.jpg",
      "id_str" : "728707983543144449",
      "id" : 728707983543144449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChzkDNgUkAEwc14.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/x3J7CMj14d"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/QQFUQ4w3zh",
      "expanded_url" : "http:\/\/go.wh.gov\/AntiCorruption",
      "display_url" : "go.wh.gov\/AntiCorruption"
    } ]
  },
  "geo" : { },
  "id_str" : "728708013649891328",
  "text" : ".@POTUS took new steps today to boost financial transparency and fight financial crime. https:\/\/t.co\/QQFUQ4w3zh https:\/\/t.co\/x3J7CMj14d",
  "id" : 728708013649891328,
  "created_at" : "2016-05-06 22:08:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Bryan Cranston",
      "screen_name" : "BryanCranston",
      "indices" : [ 38, 52 ],
      "id_str" : "80096621",
      "id" : 80096621
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/728680757548322816\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/NvVWVo4Aee",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChzCdpnUkAA6Z-g.jpg",
      "id_str" : "728671054369951744",
      "id" : 728671054369951744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChzCdpnUkAA6Z-g.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/NvVWVo4Aee"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/tpcqbzH0kx",
      "expanded_url" : "http:\/\/nyti.ms\/1UE6thB",
      "display_url" : "nyti.ms\/1UE6thB"
    } ]
  },
  "geo" : { },
  "id_str" : "728680757548322816",
  "text" : "Read the interview between @POTUS and @BryanCranston on the power of good storytelling: https:\/\/t.co\/tpcqbzH0kx https:\/\/t.co\/NvVWVo4Aee",
  "id" : 728680757548322816,
  "created_at" : "2016-05-06 20:20:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728675835113132033\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/XUY4croFT6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChyZuVUUUAAoeFu.jpg",
      "id_str" : "728626261002571776",
      "id" : 728626261002571776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChyZuVUUUAAoeFu.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/XUY4croFT6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728675835113132033",
  "text" : "This is what progress looks like: \n14.6 million new jobs \u2713 \n74 straight months of private-sector job growth \u2713 https:\/\/t.co\/XUY4croFT6",
  "id" : 728675835113132033,
  "created_at" : "2016-05-06 20:00:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Bryan Cranston",
      "screen_name" : "BryanCranston",
      "indices" : [ 44, 58 ],
      "id_str" : "80096621",
      "id" : 80096621
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728670621463384064\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/XxS9iJzZyJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChzCC2LUkAAVVvp.jpg",
      "id_str" : "728670593885704192",
      "id" : 728670593885704192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChzCC2LUkAAVVvp.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/XxS9iJzZyJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/tpcqbzYBJ7",
      "expanded_url" : "http:\/\/nyti.ms\/1UE6thB",
      "display_url" : "nyti.ms\/1UE6thB"
    } ]
  },
  "geo" : { },
  "id_str" : "728670621463384064",
  "text" : "\"I live above the store\" \u2014@POTUS talks with @BryanCranston about family life: https:\/\/t.co\/tpcqbzYBJ7 https:\/\/t.co\/XxS9iJzZyJ",
  "id" : 728670621463384064,
  "created_at" : "2016-05-06 19:39:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 53, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728662584195350528",
  "text" : "RT @vj44: Hi everyone! Welcome to my office hours on #MothersDay. Mother's Day is a great occasion for us to thank our moms. https:\/\/t.co\/A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter QandA\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/728662300186578945\/video\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/AiVOuBturW",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/728662166312759296\/pu\/img\/Jw_nw50nT2lbWhA2.jpg",
        "id_str" : "728662166312759296",
        "id" : 728662166312759296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/728662166312759296\/pu\/img\/Jw_nw50nT2lbWhA2.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/AiVOuBturW"
      } ],
      "hashtags" : [ {
        "text" : "MothersDay",
        "indices" : [ 43, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728662300186578945",
    "text" : "Hi everyone! Welcome to my office hours on #MothersDay. Mother's Day is a great occasion for us to thank our moms. https:\/\/t.co\/AiVOuBturW",
    "id" : 728662300186578945,
    "created_at" : "2016-05-06 19:06:44 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 728662584195350528,
  "created_at" : "2016-05-06 19:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/SDCHW1gNVl",
      "expanded_url" : "http:\/\/go.wh.gov\/iXaxb3",
      "display_url" : "go.wh.gov\/iXaxb3"
    } ]
  },
  "geo" : { },
  "id_str" : "728650569661841408",
  "text" : "Ramona was sentenced to life in prison for a nonviolent offense. Now she's making the most of her second chance: https:\/\/t.co\/SDCHW1gNVl",
  "id" : 728650569661841408,
  "created_at" : "2016-05-06 18:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/DWFY8xgEZm",
      "expanded_url" : "http:\/\/go.wh.gov\/5AqSbg",
      "display_url" : "go.wh.gov\/5AqSbg"
    } ]
  },
  "geo" : { },
  "id_str" : "728647500161290240",
  "text" : "\"Everything is 3-D to me.\" Read this man's story of life outside prison after @POTUS commuted his life sentence: https:\/\/t.co\/DWFY8xgEZm",
  "id" : 728647500161290240,
  "created_at" : "2016-05-06 18:07:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/hlZI0T2HE2",
      "expanded_url" : "http:\/\/snpy.tv\/1q3QbSy",
      "display_url" : "snpy.tv\/1q3QbSy"
    } ]
  },
  "geo" : { },
  "id_str" : "728627933577814016",
  "text" : "\u201CThe economy has been growing, unemployment has been falling, and wages have been rising\u201D \u2014@POTUS https:\/\/t.co\/hlZI0T2HE2",
  "id" : 728627933577814016,
  "created_at" : "2016-05-06 16:50:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/vzff5yGpjT",
      "expanded_url" : "http:\/\/go.wh.gov\/yb6Qvo",
      "display_url" : "go.wh.gov\/yb6Qvo"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/dyT4hEa4LV",
      "expanded_url" : "http:\/\/snpy.tv\/1XcCTQS",
      "display_url" : "snpy.tv\/1XcCTQS"
    } ]
  },
  "geo" : { },
  "id_str" : "728624517078233089",
  "text" : ".@POTUS just took a series of steps to combat money laundering, corruption, and tax evasion: https:\/\/t.co\/vzff5yGpjT https:\/\/t.co\/dyT4hEa4LV",
  "id" : 728624517078233089,
  "created_at" : "2016-05-06 16:36:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/vzff5yGpjT",
      "expanded_url" : "http:\/\/go.wh.gov\/yb6Qvo",
      "display_url" : "go.wh.gov\/yb6Qvo"
    } ]
  },
  "geo" : { },
  "id_str" : "728622039930707968",
  "text" : "\u201CIn America, no matter how wealthy or powerful, you should play by the same rules as everybody else.\u201D \u2014@POTUS: https:\/\/t.co\/vzff5yGpjT",
  "id" : 728622039930707968,
  "created_at" : "2016-05-06 16:26:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728621240697692161\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/5YpwfkFw42",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChyVB9IUgAEa-MD.jpg",
      "id_str" : "728621100549046273",
      "id" : 728621100549046273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChyVB9IUgAEa-MD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/5YpwfkFw42"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728621240697692161",
  "text" : "\"We\u2019re plugging a gap in our tax rules that foreigners can exploit to hide their assets to evade taxes.\" \u2014@POTUS https:\/\/t.co\/5YpwfkFw42",
  "id" : 728621240697692161,
  "created_at" : "2016-05-06 16:23:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 138, 144 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728620993053380608",
  "text" : "\u201CWe\u2019re requiring banks and other financial institutions to know, verify, &amp; report who the real people are behind shell corporations\" \u2014@POTUS",
  "id" : 728620993053380608,
  "created_at" : "2016-05-06 16:22:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728620902536105995\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/etWBbYioVH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChyUwHeUYAQJAz-.jpg",
      "id_str" : "728620794088022020",
      "id" : 728620794088022020,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChyUwHeUYAQJAz-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/etWBbYioVH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728620902536105995",
  "text" : "\"Thousands of individuals have come forward to disclose offshore accounts and pay the taxes they owe\" \u2014@POTUS https:\/\/t.co\/etWBbYioVH",
  "id" : 728620902536105995,
  "created_at" : "2016-05-06 16:22:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728620716615184384\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/iyuC4rALnF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChyUplOUkAAnQX8.jpg",
      "id_str" : "728620681814904832",
      "id" : 728620681814904832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChyUplOUkAAnQX8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iyuC4rALnF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728620716615184384",
  "text" : "\"We\u2019ve taken several steps to make sure our tax laws are enforced\u201D \u2014@POTUS https:\/\/t.co\/iyuC4rALnF",
  "id" : 728620716615184384,
  "created_at" : "2016-05-06 16:21:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728619969181843456\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/z0TSj2PeSK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChyT1ScUUAAxvbx.jpg",
      "id_str" : "728619783420137472",
      "id" : 728619783420137472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChyT1ScUUAAxvbx.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/z0TSj2PeSK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728619969181843456",
  "text" : "\u201COver that record streak of job growth, our businesses have created 14.6 million new jobs in all.\u201D \u2014@POTUS https:\/\/t.co\/z0TSj2PeSK",
  "id" : 728619969181843456,
  "created_at" : "2016-05-06 16:18:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/728619468788748288\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/B64JACtOvj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChyTiwJVIAADSLX.jpg",
      "id_str" : "728619464976048128",
      "id" : 728619464976048128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChyTiwJVIAADSLX.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/B64JACtOvj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/vzff5yGpjT",
      "expanded_url" : "http:\/\/go.wh.gov\/yb6Qvo",
      "display_url" : "go.wh.gov\/yb6Qvo"
    } ]
  },
  "geo" : { },
  "id_str" : "728619468788748288",
  "text" : "Happening now: Watch @POTUS drop by the briefing room to talk about the economy: https:\/\/t.co\/vzff5yGpjT https:\/\/t.co\/B64JACtOvj",
  "id" : 728619468788748288,
  "created_at" : "2016-05-06 16:16:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728595496001011713\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/YwvIVGi0NF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chx9p-PU4AAcKBU.jpg",
      "id_str" : "728595399762567168",
      "id" : 728595399762567168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chx9p-PU4AAcKBU.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/YwvIVGi0NF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/4Vc0cDsSdZ",
      "expanded_url" : "http:\/\/go.wh.gov\/AprilJobs",
      "display_url" : "go.wh.gov\/AprilJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "728595496001011713",
  "text" : "FACT: American businesses have added 14.6 million jobs over 6 straight years of growth \u2192 https:\/\/t.co\/4Vc0cDsSdZ https:\/\/t.co\/YwvIVGi0NF",
  "id" : 728595496001011713,
  "created_at" : "2016-05-06 14:41:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728584843915857920\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/1985oSWvSV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChxzuHRUoAAN4R7.jpg",
      "id_str" : "728584475790057472",
      "id" : 728584475790057472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChxzuHRUoAAN4R7.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/1985oSWvSV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/4Vc0cDsSdZ",
      "expanded_url" : "http:\/\/go.wh.gov\/AprilJobs",
      "display_url" : "go.wh.gov\/AprilJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "728584843915857920",
  "text" : "Our businesses have added 14.6 million jobs over the past 6 years\u2014the longest streak ever \u2192 https:\/\/t.co\/4Vc0cDsSdZ https:\/\/t.co\/1985oSWvSV",
  "id" : 728584843915857920,
  "created_at" : "2016-05-06 13:58:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728574969526009856",
  "text" : "RT @vj44: This Sunday, we're celebrating moms across the country! Qs about the work we're doing to support moms? Ask by 3pm today using #Mo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MothersDay",
        "indices" : [ 126, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728567361284886529",
    "text" : "This Sunday, we're celebrating moms across the country! Qs about the work we're doing to support moms? Ask by 3pm today using #MothersDay",
    "id" : 728567361284886529,
    "created_at" : "2016-05-06 12:49:29 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 728574969526009856,
  "created_at" : "2016-05-06 13:19:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 36, 39 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 123, 133 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CincoDeMayo",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728396098553917442",
  "text" : "RT @lacasablanca: Today, @POTUS and @VP met young activist Sophie Cruz at the White House #CincoDeMayo reception. Photo by @petesouza. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 7, 13 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 18, 21 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "petesouza",
        "screen_name" : "petesouza",
        "indices" : [ 105, 115 ],
        "id_str" : "18215973",
        "id" : 18215973
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/728395178751500288\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/DOWbrsZ30M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChvHc7LXIAIEzmA.jpg",
        "id_str" : "728395064486076418",
        "id" : 728395064486076418,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChvHc7LXIAIEzmA.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1535,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1366
        } ],
        "display_url" : "pic.twitter.com\/DOWbrsZ30M"
      } ],
      "hashtags" : [ {
        "text" : "CincoDeMayo",
        "indices" : [ 72, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728395178751500288",
    "text" : "Today, @POTUS and @VP met young activist Sophie Cruz at the White House #CincoDeMayo reception. Photo by @petesouza. https:\/\/t.co\/DOWbrsZ30M",
    "id" : 728395178751500288,
    "created_at" : "2016-05-06 01:25:18 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 728396098553917442,
  "created_at" : "2016-05-06 01:28:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728392861276725248\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/ATi9PRh5Ge",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chu-S06XEAA_4h2.jpg",
      "id_str" : "728384995400814592",
      "id" : 728384995400814592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chu-S06XEAA_4h2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ATi9PRh5Ge"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728392861276725248",
  "text" : "FACT: @POTUS has commuted prison sentences for more people than the previous 6 presidents combined. https:\/\/t.co\/ATi9PRh5Ge",
  "id" : 728392861276725248,
  "created_at" : "2016-05-06 01:16:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "Man\u00E1",
      "screen_name" : "manaoficial",
      "indices" : [ 78, 90 ],
      "id_str" : "95715393",
      "id" : 95715393
    }, {
      "name" : "Alondra Santos",
      "screen_name" : "ImAlondraSantos",
      "indices" : [ 107, 123 ],
      "id_str" : "1684866108",
      "id" : 1684866108
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CincoDeMayo",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728387062701936640",
  "text" : "RT @lacasablanca: Today's #CincoDeMayo performers included Mexican rock icons @manaoficial and rising star @ImAlondraSantos. https:\/\/t.co\/v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Man\u00E1",
        "screen_name" : "manaoficial",
        "indices" : [ 60, 72 ],
        "id_str" : "95715393",
        "id" : 95715393
      }, {
        "name" : "Alondra Santos",
        "screen_name" : "ImAlondraSantos",
        "indices" : [ 89, 105 ],
        "id_str" : "1684866108",
        "id" : 1684866108
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/728344466516541441\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/vfkzMEWfcJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChuZXzWXAAAlKEX.jpg",
        "id_str" : "728344398950498304",
        "id" : 728344398950498304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChuZXzWXAAAlKEX.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vfkzMEWfcJ"
      } ],
      "hashtags" : [ {
        "text" : "CincoDeMayo",
        "indices" : [ 8, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728344466516541441",
    "text" : "Today's #CincoDeMayo performers included Mexican rock icons @manaoficial and rising star @ImAlondraSantos. https:\/\/t.co\/vfkzMEWfcJ",
    "id" : 728344466516541441,
    "created_at" : "2016-05-05 22:03:47 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 728387062701936640,
  "created_at" : "2016-05-06 00:53:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/Dl2oXBCOHj",
      "expanded_url" : "http:\/\/go.wh.gov\/Jdxxgd",
      "display_url" : "go.wh.gov\/Jdxxgd"
    }, {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/NGRVpOLBB0",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/beee7e6e-de8c-485c-85be-6087395462ec",
      "display_url" : "amp.twimg.com\/v\/beee7e6e-de8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728384542256582660",
  "text" : "Thanks to @POTUS, 58 men and women will get a second chance: https:\/\/t.co\/Dl2oXBCOHj\nhttps:\/\/t.co\/NGRVpOLBB0",
  "id" : 728384542256582660,
  "created_at" : "2016-05-06 00:43:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728352636555145216",
  "text" : "\"I challenge every American to keep asking that simple question: How can I give back to these troops &amp; families who have given me so much?\"",
  "id" : 728352636555145216,
  "created_at" : "2016-05-05 22:36:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HireAVet",
      "indices" : [ 31, 40 ]
    }, {
      "text" : "JoiningForces",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728352122463526912",
  "text" : "\"If you want a job done right, #HireAVet; hire a military spouse.\" \u2014@POTUS #JoiningForces",
  "id" : 728352122463526912,
  "created_at" : "2016-05-05 22:34:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 95, 102 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 104, 112 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 118, 132 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728351920218378240",
  "text" : "\"They wanted to channel what they knew was American\u2019s goodwill toward our military\" \u2014@POTUS on @FLOTUS, @DrBiden, and @JoiningForces",
  "id" : 728351920218378240,
  "created_at" : "2016-05-05 22:33:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 64, 70 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 107, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728351238157422592",
  "text" : "\"One of my greatest honors is to serve you and your families.\" \u2014@POTUS to our troops and military families #JoiningForces",
  "id" : 728351238157422592,
  "created_at" : "2016-05-05 22:30:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 14, 17 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 19, 26 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 32, 40 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 62, 76 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "USO",
      "screen_name" : "the_USO",
      "indices" : [ 93, 101 ],
      "id_str" : "36681590",
      "id" : 36681590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/ZcOsvbPEB9",
      "expanded_url" : "http:\/\/go.wh.gov\/3BB1Rw",
      "display_url" : "go.wh.gov\/3BB1Rw"
    } ]
  },
  "geo" : { },
  "id_str" : "728341950382809088",
  "text" : "Watch @POTUS, @VP, @FLOTUS, and @DrBiden celebrate 5 years of @JoiningForces and 75 years of @The_USO at 6pm ET: https:\/\/t.co\/ZcOsvbPEB9",
  "id" : 728341950382809088,
  "created_at" : "2016-05-05 21:53:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CincoDeMayo",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728318591691558913",
  "text" : "\"That\u2019s what makes strong communities. That's what makes a strong country. People working to push this country forward\" \u2014@POTUS #CincoDeMayo",
  "id" : 728318591691558913,
  "created_at" : "2016-05-05 20:20:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CincoDeMayo",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728317469652291585",
  "text" : "\"Together, we continue to fight to fix our broken immigration system.\" \u2014@POTUS #CincoDeMayo",
  "id" : 728317469652291585,
  "created_at" : "2016-05-05 20:16:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 36, 49 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 53, 59 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CincoDeMayo",
      "indices" : [ 8, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728316584847118337",
  "text" : "\"\u00A1Feliz #CincoDeMayo! Bienvenidos a @LaCasaBlanca.\" \u2014@POTUS",
  "id" : 728316584847118337,
  "created_at" : "2016-05-05 20:12:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728310964773326849\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/wmS5RxCM67",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cht6qb_WkAAzbTR.jpg",
      "id_str" : "728310634237038592",
      "id" : 728310634237038592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cht6qb_WkAAzbTR.jpg",
      "sizes" : [ {
        "h" : 1975,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 722,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wmS5RxCM67"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/Dl2oXBCOHj",
      "expanded_url" : "http:\/\/go.wh.gov\/Jdxxgd",
      "display_url" : "go.wh.gov\/Jdxxgd"
    } ]
  },
  "geo" : { },
  "id_str" : "728310964773326849",
  "text" : "Breaking: @POTUS just granted clemency to 58 men and women who have earned a second chance: https:\/\/t.co\/Dl2oXBCOHj https:\/\/t.co\/wmS5RxCM67",
  "id" : 728310964773326849,
  "created_at" : "2016-05-05 19:50:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CincoDeMayo",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/DOEt52F62N",
      "expanded_url" : "http:\/\/go.wh.gov\/CincoDeMayo",
      "display_url" : "go.wh.gov\/CincoDeMayo"
    } ]
  },
  "geo" : { },
  "id_str" : "728309388868526085",
  "text" : "\u00A1Feliz Cinco de Mayo! \nJoin @POTUS in celebrating #CincoDeMayo at the White House. Watch live at 4pm ET: https:\/\/t.co\/DOEt52F62N",
  "id" : 728309388868526085,
  "created_at" : "2016-05-05 19:44:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ATTN:",
      "screen_name" : "attn",
      "indices" : [ 3, 8 ],
      "id_str" : "214112621",
      "id" : 214112621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/2AeXs5gZFb",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/beee7e6e-de8c-485c-85be-6087395462ec",
      "display_url" : "amp.twimg.com\/v\/beee7e6e-de8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "728305380258893824",
  "text" : "RT @attn: It's time to stop locking up non-violent drug offenders for life.\nhttps:\/\/t.co\/2AeXs5gZFb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/2AeXs5gZFb",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/beee7e6e-de8c-485c-85be-6087395462ec",
        "display_url" : "amp.twimg.com\/v\/beee7e6e-de8\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "728299611551502336",
    "text" : "It's time to stop locking up non-violent drug offenders for life.\nhttps:\/\/t.co\/2AeXs5gZFb",
    "id" : 728299611551502336,
    "created_at" : "2016-05-05 19:05:33 +0000",
    "user" : {
      "name" : "ATTN:",
      "screen_name" : "attn",
      "protected" : false,
      "id_str" : "214112621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616387650560389120\/7dI5Ky0i_normal.jpg",
      "id" : 214112621,
      "verified" : true
    }
  },
  "id" : 728305380258893824,
  "created_at" : "2016-05-05 19:28:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 4, 9 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/kkMeAcjt2R",
      "expanded_url" : "http:\/\/go.wh.gov\/Rghz5t",
      "display_url" : "go.wh.gov\/Rghz5t"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/eLdA7PLYsC",
      "expanded_url" : "http:\/\/snpy.tv\/26XqCnL",
      "display_url" : "snpy.tv\/26XqCnL"
    } ]
  },
  "geo" : { },
  "id_str" : "728282227063185409",
  "text" : "The @CFPB wants to empower consumers to take big companies to court.\nHere's why it matters: https:\/\/t.co\/kkMeAcjt2R https:\/\/t.co\/eLdA7PLYsC",
  "id" : 728282227063185409,
  "created_at" : "2016-05-05 17:56:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728254967962816513",
  "text" : "RT @VP: A job is more than a paycheck. It's about dignity. If unfair agreements have affected you, I want to know about it: https:\/\/t.co\/Kp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/KppjsSVJd4",
        "expanded_url" : "http:\/\/go.wh.gov\/jxkpfc",
        "display_url" : "go.wh.gov\/jxkpfc"
      } ]
    },
    "geo" : { },
    "id_str" : "728245062572847104",
    "text" : "A job is more than a paycheck. It's about dignity. If unfair agreements have affected you, I want to know about it: https:\/\/t.co\/KppjsSVJd4",
    "id" : 728245062572847104,
    "created_at" : "2016-05-05 15:28:47 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 728254967962816513,
  "created_at" : "2016-05-05 16:08:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 64, 70 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/fKPGpHwvCa",
      "expanded_url" : "http:\/\/go.wh.gov\/ky2U3r",
      "display_url" : "go.wh.gov\/ky2U3r"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/5MoJ6we0s3",
      "expanded_url" : "http:\/\/snpy.tv\/1rtd16V",
      "display_url" : "snpy.tv\/1rtd16V"
    } ]
  },
  "geo" : { },
  "id_str" : "728248868333301760",
  "text" : "\"A young girl shouldn't have to go to Washington to be heard.\" \u2014@POTUS on 8-year-old Mari: https:\/\/t.co\/fKPGpHwvCa https:\/\/t.co\/5MoJ6we0s3",
  "id" : 728248868333301760,
  "created_at" : "2016-05-05 15:43:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MayThe4thBeWithYou",
      "indices" : [ 38, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/9g1JUHV1n5",
      "expanded_url" : "http:\/\/snpy.tv\/26V717K",
      "display_url" : "snpy.tv\/26V717K"
    } ]
  },
  "geo" : { },
  "id_str" : "728034033494417408",
  "text" : "Dance. Or dance not. There is no try. #MayThe4thBeWithYou https:\/\/t.co\/9g1JUHV1n5",
  "id" : 728034033494417408,
  "created_at" : "2016-05-05 01:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AAPI",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/DssyqTYxvI",
      "expanded_url" : "http:\/\/snpy.tv\/1SNMxYr",
      "display_url" : "snpy.tv\/1SNMxYr"
    } ]
  },
  "geo" : { },
  "id_str" : "728021418827358209",
  "text" : "\u201CWe were all strangers once until America welcomed us home.\u201D \u2014@POTUS to the #AAPI community https:\/\/t.co\/DssyqTYxvI",
  "id" : 728021418827358209,
  "created_at" : "2016-05-05 00:40:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AAPI",
      "indices" : [ 5, 10 ]
    }, {
      "text" : "APAICSgala",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/DjxA5NOprn",
      "expanded_url" : "http:\/\/snpy.tv\/1q1fdSh",
      "display_url" : "snpy.tv\/1q1fdSh"
    } ]
  },
  "geo" : { },
  "id_str" : "728017924754116614",
  "text" : "\"The #AAPI community, you\u2019re part of the lifeblood of this nation\" \u2014@POTUS at the #APAICSgala  https:\/\/t.co\/DjxA5NOprn",
  "id" : 728017924754116614,
  "created_at" : "2016-05-05 00:26:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AAPI",
      "indices" : [ 42, 47 ]
    }, {
      "text" : "APAICSgala",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/JZ3If6fYVx",
      "expanded_url" : "http:\/\/go.wh.gov\/AAPIMonth",
      "display_url" : "go.wh.gov\/AAPIMonth"
    } ]
  },
  "geo" : { },
  "id_str" : "728013687383044097",
  "text" : "At 8:25pm ET, @POTUS gives remarks to the #AAPI community. Watch live:  https:\/\/t.co\/JZ3If6fYVx #APAICSgala",
  "id" : 728013687383044097,
  "created_at" : "2016-05-05 00:09:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/728003365469184000\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/eUymMbONIJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChpjHkyWsAA6Elk.jpg",
      "id_str" : "728003271558868992",
      "id" : 728003271558868992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChpjHkyWsAA6Elk.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eUymMbONIJ"
    } ],
    "hashtags" : [ {
      "text" : "HolocaustRemembranceDay",
      "indices" : [ 42, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/JGOp6Hd9Ly",
      "expanded_url" : "http:\/\/go.wh.gov\/Engx58",
      "display_url" : "go.wh.gov\/Engx58"
    } ]
  },
  "geo" : { },
  "id_str" : "728003365469184000",
  "text" : "\"'Never forget. Never again.'\" \u2014@POTUS on #HolocaustRemembranceDay: https:\/\/t.co\/JGOp6Hd9Ly https:\/\/t.co\/eUymMbONIJ",
  "id" : 728003365469184000,
  "created_at" : "2016-05-04 23:28:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/727985641196294146\/photo\/1",
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/UNWs5yJN5E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChpSkomWwAAaiqI.jpg",
      "id_str" : "727985079100817408",
      "id" : 727985079100817408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChpSkomWwAAaiqI.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UNWs5yJN5E"
    } ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/y89tceYcFR",
      "expanded_url" : "http:\/\/go.wh.gov\/ZETRFd",
      "display_url" : "go.wh.gov\/ZETRFd"
    } ]
  },
  "geo" : { },
  "id_str" : "727985641196294146",
  "text" : "Here's how we're responding to the public health crisis in #Flint \u2192 https:\/\/t.co\/y89tceYcFR https:\/\/t.co\/UNWs5yJN5E",
  "id" : 727985641196294146,
  "created_at" : "2016-05-04 22:17:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/727973414540091392\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/vAWKsHDdKV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChpH9kiUoAETRqV.jpg",
      "id_str" : "727973412878983169",
      "id" : 727973412878983169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChpH9kiUoAETRqV.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vAWKsHDdKV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727981714170056705",
  "text" : "RT @vj44: .@POTUS with Little Miss Flint https:\/\/t.co\/vAWKsHDdKV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/727973414540091392\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/vAWKsHDdKV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChpH9kiUoAETRqV.jpg",
        "id_str" : "727973412878983169",
        "id" : 727973412878983169,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChpH9kiUoAETRqV.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 3024,
          "resize" : "fit",
          "w" : 4032
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vAWKsHDdKV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727973414540091392",
    "text" : ".@POTUS with Little Miss Flint https:\/\/t.co\/vAWKsHDdKV",
    "id" : 727973414540091392,
    "created_at" : "2016-05-04 21:29:21 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 727981714170056705,
  "created_at" : "2016-05-04 22:02:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/OcDywofkm0",
      "expanded_url" : "http:\/\/snpy.tv\/1X95XZK",
      "display_url" : "snpy.tv\/1X95XZK"
    } ]
  },
  "geo" : { },
  "id_str" : "727979989392449536",
  "text" : "\"This was a manmade disaster.\nThis was avoidable.\nThis was preventable.\"\n@POTUS to the #Flint community: https:\/\/t.co\/OcDywofkm0",
  "id" : 727979989392449536,
  "created_at" : "2016-05-04 21:55:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 40, 46 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 54, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/y89tceGBhh",
      "expanded_url" : "http:\/\/go.wh.gov\/ZETRFd",
      "display_url" : "go.wh.gov\/ZETRFd"
    }, {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/nRap0QvyPU",
      "expanded_url" : "http:\/\/snpy.tv\/26Uwa2f",
      "display_url" : "snpy.tv\/26Uwa2f"
    } ]
  },
  "geo" : { },
  "id_str" : "727978438368206848",
  "text" : "\"The American people care about Flint\" \u2014@POTUS to the #Flint community: https:\/\/t.co\/y89tceGBhh https:\/\/t.co\/nRap0QvyPU",
  "id" : 727978438368206848,
  "created_at" : "2016-05-04 21:49:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/AkHsQuT3pU",
      "expanded_url" : "http:\/\/snpy.tv\/1X953fN",
      "display_url" : "snpy.tv\/1X953fN"
    } ]
  },
  "geo" : { },
  "id_str" : "727974450650583040",
  "text" : "\"Flint's recovery is everybody's responsibility. And I'm going to make sure that responsibility is met.\" \u2014@POTUS https:\/\/t.co\/AkHsQuT3pU",
  "id" : 727974450650583040,
  "created_at" : "2016-05-04 21:33:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727961797836345345",
  "text" : "\"It\u2019s not enough just to fix the water. We've got to fix the mindset of neglect.\" \u2014@POTUS in #Flint",
  "id" : 727961797836345345,
  "created_at" : "2016-05-04 20:43:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727960153891307520",
  "text" : "\"Congress also needs to act in bipartisan fashion, do their job and make sure Flint has the necessary resources.\" \u2014@POTUS in #Flint",
  "id" : 727960153891307520,
  "created_at" : "2016-05-04 20:36:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 125, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727955953795108868",
  "text" : "\u201CFlint\u2019s recovery is everyone\u2019s responsibility. And I will do all I can to make sure that responsibility is met.\u201D \u2014@POTUS in #Flint",
  "id" : 727955953795108868,
  "created_at" : "2016-05-04 20:19:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/y89tceYcFR",
      "expanded_url" : "http:\/\/go.wh.gov\/ZETRFd",
      "display_url" : "go.wh.gov\/ZETRFd"
    } ]
  },
  "geo" : { },
  "id_str" : "727955307863916544",
  "text" : "\u201CI\u2019ve also come here to tell you that I\u2019ve got your back.\u201D \u2014@POTUS to the community members of #Flint: https:\/\/t.co\/y89tceYcFR",
  "id" : 727955307863916544,
  "created_at" : "2016-05-04 20:17:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727954920192774144",
  "text" : "\u201CThat\u2019s why I\u2019m here\u2026I want to hear directly from you about how this public health crisis has disrupted your lives.\u201D \u2014@POTUS in #Flint",
  "id" : 727954920192774144,
  "created_at" : "2016-05-04 20:15:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/NRFqmHgjfk",
      "expanded_url" : "http:\/\/go.wh.gov\/wEzsCU",
      "display_url" : "go.wh.gov\/wEzsCU"
    } ]
  },
  "geo" : { },
  "id_str" : "727954310005428224",
  "text" : "\"I received a letter from an eight-year-old girl named Mari Copeny.\u201D \u2014@POTUS in #Flint\n\nRead Mari\u2019s letter: https:\/\/t.co\/NRFqmHgjfk",
  "id" : 727954310005428224,
  "created_at" : "2016-05-04 20:13:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/y89tceGBhh",
      "expanded_url" : "http:\/\/go.wh.gov\/ZETRFd",
      "display_url" : "go.wh.gov\/ZETRFd"
    } ]
  },
  "geo" : { },
  "id_str" : "727949695054532609",
  "text" : "Today @POTUS is in #Flint.\nWatch him speak to community members at 4:00pm ET: https:\/\/t.co\/y89tceGBhh",
  "id" : 727949695054532609,
  "created_at" : "2016-05-04 19:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EPA\/status\/727943382002216965\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/vriW5hsim6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChonD2oW0AAU5IC.jpg",
      "id_str" : "727937236931629056",
      "id" : 727937236931629056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChonD2oW0AAU5IC.jpg",
      "sizes" : [ {
        "h" : 968,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 549,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 968,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 968,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vriW5hsim6"
    } ],
    "hashtags" : [ {
      "text" : "FlushForFlint",
      "indices" : [ 50, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727948524562862081",
  "text" : "RT @EPA: During May, Flint residents are asked to #FlushForFlint in 3 steps. https:\/\/t.co\/vriW5hsim6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EPA\/status\/727943382002216965\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/vriW5hsim6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChonD2oW0AAU5IC.jpg",
        "id_str" : "727937236931629056",
        "id" : 727937236931629056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChonD2oW0AAU5IC.jpg",
        "sizes" : [ {
          "h" : 968,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 549,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 968,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 968,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/vriW5hsim6"
      } ],
      "hashtags" : [ {
        "text" : "FlushForFlint",
        "indices" : [ 41, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727943382002216965",
    "text" : "During May, Flint residents are asked to #FlushForFlint in 3 steps. https:\/\/t.co\/vriW5hsim6",
    "id" : 727943382002216965,
    "created_at" : "2016-05-04 19:30:01 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 727948524562862081,
  "created_at" : "2016-05-04 19:50:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727945321226108931\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/Kj6xWM9OQT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChouHZhVAAAVgyL.jpg",
      "id_str" : "727944994418393088",
      "id" : 727944994418393088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChouHZhVAAAVgyL.jpg",
      "sizes" : [ {
        "h" : 456,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1073,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 805,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1073,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/Kj6xWM9OQT"
    } ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/NRFqmHgjfk",
      "expanded_url" : "http:\/\/go.wh.gov\/wEzsCU",
      "display_url" : "go.wh.gov\/wEzsCU"
    } ]
  },
  "geo" : { },
  "id_str" : "727945321226108931",
  "text" : "In March, 8-year-old Mari from #Flint wrote to @POTUS.\nToday, he's going to meet her: https:\/\/t.co\/NRFqmHgjfk https:\/\/t.co\/Kj6xWM9OQT",
  "id" : 727945321226108931,
  "created_at" : "2016-05-04 19:37:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 93, 100 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Cecilia44\/status\/727925280178741248\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/eyqFGOnrSq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChocLxBUoAA3KvM.jpg",
      "id_str" : "727925278236778496",
      "id" : 727925278236778496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChocLxBUoAA3KvM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 917,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2049,
        "resize" : "fit",
        "w" : 2287
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eyqFGOnrSq"
    } ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727929432925556736",
  "text" : "RT @Cecilia44: Thx to #Flint Head Start for upping crucial services for kids &amp; fams with @HHSGov funding. 2\/2 https:\/\/t.co\/eyqFGOnrSq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HHS.gov",
        "screen_name" : "HHSGov",
        "indices" : [ 78, 85 ],
        "id_str" : "44783853",
        "id" : 44783853
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Cecilia44\/status\/727925280178741248\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/eyqFGOnrSq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChocLxBUoAA3KvM.jpg",
        "id_str" : "727925278236778496",
        "id" : 727925278236778496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChocLxBUoAA3KvM.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 917,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2049,
          "resize" : "fit",
          "w" : 2287
        }, {
          "h" : 305,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/eyqFGOnrSq"
      } ],
      "hashtags" : [ {
        "text" : "Flint",
        "indices" : [ 7, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727925280178741248",
    "text" : "Thx to #Flint Head Start for upping crucial services for kids &amp; fams with @HHSGov funding. 2\/2 https:\/\/t.co\/eyqFGOnrSq",
    "id" : 727925280178741248,
    "created_at" : "2016-05-04 18:18:05 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 727929432925556736,
  "created_at" : "2016-05-04 18:34:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727910434037207040\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/apW8COb66e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChoOTNIUkAAqhc3.jpg",
      "id_str" : "727910012878622720",
      "id" : 727910012878622720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChoOTNIUkAAqhc3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/apW8COb66e"
    } ],
    "hashtags" : [ {
      "text" : "Flint",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/y89tceYcFR",
      "expanded_url" : "http:\/\/go.wh.gov\/ZETRFd",
      "display_url" : "go.wh.gov\/ZETRFd"
    } ]
  },
  "geo" : { },
  "id_str" : "727910434037207040",
  "text" : "Today @POTUS is in #Flint. Here's one way we're helping the city and its residents recover: https:\/\/t.co\/y89tceYcFR https:\/\/t.co\/apW8COb66e",
  "id" : 727910434037207040,
  "created_at" : "2016-05-04 17:19:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 75, 79 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/HDN5wPwXrg",
      "expanded_url" : "http:\/\/go.wh.gov\/xmmZyA",
      "display_url" : "go.wh.gov\/xmmZyA"
    } ]
  },
  "geo" : { },
  "id_str" : "727901757867692032",
  "text" : "\"Five generations of my family have called Flint, Michigan home.\" How this @EPA staffer is helping his hometown: https:\/\/t.co\/HDN5wPwXrg",
  "id" : 727901757867692032,
  "created_at" : "2016-05-04 16:44:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727898781434314752",
  "text" : "RT @Denis44: 44% of Americans know someone addicted 2 Rx painkillers. This is why we need Congress 2 pass the President's budget: https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/NfOqibSMw1",
        "expanded_url" : "http:\/\/kff.org\/report-section\/kaiser-health-tracking-poll-april-2016-substance-abuse-and-mental-health\/",
        "display_url" : "kff.org\/report-section\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "727891862384574464",
    "text" : "44% of Americans know someone addicted 2 Rx painkillers. This is why we need Congress 2 pass the President's budget: https:\/\/t.co\/NfOqibSMw1",
    "id" : 727891862384574464,
    "created_at" : "2016-05-04 16:05:18 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 727898781434314752,
  "created_at" : "2016-05-04 16:32:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AI",
      "indices" : [ 141, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/xMXZwHdrZh",
      "expanded_url" : "http:\/\/go.wh.gov\/MDNRuy",
      "display_url" : "go.wh.gov\/MDNRuy"
    } ]
  },
  "geo" : { },
  "id_str" : "727861269030559744",
  "text" : "We're announcing new steps to understand the benefits &amp; risks of artificial intelligence. Join the conversation: https:\/\/t.co\/xMXZwHdrZh #AI",
  "id" : 727861269030559744,
  "created_at" : "2016-05-04 14:03:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/washingtonpost\/status\/727230694691340289\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/SrRxHoiUWw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChekdoGUoAELOdy.jpg",
      "id_str" : "727230693730721793",
      "id" : 727230693730721793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChekdoGUoAELOdy.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/SrRxHoiUWw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/k9lB5D5zZH",
      "expanded_url" : "http:\/\/wapo.st\/1TreDF5",
      "display_url" : "wapo.st\/1TreDF5"
    } ]
  },
  "geo" : { },
  "id_str" : "727641435571298304",
  "text" : ".@POTUS outlines how his trade agreement will strengthen the U.S. economy and U.S. security: https:\/\/t.co\/k9lB5D5zZH https:\/\/t.co\/SrRxHoiUWw",
  "id" : 727641435571298304,
  "created_at" : "2016-05-03 23:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/OBdWap6oZZ",
      "expanded_url" : "http:\/\/snpy.tv\/1SKIz2L",
      "display_url" : "snpy.tv\/1SKIz2L"
    } ]
  },
  "geo" : { },
  "id_str" : "727637642251145218",
  "text" : "\"We\u2019ve taken the first steps towards making sure every young person in America gets the best start possible.\" \u2014POTUS https:\/\/t.co\/OBdWap6oZZ",
  "id" : 727637642251145218,
  "created_at" : "2016-05-03 23:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 64, 73 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727631181802557440\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/BzVHKcrPvW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChkQTBeWEAEFPmE.jpg",
      "id_str" : "727630733796315137",
      "id" : 727630733796315137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChkQTBeWEAEFPmE.jpg",
      "sizes" : [ {
        "h" : 686,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 686,
        "resize" : "fit",
        "w" : 406
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 686,
        "resize" : "fit",
        "w" : 406
      } ],
      "display_url" : "pic.twitter.com\/BzVHKcrPvW"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727631181802557440\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/BzVHKcrPvW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChkQVdPWkAETMOp.jpg",
      "id_str" : "727630775609364481",
      "id" : 727630775609364481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChkQVdPWkAETMOp.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/BzVHKcrPvW"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727631181802557440\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/BzVHKcrPvW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChkQYi4WwAAnlWb.jpg",
      "id_str" : "727630828663128064",
      "id" : 727630828663128064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChkQYi4WwAAnlWb.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/BzVHKcrPvW"
    } ],
    "hashtags" : [ {
      "text" : "TeachersAppreciationDay",
      "indices" : [ 18, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/GIuE47taVq",
      "expanded_url" : "https:\/\/www.snapchat.com\/add\/whitehouse",
      "display_url" : "snapchat.com\/add\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "727631181802557440",
  "text" : "We're celebrating #TeachersAppreciationDay! Add \"WhiteHouse\" on @Snapchat to learn more: https:\/\/t.co\/GIuE47taVq https:\/\/t.co\/BzVHKcrPvW",
  "id" : 727631181802557440,
  "created_at" : "2016-05-03 22:49:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/WDi8YhHn5d",
      "expanded_url" : "http:\/\/snpy.tv\/26QY1QX",
      "display_url" : "snpy.tv\/26QY1QX"
    } ]
  },
  "geo" : { },
  "id_str" : "727625893590532096",
  "text" : ".@POTUS's message to future generations of teachers: \"This is a dream job.\" https:\/\/t.co\/WDi8YhHn5d",
  "id" : 727625893590532096,
  "created_at" : "2016-05-03 22:28:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/dmrj3choCv",
      "expanded_url" : "http:\/\/snpy.tv\/1TJNU9i",
      "display_url" : "snpy.tv\/1TJNU9i"
    } ]
  },
  "geo" : { },
  "id_str" : "727625042280898560",
  "text" : "The educators who teach our nation's children fulfill the promise of a nation always looking forward. #ThankATeacher https:\/\/t.co\/dmrj3choCv",
  "id" : 727625042280898560,
  "created_at" : "2016-05-03 22:25:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeacherAppreciationDay",
      "indices" : [ 91, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/SgnqA5kQGO",
      "expanded_url" : "http:\/\/snpy.tv\/1pYNVMi",
      "display_url" : "snpy.tv\/1pYNVMi"
    } ]
  },
  "geo" : { },
  "id_str" : "727620437249789952",
  "text" : "RT if you agree: We all depend on teachers, and they deserve our appreciation and support. #TeacherAppreciationDay https:\/\/t.co\/SgnqA5kQGO",
  "id" : 727620437249789952,
  "created_at" : "2016-05-03 22:06:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeacherAppreciationDay",
      "indices" : [ 73, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/EwayRDUQmE",
      "expanded_url" : "http:\/\/snpy.tv\/1rk6ETl",
      "display_url" : "snpy.tv\/1rk6ETl"
    } ]
  },
  "geo" : { },
  "id_str" : "727616466128797696",
  "text" : "Watch 2016 National Teacher of the Year Jahana Hayes introduce @POTUS on #TeacherAppreciationDay. https:\/\/t.co\/EwayRDUQmE",
  "id" : 727616466128797696,
  "created_at" : "2016-05-03 21:50:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeacherAppreciationDay",
      "indices" : [ 81, 104 ]
    }, {
      "text" : "ThankATeacher",
      "indices" : [ 105, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727603127902470146",
  "text" : "\u201CI\u2019m so proud of all of you\u2026thank you for making our nation stronger.\u201D \u2014POTUS on #TeacherAppreciationDay #ThankATeacher",
  "id" : 727603127902470146,
  "created_at" : "2016-05-03 20:57:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727602241289474053",
  "text" : "\"We\u2019re starting to give educators like those behind me the flexibility to spend more time teaching creatively than testing.\" \u2014POTUS",
  "id" : 727602241289474053,
  "created_at" : "2016-05-03 20:54:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727601202536534016",
  "text" : "\"Today, 20 million more students and most of our school districts have fast broadband and wireless in the classroom.\" \u2014POTUS #ThankATeacher",
  "id" : 727601202536534016,
  "created_at" : "2016-05-03 20:50:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727600998622048257\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/BzG7Em0WTH",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Chj1Kl8UoAA-MYW.jpg",
      "id_str" : "727600902152953856",
      "id" : 727600902152953856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Chj1Kl8UoAA-MYW.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BzG7Em0WTH"
    } ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727600998622048257",
  "text" : "\"Today, high school graduation rates have never been higher, dropout rates have dropped\" \u2014POTUS #ThankATeacher https:\/\/t.co\/BzG7Em0WTH",
  "id" : 727600998622048257,
  "created_at" : "2016-05-03 20:49:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 129, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727599058982993921",
  "text" : "\"In their daily lives, the men &amp; women who teach our children fulfill the promise of a nation always looking forward\" \u2014POTUS #ThankATeacher",
  "id" : 727599058982993921,
  "created_at" : "2016-05-03 20:41:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727598409276854273",
  "text" : "\"We say publicly as a country what we should be just as eager to say every day of the year, and that is thank you.\" \u2014POTUS #ThankATeacher",
  "id" : 727598409276854273,
  "created_at" : "2016-05-03 20:39:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/727597693409873920\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/mKyl50ffS4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chjx9RQVEAAs-Gr.jpg",
      "id_str" : "727597374726541312",
      "id" : 727597374726541312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chjx9RQVEAAs-Gr.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 4928
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mKyl50ffS4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/ezVzVMZH6A",
      "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
      "display_url" : "go.wh.gov\/ThankATeacher"
    } ]
  },
  "geo" : { },
  "id_str" : "727597693409873920",
  "text" : "\"That's what teaching is about: the passion, commitment\" \u2014Teacher of the Year Jahana Hayes: https:\/\/t.co\/ezVzVMZH6A https:\/\/t.co\/mKyl50ffS4",
  "id" : 727597693409873920,
  "created_at" : "2016-05-03 20:36:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 96, 110 ]
    }, {
      "text" : "TeacherAppreciationDay",
      "indices" : [ 111, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/o6PuzWJYeq",
      "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
      "display_url" : "go.wh.gov\/ThankATeacher"
    } ]
  },
  "geo" : { },
  "id_str" : "727596741701324800",
  "text" : "RT @WHLive: Happening now: @POTUS honors the 2016 Teacher of the Year \u2192 https:\/\/t.co\/o6PuzWJYeq #ThankATeacher #TeacherAppreciationDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 84, 98 ]
      }, {
        "text" : "TeacherAppreciationDay",
        "indices" : [ 99, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/o6PuzWJYeq",
        "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
        "display_url" : "go.wh.gov\/ThankATeacher"
      } ]
    },
    "geo" : { },
    "id_str" : "727596627930828800",
    "text" : "Happening now: @POTUS honors the 2016 Teacher of the Year \u2192 https:\/\/t.co\/o6PuzWJYeq #ThankATeacher #TeacherAppreciationDay",
    "id" : 727596627930828800,
    "created_at" : "2016-05-03 20:32:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 727596741701324800,
  "created_at" : "2016-05-03 20:32:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727593598426828800\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/NGOGG0pbXk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chjs8AJXIAANbR_.jpg",
      "id_str" : "727591855395905536",
      "id" : 727591855395905536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chjs8AJXIAANbR_.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 860
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 860
      } ],
      "display_url" : "pic.twitter.com\/NGOGG0pbXk"
    } ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/ezVzVMI5I0",
      "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
      "display_url" : "go.wh.gov\/ThankATeacher"
    } ]
  },
  "geo" : { },
  "id_str" : "727593598426828800",
  "text" : "At 4:30pm ET, watch @POTUS honor the 2016 National Teacher of the Year \u2192 https:\/\/t.co\/ezVzVMI5I0 #ThankATeacher https:\/\/t.co\/NGOGG0pbXk",
  "id" : 727593598426828800,
  "created_at" : "2016-05-03 20:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727586899049762816\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Wpuuz3O2Ov",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChjoXZbWkAAgZEU.jpg",
      "id_str" : "727586828480581632",
      "id" : 727586828480581632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChjoXZbWkAAgZEU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Wpuuz3O2Ov"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727586899049762816",
  "text" : ".@POTUS's bold vision for improving our education system will help give all students the fair chance they deserve. https:\/\/t.co\/Wpuuz3O2Ov",
  "id" : 727586899049762816,
  "created_at" : "2016-05-03 19:53:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727582533211295744\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/1JHikUhxzM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChjkARmW0AEumyl.jpg",
      "id_str" : "727582033195749377",
      "id" : 727582033195749377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChjkARmW0AEumyl.jpg",
      "sizes" : [ {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 4928
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1JHikUhxzM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ezVzVMZH6A",
      "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
      "display_url" : "go.wh.gov\/ThankATeacher"
    } ]
  },
  "geo" : { },
  "id_str" : "727582533211295744",
  "text" : "Teacher of the Year Jahana Hayes on how the support of good teachers changed her life: https:\/\/t.co\/ezVzVMZH6A https:\/\/t.co\/1JHikUhxzM",
  "id" : 727582533211295744,
  "created_at" : "2016-05-03 19:36:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727574913280819200\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/lISqhFUdK8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChjdPaAVEAA7bdN.jpg",
      "id_str" : "727574596568813568",
      "id" : 727574596568813568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChjdPaAVEAA7bdN.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      } ],
      "display_url" : "pic.twitter.com\/lISqhFUdK8"
    } ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/ezVzVMZH6A",
      "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
      "display_url" : "go.wh.gov\/ThankATeacher"
    } ]
  },
  "geo" : { },
  "id_str" : "727574913280819200",
  "text" : "Love teachers? Share how a teacher made a difference in your life using #ThankATeacher \u2192 https:\/\/t.co\/ezVzVMZH6A https:\/\/t.co\/lISqhFUdK8",
  "id" : 727574913280819200,
  "created_at" : "2016-05-03 19:05:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankaTeacher",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727564024628453377",
  "text" : "RT @Cecilia44: Thanks to Mr. Everson, my HS choir director who gave me &amp; so many other students a voice to sing. #ThankaTeacher https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Cecilia44\/status\/727549993423245312\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/wmYBau9b5c",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChjG3SCW4AAQs8Y.jpg",
        "id_str" : "727549992857165824",
        "id" : 727549992857165824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChjG3SCW4AAQs8Y.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/wmYBau9b5c"
      } ],
      "hashtags" : [ {
        "text" : "ThankaTeacher",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727549993423245312",
    "text" : "Thanks to Mr. Everson, my HS choir director who gave me &amp; so many other students a voice to sing. #ThankaTeacher https:\/\/t.co\/wmYBau9b5c",
    "id" : 727549993423245312,
    "created_at" : "2016-05-03 17:26:50 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 727564024628453377,
  "created_at" : "2016-05-03 18:22:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727562251721269248",
  "text" : "RT @POTUS: To my 5th grade teacher Ms. Mabel Hefty and the educators who inspire our young people every single day: Thank you. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PunahouSchool\/status\/593489304770498561\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/fz2ij8daBg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDx_YBKWYAA7d3o.png",
        "id_str" : "593489301511495680",
        "id" : 593489301511495680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDx_YBKWYAA7d3o.png",
        "sizes" : [ {
          "h" : 217,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1108,
          "resize" : "fit",
          "w" : 1738
        }, {
          "h" : 653,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/fz2ij8daBg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727561463993270272",
    "text" : "To my 5th grade teacher Ms. Mabel Hefty and the educators who inspire our young people every single day: Thank you. https:\/\/t.co\/fz2ij8daBg",
    "id" : 727561463993270272,
    "created_at" : "2016-05-03 18:12:25 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 727562251721269248,
  "created_at" : "2016-05-03 18:15:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 63, 77 ]
    }, {
      "text" : "WhyITeach",
      "indices" : [ 78, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/JoARW6V493",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/2743a34a-2bc4-4332-b570-4aaefaf3512e",
      "display_url" : "amp.twimg.com\/v\/2743a34a-2bc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727525920358174720",
  "text" : "RT @usedgov: Tell us about the teacher that changed your life. #ThankATeacher #WhyITeach\nhttps:\/\/t.co\/JoARW6V493",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 50, 64 ]
      }, {
        "text" : "WhyITeach",
        "indices" : [ 65, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/JoARW6V493",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/2743a34a-2bc4-4332-b570-4aaefaf3512e",
        "display_url" : "amp.twimg.com\/v\/2743a34a-2bc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "727259051021619200",
    "text" : "Tell us about the teacher that changed your life. #ThankATeacher #WhyITeach\nhttps:\/\/t.co\/JoARW6V493",
    "id" : 727259051021619200,
    "created_at" : "2016-05-02 22:10:44 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 727525920358174720,
  "created_at" : "2016-05-03 15:51:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/6M8Fjbu22b",
      "expanded_url" : "http:\/\/cnn.it\/1rejouF",
      "display_url" : "cnn.it\/1rejouF"
    } ]
  },
  "geo" : { },
  "id_str" : "727260422743674881",
  "text" : "\"This was going to be our best chance to get bin Laden\" @POTUS reflects on the decision he made five years ago: https:\/\/t.co\/6M8Fjbu22b",
  "id" : 727260422743674881,
  "created_at" : "2016-05-02 22:16:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 3, 18 ],
      "id_str" : "2467791",
      "id" : 2467791
    }, {
      "name" : "Post Opinions",
      "screen_name" : "PostOpinions",
      "indices" : [ 122, 135 ],
      "id_str" : "14345812",
      "id" : 14345812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/VVusfQTLfK",
      "expanded_url" : "http:\/\/wapo.st\/1TreDF5",
      "display_url" : "wapo.st\/1TreDF5"
    } ]
  },
  "geo" : { },
  "id_str" : "727254540890808325",
  "text" : "RT @washingtonpost: Obama: The TPP would let America, not China, lead the way on global trade https:\/\/t.co\/VVusfQTLfK via @PostOpinions htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Post Opinions",
        "screen_name" : "PostOpinions",
        "indices" : [ 102, 115 ],
        "id_str" : "14345812",
        "id" : 14345812
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/washingtonpost\/status\/727230694691340289\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/40zN4HOOkz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChekdoGUoAELOdy.jpg",
        "id_str" : "727230693730721793",
        "id" : 727230693730721793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChekdoGUoAELOdy.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/40zN4HOOkz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/VVusfQTLfK",
        "expanded_url" : "http:\/\/wapo.st\/1TreDF5",
        "display_url" : "wapo.st\/1TreDF5"
      } ]
    },
    "geo" : { },
    "id_str" : "727230694691340289",
    "text" : "Obama: The TPP would let America, not China, lead the way on global trade https:\/\/t.co\/VVusfQTLfK via @PostOpinions https:\/\/t.co\/40zN4HOOkz",
    "id" : 727230694691340289,
    "created_at" : "2016-05-02 20:18:03 +0000",
    "user" : {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "protected" : false,
      "id_str" : "2467791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753656134565785600\/iQ1GX-ov_normal.jpg",
      "id" : 2467791,
      "verified" : true
    }
  },
  "id" : 727254540890808325,
  "created_at" : "2016-05-02 21:52:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Kirk",
      "screen_name" : "SenatorKirk",
      "indices" : [ 3, 15 ],
      "id_str" : "211588974",
      "id" : 211588974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727249855467409408",
  "text" : "RT @SenatorKirk: As a rational, independent voice in the Senate I urge my colleagues to give Judge Garland a fair hearing and a vote. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/lkWQ78sQlp",
        "expanded_url" : "http:\/\/cnn.it\/26LccXL",
        "display_url" : "cnn.it\/26LccXL"
      } ]
    },
    "geo" : { },
    "id_str" : "727248851464163328",
    "text" : "As a rational, independent voice in the Senate I urge my colleagues to give Judge Garland a fair hearing and a vote. https:\/\/t.co\/lkWQ78sQlp",
    "id" : 727248851464163328,
    "created_at" : "2016-05-02 21:30:12 +0000",
    "user" : {
      "name" : "Mark Kirk",
      "screen_name" : "SenatorKirk",
      "protected" : false,
      "id_str" : "211588974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1196593136\/Mark_Kirk_Official_Portrait_social_-_twitter_normal.jpg",
      "id" : 211588974,
      "verified" : true
    }
  },
  "id" : 727249855467409408,
  "created_at" : "2016-05-02 21:34:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727246720548110338\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/EIsYq6YLsh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chey4wLWMAIa4Od.jpg",
      "id_str" : "727246552918536194",
      "id" : 727246552918536194,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chey4wLWMAIa4Od.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EIsYq6YLsh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/El0biJ4hAN",
      "expanded_url" : "http:\/\/go.wh.gov\/9Ka3vi",
      "display_url" : "go.wh.gov\/9Ka3vi"
    } ]
  },
  "geo" : { },
  "id_str" : "727246720548110338",
  "text" : "Here's what happened five years ago during the mission that killed Usama bin Laden \u2192 https:\/\/t.co\/El0biJ4hAN https:\/\/t.co\/EIsYq6YLsh",
  "id" : 727246720548110338,
  "created_at" : "2016-05-02 21:21:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 54, 68 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/MvBpBAn9hq",
      "expanded_url" : "http:\/\/go.wh.gov\/JFStories",
      "display_url" : "go.wh.gov\/JFStories"
    } ]
  },
  "geo" : { },
  "id_str" : "727236084644515840",
  "text" : "RT @FLOTUS: Today, we kick off the 5th anniversary of @JoiningForces! Follow along as we celebrate: https:\/\/t.co\/MvBpBAn9hq \uD83C\uDDFA\uD83C\uDDF8 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 42, 56 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/727235978440654856\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/oZSKWtxqhh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ChepGbjW0AUXEex.jpg",
        "id_str" : "727235792783986693",
        "id" : 727235792783986693,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChepGbjW0AUXEex.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1362,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/oZSKWtxqhh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/MvBpBAn9hq",
        "expanded_url" : "http:\/\/go.wh.gov\/JFStories",
        "display_url" : "go.wh.gov\/JFStories"
      } ]
    },
    "geo" : { },
    "id_str" : "727235978440654856",
    "text" : "Today, we kick off the 5th anniversary of @JoiningForces! Follow along as we celebrate: https:\/\/t.co\/MvBpBAn9hq \uD83C\uDDFA\uD83C\uDDF8 https:\/\/t.co\/oZSKWtxqhh",
    "id" : 727235978440654856,
    "created_at" : "2016-05-02 20:39:03 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 727236084644515840,
  "created_at" : "2016-05-02 20:39:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727226245486780416\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/55SjdV0orT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChegSvgUgAE5cEt.jpg",
      "id_str" : "727226108693741569",
      "id" : 727226108693741569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChegSvgUgAE5cEt.jpg",
      "sizes" : [ {
        "h" : 396,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 676,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 990,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/55SjdV0orT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/El0biJlSsl",
      "expanded_url" : "http:\/\/go.wh.gov\/9Ka3vi",
      "display_url" : "go.wh.gov\/9Ka3vi"
    } ]
  },
  "geo" : { },
  "id_str" : "727226245486780416",
  "text" : "Staff in the room with @POTUS recount the mission that led to the death of Usama bin Laden: https:\/\/t.co\/El0biJlSsl https:\/\/t.co\/55SjdV0orT",
  "id" : 727226245486780416,
  "created_at" : "2016-05-02 20:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/727214879682097152\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/nrwRNBmRBC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CheSIxTWMAAvipl.jpg",
      "id_str" : "727210544214716416",
      "id" : 727210544214716416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CheSIxTWMAAvipl.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nrwRNBmRBC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/El0biJlSsl",
      "expanded_url" : "http:\/\/go.wh.gov\/9Ka3vi",
      "display_url" : "go.wh.gov\/9Ka3vi"
    } ]
  },
  "geo" : { },
  "id_str" : "727214879682097152",
  "text" : "5 years later, look inside the Usama bin Laden raid from @POTUS\u2019s national security team: https:\/\/t.co\/El0biJlSsl https:\/\/t.co\/nrwRNBmRBC",
  "id" : 727214879682097152,
  "created_at" : "2016-05-02 19:15:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/727209849084321793\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/NP7cEoYHv7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CheRbjbWYAIaqJD.jpg",
      "id_str" : "727209767396073474",
      "id" : 727209767396073474,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CheRbjbWYAIaqJD.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 860
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 860
      } ],
      "display_url" : "pic.twitter.com\/NP7cEoYHv7"
    } ],
    "hashtags" : [ {
      "text" : "TeacherAppreciationWeek",
      "indices" : [ 5, 29 ]
    }, {
      "text" : "ThankATeacher",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727209849084321793",
  "text" : "It's #TeacherAppreciationWeek! Join us in celebrating all the hard-working teachers in our lives. #ThankATeacher https:\/\/t.co\/NP7cEoYHv7",
  "id" : 727209849084321793,
  "created_at" : "2016-05-02 18:55:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/HzpFlt8wfc",
      "expanded_url" : "https:\/\/goo.gl\/eRZ15P",
      "display_url" : "goo.gl\/eRZ15P"
    } ]
  },
  "geo" : { },
  "id_str" : "727143233613090817",
  "text" : "RT @DrBiden: It\u2019s Teacher Appreciation Week! I\u2019m dedicating a song to my favorite teacher\u2192 https:\/\/t.co\/HzpFlt8wfc #ThankATeacher\nhttps:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/HzpFlt8wfc",
        "expanded_url" : "https:\/\/goo.gl\/eRZ15P",
        "display_url" : "goo.gl\/eRZ15P"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/xx7zDt6Qma",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/14a76de9-c5ed-48e7-9275-eb9809dbf3ff",
        "display_url" : "amp.twimg.com\/v\/14a76de9-c5e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "727136244103151616",
    "text" : "It\u2019s Teacher Appreciation Week! I\u2019m dedicating a song to my favorite teacher\u2192 https:\/\/t.co\/HzpFlt8wfc #ThankATeacher\nhttps:\/\/t.co\/xx7zDt6Qma",
    "id" : 727136244103151616,
    "created_at" : "2016-05-02 14:02:44 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 727143233613090817,
  "created_at" : "2016-05-02 14:30:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 90, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726908436982566912",
  "text" : "RT @SCOTUSnom: \"Judge Merrick Garland has more federal judicial experience than any other #SCOTUS nominee in history.\" \u2014@POTUS: https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 105, 111 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 75, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/oYLvrNLFRA",
        "expanded_url" : "http:\/\/snpy.tv\/1O1uKr3",
        "display_url" : "snpy.tv\/1O1uKr3"
      } ]
    },
    "geo" : { },
    "id_str" : "726856290811572224",
    "text" : "\"Judge Merrick Garland has more federal judicial experience than any other #SCOTUS nominee in history.\" \u2014@POTUS: https:\/\/t.co\/oYLvrNLFRA",
    "id" : 726856290811572224,
    "created_at" : "2016-05-01 19:30:18 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 726908436982566912,
  "created_at" : "2016-05-01 22:57:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/IddjwWeL0z",
      "expanded_url" : "http:\/\/snpy.tv\/1O1uKr3",
      "display_url" : "snpy.tv\/1O1uKr3"
    } ]
  },
  "geo" : { },
  "id_str" : "726849789778923520",
  "text" : "\u201CIt\u2019s about upholding the institutions that make our democracy work.\" \u2014@POTUS on filling the open #SCOTUS seat: https:\/\/t.co\/IddjwWeL0z",
  "id" : 726849789778923520,
  "created_at" : "2016-05-01 19:04:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PetPreparedness",
      "indices" : [ 84, 100 ]
    }, {
      "text" : "PrepareAthon",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/hLdg3nbmU3",
      "expanded_url" : "http:\/\/snpy.tv\/1r3GO65",
      "display_url" : "snpy.tv\/1r3GO65"
    } ]
  },
  "geo" : { },
  "id_str" : "726824809233928192",
  "text" : "Bo &amp; Sunny are ready for anything. Is your family pet prepared for emergencies? #PetPreparedness #PrepareAthon https:\/\/t.co\/hLdg3nbmU3",
  "id" : 726824809233928192,
  "created_at" : "2016-05-01 17:25:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/IddjwVX9BZ",
      "expanded_url" : "http:\/\/snpy.tv\/1O1uKr3",
      "display_url" : "snpy.tv\/1O1uKr3"
    } ]
  },
  "geo" : { },
  "id_str" : "726810976922689536",
  "text" : "\"Give Judge Garland an up-or-down vote. Treat him\u2014and our democracy\u2014with the respect they deserve.\u201D \u2014@POTUS #SCOTUS https:\/\/t.co\/IddjwVX9BZ",
  "id" : 726810976922689536,
  "created_at" : "2016-05-01 16:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/p1xFpHJten",
      "expanded_url" : "http:\/\/snpy.tv\/1X0D9Co",
      "display_url" : "snpy.tv\/1X0D9Co"
    } ]
  },
  "geo" : { },
  "id_str" : "726788411139325953",
  "text" : "ICYMI: @POTUS shares an inside look into his preparations for life after the Presidency. #WHCD https:\/\/t.co\/p1xFpHJten",
  "id" : 726788411139325953,
  "created_at" : "2016-05-01 15:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]