Grailbird.data.tweets_2014_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/539103752565694465\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/5eOFLNdFrX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3tHskFCUAAfu39.jpg",
      "id_str" : "539103411325521920",
      "id" : 539103411325521920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3tHskFCUAAfu39.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/5eOFLNdFrX"
    } ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 95, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/O025qS2F3O",
      "expanded_url" : "http:\/\/go.wh.gov\/NTCzMZ",
      "display_url" : "go.wh.gov\/NTCzMZ"
    } ]
  },
  "geo" : { },
  "id_str" : "539103752565694465",
  "text" : "\"Thanks to Stevie, all of us have been moved to higher ground.\" \u2014Obama: http:\/\/t.co\/O025qS2F3O #MedalOfFreedom http:\/\/t.co\/5eOFLNdFrX",
  "id" : 539103752565694465,
  "created_at" : "2014-11-30 17:08:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/538871054978916354\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ByAzvRlTDr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3pzlGdCMAENuP0.jpg",
      "id_str" : "538870186648940545",
      "id" : 538870186648940545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3pzlGdCMAENuP0.jpg",
      "sizes" : [ {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1311
      }, {
        "h" : 686,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1172,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ByAzvRlTDr"
    } ],
    "hashtags" : [ {
      "text" : "SmallBusinessSaturday",
      "indices" : [ 80, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538871054978916354",
  "text" : "\u201CSmall businesses are the cornerstones of our communities.\u201D \u2014President Obama on #SmallBusinessSaturday http:\/\/t.co\/ByAzvRlTDr",
  "id" : 538871054978916354,
  "created_at" : "2014-11-30 01:44:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538814728093450240",
  "text" : "\u201CWe rededicate ourselves to ensuring ours is a country where small businesses can thrive.\u201D \u2014President Obama on #SmallBizSat",
  "id" : 538814728093450240,
  "created_at" : "2014-11-29 22:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "SmallBizSat",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/W7ykbgS912",
      "expanded_url" : "http:\/\/youtu.be\/A5Kp_Uwbopw",
      "display_url" : "youtu.be\/A5Kp_Uwbopw"
    } ]
  },
  "geo" : { },
  "id_str" : "538799641500729345",
  "text" : "The Affordable Care Act is helping entrepreneurs #GetCovered and pursue their dreams \u2192 http:\/\/t.co\/W7ykbgS912 #SmallBizSat",
  "id" : 538799641500729345,
  "created_at" : "2014-11-29 21:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tour du lich Da Lat",
      "screen_name" : "Politics_Prose",
      "indices" : [ 25, 40 ],
      "id_str" : "3390044115",
      "id" : 3390044115
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/538788503903928320\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/sQjr1fHB9V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3oo4v4CQAAj03J.jpg",
      "id_str" : "538788060813475840",
      "id" : 538788060813475840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3oo4v4CQAAj03J.jpg",
      "sizes" : [ {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1311
      }, {
        "h" : 686,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1172,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 389,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sQjr1fHB9V"
    } ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538788503903928320",
  "text" : "The Obamas shop small at @Politics_Prose, a local bookstore, on Small Business Saturday. #SmallBizSat http:\/\/t.co\/sQjr1fHB9V",
  "id" : 538788503903928320,
  "created_at" : "2014-11-29 20:16:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538773854165155840",
  "text" : "RT @arneduncan: Supported fantastic small biz today! Did my dry cleaning at Hi-Hat Cleaners and got a haircut at the Lyon Village barbersho\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538773214545993728",
    "text" : "Supported fantastic small biz today! Did my dry cleaning at Hi-Hat Cleaners and got a haircut at the Lyon Village barbershop. #SmallBizSat",
    "id" : 538773214545993728,
    "created_at" : "2014-11-29 19:15:18 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 538773854165155840,
  "created_at" : "2014-11-29 19:17:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBusinessSaturday",
      "indices" : [ 12, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538769453027061761",
  "text" : "\u201CAs we mark #SmallBusinessSaturday, let us continue to encourage the entrepreneurial spirit wherever we find it.\u201D \u2014President Obama",
  "id" : 538769453027061761,
  "created_at" : "2014-11-29 19:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538765810135990274",
  "text" : "RT @LaborSec: There are many small businesses that invest in their workers and their community - don't forget to visit one today on #SmallB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 118, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538722318504431618",
    "text" : "There are many small businesses that invest in their workers and their community - don't forget to visit one today on #SmallBizSat.",
    "id" : 538722318504431618,
    "created_at" : "2014-11-29 15:53:04 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 538765810135990274,
  "created_at" : "2014-11-29 18:45:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 24, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538761234754326528",
  "text" : "RT @vj44: Spending this #SmallBizSat in Hyde Park, visiting local small businesses in the neighborhood where I grew up! http:\/\/t.co\/CwR3Myj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/538754455370735616\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/CwR3MyjSM7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3oKUUSIEAATWWc.jpg",
        "id_str" : "538754449582592000",
        "id" : 538754449582592000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3oKUUSIEAATWWc.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CwR3MyjSM7"
      } ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 14, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538754455370735616",
    "text" : "Spending this #SmallBizSat in Hyde Park, visiting local small businesses in the neighborhood where I grew up! http:\/\/t.co\/CwR3MyjSM7",
    "id" : 538754455370735616,
    "created_at" : "2014-11-29 18:00:46 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 538761234754326528,
  "created_at" : "2014-11-29 18:27:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DineSmall",
      "indices" : [ 93, 103 ]
    }, {
      "text" : "SmallBizSat",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538757588238991360",
  "text" : "RT @SBAgov: Today is Small Business Saturday! Show your support by shopping and dining small #DineSmall #SmallBizSat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DineSmall",
        "indices" : [ 81, 91 ]
      }, {
        "text" : "SmallBizSat",
        "indices" : [ 92, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538686524175708160",
    "text" : "Today is Small Business Saturday! Show your support by shopping and dining small #DineSmall #SmallBizSat",
    "id" : 538686524175708160,
    "created_at" : "2014-11-29 13:30:50 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 538757588238991360,
  "created_at" : "2014-11-29 18:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/534783594758021122\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/7IX4jDKKam",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2vu0mVCUAAjsw6.jpg",
      "id_str" : "534783568182923264",
      "id" : 534783568182923264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2vu0mVCUAAjsw6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7IX4jDKKam"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 65, 76 ]
    }, {
      "text" : "BlackFriday",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "538444786420563969",
  "text" : "Looking for a good deal on health coverage? See your options and #GetCovered at http:\/\/t.co\/NSeLHFvc62. #BlackFriday http:\/\/t.co\/7IX4jDKKam",
  "id" : 538444786420563969,
  "created_at" : "2014-11-28 21:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/534716282021502976\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/SPswoFO7gz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2uxCNfCcAAoqau.jpg",
      "id_str" : "534715632311234560",
      "id" : 534715632311234560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2uxCNfCcAAoqau.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SPswoFO7gz"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 24, 35 ]
    }, {
      "text" : "BlackFriday",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "538429678831161344",
  "text" : "Here are 4 ways you can #GetCovered today:\nhttp:\/\/t.co\/NSeLHFvc62\n\u260F 1(800)318-2596\n\u2709 By mail\n\u270D In person\n#BlackFriday\nhttp:\/\/t.co\/SPswoFO7gz",
  "id" : 538429678831161344,
  "created_at" : "2014-11-28 20:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/538419295420948481\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/hyJmOqWAF6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3jZKsGCMAAFrOt.jpg",
      "id_str" : "538418933129162752",
      "id" : 538418933129162752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3jZKsGCMAAFrOt.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/hyJmOqWAF6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/oq9uazkYZ3",
      "expanded_url" : "http:\/\/go.wh.gov\/2kykfS",
      "display_url" : "go.wh.gov\/2kykfS"
    } ]
  },
  "geo" : { },
  "id_str" : "538419295420948481",
  "text" : "It's beginning to look a lot like Christmas at the White House: http:\/\/t.co\/oq9uazkYZ3 http:\/\/t.co\/hyJmOqWAF6",
  "id" : 538419295420948481,
  "created_at" : "2014-11-28 19:48:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackFriday",
      "indices" : [ 33, 45 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/NSeLHFvc62",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "538399500478328833",
  "text" : "Don't feel like dealing with the #BlackFriday crowds at the store? #GetCovered from the comfort of your couch at http:\/\/t.co\/NSeLHFvc62.",
  "id" : 538399500478328833,
  "created_at" : "2014-11-28 18:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/534783594758021122\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/7k7zKo5x1g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2vu0mVCUAAjsw6.jpg",
      "id_str" : "534783568182923264",
      "id" : 534783568182923264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2vu0mVCUAAjsw6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7k7zKo5x1g"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/JxkdfixJNs",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "538377596732715008",
  "text" : "Spread the word: If you need health coverage, you can #GetCovered today at http:\/\/t.co\/JxkdfixJNs. http:\/\/t.co\/7k7zKo5x1g",
  "id" : 538377596732715008,
  "created_at" : "2014-11-28 17:03:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackFriday",
      "indices" : [ 29, 41 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/JxkdfixJNs",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "538369516565454848",
  "text" : "Looking for a good deal this #BlackFriday? Sign up for a quality, affordable health care plan at http:\/\/t.co\/JxkdfixJNs. #GetCovered",
  "id" : 538369516565454848,
  "created_at" : "2014-11-28 16:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/538101262286209025\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/opoOmE60t1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ez9RBCAAABNt7.jpg",
      "id_str" : "538096545615183872",
      "id" : 538096545615183872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ez9RBCAAABNt7.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/opoOmE60t1"
    } ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538101262286209025",
  "text" : "\"We are grateful to the countless Americans who serve their communities.\" \u2014President Obama on #Thanksgiving. http:\/\/t.co\/opoOmE60t1",
  "id" : 538101262286209025,
  "created_at" : "2014-11-27 22:45:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/538069068222586881\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/akyzyDM84W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ea9zsCYAEvR-F.jpg",
      "id_str" : "538069067131674625",
      "id" : 538069067131674625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ea9zsCYAEvR-F.jpg",
      "sizes" : [ {
        "h" : 298,
        "resize" : "fit",
        "w" : 447
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 447
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 447
      } ],
      "display_url" : "pic.twitter.com\/akyzyDM84W"
    } ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538097033882898432",
  "text" : "RT @VP: Let's give thanks to all the warriors in uniform who have defended our freedom. Happy #Thanksgiving. http:\/\/t.co\/akyzyDM84W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/538069068222586881\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/akyzyDM84W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ea9zsCYAEvR-F.jpg",
        "id_str" : "538069067131674625",
        "id" : 538069067131674625,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ea9zsCYAEvR-F.jpg",
        "sizes" : [ {
          "h" : 298,
          "resize" : "fit",
          "w" : 447
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 447
        }, {
          "h" : 298,
          "resize" : "fit",
          "w" : 447
        } ],
        "display_url" : "pic.twitter.com\/akyzyDM84W"
      } ],
      "hashtags" : [ {
        "text" : "Thanksgiving",
        "indices" : [ 86, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538069068222586881",
    "text" : "Let's give thanks to all the warriors in uniform who have defended our freedom. Happy #Thanksgiving. http:\/\/t.co\/akyzyDM84W",
    "id" : 538069068222586881,
    "created_at" : "2014-11-27 20:37:17 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 538097033882898432,
  "created_at" : "2014-11-27 22:28:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538096775832567808",
  "text" : "RT @SecBurwell: If you're talking turkey today, make sure you're also talking health care with your family &amp; friends. #GetCovered #HappyTha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 106, 117 ]
      }, {
        "text" : "HappyThanksgiving",
        "indices" : [ 118, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538023513832308737",
    "text" : "If you're talking turkey today, make sure you're also talking health care with your family &amp; friends. #GetCovered #HappyThanksgiving",
    "id" : 538023513832308737,
    "created_at" : "2014-11-27 17:36:16 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 538096775832567808,
  "created_at" : "2014-11-27 22:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 1, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/04Fw7H2MvD",
      "expanded_url" : "http:\/\/go.wh.gov\/SuqKpd",
      "display_url" : "go.wh.gov\/SuqKpd"
    } ]
  },
  "geo" : { },
  "id_str" : "538078840963072000",
  "text" : "\"#Thanksgiving is my favorite holiday because, more than any other, it is uniquely American.\" \u2014President Obama: http:\/\/t.co\/04Fw7H2MvD",
  "id" : 538078840963072000,
  "created_at" : "2014-11-27 21:16:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/538071045157044224\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/UPelI52ASk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3eVXMACMAI3WvC.jpg",
      "id_str" : "538062906084962306",
      "id" : 538062906084962306,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3eVXMACMAI3WvC.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2333,
        "resize" : "fit",
        "w" : 3500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UPelI52ASk"
    } ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538071045157044224",
  "text" : "Today President Obama called U.S. troops to express his appreciation on #Thanksgiving on behalf of a grateful nation. http:\/\/t.co\/UPelI52ASk",
  "id" : 538071045157044224,
  "created_at" : "2014-11-27 20:45:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 28, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538058292258668544",
  "text" : "RT @FLOTUS: As we celebrate #Thanksgiving, let's give thanks to our men and women in uniform serving our country far from their homes and f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Thanksgiving",
        "indices" : [ 16, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538058247102808064",
    "text" : "As we celebrate #Thanksgiving, let's give thanks to our men and women in uniform serving our country far from their homes and families. \u2013mo",
    "id" : 538058247102808064,
    "created_at" : "2014-11-27 19:54:17 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 538058292258668544,
  "created_at" : "2014-11-27 19:54:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/04Fw7H2MvD",
      "expanded_url" : "http:\/\/go.wh.gov\/SuqKpd",
      "display_url" : "go.wh.gov\/SuqKpd"
    } ]
  },
  "geo" : { },
  "id_str" : "538037843965120514",
  "text" : "\"On behalf of the Obama family...I want to wish you a very happy #Thanksgiving.\" \u2014President Obama: http:\/\/t.co\/04Fw7H2MvD",
  "id" : 538037843965120514,
  "created_at" : "2014-11-27 18:33:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/537806807599562753\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/aGRJGCCk8S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3arHW6CYAAfY-p.jpg",
      "id_str" : "537805348413792256",
      "id" : 537805348413792256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3arHW6CYAAfY-p.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/aGRJGCCk8S"
    } ],
    "hashtags" : [ {
      "text" : "WHTurkeyPardon",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537806807599562753",
  "text" : "\u201CTomorrow is a pretty special moment when we give thanks for the people we love\" \u2014Obama at the annual #WHTurkeyPardon http:\/\/t.co\/aGRJGCCk8S",
  "id" : 537806807599562753,
  "created_at" : "2014-11-27 03:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537801432670699520",
  "text" : "RT @petesouza: President Obama and his daughters, Malia and Sasha, check out one of the turkeys before today's annual turkey pardon http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/537799141121064961\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/HTfuanTvrg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ald2tIgAIMzPs.jpg",
        "id_str" : "537799137836957698",
        "id" : 537799137836957698,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ald2tIgAIMzPs.jpg",
        "sizes" : [ {
          "h" : 688,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 688,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HTfuanTvrg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537799141121064961",
    "text" : "President Obama and his daughters, Malia and Sasha, check out one of the turkeys before today's annual turkey pardon http:\/\/t.co\/HTfuanTvrg",
    "id" : 537799141121064961,
    "created_at" : "2014-11-27 02:44:41 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 537801432670699520,
  "created_at" : "2014-11-27 02:53:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/537727614341758978\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/x69vHvVJnP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ZScNsCYAEtSbO.jpg",
      "id_str" : "537707850181533697",
      "id" : 537707850181533697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ZScNsCYAEtSbO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/x69vHvVJnP"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 55, 66 ]
    }, {
      "text" : "Thanksgiving",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537727614341758978",
  "text" : "There's a good chance it'll take less time to apply to #GetCovered than it takes to make #Thanksgiving dinner: http:\/\/t.co\/x69vHvVJnP",
  "id" : 537727614341758978,
  "created_at" : "2014-11-26 22:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamMac",
      "indices" : [ 13, 21 ]
    }, {
      "text" : "TeamCheese",
      "indices" : [ 25, 36 ]
    }, {
      "text" : "MacAndCheese",
      "indices" : [ 55, 68 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 81, 92 ]
    }, {
      "text" : "Thanksgiving",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/yO75Q1E7Yc",
      "expanded_url" : "http:\/\/wh.gov\/recipe-for-coverage",
      "display_url" : "wh.gov\/recipe-for-cov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537712524435546113",
  "text" : "Did you vote #TeamMac or #TeamCheese? Now try out this #MacAndCheese recipe, and #GetCovered this #Thanksgiving \u2192 http:\/\/t.co\/yO75Q1E7Yc",
  "id" : 537712524435546113,
  "created_at" : "2014-11-26 21:00:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTurkeyPardon",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537692749567655936",
  "text" : "\"We remember the folks who can\u2019t spend their holiday at home, especially the brave men and women in uniform.\" \u2014Obama #WHTurkeyPardon",
  "id" : 537692749567655936,
  "created_at" : "2014-11-26 19:41:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/537690678206431232\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/vcdjMDpsnR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ZCfWICIAA59HL.jpg",
      "id_str" : "537690311800004608",
      "id" : 537690311800004608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ZCfWICIAA59HL.jpg",
      "sizes" : [ {
        "h" : 136,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/vcdjMDpsnR"
    } ],
    "hashtags" : [ {
      "text" : "TeamCheese",
      "indices" : [ 9, 20 ]
    }, {
      "text" : "Thanksgiving",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537690678206431232",
  "text" : "Congrats #TeamCheese. President Obama just announced that your bird is the 2014 National #Thanksgiving Turkey! http:\/\/t.co\/vcdjMDpsnR",
  "id" : 537690678206431232,
  "created_at" : "2014-11-26 19:33:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 57, 70 ]
    }, {
      "text" : "TeamMac",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "TeamCheese",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/b4tqL3X2az",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "537684144084762625",
  "text" : "Watch at 2:15pm ET: President Obama pardons the National #Thanksgiving Turkey. Is it #TeamMac or #TeamCheese? \u2192 http:\/\/t.co\/b4tqL3X2az",
  "id" : 537684144084762625,
  "created_at" : "2014-11-26 19:07:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamMac",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "TeamCheese",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/bSBUSy77U5",
      "expanded_url" : "https:\/\/vine.co\/v\/O1EjDEZW6Ml",
      "display_url" : "vine.co\/v\/O1EjDEZW6Ml"
    } ]
  },
  "geo" : { },
  "id_str" : "537664934738264064",
  "text" : "Will the 2014 National Thanksgiving Turkey be Mac or Cheese? Polls close at 1pm ET: https:\/\/t.co\/bSBUSy77U5 #TeamMac #TeamCheese",
  "id" : 537664934738264064,
  "created_at" : "2014-11-26 17:51:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 53, 66 ]
    }, {
      "text" : "TeamMac",
      "indices" : [ 80, 88 ]
    }, {
      "text" : "TeamCheese",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/iBGKSoqror",
      "expanded_url" : "http:\/\/go.wh.gov\/hFAu8P",
      "display_url" : "go.wh.gov\/hFAu8P"
    } ]
  },
  "geo" : { },
  "id_str" : "537656970291863552",
  "text" : "Make your gobble heard: Who will become the National #Thanksgiving Turkey? Vote #TeamMac or #TeamCheese by 1pm ET \u2192 http:\/\/t.co\/iBGKSoqror",
  "id" : 537656970291863552,
  "created_at" : "2014-11-26 17:19:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Larson",
      "screen_name" : "Phil44",
      "indices" : [ 3, 10 ],
      "id_str" : "2525192749",
      "id" : 2525192749
    }, {
      "name" : "Letterman",
      "screen_name" : "Letterman",
      "indices" : [ 13, 23 ],
      "id_str" : "25140900",
      "id" : 25140900
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 24, 39 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Nico & Vinz",
      "screen_name" : "NicoandVinz",
      "indices" : [ 40, 52 ],
      "id_str" : "200049436",
      "id" : 200049436
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Phil44\/status\/537649464178380801\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/o6jkxOnQva",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3YdVqHCUAAmLTv.jpg",
      "id_str" : "537649463435612160",
      "id" : 537649463435612160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3YdVqHCUAAmLTv.jpg",
      "sizes" : [ {
        "h" : 168,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 794
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 794
      } ],
      "display_url" : "pic.twitter.com\/o6jkxOnQva"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537652895425232896",
  "text" : "RT @Phil44: .@Letterman @whitehouseostp @NicoandVinz Who's that guy in the middle? Must. Watch. Tonight. http:\/\/t.co\/o6jkxOnQva",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Letterman",
        "screen_name" : "Letterman",
        "indices" : [ 1, 11 ],
        "id_str" : "25140900",
        "id" : 25140900
      }, {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 12, 27 ],
        "id_str" : "33998183",
        "id" : 33998183
      }, {
        "name" : "Nico & Vinz",
        "screen_name" : "NicoandVinz",
        "indices" : [ 28, 40 ],
        "id_str" : "200049436",
        "id" : 200049436
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Phil44\/status\/537649464178380801\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/o6jkxOnQva",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3YdVqHCUAAmLTv.jpg",
        "id_str" : "537649463435612160",
        "id" : 537649463435612160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3YdVqHCUAAmLTv.jpg",
        "sizes" : [ {
          "h" : 168,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 794
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 794
        } ],
        "display_url" : "pic.twitter.com\/o6jkxOnQva"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "537644048119787520",
    "geo" : { },
    "id_str" : "537649464178380801",
    "in_reply_to_user_id" : 25140900,
    "text" : ".@Letterman @whitehouseostp @NicoandVinz Who's that guy in the middle? Must. Watch. Tonight. http:\/\/t.co\/o6jkxOnQva",
    "id" : 537649464178380801,
    "in_reply_to_status_id" : 537644048119787520,
    "created_at" : "2014-11-26 16:49:55 +0000",
    "in_reply_to_screen_name" : "Letterman",
    "in_reply_to_user_id_str" : "25140900",
    "user" : {
      "name" : "Phil Larson",
      "screen_name" : "Phil44",
      "protected" : false,
      "id_str" : "2525192749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470938302095183874\/eFAyUNAe_normal.jpeg",
      "id" : 2525192749,
      "verified" : true
    }
  },
  "id" : 537652895425232896,
  "created_at" : "2014-11-26 17:03:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTurkeyPardon",
      "indices" : [ 13, 28 ]
    }, {
      "text" : "TeamMac",
      "indices" : [ 91, 99 ]
    }, {
      "text" : "TeamCheese",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/frNyFCH1v6",
      "expanded_url" : "http:\/\/go.wh.gov\/hFAu8P",
      "display_url" : "go.wh.gov\/hFAu8P"
    } ]
  },
  "geo" : { },
  "id_str" : "537617841928015872",
  "text" : "Today is the #WHTurkeyPardon. Cast your vote now for America's next top turkey. Are you on #TeamMac or #TeamCheese? http:\/\/t.co\/frNyFCH1v6",
  "id" : 537617841928015872,
  "created_at" : "2014-11-26 14:44:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/qCmyR0gumV",
      "expanded_url" : "http:\/\/snpy.tv\/1tsdcJc",
      "display_url" : "snpy.tv\/1tsdcJc"
    } ]
  },
  "geo" : { },
  "id_str" : "537394906952912896",
  "text" : "\u201CThose of you who are prepared to work constructively, your President will work with you.\u201D \u2014President Obama #Ferguson http:\/\/t.co\/qCmyR0gumV",
  "id" : 537394906952912896,
  "created_at" : "2014-11-25 23:58:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537390249459322880",
  "text" : "\"We didn\u2019t raise the Statue of Liberty with her back to the world; we did it...with her light...shining.\" \u2014Obama #ImmigrationAction",
  "id" : 537390249459322880,
  "created_at" : "2014-11-25 23:39:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537389775687520256",
  "text" : "\"We're not a nation that kicks out strivers and dreamers who want to earn their piece of the American Dream.\" \u2014Obama #ImmigrationAction",
  "id" : 537389775687520256,
  "created_at" : "2014-11-25 23:38:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/537389173238685696\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/g4MCc0ej4N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3UwgdDCEAAZAl9.jpg",
      "id_str" : "537389064651935744",
      "id" : 537389064651935744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3UwgdDCEAAZAl9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g4MCc0ej4N"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537389173238685696",
  "text" : "\"Pass a bill. I want to work with both parties on a more permanent legislative solution.\" \u2014Obama #ImmigrationAction http:\/\/t.co\/g4MCc0ej4N",
  "id" : 537389173238685696,
  "created_at" : "2014-11-25 23:35:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/537388456495042560\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/PoKgGH8RPJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3UuhT1CQAAmMt9.jpg",
      "id_str" : "537386880333922304",
      "id" : 537386880333922304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3UuhT1CQAAmMt9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PoKgGH8RPJ"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 70, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537388456495042560",
  "text" : "\"It's accountability. It's a common-sense approach.\" \u2014President Obama #ImmigrationAction http:\/\/t.co\/PoKgGH8RPJ",
  "id" : 537388456495042560,
  "created_at" : "2014-11-25 23:32:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537386761123823616",
  "text" : "\"We\u2019ll keep focusing the limited enforcement resources we do have on actual threats to our security. Felons, not families.\" \u2014President Obama",
  "id" : 537386761123823616,
  "created_at" : "2014-11-25 23:26:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/537386642857029634\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/RDbS4nL7aO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3UuQ7nCAAASbTT.jpg",
      "id_str" : "537386598954827776",
      "id" : 537386598954827776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3UuQ7nCAAASbTT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RDbS4nL7aO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537386642857029634",
  "text" : "\"I\u2019m taking new steps to deal responsibly with the millions of undocumented immigrants who already live here.\" \u2014Obama http:\/\/t.co\/RDbS4nL7aO",
  "id" : 537386642857029634,
  "created_at" : "2014-11-25 23:25:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/537386327290163201\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ULrR6ULVvs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3Ut8ndCcAEqaO_.jpg",
      "id_str" : "537386249946820609",
      "id" : 537386249946820609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3Ut8ndCcAEqaO_.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ULrR6ULVvs"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537386327290163201",
  "text" : "\"More resources for law enforcement to stem the flow of illegal crossings at the border\" \u2014Obama #ImmigrationAction http:\/\/t.co\/ULrR6ULVvs",
  "id" : 537386327290163201,
  "created_at" : "2014-11-25 23:24:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537386141264384000",
  "text" : "RT @WHLive: \"For a year and a half...Republican leaders in the House simply refused to allow a vote.\" \u2014President Obama on immigration reform",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537386114647343104",
    "text" : "\"For a year and a half...Republican leaders in the House simply refused to allow a vote.\" \u2014President Obama on immigration reform",
    "id" : 537386114647343104,
    "created_at" : "2014-11-25 23:23:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 537386141264384000,
  "created_at" : "2014-11-25 23:23:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 110, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537385344992555008",
  "text" : "\"Being a nation of immigrants gives us a huge entrepreneurial advantage over other nations.\" \u2014President Obama #ImmigrationAction",
  "id" : 537385344992555008,
  "created_at" : "2014-11-25 23:20:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 102, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537385248078974976",
  "text" : "RT @WHLive: \"Immigrants and their children start over 40% of Fortune 500 companies.\" \u2014President Obama #ImmigrationAction",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 90, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537385220832763904",
    "text" : "\"Immigrants and their children start over 40% of Fortune 500 companies.\" \u2014President Obama #ImmigrationAction",
    "id" : 537385220832763904,
    "created_at" : "2014-11-25 23:19:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 537385248078974976,
  "created_at" : "2014-11-25 23:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537384403891412992",
  "text" : "RT @WHLive: \"We are Swedish and Polish and German and Italian. Everybody's Irish on St. Patrick\u2019s Day.\" \u2014Obama on Chicago being a city of i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "537384377643454464",
    "text" : "\"We are Swedish and Polish and German and Italian. Everybody's Irish on St. Patrick\u2019s Day.\" \u2014Obama on Chicago being a city of immigrants",
    "id" : 537384377643454464,
    "created_at" : "2014-11-25 23:16:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 537384403891412992,
  "created_at" : "2014-11-25 23:16:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537383967448911872",
  "text" : "\"To those who think that what happened in #Ferguson is an excuse for violence, I do not have any sympathy for that.\" \u2014President Obama",
  "id" : 537383967448911872,
  "created_at" : "2014-11-25 23:14:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537383453889544192",
  "text" : "\"The bottom line is, nothing of significance, nothing of benefit results from destructive acts.\" \u2014President Obama #Ferguson",
  "id" : 537383453889544192,
  "created_at" : "2014-11-25 23:12:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 27, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/b4tqL3X2az",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "537383364471570432",
  "text" : "\"The problem is not just a #Ferguson problem, it is an American problem.\u201D \u2014President Obama: http:\/\/t.co\/b4tqL3X2az",
  "id" : 537383364471570432,
  "created_at" : "2014-11-25 23:12:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537382325563449344",
  "text" : "\"Burning buildings, torching cars, destroying property\u2026that\u2019s destructive and there\u2019s no excuse for it.\u201D \u2014President Obama #Ferguson",
  "id" : 537382325563449344,
  "created_at" : "2014-11-25 23:08:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537382262984433665",
  "text" : "\"The frustrations we\u2019ve seen are not just about a particular incident; they have deep roots in many communities of color.\" \u2014Obama #Ferguson",
  "id" : 537382262984433665,
  "created_at" : "2014-11-25 23:08:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 100, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/vJOj06vXww",
      "expanded_url" : "http:\/\/go.wh.gov\/j4u8JU",
      "display_url" : "go.wh.gov\/j4u8JU"
    } ]
  },
  "geo" : { },
  "id_str" : "537381462547660801",
  "text" : "Watch live: President Obama speaks on fixing our broken immigration system \u2192 http:\/\/t.co\/vJOj06vXww #ImmigrationAction",
  "id" : 537381462547660801,
  "created_at" : "2014-11-25 23:04:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 105, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/vJOj06vXww",
      "expanded_url" : "http:\/\/go.wh.gov\/j4u8JU",
      "display_url" : "go.wh.gov\/j4u8JU"
    } ]
  },
  "geo" : { },
  "id_str" : "537368993930428416",
  "text" : "Watch President Obama speak at 5:35pm ET on fixing our broken immigration system: http:\/\/t.co\/vJOj06vXww #ImmigrationAction",
  "id" : 537368993930428416,
  "created_at" : "2014-11-25 22:15:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/537339165252546560\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/d4utjqzeWJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3UCWU9CMAAtIiu.jpg",
      "id_str" : "537338313145724928",
      "id" : 537338313145724928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3UCWU9CMAAtIiu.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/d4utjqzeWJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537339165252546560",
  "text" : "Here's how President Obama's giving more than 4 million undocumented immigrants an opportunity to play by the rules. http:\/\/t.co\/d4utjqzeWJ",
  "id" : 537339165252546560,
  "created_at" : "2014-11-25 20:16:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/537314422478610433\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/adpmwVQiKY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3TsmqyCAAAbXVZ.jpg",
      "id_str" : "537314404627251200",
      "id" : 537314404627251200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3TsmqyCAAAbXVZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/adpmwVQiKY"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 91, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537314422478610433",
  "text" : "Share the latest steps that President Obama's taking to fix our broken immigration system. #ImmigrationAction http:\/\/t.co\/adpmwVQiKY",
  "id" : 537314422478610433,
  "created_at" : "2014-11-25 18:38:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/kLVZMnOgfv",
      "expanded_url" : "http:\/\/youtu.be\/j-6cvLqtNkY",
      "display_url" : "youtu.be\/j-6cvLqtNkY"
    } ]
  },
  "geo" : { },
  "id_str" : "537302759629156352",
  "text" : "In case you missed it, go behind the scenes with President Obama as he prepared to announce his #ImmigrationAction: http:\/\/t.co\/kLVZMnOgfv",
  "id" : 537302759629156352,
  "created_at" : "2014-11-25 17:52:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/EKB6Gijg8v",
      "expanded_url" : "http:\/\/go.wh.gov\/M5Rt1R",
      "display_url" : "go.wh.gov\/M5Rt1R"
    } ]
  },
  "geo" : { },
  "id_str" : "537282130171027459",
  "text" : "Our economy continues to grow.\n3rd-quarter GDP = \u2191 3.9%\nConsumer spending = \u2191\nBusiness investment = \u2191\nhttp:\/\/t.co\/EKB6Gijg8v",
  "id" : 537282130171027459,
  "created_at" : "2014-11-25 16:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 18, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/EKB6Gijg8v",
      "expanded_url" : "http:\/\/go.wh.gov\/M5Rt1R",
      "display_url" : "go.wh.gov\/M5Rt1R"
    } ]
  },
  "geo" : { },
  "id_str" : "537274645389398016",
  "text" : "President Obama's #ImmigrationAction will boost GDP by at least an estimated 0.4% over 10 years \u2192 http:\/\/t.co\/EKB6Gijg8v",
  "id" : 537274645389398016,
  "created_at" : "2014-11-25 16:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/537269361749544960\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/sw9Acnqf7D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3TDhS6CYAAHVt7.jpg",
      "id_str" : "537269232342294528",
      "id" : 537269232342294528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3TDhS6CYAAHVt7.jpg",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/sw9Acnqf7D"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/jYzn0V6vcl",
      "expanded_url" : "http:\/\/go.wh.gov\/M5Rt1R",
      "display_url" : "go.wh.gov\/M5Rt1R"
    } ]
  },
  "geo" : { },
  "id_str" : "537269361749544960",
  "text" : "FACT: Our economy grew at a 3.9% rate last quarter\u2014the 2nd straight quarter of strong growth. http:\/\/t.co\/jYzn0V6vcl http:\/\/t.co\/sw9Acnqf7D",
  "id" : 537269361749544960,
  "created_at" : "2014-11-25 15:39:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/537100599452381185\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/JZ26fetEpb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3Qp-VTCYAA6TyB.jpg",
      "id_str" : "537100406409551872",
      "id" : 537100406409551872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3Qp-VTCYAA6TyB.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 733
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 733
      } ],
      "display_url" : "pic.twitter.com\/JZ26fetEpb"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/6bWKyIJFFD",
      "expanded_url" : "http:\/\/go.wh.gov\/73nwnw",
      "display_url" : "go.wh.gov\/73nwnw"
    } ]
  },
  "geo" : { },
  "id_str" : "537100599452381185",
  "text" : "\"This is not just an issue for #Ferguson. This is an issue for America.\" \u2014President Obama: http:\/\/t.co\/6bWKyIJFFD http:\/\/t.co\/JZ26fetEpb",
  "id" : 537100599452381185,
  "created_at" : "2014-11-25 04:28:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/fxfAQODQ8m",
      "expanded_url" : "http:\/\/youtu.be\/O2BBAfWucaE",
      "display_url" : "youtu.be\/O2BBAfWucaE"
    } ]
  },
  "geo" : { },
  "id_str" : "537097630048714753",
  "text" : "President Obama just delivered a statement on the #Ferguson grand jury decision. Watch it here \u2192 http:\/\/t.co\/fxfAQODQ8m",
  "id" : 537097630048714753,
  "created_at" : "2014-11-25 04:17:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/PMkjKQTol3",
      "expanded_url" : "http:\/\/snpy.tv\/1znu8VH",
      "display_url" : "snpy.tv\/1znu8VH"
    } ]
  },
  "geo" : { },
  "id_str" : "537084594630045696",
  "text" : "Watch President Obama's statement on the #Ferguson grand jury decision. http:\/\/t.co\/PMkjKQTol3",
  "id" : 537084594630045696,
  "created_at" : "2014-11-25 03:25:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537081787998932992",
  "text" : "\"We need to recognize that this is not just an issue for #Ferguson. This is an issue for America.\" \u2014President Obama",
  "id" : 537081787998932992,
  "created_at" : "2014-11-25 03:14:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537081361585029120",
  "text" : "\"In too many parts of this country, a deep distrust exists between law enforcement and communities of color.\" \u2014President Obama #Ferguson",
  "id" : 537081361585029120,
  "created_at" : "2014-11-25 03:12:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 44, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537081212683038720",
  "text" : "\"We need to recognize that the situation in #Ferguson speaks to broader challenges that we still face as a nation.\" \u2014President Obama",
  "id" : 537081212683038720,
  "created_at" : "2014-11-25 03:11:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537081073130168320",
  "text" : "\"I also appeal to the law enforcement officials in #Ferguson and the region to show care and restraint in managing peaceful protests\" \u2014Obama",
  "id" : 537081073130168320,
  "created_at" : "2014-11-25 03:11:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537081001051041792",
  "text" : "\"Michael Brown\u2019s parents have lost more than anyone. We should be honoring their wishes.\" \u2014President Obama #Ferguson",
  "id" : 537081001051041792,
  "created_at" : "2014-11-25 03:11:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537080803922960387",
  "text" : "\"I join Michael\u2019s parents in asking anyone who protests this decision to do so peacefully.\" \u2014President Obama #Ferguson",
  "id" : 537080803922960387,
  "created_at" : "2014-11-25 03:10:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537080713896415233",
  "text" : "\"We are a nation built on the rule of law. And so we must accept that this decision was the grand jury\u2019s to make.\" \u2014Obama #Ferguson",
  "id" : 537080713896415233,
  "created_at" : "2014-11-25 03:09:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537080642668740608",
  "text" : "\"It's an outcome that, either way, was going to be the subject of intense disagreement\u2014not only in #Ferguson, but across America.\" \u2014Obama",
  "id" : 537080642668740608,
  "created_at" : "2014-11-25 03:09:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/dgUaDizb62",
      "expanded_url" : "http:\/\/go.wh.gov\/WnoQ1D",
      "display_url" : "go.wh.gov\/WnoQ1D"
    } ]
  },
  "geo" : { },
  "id_str" : "537080533897859072",
  "text" : "Happening now: President Obama delivers a statement from the White House Briefing Room \u2192 http:\/\/t.co\/dgUaDizb62",
  "id" : 537080533897859072,
  "created_at" : "2014-11-25 03:09:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/bUnsrV4OqA",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "537076541578956800",
  "text" : "At 10pm ET, watch President Obama deliver a statement from the White House Briefing Room \u2192 http:\/\/t.co\/bUnsrV4OqA",
  "id" : 537076541578956800,
  "created_at" : "2014-11-25 02:53:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0438\u043D\u043E\u0433\u0440\u0430\u0434\u043E\u0432   \u0421\u043F\u0438\u0440\u0438\u0434\u043E",
      "screen_name" : "john_dingell",
      "indices" : [ 3, 16 ],
      "id_str" : "2982226132",
      "id" : 2982226132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537006272680194048",
  "text" : "RT @john_dingell: Today is also likely the only day that Meryl Streep and I will be wearing the same thing.\n\nSo, who wore it best? http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/john_dingell\/status\/537005144161124352\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Kql9JPkhLN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3PS7qACYAAqJ0y.png",
        "id_str" : "537004702915780608",
        "id" : 537004702915780608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3PS7qACYAAqJ0y.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Kql9JPkhLN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "536991920074289154",
    "geo" : { },
    "id_str" : "537005144161124352",
    "in_reply_to_user_id" : 109025212,
    "text" : "Today is also likely the only day that Meryl Streep and I will be wearing the same thing.\n\nSo, who wore it best? http:\/\/t.co\/Kql9JPkhLN",
    "id" : 537005144161124352,
    "in_reply_to_status_id" : 536991920074289154,
    "created_at" : "2014-11-24 22:09:38 +0000",
    "in_reply_to_screen_name" : "JohnDingell",
    "in_reply_to_user_id_str" : "109025212",
    "user" : {
      "name" : "John Dingell",
      "screen_name" : "JohnDingell",
      "protected" : false,
      "id_str" : "109025212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751796404864122880\/jiPHasvn_normal.jpg",
      "id" : 109025212,
      "verified" : true
    }
  },
  "id" : 537006272680194048,
  "created_at" : "2014-11-24 22:14:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/537000414466412544\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/FtRU2x6Ikx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3PO0-0CIAAWf3T.jpg",
      "id_str" : "537000190196981760",
      "id" : 537000190196981760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3PO0-0CIAAWf3T.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FtRU2x6Ikx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537000414466412544",
  "text" : "President Obama's taking new steps to fix our immigration system.\nIt's time for House Republicans to finish the job. http:\/\/t.co\/FtRU2x6Ikx",
  "id" : 537000414466412544,
  "created_at" : "2014-11-24 21:50:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/536990099070672896\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/j33KQZ1NcR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3PFTbECMAAni0X.jpg",
      "id_str" : "536989718060085248",
      "id" : 536989718060085248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3PFTbECMAAni0X.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/j33KQZ1NcR"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 75, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/qzUegYsEXY",
      "expanded_url" : "http:\/\/go.wh.gov\/Tow6P2",
      "display_url" : "go.wh.gov\/Tow6P2"
    } ]
  },
  "geo" : { },
  "id_str" : "536990099070672896",
  "text" : "\"Amnesty is the immigration system we have today.\" \u2014President Obama on his #ImmigrationAction: http:\/\/t.co\/qzUegYsEXY http:\/\/t.co\/j33KQZ1NcR",
  "id" : 536990099070672896,
  "created_at" : "2014-11-24 21:09:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "ARPA-E",
      "screen_name" : "ARPAE",
      "indices" : [ 78, 84 ],
      "id_str" : "55308417",
      "id" : 55308417
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 23, 35 ]
    }, {
      "text" : "STEM",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "science",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/mtrKAyjQeJ",
      "expanded_url" : "http:\/\/go.usa.gov\/HTpQ",
      "display_url" : "go.usa.gov\/HTpQ"
    } ]
  },
  "geo" : { },
  "id_str" : "536984778247897088",
  "text" : "RT @ENERGY: Our latest #WomenInSTEM profile Cheryl Martin, Acting Director of @ARPAE \u2192 http:\/\/t.co\/mtrKAyjQeJ #STEM #science http:\/\/t.co\/xo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ARPA-E",
        "screen_name" : "ARPAE",
        "indices" : [ 66, 72 ],
        "id_str" : "55308417",
        "id" : 55308417
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/536935558560624640\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/xomViv11GZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3OUC6HIAAAHbY6.jpg",
        "id_str" : "536935558267011072",
        "id" : 536935558267011072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3OUC6HIAAAHbY6.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1063,
          "resize" : "fit",
          "w" : 1594
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xomViv11GZ"
      } ],
      "hashtags" : [ {
        "text" : "WomenInSTEM",
        "indices" : [ 11, 23 ]
      }, {
        "text" : "STEM",
        "indices" : [ 98, 103 ]
      }, {
        "text" : "science",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/mtrKAyjQeJ",
        "expanded_url" : "http:\/\/go.usa.gov\/HTpQ",
        "display_url" : "go.usa.gov\/HTpQ"
      } ]
    },
    "geo" : { },
    "id_str" : "536935558560624640",
    "text" : "Our latest #WomenInSTEM profile Cheryl Martin, Acting Director of @ARPAE \u2192 http:\/\/t.co\/mtrKAyjQeJ #STEM #science http:\/\/t.co\/xomViv11GZ",
    "id" : 536935558560624640,
    "created_at" : "2014-11-24 17:33:07 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 536984778247897088,
  "created_at" : "2014-11-24 20:48:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536971323084644352",
  "text" : "\"We give thanks to a person whose love for her family is matched by her devotion to her nation.\" \u2014Obama on Ethel Kennedy #MedalOfFreedom",
  "id" : 536971323084644352,
  "created_at" : "2014-11-24 19:55:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536969836690419712",
  "text" : "\"The chronicler of the Greatest Generation...we celebrate [Tom Brokaw] as one of our nation\u2019s greatest journalists.\" \u2014Obama #MedalOfFreedom",
  "id" : 536969836690419712,
  "created_at" : "2014-11-24 19:49:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 97, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536969238037417984",
  "text" : "\"Thanks to Stevie, all of us have been moved to higher ground.\" \u2014President Obama on awarding the #MedalOfFreedom to Stevie Wonder",
  "id" : 536969238037417984,
  "created_at" : "2014-11-24 19:46:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536968745584193537",
  "text" : "\"Meryl is truly one of America\u2019s leading ladies.\" \u2014President Obama on awarding Meryl Streep the #MedalOfFreedom",
  "id" : 536968745584193537,
  "created_at" : "2014-11-24 19:45:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0438\u043D\u043E\u0433\u0440\u0430\u0434\u043E\u0432   \u0421\u043F\u0438\u0440\u0438\u0434\u043E",
      "screen_name" : "john_dingell",
      "indices" : [ 107, 120 ],
      "id_str" : "2982226132",
      "id" : 2982226132
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536967311073509376",
  "text" : "\"He gaveled in the vote for Medicare; helped lead the fight for the Civil Rights Act.\" \u2014President Obama on @John_Dingell #MedalOfFreedom",
  "id" : 536967311073509376,
  "created_at" : "2014-11-24 19:39:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536967245847883776",
  "text" : "RT @WHLive: \"Patsy [Mink] was a passionate advocate for opportunity &amp; equality &amp; realizing the promise of the American dream.\" \u2014Obama #Meda\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalOfFreedom",
        "indices" : [ 130, 145 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "536967130621960192",
    "text" : "\"Patsy [Mink] was a passionate advocate for opportunity &amp; equality &amp; realizing the promise of the American dream.\" \u2014Obama #MedalOfFreedom",
    "id" : 536967130621960192,
    "created_at" : "2014-11-24 19:38:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 536967245847883776,
  "created_at" : "2014-11-24 19:39:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536966513237164032",
  "text" : "\"Once a year, we set aside this event to celebrate people...with our highest civilian honor\u2014the Presidential #MedalOfFreedom.\" \u2014Obama",
  "id" : 536966513237164032,
  "created_at" : "2014-11-24 19:36:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 39, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/iTvhhbit87",
      "expanded_url" : "http:\/\/go.wh.gov\/oWnoUT",
      "display_url" : "go.wh.gov\/oWnoUT"
    } ]
  },
  "geo" : { },
  "id_str" : "536966300153950208",
  "text" : "Watch live: President Obama awards the #MedalOfFreedom to 19 recipients \u2192 http:\/\/t.co\/iTvhhbit87",
  "id" : 536966300153950208,
  "created_at" : "2014-11-24 19:35:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 32, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/iTvhhbit87",
      "expanded_url" : "http:\/\/go.wh.gov\/oWnoUT",
      "display_url" : "go.wh.gov\/oWnoUT"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/zyTzeK0fBd",
      "expanded_url" : "http:\/\/wh.gov\/medal-of-freedom",
      "display_url" : "wh.gov\/medal-of-freed\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "536958986269257728",
  "text" : "Watch President Obama award the #MedalOfFreedom at 2:15pm ET \u2192 http:\/\/t.co\/iTvhhbit87\nCheck out past recipients \u2192 http:\/\/t.co\/zyTzeK0fBd",
  "id" : 536958986269257728,
  "created_at" : "2014-11-24 19:06:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/536950994131640320\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/mOfI5kV8bl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3Oh6isCIAE_qiu.jpg",
      "id_str" : "536950807703199745",
      "id" : 536950807703199745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3Oh6isCIAE_qiu.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/mOfI5kV8bl"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 89, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/qzUegYsEXY",
      "expanded_url" : "http:\/\/go.wh.gov\/Tow6P2",
      "display_url" : "go.wh.gov\/Tow6P2"
    } ]
  },
  "geo" : { },
  "id_str" : "536950994131640320",
  "text" : "RT if you agree: It's time to fix our broken immigration system \u2192 http:\/\/t.co\/qzUegYsEXY #ImmigrationAction http:\/\/t.co\/mOfI5kV8bl",
  "id" : 536950994131640320,
  "created_at" : "2014-11-24 18:34:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/536927978782224384\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/iv6SUwJh2C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ONBBeCMAAl3mE.jpg",
      "id_str" : "536927829301014528",
      "id" : 536927829301014528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ONBBeCMAAl3mE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iv6SUwJh2C"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 52, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/yflT7VHV5p",
      "expanded_url" : "http:\/\/go.wh.gov\/Tow6P2",
      "display_url" : "go.wh.gov\/Tow6P2"
    } ]
  },
  "geo" : { },
  "id_str" : "536927978782224384",
  "text" : "We were strangers once, too. http:\/\/t.co\/yflT7VHV5p #ImmigrationAction http:\/\/t.co\/iv6SUwJh2C",
  "id" : 536927978782224384,
  "created_at" : "2014-11-24 17:03:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 86, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/kLVZMnOgfv",
      "expanded_url" : "http:\/\/youtu.be\/j-6cvLqtNkY",
      "display_url" : "youtu.be\/j-6cvLqtNkY"
    } ]
  },
  "geo" : { },
  "id_str" : "536913665610743808",
  "text" : "\"We are, and always will be, a nation of immigrants.\"\nPresident Obama reflects on his #ImmigrationAction \u2192 http:\/\/t.co\/kLVZMnOgfv",
  "id" : 536913665610743808,
  "created_at" : "2014-11-24 16:06:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/bUnsrV4OqA",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "536890576159784961",
  "text" : "Watch President Obama make a personnel announcement at 11:10am ET \u2192 http:\/\/t.co\/bUnsrV4OqA",
  "id" : 536890576159784961,
  "created_at" : "2014-11-24 14:34:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 111, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/T7Gp7N2Qth",
      "expanded_url" : "http:\/\/youtu.be\/j-6cvLqtNkY",
      "display_url" : "youtu.be\/j-6cvLqtNkY"
    } ]
  },
  "geo" : { },
  "id_str" : "536632831573622784",
  "text" : "Go behind-the-scenes with President Obama before delivering his address to the nation \u2192 http:\/\/t.co\/T7Gp7N2Qth #ImmigrationAction",
  "id" : 536632831573622784,
  "created_at" : "2014-11-23 21:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/5Vubai1j1Q",
      "expanded_url" : "http:\/\/go.wh.gov\/qBVKCS",
      "display_url" : "go.wh.gov\/qBVKCS"
    } ]
  },
  "geo" : { },
  "id_str" : "536613947420311553",
  "text" : "\"What makes us Americans is our shared commitment to an ideal that all of us are created equal.\" \u2014President Obama http:\/\/t.co\/5Vubai1j1Q",
  "id" : 536613947420311553,
  "created_at" : "2014-11-23 20:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 106, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/5Vubai1j1Q",
      "expanded_url" : "http:\/\/go.wh.gov\/qBVKCS",
      "display_url" : "go.wh.gov\/qBVKCS"
    } ]
  },
  "geo" : { },
  "id_str" : "536580019187769344",
  "text" : "\"Pass a bill.\" \u2014President Obama to Republicans in Congress on immigration reform: http:\/\/t.co\/5Vubai1j1Q  #ImmigrationAction",
  "id" : 536580019187769344,
  "created_at" : "2014-11-23 18:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5Vubai1j1Q",
      "expanded_url" : "http:\/\/go.wh.gov\/qBVKCS",
      "display_url" : "go.wh.gov\/qBVKCS"
    } ]
  },
  "geo" : { },
  "id_str" : "536547514476810240",
  "text" : "\"We are a nation of immigrants. It has always given America a big advantage.\" \u2014President Obama: http:\/\/t.co\/5Vubai1j1Q #ImmigrationAction",
  "id" : 536547514476810240,
  "created_at" : "2014-11-23 15:51:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/5Vubai1j1Q",
      "expanded_url" : "http:\/\/go.wh.gov\/qBVKCS",
      "display_url" : "go.wh.gov\/qBVKCS"
    } ]
  },
  "geo" : { },
  "id_str" : "536317238362402816",
  "text" : "\"We\u2019ll bring more undocumented immigrants out of the shadows so they can play by the rules\" \u2014President Obama: http:\/\/t.co\/5Vubai1j1Q",
  "id" : 536317238362402816,
  "created_at" : "2014-11-23 00:36:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/5Vubai1j1Q",
      "expanded_url" : "http:\/\/go.wh.gov\/qBVKCS",
      "display_url" : "go.wh.gov\/qBVKCS"
    } ]
  },
  "geo" : { },
  "id_str" : "536285571929227265",
  "text" : "\"We\u2019ll focus enforcement resources on people who are threats to our security\u2014felons, not families.\" \u2014Obama: http:\/\/t.co\/5Vubai1j1Q",
  "id" : 536285571929227265,
  "created_at" : "2014-11-22 22:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/5Vubai1j1Q",
      "expanded_url" : "http:\/\/go.wh.gov\/qBVKCS",
      "display_url" : "go.wh.gov\/qBVKCS"
    } ]
  },
  "geo" : { },
  "id_str" : "536270488599658496",
  "text" : "\"We\u2019re providing more resources at the border to help law enforcement personnel stop illegal crossings.\" \u2014Obama: http:\/\/t.co\/5Vubai1j1Q",
  "id" : 536270488599658496,
  "created_at" : "2014-11-22 21:30:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 94, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/T7Gp7N2Qth",
      "expanded_url" : "http:\/\/youtu.be\/j-6cvLqtNkY",
      "display_url" : "youtu.be\/j-6cvLqtNkY"
    } ]
  },
  "geo" : { },
  "id_str" : "536243989960073216",
  "text" : "\"We are,\nand always will be,\na nation of immigrants.\"\n\u2014President Obama\nhttp:\/\/t.co\/T7Gp7N2Qth\n#ImmigrationAction",
  "id" : 536243989960073216,
  "created_at" : "2014-11-22 19:45:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PassABill",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/5Vubai1j1Q",
      "expanded_url" : "http:\/\/go.wh.gov\/qBVKCS",
      "display_url" : "go.wh.gov\/qBVKCS"
    } ]
  },
  "geo" : { },
  "id_str" : "536225146466365440",
  "text" : "\"For a year and a half, Republican leaders in the House have refused to allow that simple vote.\" \u2014Obama: http:\/\/t.co\/5Vubai1j1Q  #PassABill",
  "id" : 536225146466365440,
  "created_at" : "2014-11-22 18:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5Vubai1j1Q",
      "expanded_url" : "http:\/\/go.wh.gov\/qBVKCS",
      "display_url" : "go.wh.gov\/qBVKCS"
    } ]
  },
  "geo" : { },
  "id_str" : "536202007783038977",
  "text" : "\"We are a nation of immigrants. It has always given America a big advantage.\" \u2014President Obama: http:\/\/t.co\/5Vubai1j1Q #ImmigrationAction",
  "id" : 536202007783038977,
  "created_at" : "2014-11-22 16:58:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Guerrero",
      "screen_name" : "dianeguerrero__",
      "indices" : [ 3, 19 ],
      "id_str" : "1635077976",
      "id" : 1635077976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigrationaction",
      "indices" : [ 105, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535950673041694720",
  "text" : "RT @dianeguerrero__: What a historical moment! A step in the right direction. Thank you to my community! #immigrationaction http:\/\/t.co\/7yd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigrationaction",
        "indices" : [ 84, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/7ydiz6wVQk",
        "expanded_url" : "http:\/\/instagram.com\/p\/vra_EAEZET\/",
        "display_url" : "instagram.com\/p\/vra_EAEZET\/"
      } ]
    },
    "geo" : { },
    "id_str" : "535922024179593217",
    "text" : "What a historical moment! A step in the right direction. Thank you to my community! #immigrationaction http:\/\/t.co\/7ydiz6wVQk",
    "id" : 535922024179593217,
    "created_at" : "2014-11-21 22:25:42 +0000",
    "user" : {
      "name" : "Diane Guerrero",
      "screen_name" : "dianeguerrero__",
      "protected" : false,
      "id_str" : "1635077976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768796654048841728\/do9LsylK_normal.jpg",
      "id" : 1635077976,
      "verified" : true
    }
  },
  "id" : 535950673041694720,
  "created_at" : "2014-11-22 00:19:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535948832530784256\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/RSaO4C1Fjm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ASM-3CIAAh6Uw.jpg",
      "id_str" : "535948369898643456",
      "id" : 535948369898643456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ASM-3CIAAh6Uw.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RSaO4C1Fjm"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 99, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/nOu2WpXwkL",
      "expanded_url" : "http:\/\/youtu.be\/SdMxHA4cmIs",
      "display_url" : "youtu.be\/SdMxHA4cmIs"
    } ]
  },
  "geo" : { },
  "id_str" : "535948832530784256",
  "text" : "\"We are a nation of immigrants\" \u2014Obama at Del Sol High School in Las Vegas: http:\/\/t.co\/nOu2WpXwkL #ImmigrationAction http:\/\/t.co\/RSaO4C1Fjm",
  "id" : 535948832530784256,
  "created_at" : "2014-11-22 00:12:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/HKAUuNegUG",
      "expanded_url" : "http:\/\/go.wh.gov\/dViXVh",
      "display_url" : "go.wh.gov\/dViXVh"
    } ]
  },
  "geo" : { },
  "id_str" : "535944688155774976",
  "text" : "RT @FLOTUS: The President &amp; First Lady sat down to lunch with students from the Standing Rock Sioux Tribe: http:\/\/t.co\/HKAUuNegUG http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/535941317797216256\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/RwUZ16k7yj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ALs5BCcAA1lTu.jpg",
        "id_str" : "535941221504413696",
        "id" : 535941221504413696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ALs5BCcAA1lTu.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/RwUZ16k7yj"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/HKAUuNegUG",
        "expanded_url" : "http:\/\/go.wh.gov\/dViXVh",
        "display_url" : "go.wh.gov\/dViXVh"
      } ]
    },
    "geo" : { },
    "id_str" : "535941317797216256",
    "text" : "The President &amp; First Lady sat down to lunch with students from the Standing Rock Sioux Tribe: http:\/\/t.co\/HKAUuNegUG http:\/\/t.co\/RwUZ16k7yj",
    "id" : 535941317797216256,
    "created_at" : "2014-11-21 23:42:22 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 535944688155774976,
  "created_at" : "2014-11-21 23:55:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/kLVZMnOgfv",
      "expanded_url" : "http:\/\/youtu.be\/j-6cvLqtNkY",
      "display_url" : "youtu.be\/j-6cvLqtNkY"
    } ]
  },
  "geo" : { },
  "id_str" : "535923393489821697",
  "text" : "\"To be an American is about something more than what we look like.\" \u2014President Obama\nWatch \u2192 http:\/\/t.co\/kLVZMnOgfv #ImmigrationAction",
  "id" : 535923393489821697,
  "created_at" : "2014-11-21 22:31:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 94, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/CBIK6wGsi5",
      "expanded_url" : "http:\/\/snpy.tv\/11meK0Q",
      "display_url" : "snpy.tv\/11meK0Q"
    } ]
  },
  "geo" : { },
  "id_str" : "535915766491922433",
  "text" : "\"What makes us American is a shared commitment to an ideal that all of us are created equal.\" #ImmigrationAction http:\/\/t.co\/CBIK6wGsi5",
  "id" : 535915766491922433,
  "created_at" : "2014-11-21 22:00:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 36, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/PvWTPoiTNJ",
      "expanded_url" : "http:\/\/go.wh.gov\/VJpNqc",
      "display_url" : "go.wh.gov\/VJpNqc"
    }, {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/K5oOsG4f03",
      "expanded_url" : "http:\/\/snpy.tv\/11mbgLL",
      "display_url" : "snpy.tv\/11mbgLL"
    } ]
  },
  "geo" : { },
  "id_str" : "535907970815901696",
  "text" : "S\u00ED se puede. http:\/\/t.co\/PvWTPoiTNJ #ImmigrationAction http:\/\/t.co\/K5oOsG4f03",
  "id" : 535907970815901696,
  "created_at" : "2014-11-21 21:29:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535906209145303040",
  "text" : "\"What makes us American is our shared commitment to an ideal\u2014that all of us are created equal.\" \u2014President Obama #ImmigrationAction",
  "id" : 535906209145303040,
  "created_at" : "2014-11-21 21:22:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535905869817729024",
  "text" : "\"We didn\u2019t raise the Statue of Liberty with her back to the world; we did it with her light shining\" \u2014President Obama #ImmigrationAction",
  "id" : 535905869817729024,
  "created_at" : "2014-11-21 21:21:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535905589210402816",
  "text" : "\"We're not a nation that kicks out strivers and dreamers who want to earn their piece of the American Dream.\" \u2014Obama #ImmigrationAction",
  "id" : 535905589210402816,
  "created_at" : "2014-11-21 21:20:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535905021188386816",
  "text" : "\"We are a nation that gives them a chance to take responsibility...and create a better future for their kids.\" \u2014Obama #ImmigrationAction",
  "id" : 535905021188386816,
  "created_at" : "2014-11-21 21:18:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 94, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535904233972068352",
  "text" : "\"Pass a bill.\" \u2014President Obama to Republicans in Congress on the need for immigration reform #ImmigrationAction",
  "id" : 535904233972068352,
  "created_at" : "2014-11-21 21:15:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535903855989755904\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/6Z2j6l6JHz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2_pgP0CQAAag9p.jpg",
      "id_str" : "535903620890247168",
      "id" : 535903620890247168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2_pgP0CQAAag9p.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6Z2j6l6JHz"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535903855989755904",
  "text" : "\"If you meet the criteria, you can come out of the shadows and...get right with the law.\" \u2014Obama #ImmigrationAction http:\/\/t.co\/6Z2j6l6JHz",
  "id" : 535903855989755904,
  "created_at" : "2014-11-21 21:13:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535903403055251458",
  "text" : "\"Amnesty...is the system we have today...millions of people who live here without...playing by the rules.\" \u2014Obama #ImmigrationAction",
  "id" : 535903403055251458,
  "created_at" : "2014-11-21 21:11:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/535902934375346177\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/6Td3hZwYW3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2_o3rvCQAIYzfb.jpg",
      "id_str" : "535902924010831874",
      "id" : 535902924010831874,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2_o3rvCQAIYzfb.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6Td3hZwYW3"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 53, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535902934375346177",
  "text" : "\"We\u2019ve offered the following deal.\" \u2014President Obama #ImmigrationAction http:\/\/t.co\/6Td3hZwYW3",
  "id" : 535902934375346177,
  "created_at" : "2014-11-21 21:09:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535902686336786432\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/M2KWJmwdam",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2_ooGjCUAAtZej.jpg",
      "id_str" : "535902656330354688",
      "id" : 535902656330354688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2_ooGjCUAAtZej.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/M2KWJmwdam"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 79, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535902686336786432",
  "text" : "\u201CThis is not just a Latino issue. This is an American issue.\u201D \u2014President Obama #ImmigrationAction http:\/\/t.co\/M2KWJmwdam",
  "id" : 535902686336786432,
  "created_at" : "2014-11-21 21:08:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535901823719460864",
  "text" : "\"We\u2019ll keep focusing enforcement resources on actual threats to our security. But that means felons, not families\" \u2014Obama #ImmigrationAction",
  "id" : 535901823719460864,
  "created_at" : "2014-11-21 21:05:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535901429597487104\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/AF1rhbGpsp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2_nfzmCEAAhNP1.jpg",
      "id_str" : "535901414292066304",
      "id" : 535901414292066304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2_nfzmCEAAhNP1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AF1rhbGpsp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535901429597487104",
  "text" : "\"We\u2019re providing more resources to law enforcement so they can stem the flow of illegal crossings\" \u2014Obama http:\/\/t.co\/AF1rhbGpsp",
  "id" : 535901429597487104,
  "created_at" : "2014-11-21 21:03:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535901215641849856",
  "text" : "RT @WHLive: \"I will not give up. I want to keep working with Members of Congress to make reform a reality.\" \u2014President Obama #ImmigrationAc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 113, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535901192254394368",
    "text" : "\"I will not give up. I want to keep working with Members of Congress to make reform a reality.\" \u2014President Obama #ImmigrationAction",
    "id" : 535901192254394368,
    "created_at" : "2014-11-21 21:02:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 535901215641849856,
  "created_at" : "2014-11-21 21:03:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535900862460465152",
  "text" : "RT @WHLive: \"The only thing that's been standing in the way is a simple, up or down vote in the House.\" \u2014President Obama on immigration ref\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535900838431293440",
    "text" : "\"The only thing that's been standing in the way is a simple, up or down vote in the House.\" \u2014President Obama on immigration reform",
    "id" : 535900838431293440,
    "created_at" : "2014-11-21 21:01:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 535900862460465152,
  "created_at" : "2014-11-21 21:01:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/535899561701937154\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/PkITSpMLSp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2_lzdrCcAAKgTC.jpg",
      "id_str" : "535899552981610496",
      "id" : 535899552981610496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2_lzdrCcAAKgTC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PkITSpMLSp"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 92, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535899561701937154",
  "text" : "\"Over the past six years, illegal border crossings have been cut by more than half.\" \u2014Obama #ImmigrationAction http:\/\/t.co\/PkITSpMLSp",
  "id" : 535899561701937154,
  "created_at" : "2014-11-21 20:56:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535899394047217664",
  "text" : "RT @WHLive: \"As Americans, we believe in fairness\u2014the idea that if we work hard and play by the rules, we can get ahead.\" \u2014Obama #Immigrati\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 117, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535899368487145472",
    "text" : "\"As Americans, we believe in fairness\u2014the idea that if we work hard and play by the rules, we can get ahead.\" \u2014Obama #ImmigrationAction",
    "id" : 535899368487145472,
    "created_at" : "2014-11-21 20:55:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 535899394047217664,
  "created_at" : "2014-11-21 20:55:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 104, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535899253894557696",
  "text" : "\"Our immigration system has been broken for a very long time, and everybody knows it.\" \u2014President Obama #ImmigrationAction",
  "id" : 535899253894557696,
  "created_at" : "2014-11-21 20:55:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 108, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535899165835165696",
  "text" : "\"We are a nation of immigrants\u2026and it gives us a tremendous advantage over other nations.\" \u2014President Obama #ImmigrationAction",
  "id" : 535899165835165696,
  "created_at" : "2014-11-21 20:54:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 109, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535899004845170688",
  "text" : "\"Part of what makes America exceptional is that we welcome exceptional people like Astrid.\" \u2014President Obama #ImmigrationAction",
  "id" : 535899004845170688,
  "created_at" : "2014-11-21 20:54:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 55, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/be0hVwBbuM",
      "expanded_url" : "http:\/\/go.wh.gov\/BTmfdW",
      "display_url" : "go.wh.gov\/BTmfdW"
    } ]
  },
  "geo" : { },
  "id_str" : "535898228953456641",
  "text" : "Watch live: President Obama speaks in Las Vegas on the #ImmigrationAction he announced last night \u2192 http:\/\/t.co\/be0hVwBbuM",
  "id" : 535898228953456641,
  "created_at" : "2014-11-21 20:51:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 61, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/be0hVwBbuM",
      "expanded_url" : "http:\/\/go.wh.gov\/BTmfdW",
      "display_url" : "go.wh.gov\/BTmfdW"
    } ]
  },
  "geo" : { },
  "id_str" : "535890555239424001",
  "text" : "Watch President Obama speak at 3:55pm ET in Las Vegas on the #ImmigrationAction he announced last night \u2192 http:\/\/t.co\/be0hVwBbuM",
  "id" : 535890555239424001,
  "created_at" : "2014-11-21 20:20:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 66, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/kLVZMnOgfv",
      "expanded_url" : "http:\/\/youtu.be\/j-6cvLqtNkY",
      "display_url" : "youtu.be\/j-6cvLqtNkY"
    } ]
  },
  "geo" : { },
  "id_str" : "535882945173938177",
  "text" : "Go behind the scenes with President Obama before he delivered his #ImmigrationAction address to the nation \u2192 http:\/\/t.co\/kLVZMnOgfv",
  "id" : 535882945173938177,
  "created_at" : "2014-11-21 19:50:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 108, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/w0Eoal63f2",
      "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/president-obama-speaks-on-fixing-americas-broken-immigration-system-nov-20-2014",
      "display_url" : "soundcloud.com\/whitehouse\/pre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535870921278767105",
  "text" : "\"Scripture tells us that we shall not oppress a stranger.\" \u2014President Obama\nWatch \u2192 https:\/\/t.co\/w0Eoal63f2 #ImmigrationAction",
  "id" : 535870921278767105,
  "created_at" : "2014-11-21 19:02:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 24, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535867183218581504",
  "text" : "RT @VP: The President's #ImmigrationAction restores dignity &amp; respect to millions of American families. Congress must act on a long term fi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 16, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535863890681561088",
    "text" : "The President's #ImmigrationAction restores dignity &amp; respect to millions of American families. Congress must act on a long term fix. -VP",
    "id" : 535863890681561088,
    "created_at" : "2014-11-21 18:34:42 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 535867183218581504,
  "created_at" : "2014-11-21 18:47:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 105, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/kLVZMnOgfv",
      "expanded_url" : "http:\/\/youtu.be\/j-6cvLqtNkY",
      "display_url" : "youtu.be\/j-6cvLqtNkY"
    } ]
  },
  "geo" : { },
  "id_str" : "535857670847471616",
  "text" : "\"We know the heart of a stranger. We were strangers once, too.\" \u2014President Obama: http:\/\/t.co\/kLVZMnOgfv #ImmigrationAction",
  "id" : 535857670847471616,
  "created_at" : "2014-11-21 18:09:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 87, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/gtWJZpMFPB",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/f6fc5e78-5f3e-46fd-8737-e6d8c992c948",
      "display_url" : "amp.twimg.com\/v\/f6fc5e78-5f3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535849394285731840",
  "text" : "A behind-the-scenes video you don't want to miss. Watch President Obama reflect on his #ImmigrationAction.\nhttps:\/\/t.co\/gtWJZpMFPB",
  "id" : 535849394285731840,
  "created_at" : "2014-11-21 17:37:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Narendra Modi",
      "screen_name" : "narendramodi",
      "indices" : [ 1, 14 ],
      "id_str" : "18839785",
      "id" : 18839785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/70cQ7rpppf",
      "expanded_url" : "http:\/\/go.wh.gov\/2kJ73i",
      "display_url" : "go.wh.gov\/2kJ73i"
    } ]
  },
  "in_reply_to_status_id_str" : "535794981332459521",
  "geo" : { },
  "id_str" : "535830146134315008",
  "in_reply_to_user_id" : 18839785,
  "text" : ".@narendramodi: President Obama looks forward to celebrating Republic Day in New Delhi with you: http:\/\/t.co\/70cQ7rpppf",
  "id" : 535830146134315008,
  "in_reply_to_status_id" : 535794981332459521,
  "created_at" : "2014-11-21 16:20:36 +0000",
  "in_reply_to_screen_name" : "narendramodi",
  "in_reply_to_user_id_str" : "18839785",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/535823195610578944\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/VPMbRq7fie",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2-gQ15CAAAJ4xQ.jpg",
      "id_str" : "535823091885015040",
      "id" : 535823091885015040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2-gQ15CAAAJ4xQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VPMbRq7fie"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/PvWTPoiTNJ",
      "expanded_url" : "http:\/\/go.wh.gov\/VJpNqc",
      "display_url" : "go.wh.gov\/VJpNqc"
    } ]
  },
  "geo" : { },
  "id_str" : "535823195610578944",
  "text" : "\"We are, and always will be, a nation of immigrants.\" \u2014President Obama: http:\/\/t.co\/PvWTPoiTNJ #ImmigrationAction http:\/\/t.co\/VPMbRq7fie",
  "id" : 535823195610578944,
  "created_at" : "2014-11-21 15:52:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/hqWIuXvRpJ",
      "expanded_url" : "http:\/\/snpy.tv\/1zHWr1S",
      "display_url" : "snpy.tv\/1zHWr1S"
    } ]
  },
  "geo" : { },
  "id_str" : "535806385800642560",
  "text" : "\"We shall not oppress a stranger, for we know the heart of a stranger. We were strangers once, too.\" \u2014President Obama http:\/\/t.co\/hqWIuXvRpJ",
  "id" : 535806385800642560,
  "created_at" : "2014-11-21 14:46:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535634155854262272\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/sxGp6ni0bq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B270UORCAAA0BmI.jpg",
      "id_str" : "535634033967759360",
      "id" : 535634033967759360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B270UORCAAA0BmI.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sxGp6ni0bq"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 89, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/tqb6H23QH5",
      "expanded_url" : "http:\/\/go.wh.gov\/msMfGM",
      "display_url" : "go.wh.gov\/msMfGM"
    } ]
  },
  "geo" : { },
  "id_str" : "535634155854262272",
  "text" : "RT if you agree: It's time to fix our broken immigration system \u2192 http:\/\/t.co\/tqb6H23QH5 #ImmigrationAction http:\/\/t.co\/sxGp6ni0bq",
  "id" : 535634155854262272,
  "created_at" : "2014-11-21 03:21:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 3, 19 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535631438054293504",
  "text" : "RT @SecretaryCastro: Thank you, President Obama, for taking a reasonable first step to fix our nation's broken immigration system.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535615415368437760",
    "text" : "Thank you, President Obama, for taking a reasonable first step to fix our nation's broken immigration system.",
    "id" : 535615415368437760,
    "created_at" : "2014-11-21 02:07:20 +0000",
    "user" : {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "protected" : false,
      "id_str" : "2695663285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/686622077491654658\/oEOE5IDE_normal.jpg",
      "id" : 2695663285,
      "verified" : true
    }
  },
  "id" : 535631438054293504,
  "created_at" : "2014-11-21 03:11:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/535628293966274560\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/DBypk8ggCI",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B27u_WqCYAAAT4G.png",
      "id_str" : "535628177884733440",
      "id" : 535628177884733440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B27u_WqCYAAAT4G.png",
      "sizes" : [ {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DBypk8ggCI"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 52, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/tqb6H23QH5",
      "expanded_url" : "http:\/\/go.wh.gov\/msMfGM",
      "display_url" : "go.wh.gov\/msMfGM"
    } ]
  },
  "geo" : { },
  "id_str" : "535628293966274560",
  "text" : "We were strangers once, too: http:\/\/t.co\/tqb6H23QH5 #ImmigrationAction http:\/\/t.co\/DBypk8ggCI",
  "id" : 535628293966274560,
  "created_at" : "2014-11-21 02:58:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535626053968859137",
  "text" : "RT @SecretaryJewell: As an immigrant, I know firsthand the importance of having a smart\/effective immigration system that supports families\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 122, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535620784426086400",
    "text" : "As an immigrant, I know firsthand the importance of having a smart\/effective immigration system that supports families SJ #ImmigrationAction",
    "id" : 535620784426086400,
    "created_at" : "2014-11-21 02:28:41 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 535626053968859137,
  "created_at" : "2014-11-21 02:49:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535621408915587072",
  "text" : "RT @arneduncan: American dreams can't wait. Keeping families together &amp; increasing educational opportunity will benefit all of us. #Immigra\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 119, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535620771427930112",
    "text" : "American dreams can't wait. Keeping families together &amp; increasing educational opportunity will benefit all of us. #ImmigrationAction",
    "id" : 535620771427930112,
    "created_at" : "2014-11-21 02:28:37 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 535621408915587072,
  "created_at" : "2014-11-21 02:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535620766411522048",
  "text" : "RT @vj44: Deport felons, not families. Criminals, not children. Gang members, not a mother who is working hard to provide. #ImmigrationActi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 113, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535600954570452994",
    "text" : "Deport felons, not families. Criminals, not children. Gang members, not a mother who is working hard to provide. #ImmigrationAction",
    "id" : 535600954570452994,
    "created_at" : "2014-11-21 01:09:53 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 535620766411522048,
  "created_at" : "2014-11-21 02:28:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "michaelscherer",
      "screen_name" : "michaelscherer",
      "indices" : [ 3, 18 ],
      "id_str" : "17910554",
      "id" : 17910554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535619730757804034",
  "text" : "RT @michaelscherer: Enrique Iglesias wins Latin Grammy song of year, calls tonight \"historic night ... for all the Latino people living in \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535617122198880256",
    "text" : "Enrique Iglesias wins Latin Grammy song of year, calls tonight \"historic night ... for all the Latino people living in the U.S.\"",
    "id" : 535617122198880256,
    "created_at" : "2014-11-21 02:14:07 +0000",
    "user" : {
      "name" : "michaelscherer",
      "screen_name" : "michaelscherer",
      "protected" : false,
      "id_str" : "17910554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/84691001\/s664620712_1073326_266_normal.jpg",
      "id" : 17910554,
      "verified" : true
    }
  },
  "id" : 535619730757804034,
  "created_at" : "2014-11-21 02:24:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 101, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535619071388053504",
  "text" : "RT @LaborSec: This is a moral imperative, a national security imperative and an economic imperative. #ImmigrationAction",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 87, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535604910755418112",
    "text" : "This is a moral imperative, a national security imperative and an economic imperative. #ImmigrationAction",
    "id" : 535604910755418112,
    "created_at" : "2014-11-21 01:25:36 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 535619071388053504,
  "created_at" : "2014-11-21 02:21:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/535617495323770880\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/77GNtYkwHv",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B27lOXTCUAIOYXI.png",
      "id_str" : "535617440638455810",
      "id" : 535617440638455810,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B27lOXTCUAIOYXI.png",
      "sizes" : [ {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/77GNtYkwHv"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 75, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/tqb6H23QH5",
      "expanded_url" : "http:\/\/go.wh.gov\/msMfGM",
      "display_url" : "go.wh.gov\/msMfGM"
    } ]
  },
  "geo" : { },
  "id_str" : "535617495323770880",
  "text" : "We are, and always will be, a nation of immigrants: http:\/\/t.co\/tqb6H23QH5 #ImmigrationAction http:\/\/t.co\/77GNtYkwHv",
  "id" : 535617495323770880,
  "created_at" : "2014-11-21 02:15:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 83, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/uZbTvBxKEH",
      "expanded_url" : "http:\/\/snpy.tv\/1uZrFl2",
      "display_url" : "snpy.tv\/1uZrFl2"
    } ]
  },
  "geo" : { },
  "id_str" : "535612527283929088",
  "text" : "It's time to fix our broken immigration system. Watch President Obama announce his #ImmigrationAction. http:\/\/t.co\/uZbTvBxKEH",
  "id" : 535612527283929088,
  "created_at" : "2014-11-21 01:55:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaAmnesty",
      "indices" : [ 16, 29 ]
    }, {
      "text" : "ImmigrationAction",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535609451101712384",
  "text" : "RT @pfeiffer44: #ObamaAmnesty? As the President just made clear, amnesty is the immigration system we have today. #ImmigrationAction http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaAmnesty",
        "indices" : [ 0, 13 ]
      }, {
        "text" : "ImmigrationAction",
        "indices" : [ 98, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/o1bbvjcXiT",
        "expanded_url" : "http:\/\/snpy.tv\/1xHVaKC",
        "display_url" : "snpy.tv\/1xHVaKC"
      } ]
    },
    "geo" : { },
    "id_str" : "535609348840775680",
    "text" : "#ObamaAmnesty? As the President just made clear, amnesty is the immigration system we have today. #ImmigrationAction http:\/\/t.co\/o1bbvjcXiT",
    "id" : 535609348840775680,
    "created_at" : "2014-11-21 01:43:14 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 535609451101712384,
  "created_at" : "2014-11-21 01:43:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535606990794674176",
  "text" : "RT @repjohnlewis: The President did what was right, fair, and just to bring our fellow human beings out of the shadows and into the light.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535604781344362496",
    "text" : "The President did what was right, fair, and just to bring our fellow human beings out of the shadows and into the light.",
    "id" : 535604781344362496,
    "created_at" : "2014-11-21 01:25:05 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 535606990794674176,
  "created_at" : "2014-11-21 01:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 3, 18 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535605677876473856",
  "text" : "RT @HillaryClinton: Thanks to POTUS for taking action on immigration in the face of inaction. Now let\u2019s turn to permanent bipartisan reform\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 121, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535605199705239552",
    "text" : "Thanks to POTUS for taking action on immigration in the face of inaction. Now let\u2019s turn to permanent bipartisan reform. #ImmigrationAction",
    "id" : 535605199705239552,
    "created_at" : "2014-11-21 01:26:45 +0000",
    "user" : {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "protected" : false,
      "id_str" : "1339835893",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796243884636512260\/zHVoWqKV_normal.jpg",
      "id" : 1339835893,
      "verified" : true
    }
  },
  "id" : 535605677876473856,
  "created_at" : "2014-11-21 01:28:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 48, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/fQMRtRZUn9",
      "expanded_url" : "http:\/\/snpy.tv\/1zHWr1S",
      "display_url" : "snpy.tv\/1zHWr1S"
    } ]
  },
  "geo" : { },
  "id_str" : "535604578306101250",
  "text" : "\"We were strangers once, too.\" \u2014President Obama #ImmigrationAction http:\/\/t.co\/fQMRtRZUn9",
  "id" : 535604578306101250,
  "created_at" : "2014-11-21 01:24:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535602648741707776",
  "text" : "\"What makes us Americans is our shared commitment to an ideal\u2014that all of us are created equal.\" \u2014President Obama #ImmigrationAction",
  "id" : 535602648741707776,
  "created_at" : "2014-11-21 01:16:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535602377349296128",
  "text" : "\"My fellow Americans, we are and always will be a nation of immigrants. We were strangers once, too.\" \u2014President Obama #ImmigrationAction",
  "id" : 535602377349296128,
  "created_at" : "2014-11-21 01:15:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535601838196662273",
  "text" : "\"I\u2019ve seen the heartbreak and anxiety of children whose mothers might be taken away from them.\" \u2014President Obama #ImmigrationAction",
  "id" : 535601838196662273,
  "created_at" : "2014-11-21 01:13:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 112, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535601710115205121",
  "text" : "\"We need reasoned, thoughtful, compassionate debate that focuses on our hopes, not our fears.\" \u2014President Obama #ImmigrationAction",
  "id" : 535601710115205121,
  "created_at" : "2014-11-21 01:12:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535601606033563648",
  "text" : "RT @WHLive: \"We need more than politics as usual when it comes to immigration.\" \u2014President Obama #ImmigrationAction",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 85, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535601567093628928",
    "text" : "\"We need more than politics as usual when it comes to immigration.\" \u2014President Obama #ImmigrationAction",
    "id" : 535601567093628928,
    "created_at" : "2014-11-21 01:12:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 535601606033563648,
  "created_at" : "2014-11-21 01:12:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535601361501429760",
  "text" : "\"This debate is about something bigger. It\u2019s about who we are as a country, and who we want to be for future generations.\" \u2014Obama",
  "id" : 535601361501429760,
  "created_at" : "2014-11-21 01:11:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535601277086883840",
  "text" : "\"Our history and the facts show that immigrants are a net plus for our economy and our society.\" \u2014President Obama #ImmigrationAction",
  "id" : 535601277086883840,
  "created_at" : "2014-11-21 01:11:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 99, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535600923486064641",
  "text" : "\"I want to work with both parties to pass a more permanent legislative solution.\" \u2014President Obama #ImmigrationAction",
  "id" : 535600923486064641,
  "created_at" : "2014-11-21 01:09:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/535600854233915392\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/af7DG6DMbK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B27WInnCYAEeRiN.jpg",
      "id_str" : "535600849263681537",
      "id" : 535600849263681537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B27WInnCYAEeRiN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/af7DG6DMbK"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535600854233915392",
  "text" : "\"What I\u2019m describing is accountability\u2014a common-sense, middle ground approach.\" \u2014President Obama #ImmigrationAction http:\/\/t.co\/af7DG6DMbK",
  "id" : 535600854233915392,
  "created_at" : "2014-11-21 01:09:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535600757081255937",
  "text" : "\"Amnesty is the immigration system we have today\u2014millions of people who live here without paying their taxes or playing by the rules\" \u2014Obama",
  "id" : 535600757081255937,
  "created_at" : "2014-11-21 01:09:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 108, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535600716421672960",
  "text" : "RT @WHLive: \"It does not grant citizenship, or the right to stay here permanently.\" \u2014President Obama on his #ImmigrationAction",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 96, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535600687149629441",
    "text" : "\"It does not grant citizenship, or the right to stay here permanently.\" \u2014President Obama on his #ImmigrationAction",
    "id" : 535600687149629441,
    "created_at" : "2014-11-21 01:08:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 535600716421672960,
  "created_at" : "2014-11-21 01:08:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/535600528823046144\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/5XVKp5bRow",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B27V1dwCcAEi9lE.jpg",
      "id_str" : "535600520199565313",
      "id" : 535600520199565313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B27V1dwCcAEi9lE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5XVKp5bRow"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 60, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535600528823046144",
  "text" : "\"We\u2019re going to offer the following deal.\" \u2014President Obama #ImmigrationAction http:\/\/t.co\/5XVKp5bRow",
  "id" : 535600528823046144,
  "created_at" : "2014-11-21 01:08:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 86, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535600440147062784",
  "text" : "\"We do expect people who live in this country to play by the rules.\" \u2014President Obama #ImmigrationAction",
  "id" : 535600440147062784,
  "created_at" : "2014-11-21 01:07:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535600336522592256",
  "text" : "\"As my predecessor, President Bush, once put it: 'They are a part of American life.'\" \u2014Obama on undocumented workers",
  "id" : 535600336522592256,
  "created_at" : "2014-11-21 01:07:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535600263675920384",
  "text" : "\"Many of their kids are American-born or spent most of their lives here, and their hopes, dreams, and patriotism are just like ours.\" \u2014Obama",
  "id" : 535600263675920384,
  "created_at" : "2014-11-21 01:07:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535600123942674432",
  "text" : "\"We\u2019re going to keep focusing enforcement resources on actual threats to our security. Felons, not families.\" \u2014Obama #ImmigrationAction",
  "id" : 535600123942674432,
  "created_at" : "2014-11-21 01:06:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 88, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535599973287485440",
  "text" : "\"Even as we are a nation of immigrants, we are also a nation of laws.\" \u2014President Obama #ImmigrationAction",
  "id" : 535599973287485440,
  "created_at" : "2014-11-21 01:05:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535599930513977344",
  "text" : "\"We\u2019ll take steps to deal responsibly with the millions of undocumented immigrants who...live in our country\" \u2014Obama #ImmigrationAction",
  "id" : 535599930513977344,
  "created_at" : "2014-11-21 01:05:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535599875283369984",
  "text" : "\"I will make it easier and faster for high-skilled immigrants, graduates, and entrepreneurs to stay and contribute to our economy.\" \u2014Obama",
  "id" : 535599875283369984,
  "created_at" : "2014-11-21 01:05:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/535599823550808064\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/o2ALLbjQGo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B27VM4ACMAAMuId.jpg",
      "id_str" : "535599822871343104",
      "id" : 535599822871343104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B27VM4ACMAAMuId.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/o2ALLbjQGo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535599823550808064",
  "text" : "\"First, we\u2019ll build on our progress at the border with additional resources for our law enforcement personnel\" \u2014Obama http:\/\/t.co\/o2ALLbjQGo",
  "id" : 535599823550808064,
  "created_at" : "2014-11-21 01:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535599717422354433",
  "text" : "\"There are actions I have the legal authority to take as President...that will help make our immigration system more fair &amp; just.\" \u2014Obama",
  "id" : 535599717422354433,
  "created_at" : "2014-11-21 01:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535599652385480704",
  "text" : "\"I continue to believe that the best way to solve this problem is by working together to pass that kind of common-sense law.\" \u2014Obama",
  "id" : 535599652385480704,
  "created_at" : "2014-11-21 01:04:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535599601336598528",
  "text" : "\"For a year and a half now, Republican leaders in the House have refused to allow that simple vote.\" \u2014Obama on immigration reform",
  "id" : 535599601336598528,
  "created_at" : "2014-11-21 01:04:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535599553802547200",
  "text" : "RT @WHLive: \"Last year, 68 Democrats, Republicans, and Independents came together to pass a bipartisan bill in the Senate.\" \u2014Obama #Immigra\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 119, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535599516544548864",
    "text" : "\"Last year, 68 Democrats, Republicans, and Independents came together to pass a bipartisan bill in the Senate.\" \u2014Obama #ImmigrationAction",
    "id" : 535599516544548864,
    "created_at" : "2014-11-21 01:04:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 535599553802547200,
  "created_at" : "2014-11-21 01:04:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/dptFgnRK24",
      "expanded_url" : "http:\/\/go.wh.gov\/7h2wF5",
      "display_url" : "go.wh.gov\/7h2wF5"
    } ]
  },
  "geo" : { },
  "id_str" : "535599408700616705",
  "text" : "\"Over the past six years, illegal border crossings have been cut by more than half.\" \u2014Obama: http:\/\/t.co\/dptFgnRK24 #ImmigrationAction",
  "id" : 535599408700616705,
  "created_at" : "2014-11-21 01:03:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535599337888161792",
  "text" : "\"Today, we have more agents and technology deployed to secure our southern border than at any time in our history\" \u2014Obama #ImmigrationAction",
  "id" : 535599337888161792,
  "created_at" : "2014-11-21 01:03:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535599228202917890",
  "text" : "\"When I took office, I committed to fixing this broken immigration system. And I began by doing what I could to secure our borders.\" \u2014Obama",
  "id" : 535599228202917890,
  "created_at" : "2014-11-21 01:03:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535599180379480065",
  "text" : "RT @WHLive: \"Undocumented immigrants who desperately want to embrace those responsibilities see little option but to remain in the shadows.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535599154576117760",
    "text" : "\"Undocumented immigrants who desperately want to embrace those responsibilities see little option but to remain in the shadows.\" \u2014Obama",
    "id" : 535599154576117760,
    "created_at" : "2014-11-21 01:02:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 535599180379480065,
  "created_at" : "2014-11-21 01:02:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 84, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535599045423554560",
  "text" : "\"Today, our immigration system is broken, and everybody knows it.\" \u2014President Obama #ImmigrationAction",
  "id" : 535599045423554560,
  "created_at" : "2014-11-21 01:02:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535598951521476608",
  "text" : "\"For more than 200 years, our tradition of welcoming immigrants from around the globe has given us a tremendous advantage.\" \u2014President Obama",
  "id" : 535598951521476608,
  "created_at" : "2014-11-21 01:01:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/niZoNzZNFY",
      "expanded_url" : "http:\/\/wh.gov\/immigration-action",
      "display_url" : "wh.gov\/immigration-ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535598874795065344",
  "text" : "Happening now: President Obama announces new steps to fix our broken immigration system \u2192 http:\/\/t.co\/niZoNzZNFY #ImmigrationAction",
  "id" : 535598874795065344,
  "created_at" : "2014-11-21 01:01:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 40, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/tqb6H23QH5",
      "expanded_url" : "http:\/\/go.wh.gov\/msMfGM",
      "display_url" : "go.wh.gov\/msMfGM"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/m6Tm4oIo99",
      "expanded_url" : "https:\/\/vine.co\/v\/OJpbbBpebbw",
      "display_url" : "vine.co\/v\/OJpbbBpebbw"
    } ]
  },
  "geo" : { },
  "id_str" : "535590585101324288",
  "text" : "President Obama's ready to announce his #ImmigrationAction. Watch live at 8pm ET: http:\/\/t.co\/tqb6H23QH5 https:\/\/t.co\/m6Tm4oIo99",
  "id" : 535590585101324288,
  "created_at" : "2014-11-21 00:28:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535585380800548864\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/kO5rVUL71N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B27H0LUCUAAm5X1.jpg",
      "id_str" : "535585104907620352",
      "id" : 535585104907620352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B27H0LUCUAAm5X1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kO5rVUL71N"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535585380800548864",
  "text" : "President Obama's acting so more than 4 million undocumented immigrants can play by the rules. #ImmigrationAction http:\/\/t.co\/kO5rVUL71N",
  "id" : 535585380800548864,
  "created_at" : "2014-11-21 00:08:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/535580801144868864\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/cu1UZZRvAK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B27DxpJCMAAKDSe.jpg",
      "id_str" : "535580663328419840",
      "id" : 535580663328419840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B27DxpJCMAAKDSe.jpg",
      "sizes" : [ {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cu1UZZRvAK"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 44, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/tqb6H23QH5",
      "expanded_url" : "http:\/\/go.wh.gov\/msMfGM",
      "display_url" : "go.wh.gov\/msMfGM"
    } ]
  },
  "geo" : { },
  "id_str" : "535580801144868864",
  "text" : "President Obama's making final edits to his #ImmigrationAction address. Watch at 8pm ET \u2192 http:\/\/t.co\/tqb6H23QH5 http:\/\/t.co\/cu1UZZRvAK",
  "id" : 535580801144868864,
  "created_at" : "2014-11-20 23:49:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/535572782101180417\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/SPQGorphKf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B268lfyCQAEcJ0J.jpg",
      "id_str" : "535572758076211201",
      "id" : 535572758076211201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B268lfyCQAEcJ0J.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SPQGorphKf"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 94, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535572782101180417",
  "text" : "Worth sharing: Here are the new steps President Obama's taking to fix our immigration system. #ImmigrationAction http:\/\/t.co\/SPQGorphKf",
  "id" : 535572782101180417,
  "created_at" : "2014-11-20 23:17:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/niZoNzZNFY",
      "expanded_url" : "http:\/\/wh.gov\/immigration-action",
      "display_url" : "wh.gov\/immigration-ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535570089932636162",
  "text" : "Here are the new steps I'm announcing tonight to bring more accountability &amp; security to our immigration system: http:\/\/t.co\/niZoNzZNFY -bo",
  "id" : 535570089932636162,
  "created_at" : "2014-11-20 23:07:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PunditFact",
      "screen_name" : "PunditFact",
      "indices" : [ 3, 14 ],
      "id_str" : "1733274007",
      "id" : 1733274007
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/BON4vgBZ5h",
      "expanded_url" : "http:\/\/www.politifact.com\/punditfact\/statements\/2014\/nov\/20\/rachel-maddow\/maddow-obama-and-ghw-bush-solo-immigration-moves-a\/",
      "display_url" : "politifact.com\/punditfact\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535561452682092544",
  "text" : "RT @PunditFact: Maddow says Obama's proposed immigration move 'same scale' as action by GHW Bush http:\/\/t.co\/BON4vgBZ5h http:\/\/t.co\/ETUisjO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PunditFact\/status\/535556762204897280\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/ETUisjODCe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B26uCY0IEAM0ieV.jpg",
        "id_str" : "535556761747722243",
        "id" : 535556761747722243,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B26uCY0IEAM0ieV.jpg",
        "sizes" : [ {
          "h" : 293,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 541,
          "resize" : "fit",
          "w" : 628
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 517,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 541,
          "resize" : "fit",
          "w" : 628
        } ],
        "display_url" : "pic.twitter.com\/ETUisjODCe"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/BON4vgBZ5h",
        "expanded_url" : "http:\/\/www.politifact.com\/punditfact\/statements\/2014\/nov\/20\/rachel-maddow\/maddow-obama-and-ghw-bush-solo-immigration-moves-a\/",
        "display_url" : "politifact.com\/punditfact\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "535556762204897280",
    "text" : "Maddow says Obama's proposed immigration move 'same scale' as action by GHW Bush http:\/\/t.co\/BON4vgBZ5h http:\/\/t.co\/ETUisjODCe",
    "id" : 535556762204897280,
    "created_at" : "2014-11-20 22:14:16 +0000",
    "user" : {
      "name" : "PunditFact",
      "screen_name" : "PunditFact",
      "protected" : false,
      "id_str" : "1733274007",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657302869343793152\/WjZLeSMn_normal.jpg",
      "id" : 1733274007,
      "verified" : true
    }
  },
  "id" : 535561452682092544,
  "created_at" : "2014-11-20 22:32:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/niZoNzZNFY",
      "expanded_url" : "http:\/\/wh.gov\/immigration-action",
      "display_url" : "wh.gov\/immigration-ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535547041691086848",
  "text" : "Every President since Eisenhower has taken action to address immigration. Take a look back: http:\/\/t.co\/niZoNzZNFY #ImmigrationAction",
  "id" : 535547041691086848,
  "created_at" : "2014-11-20 21:35:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 26, 29 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyBirthday",
      "indices" : [ 3, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/djDvrfr9Wn",
      "expanded_url" : "https:\/\/vine.co\/v\/OJwnMa0AYaL",
      "display_url" : "vine.co\/v\/OJwnMa0AYaL"
    } ]
  },
  "geo" : { },
  "id_str" : "535531466307149824",
  "text" : "\u266B \"#HappyBirthday to you, @VP,\" as sung by the crowd at 5th Global Entrepreneurship Summit in Marrakech, Morocco. \u266B https:\/\/t.co\/djDvrfr9Wn",
  "id" : 535531466307149824,
  "created_at" : "2014-11-20 20:33:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/niZoNzZNFY",
      "expanded_url" : "http:\/\/wh.gov\/immigration-action",
      "display_url" : "wh.gov\/immigration-ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535514096754368513",
  "text" : "\u201CWe define ourselves as a nation of immigrants. That\u2019s who we are\u2014in our bones.\" \u2014President Obama: http:\/\/t.co\/niZoNzZNFY #ImmigrationAction",
  "id" : 535514096754368513,
  "created_at" : "2014-11-20 19:24:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 80, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/eIjIo5SgVu",
      "expanded_url" : "http:\/\/wh.gov\/immigration-action",
      "display_url" : "wh.gov\/immigration-ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535502700499050496",
  "text" : "RT @pfeiffer44: Take a look back at how Presidents from both parties have taken #ImmigrationAction: http:\/\/t.co\/eIjIo5SgVu http:\/\/t.co\/8bPy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535498888023900160\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/8bPyJ7QYmz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B25zY3DCYAEEnsE.jpg",
        "id_str" : "535492276634411009",
        "id" : 535492276634411009,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B25zY3DCYAEEnsE.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8bPyJ7QYmz"
      } ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 64, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/eIjIo5SgVu",
        "expanded_url" : "http:\/\/wh.gov\/immigration-action",
        "display_url" : "wh.gov\/immigration-ac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "535500933808259072",
    "text" : "Take a look back at how Presidents from both parties have taken #ImmigrationAction: http:\/\/t.co\/eIjIo5SgVu http:\/\/t.co\/8bPyJ7QYmz",
    "id" : 535500933808259072,
    "created_at" : "2014-11-20 18:32:26 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 535502700499050496,
  "created_at" : "2014-11-20 18:39:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535498888023900160\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/QxljXOTpuc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B25zY3DCYAEEnsE.jpg",
      "id_str" : "535492276634411009",
      "id" : 535492276634411009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B25zY3DCYAEEnsE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QxljXOTpuc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/aahVLPoYN6",
      "expanded_url" : "http:\/\/wh.gov\/immigration-action",
      "display_url" : "wh.gov\/immigration-ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535498888023900160",
  "text" : "At 8pm ET, President Obama will announce new steps to fix our broken immigration system \u2192 http:\/\/t.co\/aahVLPoYN6 http:\/\/t.co\/QxljXOTpuc",
  "id" : 535498888023900160,
  "created_at" : "2014-11-20 18:24:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEMmedals",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535478968141369344",
  "text" : "\u201CWe have to broaden opportunities for young scientists, especially young girls and minorities, to enter the field.\u201D \u2014Obama #STEMmedals",
  "id" : 535478968141369344,
  "created_at" : "2014-11-20 17:05:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEMmedals",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535478331525705728",
  "text" : "\u201CSo much of what has set us apart economically, culturally, is our commitment to science.\u201D \u2014President Obama #STEMmedals",
  "id" : 535478331525705728,
  "created_at" : "2014-11-20 17:02:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEMmedals",
      "indices" : [ 136, 147 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/bUnsrV4OqA",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "535475829363331072",
  "text" : "Watch President Obama award the National Medals of Science &amp; National Medals of Technology &amp; Innovation: http:\/\/t.co\/bUnsrV4OqA #STEMmedals",
  "id" : 535475829363331072,
  "created_at" : "2014-11-20 16:52:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senate Democrats",
      "screen_name" : "SenateDems",
      "indices" : [ 3, 14 ],
      "id_str" : "73238146",
      "id" : 73238146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535470022454288384",
  "text" : "RT @SenateDems: Sure, \u201CRepublicans did it, too.\u201D \n\nBut importantly: Republicans did it because it\u2019s legal and helped improve America. http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SenateDems\/status\/535457897086746624\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/QSNsCLQdi0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B25UBLdCYAAKyxy.png",
        "id_str" : "535457784934850560",
        "id" : 535457784934850560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B25UBLdCYAAKyxy.png",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/QSNsCLQdi0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535457897086746624",
    "text" : "Sure, \u201CRepublicans did it, too.\u201D \n\nBut importantly: Republicans did it because it\u2019s legal and helped improve America. http:\/\/t.co\/QSNsCLQdi0",
    "id" : 535457897086746624,
    "created_at" : "2014-11-20 15:41:25 +0000",
    "user" : {
      "name" : "Senate Democrats",
      "screen_name" : "SenateDems",
      "protected" : false,
      "id_str" : "73238146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1214915758\/Reid_and_Dem_Senate_leadership_normal.jpg",
      "id" : 73238146,
      "verified" : true
    }
  },
  "id" : 535470022454288384,
  "created_at" : "2014-11-20 16:29:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 88, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535458964188585985",
  "text" : "RT @NancyPelosi: Prez Obama has clear legal authority &amp; executive precedent to take #ImmigrationAction. Americans can no longer wait. http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/535450185896570880\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/obAXs4aWjz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B25NG0vCMAA0K6j.jpg",
        "id_str" : "535450185334140928",
        "id" : 535450185334140928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B25NG0vCMAA0K6j.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/obAXs4aWjz"
      } ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 71, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535450185896570880",
    "text" : "Prez Obama has clear legal authority &amp; executive precedent to take #ImmigrationAction. Americans can no longer wait. http:\/\/t.co\/obAXs4aWjz",
    "id" : 535450185896570880,
    "created_at" : "2014-11-20 15:10:47 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 535458964188585985,
  "created_at" : "2014-11-20 15:45:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JORGE RAMOS",
      "screen_name" : "jorgeramosnews",
      "indices" : [ 3, 18 ],
      "id_str" : "110213431",
      "id" : 110213431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535454547297050624",
  "text" : "RT @jorgeramosnews: If Republicans really want immigration reform in Congress, they'll have many months to do it before executive action ki\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535410657647394817",
    "text" : "If Republicans really want immigration reform in Congress, they'll have many months to do it before executive action kicks in. Your choice",
    "id" : 535410657647394817,
    "created_at" : "2014-11-20 12:33:42 +0000",
    "user" : {
      "name" : "JORGE RAMOS",
      "screen_name" : "jorgeramosnews",
      "protected" : false,
      "id_str" : "110213431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1136679713\/_T8I5829_normal.jpg",
      "id" : 110213431,
      "verified" : true
    }
  },
  "id" : 535454547297050624,
  "created_at" : "2014-11-20 15:28:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "The Hill",
      "screen_name" : "thehill",
      "indices" : [ 102, 110 ],
      "id_str" : "1917731",
      "id" : 1917731
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/qrcEnLEy3x",
      "expanded_url" : "http:\/\/bit.ly\/1xtbH3J",
      "display_url" : "bit.ly\/1xtbH3J"
    } ]
  },
  "geo" : { },
  "id_str" : "535449283651055616",
  "text" : "RT @Schultz44: Bill Clinton: Obama on 'firm ground' with immigration order http:\/\/t.co\/qrcEnLEy3x via @thehill",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Hill",
        "screen_name" : "thehill",
        "indices" : [ 87, 95 ],
        "id_str" : "1917731",
        "id" : 1917731
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/qrcEnLEy3x",
        "expanded_url" : "http:\/\/bit.ly\/1xtbH3J",
        "display_url" : "bit.ly\/1xtbH3J"
      } ]
    },
    "geo" : { },
    "id_str" : "535443399294599169",
    "text" : "Bill Clinton: Obama on 'firm ground' with immigration order http:\/\/t.co\/qrcEnLEy3x via @thehill",
    "id" : 535443399294599169,
    "created_at" : "2014-11-20 14:43:49 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 535449283651055616,
  "created_at" : "2014-11-20 15:07:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535245790302961664\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/H6zxjlhkhm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B22TEnTCEAAmHJ6.jpg",
      "id_str" : "535245638204526592",
      "id" : 535245638204526592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B22TEnTCEAAmHJ6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/H6zxjlhkhm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/GjHjoKu34E",
      "expanded_url" : "http:\/\/go.wh.gov\/sT4sMQ",
      "display_url" : "go.wh.gov\/sT4sMQ"
    } ]
  },
  "geo" : { },
  "id_str" : "535245790302961664",
  "text" : "\"We\u2019ve got to bring the world to every child\u2019s fingertips.\" \u2014President Obama on ConnectED: http:\/\/t.co\/GjHjoKu34E http:\/\/t.co\/H6zxjlhkhm",
  "id" : 535245790302961664,
  "created_at" : "2014-11-20 01:38:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535234642312720384\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/1o3blGKBUs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B22JCcDCQAA7-Sr.jpg",
      "id_str" : "535234605708623872",
      "id" : 535234605708623872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B22JCcDCQAA7-Sr.jpg",
      "sizes" : [ {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1060,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1o3blGKBUs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/dv1S6Lb03L",
      "expanded_url" : "http:\/\/go.wh.gov\/nybDXZ",
      "display_url" : "go.wh.gov\/nybDXZ"
    } ]
  },
  "geo" : { },
  "id_str" : "535234642312720384",
  "text" : "Seven score and 11 years ago today, President Lincoln delivered the Gettysburg Address \u2192 http:\/\/t.co\/dv1S6Lb03L http:\/\/t.co\/1o3blGKBUs",
  "id" : 535234642312720384,
  "created_at" : "2014-11-20 00:54:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535168161487028224",
  "text" : "RT @Cecilia44: A history of Presidents who have used executive authority on behalf of immigrants. Lots of them. From both parties. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/GT5NSMjtVZ",
        "expanded_url" : "http:\/\/goo.gl\/j4bJQn",
        "display_url" : "goo.gl\/j4bJQn"
      } ]
    },
    "geo" : { },
    "id_str" : "533731389481291776",
    "text" : "A history of Presidents who have used executive authority on behalf of immigrants. Lots of them. From both parties. http:\/\/t.co\/GT5NSMjtVZ",
    "id" : 533731389481291776,
    "created_at" : "2014-11-15 21:20:54 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 535168161487028224,
  "created_at" : "2014-11-19 20:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535148207513550848",
  "text" : "RT @NancyPelosi: Tomorrow at 8pm ET, President Obama will lay out new steps he's taking to fix our broken immigration system: http:\/\/t.co\/r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/rUgQpRd0NZ",
        "expanded_url" : "http:\/\/go.wh.gov\/sRN9yZ",
        "display_url" : "go.wh.gov\/sRN9yZ"
      } ]
    },
    "geo" : { },
    "id_str" : "535146744238329856",
    "text" : "Tomorrow at 8pm ET, President Obama will lay out new steps he's taking to fix our broken immigration system: http:\/\/t.co\/rUgQpRd0NZ",
    "id" : 535146744238329856,
    "created_at" : "2014-11-19 19:05:01 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 535148207513550848,
  "created_at" : "2014-11-19 19:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535147427322683393",
  "text" : "RT @SenatorReid: Today marks the 510th day that the Republican-led House has refused to address our broken immigration system. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenatorReid\/status\/535146160114384896\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/wyG6EzBGTK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B204ZWrCMAAXzLq.png",
        "id_str" : "535145938960920576",
        "id" : 535145938960920576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B204ZWrCMAAXzLq.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 470
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 470
        } ],
        "display_url" : "pic.twitter.com\/wyG6EzBGTK"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535146160114384896",
    "text" : "Today marks the 510th day that the Republican-led House has refused to address our broken immigration system. http:\/\/t.co\/wyG6EzBGTK",
    "id" : 535146160114384896,
    "created_at" : "2014-11-19 19:02:41 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 535147427322683393,
  "created_at" : "2014-11-19 19:07:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JORGE RAMOS",
      "screen_name" : "jorgeramosnews",
      "indices" : [ 3, 18 ],
      "id_str" : "110213431",
      "id" : 110213431
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535140712245768193",
  "text" : "RT @jorgeramosnews: Univision transmitir\u00E1 en vivo el discurso de Obama ma\u00F1ana sobre la acci\u00F3n ejecutiva. Muy importante. 8pm est",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535139383423549440",
    "text" : "Univision transmitir\u00E1 en vivo el discurso de Obama ma\u00F1ana sobre la acci\u00F3n ejecutiva. Muy importante. 8pm est",
    "id" : 535139383423549440,
    "created_at" : "2014-11-19 18:35:46 +0000",
    "user" : {
      "name" : "JORGE RAMOS",
      "screen_name" : "jorgeramosnews",
      "protected" : false,
      "id_str" : "110213431",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1136679713\/_T8I5829_normal.jpg",
      "id" : 110213431,
      "verified" : true
    }
  },
  "id" : 535140712245768193,
  "created_at" : "2014-11-19 18:41:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535138270393270272",
  "text" : "RT @lacasablanca: Ma\u00F1ana a las 8 PM ET el Presidente Obama hablar\u00E1 sobre las pr\u00F3ximas medidas para arreglar nuestro sistema migratorio http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/JXgqbafWT9",
        "expanded_url" : "https:\/\/www.facebook.com\/whitehouse.espanol",
        "display_url" : "facebook.com\/whitehouse.esp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "535135412327424001",
    "text" : "Ma\u00F1ana a las 8 PM ET el Presidente Obama hablar\u00E1 sobre las pr\u00F3ximas medidas para arreglar nuestro sistema migratorio https:\/\/t.co\/JXgqbafWT9",
    "id" : 535135412327424001,
    "created_at" : "2014-11-19 18:19:59 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 535138270393270272,
  "created_at" : "2014-11-19 18:31:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/tsLHuHb3Ed",
      "expanded_url" : "http:\/\/go.wh.gov\/sRN9yZ",
      "display_url" : "go.wh.gov\/sRN9yZ"
    } ]
  },
  "geo" : { },
  "id_str" : "535131572760879104",
  "text" : "President Obama will address the nation tomorrow night on new steps he's taking to fix our broken immigration system: http:\/\/t.co\/tsLHuHb3Ed",
  "id" : 535131572760879104,
  "created_at" : "2014-11-19 18:04:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureReady",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/KonYkgyXEd",
      "expanded_url" : "http:\/\/wh.gov\/ConnectED",
      "display_url" : "wh.gov\/ConnectED"
    } ]
  },
  "geo" : { },
  "id_str" : "535110760729300992",
  "text" : "\"Every child deserves a shot at a world-class education.\" \u2014President Obama: http:\/\/t.co\/KonYkgyXEd #FutureReady",
  "id" : 535110760729300992,
  "created_at" : "2014-11-19 16:42:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535109087394942976",
  "text" : "RT @WHLive: \"All the wireless devices and fancy software in the world won\u2019t make a difference unless we have great teachers in the classroo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "535109051898548224",
    "text" : "\"All the wireless devices and fancy software in the world won\u2019t make a difference unless we have great teachers in the classroom.\" \u2014Obama",
    "id" : 535109051898548224,
    "created_at" : "2014-11-19 16:35:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 535109087394942976,
  "created_at" : "2014-11-19 16:35:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureReady",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/KonYkgyXEd",
      "expanded_url" : "http:\/\/wh.gov\/ConnectED",
      "display_url" : "wh.gov\/ConnectED"
    } ]
  },
  "geo" : { },
  "id_str" : "535108713560817664",
  "text" : "\"You can find out how your school district could benefit at http:\/\/t.co\/KonYkgyXEd.\" \u2014President Obama on ConnectED #FutureReady",
  "id" : 535108713560817664,
  "created_at" : "2014-11-19 16:33:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/n3rHoOWJ6B",
      "expanded_url" : "http:\/\/wh.gov\/connected",
      "display_url" : "wh.gov\/connected"
    } ]
  },
  "geo" : { },
  "id_str" : "535108503111622656",
  "text" : "RT @WHLive: \"So far, 10 companies have made commitments totaling more than $2 billion.\" \u2014President Obama: http:\/\/t.co\/n3rHoOWJ6B #FutureRea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FutureReady",
        "indices" : [ 117, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/n3rHoOWJ6B",
        "expanded_url" : "http:\/\/wh.gov\/connected",
        "display_url" : "wh.gov\/connected"
      } ]
    },
    "geo" : { },
    "id_str" : "535108471964725248",
    "text" : "\"So far, 10 companies have made commitments totaling more than $2 billion.\" \u2014President Obama: http:\/\/t.co\/n3rHoOWJ6B #FutureReady",
    "id" : 535108471964725248,
    "created_at" : "2014-11-19 16:32:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 535108503111622656,
  "created_at" : "2014-11-19 16:33:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureReady",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/KonYkgyXEd",
      "expanded_url" : "http:\/\/wh.gov\/ConnectED",
      "display_url" : "wh.gov\/ConnectED"
    } ]
  },
  "geo" : { },
  "id_str" : "535108292905664512",
  "text" : "\"We\u2019ve got to bring the world to every child\u2019s fingertips.\" \u2014President Obama on ConnectED: http:\/\/t.co\/KonYkgyXEd #FutureReady",
  "id" : 535108292905664512,
  "created_at" : "2014-11-19 16:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535107716532801536",
  "text" : "\"We need to step up our game...to make sure that every child in America can go as far as their talent and hard work...will take them\" \u2014Obama",
  "id" : 535107716532801536,
  "created_at" : "2014-11-19 16:29:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureReady",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535107404854095873",
  "text" : "\"We have to make sure that no striving young person is priced out of a college education.\" \u2014President Obama #FutureReady",
  "id" : 535107404854095873,
  "created_at" : "2014-11-19 16:28:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535107305667166208\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/XpmLsAaXS2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B20VP6TCAAAP4Oq.jpg",
      "id_str" : "535107293818257408",
      "id" : 535107293818257408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B20VP6TCAAAP4Oq.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XpmLsAaXS2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535107305667166208",
  "text" : "\"Dropout rates are down. The graduation rate is the highest on record.\" \u2014President Obama http:\/\/t.co\/XpmLsAaXS2",
  "id" : 535107305667166208,
  "created_at" : "2014-11-19 16:28:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535107114494996480\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/KpPXrSnsfc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B20VFLFCQAACEfk.jpg",
      "id_str" : "535107109344395264",
      "id" : 535107109344395264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B20VFLFCQAACEfk.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KpPXrSnsfc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535107114494996480",
  "text" : "\"For the first time in more than six years, the unemployment rate is below 6%.\" \u2014President Obama http:\/\/t.co\/KpPXrSnsfc",
  "id" : 535107114494996480,
  "created_at" : "2014-11-19 16:27:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535107017518497792\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/l4N1kVXZiz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B20U-yBCMAA0hwR.jpg",
      "id_str" : "535106999537512448",
      "id" : 535106999537512448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B20U-yBCMAA0hwR.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/l4N1kVXZiz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535107017518497792",
  "text" : "\"Our businesses have added 10.6 million new jobs during the course of 56 months.\" \u2014President Obama http:\/\/t.co\/l4N1kVXZiz",
  "id" : 535107017518497792,
  "created_at" : "2014-11-19 16:27:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureReady",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535106526466158593",
  "text" : "\"We are here to take another step toward making sure that all our kids get the education they need to compete\" \u2014Obama #FutureReady",
  "id" : 535106526466158593,
  "created_at" : "2014-11-19 16:25:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureReady",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/Moqgf0Iwri",
      "expanded_url" : "http:\/\/go.wh.gov\/AogmBZ",
      "display_url" : "go.wh.gov\/AogmBZ"
    } ]
  },
  "geo" : { },
  "id_str" : "535106351618215936",
  "text" : "Watch live: President Obama speaks at a ConnectED conference \u2192 http:\/\/t.co\/Moqgf0Iwri #FutureReady",
  "id" : 535106351618215936,
  "created_at" : "2014-11-19 16:24:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535096700071731200\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/XBiPja7XeY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B20LihhCYAA1fhy.jpg",
      "id_str" : "535096618467352576",
      "id" : 535096618467352576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B20LihhCYAA1fhy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/XBiPja7XeY"
    } ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 33, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Moqgf0Iwri",
      "expanded_url" : "http:\/\/go.wh.gov\/AogmBZ",
      "display_url" : "go.wh.gov\/AogmBZ"
    } ]
  },
  "geo" : { },
  "id_str" : "535096700071731200",
  "text" : "Watch President Obama speak at a #ConnectED conference at 10:50am ET \u2192 http:\/\/t.co\/Moqgf0Iwri http:\/\/t.co\/XBiPja7XeY",
  "id" : 535096700071731200,
  "created_at" : "2014-11-19 15:46:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/535094435403407363\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ibYhiaM3hK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B20JLb6CIAAmMDe.jpg",
      "id_str" : "535094022801334272",
      "id" : 535094022801334272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B20JLb6CIAAmMDe.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 627,
        "resize" : "fit",
        "w" : 1255
      } ],
      "display_url" : "pic.twitter.com\/ibYhiaM3hK"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/xstJfQpT8K",
      "expanded_url" : "http:\/\/wh.gov\/filmfestival",
      "display_url" : "wh.gov\/filmfestival"
    } ]
  },
  "geo" : { },
  "id_str" : "535094435403407363",
  "text" : "Calling all student filmmakers! Submit your video for the second-annual #WHFilmFest \u2192 http:\/\/t.co\/xstJfQpT8K http:\/\/t.co\/ibYhiaM3hK",
  "id" : 535094435403407363,
  "created_at" : "2014-11-19 15:37:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/8SBAGY6lN7",
      "expanded_url" : "http:\/\/go.wh.gov\/hdg6aF",
      "display_url" : "go.wh.gov\/hdg6aF"
    } ]
  },
  "geo" : { },
  "id_str" : "534885619336753152",
  "text" : "Ryan P. wrote the President: \"There are millions of people who will never forget what you did for us.\u201D http:\/\/t.co\/8SBAGY6lN7 #GetCovered",
  "id" : 534885619336753152,
  "created_at" : "2014-11-19 01:47:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/534838508163461121\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/wFakVI95Ug",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2wguqVCMAEkMKa.jpg",
      "id_str" : "534838441758830593",
      "id" : 534838441758830593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2wguqVCMAEkMKa.jpg",
      "sizes" : [ {
        "h" : 701,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 411,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 701,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wFakVI95Ug"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/iJbmdd6P8n",
      "expanded_url" : "http:\/\/toolkit.climate.gov",
      "display_url" : "toolkit.climate.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534838508163461121",
  "text" : "Worth sharing: Here's a new toolkit to help communities respond to climate change \u2192 http:\/\/t.co\/iJbmdd6P8n http:\/\/t.co\/wFakVI95Ug",
  "id" : 534838508163461121,
  "created_at" : "2014-11-18 22:40:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/534783594758021122\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/7IX4jDKKam",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2vu0mVCUAAjsw6.jpg",
      "id_str" : "534783568182923264",
      "id" : 534783568182923264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2vu0mVCUAAjsw6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7IX4jDKKam"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/2S7CGldNyn",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534783594758021122",
  "text" : "Right now, you can sign up for health coverage. Find a plan that works for you at http:\/\/t.co\/2S7CGldNyn #GetCovered http:\/\/t.co\/7IX4jDKKam",
  "id" : 534783594758021122,
  "created_at" : "2014-11-18 19:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/534768307857940480\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/oTKVrhlgML",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2vg4CWCUAAurru.jpg",
      "id_str" : "534768234080129024",
      "id" : 534768234080129024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2vg4CWCUAAurru.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oTKVrhlgML"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/RxPSPexfVE",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "534768307857940480",
  "text" : "President Obama announced a new target to cut U.S. carbon pollution by 26-28% \u2192 http:\/\/t.co\/RxPSPexfVE #ActOnClimate http:\/\/t.co\/oTKVrhlgML",
  "id" : 534768307857940480,
  "created_at" : "2014-11-18 18:01:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/534739351255519232\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/oRkIuEPIbc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2vGhU4CcAAX5-5.png",
      "id_str" : "534739256615268352",
      "id" : 534739256615268352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2vGhU4CcAAX5-5.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 1129
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 98,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oRkIuEPIbc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534739351255519232",
  "text" : "\"I strongly condemn today\u2019s terrorist attack on worshipers at a synagogue in Jerusalem.\" \u2014President Obama http:\/\/t.co\/oRkIuEPIbc",
  "id" : 534739351255519232,
  "created_at" : "2014-11-18 16:06:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/534732922297675776\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KAgBMdZnx7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2vAuqVCAAIgmcJ.jpg",
      "id_str" : "534732888642551810",
      "id" : 534732888642551810,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2vAuqVCAAIgmcJ.jpg",
      "sizes" : [ {
        "h" : 712,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 417,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 712,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KAgBMdZnx7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/LFR1FnK7xy",
      "expanded_url" : "http:\/\/toolkit.climate.gov",
      "display_url" : "toolkit.climate.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534732922297675776",
  "text" : "Climate change is one of the biggest threats we face. It's time to help communities respond \u2192 http:\/\/t.co\/LFR1FnK7xy http:\/\/t.co\/KAgBMdZnx7",
  "id" : 534732922297675776,
  "created_at" : "2014-11-18 15:40:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/534716282021502976\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/SPswoFO7gz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2uxCNfCcAAoqau.jpg",
      "id_str" : "534715632311234560",
      "id" : 534715632311234560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2uxCNfCcAAoqau.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SPswoFO7gz"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 58, 62 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/nSVgCcRYlE",
      "expanded_url" : "http:\/\/wh.gov\/get-covered",
      "display_url" : "wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "534716282021502976",
  "text" : "Millions have signed up for health coverage thanks to the #ACA. Help even more #GetCovered \u2192 http:\/\/t.co\/nSVgCcRYlE http:\/\/t.co\/SPswoFO7gz",
  "id" : 534716282021502976,
  "created_at" : "2014-11-18 14:34:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "indices" : [ 3, 14 ],
      "id_str" : "15693493",
      "id" : 15693493
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/funnyordie\/status\/534464310311804928\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/7eXJ0nkpEx",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B2rMdFPCYAA43WX.png",
      "id_str" : "534464305790345216",
      "id" : 534464305790345216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B2rMdFPCYAA43WX.png",
      "sizes" : [ {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 282,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/7eXJ0nkpEx"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/LJ197TD3dI",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534485782984011777",
  "text" : "RT @funnyordie: Open enrollment is back! #GetCovered at http:\/\/t.co\/LJ197TD3dI, it's as easy as clicking a button. http:\/\/t.co\/7eXJ0nkpEx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/funnyordie\/status\/534464310311804928\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/7eXJ0nkpEx",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B2rMdFPCYAA43WX.png",
        "id_str" : "534464305790345216",
        "id" : 534464305790345216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B2rMdFPCYAA43WX.png",
        "sizes" : [ {
          "h" : 282,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 282,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/7eXJ0nkpEx"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/LJ197TD3dI",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "534464310311804928",
    "text" : "Open enrollment is back! #GetCovered at http:\/\/t.co\/LJ197TD3dI, it's as easy as clicking a button. http:\/\/t.co\/7eXJ0nkpEx",
    "id" : 534464310311804928,
    "created_at" : "2014-11-17 21:53:16 +0000",
    "user" : {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "protected" : false,
      "id_str" : "15693493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796062959185182720\/FN6QGp0H_normal.jpg",
      "id" : 15693493,
      "verified" : true
    }
  },
  "id" : 534485782984011777,
  "created_at" : "2014-11-17 23:18:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/534479005496250370\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/3ETFEZTRkz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2rZyUzCYAA1ljn.jpg",
      "id_str" : "534478964396285952",
      "id" : 534478964396285952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2rZyUzCYAA1ljn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3ETFEZTRkz"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/vH4K0utaVk",
      "expanded_url" : "http:\/\/go.wh.gov\/1s96zC",
      "display_url" : "go.wh.gov\/1s96zC"
    } ]
  },
  "geo" : { },
  "id_str" : "534479005496250370",
  "text" : "Check out this new toolkit to help communities respond to climate change \u2192 http:\/\/t.co\/vH4K0utaVk #ActOnClimate http:\/\/t.co\/3ETFEZTRkz",
  "id" : 534479005496250370,
  "created_at" : "2014-11-17 22:51:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Keys",
      "screen_name" : "aliciakeys",
      "indices" : [ 3, 14 ],
      "id_str" : "35094637",
      "id" : 35094637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/9GFd5nSabR",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534465093853933569",
  "text" : "RT @aliciakeys: Open enrollment is back @ http:\/\/t.co\/9GFd5nSabR. Can't think of many things more valuable than ur health! Take care of urs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/9GFd5nSabR",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "534462065805914112",
    "text" : "Open enrollment is back @ http:\/\/t.co\/9GFd5nSabR. Can't think of many things more valuable than ur health! Take care of urself! #GetCovered",
    "id" : 534462065805914112,
    "created_at" : "2014-11-17 21:44:20 +0000",
    "user" : {
      "name" : "Alicia Keys",
      "screen_name" : "aliciakeys",
      "protected" : false,
      "id_str" : "35094637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784235369906614272\/IyyZ25fR_normal.jpg",
      "id" : 35094637,
      "verified" : true
    }
  },
  "id" : 534465093853933569,
  "created_at" : "2014-11-17 21:56:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "indices" : [ 3, 13 ],
      "id_str" : "25110374",
      "id" : 25110374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getcovered",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Ws9UiblP4V",
      "expanded_url" : "http:\/\/www.healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534462742216704001",
  "text" : "RT @UncleRUSH: Today is the day that we #getcovered.  If you don't have insurance, you can sign up now at: http:\/\/t.co\/Ws9UiblP4V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getcovered",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/Ws9UiblP4V",
        "expanded_url" : "http:\/\/www.healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "534458778885058560",
    "text" : "Today is the day that we #getcovered.  If you don't have insurance, you can sign up now at: http:\/\/t.co\/Ws9UiblP4V",
    "id" : 534458778885058560,
    "created_at" : "2014-11-17 21:31:17 +0000",
    "user" : {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "protected" : false,
      "id_str" : "25110374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748232081008959488\/0fWqh6-F_normal.jpg",
      "id" : 25110374,
      "verified" : true
    }
  },
  "id" : 534462742216704001,
  "created_at" : "2014-11-17 21:47:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/vVptEkMIRR",
      "expanded_url" : "http:\/\/go.wh.gov\/aoehx4",
      "display_url" : "go.wh.gov\/aoehx4"
    } ]
  },
  "geo" : { },
  "id_str" : "534453036773433346",
  "text" : "Today, 20 more companies are joining President Obama's SupplierPay initiative to help strengthen small businesses \u2192 http:\/\/t.co\/vVptEkMIRR",
  "id" : 534453036773433346,
  "created_at" : "2014-11-17 21:08:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 26, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/4E8NM8Y6jM",
      "expanded_url" : "http:\/\/toolkit.climate.gov",
      "display_url" : "toolkit.climate.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534430434172891136",
  "text" : "RT @Podesta44: Bipartisan #ActOnClimate resilience task force asked for better data. So today we're launching http:\/\/t.co\/4E8NM8Y6jM http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Podesta44\/status\/534412186454474752\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/o8qZ764IkT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2pmTZZCQAAuhT4.png",
        "id_str" : "534351989216264192",
        "id" : 534351989216264192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2pmTZZCQAAuhT4.png",
        "sizes" : [ {
          "h" : 422,
          "resize" : "fit",
          "w" : 911
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 911
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 157,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/o8qZ764IkT"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 11, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/4E8NM8Y6jM",
        "expanded_url" : "http:\/\/toolkit.climate.gov",
        "display_url" : "toolkit.climate.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "534412186454474752",
    "text" : "Bipartisan #ActOnClimate resilience task force asked for better data. So today we're launching http:\/\/t.co\/4E8NM8Y6jM http:\/\/t.co\/o8qZ764IkT",
    "id" : 534412186454474752,
    "created_at" : "2014-11-17 18:26:08 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 534430434172891136,
  "created_at" : "2014-11-17 19:38:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connie Britton",
      "screen_name" : "conniebritton",
      "indices" : [ 3, 17 ],
      "id_str" : "1905230346",
      "id" : 1905230346
    }, {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 117, 131 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534422775281491968",
  "text" : "RT @conniebritton: Your health is everything. Have you and your family enrolled for health coverage yet? #GetCovered @HealthCareGov",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthCare.gov",
        "screen_name" : "HealthCareGov",
        "indices" : [ 98, 112 ],
        "id_str" : "86697288",
        "id" : 86697288
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 86, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "534409510098837506",
    "text" : "Your health is everything. Have you and your family enrolled for health coverage yet? #GetCovered @HealthCareGov",
    "id" : 534409510098837506,
    "created_at" : "2014-11-17 18:15:30 +0000",
    "user" : {
      "name" : "Connie Britton",
      "screen_name" : "conniebritton",
      "protected" : false,
      "id_str" : "1905230346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795623148842524672\/CqwRofAF_normal.jpg",
      "id" : 1905230346,
      "verified" : true
    }
  },
  "id" : 534422775281491968,
  "created_at" : "2014-11-17 19:08:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pharrell Williams",
      "screen_name" : "Pharrell",
      "indices" : [ 3, 12 ],
      "id_str" : "338084918",
      "id" : 338084918
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/up7RpXH3TY",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534410095929876480",
  "text" : "RT @Pharrell: Keep those you love healthy. Today is the day to #GetCovered at http:\/\/t.co\/up7RpXH3TY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 49, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/up7RpXH3TY",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "534408584957009922",
    "text" : "Keep those you love healthy. Today is the day to #GetCovered at http:\/\/t.co\/up7RpXH3TY",
    "id" : 534408584957009922,
    "created_at" : "2014-11-17 18:11:50 +0000",
    "user" : {
      "name" : "Pharrell Williams",
      "screen_name" : "Pharrell",
      "protected" : false,
      "id_str" : "338084918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777892792328531968\/aRbbZcMo_normal.jpg",
      "id" : 338084918,
      "verified" : true
    }
  },
  "id" : 534410095929876480,
  "created_at" : "2014-11-17 18:17:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenna  Ushkowitz",
      "screen_name" : "JennaUshkowitz",
      "indices" : [ 3, 18 ],
      "id_str" : "32981735",
      "id" : 32981735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getcovered",
      "indices" : [ 25, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/GtM631N2UA",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534404090491830272",
  "text" : "RT @JennaUshkowitz: Hey! #getcovered at http:\/\/t.co\/GtM631N2UA now! Open enrollment is back! \uD83D\uDC4D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getcovered",
        "indices" : [ 5, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/GtM631N2UA",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "534391743970426880",
    "text" : "Hey! #getcovered at http:\/\/t.co\/GtM631N2UA now! Open enrollment is back! \uD83D\uDC4D",
    "id" : 534391743970426880,
    "created_at" : "2014-11-17 17:04:54 +0000",
    "user" : {
      "name" : "Jenna  Ushkowitz",
      "screen_name" : "JennaUshkowitz",
      "protected" : false,
      "id_str" : "32981735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792537756316602368\/iSTQ5gF1_normal.jpg",
      "id" : 32981735,
      "verified" : true
    }
  },
  "id" : 534404090491830272,
  "created_at" : "2014-11-17 17:53:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cris Carter",
      "screen_name" : "criscarter80",
      "indices" : [ 3, 16 ],
      "id_str" : "718728986",
      "id" : 718728986
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/NN6EvWDAcH",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534385784074551297",
  "text" : "RT @criscarter80: Nov. 15 was the kickoff for open enrollment season. Are you covered?  #GetCovered by visiting http:\/\/t.co\/NN6EvWDAcH today",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 70, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/NN6EvWDAcH",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "534375851090264064",
    "text" : "Nov. 15 was the kickoff for open enrollment season. Are you covered?  #GetCovered by visiting http:\/\/t.co\/NN6EvWDAcH today",
    "id" : 534375851090264064,
    "created_at" : "2014-11-17 16:01:45 +0000",
    "user" : {
      "name" : "Cris Carter",
      "screen_name" : "criscarter80",
      "protected" : false,
      "id_str" : "718728986",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797876731084468224\/o4TeSCsA_normal.jpg",
      "id" : 718728986,
      "verified" : true
    }
  },
  "id" : 534385784074551297,
  "created_at" : "2014-11-17 16:41:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julia Louis-Dreyfus",
      "screen_name" : "OfficialJLD",
      "indices" : [ 3, 15 ],
      "id_str" : "502281810",
      "id" : 502281810
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 61, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/0JdON3nuVS",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534376073807810560",
  "text" : "RT @OfficialJLD: Hey, guess what?  Open enrollment is back!  #GetCovered at http:\/\/t.co\/0JdON3nuVS.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 44, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/0JdON3nuVS",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "534369354176290816",
    "text" : "Hey, guess what?  Open enrollment is back!  #GetCovered at http:\/\/t.co\/0JdON3nuVS.",
    "id" : 534369354176290816,
    "created_at" : "2014-11-17 15:35:56 +0000",
    "user" : {
      "name" : "Julia Louis-Dreyfus",
      "screen_name" : "OfficialJLD",
      "protected" : false,
      "id_str" : "502281810",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724969808144437248\/fmiwz4kK_normal.jpg",
      "id" : 502281810,
      "verified" : true
    }
  },
  "id" : 534376073807810560,
  "created_at" : "2014-11-17 16:02:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/534368321966440448\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/1ZHU7xGtfO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2p03skCcAARIwC.jpg",
      "id_str" : "534368006000766976",
      "id" : 534368006000766976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2p03skCcAARIwC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1ZHU7xGtfO"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "ReadySetEnroll",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/5zeR2Sp97i",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534368321966440448",
  "text" : "Need health coverage? Here are four ways you can #GetCovered today \u2192 http:\/\/t.co\/5zeR2Sp97i #ReadySetEnroll http:\/\/t.co\/1ZHU7xGtfO",
  "id" : 534368321966440448,
  "created_at" : "2014-11-17 15:31:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534360199138512896",
  "text" : "RT @JFriedman44: Today, 20 companies are joining the 26 that adopted the SupplierPay pledge at launch annoncement with POTUS in July: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/8R3sN4ZOAR",
        "expanded_url" : "http:\/\/1.usa.gov\/1uyoi4y",
        "display_url" : "1.usa.gov\/1uyoi4y"
      } ]
    },
    "geo" : { },
    "id_str" : "534357238035787776",
    "text" : "Today, 20 companies are joining the 26 that adopted the SupplierPay pledge at launch annoncement with POTUS in July: http:\/\/t.co\/8R3sN4ZOAR",
    "id" : 534357238035787776,
    "created_at" : "2014-11-17 14:47:48 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 534360199138512896,
  "created_at" : "2014-11-17 14:59:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/534354534047293442\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/ZsfeZG0vla",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2pol0OCAAE4IHm.jpg",
      "id_str" : "534354504678768641",
      "id" : 534354504678768641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2pol0OCAAE4IHm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZsfeZG0vla"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "ReadySetEnroll",
      "indices" : [ 95, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/2S7CGldNyn",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "534354534047293442",
  "text" : "If you or someone you know needs health coverage, #GetCovered today at http:\/\/t.co\/2S7CGldNyn. #ReadySetEnroll http:\/\/t.co\/ZsfeZG0vla",
  "id" : 534354534047293442,
  "created_at" : "2014-11-17 14:37:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/AjCswE50V7",
      "expanded_url" : "http:\/\/go.wh.gov\/uoSQUC",
      "display_url" : "go.wh.gov\/uoSQUC"
    } ]
  },
  "geo" : { },
  "id_str" : "534141680308342785",
  "text" : "\"Together, we can make sure that even more of America gets covered in the year ahead.\" \u2014Obama: http:\/\/t.co\/AjCswE50V7 #GetCovered",
  "id" : 534141680308342785,
  "created_at" : "2014-11-17 00:31:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 58, 69 ]
    }, {
      "text" : "ReadySetEnroll",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Fj5uXFF6bK",
      "expanded_url" : "http:\/\/go.wh.gov\/kiFoU6",
      "display_url" : "go.wh.gov\/kiFoU6"
    } ]
  },
  "geo" : { },
  "id_str" : "534111210497511425",
  "text" : "\"Spread the word: Tell your friends and family members to #GetCovered.\" \u2014President Obama: http:\/\/t.co\/Fj5uXFF6bK #ReadySetEnroll",
  "id" : 534111210497511425,
  "created_at" : "2014-11-16 22:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/534106466974982145\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/FNhXxwj8Re",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2mG3zWCYAAhJs2.png",
      "id_str" : "534106324053680128",
      "id" : 534106324053680128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2mG3zWCYAAhJs2.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 874
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 874
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FNhXxwj8Re"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534106466974982145",
  "text" : "\"Today we offer our prayers and condolences to the parents and family of Abdul-Rahman Kassig.\" \u2014President Obama http:\/\/t.co\/FNhXxwj8Re",
  "id" : 534106466974982145,
  "created_at" : "2014-11-16 22:11:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/2S7CGldNyn",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/B18McHRQzx",
      "expanded_url" : "http:\/\/CuidadoDeSalud.gov",
      "display_url" : "CuidadoDeSalud.gov"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/AjCswE50V7",
      "expanded_url" : "http:\/\/go.wh.gov\/uoSQUC",
      "display_url" : "go.wh.gov\/uoSQUC"
    } ]
  },
  "geo" : { },
  "id_str" : "534099141652008960",
  "text" : "\"Take a few minutes to check out http:\/\/t.co\/2S7CGldNyn, http:\/\/t.co\/B18McHRQzx, or call 1-800-318-2596.\" \u2014Obama: http:\/\/t.co\/AjCswE50V7",
  "id" : 534099141652008960,
  "created_at" : "2014-11-16 21:42:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 106, 117 ]
    }, {
      "text" : "ReadySetEnroll",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/AjCswE50V7",
      "expanded_url" : "http:\/\/go.wh.gov\/uoSQUC",
      "display_url" : "go.wh.gov\/uoSQUC"
    } ]
  },
  "geo" : { },
  "id_str" : "534050833524998144",
  "text" : "\"Health care prices have grown at their slowest rate in nearly 50 years.\"  \u2014Obama: http:\/\/t.co\/AjCswE50V7 #GetCovered #ReadySetEnroll",
  "id" : 534050833524998144,
  "created_at" : "2014-11-16 18:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/AjCswE50V7",
      "expanded_url" : "http:\/\/go.wh.gov\/uoSQUC",
      "display_url" : "go.wh.gov\/uoSQUC"
    } ]
  },
  "geo" : { },
  "id_str" : "534029919647301632",
  "text" : "\"You only have three months to shop for plans, so it\u2019s worth starting right away.\" \u2014President Obama: http:\/\/t.co\/AjCswE50V7 #GetCovered",
  "id" : 534029919647301632,
  "created_at" : "2014-11-16 17:07:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/AjCswE50V7",
      "expanded_url" : "http:\/\/go.wh.gov\/uoSQUC",
      "display_url" : "go.wh.gov\/uoSQUC"
    } ]
  },
  "geo" : { },
  "id_str" : "533794103763279872",
  "text" : "\"You only have three months to shop for plans, so it\u2019s worth starting right away.\" \u2014President Obama: http:\/\/t.co\/AjCswE50V7 #GetCovered",
  "id" : 533794103763279872,
  "created_at" : "2014-11-16 01:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/533768927482896384\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/roeOMwh33h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2hTSxkCcAAYXww.jpg",
      "id_str" : "533768137850646528",
      "id" : 533768137850646528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2hTSxkCcAAYXww.jpg",
      "sizes" : [ {
        "h" : 1100,
        "resize" : "fit",
        "w" : 849
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 849
      }, {
        "h" : 441,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/roeOMwh33h"
    } ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 62, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/mbSY0ZQLxD",
      "expanded_url" : "http:\/\/go.wh.gov\/b7zgmC",
      "display_url" : "go.wh.gov\/b7zgmC"
    } ]
  },
  "geo" : { },
  "id_str" : "533768927482896384",
  "text" : "Sharing a koalaty moment in Australia. http:\/\/t.co\/mbSY0ZQLxD #G20 http:\/\/t.co\/roeOMwh33h",
  "id" : 533768927482896384,
  "created_at" : "2014-11-15 23:50:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 93, 104 ]
    }, {
      "text" : "ReadySetEnroll",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/AjCswE50V7",
      "expanded_url" : "http:\/\/go.wh.gov\/uoSQUC",
      "display_url" : "go.wh.gov\/uoSQUC"
    } ]
  },
  "geo" : { },
  "id_str" : "533756374002307072",
  "text" : "Spread the word: You can sign up for health coverage starting today \u2192 http:\/\/t.co\/AjCswE50V7 #GetCovered #ReadySetEnroll",
  "id" : 533756374002307072,
  "created_at" : "2014-11-15 23:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/533709130843058176\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/vIYDBNZUL4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2gdSM2CEAEOf1w.jpg",
      "id_str" : "533708754366107649",
      "id" : 533708754366107649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2gdSM2CEAEOf1w.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vIYDBNZUL4"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 28, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Ukv3WpqqAU",
      "expanded_url" : "http:\/\/wh.gov\/get-covered",
      "display_url" : "wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "533709130843058176",
  "text" : "Want to help more Americans #GetCovered? Here's how you can help spread the word \u2192 http:\/\/t.co\/Ukv3WpqqAU http:\/\/t.co\/vIYDBNZUL4",
  "id" : 533709130843058176,
  "created_at" : "2014-11-15 19:52:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregory Meeks",
      "screen_name" : "GregoryMeeks",
      "indices" : [ 3, 16 ],
      "id_str" : "22812754",
      "id" : 22812754
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 71, 82 ]
    }, {
      "text" : "ReadySetEnroll",
      "indices" : [ 109, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/uDAca8DJwk",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "533703771755659264",
  "text" : "RT @GregoryMeeks: Starting today, you can sign up for health coverage. #GetCovered at http:\/\/t.co\/uDAca8DJwk #ReadySetEnroll http:\/\/t.co\/fM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GregoryMeeks\/status\/533670817960181760\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/fMiFdsWW5U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2f6x8zIAAAp4R-.jpg",
        "id_str" : "533670816907788288",
        "id" : 533670816907788288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2f6x8zIAAAp4R-.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/fMiFdsWW5U"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 53, 64 ]
      }, {
        "text" : "ReadySetEnroll",
        "indices" : [ 91, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/uDAca8DJwk",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "533670817960181760",
    "text" : "Starting today, you can sign up for health coverage. #GetCovered at http:\/\/t.co\/uDAca8DJwk #ReadySetEnroll http:\/\/t.co\/fMiFdsWW5U",
    "id" : 533670817960181760,
    "created_at" : "2014-11-15 17:20:12 +0000",
    "user" : {
      "name" : "Gregory Meeks",
      "screen_name" : "GregoryMeeks",
      "protected" : false,
      "id_str" : "22812754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794288492679430144\/BOtuI9_V_normal.jpg",
      "id" : 22812754,
      "verified" : true
    }
  },
  "id" : 533703771755659264,
  "created_at" : "2014-11-15 19:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 86, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/MJN1BvI6w4",
      "expanded_url" : "http:\/\/go.hc.gov\/1EFXRuP",
      "display_url" : "go.hc.gov\/1EFXRuP"
    } ]
  },
  "geo" : { },
  "id_str" : "533700910321766400",
  "text" : "RT @HealthCareGov: Open enrollment launches today\u2014explore your plan options now &amp; #GetCovered \u2192 http:\/\/t.co\/MJN1BvI6w4 http:\/\/t.co\/7AMvn8fY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HealthCareGov\/status\/533643123398696960\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/7AMvn8fYHr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2byc2DCYAALhiW.png",
        "id_str" : "533380183248494592",
        "id" : 533380183248494592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2byc2DCYAALhiW.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 1201
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7AMvn8fYHr"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 67, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/MJN1BvI6w4",
        "expanded_url" : "http:\/\/go.hc.gov\/1EFXRuP",
        "display_url" : "go.hc.gov\/1EFXRuP"
      } ]
    },
    "geo" : { },
    "id_str" : "533643123398696960",
    "text" : "Open enrollment launches today\u2014explore your plan options now &amp; #GetCovered \u2192 http:\/\/t.co\/MJN1BvI6w4 http:\/\/t.co\/7AMvn8fYHr",
    "id" : 533643123398696960,
    "created_at" : "2014-11-15 15:30:09 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 533700910321766400,
  "created_at" : "2014-11-15 19:19:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Invincibles",
      "screen_name" : "YoungInvincible",
      "indices" : [ 3, 19 ],
      "id_str" : "67215899",
      "id" : 67215899
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 39, 50 ]
    }, {
      "text" : "ReadySetEnroll",
      "indices" : [ 120, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/CGpicrleXS",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "533695362796879872",
  "text" : "RT @YoungInvincible: Four ways you can #GetCovered today:\nhttp:\/\/t.co\/CGpicrleXS\n\u260F 1(800)318-2596\n\u2709 By mail\n\u270D In person\n#ReadySetEnroll htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YoungInvincible\/status\/533595521823567872\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/yus5lDmBXO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2e2TAbIAAAibkD.jpg",
        "id_str" : "533595518514233344",
        "id" : 533595518514233344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2e2TAbIAAAibkD.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/yus5lDmBXO"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 18, 29 ]
      }, {
        "text" : "ReadySetEnroll",
        "indices" : [ 99, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/CGpicrleXS",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "533595521823567872",
    "text" : "Four ways you can #GetCovered today:\nhttp:\/\/t.co\/CGpicrleXS\n\u260F 1(800)318-2596\n\u2709 By mail\n\u270D In person\n#ReadySetEnroll http:\/\/t.co\/yus5lDmBXO",
    "id" : 533595521823567872,
    "created_at" : "2014-11-15 12:21:00 +0000",
    "user" : {
      "name" : "Young Invincibles",
      "screen_name" : "YoungInvincible",
      "protected" : false,
      "id_str" : "67215899",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691632503577161728\/Zj3TLgji_normal.png",
      "id" : 67215899,
      "verified" : false
    }
  },
  "id" : 533695362796879872,
  "created_at" : "2014-11-15 18:57:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/533688837831426049\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/L68Fp48KKG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2gLF-ZCQAAUgaz.jpg",
      "id_str" : "533688753118658560",
      "id" : 533688753118658560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2gLF-ZCQAAUgaz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/L68Fp48KKG"
    } ],
    "hashtags" : [ {
      "text" : "ReadySetEnroll",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/5zeR2Sp97i",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "533688837831426049",
  "text" : "RT so your friends know: You can sign up for health coverage right now at http:\/\/t.co\/5zeR2Sp97i. #ReadySetEnroll http:\/\/t.co\/L68Fp48KKG",
  "id" : 533688837831426049,
  "created_at" : "2014-11-15 18:31:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Juan Vargas",
      "screen_name" : "RepJuanVargas",
      "indices" : [ 3, 17 ],
      "id_str" : "1260172386",
      "id" : 1260172386
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/7vQX0D9pDy",
      "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans\/",
      "display_url" : "healthcare.gov\/see-plans\/"
    } ]
  },
  "geo" : { },
  "id_str" : "533686185450037248",
  "text" : "RT @RepJuanVargas: Health care open enrollment starts Today! See what plan works for you \u2192 https:\/\/t.co\/7vQX0D9pDy  #GetCovered http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RepJuanVargas\/status\/533683660910637056\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/Ah2abNZ0V7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2gGdgOIAAEmUlP.jpg",
        "id_str" : "533683659778555905",
        "id" : 533683659778555905,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2gGdgOIAAEmUlP.jpg",
        "sizes" : [ {
          "h" : 234,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ah2abNZ0V7"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 97, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/7vQX0D9pDy",
        "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans\/",
        "display_url" : "healthcare.gov\/see-plans\/"
      } ]
    },
    "geo" : { },
    "id_str" : "533683660910637056",
    "text" : "Health care open enrollment starts Today! See what plan works for you \u2192 https:\/\/t.co\/7vQX0D9pDy  #GetCovered http:\/\/t.co\/Ah2abNZ0V7",
    "id" : 533683660910637056,
    "created_at" : "2014-11-15 18:11:14 +0000",
    "user" : {
      "name" : "Rep. Juan Vargas",
      "screen_name" : "RepJuanVargas",
      "protected" : false,
      "id_str" : "1260172386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3367724845\/265c22deb92e4da11c43b70cc8ca9bf7_normal.jpeg",
      "id" : 1260172386,
      "verified" : true
    }
  },
  "id" : 533686185450037248,
  "created_at" : "2014-11-15 18:21:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    }, {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 36, 50 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 16, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533681160032120832",
  "text" : "RT @SecBurwell: #GetCovered update: @HealthCareGov opened for business shortly after 1am. In first 8 hrs, 23K+ people submitted an app. #Re\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthCare.gov",
        "screen_name" : "HealthCareGov",
        "indices" : [ 20, 34 ],
        "id_str" : "86697288",
        "id" : 86697288
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "ReadySetEnroll",
        "indices" : [ 120, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "533674212192686080",
    "text" : "#GetCovered update: @HealthCareGov opened for business shortly after 1am. In first 8 hrs, 23K+ people submitted an app. #ReadySetEnroll",
    "id" : 533674212192686080,
    "created_at" : "2014-11-15 17:33:42 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 533681160032120832,
  "created_at" : "2014-11-15 18:01:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/GNfbftIQw7",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/AjCswE50V7",
      "expanded_url" : "http:\/\/go.wh.gov\/uoSQUC",
      "display_url" : "go.wh.gov\/uoSQUC"
    } ]
  },
  "geo" : { },
  "id_str" : "533680988270780416",
  "text" : "\"We\u2019ve spent the last year improving and upgrading http:\/\/t.co\/GNfbftIQw7 to make it faster and easier.\" \u2014Obama: http:\/\/t.co\/AjCswE50V7",
  "id" : 533680988270780416,
  "created_at" : "2014-11-15 18:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/AjCswE50V7",
      "expanded_url" : "http:\/\/go.wh.gov\/uoSQUC",
      "display_url" : "go.wh.gov\/uoSQUC"
    } ]
  },
  "geo" : { },
  "id_str" : "533673320999161856",
  "text" : "\"More than 10 million Americans have gained the financial security...that comes with health insurance.\" \u2014Obama: http:\/\/t.co\/AjCswE50V7",
  "id" : 533673320999161856,
  "created_at" : "2014-11-15 17:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/AjCswE50V7",
      "expanded_url" : "http:\/\/go.wh.gov\/uoSQUC",
      "display_url" : "go.wh.gov\/uoSQUC"
    } ]
  },
  "geo" : { },
  "id_str" : "533659760038383616",
  "text" : "\"Insurance companies can no longer deny you coverage just because you have a preexisting condition.\" \u2014Obama: http:\/\/t.co\/AjCswE50V7",
  "id" : 533659760038383616,
  "created_at" : "2014-11-15 16:36:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 93, 104 ]
    }, {
      "text" : "ReadySetEnroll",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/AjCswE50V7",
      "expanded_url" : "http:\/\/go.wh.gov\/uoSQUC",
      "display_url" : "go.wh.gov\/uoSQUC"
    } ]
  },
  "geo" : { },
  "id_str" : "533625497251356673",
  "text" : "Spread the word: You can sign up for health coverage starting today \u2192 http:\/\/t.co\/AjCswE50V7 #GetCovered #ReadySetEnroll",
  "id" : 533625497251356673,
  "created_at" : "2014-11-15 14:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/o9vBz6d51R",
      "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans",
      "display_url" : "healthcare.gov\/see-plans"
    } ]
  },
  "geo" : { },
  "id_str" : "533379099822026752",
  "text" : "RT @Cecilia44: Need health coverage? Find a plan that fits your needs &amp; #GetCovered starting tomorrow \u2192 https:\/\/t.co\/o9vBz6d51R #ReadySetEn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 61, 72 ]
      }, {
        "text" : "ReadySetEnroll",
        "indices" : [ 117, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/o9vBz6d51R",
        "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans",
        "display_url" : "healthcare.gov\/see-plans"
      } ]
    },
    "geo" : { },
    "id_str" : "533378546639855616",
    "text" : "Need health coverage? Find a plan that fits your needs &amp; #GetCovered starting tomorrow \u2192 https:\/\/t.co\/o9vBz6d51R #ReadySetEnroll",
    "id" : 533378546639855616,
    "created_at" : "2014-11-14 21:58:49 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 533379099822026752,
  "created_at" : "2014-11-14 22:01:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SB Nation",
      "screen_name" : "SBNation",
      "indices" : [ 3, 12 ],
      "id_str" : "16745015",
      "id" : 16745015
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Yp3BDEWA1P",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=YEmb6PUO7Qk",
      "display_url" : "youtube.com\/watch?v=YEmb6P\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "533368537889243136",
  "text" : "RT @SBNation: #ItsOnUs to stop sexual assault. Watch, and take the pledge today:  https:\/\/t.co\/Yp3BDEWA1P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/Yp3BDEWA1P",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=YEmb6PUO7Qk",
        "display_url" : "youtube.com\/watch?v=YEmb6P\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "533308419055177728",
    "text" : "#ItsOnUs to stop sexual assault. Watch, and take the pledge today:  https:\/\/t.co\/Yp3BDEWA1P",
    "id" : 533308419055177728,
    "created_at" : "2014-11-14 17:20:10 +0000",
    "user" : {
      "name" : "SB Nation",
      "screen_name" : "SBNation",
      "protected" : false,
      "id_str" : "16745015",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770307808768192516\/yVctOSZ-_normal.jpg",
      "id" : 16745015,
      "verified" : true
    }
  },
  "id" : 533368537889243136,
  "created_at" : "2014-11-14 21:19:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CEABetsey\/status\/533353368702705664\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/avInFPaZUJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2baD-dCYAANwEd.jpg",
      "id_str" : "533353367729233920",
      "id" : 533353367729233920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2baD-dCYAANwEd.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/avInFPaZUJ"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533357336640094208",
  "text" : "RT @CEABetsey: Did you know that more than half of minimum wage workers are women? It's time to #RaiseTheWage http:\/\/t.co\/avInFPaZUJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEABetsey\/status\/533353368702705664\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/avInFPaZUJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2baD-dCYAANwEd.jpg",
        "id_str" : "533353367729233920",
        "id" : 533353367729233920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2baD-dCYAANwEd.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/avInFPaZUJ"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 81, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "533353368702705664",
    "text" : "Did you know that more than half of minimum wage workers are women? It's time to #RaiseTheWage http:\/\/t.co\/avInFPaZUJ",
    "id" : 533353368702705664,
    "created_at" : "2014-11-14 20:18:46 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 533357336640094208,
  "created_at" : "2014-11-14 20:34:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everyday Health",
      "screen_name" : "EverydayHealth",
      "indices" : [ 3, 18 ],
      "id_str" : "17393790",
      "id" : 17393790
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 87, 94 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 99, 113 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HealthTalk",
      "indices" : [ 132, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533335923442724864",
  "text" : "RT @EverydayHealth: Today, we have Catherine Oakar &amp; Mayra Alvarez joining us from @HHSGov and @HealthCareGov to answer your Qs #HealthTalk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HHS.gov",
        "screen_name" : "HHSGov",
        "indices" : [ 67, 74 ],
        "id_str" : "44783853",
        "id" : 44783853
      }, {
        "name" : "HealthCare.gov",
        "screen_name" : "HealthCareGov",
        "indices" : [ 79, 93 ],
        "id_str" : "86697288",
        "id" : 86697288
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HealthTalk",
        "indices" : [ 112, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "533334050153701377",
    "text" : "Today, we have Catherine Oakar &amp; Mayra Alvarez joining us from @HHSGov and @HealthCareGov to answer your Qs #HealthTalk",
    "id" : 533334050153701377,
    "created_at" : "2014-11-14 19:02:01 +0000",
    "user" : {
      "name" : "Everyday Health",
      "screen_name" : "EverydayHealth",
      "protected" : false,
      "id_str" : "17393790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695992404374122496\/URP3kg1S_normal.jpg",
      "id" : 17393790,
      "verified" : true
    }
  },
  "id" : 533335923442724864,
  "created_at" : "2014-11-14 19:09:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/533334559341813762\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/W3sY0zzyEl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2bI302CUAAMl-N.jpg",
      "id_str" : "533334467293630464",
      "id" : 533334467293630464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2bI302CUAAMl-N.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/W3sY0zzyEl"
    } ],
    "hashtags" : [ {
      "text" : "ReadySetEnroll",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/cIUCCOLliA",
      "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans",
      "display_url" : "healthcare.gov\/see-plans"
    } ]
  },
  "geo" : { },
  "id_str" : "533334559341813762",
  "text" : "TOMORROW: You can sign up for health coverage. Check out your options \u2192 https:\/\/t.co\/cIUCCOLliA #ReadySetEnroll http:\/\/t.co\/W3sY0zzyEl",
  "id" : 533334559341813762,
  "created_at" : "2014-11-14 19:04:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/grVjVrvSS4",
      "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans",
      "display_url" : "healthcare.gov\/see-plans"
    } ]
  },
  "geo" : { },
  "id_str" : "533322710143598592",
  "text" : "RT @VP: Having health care provides peace of mind\n\nAnd starting tomorrow, you can #GetCovered\n\nLearn more \u2192 https:\/\/t.co\/grVjVrvSS4 #ReadyS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 74, 85 ]
      }, {
        "text" : "ReadySetEnroll",
        "indices" : [ 124, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/grVjVrvSS4",
        "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans",
        "display_url" : "healthcare.gov\/see-plans"
      } ]
    },
    "geo" : { },
    "id_str" : "533308283336261632",
    "text" : "Having health care provides peace of mind\n\nAnd starting tomorrow, you can #GetCovered\n\nLearn more \u2192 https:\/\/t.co\/grVjVrvSS4 #ReadySetEnroll",
    "id" : 533308283336261632,
    "created_at" : "2014-11-14 17:19:37 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 533322710143598592,
  "created_at" : "2014-11-14 18:16:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 53, 57 ]
    }, {
      "text" : "ReadySetEnroll",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/ebmuvpakLB",
      "expanded_url" : "http:\/\/politi.co\/1vbSMdZ",
      "display_url" : "politi.co\/1vbSMdZ"
    } ]
  },
  "geo" : { },
  "id_str" : "533315942269218816",
  "text" : "Poll: 71% of Americans that got coverage through the #ACA said it was \"good\" or \"excellent\" \u2192 http:\/\/t.co\/ebmuvpakLB #ReadySetEnroll",
  "id" : 533315942269218816,
  "created_at" : "2014-11-14 17:50:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/533307022985678848\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/zCIDVttVSN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2avUaqCIAA5E64.jpg",
      "id_str" : "533306371177848832",
      "id" : 533306371177848832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2avUaqCIAA5E64.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zCIDVttVSN"
    } ],
    "hashtags" : [ {
      "text" : "ReadySetEnroll",
      "indices" : [ 102, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/wcc2CipWAD",
      "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans",
      "display_url" : "healthcare.gov\/see-plans"
    } ]
  },
  "geo" : { },
  "id_str" : "533307022985678848",
  "text" : "RT to spread the word: You can sign up for health coverage starting tomorrow. https:\/\/t.co\/wcc2CipWAD #ReadySetEnroll http:\/\/t.co\/zCIDVttVSN",
  "id" : 533307022985678848,
  "created_at" : "2014-11-14 17:14:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OPM",
      "screen_name" : "USOPM",
      "indices" : [ 3, 9 ],
      "id_str" : "30231097",
      "id" : 30231097
    }, {
      "name" : "Beth Cobert",
      "screen_name" : "OPMDirector",
      "indices" : [ 22, 34 ],
      "id_str" : "1736601720",
      "id" : 1736601720
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericasWorkforce",
      "indices" : [ 58, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/c1sxi1WuiP",
      "expanded_url" : "http:\/\/go.usa.gov\/AVB9",
      "display_url" : "go.usa.gov\/AVB9"
    } ]
  },
  "geo" : { },
  "id_str" : "533301159029534720",
  "text" : "RT @USOPM: Get ready: @OPMDirector's digital town hall on #AmericasWorkforce starts soon! Tune in here: http:\/\/t.co\/c1sxi1WuiP http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Beth Cobert",
        "screen_name" : "OPMDirector",
        "indices" : [ 11, 23 ],
        "id_str" : "1736601720",
        "id" : 1736601720
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USOPM\/status\/533286340595826688\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/6OWDhUrd9h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2adGcjCYAEhH7R.png",
        "id_str" : "533286339957907457",
        "id" : 533286339957907457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2adGcjCYAEhH7R.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6OWDhUrd9h"
      } ],
      "hashtags" : [ {
        "text" : "AmericasWorkforce",
        "indices" : [ 47, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/c1sxi1WuiP",
        "expanded_url" : "http:\/\/go.usa.gov\/AVB9",
        "display_url" : "go.usa.gov\/AVB9"
      } ]
    },
    "geo" : { },
    "id_str" : "533286340595826688",
    "text" : "Get ready: @OPMDirector's digital town hall on #AmericasWorkforce starts soon! Tune in here: http:\/\/t.co\/c1sxi1WuiP http:\/\/t.co\/6OWDhUrd9h",
    "id" : 533286340595826688,
    "created_at" : "2014-11-14 15:52:26 +0000",
    "user" : {
      "name" : "OPM",
      "screen_name" : "USOPM",
      "protected" : false,
      "id_str" : "30231097",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451011795830837249\/uYbrJMUz_normal.jpeg",
      "id" : 30231097,
      "verified" : true
    }
  },
  "id" : 533301159029534720,
  "created_at" : "2014-11-14 16:51:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HealthCareGov\/status\/533300257049022464\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/uK7Q0g9Yy0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2apwfjIcAEsybG.png",
      "id_str" : "533300256457650177",
      "id" : 533300256457650177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2apwfjIcAEsybG.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uK7Q0g9Yy0"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 44, 55 ]
    }, {
      "text" : "ReadySetEnroll",
      "indices" : [ 85, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/ZpEw7U1wum",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "533300456995299328",
  "text" : "RT @HealthCareGov: 1 more day until you can #GetCovered with http:\/\/t.co\/ZpEw7U1wum! #ReadySetEnroll http:\/\/t.co\/uK7Q0g9Yy0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HealthCareGov\/status\/533300257049022464\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/uK7Q0g9Yy0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2apwfjIcAEsybG.png",
        "id_str" : "533300256457650177",
        "id" : 533300256457650177,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2apwfjIcAEsybG.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/uK7Q0g9Yy0"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 25, 36 ]
      }, {
        "text" : "ReadySetEnroll",
        "indices" : [ 66, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/ZpEw7U1wum",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "533300257049022464",
    "text" : "1 more day until you can #GetCovered with http:\/\/t.co\/ZpEw7U1wum! #ReadySetEnroll http:\/\/t.co\/uK7Q0g9Yy0",
    "id" : 533300257049022464,
    "created_at" : "2014-11-14 16:47:44 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 533300456995299328,
  "created_at" : "2014-11-14 16:48:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533292764893425664",
  "text" : "RT @CEABetsey: Due to the pay gap, the average woman will have lost $431,000 over her working lifetime. Let\u2019s change that. #EqualPay http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEABetsey\/status\/533292550254125058\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/x5cvnDY7x5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2aiv1zCcAEPSDH.jpg",
        "id_str" : "533292548668682241",
        "id" : 533292548668682241,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2aiv1zCcAEPSDH.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/x5cvnDY7x5"
      } ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "533292550254125058",
    "text" : "Due to the pay gap, the average woman will have lost $431,000 over her working lifetime. Let\u2019s change that. #EqualPay http:\/\/t.co\/x5cvnDY7x5",
    "id" : 533292550254125058,
    "created_at" : "2014-11-14 16:17:06 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 533292764893425664,
  "created_at" : "2014-11-14 16:17:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/533275628988932098\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/RB621Co3xc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2aTICNCMAAQ8ca.jpg",
      "id_str" : "533275372129759232",
      "id" : 533275372129759232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2aTICNCMAAQ8ca.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RB621Co3xc"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/cIUCCOLliA",
      "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans",
      "display_url" : "healthcare.gov\/see-plans"
    } ]
  },
  "geo" : { },
  "id_str" : "533275628988932098",
  "text" : "Starting tomorrow, you can sign up for health coverage. Check out your options \u2192 https:\/\/t.co\/cIUCCOLliA #GetCovered http:\/\/t.co\/RB621Co3xc",
  "id" : 533275628988932098,
  "created_at" : "2014-11-14 15:09:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/533047725101973504\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/cTHHGsEJaj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2XEENHIUAAFhjx.jpg",
      "id_str" : "533047707431358464",
      "id" : 533047707431358464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2XEENHIUAAFhjx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cTHHGsEJaj"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/c7Gci9XpHs",
      "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans\/",
      "display_url" : "healthcare.gov\/see-plans\/"
    } ]
  },
  "geo" : { },
  "id_str" : "533047725101973504",
  "text" : "Health care open enrollment starts Saturday. See what plan works for you \u2192 https:\/\/t.co\/c7Gci9XpHs #GetCovered http:\/\/t.co\/cTHHGsEJaj",
  "id" : 533047725101973504,
  "created_at" : "2014-11-14 00:04:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 1, 12 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/533037161109397504\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/PZV60E3wez",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2W6Ub8IYAA6Km1.jpg",
      "id_str" : "533036991173386240",
      "id" : 533036991173386240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2W6Ub8IYAA6Km1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PZV60E3wez"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/f6EKyQOQgF",
      "expanded_url" : "http:\/\/go.wh.gov\/4nqJX2",
      "display_url" : "go.wh.gov\/4nqJX2"
    } ]
  },
  "geo" : { },
  "id_str" : "533037161109397504",
  "text" : ".@SecBurwell on what you need to know to #GetCovered starting on Saturday \u2192 http:\/\/t.co\/f6EKyQOQgF http:\/\/t.co\/PZV60E3wez",
  "id" : 533037161109397504,
  "created_at" : "2014-11-13 23:22:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskDrH",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/5ctvkmMItn",
      "expanded_url" : "http:\/\/youtu.be\/ddM_JEaSOPo",
      "display_url" : "youtu.be\/ddM_JEaSOPo"
    } ]
  },
  "geo" : { },
  "id_str" : "533008846013595648",
  "text" : "Got questions on climate change &amp; what we're doing to combat it? Ask President Obama's science advisor with #AskDrH: http:\/\/t.co\/5ctvkmMItn",
  "id" : 533008846013595648,
  "created_at" : "2014-11-13 21:29:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Hawk",
      "screen_name" : "tonyhawk",
      "indices" : [ 3, 12 ],
      "id_str" : "21879024",
      "id" : 21879024
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Y2tr0DUdSY",
      "expanded_url" : "http:\/\/youtu.be\/jQbymKIyJns",
      "display_url" : "youtu.be\/jQbymKIyJns"
    } ]
  },
  "geo" : { },
  "id_str" : "533005958486573057",
  "text" : "RT @tonyhawk: FACT: 8 in 10 victims of sexual assault knew their attacker. #ItsOnUs to hold our friends accountable \u2192 http:\/\/t.co\/Y2tr0DUdSY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 61, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/Y2tr0DUdSY",
        "expanded_url" : "http:\/\/youtu.be\/jQbymKIyJns",
        "display_url" : "youtu.be\/jQbymKIyJns"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 33.13064558434591, -117.2092668526966 ]
    },
    "id_str" : "532932216402087936",
    "text" : "FACT: 8 in 10 victims of sexual assault knew their attacker. #ItsOnUs to hold our friends accountable \u2192 http:\/\/t.co\/Y2tr0DUdSY",
    "id" : 532932216402087936,
    "created_at" : "2014-11-13 16:25:16 +0000",
    "user" : {
      "name" : "Tony Hawk",
      "screen_name" : "tonyhawk",
      "protected" : false,
      "id_str" : "21879024",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1325015260\/1979_driveway_fs_stink_normal.jpg",
      "id" : 21879024,
      "verified" : true
    }
  },
  "id" : 533005958486573057,
  "created_at" : "2014-11-13 21:18:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/f6EKyQOQgF",
      "expanded_url" : "http:\/\/go.wh.gov\/4nqJX2",
      "display_url" : "go.wh.gov\/4nqJX2"
    } ]
  },
  "geo" : { },
  "id_str" : "532999174950629376",
  "text" : "See how the Affordable Care Act helped the Dicksons become entrepreneurs and open a small business \u2192 http:\/\/t.co\/f6EKyQOQgF #GetCovered",
  "id" : 532999174950629376,
  "created_at" : "2014-11-13 20:51:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532987873872470016\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/QTOpvrHPxd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2WNlL_IIAAyqqs.jpg",
      "id_str" : "532987800925511680",
      "id" : 532987800925511680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2WNlL_IIAAyqqs.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QTOpvrHPxd"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/cIUCCOLliA",
      "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans",
      "display_url" : "healthcare.gov\/see-plans"
    } ]
  },
  "geo" : { },
  "id_str" : "532987873872470016",
  "text" : "Need health coverage? You can #GetCovered starting Saturday. Check out plans in your state \u2192 https:\/\/t.co\/cIUCCOLliA http:\/\/t.co\/QTOpvrHPxd",
  "id" : 532987873872470016,
  "created_at" : "2014-11-13 20:06:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Tammy Baldwin",
      "screen_name" : "SenatorBaldwin",
      "indices" : [ 3, 18 ],
      "id_str" : "1074518754",
      "id" : 1074518754
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/NSjzX7vTnt",
      "expanded_url" : "http:\/\/healthcare.gov\/see-plans",
      "display_url" : "healthcare.gov\/see-plans"
    } ]
  },
  "geo" : { },
  "id_str" : "532973502757081088",
  "text" : "RT @SenatorBaldwin: Get a head start on finding affordable health coverage &amp; window shop at http:\/\/t.co\/NSjzX7vTnt today! #GetCovered http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenatorBaldwin\/status\/532963867266019329\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ChBDZScoJw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2VnzHdIAAAPkS4.jpg",
        "id_str" : "532946258785468416",
        "id" : 532946258785468416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2VnzHdIAAAPkS4.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ChBDZScoJw"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 106, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/NSjzX7vTnt",
        "expanded_url" : "http:\/\/healthcare.gov\/see-plans",
        "display_url" : "healthcare.gov\/see-plans"
      } ]
    },
    "geo" : { },
    "id_str" : "532963867266019329",
    "text" : "Get a head start on finding affordable health coverage &amp; window shop at http:\/\/t.co\/NSjzX7vTnt today! #GetCovered http:\/\/t.co\/ChBDZScoJw",
    "id" : 532963867266019329,
    "created_at" : "2014-11-13 18:31:02 +0000",
    "user" : {
      "name" : "Sen. Tammy Baldwin",
      "screen_name" : "SenatorBaldwin",
      "protected" : false,
      "id_str" : "1074518754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656152457756692481\/jq9YvUuw_normal.jpg",
      "id" : 1074518754,
      "verified" : true
    }
  },
  "id" : 532973502757081088,
  "created_at" : "2014-11-13 19:09:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532967798876954625\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/sTvUxWqtdL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2V7GYrIgAAhMRJ.jpg",
      "id_str" : "532967480546066432",
      "id" : 532967480546066432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2V7GYrIgAAhMRJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sTvUxWqtdL"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/9BQ4oCKFhc",
      "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans",
      "display_url" : "healthcare.gov\/see-plans"
    } ]
  },
  "geo" : { },
  "id_str" : "532967798876954625",
  "text" : "If you need health coverage, you can #GetCovered starting on Saturday. See your options \u2192 https:\/\/t.co\/9BQ4oCKFhc http:\/\/t.co\/sTvUxWqtdL",
  "id" : 532967798876954625,
  "created_at" : "2014-11-13 18:46:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ue7wvTzabW",
      "expanded_url" : "http:\/\/youtu.be\/jQbymKIyJns?list=PLiDAAUyM1QRy9HvIAI81R6UfjzlgvwfHb",
      "display_url" : "youtu.be\/jQbymKIyJns?li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532956492035801089",
  "text" : "RT @vj44: This isn\u2019t a PSA about sexual assault. It\u2019s about being the folks who stop it. #ItsOnUs. All of us: http:\/\/t.co\/ue7wvTzabW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/ue7wvTzabW",
        "expanded_url" : "http:\/\/youtu.be\/jQbymKIyJns?list=PLiDAAUyM1QRy9HvIAI81R6UfjzlgvwfHb",
        "display_url" : "youtu.be\/jQbymKIyJns?li\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532940966668169216",
    "text" : "This isn\u2019t a PSA about sexual assault. It\u2019s about being the folks who stop it. #ItsOnUs. All of us: http:\/\/t.co\/ue7wvTzabW",
    "id" : 532940966668169216,
    "created_at" : "2014-11-13 17:00:02 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 532956492035801089,
  "created_at" : "2014-11-13 18:01:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532945308112920576\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Q9loyUIOxD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2Vm5YCIAAA5r6M.jpg",
      "id_str" : "532945266803212288",
      "id" : 532945266803212288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2Vm5YCIAAA5r6M.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Q9loyUIOxD"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/i57ih8yv73",
      "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans\/",
      "display_url" : "healthcare.gov\/see-plans\/"
    } ]
  },
  "geo" : { },
  "id_str" : "532945308112920576",
  "text" : "You can sign up for health coverage starting on Saturday. See your options \u2192 https:\/\/t.co\/i57ih8yv73 #GetCovered http:\/\/t.co\/Q9loyUIOxD",
  "id" : 532945308112920576,
  "created_at" : "2014-11-13 17:17:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/OwjutKbaCF",
      "expanded_url" : "http:\/\/youtu.be\/egpQUB55FWg",
      "display_url" : "youtu.be\/egpQUB55FWg"
    } ]
  },
  "geo" : { },
  "id_str" : "532937888565317632",
  "text" : "Watch a recap of President Obama's trip to China, including new commitments to reduce carbon pollution: http:\/\/t.co\/OwjutKbaCF #ActOnClimate",
  "id" : 532937888565317632,
  "created_at" : "2014-11-13 16:47:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/7aGUmPQNTW",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    }, {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/n79BpJrcWK",
      "expanded_url" : "http:\/\/youtu.be\/jQbymKIyJns",
      "display_url" : "youtu.be\/jQbymKIyJns"
    } ]
  },
  "geo" : { },
  "id_str" : "532927211188547585",
  "text" : "#ItsOnUs to stop sexual assault. Take the pledge and be a part of the solution at http:\/\/t.co\/7aGUmPQNTW. http:\/\/t.co\/n79BpJrcWK",
  "id" : 532927211188547585,
  "created_at" : "2014-11-13 16:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/k8XAk4Cp2n",
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532908216019984384",
      "display_url" : "twitter.com\/WhiteHouse\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532911241275400194",
  "text" : "RT @twitter: The @WhiteHouse just debuted new #ItsOnUs PSA w\/ Twitter video tool. Watch this important message here: https:\/\/t.co\/k8XAk4Cp2n",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 33, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/k8XAk4Cp2n",
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532908216019984384",
        "display_url" : "twitter.com\/WhiteHouse\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532911097175498752",
    "text" : "The @WhiteHouse just debuted new #ItsOnUs PSA w\/ Twitter video tool. Watch this important message here: https:\/\/t.co\/k8XAk4Cp2n",
    "id" : 532911097175498752,
    "created_at" : "2014-11-13 15:01:21 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767879603977191425\/29zfZY6I_normal.jpg",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 532911241275400194,
  "created_at" : "2014-11-13 15:01:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/8fO4cJoHpl",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/20fae610-67a4-4303-88db-5a83ab60c765",
      "display_url" : "amp.twimg.com\/v\/20fae610-67a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532908216019984384",
  "text" : "#ItsOnUs to:\nStep up and say something.\nNot look the other way.\nWatch this PSA &amp; pledge to help stop sexual assault:\nhttps:\/\/t.co\/8fO4cJoHpl",
  "id" : 532908216019984384,
  "created_at" : "2014-11-13 14:49:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/532699259477307392\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/VETG0LaQwX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2SG72PIQAAclEH.jpg",
      "id_str" : "532699018665934848",
      "id" : 532699018665934848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2SG72PIQAAclEH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VETG0LaQwX"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532699259477307392",
  "text" : "FACT: President Obama just set a new target to cut U.S. carbon pollution by 26-28% by 2025. #ActOnClimate http:\/\/t.co\/VETG0LaQwX",
  "id" : 532699259477307392,
  "created_at" : "2014-11-13 00:59:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/3QzBrnlUeU",
      "expanded_url" : "http:\/\/bit.ly\/1wkHSOs",
      "display_url" : "bit.ly\/1wkHSOs"
    } ]
  },
  "geo" : { },
  "id_str" : "532689359024037888",
  "text" : "RT @voxdotcom: After 9 months of negotiations the US &amp; China reached a major deal on cutting emissions http:\/\/t.co\/3QzBrnlUeU http:\/\/t.co\/H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/voxdotcom\/status\/532497998648205312\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Hs6Mhn01dc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2PP_8oCYAACtyU.jpg",
        "id_str" : "532497878472613888",
        "id" : 532497878472613888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2PP_8oCYAACtyU.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Hs6Mhn01dc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/3QzBrnlUeU",
        "expanded_url" : "http:\/\/bit.ly\/1wkHSOs",
        "display_url" : "bit.ly\/1wkHSOs"
      } ]
    },
    "geo" : { },
    "id_str" : "532688044130697216",
    "text" : "After 9 months of negotiations the US &amp; China reached a major deal on cutting emissions http:\/\/t.co\/3QzBrnlUeU http:\/\/t.co\/Hs6Mhn01dc",
    "id" : 532688044130697216,
    "created_at" : "2014-11-13 00:15:01 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 532689359024037888,
  "created_at" : "2014-11-13 00:20:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532682735098134528\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/9VjvoUvMxU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2R4HQTIUAACRm-.jpg",
      "id_str" : "532682721966182400",
      "id" : 532682721966182400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2R4HQTIUAACRm-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9VjvoUvMxU"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 37, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/sL85pDk8wu",
      "expanded_url" : "https:\/\/www.healthcare.gov\/see-plans\/",
      "display_url" : "healthcare.gov\/see-plans\/"
    } ]
  },
  "geo" : { },
  "id_str" : "532682735098134528",
  "text" : "If you need health coverage, you can #GetCovered starting November 15th. See your options \u2192 https:\/\/t.co\/sL85pDk8wu http:\/\/t.co\/9VjvoUvMxU",
  "id" : 532682735098134528,
  "created_at" : "2014-11-12 23:53:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 3, 11 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 48, 59 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "AFI",
      "screen_name" : "AmericanFilm",
      "indices" : [ 104, 117 ],
      "id_str" : "24254832",
      "id" : 24254832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532665505350295554",
  "text" : "RT @WHVideo: Big news: We're announcing the 2nd @WhiteHouse Student Film Festival in collaboration with @AmericanFilm: http:\/\/t.co\/0WaeJ73F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 35, 46 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "AFI",
        "screen_name" : "AmericanFilm",
        "indices" : [ 91, 104 ],
        "id_str" : "24254832",
        "id" : 24254832
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHFilmFest",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/0WaeJ73FPv",
        "expanded_url" : "http:\/\/wh.gov\/FilmFest",
        "display_url" : "wh.gov\/FilmFest"
      } ]
    },
    "geo" : { },
    "id_str" : "532665410244845569",
    "text" : "Big news: We're announcing the 2nd @WhiteHouse Student Film Festival in collaboration with @AmericanFilm: http:\/\/t.co\/0WaeJ73FPv #WHFilmFest",
    "id" : 532665410244845569,
    "created_at" : "2014-11-12 22:45:04 +0000",
    "user" : {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "protected" : false,
      "id_str" : "1378231782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3636216064\/e21f3204adfdbc85dafef197487218a0_normal.jpeg",
      "id" : 1378231782,
      "verified" : true
    }
  },
  "id" : 532665505350295554,
  "created_at" : "2014-11-12 22:45:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 3, 15 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/qQ89cosVe6",
      "expanded_url" : "http:\/\/go.wh.gov\/HY5PRG",
      "display_url" : "go.wh.gov\/HY5PRG"
    } ]
  },
  "geo" : { },
  "id_str" : "532643260217298945",
  "text" : "RT @billclinton: Great news last night on historic climate cooperation between the US and China #ActOnClimate http:\/\/t.co\/qQ89cosVe6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 79, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/qQ89cosVe6",
        "expanded_url" : "http:\/\/go.wh.gov\/HY5PRG",
        "display_url" : "go.wh.gov\/HY5PRG"
      } ]
    },
    "geo" : { },
    "id_str" : "532642059501703168",
    "text" : "Great news last night on historic climate cooperation between the US and China #ActOnClimate http:\/\/t.co\/qQ89cosVe6",
    "id" : 532642059501703168,
    "created_at" : "2014-11-12 21:12:17 +0000",
    "user" : {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "protected" : false,
      "id_str" : "1330457336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451207149478096896\/HoMUOmyu_normal.jpeg",
      "id" : 1330457336,
      "verified" : true
    }
  },
  "id" : 532643260217298945,
  "created_at" : "2014-11-12 21:17:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532632373863534592",
  "text" : "RT @repjohnlewis: It is our obligation to leave this little spaceship we call Earth a little cleaner and a little greener for generations y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532631506024673281",
    "text" : "It is our obligation to leave this little spaceship we call Earth a little cleaner and a little greener for generations yet unborn.",
    "id" : 532631506024673281,
    "created_at" : "2014-11-12 20:30:21 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 532632373863534592,
  "created_at" : "2014-11-12 20:33:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Frist, M.D.",
      "screen_name" : "bfrist",
      "indices" : [ 14, 21 ],
      "id_str" : "5660532",
      "id" : 5660532
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/rnbwZSSE0v",
      "expanded_url" : "http:\/\/fxn.ws\/1Ba6Yre",
      "display_url" : "fxn.ws\/1Ba6Yre"
    } ]
  },
  "geo" : { },
  "id_str" : "532618614499991552",
  "text" : "Worth a read: @Bfrist on why Congress should approve the President's funding request to fight #Ebola in West Africa \u2192 http:\/\/t.co\/rnbwZSSE0v",
  "id" : 532618614499991552,
  "created_at" : "2014-11-12 19:39:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532590466588758018\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Nxydg6Iwd1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2QkExFIMAAYnnz.jpg",
      "id_str" : "532590320249483264",
      "id" : 532590320249483264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2QkExFIMAAYnnz.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Nxydg6Iwd1"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/v0k6bybtG6",
      "expanded_url" : "http:\/\/go.wh.gov\/uQFZeG",
      "display_url" : "go.wh.gov\/uQFZeG"
    } ]
  },
  "geo" : { },
  "id_str" : "532590466588758018",
  "text" : "Let's keep fighting to give every woman the chance to realize her dreams \u2192 http:\/\/t.co\/v0k6bybtG6 #WomenSucceed http:\/\/t.co\/Nxydg6Iwd1",
  "id" : 532590466588758018,
  "created_at" : "2014-11-12 17:47:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532576141199310849\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/eJsLwtT3tm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2QXFS9CQAAuqiS.jpg",
      "id_str" : "532576035691184128",
      "id" : 532576035691184128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2QXFS9CQAAuqiS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eJsLwtT3tm"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 66, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/52GMrkGj51",
      "expanded_url" : "http:\/\/go.wh.gov\/HY5PRG",
      "display_url" : "go.wh.gov\/HY5PRG"
    } ]
  },
  "geo" : { },
  "id_str" : "532576141199310849",
  "text" : "See how President Obama is building on the progress we've made to #ActOnClimate \u2192 http:\/\/t.co\/52GMrkGj51 http:\/\/t.co\/eJsLwtT3tm",
  "id" : 532576141199310849,
  "created_at" : "2014-11-12 16:50:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philae Lander",
      "screen_name" : "Philae2014",
      "indices" : [ 3, 14 ],
      "id_str" : "208442526",
      "id" : 208442526
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CometLanding",
      "indices" : [ 48, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532567168882573312",
  "text" : "RT @Philae2014: Touchdown! My new address: 67P! #CometLanding",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CometLanding",
        "indices" : [ 32, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532564514051735552",
    "text" : "Touchdown! My new address: 67P! #CometLanding",
    "id" : 532564514051735552,
    "created_at" : "2014-11-12 16:04:09 +0000",
    "user" : {
      "name" : "Philae Lander",
      "screen_name" : "Philae2014",
      "protected" : false,
      "id_str" : "208442526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/532839122797211648\/M5ayKX24_normal.jpeg",
      "id" : 208442526,
      "verified" : true
    }
  },
  "id" : 532567168882573312,
  "created_at" : "2014-11-12 16:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 30, 34 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/532561702580400128\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/rWSh1fk801",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2QJ8n7CYAEx-8o.jpg",
      "id_str" : "532561593049964545",
      "id" : 532561593049964545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2QJ8n7CYAEx-8o.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rWSh1fk801"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 46, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/xF3gOG7xcA",
      "expanded_url" : "http:\/\/go.wh.gov\/YXmsuS",
      "display_url" : "go.wh.gov\/YXmsuS"
    } ]
  },
  "geo" : { },
  "id_str" : "532561702580400128",
  "text" : "President Obama is urging the @FCC to protect #NetNeutrality. Get the facts on his plan: http:\/\/t.co\/xF3gOG7xcA http:\/\/t.co\/rWSh1fk801",
  "id" : 532561702580400128,
  "created_at" : "2014-11-12 15:52:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532549792837414912\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/47xmPKDDG1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2P_AkGCEAATYvp.jpg",
      "id_str" : "532549566113910784",
      "id" : 532549566113910784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2P_AkGCEAATYvp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/47xmPKDDG1"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/52GMrkGj51",
      "expanded_url" : "http:\/\/go.wh.gov\/HY5PRG",
      "display_url" : "go.wh.gov\/HY5PRG"
    } ]
  },
  "geo" : { },
  "id_str" : "532549792837414912",
  "text" : "We can't leave our kids a planet that's beyond repair. See our latest steps to #ActOnClimate: http:\/\/t.co\/52GMrkGj51 http:\/\/t.co\/47xmPKDDG1",
  "id" : 532549792837414912,
  "created_at" : "2014-11-12 15:05:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 80, 85 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "ESA Rosetta Mission",
      "screen_name" : "ESA_Rosetta",
      "indices" : [ 109, 121 ],
      "id_str" : "253536357",
      "id" : 253536357
    }, {
      "name" : "Philae Lander",
      "screen_name" : "Philae2014",
      "indices" : [ 122, 133 ],
      "id_str" : "208442526",
      "id" : 208442526
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CometLanding",
      "indices" : [ 52, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/6b07FGmMZS",
      "expanded_url" : "http:\/\/www.nasa.gov\/multimedia\/nasatv\/index.html#.VGNvIvnF8wA",
      "display_url" : "nasa.gov\/multimedia\/nas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532545497228390401",
  "text" : "RT @whitehouseostp: Landing in about one hour! Live #CometLanding coverage from @NASA http:\/\/t.co\/6b07FGmMZS @ESA_Rosetta @Philae2014 http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 60, 65 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "ESA Rosetta Mission",
        "screen_name" : "ESA_Rosetta",
        "indices" : [ 89, 101 ],
        "id_str" : "253536357",
        "id" : 253536357
      }, {
        "name" : "Philae Lander",
        "screen_name" : "Philae2014",
        "indices" : [ 102, 113 ],
        "id_str" : "208442526",
        "id" : 208442526
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/532545160333127681\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/eKwZrYXXx4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2P7ADsIEAAwsY9.jpg",
        "id_str" : "532545159368806400",
        "id" : 532545159368806400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2P7ADsIEAAwsY9.jpg",
        "sizes" : [ {
          "h" : 169,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 753
        }, {
          "h" : 299,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 753
        } ],
        "display_url" : "pic.twitter.com\/eKwZrYXXx4"
      } ],
      "hashtags" : [ {
        "text" : "CometLanding",
        "indices" : [ 32, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/6b07FGmMZS",
        "expanded_url" : "http:\/\/www.nasa.gov\/multimedia\/nasatv\/index.html#.VGNvIvnF8wA",
        "display_url" : "nasa.gov\/multimedia\/nas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532545160333127681",
    "text" : "Landing in about one hour! Live #CometLanding coverage from @NASA http:\/\/t.co\/6b07FGmMZS @ESA_Rosetta @Philae2014 http:\/\/t.co\/eKwZrYXXx4",
    "id" : 532545160333127681,
    "created_at" : "2014-11-12 14:47:15 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 532545497228390401,
  "created_at" : "2014-11-12 14:48:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532537787346866176\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/p1yL44x4iY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2P0QZBCAAAZ_7L.jpg",
      "id_str" : "532537743390146560",
      "id" : 532537743390146560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2P0QZBCAAAZ_7L.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/p1yL44x4iY"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/3Ns7QaNnAr",
      "expanded_url" : "http:\/\/go.wh.gov\/ontD8L",
      "display_url" : "go.wh.gov\/ontD8L"
    } ]
  },
  "geo" : { },
  "id_str" : "532537787346866176",
  "text" : "Get the facts on the U.S. &amp; China's new commitments to reduce carbon pollution: http:\/\/t.co\/3Ns7QaNnAr #ActOnClimate http:\/\/t.co\/p1yL44x4iY",
  "id" : 532537787346866176,
  "created_at" : "2014-11-12 14:17:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532390784318722048\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/HU2ODbxsXS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2NueeKCcAAy4Gm.jpg",
      "id_str" : "532390650730147840",
      "id" : 532390650730147840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2NueeKCcAAy4Gm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HU2ODbxsXS"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532390784318722048",
  "text" : "FACT: President Obama just set a new target to cut U.S. carbon pollution by 26-28% by 2025. #ActOnClimate http:\/\/t.co\/HU2ODbxsXS",
  "id" : 532390784318722048,
  "created_at" : "2014-11-12 04:33:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532387713953976320\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/r2JtIKzes3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2NjVRmCQAAKJm7.jpg",
      "id_str" : "532378398111186944",
      "id" : 532378398111186944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2NjVRmCQAAKJm7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/r2JtIKzes3"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/pW5LQYzFRr",
      "expanded_url" : "http:\/\/go.wh.gov\/ontD8L",
      "display_url" : "go.wh.gov\/ontD8L"
    } ]
  },
  "geo" : { },
  "id_str" : "532387713953976320",
  "text" : "Big news: The U.S. &amp; China just announced new targets to cut carbon pollution \u2192 http:\/\/t.co\/pW5LQYzFRr #ActOnClimate http:\/\/t.co\/r2JtIKzes3",
  "id" : 532387713953976320,
  "created_at" : "2014-11-12 04:21:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/532285207311683584\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/RHHgZzUZKm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2MOkjIIAAEOV0h.png",
      "id_str" : "532285202027249665",
      "id" : 532285202027249665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2MOkjIIAAEOV0h.png",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/RHHgZzUZKm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532326549844811777",
  "text" : "RT @VP: We stand here today to show our respect, and to recognize our responsibility to care for all our veterans. http:\/\/t.co\/RHHgZzUZKm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/532285207311683584\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/RHHgZzUZKm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2MOkjIIAAEOV0h.png",
        "id_str" : "532285202027249665",
        "id" : 532285202027249665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2MOkjIIAAEOV0h.png",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/RHHgZzUZKm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532285207311683584",
    "text" : "We stand here today to show our respect, and to recognize our responsibility to care for all our veterans. http:\/\/t.co\/RHHgZzUZKm",
    "id" : 532285207311683584,
    "created_at" : "2014-11-11 21:34:17 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 532326549844811777,
  "created_at" : "2014-11-12 00:18:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532309543556878338\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/CDwWILm7aJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2MkpYFCIAEyfwi.png",
      "id_str" : "532309474216648705",
      "id" : 532309474216648705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2MkpYFCIAEyfwi.png",
      "sizes" : [ {
        "h" : 276,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 92,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 1089
      } ],
      "display_url" : "pic.twitter.com\/CDwWILm7aJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532309543556878338",
  "text" : "\"John put his life on the line to make real our country\u2019s promise of equal rights for all.\" \u2014Obama on John Doar: http:\/\/t.co\/CDwWILm7aJ",
  "id" : 532309543556878338,
  "created_at" : "2014-11-11 23:10:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 20, 32 ]
    }, {
      "text" : "publiclands",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Hh1dWCvTXj",
      "expanded_url" : "http:\/\/youtu.be\/eJaQ7-sHCcc",
      "display_url" : "youtu.be\/eJaQ7-sHCcc"
    } ]
  },
  "geo" : { },
  "id_str" : "532294633691160577",
  "text" : "RT @Interior: Happy #VeteransDay! We're celebrating with this great video of veterans enjoying #publiclands http:\/\/t.co\/Hh1dWCvTXj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 6, 18 ]
      }, {
        "text" : "publiclands",
        "indices" : [ 81, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/Hh1dWCvTXj",
        "expanded_url" : "http:\/\/youtu.be\/eJaQ7-sHCcc",
        "display_url" : "youtu.be\/eJaQ7-sHCcc"
      } ]
    },
    "geo" : { },
    "id_str" : "532174222710571011",
    "text" : "Happy #VeteransDay! We're celebrating with this great video of veterans enjoying #publiclands http:\/\/t.co\/Hh1dWCvTXj",
    "id" : 532174222710571011,
    "created_at" : "2014-11-11 14:13:16 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 532294633691160577,
  "created_at" : "2014-11-11 22:11:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532267420774592512\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/xetUn4jN3l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2L930ACYAAvm7q.jpg",
      "id_str" : "532266841276571648",
      "id" : 532266841276571648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2L930ACYAAvm7q.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xetUn4jN3l"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 86, 98 ]
    }, {
      "text" : "HonoringVets",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/HwXAN4BWOf",
      "expanded_url" : "http:\/\/go.wh.gov\/RfoYkW",
      "display_url" : "go.wh.gov\/RfoYkW"
    } ]
  },
  "geo" : { },
  "id_str" : "532267420774592512",
  "text" : "It's our sacred obligation to help every veteran find a home \u2192 http:\/\/t.co\/HwXAN4BWOf #VeteransDay #HonoringVets http:\/\/t.co\/xetUn4jN3l",
  "id" : 532267420774592512,
  "created_at" : "2014-11-11 20:23:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/532252587215446016\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/btSdHIkGBy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2Lwy8eCcAEP-BK.jpg",
      "id_str" : "532252463999381505",
      "id" : 532252463999381505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2Lwy8eCcAEP-BK.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/btSdHIkGBy"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 75, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/uow9QuKAR2",
      "expanded_url" : "http:\/\/youtu.be\/HYXhnj2TD_Y",
      "display_url" : "youtu.be\/HYXhnj2TD_Y"
    } ]
  },
  "geo" : { },
  "id_str" : "532252587215446016",
  "text" : "\"If you see a veteran, go on up and shake their hand.\" \u2014President Obama on #VeteransDay: http:\/\/t.co\/uow9QuKAR2 http:\/\/t.co\/btSdHIkGBy",
  "id" : 532252587215446016,
  "created_at" : "2014-11-11 19:24:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 3, 15 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 20, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532240712696614913",
  "text" : "RT @billclinton: On #VeteransDay, honoring all the brave men and women who have given - and\ncontinue to give - so much to our great country.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 3, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532236947121774592",
    "text" : "On #VeteransDay, honoring all the brave men and women who have given - and\ncontinue to give - so much to our great country.",
    "id" : 532236947121774592,
    "created_at" : "2014-11-11 18:22:31 +0000",
    "user" : {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "protected" : false,
      "id_str" : "1330457336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451207149478096896\/HoMUOmyu_normal.jpeg",
      "id" : 1330457336,
      "verified" : true
    }
  },
  "id" : 532240712696614913,
  "created_at" : "2014-11-11 18:37:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532222077915234304",
  "text" : "RT @FLOTUS: Today, we salute the brave men and women who keep us safe each and every day. Thank you for your service and sacrifice. #Vetera\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 120, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532220359307575296",
    "text" : "Today, we salute the brave men and women who keep us safe each and every day. Thank you for your service and sacrifice. #VeteransDay \u2013mo",
    "id" : 532220359307575296,
    "created_at" : "2014-11-11 17:16:36 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 532222077915234304,
  "created_at" : "2014-11-11 17:23:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532219937448677376",
  "text" : "RT @DeptVetAffairs: Veterans are honored with a wreath-laying ceremony at the WWII Memorial in Washington, DC #HonoringVets http:\/\/t.co\/Dai\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeptVetAffairs\/status\/532210902792036354\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/DaiekZtSK3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2LK_wJCYAAohr_.jpg",
        "id_str" : "532210902586515456",
        "id" : 532210902586515456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2LK_wJCYAAohr_.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/DaiekZtSK3"
      } ],
      "hashtags" : [ {
        "text" : "HonoringVets",
        "indices" : [ 90, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532210902792036354",
    "text" : "Veterans are honored with a wreath-laying ceremony at the WWII Memorial in Washington, DC #HonoringVets http:\/\/t.co\/DaiekZtSK3",
    "id" : 532210902792036354,
    "created_at" : "2014-11-11 16:39:01 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 532219937448677376,
  "created_at" : "2014-11-11 17:14:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532218204249407488",
  "text" : "RT @VP: \"As Jill points out, only 1% of America\u2019s population serves in uniform, but 99% of all Americans owe that 1%.\" -Vice President Biden",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532213733658198016",
    "text" : "\"As Jill points out, only 1% of America\u2019s population serves in uniform, but 99% of all Americans owe that 1%.\" -Vice President Biden",
    "id" : 532213733658198016,
    "created_at" : "2014-11-11 16:50:16 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 532218204249407488,
  "created_at" : "2014-11-11 17:08:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/cMefR9j25x",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/vice-president-biden-speaks-arlington-national-cemetery",
      "display_url" : "whitehouse.gov\/live\/vice-pres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532216980636307456",
  "text" : "RT @VP: \"You are the heart and soul, and the very spine of this nation.\" -Vice President Biden to America's veterans http:\/\/t.co\/cMefR9j25x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/cMefR9j25x",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/vice-president-biden-speaks-arlington-national-cemetery",
        "display_url" : "whitehouse.gov\/live\/vice-pres\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532211819763363840",
    "text" : "\"You are the heart and soul, and the very spine of this nation.\" -Vice President Biden to America's veterans http:\/\/t.co\/cMefR9j25x",
    "id" : 532211819763363840,
    "created_at" : "2014-11-11 16:42:40 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 532216980636307456,
  "created_at" : "2014-11-11 17:03:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532211709054705664",
  "text" : "RT @VP: \"We pause today to thank the more than 23 million surviving veterans who have so bravely and faithfully protected our freedom.\" -VP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532211512455098369",
    "text" : "\"We pause today to thank the more than 23 million surviving veterans who have so bravely and faithfully protected our freedom.\" -VP Biden",
    "id" : 532211512455098369,
    "created_at" : "2014-11-11 16:41:27 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 532211709054705664,
  "created_at" : "2014-11-11 16:42:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/bDPpaMe0dM",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/vice-president-biden-speaks-arlington-national-cemetery",
      "display_url" : "whitehouse.gov\/live\/vice-pres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "532207657500020736",
  "text" : "RT @VP: Happening soon: Vice President Biden speaks at Arlington National Cemetery on Veterans Day http:\/\/t.co\/bDPpaMe0dM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/bDPpaMe0dM",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/vice-president-biden-speaks-arlington-national-cemetery",
        "display_url" : "whitehouse.gov\/live\/vice-pres\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "532200628303708160",
    "text" : "Happening soon: Vice President Biden speaks at Arlington National Cemetery on Veterans Day http:\/\/t.co\/bDPpaMe0dM",
    "id" : 532200628303708160,
    "created_at" : "2014-11-11 15:58:12 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 532207657500020736,
  "created_at" : "2014-11-11 16:26:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 70, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/6al7dRMo2a",
      "expanded_url" : "https:\/\/vine.co\/v\/OiJg0KzHxta",
      "display_url" : "vine.co\/v\/OiJg0KzHxta"
    } ]
  },
  "geo" : { },
  "id_str" : "531980700136648704",
  "text" : "It's\ntime\nto\nkeep\nthe\ninternet\nopen\nand\nfree.\nhttps:\/\/t.co\/6al7dRMo2a\n#NetNeutrality",
  "id" : 531980700136648704,
  "created_at" : "2014-11-11 01:24:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/531951286476750849\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/IPlWwxbZ3Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2Hd5o2CEAAjadG.jpg",
      "id_str" : "531950213292756992",
      "id" : 531950213292756992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2Hd5o2CEAAjadG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IPlWwxbZ3Z"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 74, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/MRwZ8tWtUz",
      "expanded_url" : "https:\/\/medium.com\/@PresidentObama\/my-plan-for-a-free-and-open-internet-c45e2f4ab1e4",
      "display_url" : "medium.com\/@PresidentObam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531951286476750849",
  "text" : "\"My commitment remains as strong as ever.\" \u2014President Obama on protecting #NetNeutrality: https:\/\/t.co\/MRwZ8tWtUz http:\/\/t.co\/IPlWwxbZ3Z",
  "id" : 531951286476750849,
  "created_at" : "2014-11-10 23:27:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531944572994088960",
  "text" : "RT @GovernorOMalley: I agree with President Obama's Net Neutrality approach. We shouldn't have gatekeepers picking winners &amp; losers online.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531935158493261824",
    "text" : "I agree with President Obama's Net Neutrality approach. We shouldn't have gatekeepers picking winners &amp; losers online.",
    "id" : 531935158493261824,
    "created_at" : "2014-11-10 22:23:19 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 531944572994088960,
  "created_at" : "2014-11-10 23:00:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/531938038880796672\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/OBUbNIKT4u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2HSppTCAAATb5k.jpg",
      "id_str" : "531937843908575232",
      "id" : 531937843908575232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2HSppTCAAATb5k.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OBUbNIKT4u"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Tctsw0sTgK",
      "expanded_url" : "http:\/\/go.wh.gov\/TvB2v1",
      "display_url" : "go.wh.gov\/TvB2v1"
    } ]
  },
  "geo" : { },
  "id_str" : "531938038880796672",
  "text" : "Get the latest on how today's new visa policy will boost tourism and support American jobs \u2192 http:\/\/t.co\/Tctsw0sTgK http:\/\/t.co\/OBUbNIKT4u",
  "id" : 531938038880796672,
  "created_at" : "2014-11-10 22:34:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531933822037024769",
  "text" : "RT @Interior: Enjoy the great outdoors tomorrow with free entrance to all public lands on Veterans Day. RT to spread the word! http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/531932069149302784\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/74egpIgAHJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2HNZbbIQAAmMs4.jpg",
        "id_str" : "531932067748397056",
        "id" : 531932067748397056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2HNZbbIQAAmMs4.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 996,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/74egpIgAHJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531932069149302784",
    "text" : "Enjoy the great outdoors tomorrow with free entrance to all public lands on Veterans Day. RT to spread the word! http:\/\/t.co\/74egpIgAHJ",
    "id" : 531932069149302784,
    "created_at" : "2014-11-10 22:11:02 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 531933822037024769,
  "created_at" : "2014-11-10 22:18:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/tPPpk4Nsgm",
      "expanded_url" : "http:\/\/wrd.cm\/144H8X6",
      "display_url" : "wrd.cm\/144H8X6"
    } ]
  },
  "geo" : { },
  "id_str" : "531931953566478336",
  "text" : "RT @WIRED: President Obama calls on the FCC to uphold Net Neutrality http:\/\/t.co\/tPPpk4Nsgm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/tPPpk4Nsgm",
        "expanded_url" : "http:\/\/wrd.cm\/144H8X6",
        "display_url" : "wrd.cm\/144H8X6"
      } ]
    },
    "geo" : { },
    "id_str" : "531848990388920320",
    "text" : "President Obama calls on the FCC to uphold Net Neutrality http:\/\/t.co\/tPPpk4Nsgm",
    "id" : 531848990388920320,
    "created_at" : "2014-11-10 16:40:55 +0000",
    "user" : {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615598832726970372\/jsK-gBSt_normal.png",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 531931953566478336,
  "created_at" : "2014-11-10 22:10:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Firefox",
      "screen_name" : "firefox",
      "indices" : [ 3, 11 ],
      "id_str" : "2142731",
      "id" : 2142731
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 66, 77 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531929286832173056",
  "text" : "RT @firefox: We stand for the open Web &amp; are thrilled to hear @WhiteHouse's plan to protect #NetNeutrality on our 10th anniversary http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 53, 64 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NetNeutrality",
        "indices" : [ 83, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/JqyPD1fRBC",
        "expanded_url" : "http:\/\/mzl.la\/1wLjrxs",
        "display_url" : "mzl.la\/1wLjrxs"
      } ]
    },
    "geo" : { },
    "id_str" : "531849672605044736",
    "text" : "We stand for the open Web &amp; are thrilled to hear @WhiteHouse's plan to protect #NetNeutrality on our 10th anniversary http:\/\/t.co\/JqyPD1fRBC",
    "id" : 531849672605044736,
    "created_at" : "2014-11-10 16:43:37 +0000",
    "user" : {
      "name" : "Firefox",
      "screen_name" : "firefox",
      "protected" : false,
      "id_str" : "2142731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747872627218350081\/37FasHm-_normal.jpg",
      "id" : 2142731,
      "verified" : true
    }
  },
  "id" : 531929286832173056,
  "created_at" : "2014-11-10 21:59:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/531921626200158208\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/LFkpfwaZUZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2HDvLeCEAAmbmI.jpg",
      "id_str" : "531921446306451456",
      "id" : 531921446306451456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2HDvLeCEAAmbmI.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LFkpfwaZUZ"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 18, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531921626200158208",
  "text" : "President Obama's #NetNeutrality plan would \u2191 transparency to prevent ISPs from giving websites special treatment. http:\/\/t.co\/LFkpfwaZUZ",
  "id" : 531921626200158208,
  "created_at" : "2014-11-10 21:29:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 3, 10 ],
      "id_str" : "52484614",
      "id" : 52484614
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 67, 78 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/RLPvRt4lOh",
      "expanded_url" : "http:\/\/tmblr.co\/ZE5Fby1VHKxLZ",
      "display_url" : "tmblr.co\/ZE5Fby1VHKxLZ"
    } ]
  },
  "geo" : { },
  "id_str" : "531900488011087872",
  "text" : "RT @tumblr: This is huge: A strong approach to net neutrality from @WhiteHouse: http:\/\/t.co\/RLPvRt4lOh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 55, 66 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/RLPvRt4lOh",
        "expanded_url" : "http:\/\/tmblr.co\/ZE5Fby1VHKxLZ",
        "display_url" : "tmblr.co\/ZE5Fby1VHKxLZ"
      } ]
    },
    "geo" : { },
    "id_str" : "531900025866301441",
    "text" : "This is huge: A strong approach to net neutrality from @WhiteHouse: http:\/\/t.co\/RLPvRt4lOh",
    "id" : 531900025866301441,
    "created_at" : "2014-11-10 20:03:43 +0000",
    "user" : {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "protected" : false,
      "id_str" : "52484614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791014307089747968\/jqxriE5C_normal.jpg",
      "id" : 52484614,
      "verified" : true
    }
  },
  "id" : 531900488011087872,
  "created_at" : "2014-11-10 20:05:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 3, 15 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/bOAhE5nZz5",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/net-neutrality",
      "display_url" : "whitehouse.gov\/net-neutrality"
    } ]
  },
  "geo" : { },
  "id_str" : "531887797259350016",
  "text" : "MT @Kickstarter: This is huge! President Obama is sticking up for a free and open Internet: http:\/\/t.co\/bOAhE5nZz5 #NetNeutrality",
  "id" : 531887797259350016,
  "created_at" : "2014-11-10 19:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Jay Inslee",
      "screen_name" : "GovInslee",
      "indices" : [ 3, 13 ],
      "id_str" : "1077214808",
      "id" : 1077214808
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 43, 54 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 58, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531887707853950976",
  "text" : "RT @GovInslee: I applaud strong stand from @WhiteHouse on #NetNeutrality. WA is a longtime vocal advocate for a free open internet http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 28, 39 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NetNeutrality",
        "indices" : [ 43, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/QSXLBKhLBd",
        "expanded_url" : "http:\/\/bit.ly\/1yqX3rr",
        "display_url" : "bit.ly\/1yqX3rr"
      } ]
    },
    "geo" : { },
    "id_str" : "531886629305069568",
    "text" : "I applaud strong stand from @WhiteHouse on #NetNeutrality. WA is a longtime vocal advocate for a free open internet http:\/\/t.co\/QSXLBKhLBd",
    "id" : 531886629305069568,
    "created_at" : "2014-11-10 19:10:29 +0000",
    "user" : {
      "name" : "Governor Jay Inslee",
      "screen_name" : "GovInslee",
      "protected" : false,
      "id_str" : "1077214808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738748381569253377\/EcSskMQ8_normal.jpg",
      "id" : 1077214808,
      "verified" : true
    }
  },
  "id" : 531887707853950976,
  "created_at" : "2014-11-10 19:14:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storyful",
      "screen_name" : "Storyful",
      "indices" : [ 3, 12 ],
      "id_str" : "119714092",
      "id" : 119714092
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "reddit AMA",
      "screen_name" : "reddit_AMA",
      "indices" : [ 43, 54 ],
      "id_str" : "524487620",
      "id" : 524487620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/NEgjB3zf78",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/comments\/2lvly9\/president_obama_just_announced_his_plan_to_keep\/",
      "display_url" : "reddit.com\/r\/IAmA\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531886299779567616",
  "text" : "RT @Storyful: The @WhiteHouse is running a @reddit_AMA on President Obama's #NetNeutrality plan now http:\/\/t.co\/NEgjB3zf78",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "reddit AMA",
        "screen_name" : "reddit_AMA",
        "indices" : [ 29, 40 ],
        "id_str" : "524487620",
        "id" : 524487620
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NetNeutrality",
        "indices" : [ 62, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/NEgjB3zf78",
        "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/comments\/2lvly9\/president_obama_just_announced_his_plan_to_keep\/",
        "display_url" : "reddit.com\/r\/IAmA\/comment\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "531885684056133632",
    "text" : "The @WhiteHouse is running a @reddit_AMA on President Obama's #NetNeutrality plan now http:\/\/t.co\/NEgjB3zf78",
    "id" : 531885684056133632,
    "created_at" : "2014-11-10 19:06:43 +0000",
    "user" : {
      "name" : "Storyful",
      "screen_name" : "Storyful",
      "protected" : false,
      "id_str" : "119714092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722432712812826626\/xT8MsF8f_normal.jpg",
      "id" : 119714092,
      "verified" : true
    }
  },
  "id" : 531886299779567616,
  "created_at" : "2014-11-10 19:09:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "reddit AMA",
      "screen_name" : "reddit_AMA",
      "indices" : [ 38, 49 ],
      "id_str" : "524487620",
      "id" : 524487620
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/531884258458345472\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/3A3MmY7A6i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2Gh6IzCEAAajz9.jpg",
      "id_str" : "531884251172442112",
      "id" : 531884251172442112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2Gh6IzCEAAajz9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3A3MmY7A6i"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 71, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/8t5Td18AXG",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/comments\/2lvly9\/president_obama_just_announced_his_plan_to_keep\/",
      "display_url" : "reddit.com\/r\/IAmA\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531884258458345472",
  "text" : "Right now: Join the @WhiteHouse for a @Reddit_AMA on President Obama's #NetNeutrality plan: http:\/\/t.co\/8t5Td18AXG http:\/\/t.co\/3A3MmY7A6i",
  "id" : 531884258458345472,
  "created_at" : "2014-11-10 19:01:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vimeo",
      "screen_name" : "Vimeo",
      "indices" : [ 3, 9 ],
      "id_str" : "14718218",
      "id" : 14718218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 36, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/AfmfqBuSHq",
      "expanded_url" : "https:\/\/vimeo.com\/blog\/post:659",
      "display_url" : "vimeo.com\/blog\/post:659"
    } ]
  },
  "geo" : { },
  "id_str" : "531881583075409920",
  "text" : "RT @Vimeo: President Obama supports #NetNeutrality \u2014 and you should, too. https:\/\/t.co\/AfmfqBuSHq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NetNeutrality",
        "indices" : [ 25, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/AfmfqBuSHq",
        "expanded_url" : "https:\/\/vimeo.com\/blog\/post:659",
        "display_url" : "vimeo.com\/blog\/post:659"
      } ]
    },
    "geo" : { },
    "id_str" : "531880997466689536",
    "text" : "President Obama supports #NetNeutrality \u2014 and you should, too. https:\/\/t.co\/AfmfqBuSHq",
    "id" : 531880997466689536,
    "created_at" : "2014-11-10 18:48:06 +0000",
    "user" : {
      "name" : "Vimeo",
      "screen_name" : "Vimeo",
      "protected" : false,
      "id_str" : "14718218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748713206416285696\/s_va9BwO_normal.jpg",
      "id" : 14718218,
      "verified" : true
    }
  },
  "id" : 531881583075409920,
  "created_at" : "2014-11-10 18:50:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Netflix US",
      "screen_name" : "netflix",
      "indices" : [ 3, 11 ],
      "id_str" : "16573941",
      "id" : 16573941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/0Qy6NMCnW2",
      "expanded_url" : "http:\/\/1.usa.gov\/1xdiOy6",
      "display_url" : "1.usa.gov\/1xdiOy6"
    } ]
  },
  "geo" : { },
  "id_str" : "531876947023101953",
  "text" : "MT @Netflix: Pres. Obama agrees: consumers should pick winners and losers on the Internet, not broadband gatekeepers. http:\/\/t.co\/0Qy6NMCnW2",
  "id" : 531876947023101953,
  "created_at" : "2014-11-10 18:32:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Etsy",
      "screen_name" : "Etsy",
      "indices" : [ 3, 8 ],
      "id_str" : "11522502",
      "id" : 11522502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/qfbhLtUXVR",
      "expanded_url" : "http:\/\/etsy.me\/1tyJOkj",
      "display_url" : "etsy.me\/1tyJOkj"
    } ]
  },
  "geo" : { },
  "id_str" : "531873990743031810",
  "text" : "MT @Etsy: An open and free Internet is for everyone. President Obama, thanks for supporting #NetNeutrality http:\/\/t.co\/qfbhLtUXVR",
  "id" : 531873990743031810,
  "created_at" : "2014-11-10 18:20:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "reddit AMA",
      "screen_name" : "reddit_AMA",
      "indices" : [ 76, 87 ],
      "id_str" : "524487620",
      "id" : 524487620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 51, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/8t5Td18AXG",
      "expanded_url" : "http:\/\/www.reddit.com\/r\/IAmA\/comments\/2lvly9\/president_obama_just_announced_his_plan_to_keep\/",
      "display_url" : "reddit.com\/r\/IAmA\/comment\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531871469861863424",
  "text" : "President Obama just announced his plan to protect #NetNeutrality.\nJoin our @Reddit_AMA at 2pm ET \u2192 http:\/\/t.co\/8t5Td18AXG",
  "id" : 531871469861863424,
  "created_at" : "2014-11-10 18:10:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "indices" : [ 3, 8 ],
      "id_str" : "1183041",
      "id" : 1183041
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 61, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531869049454886913",
  "text" : "RT @wilw: I am so happy to read the president\u2019s statement on #NetNeutrality today. This is the strong, unambiguous message I\u2019ve been waitin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NetNeutrality",
        "indices" : [ 51, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531867016852799490",
    "text" : "I am so happy to read the president\u2019s statement on #NetNeutrality today. This is the strong, unambiguous message I\u2019ve been waiting for.",
    "id" : 531867016852799490,
    "created_at" : "2014-11-10 17:52:33 +0000",
    "user" : {
      "name" : "Wil Wheaton",
      "screen_name" : "wilw",
      "protected" : false,
      "id_str" : "1183041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793503013851631616\/55p1uw70_normal.jpg",
      "id" : 1183041,
      "verified" : true
    }
  },
  "id" : 531869049454886913,
  "created_at" : "2014-11-10 18:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 47, 58 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 22, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/pIWKFe4djr",
      "expanded_url" : "http:\/\/go.wh.gov\/net-neutrality",
      "display_url" : "go.wh.gov\/net-neutrality"
    } ]
  },
  "geo" : { },
  "id_str" : "531862625315876865",
  "text" : "RT @CoryBooker: Great #NetNeutrality plan from @WhiteHouse to keep the internet open and free. Read about it here: http:\/\/t.co\/pIWKFe4djr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 31, 42 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NetNeutrality",
        "indices" : [ 6, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/pIWKFe4djr",
        "expanded_url" : "http:\/\/go.wh.gov\/net-neutrality",
        "display_url" : "go.wh.gov\/net-neutrality"
      } ]
    },
    "geo" : { },
    "id_str" : "531862286009638912",
    "text" : "Great #NetNeutrality plan from @WhiteHouse to keep the internet open and free. Read about it here: http:\/\/t.co\/pIWKFe4djr",
    "id" : 531862286009638912,
    "created_at" : "2014-11-10 17:33:45 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 531862625315876865,
  "created_at" : "2014-11-10 17:35:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Ben Cardin",
      "screen_name" : "SenatorCardin",
      "indices" : [ 3, 17 ],
      "id_str" : "109071031",
      "id" : 109071031
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 28, 39 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 65, 79 ]
    }, {
      "text" : "InternetFastlanes",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531856120394952704",
  "text" : "RT @SenatorCardin: Kudos to @WhiteHouse for continued support of #NetNeutrality. \nConstituents overwhelmingly say NO #InternetFastlanes htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 9, 20 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenatorCardin\/status\/531853279551295488\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/6wokIYqzqk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2GFvUVIIAErMP5.jpg",
        "id_str" : "531853278964097025",
        "id" : 531853278964097025,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2GFvUVIIAErMP5.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6wokIYqzqk"
      } ],
      "hashtags" : [ {
        "text" : "NetNeutrality",
        "indices" : [ 46, 60 ]
      }, {
        "text" : "InternetFastlanes",
        "indices" : [ 98, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531853279551295488",
    "text" : "Kudos to @WhiteHouse for continued support of #NetNeutrality. \nConstituents overwhelmingly say NO #InternetFastlanes http:\/\/t.co\/6wokIYqzqk",
    "id" : 531853279551295488,
    "created_at" : "2014-11-10 16:57:57 +0000",
    "user" : {
      "name" : "Senator Ben Cardin",
      "screen_name" : "SenatorCardin",
      "protected" : false,
      "id_str" : "109071031",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776828125573414912\/GaboV8L8_normal.jpg",
      "id" : 109071031,
      "verified" : true
    }
  },
  "id" : 531856120394952704,
  "created_at" : "2014-11-10 17:09:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 36, 40 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/3y3YLQD6MB",
      "expanded_url" : "http:\/\/go.wh.gov\/net-neutrality",
      "display_url" : "go.wh.gov\/net-neutrality"
    } ]
  },
  "geo" : { },
  "id_str" : "531855478260002816",
  "text" : "FACT: President Obama is urging the @FCC to prevent internet service providers from blocking legal online content \u2192 http:\/\/t.co\/3y3YLQD6MB",
  "id" : 531855478260002816,
  "created_at" : "2014-11-10 17:06:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Wyden",
      "screen_name" : "RonWyden",
      "indices" : [ 3, 12 ],
      "id_str" : "250188760",
      "id" : 250188760
    }, {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 47, 51 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531846963637940224",
  "text" : "RT @RonWyden: Retweet to join me in urging the @FCC to listen to the millions of Americans &amp; the President who have called for #NetNeutrali\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The FCC",
        "screen_name" : "FCC",
        "indices" : [ 33, 37 ],
        "id_str" : "66369206",
        "id" : 66369206
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NetNeutrality",
        "indices" : [ 117, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531835177778286592",
    "text" : "Retweet to join me in urging the @FCC to listen to the millions of Americans &amp; the President who have called for #NetNeutrality",
    "id" : 531835177778286592,
    "created_at" : "2014-11-10 15:46:02 +0000",
    "user" : {
      "name" : "Ron Wyden",
      "screen_name" : "RonWyden",
      "protected" : false,
      "id_str" : "250188760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649659158531297280\/w_0M4leg_normal.jpg",
      "id" : 250188760,
      "verified" : true
    }
  },
  "id" : 531846963637940224,
  "created_at" : "2014-11-10 16:32:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 47, 51 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/531845009944096769\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/BBl3AOFhP5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2F-H-uCcAAnDAn.jpg",
      "id_str" : "531844906566709248",
      "id" : 531844906566709248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2F-H-uCcAAnDAn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BBl3AOFhP5"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 63, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/3y3YLQD6MB",
      "expanded_url" : "http:\/\/go.wh.gov\/net-neutrality",
      "display_url" : "go.wh.gov\/net-neutrality"
    } ]
  },
  "geo" : { },
  "id_str" : "531845009944096769",
  "text" : "Spread the word: President Obama is urging the @FCC to protect #NetNeutrality \u2192 http:\/\/t.co\/3y3YLQD6MB http:\/\/t.co\/BBl3AOFhP5",
  "id" : 531845009944096769,
  "created_at" : "2014-11-10 16:25:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "just a backup",
      "screen_name" : "drizzled",
      "indices" : [ 129, 138 ],
      "id_str" : "59014109",
      "id" : 59014109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/DajC662YTa",
      "expanded_url" : "http:\/\/tcrn.ch\/1u1rFkr",
      "display_url" : "tcrn.ch\/1u1rFkr"
    } ]
  },
  "geo" : { },
  "id_str" : "531835826309566465",
  "text" : "RT @TechCrunch: President Obama Calls For A Free And Open Internet, Wants It Reclassified As A Utility http:\/\/t.co\/DajC662YTa by @drizzled",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/10up.com\" rel=\"nofollow\"\u003E10up Publish Tweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "just a backup",
        "screen_name" : "drizzled",
        "indices" : [ 113, 122 ],
        "id_str" : "59014109",
        "id" : 59014109
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/DajC662YTa",
        "expanded_url" : "http:\/\/tcrn.ch\/1u1rFkr",
        "display_url" : "tcrn.ch\/1u1rFkr"
      } ]
    },
    "geo" : { },
    "id_str" : "531818975449985025",
    "text" : "President Obama Calls For A Free And Open Internet, Wants It Reclassified As A Utility http:\/\/t.co\/DajC662YTa by @drizzled",
    "id" : 531818975449985025,
    "created_at" : "2014-11-10 14:41:39 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615392662233808896\/EtxjSSKk_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 531835826309566465,
  "created_at" : "2014-11-10 15:48:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Keith Ellison",
      "screen_name" : "keithellison",
      "indices" : [ 3, 16 ],
      "id_str" : "14135426",
      "id" : 14135426
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/4YgWKvGf1D",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/net-neutrality",
      "display_url" : "whitehouse.gov\/net-neutrality"
    } ]
  },
  "geo" : { },
  "id_str" : "531832231351042048",
  "text" : "RT @keithellison: Do you care about a free and open internet? So does President Obama. Read his plan: http:\/\/t.co\/4YgWKvGf1D #NetNeutrality",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NetNeutrality",
        "indices" : [ 107, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/4YgWKvGf1D",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/net-neutrality",
        "display_url" : "whitehouse.gov\/net-neutrality"
      } ]
    },
    "geo" : { },
    "id_str" : "531831671126249472",
    "text" : "Do you care about a free and open internet? So does President Obama. Read his plan: http:\/\/t.co\/4YgWKvGf1D #NetNeutrality",
    "id" : 531831671126249472,
    "created_at" : "2014-11-10 15:32:06 +0000",
    "user" : {
      "name" : "Rep. Keith Ellison",
      "screen_name" : "keithellison",
      "protected" : false,
      "id_str" : "14135426",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794278327070687234\/RRPkSnJI_normal.jpg",
      "id" : 14135426,
      "verified" : true
    }
  },
  "id" : 531832231351042048,
  "created_at" : "2014-11-10 15:34:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/nfOWGACKUP",
      "expanded_url" : "http:\/\/nyti.ms\/1ATZLvc",
      "display_url" : "nyti.ms\/1ATZLvc"
    } ]
  },
  "geo" : { },
  "id_str" : "531830113063927810",
  "text" : "RT @nytimes: Breaking News: Obama Urges F.C.C. to Adopt Rules to Protect Net Neutrality\nhttp:\/\/t.co\/nfOWGACKUP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nytimes.com\/twitter\" rel=\"nofollow\"\u003EThe New York Times\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/nfOWGACKUP",
        "expanded_url" : "http:\/\/nyti.ms\/1ATZLvc",
        "display_url" : "nyti.ms\/1ATZLvc"
      } ]
    },
    "geo" : { },
    "id_str" : "531829471050215424",
    "text" : "Breaking News: Obama Urges F.C.C. to Adopt Rules to Protect Net Neutrality\nhttp:\/\/t.co\/nfOWGACKUP",
    "id" : 531829471050215424,
    "created_at" : "2014-11-10 15:23:21 +0000",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758384037589348352\/KB3RFwFm_normal.jpg",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 531830113063927810,
  "created_at" : "2014-11-10 15:25:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elise Hu (\uC77C\uB9AC\uC2A4 \uD6C4)",
      "screen_name" : "elisewho",
      "indices" : [ 3, 12 ],
      "id_str" : "16001350",
      "id" : 16001350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531827666790281216",
  "text" : "RT @elisewho: It's pretty huge that POTUS has come out in support of reclassifying the Internet as a utility. Statement: http:\/\/t.co\/iBN7Pg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/iBN7PgzJ3C",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/net-neutrality",
        "display_url" : "whitehouse.gov\/net-neutrality"
      } ]
    },
    "geo" : { },
    "id_str" : "531817768296144896",
    "text" : "It's pretty huge that POTUS has come out in support of reclassifying the Internet as a utility. Statement: http:\/\/t.co\/iBN7PgzJ3C",
    "id" : 531817768296144896,
    "created_at" : "2014-11-10 14:36:51 +0000",
    "user" : {
      "name" : "Elise Hu (\uC77C\uB9AC\uC2A4 \uD6C4)",
      "screen_name" : "elisewho",
      "protected" : false,
      "id_str" : "16001350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1852699837\/hu_normal.jpg",
      "id" : 16001350,
      "verified" : true
    }
  },
  "id" : 531827666790281216,
  "created_at" : "2014-11-10 15:16:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarkeyMemo",
      "screen_name" : "MARKEYMEMO",
      "indices" : [ 3, 14 ],
      "id_str" : "3047090620",
      "id" : 3047090620
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 39, 50 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/th4vzXexc5",
      "expanded_url" : "http:\/\/1.usa.gov\/1qDMCNI",
      "display_url" : "1.usa.gov\/1qDMCNI"
    } ]
  },
  "geo" : { },
  "id_str" : "531826910951534592",
  "text" : "RT @MarkeyMemo: Thank you Mr.President @WhiteHouse for standing w fellow netizens in support of #NetNeutrality http:\/\/t.co\/th4vzXexc5 http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 23, 34 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MarkeyMemo\/status\/531825895749996544\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/RXS7pTxTh1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2Fs1XZCMAA8Bu8.jpg",
        "id_str" : "531825895074312192",
        "id" : 531825895074312192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2Fs1XZCMAA8Bu8.jpg",
        "sizes" : [ {
          "h" : 403,
          "resize" : "fit",
          "w" : 843
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 843
        } ],
        "display_url" : "pic.twitter.com\/RXS7pTxTh1"
      } ],
      "hashtags" : [ {
        "text" : "NetNeutrality",
        "indices" : [ 80, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/th4vzXexc5",
        "expanded_url" : "http:\/\/1.usa.gov\/1qDMCNI",
        "display_url" : "1.usa.gov\/1qDMCNI"
      } ]
    },
    "geo" : { },
    "id_str" : "531825895749996544",
    "text" : "Thank you Mr.President @WhiteHouse for standing w fellow netizens in support of #NetNeutrality http:\/\/t.co\/th4vzXexc5 http:\/\/t.co\/RXS7pTxTh1",
    "id" : 531825895749996544,
    "created_at" : "2014-11-10 15:09:09 +0000",
    "user" : {
      "name" : "Ed Markey",
      "screen_name" : "SenMarkey",
      "protected" : false,
      "id_str" : "21406834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739889609262411780\/qDeJ7rdE_normal.jpg",
      "id" : 21406834,
      "verified" : true
    }
  },
  "id" : 531826910951534592,
  "created_at" : "2014-11-10 15:13:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rap game Bodhi Rook",
      "screen_name" : "anildash",
      "indices" : [ 3, 12 ],
      "id_str" : "36823",
      "id" : 36823
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 37, 41 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/kN68f2iivG",
      "expanded_url" : "http:\/\/www.vox.com\/2014\/11\/10\/7185979\/obama-reclassification",
      "display_url" : "vox.com\/2014\/11\/10\/718\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531824086780243968",
  "text" : "RT @anildash: Huge: @whitehouse asks @FCC to reclassify the internet to support neutrality: http:\/\/t.co\/kN68f2iivG Thanks to 4M people who \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 6, 17 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "The FCC",
        "screen_name" : "FCC",
        "indices" : [ 23, 27 ],
        "id_str" : "66369206",
        "id" : 66369206
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/kN68f2iivG",
        "expanded_url" : "http:\/\/www.vox.com\/2014\/11\/10\/7185979\/obama-reclassification",
        "display_url" : "vox.com\/2014\/11\/10\/718\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "531823803631153152",
    "text" : "Huge: @whitehouse asks @FCC to reclassify the internet to support neutrality: http:\/\/t.co\/kN68f2iivG Thanks to 4M people who wrote the FCC.",
    "id" : 531823803631153152,
    "created_at" : "2014-11-10 15:00:50 +0000",
    "user" : {
      "name" : "rap game Bodhi Rook",
      "screen_name" : "anildash",
      "protected" : false,
      "id_str" : "36823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786179830266167296\/AmZpJJLv_normal.jpg",
      "id" : 36823,
      "verified" : true
    }
  },
  "id" : 531824086780243968,
  "created_at" : "2014-11-10 15:01:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 3, 11 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Gizmodo\/status\/531820496049176576\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/7A4mNZhSN7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2Fn7FfIYAAbRbt.jpg",
      "id_str" : "531820495789121536",
      "id" : 531820495789121536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2Fn7FfIYAAbRbt.jpg",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 352,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 636
      } ],
      "display_url" : "pic.twitter.com\/7A4mNZhSN7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/3xKNjFmCPS",
      "expanded_url" : "http:\/\/gizmo.do\/JoGz6v0",
      "display_url" : "gizmo.do\/JoGz6v0"
    } ]
  },
  "geo" : { },
  "id_str" : "531822958151733248",
  "text" : "RT @Gizmodo: Obama's plan to save the internet: http:\/\/t.co\/3xKNjFmCPS http:\/\/t.co\/7A4mNZhSN7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Gizmodo\/status\/531820496049176576\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/7A4mNZhSN7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2Fn7FfIYAAbRbt.jpg",
        "id_str" : "531820495789121536",
        "id" : 531820495789121536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2Fn7FfIYAAbRbt.jpg",
        "sizes" : [ {
          "h" : 199,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 352,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 636
        } ],
        "display_url" : "pic.twitter.com\/7A4mNZhSN7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/3xKNjFmCPS",
        "expanded_url" : "http:\/\/gizmo.do\/JoGz6v0",
        "display_url" : "gizmo.do\/JoGz6v0"
      } ]
    },
    "geo" : { },
    "id_str" : "531820496049176576",
    "text" : "Obama's plan to save the internet: http:\/\/t.co\/3xKNjFmCPS http:\/\/t.co\/7A4mNZhSN7",
    "id" : 531820496049176576,
    "created_at" : "2014-11-10 14:47:41 +0000",
    "user" : {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "protected" : false,
      "id_str" : "2890961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590508740010348544\/eS1F7mN5_normal.png",
      "id" : 2890961,
      "verified" : true
    }
  },
  "id" : 531822958151733248,
  "created_at" : "2014-11-10 14:57:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mashable News",
      "screen_name" : "MashableNews",
      "indices" : [ 3, 16 ],
      "id_str" : "372502604",
      "id" : 372502604
    }, {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 58, 62 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MashableNews\/status\/531817697315921921\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/5XL1C7IVi3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2FlLJACUAA3cAO.png",
      "id_str" : "531817473075466240",
      "id" : 531817473075466240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2FlLJACUAA3cAO.png",
      "sizes" : [ {
        "h" : 169,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 299,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 937
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 937
      } ],
      "display_url" : "pic.twitter.com\/5XL1C7IVi3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/HWmPN7HQiH",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/net-neutrality",
      "display_url" : "whitehouse.gov\/net-neutrality"
    } ]
  },
  "geo" : { },
  "id_str" : "531820438432022528",
  "text" : "RT @MashableNews: President Obama issues statement to the @FCC on net neutrality http:\/\/t.co\/HWmPN7HQiH http:\/\/t.co\/5XL1C7IVi3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The FCC",
        "screen_name" : "FCC",
        "indices" : [ 40, 44 ],
        "id_str" : "66369206",
        "id" : 66369206
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MashableNews\/status\/531817697315921921\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/5XL1C7IVi3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2FlLJACUAA3cAO.png",
        "id_str" : "531817473075466240",
        "id" : 531817473075466240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2FlLJACUAA3cAO.png",
        "sizes" : [ {
          "h" : 169,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 299,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 937
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 937
        } ],
        "display_url" : "pic.twitter.com\/5XL1C7IVi3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/HWmPN7HQiH",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/net-neutrality",
        "display_url" : "whitehouse.gov\/net-neutrality"
      } ]
    },
    "geo" : { },
    "id_str" : "531817697315921921",
    "text" : "President Obama issues statement to the @FCC on net neutrality http:\/\/t.co\/HWmPN7HQiH http:\/\/t.co\/5XL1C7IVi3",
    "id" : 531817697315921921,
    "created_at" : "2014-11-10 14:36:34 +0000",
    "user" : {
      "name" : "Mashable News",
      "screen_name" : "MashableNews",
      "protected" : false,
      "id_str" : "372502604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661556345116717057\/OgA52eye_normal.jpg",
      "id" : 372502604,
      "verified" : true
    }
  },
  "id" : 531820438432022528,
  "created_at" : "2014-11-10 14:47:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/531819820028018688\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ifCoS1ty8j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2FnQmJCcAE_e8X.jpg",
      "id_str" : "531819765820452865",
      "id" : 531819765820452865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2FnQmJCcAE_e8X.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ifCoS1ty8j"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/3y3YLQD6MB",
      "expanded_url" : "http:\/\/go.wh.gov\/net-neutrality",
      "display_url" : "go.wh.gov\/net-neutrality"
    } ]
  },
  "geo" : { },
  "id_str" : "531819820028018688",
  "text" : "It's time to keep the internet open and free. Read President Obama's plan \u2192 http:\/\/t.co\/3y3YLQD6MB #NetNeutrality http:\/\/t.co\/ifCoS1ty8j",
  "id" : 531819820028018688,
  "created_at" : "2014-11-10 14:45:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Wu",
      "screen_name" : "superwuster",
      "indices" : [ 3, 15 ],
      "id_str" : "14636374",
      "id" : 14636374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531819380414623745",
  "text" : "RT @superwuster: BIG NEWS (for Net Neutrality) -- President Obama demands bright-line rules, endorses Title II reclassification http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/eKIVB9RVoJ",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/net-neutrality",
        "display_url" : "whitehouse.gov\/net-neutrality"
      } ]
    },
    "geo" : { },
    "id_str" : "531817607515873282",
    "text" : "BIG NEWS (for Net Neutrality) -- President Obama demands bright-line rules, endorses Title II reclassification http:\/\/t.co\/eKIVB9RVoJ",
    "id" : 531817607515873282,
    "created_at" : "2014-11-10 14:36:12 +0000",
    "user" : {
      "name" : "Tim Wu",
      "screen_name" : "superwuster",
      "protected" : false,
      "id_str" : "14636374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509963432854953984\/NNbGKNcb_normal.jpeg",
      "id" : 14636374,
      "verified" : false
    }
  },
  "id" : 531819380414623745,
  "created_at" : "2014-11-10 14:43:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 15, 19 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 82, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/3y3YLQD6MB",
      "expanded_url" : "http:\/\/go.wh.gov\/net-neutrality",
      "display_url" : "go.wh.gov\/net-neutrality"
    } ]
  },
  "geo" : { },
  "id_str" : "531813644695531520",
  "text" : "I'm urging the @FCC to keep the internet open and free. Here's my plan to protect #NetNeutrality for everyone: http:\/\/t.co\/3y3YLQD6MB \u2013bo",
  "id" : 531813644695531520,
  "created_at" : "2014-11-10 14:20:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 75, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/G08vtftI0o",
      "expanded_url" : "http:\/\/go.wh.gov\/a8npmJ",
      "display_url" : "go.wh.gov\/a8npmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "531582110365003777",
  "text" : "\"If you see a veteran, go on up and shake their hand.\" \u2014President Obama on #VeteransDay: http:\/\/t.co\/G08vtftI0o",
  "id" : 531582110365003777,
  "created_at" : "2014-11-09 23:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/G08vtftI0o",
      "expanded_url" : "http:\/\/go.wh.gov\/a8npmJ",
      "display_url" : "go.wh.gov\/a8npmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "531529194388209664",
  "text" : "\"Anyone who has defended America deserves to live in dignity in America.\" \u2014Obama on ending veteran homelessness: http:\/\/t.co\/G08vtftI0o",
  "id" : 531529194388209664,
  "created_at" : "2014-11-09 19:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/G08vtftI0o",
      "expanded_url" : "http:\/\/go.wh.gov\/a8npmJ",
      "display_url" : "go.wh.gov\/a8npmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "531483934853300225",
  "text" : "\"When our veterans have the opportunity to succeed, our whole nation is stronger.\" \u2014President Obama: http:\/\/t.co\/G08vtftI0o #VeteransDay",
  "id" : 531483934853300225,
  "created_at" : "2014-11-09 16:30:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/IfMPNUo3dZ",
      "expanded_url" : "http:\/\/go.wh.gov\/a8npmJ",
      "display_url" : "go.wh.gov\/a8npmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "531458376988114944",
  "text" : "\"Let\u2019s honor our veterans by making sure they get their shot at the American Dream.\" \u2014President Obama: http:\/\/t.co\/IfMPNUo3dZ #VeteransDay",
  "id" : 531458376988114944,
  "created_at" : "2014-11-09 14:48:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WoundedWarriors",
      "indices" : [ 89, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/G08vtftI0o",
      "expanded_url" : "http:\/\/go.wh.gov\/a8npmJ",
      "display_url" : "go.wh.gov\/a8npmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "531215150200537088",
  "text" : "\"No matter how hard it is, they never give up\u2026and we can\u2019t ever quit on them.\" \u2014Obama on #WoundedWarriors: http:\/\/t.co\/G08vtftI0o",
  "id" : 531215150200537088,
  "created_at" : "2014-11-08 22:42:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531204074608553984",
  "text" : "RT @VP: Welcome home Kenneth Bae &amp; Matthew Miller. We're grateful for the tireless efforts of everyone who helped them return to their fami\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531163959051976704",
    "text" : "Welcome home Kenneth Bae &amp; Matthew Miller. We're grateful for the tireless efforts of everyone who helped them return to their families. -VP",
    "id" : 531163959051976704,
    "created_at" : "2014-11-08 19:18:51 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 531204074608553984,
  "created_at" : "2014-11-08 21:58:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/G08vtftI0o",
      "expanded_url" : "http:\/\/go.wh.gov\/a8npmJ",
      "display_url" : "go.wh.gov\/a8npmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "531184693975072768",
  "text" : "\"The end of a war is just the beginning of our obligations to those who serve in our name.\" \u2014Obama: http:\/\/t.co\/G08vtftI0o #VeteransDay",
  "id" : 531184693975072768,
  "created_at" : "2014-11-08 20:41:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/G08vtftI0o",
      "expanded_url" : "http:\/\/go.wh.gov\/a8npmJ",
      "display_url" : "go.wh.gov\/a8npmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "531154225279954944",
  "text" : "\"Next month, our combat mission will be over, and America\u2019s longest war will come to a responsible end.\" \u2014Obama: http:\/\/t.co\/G08vtftI0o",
  "id" : 531154225279954944,
  "created_at" : "2014-11-08 18:40:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 16, 26 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DPRK",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GOQ9AO6FsL",
      "expanded_url" : "http:\/\/go.usa.gov\/A8z9",
      "display_url" : "go.usa.gov\/A8z9"
    } ]
  },
  "geo" : { },
  "id_str" : "531143713624715264",
  "text" : "RT @StateDept: .@StateDept welcomes the release of U.S. citizens Kenneth Bae and Matthew Todd Miller from the #DPRK. http:\/\/t.co\/GOQ9AO6FsL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 1, 11 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DPRK",
        "indices" : [ 95, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/GOQ9AO6FsL",
        "expanded_url" : "http:\/\/go.usa.gov\/A8z9",
        "display_url" : "go.usa.gov\/A8z9"
      } ]
    },
    "geo" : { },
    "id_str" : "531116330351857664",
    "text" : ".@StateDept welcomes the release of U.S. citizens Kenneth Bae and Matthew Todd Miller from the #DPRK. http:\/\/t.co\/GOQ9AO6FsL",
    "id" : 531116330351857664,
    "created_at" : "2014-11-08 16:09:35 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 531143713624715264,
  "created_at" : "2014-11-08 17:58:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/531111907353448448\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/EjkctXMjAC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B17jcrDIMAMTOXC.jpg",
      "id_str" : "531111887807983619",
      "id" : 531111887807983619,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B17jcrDIMAMTOXC.jpg",
      "sizes" : [ {
        "h" : 380,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 648,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EjkctXMjAC"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531140454340108288",
  "text" : "RT @Interior: RT to spread the word \u2192 We're waiving entrance fees for all public lands on #VeteransDay http:\/\/t.co\/EjkctXMjAC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/531111907353448448\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/EjkctXMjAC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B17jcrDIMAMTOXC.jpg",
        "id_str" : "531111887807983619",
        "id" : 531111887807983619,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B17jcrDIMAMTOXC.jpg",
        "sizes" : [ {
          "h" : 380,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 215,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 648,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/EjkctXMjAC"
      } ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 76, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531111907353448448",
    "text" : "RT to spread the word \u2192 We're waiving entrance fees for all public lands on #VeteransDay http:\/\/t.co\/EjkctXMjAC",
    "id" : 531111907353448448,
    "created_at" : "2014-11-08 15:52:00 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 531140454340108288,
  "created_at" : "2014-11-08 17:45:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531128221610545152",
  "text" : "RT @vj44: Loretta Lynch - not about splash, but substance. If confirmed, she'll be a tireless force for fair and equal justice. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/531127752406355969\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/jYE51sIyKj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B17x33rIMAAMSaP.jpg",
        "id_str" : "531127748216238080",
        "id" : 531127748216238080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B17x33rIMAAMSaP.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jYE51sIyKj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531127752406355969",
    "text" : "Loretta Lynch - not about splash, but substance. If confirmed, she'll be a tireless force for fair and equal justice. http:\/\/t.co\/jYE51sIyKj",
    "id" : 531127752406355969,
    "created_at" : "2014-11-08 16:54:58 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 531128221610545152,
  "created_at" : "2014-11-08 16:56:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531122619815591936",
  "text" : "\"I can think of no better public servant to be our next Attorney General.\" \u2014President Obama on nominating Loretta Lynch for AG",
  "id" : 531122619815591936,
  "created_at" : "2014-11-08 16:34:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531122318169616384",
  "text" : "\"Loretta [Lynch] doesn\u2019t look to make headlines\u2014she looks to make a difference. She\u2019s not about splash\u2014she is about substance.\" \u2014Obama",
  "id" : 531122318169616384,
  "created_at" : "2014-11-08 16:33:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531122171327037440",
  "text" : "RT @WHLive: \"She\u2019s helped secure billions in settlements from some of the world\u2019s biggest banks accused of fraud\" \u2014President Obama on Loret\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531122146463219712",
    "text" : "\"She\u2019s helped secure billions in settlements from some of the world\u2019s biggest banks accused of fraud\" \u2014President Obama on Loretta Lynch",
    "id" : 531122146463219712,
    "created_at" : "2014-11-08 16:32:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 531122171327037440,
  "created_at" : "2014-11-08 16:32:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531121989956952065",
  "text" : "RT @WHLive: \"She successfully prosecuted the terrorists who plotted to bomb the Federal Reserve Bank &amp; the New York City subway\" \u2014Obama on \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "531121953521008640",
    "text" : "\"She successfully prosecuted the terrorists who plotted to bomb the Federal Reserve Bank &amp; the New York City subway\" \u2014Obama on Loretta Lynch",
    "id" : 531121953521008640,
    "created_at" : "2014-11-08 16:31:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 531121989956952065,
  "created_at" : "2014-11-08 16:32:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531121672108400640",
  "text" : "RT @WHLive: \"Today, I can announce...my nominee for our next Attorney General\u2014U.S. Attorney Loretta Lynch.\" \u2014President Obama: http:\/\/t.co\/H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/HxcDVMiQQm",
        "expanded_url" : "http:\/\/go.wh.gov\/AvuABB",
        "display_url" : "go.wh.gov\/AvuABB"
      } ]
    },
    "geo" : { },
    "id_str" : "531121628575694848",
    "text" : "\"Today, I can announce...my nominee for our next Attorney General\u2014U.S. Attorney Loretta Lynch.\" \u2014President Obama: http:\/\/t.co\/HxcDVMiQQm",
    "id" : 531121628575694848,
    "created_at" : "2014-11-08 16:30:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 531121672108400640,
  "created_at" : "2014-11-08 16:30:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531121409213603841",
  "text" : "\"Thanks to Eric, our nation is safer and freer, and more Americans...receive fair and equal treatment under the law.\" \u2014Obama on AG Holder",
  "id" : 531121409213603841,
  "created_at" : "2014-11-08 16:29:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531121013980155904",
  "text" : "\"In a country built on the rule of law, there are few offices more important than that of Attorney General.\" \u2014President Obama",
  "id" : 531121013980155904,
  "created_at" : "2014-11-08 16:28:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/O5kP9rrSsi",
      "expanded_url" : "http:\/\/go.wh.gov\/AvuABB",
      "display_url" : "go.wh.gov\/AvuABB"
    } ]
  },
  "geo" : { },
  "id_str" : "531120891480915968",
  "text" : "Happening now: President Obama announces his intent to nominate U.S. Attorney Loretta Lynch for Attorney General \u2192 http:\/\/t.co\/O5kP9rrSsi",
  "id" : 531120891480915968,
  "created_at" : "2014-11-08 16:27:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/O5kP9rrSsi",
      "expanded_url" : "http:\/\/go.wh.gov\/AvuABB",
      "display_url" : "go.wh.gov\/AvuABB"
    } ]
  },
  "geo" : { },
  "id_str" : "531110173796880384",
  "text" : "Watch President Obama announce his intent to nominate U.S. Attorney Loretta Lynch for Attorney General at 11:10am ET: http:\/\/t.co\/O5kP9rrSsi",
  "id" : 531110173796880384,
  "created_at" : "2014-11-08 15:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/IfMPNUo3dZ",
      "expanded_url" : "http:\/\/go.wh.gov\/a8npmJ",
      "display_url" : "go.wh.gov\/a8npmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "531106685910540288",
  "text" : "President Obama's weekly address: This #VeteransDay, let's honor our veterans \u2192 http:\/\/t.co\/IfMPNUo3dZ",
  "id" : 531106685910540288,
  "created_at" : "2014-11-08 15:31:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 72, 81 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/43ytGt68gD",
      "expanded_url" : "http:\/\/go.wh.gov\/yBNQjd",
      "display_url" : "go.wh.gov\/yBNQjd"
    } ]
  },
  "geo" : { },
  "id_str" : "530877252615954433",
  "text" : "\"No one who works full-time should have to raise a family in poverty.\" \u2014@LaborSec on why it's time to #RaiseTheWage: http:\/\/t.co\/43ytGt68gD",
  "id" : 530877252615954433,
  "created_at" : "2014-11-08 00:19:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/530860629909700608\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/eTnUvcR2BP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B13-1hhCAAAHobA.png",
      "id_str" : "530860526583021568",
      "id" : 530860526583021568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B13-1hhCAAAHobA.png",
      "sizes" : [ {
        "h" : 205,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 68,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 1148
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/eTnUvcR2BP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530860629909700608",
  "text" : "Tomorrow, President Obama will announce his intent to nominate U.S. Attorney Loretta Lynch for Attorney General. http:\/\/t.co\/eTnUvcR2BP",
  "id" : 530860629909700608,
  "created_at" : "2014-11-07 23:13:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/530835151711113216\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/hxyrgTN9Vd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B13ns7cCIAE82o3.jpg",
      "id_str" : "530835090155118593",
      "id" : 530835090155118593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B13ns7cCIAE82o3.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 1006
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 1006
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 132,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hxyrgTN9Vd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530835151711113216",
  "text" : "\"Walls of concrete and barbed wire are ultimately no match for the will of ordinary men and women.\" \u2014President Obama http:\/\/t.co\/hxyrgTN9Vd",
  "id" : 530835151711113216,
  "created_at" : "2014-11-07 21:32:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/530819848993918976\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/EqMOmTSwfP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B13Zv8mCYAAPH_Q.jpg",
      "id_str" : "530819748842332160",
      "id" : 530819748842332160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B13Zv8mCYAAPH_Q.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/EqMOmTSwfP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530819848993918976",
  "text" : "President Obama shows the Jackie Robinson West All Stars a program from the MLK Jr. March on Washington. http:\/\/t.co\/EqMOmTSwfP",
  "id" : 530819848993918976,
  "created_at" : "2014-11-07 20:31:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/530796346270167045\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/APxY5U38ab",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B12c1pMCIAAp_hs.jpg",
      "id_str" : "530752776502910976",
      "id" : 530752776502910976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B12c1pMCIAAp_hs.jpg",
      "sizes" : [ {
        "h" : 657,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 319,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 657,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/APxY5U38ab"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/pQjj9XyMDM",
      "expanded_url" : "http:\/\/1.usa.gov\/1z6dbjj",
      "display_url" : "1.usa.gov\/1z6dbjj"
    } ]
  },
  "geo" : { },
  "id_str" : "530797100548624384",
  "text" : "RT @USDOL: FACT: The unemployment rate dropped to 5.8% \u2014 the lowest since 2008. \n\nhttp:\/\/t.co\/pQjj9XyMDM http:\/\/t.co\/APxY5U38ab",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/530796346270167045\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/APxY5U38ab",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B12c1pMCIAAp_hs.jpg",
        "id_str" : "530752776502910976",
        "id" : 530752776502910976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B12c1pMCIAAp_hs.jpg",
        "sizes" : [ {
          "h" : 657,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 319,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 657,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/APxY5U38ab"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/pQjj9XyMDM",
        "expanded_url" : "http:\/\/1.usa.gov\/1z6dbjj",
        "display_url" : "1.usa.gov\/1z6dbjj"
      } ]
    },
    "geo" : { },
    "id_str" : "530796346270167045",
    "text" : "FACT: The unemployment rate dropped to 5.8% \u2014 the lowest since 2008. \n\nhttp:\/\/t.co\/pQjj9XyMDM http:\/\/t.co\/APxY5U38ab",
    "id" : 530796346270167045,
    "created_at" : "2014-11-07 18:58:05 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 530797100548624384,
  "created_at" : "2014-11-07 19:01:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/530783418607353856\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/SuWyWm5PuB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B124lT_CEAIyZHn.jpg",
      "id_str" : "530783282258907138",
      "id" : 530783282258907138,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B124lT_CEAIyZHn.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SuWyWm5PuB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/G72bKriGWD",
      "expanded_url" : "http:\/\/go.wh.gov\/xhz1WL",
      "display_url" : "go.wh.gov\/xhz1WL"
    } ]
  },
  "geo" : { },
  "id_str" : "530783418607353856",
  "text" : "FACT: Our manufacturers have added more than 728,000 jobs since February 2010 \u2192 http:\/\/t.co\/G72bKriGWD http:\/\/t.co\/SuWyWm5PuB",
  "id" : 530783418607353856,
  "created_at" : "2014-11-07 18:06:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/530772363735203840\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/d8MqIqbTAR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B12ui4jCIAAl_CE.jpg",
      "id_str" : "530772245417697280",
      "id" : 530772245417697280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B12ui4jCIAAl_CE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/d8MqIqbTAR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530772363735203840",
  "text" : "Over the past year, the unemployment rate has dropped by as large of an amount as any 12-month period in 30 years. http:\/\/t.co\/d8MqIqbTAR",
  "id" : 530772363735203840,
  "created_at" : "2014-11-07 17:22:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/G72bKriGWD",
      "expanded_url" : "http:\/\/go.wh.gov\/xhz1WL",
      "display_url" : "go.wh.gov\/xhz1WL"
    } ]
  },
  "geo" : { },
  "id_str" : "530761451472834561",
  "text" : "Our businesses have added at least 200,000 jobs in 9 straight months, the 1st time that's happened since the 1990s \u2192 http:\/\/t.co\/G72bKriGWD",
  "id" : 530761451472834561,
  "created_at" : "2014-11-07 16:39:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/530751638596632577\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/qpGEGy4HGL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B12a38pCEAAojLf.jpg",
      "id_str" : "530750617061298176",
      "id" : 530750617061298176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B12a38pCEAAojLf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qpGEGy4HGL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/G72bKriGWD",
      "expanded_url" : "http:\/\/go.wh.gov\/xhz1WL",
      "display_url" : "go.wh.gov\/xhz1WL"
    } ]
  },
  "geo" : { },
  "id_str" : "530751638596632577",
  "text" : "FACT: Our businesses are on pace for the strongest year of job growth since the late 1990s. http:\/\/t.co\/G72bKriGWD http:\/\/t.co\/qpGEGy4HGL",
  "id" : 530751638596632577,
  "created_at" : "2014-11-07 16:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/530741966779068417\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/IDZNLuE15v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B12TAZCCMAA8Wv7.jpg",
      "id_str" : "530741966028288000",
      "id" : 530741966028288000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B12TAZCCMAA8Wv7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IDZNLuE15v"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/G72bKriGWD",
      "expanded_url" : "http:\/\/go.wh.gov\/xhz1WL",
      "display_url" : "go.wh.gov\/xhz1WL"
    } ]
  },
  "geo" : { },
  "id_str" : "530741966779068417",
  "text" : "FACT: The unemployment rate fell to 5.8% last month\u2014the lowest since July 2008 \u2192 http:\/\/t.co\/G72bKriGWD http:\/\/t.co\/IDZNLuE15v",
  "id" : 530741966779068417,
  "created_at" : "2014-11-07 15:22:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/530738647650533376\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/4hXxKM8Jzl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B12P_MsCUAAR-Dl.jpg",
      "id_str" : "530738647000043520",
      "id" : 530738647000043520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B12P_MsCUAAR-Dl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4hXxKM8Jzl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530738647650533376",
  "text" : "Our businesses have added 10.6 million jobs over 56 straight months of growth\u2014extending the longest streak on record. http:\/\/t.co\/4hXxKM8Jzl",
  "id" : 530738647650533376,
  "created_at" : "2014-11-07 15:08:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/530528426105798657\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/mhSEKitHbK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1zQyrVIQAAAXcc.jpg",
      "id_str" : "530528425166258176",
      "id" : 530528425166258176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1zQyrVIQAAAXcc.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mhSEKitHbK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/qj3VUcYeLN",
      "expanded_url" : "http:\/\/go.wh.gov\/khrhzv",
      "display_url" : "go.wh.gov\/khrhzv"
    } ]
  },
  "geo" : { },
  "id_str" : "530528426105798657",
  "text" : "Here's the glove that the Jackie Robinson West All Stars gave President Obama today \u2192 http:\/\/t.co\/qj3VUcYeLN http:\/\/t.co\/mhSEKitHbK",
  "id" : 530528426105798657,
  "created_at" : "2014-11-07 01:13:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 54, 61 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 115, 126 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530519131129659392",
  "text" : "RT @JoiningForces: Happening now: The President &amp; @FLOTUS host music legends for a salute to the troops at the @WhiteHouse \u2192 http:\/\/t.co\/mX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 35, 42 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 96, 107 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PBSipwh",
        "indices" : [ 133, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/mXTh5aPf47",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "530519045112872961",
    "text" : "Happening now: The President &amp; @FLOTUS host music legends for a salute to the troops at the @WhiteHouse \u2192 http:\/\/t.co\/mXTh5aPf47 #PBSipwh",
    "id" : 530519045112872961,
    "created_at" : "2014-11-07 00:36:11 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 530519131129659392,
  "created_at" : "2014-11-07 00:36:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 34, 45 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "UChicago",
      "screen_name" : "UChicago",
      "indices" : [ 98, 107 ],
      "id_str" : "131144285",
      "id" : 131144285
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbt",
      "indices" : [ 57, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530498405483950081",
  "text" : "RT @usedgov: Happy 50th birthday, @arneduncan! A special #tbt -- young Arne reading with his dad, @UChicago prof Starkey Duncan! http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 21, 32 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      }, {
        "name" : "UChicago",
        "screen_name" : "UChicago",
        "indices" : [ 85, 94 ],
        "id_str" : "131144285",
        "id" : 131144285
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/530374111592062976\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/elg45kIStp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1xEcb-CYAEeSiV.jpg",
        "id_str" : "530374111457861633",
        "id" : 530374111457861633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1xEcb-CYAEeSiV.jpg",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 617,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 617,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 617,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/elg45kIStp"
      } ],
      "hashtags" : [ {
        "text" : "tbt",
        "indices" : [ 44, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530374111592062976",
    "text" : "Happy 50th birthday, @arneduncan! A special #tbt -- young Arne reading with his dad, @UChicago prof Starkey Duncan! http:\/\/t.co\/elg45kIStp",
    "id" : 530374111592062976,
    "created_at" : "2014-11-06 15:00:16 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 530498405483950081,
  "created_at" : "2014-11-06 23:14:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Shedd Aquarium",
      "screen_name" : "shedd_aquarium",
      "indices" : [ 35, 50 ],
      "id_str" : "27093057",
      "id" : 27093057
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/530487557067636736\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/F0v3QvmL0O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yrnypIEAAe0tt.jpg",
      "id_str" : "530487556220391424",
      "id" : 530487556220391424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yrnypIEAAe0tt.jpg",
      "sizes" : [ {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/F0v3QvmL0O"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/530487557067636736\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/F0v3QvmL0O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yrnwyIIAIpd_W.jpg",
      "id_str" : "530487555721273346",
      "id" : 530487555721273346,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yrnwyIIAIpd_W.jpg",
      "sizes" : [ {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/F0v3QvmL0O"
    } ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530489982876934145",
  "text" : "RT @Interior: These cute photos of @shedd_aquarium's rescued sea otter pup will make your day #nature http:\/\/t.co\/F0v3QvmL0O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shedd Aquarium",
        "screen_name" : "shedd_aquarium",
        "indices" : [ 21, 36 ],
        "id_str" : "27093057",
        "id" : 27093057
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/530487557067636736\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/F0v3QvmL0O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yrnypIEAAe0tt.jpg",
        "id_str" : "530487556220391424",
        "id" : 530487556220391424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yrnypIEAAe0tt.jpg",
        "sizes" : [ {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/F0v3QvmL0O"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/530487557067636736\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/F0v3QvmL0O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yrnwyIIAIpd_W.jpg",
        "id_str" : "530487555721273346",
        "id" : 530487555721273346,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yrnwyIIAIpd_W.jpg",
        "sizes" : [ {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/F0v3QvmL0O"
      } ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 80, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530487557067636736",
    "text" : "These cute photos of @shedd_aquarium's rescued sea otter pup will make your day #nature http:\/\/t.co\/F0v3QvmL0O",
    "id" : 530487557067636736,
    "created_at" : "2014-11-06 22:31:04 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 530489982876934145,
  "created_at" : "2014-11-06 22:40:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/530483993771515905\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/X19iyI4iF4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1yoYY0IMAIILDd.jpg",
      "id_str" : "530483993054294018",
      "id" : 530483993054294018,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1yoYY0IMAIILDd.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/X19iyI4iF4"
    } ],
    "hashtags" : [ {
      "text" : "LLWS",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530483993771515905",
  "text" : "President Obama welcomes the #LLWS U.S. champion Jackie Robinson West All Stars to the Oval Office. http:\/\/t.co\/X19iyI4iF4",
  "id" : 530483993771515905,
  "created_at" : "2014-11-06 22:16:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 40, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/od06C13gcd",
      "expanded_url" : "http:\/\/youtu.be\/Q_yVh16KE_Q",
      "display_url" : "youtu.be\/Q_yVh16KE_Q"
    } ]
  },
  "geo" : { },
  "id_str" : "530463909594275845",
  "text" : "\"The best way to protect Americans from #Ebola is to stop the outbreak at its source.\" \u2014President Obama: http:\/\/t.co\/od06C13gcd",
  "id" : 530463909594275845,
  "created_at" : "2014-11-06 20:57:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/od06C13gcd",
      "expanded_url" : "http:\/\/youtu.be\/Q_yVh16KE_Q",
      "display_url" : "youtu.be\/Q_yVh16KE_Q"
    } ]
  },
  "geo" : { },
  "id_str" : "530448340744699907",
  "text" : "Hear from some of the heroes working to stop #Ebola at its source in West Africa \u2192 http:\/\/t.co\/od06C13gcd",
  "id" : 530448340744699907,
  "created_at" : "2014-11-06 19:55:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 42, 51 ],
      "id_str" : "2425151",
      "id" : 2425151
    }, {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 53, 60 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 26, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/f011K6JUJO",
      "expanded_url" : "http:\/\/go.wh.gov\/XnTFny",
      "display_url" : "go.wh.gov\/XnTFny"
    } ]
  },
  "geo" : { },
  "id_str" : "530436011768446976",
  "text" : "Together we can help stop #Ebola. See how @Facebook, @Google, and others are taking action to stop this disease \u2192 http:\/\/t.co\/f011K6JUJO",
  "id" : 530436011768446976,
  "created_at" : "2014-11-06 19:06:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 82, 93 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationofMakers",
      "indices" : [ 24, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/p976ocEM9c",
      "expanded_url" : "http:\/\/www.instructables.com\/contest\/ornamentdesignchallenge",
      "display_url" : "instructables.com\/contest\/orname\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "530432056375779328",
  "text" : "RT @whitehouseostp: Hey #NationofMakers! 4 days left to submit your 3D design for @WhiteHouse ornament challenge! http:\/\/t.co\/p976ocEM9c ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 62, 73 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Phil44\/status\/530429885647699968\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/3xDl6PlKTI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1x3K1nIQAMH47K.jpg",
        "id_str" : "530429884196470787",
        "id" : 530429884196470787,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1x3K1nIQAMH47K.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        } ],
        "display_url" : "pic.twitter.com\/3xDl6PlKTI"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/Phil44\/status\/530429885647699968\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/3xDl6PlKTI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1x3K04IQAA21JP.jpg",
        "id_str" : "530429883999338496",
        "id" : 530429883999338496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1x3K04IQAA21JP.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        } ],
        "display_url" : "pic.twitter.com\/3xDl6PlKTI"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/Phil44\/status\/530429885647699968\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/3xDl6PlKTI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1x3K0FIYAInRmD.jpg",
        "id_str" : "530429883785437186",
        "id" : 530429883785437186,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1x3K0FIYAInRmD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        } ],
        "display_url" : "pic.twitter.com\/3xDl6PlKTI"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/Phil44\/status\/530429885647699968\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/3xDl6PlKTI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1x3K0vIIAEuEnK.jpg",
        "id_str" : "530429883961581569",
        "id" : 530429883961581569,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1x3K0vIIAEuEnK.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 306
        } ],
        "display_url" : "pic.twitter.com\/3xDl6PlKTI"
      } ],
      "hashtags" : [ {
        "text" : "NationofMakers",
        "indices" : [ 4, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/p976ocEM9c",
        "expanded_url" : "http:\/\/www.instructables.com\/contest\/ornamentdesignchallenge",
        "display_url" : "instructables.com\/contest\/orname\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "530431886309736449",
    "text" : "Hey #NationofMakers! 4 days left to submit your 3D design for @WhiteHouse ornament challenge! http:\/\/t.co\/p976ocEM9c http:\/\/t.co\/3xDl6PlKTI",
    "id" : 530431886309736449,
    "created_at" : "2014-11-06 18:49:51 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 530432056375779328,
  "created_at" : "2014-11-06 18:50:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530406543015964672",
  "text" : "\"It is incumbent on all of us, as Americans, to uphold the values they fight for.\" \u2014Obama on our men and women in uniform #MedalOfHonor",
  "id" : 530406543015964672,
  "created_at" : "2014-11-06 17:09:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530406354893025282",
  "text" : "\"Today, we honor...one of those men\u2014Lt. Alonzo Cushing\u2014who as Lincoln said, 'gave their last full measure of devotion'\" \u2014Obama #MedalOfHonor",
  "id" : 530406354893025282,
  "created_at" : "2014-11-06 17:08:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530406194016288768",
  "text" : "\"I might not be standing here...as President had it not been for the ultimate sacrifices of those courageous Americans\" \u2014Obama on Gettysburg",
  "id" : 530406194016288768,
  "created_at" : "2014-11-06 17:07:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530405334574067712",
  "text" : "\"No matter how long it takes, it is never too late to do the right thing.\" \u2014Obama on awarding the #MedalOfHonor to Alonzo H. Cushing",
  "id" : 530405334574067712,
  "created_at" : "2014-11-06 17:04:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 39, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/hNBmF2D1rH",
      "expanded_url" : "http:\/\/go.wh.gov\/E7h5NJ",
      "display_url" : "go.wh.gov\/E7h5NJ"
    } ]
  },
  "geo" : { },
  "id_str" : "530404614420451328",
  "text" : "Watch live: President Obama awards the #MedalOfHonor to Army First Lieutenant Alonzo H. Cushing \u2192 http:\/\/t.co\/hNBmF2D1rH",
  "id" : 530404614420451328,
  "created_at" : "2014-11-06 17:01:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 38, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/pXfPXPscUI",
      "expanded_url" : "http:\/\/youtu.be\/nt53GPz9dmE",
      "display_url" : "youtu.be\/nt53GPz9dmE"
    } ]
  },
  "geo" : { },
  "id_str" : "530396771109724161",
  "text" : "Before President Obama awards today's #MedalOfHonor, get a behind-the-scenes look at the ceremony \u2192 http:\/\/t.co\/pXfPXPscUI",
  "id" : 530396771109724161,
  "created_at" : "2014-11-06 16:30:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 32, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/hNBmF2D1rH",
      "expanded_url" : "http:\/\/go.wh.gov\/E7h5NJ",
      "display_url" : "go.wh.gov\/E7h5NJ"
    } ]
  },
  "geo" : { },
  "id_str" : "530388117677568001",
  "text" : "Watch President Obama award the #MedalOfHonor to Army First Lieutenant Alonzo H. Cushing at 11:45am ET \u2192 http:\/\/t.co\/hNBmF2D1rH",
  "id" : 530388117677568001,
  "created_at" : "2014-11-06 15:55:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/530146892148006915\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mrCUuBAEws",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1t1yeKCEAA2xwI.jpg",
      "id_str" : "530146891095216128",
      "id" : 530146891095216128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1t1yeKCEAA2xwI.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/mrCUuBAEws"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530146892148006915",
  "text" : "\"We've just got to keep at it until every American feels the gains of a growing economy...in their own lives.\" \u2014Obama http:\/\/t.co\/mrCUuBAEws",
  "id" : 530146892148006915,
  "created_at" : "2014-11-05 23:57:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530146666771259392",
  "text" : "RT @LaborSec: AK, AR, NE and SD approved measures yesterday to #RaiseTheWage. This action will benefit thousands of working families in the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 49, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530016547444891649",
    "text" : "AK, AR, NE and SD approved measures yesterday to #RaiseTheWage. This action will benefit thousands of working families in their communities.",
    "id" : 530016547444891649,
    "created_at" : "2014-11-05 15:19:26 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 530146666771259392,
  "created_at" : "2014-11-05 23:56:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/KTcq9FEe2J",
      "expanded_url" : "http:\/\/go.wh.gov\/fiGScC",
      "display_url" : "go.wh.gov\/fiGScC"
    } ]
  },
  "geo" : { },
  "id_str" : "530141388801708032",
  "text" : "Get the facts on today's funding request to Congress on enhancing the U.S. response to #Ebola at home and abroad \u2192 http:\/\/t.co\/KTcq9FEe2J",
  "id" : 530141388801708032,
  "created_at" : "2014-11-05 23:35:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/jv6UUqpOMj",
      "expanded_url" : "http:\/\/snpy.tv\/1yZT6uV",
      "display_url" : "snpy.tv\/1yZT6uV"
    } ]
  },
  "geo" : { },
  "id_str" : "530129999437639682",
  "text" : "\"Get stuff done. Don't worry about the next election.\" \u2014Obama on what Americans expect from Washington http:\/\/t.co\/jv6UUqpOMj",
  "id" : 530129999437639682,
  "created_at" : "2014-11-05 22:50:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/sV85QhOxTY",
      "expanded_url" : "http:\/\/snpy.tv\/10wu8HG",
      "display_url" : "snpy.tv\/10wu8HG"
    } ]
  },
  "geo" : { },
  "id_str" : "530113446537207808",
  "text" : "\"The United States of America has big things to do. We can and will make progress if we do it together.\" \u2014Obama http:\/\/t.co\/sV85QhOxTY",
  "id" : 530113446537207808,
  "created_at" : "2014-11-05 21:44:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/530104236667699200\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/yWWt8KHHfY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1tO_m5CMAAaXgR.jpg",
      "id_str" : "530104235824656384",
      "id" : 530104235824656384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1tO_m5CMAAaXgR.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yWWt8KHHfY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530104236667699200",
  "text" : "\u201CWhen you look at the facts, our economy is stronger than just about anybody\u2019s.\u201D \u2014President Obama http:\/\/t.co\/yWWt8KHHfY",
  "id" : 530104236667699200,
  "created_at" : "2014-11-05 21:07:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530098714728079361",
  "text" : "\u201CWe now know that the law works. You have millions of people who have health insurance that didn\u2019t have it before.\u201D \u2014Obama #ACAWorks",
  "id" : 530098714728079361,
  "created_at" : "2014-11-05 20:45:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530097748314296320",
  "text" : "\"My number one goal is...to deliver as much as I can for the American people in these last two years.\u201D \u2014President Obama",
  "id" : 530097748314296320,
  "created_at" : "2014-11-05 20:42:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530092917420204032",
  "text" : "\u201CWhat we can\u2019t do is just keep on waiting. There is a cost to waiting.\u201D \u2014President Obama on reforming our immigration system",
  "id" : 530092917420204032,
  "created_at" : "2014-11-05 20:22:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530091598395097088",
  "text" : "\"Get stuff done. Don't worry about the next election. Don't worry about party affiliation.\" \u2014Obama on what Americans expect from Washington",
  "id" : 530091598395097088,
  "created_at" : "2014-11-05 20:17:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530089760673783808",
  "text" : "\"I will measure ideas not by whether they come from Democrats or Republicans, but by whether they work for the American people.\" \u2014Obama",
  "id" : 530089760673783808,
  "created_at" : "2014-11-05 20:10:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530088863319207937",
  "text" : "\"The United States of America has big things to do. We can and will make progress if we do it together.\" \u2014President Obama",
  "id" : 530088863319207937,
  "created_at" : "2014-11-05 20:06:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530088704702828544",
  "text" : "\"We are simply more than just a collection of red and blue states.\" \u2014President Obama",
  "id" : 530088704702828544,
  "created_at" : "2014-11-05 20:06:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530088585203294209",
  "text" : "\"I meet Americans all across this country who are determined, and big-hearted, and ask what they can do, and never give up.\" \u2014Obama",
  "id" : 530088585203294209,
  "created_at" : "2014-11-05 20:05:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530087895991066625",
  "text" : "\"In the 5 states where a minimum wage increase was on the ballot last night, voters went 5-for-5 to increase it.\" \u2014Obama #RaiseTheWage",
  "id" : 530087895991066625,
  "created_at" : "2014-11-05 20:02:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530087691841712128",
  "text" : "RT @WHLive: \"Traditionally, both parties have been for creating jobs rebuilding our infrastructure.\" \u2014President Obama #RebuildAmerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RebuildAmerica",
        "indices" : [ 106, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530087664155131904",
    "text" : "\"Traditionally, both parties have been for creating jobs rebuilding our infrastructure.\" \u2014President Obama #RebuildAmerica",
    "id" : 530087664155131904,
    "created_at" : "2014-11-05 20:02:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 530087691841712128,
  "created_at" : "2014-11-05 20:02:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530087502590541824",
  "text" : "RT @WHLive: \"We\u2019ve just got to keep at it until every American feels the gains of a growing economy where it matters most: in their own liv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530087469182902274",
    "text" : "\"We\u2019ve just got to keep at it until every American feels the gains of a growing economy where it matters most: in their own lives.\"  \u2014Obama",
    "id" : 530087469182902274,
    "created_at" : "2014-11-05 20:01:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 530087502590541824,
  "created_at" : "2014-11-05 20:01:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530087314740219907",
  "text" : "\"Manufacturing has grown; our deficits have shrunk; our dependence on foreign oil is down; our graduation rates are up.\" \u2014President Obama",
  "id" : 530087314740219907,
  "created_at" : "2014-11-05 20:00:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530087172079382528",
  "text" : "RT @WHLive: \"This country has made real progress since the crisis 6 years ago. More Americans are working. More Americans have health insur\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "530087146267639808",
    "text" : "\"This country has made real progress since the crisis 6 years ago. More Americans are working. More Americans have health insurance.\" \u2014Obama",
    "id" : 530087146267639808,
    "created_at" : "2014-11-05 19:59:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 530087172079382528,
  "created_at" : "2014-11-05 20:00:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530087051484745728",
  "text" : "\"To everyone who voted, I want you to know...I hear you. To the two-thirds of voters who chose not to participate...I hear you, too.\" \u2014Obama",
  "id" : 530087051484745728,
  "created_at" : "2014-11-05 19:59:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530086836992245761",
  "text" : "\"[Americans] expect the people they elect to work as hard as they do. They expect us to focus on their ambitions, and not ours.\" \u2014Obama",
  "id" : 530086836992245761,
  "created_at" : "2014-11-05 19:58:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "530086691131121664",
  "text" : "\"On Friday, I look forward to hosting the entire Republican &amp; Democratic leadership at the White House to chart a new course forward\" \u2014Obama",
  "id" : 530086691131121664,
  "created_at" : "2014-11-05 19:58:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/5nNAKtvOXv",
      "expanded_url" : "http:\/\/go.wh.gov\/BYWhXn",
      "display_url" : "go.wh.gov\/BYWhXn"
    } ]
  },
  "geo" : { },
  "id_str" : "530086525657051136",
  "text" : "Happening now: President Obama holds a press conference at the White House. Watch \u2192 http:\/\/t.co\/5nNAKtvOXv",
  "id" : 530086525657051136,
  "created_at" : "2014-11-05 19:57:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/5nNAKtvOXv",
      "expanded_url" : "http:\/\/go.wh.gov\/BYWhXn",
      "display_url" : "go.wh.gov\/BYWhXn"
    } ]
  },
  "geo" : { },
  "id_str" : "530065152356282369",
  "text" : "At 2:50pm ET, President Obama holds a press conference at the White House. Watch \u2192 http:\/\/t.co\/5nNAKtvOXv",
  "id" : 530065152356282369,
  "created_at" : "2014-11-05 18:32:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/529770324519165953\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ldvzfIt2Yh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1ofTWLIEAAZkd9.jpg",
      "id_str" : "529770323399675904",
      "id" : 529770323399675904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1ofTWLIEAAZkd9.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ldvzfIt2Yh"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 23, 36 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/wARzurCJUt",
      "expanded_url" : "http:\/\/wh.gov\/raise-the-wage",
      "display_url" : "wh.gov\/raise-the-wage"
    } ]
  },
  "geo" : { },
  "id_str" : "529770324519165953",
  "text" : "Let's help millions of #WomenSucceed by raising the minimum wage to $10.10 \u2192 http:\/\/t.co\/wARzurCJUt #RaiseTheWage http:\/\/t.co\/ldvzfIt2Yh",
  "id" : 529770324519165953,
  "created_at" : "2014-11-04 23:01:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529741596179574784\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/VAhv9xLcWv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1oFLKPIIAERMcQ.jpg",
      "id_str" : "529741595453956097",
      "id" : 529741595453956097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1oFLKPIIAERMcQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VAhv9xLcWv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/l2KwMpTfLu",
      "expanded_url" : "http:\/\/go.wh.gov\/zGucWQ",
      "display_url" : "go.wh.gov\/zGucWQ"
    } ]
  },
  "geo" : { },
  "id_str" : "529741596179574784",
  "text" : "More than 10.3 million jobs over 55 months \u2713\nThe lowest unemployment rate in 6 years \u2713\nhttp:\/\/t.co\/l2KwMpTfLu http:\/\/t.co\/VAhv9xLcWv",
  "id" : 529741596179574784,
  "created_at" : "2014-11-04 21:06:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/529721129120710656\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/DomGWvF2Zo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1nyjzAIQAAe6Uz.jpg",
      "id_str" : "529721127992836096",
      "id" : 529721127992836096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1nyjzAIQAAe6Uz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DomGWvF2Zo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/wHVulsKQmc",
      "expanded_url" : "http:\/\/go.wh.gov\/zGucWQ",
      "display_url" : "go.wh.gov\/zGucWQ"
    } ]
  },
  "geo" : { },
  "id_str" : "529721129120710656",
  "text" : "RT to spread the word: The unemployment rate is the lowest it's been in 6 years \u2192 http:\/\/t.co\/wHVulsKQmc http:\/\/t.co\/DomGWvF2Zo",
  "id" : 529721129120710656,
  "created_at" : "2014-11-04 19:45:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529709504422625280\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/hh3ohUfXyx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1nn_IsIEAE42Ai.jpg",
      "id_str" : "529709503043080193",
      "id" : 529709503043080193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1nn_IsIEAE42Ai.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hh3ohUfXyx"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529709504422625280",
  "text" : "It's time for Republicans in Congress to help close the pay gap between men and women. #EqualPay http:\/\/t.co\/hh3ohUfXyx",
  "id" : 529709504422625280,
  "created_at" : "2014-11-04 18:59:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/529695192895741952\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/WGw7mFFohE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1na-IIIAAMK57G.jpg",
      "id_str" : "529695192061050883",
      "id" : 529695192061050883,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1na-IIIAAMK57G.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/WGw7mFFohE"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/YspXYBqoWE",
      "expanded_url" : "http:\/\/go.wh.gov\/ki3gqu",
      "display_url" : "go.wh.gov\/ki3gqu"
    } ]
  },
  "geo" : { },
  "id_str" : "529695192895741952",
  "text" : "Let's keep fighting to give every woman the chance to realize her dreams \u2192 http:\/\/t.co\/YspXYBqoWE #EqualPay http:\/\/t.co\/WGw7mFFohE",
  "id" : 529695192895741952,
  "created_at" : "2014-11-04 18:02:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529683700074565632\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/QrKDgEVyou",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1nQhIEIMAAzT4y.jpg",
      "id_str" : "529683698711801856",
      "id" : 529683698711801856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1nQhIEIMAAzT4y.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QrKDgEVyou"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/zU442SRAjK",
      "expanded_url" : "http:\/\/go.wh.gov\/ki3gqu",
      "display_url" : "go.wh.gov\/ki3gqu"
    } ]
  },
  "geo" : { },
  "id_str" : "529683700074565632",
  "text" : "RT if you agree: Women should earn the same pay as men for doing the same work \u2192 http:\/\/t.co\/zU442SRAjK #EqualPay http:\/\/t.co\/QrKDgEVyou",
  "id" : 529683700074565632,
  "created_at" : "2014-11-04 17:16:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529672024889634816\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/u3Z9wa96qy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1nDgpYIMAAJYPZ.jpg",
      "id_str" : "529669396823027712",
      "id" : 529669396823027712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1nDgpYIMAAJYPZ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/u3Z9wa96qy"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/wARzurCJUt",
      "expanded_url" : "http:\/\/wh.gov\/raise-the-wage",
      "display_url" : "wh.gov\/raise-the-wage"
    } ]
  },
  "geo" : { },
  "id_str" : "529672024889634816",
  "text" : "FACT: Republicans in Congress continue to block raising the minimum wage \u2192 http:\/\/t.co\/wARzurCJUt #RaiseTheWage http:\/\/t.co\/u3Z9wa96qy",
  "id" : 529672024889634816,
  "created_at" : "2014-11-04 16:30:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529664702079434752\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/R4YHe3e1m8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1m_PT3IYAEpkFM.jpg",
      "id_str" : "529664700943196161",
      "id" : 529664700943196161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1m_PT3IYAEpkFM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/R4YHe3e1m8"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529664702079434752",
  "text" : "Women make less than men in almost every field 4 years after graduation. It's time to change that. #EqualPay http:\/\/t.co\/R4YHe3e1m8",
  "id" : 529664702079434752,
  "created_at" : "2014-11-04 16:01:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529422876382736386\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/GEPFtioWWU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1jWxkaCQAAcEDk.jpg",
      "id_str" : "529409103290843136",
      "id" : 529409103290843136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1jWxkaCQAAcEDk.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GEPFtioWWU"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529422876382736386",
  "text" : "RT if you agree: Women should earn the same pay as men for doing the same work. Period. #EqualPay http:\/\/t.co\/GEPFtioWWU",
  "id" : 529422876382736386,
  "created_at" : "2014-11-04 00:00:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529407797914783745\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/vGVitVtj4j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1jVljMCYAEK5e9.jpg",
      "id_str" : "529407797293637633",
      "id" : 529407797293637633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1jVljMCYAEK5e9.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vGVitVtj4j"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/YspXYBqoWE",
      "expanded_url" : "http:\/\/go.wh.gov\/ki3gqu",
      "display_url" : "go.wh.gov\/ki3gqu"
    } ]
  },
  "geo" : { },
  "id_str" : "529407797914783745",
  "text" : "When #WomenSucceed, America succeeds. It's long-past time to ensure #EqualPay for women \u2192 http:\/\/t.co\/YspXYBqoWE http:\/\/t.co\/vGVitVtj4j",
  "id" : 529407797914783745,
  "created_at" : "2014-11-03 23:00:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 26, 37 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529391079179956224",
  "text" : "RT @FLOTUS: Check out the @WhiteHouse Tumblr now for the First Lady's answers to your Q's on helping students #ReachHigher \u2192 http:\/\/t.co\/YY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 98, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/YYT2OZOcMq",
        "expanded_url" : "http:\/\/whitehouse.tumblr.com",
        "display_url" : "whitehouse.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "529390323634405376",
    "text" : "Check out the @WhiteHouse Tumblr now for the First Lady's answers to your Q's on helping students #ReachHigher \u2192 http:\/\/t.co\/YYT2OZOcMq",
    "id" : 529390323634405376,
    "created_at" : "2014-11-03 21:51:03 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 529391079179956224,
  "created_at" : "2014-11-03 21:54:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zingerman's",
      "screen_name" : "zingermans",
      "indices" : [ 35, 46 ],
      "id_str" : "20008239",
      "id" : 20008239
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529386582613454848\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/qwNKZ81FXS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1jCSpcCAAEOEQ3.jpg",
      "id_str" : "529386581832892417",
      "id" : 529386581832892417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1jCSpcCAAEOEQ3.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/qwNKZ81FXS"
    } ],
    "hashtags" : [ {
      "text" : "NationalSandwichDay",
      "indices" : [ 91, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529386582613454848",
  "text" : "Businesses around the country like @Zingermans agree: It's time to raise the minimum wage. #NationalSandwichDay http:\/\/t.co\/qwNKZ81FXS",
  "id" : 529386582613454848,
  "created_at" : "2014-11-03 21:36:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 81, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529372324827774977",
  "text" : "RT @vj44: Last week, POTUS traveled to RI to meet with \uD83D\uDE4E\uD83D\uDC69\uD83D\uDC75 about how we can help #FamiliesSucceed. Here's what they said: https:\/\/t.co\/whjo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FamiliesSucceed",
        "indices" : [ 71, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/whjomJ2POA",
        "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/dcbc7652fdb8",
        "display_url" : "medium.com\/@WhiteHouse\/dc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "529371542808199169",
    "text" : "Last week, POTUS traveled to RI to meet with \uD83D\uDE4E\uD83D\uDC69\uD83D\uDC75 about how we can help #FamiliesSucceed. Here's what they said: https:\/\/t.co\/whjomJ2POA",
    "id" : 529371542808199169,
    "created_at" : "2014-11-03 20:36:25 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 529372324827774977,
  "created_at" : "2014-11-03 20:39:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529358043008335872\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/irgLMfZ80h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1ioVbZCEAAE1TS.jpg",
      "id_str" : "529358042299502592",
      "id" : 529358042299502592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1ioVbZCEAAE1TS.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/irgLMfZ80h"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/wARzurCJUt",
      "expanded_url" : "http:\/\/wh.gov\/raise-the-wage",
      "display_url" : "wh.gov\/raise-the-wage"
    } ]
  },
  "geo" : { },
  "id_str" : "529358043008335872",
  "text" : "Nobody who works full-time should have to raise a family in poverty: http:\/\/t.co\/wARzurCJUt #RaiseTheWage http:\/\/t.co\/irgLMfZ80h",
  "id" : 529358043008335872,
  "created_at" : "2014-11-03 19:42:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529347434032283648\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/OTPT3C26mc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1ier4ECIAA1GpB.jpg",
      "id_str" : "529347432836898816",
      "id" : 529347432836898816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1ier4ECIAA1GpB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OTPT3C26mc"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/zU442SRAjK",
      "expanded_url" : "http:\/\/go.wh.gov\/ki3gqu",
      "display_url" : "go.wh.gov\/ki3gqu"
    } ]
  },
  "geo" : { },
  "id_str" : "529347434032283648",
  "text" : "RT if you agree: It's time to ensure #EqualPay for women \u2192 http:\/\/t.co\/zU442SRAjK http:\/\/t.co\/OTPT3C26mc",
  "id" : 529347434032283648,
  "created_at" : "2014-11-03 19:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529333575187849216\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/twTvdsTerL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1iSFENCYAEC9bt.jpg",
      "id_str" : "529333571941457921",
      "id" : 529333571941457921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1iSFENCYAEC9bt.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/twTvdsTerL"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529333575187849216",
  "text" : "FACT: Raising the minimum wage to $10.10 would benefit nearly 28 million workers.\nIt's time to #RaiseTheWage. http:\/\/t.co\/twTvdsTerL",
  "id" : 529333575187849216,
  "created_at" : "2014-11-03 18:05:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529316120571179008\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/0nTobvHH5r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1iCNOhCYAAhAuC.jpg",
      "id_str" : "529316119962607616",
      "id" : 529316119962607616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1iCNOhCYAAhAuC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0nTobvHH5r"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529316120571179008",
  "text" : "FACT: The Paycheck Fairness Act would help women fight for #EqualPay.\nRepublicans in Congress continue to block it. http:\/\/t.co\/0nTobvHH5r",
  "id" : 529316120571179008,
  "created_at" : "2014-11-03 16:56:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529301989503418369\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/9olu43ECvP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1h1WrLCYAAhMcn.jpg",
      "id_str" : "529301988622622720",
      "id" : 529301988622622720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1h1WrLCYAAhMcn.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/9olu43ECvP"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529301989503418369",
  "text" : "Our daughters should be treated the same as our sons.\nIt's time to ensure #EqualPay for women. http:\/\/t.co\/9olu43ECvP",
  "id" : 529301989503418369,
  "created_at" : "2014-11-03 16:00:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep Donna F Edwards",
      "screen_name" : "repdonnaedwards",
      "indices" : [ 3, 19 ],
      "id_str" : "82649553",
      "id" : 82649553
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529293658646790145",
  "text" : "RT @repdonnaedwards: Americans know if we #RaiseTheWage, poverty would be reduced! Republicans, however, think otherwise: http:\/\/t.co\/vdX6b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/repdonnaedwards\/status\/529261423856467968\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/vdX6bPUMTg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B1hQdcyIYAAVh2v.png",
        "id_str" : "529261423088918528",
        "id" : 529261423088918528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1hQdcyIYAAVh2v.png",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 669
        }, {
          "h" : 195,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 669
        } ],
        "display_url" : "pic.twitter.com\/vdX6bPUMTg"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 21, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "529261423856467968",
    "text" : "Americans know if we #RaiseTheWage, poverty would be reduced! Republicans, however, think otherwise: http:\/\/t.co\/vdX6bPUMTg",
    "id" : 529261423856467968,
    "created_at" : "2014-11-03 13:18:51 +0000",
    "user" : {
      "name" : "Rep Donna F Edwards",
      "screen_name" : "repdonnaedwards",
      "protected" : false,
      "id_str" : "82649553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796033669290803200\/2biK3A-D_normal.jpg",
      "id" : 82649553,
      "verified" : true
    }
  },
  "id" : 529293658646790145,
  "created_at" : "2014-11-03 15:26:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/529288502416916480\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/fqnrfGdqBy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1hpFoKCYAMgsig.jpg",
      "id_str" : "529288501615812611",
      "id" : 529288501615812611,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1hpFoKCYAMgsig.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fqnrfGdqBy"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529288502416916480",
  "text" : "Women should earn the same pay as men for doing the same work.\nIt's time to ensure #EqualPay for women. http:\/\/t.co\/fqnrfGdqBy",
  "id" : 529288502416916480,
  "created_at" : "2014-11-03 15:06:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/528206821014515712\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/CnYjS9jEta",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1SRTfgCQAEXyHf.jpg",
      "id_str" : "528206820368596993",
      "id" : 528206820368596993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1SRTfgCQAEXyHf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CnYjS9jEta"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/flhvqkcvDz",
      "expanded_url" : "http:\/\/go.wh.gov\/ynV92u",
      "display_url" : "go.wh.gov\/ynV92u"
    } ]
  },
  "geo" : { },
  "id_str" : "529090613174484992",
  "text" : "\"For the first time in six years, the unemployment rate is below 6%.\" \u2014President Obama: http:\/\/t.co\/flhvqkcvDz http:\/\/t.co\/CnYjS9jEta",
  "id" : 529090613174484992,
  "created_at" : "2014-11-03 02:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/528977640107958272\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/FXqjJv53Wz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1dOXD8CYAIFvdL.png",
      "id_str" : "528977639340400642",
      "id" : 528977639340400642,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1dOXD8CYAIFvdL.png",
      "sizes" : [ {
        "h" : 535,
        "resize" : "fit",
        "w" : 844
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 844
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FXqjJv53Wz"
    } ],
    "hashtags" : [ {
      "text" : "EndImpunity",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528977640107958272",
  "text" : "\"All governments must protect the ability of journalists to write and speak freely.\" \u2014President Obama #EndImpunity http:\/\/t.co\/FXqjJv53Wz",
  "id" : 528977640107958272,
  "created_at" : "2014-11-02 18:31:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528276211102134272\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/DzpBNJ7awy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1TQadiCEAA2qRj.jpg",
      "id_str" : "528276209331736576",
      "id" : 528276209331736576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1TQadiCEAA2qRj.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DzpBNJ7awy"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/flhvqkcvDz",
      "expanded_url" : "http:\/\/go.wh.gov\/ynV92u",
      "display_url" : "go.wh.gov\/ynV92u"
    } ]
  },
  "geo" : { },
  "id_str" : "528947166622912512",
  "text" : "\"Let\u2019s do this\u2014let\u2019s give America a raise.\" \u2014President Obama: http:\/\/t.co\/flhvqkcvDz #RaiseTheWage http:\/\/t.co\/DzpBNJ7awy",
  "id" : 528947166622912512,
  "created_at" : "2014-11-02 16:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/flhvqkcvDz",
      "expanded_url" : "http:\/\/go.wh.gov\/ynV92u",
      "display_url" : "go.wh.gov\/ynV92u"
    } ]
  },
  "geo" : { },
  "id_str" : "528932089043771395",
  "text" : "\"About 28 million workers would benefit from an increase in the minimum wage to $10.10\/hour.\" \u2014Obama: http:\/\/t.co\/flhvqkcvDz #RaiseTheWage",
  "id" : 528932089043771395,
  "created_at" : "2014-11-02 15:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/528208703988584448\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/VPUFc7m1Rk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B1STA_vCMAI7aES.jpg",
      "id_str" : "528208701627183106",
      "id" : 528208701627183106,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B1STA_vCMAI7aES.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VPUFc7m1Rk"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 28, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/flhvqkcvDz",
      "expanded_url" : "http:\/\/go.wh.gov\/ynV92u",
      "display_url" : "go.wh.gov\/ynV92u"
    } ]
  },
  "geo" : { },
  "id_str" : "528592395680501761",
  "text" : "\"Let\u2019s make sure women earn #EqualPay for equal work.\" \u2014President Obama: http:\/\/t.co\/flhvqkcvDz http:\/\/t.co\/VPUFc7m1Rk",
  "id" : 528592395680501761,
  "created_at" : "2014-11-01 17:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/flhvqkcvDz",
      "expanded_url" : "http:\/\/go.wh.gov\/ynV92u",
      "display_url" : "go.wh.gov\/ynV92u"
    } ]
  },
  "geo" : { },
  "id_str" : "528573452312014848",
  "text" : "\"Even though it\u2019s 2014, there are women still earning less than men for doing the same work.\" \u2014Obama: http:\/\/t.co\/flhvqkcvDz #EqualPay",
  "id" : 528573452312014848,
  "created_at" : "2014-11-01 15:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/l9vnsH6LQ8",
      "expanded_url" : "http:\/\/go.wh.gov\/ynV92u",
      "display_url" : "go.wh.gov\/ynV92u"
    } ]
  },
  "geo" : { },
  "id_str" : "528559641505300482",
  "text" : "\"We should be choosing policies that benefit women\u2014because that benefits all of us.\" \u2014President Obama: http:\/\/t.co\/l9vnsH6LQ8 #WomenSucceed",
  "id" : 528559641505300482,
  "created_at" : "2014-11-01 14:50:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]