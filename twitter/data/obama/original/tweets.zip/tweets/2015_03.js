Grailbird.data.tweets_2015_03 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 75, 85 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 90, 102 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/583066231281946624\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/bP4kebVDPR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBd3RGcVEAAunCx.jpg",
      "id_str" : "583065812438683648",
      "id" : 583065812438683648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBd3RGcVEAAunCx.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bP4kebVDPR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583066231281946624",
  "text" : "President Obama receives an update on the P5+1 negotiations with Iran from @JohnKerry and @ErnestMoniz. http:\/\/t.co\/bP4kebVDPR",
  "id" : 583066231281946624,
  "created_at" : "2015-04-01 00:39:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/vHVkobsJ3S",
      "expanded_url" : "http:\/\/go.wh.gov\/PCUJw3",
      "display_url" : "go.wh.gov\/PCUJw3"
    } ]
  },
  "geo" : { },
  "id_str" : "583032187190185984",
  "text" : "RT @FLOTUS: Free admission to all public lands.\nFor every 4th-grader in America.\n#FindYourPark \u2192 http:\/\/t.co\/vHVkobsJ3S http:\/\/t.co\/ySbup9N\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/583029821896183810\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/ySbup9NEGL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBdDDWiUwAE3Yaz.jpg",
        "id_str" : "583008401635983361",
        "id" : 583008401635983361,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBdDDWiUwAE3Yaz.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ySbup9NEGL"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 69, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/vHVkobsJ3S",
        "expanded_url" : "http:\/\/go.wh.gov\/PCUJw3",
        "display_url" : "go.wh.gov\/PCUJw3"
      } ]
    },
    "geo" : { },
    "id_str" : "583029821896183810",
    "text" : "Free admission to all public lands.\nFor every 4th-grader in America.\n#FindYourPark \u2192 http:\/\/t.co\/vHVkobsJ3S http:\/\/t.co\/ySbup9NEGL",
    "id" : 583029821896183810,
    "created_at" : "2015-03-31 22:15:16 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 583032187190185984,
  "created_at" : "2015-03-31 22:24:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/583010997750792193\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/a4J2j1ZlOM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBdAfYEUMAAlDFF.jpg",
      "id_str" : "583005584548442112",
      "id" : 583005584548442112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBdAfYEUMAAlDFF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/a4J2j1ZlOM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/xXX33NiMto",
      "expanded_url" : "http:\/\/go.wh.gov\/eiwbyd",
      "display_url" : "go.wh.gov\/eiwbyd"
    } ]
  },
  "geo" : { },
  "id_str" : "583010997750792193",
  "text" : "President Obama's trade deal represents a historic opportunity to protect our environment: http:\/\/t.co\/xXX33NiMto http:\/\/t.co\/a4J2j1ZlOM",
  "id" : 583010997750792193,
  "created_at" : "2015-03-31 21:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/583003307402104834\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/gS1VOxNRYY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBc-UmZUUAE27cT.png",
      "id_str" : "583003200392810497",
      "id" : 583003200392810497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBc-UmZUUAE27cT.png",
      "sizes" : [ {
        "h" : 374,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 593
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 593
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 593
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/gS1VOxNRYY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/QO11L23x1j",
      "expanded_url" : "http:\/\/go.wh.gov\/T3geuW",
      "display_url" : "go.wh.gov\/T3geuW"
    } ]
  },
  "geo" : { },
  "id_str" : "583003307402104834",
  "text" : "\"I believe in your ability to prove the doubters wrong.\" \u2014President Obama: http:\/\/t.co\/QO11L23x1j http:\/\/t.co\/gS1VOxNRYY",
  "id" : 583003307402104834,
  "created_at" : "2015-03-31 20:29:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/582990524358918144\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/3SmaP7vo7Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBcyodtUQAAfppY.png",
      "id_str" : "582990347518623744",
      "id" : 582990347518623744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBcyodtUQAAfppY.png",
      "sizes" : [ {
        "h" : 374,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 593
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 593
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 593
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/3SmaP7vo7Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/QO11L23x1j",
      "expanded_url" : "http:\/\/go.wh.gov\/T3geuW",
      "display_url" : "go.wh.gov\/T3geuW"
    } ]
  },
  "geo" : { },
  "id_str" : "582990524358918144",
  "text" : "President Obama just sent 22 people this letter.\nHere's why he's giving them a 2nd chance \u2192 http:\/\/t.co\/QO11L23x1j http:\/\/t.co\/3SmaP7vo7Q",
  "id" : 582990524358918144,
  "created_at" : "2015-03-31 19:39:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/582940830056329216\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/eog4QbPbvA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBcFmDlUUAALtvR.jpg",
      "id_str" : "582940828122763264",
      "id" : 582940828122763264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBcFmDlUUAALtvR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eog4QbPbvA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/8HVIqcpEYa",
      "expanded_url" : "https:\/\/medium.com\/@Deese44\/we-re-taking-action-on-climate-change-and-the-world-is-joining-us-2bf44a62b9b9",
      "display_url" : "medium.com\/@Deese44\/we-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582964638809251840",
  "text" : "RT @VP: We\u2019re taking action on climate change\u200A\u2014\u200Aand the world is joining us. Here's how \u2192 https:\/\/t.co\/8HVIqcpEYa http:\/\/t.co\/eog4QbPbvA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/582940830056329216\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/eog4QbPbvA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBcFmDlUUAALtvR.jpg",
        "id_str" : "582940828122763264",
        "id" : 582940828122763264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBcFmDlUUAALtvR.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/eog4QbPbvA"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/8HVIqcpEYa",
        "expanded_url" : "https:\/\/medium.com\/@Deese44\/we-re-taking-action-on-climate-change-and-the-world-is-joining-us-2bf44a62b9b9",
        "display_url" : "medium.com\/@Deese44\/we-re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "582940830056329216",
    "text" : "We\u2019re taking action on climate change\u200A\u2014\u200Aand the world is joining us. Here's how \u2192 https:\/\/t.co\/8HVIqcpEYa http:\/\/t.co\/eog4QbPbvA",
    "id" : 582940830056329216,
    "created_at" : "2015-03-31 16:21:39 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 582964638809251840,
  "created_at" : "2015-03-31 17:56:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/582947609163264000\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/7ElzUAuigm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBcLo0iUUAA3UrM.jpg",
      "id_str" : "582947472693022720",
      "id" : 582947472693022720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBcLo0iUUAA3UrM.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/7ElzUAuigm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/uN6Wyez1MU",
      "expanded_url" : "http:\/\/go.wh.gov\/1wB8vs",
      "display_url" : "go.wh.gov\/1wB8vs"
    } ]
  },
  "geo" : { },
  "id_str" : "582947609163264000",
  "text" : "\"The capacity to reach across our differences is something that\u2019s entirely up to us.\" \u2014Obama: http:\/\/t.co\/uN6Wyez1MU http:\/\/t.co\/7ElzUAuigm",
  "id" : 582947609163264000,
  "created_at" : "2015-03-31 16:48:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/582932917782892544\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/EvAalG5g0N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBb6AS9WkAEiAlz.jpg",
      "id_str" : "582928084787171329",
      "id" : 582928084787171329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBb6AS9WkAEiAlz.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EvAalG5g0N"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 60, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/aPWTygLx95",
      "expanded_url" : "http:\/\/go.wh.gov\/climate-goal",
      "display_url" : "go.wh.gov\/climate-goal"
    } ]
  },
  "geo" : { },
  "id_str" : "582932917782892544",
  "text" : "Under President Obama, America is leading global efforts to #ActOnClimate \u2192 http:\/\/t.co\/aPWTygLx95 http:\/\/t.co\/EvAalG5g0N",
  "id" : 582932917782892544,
  "created_at" : "2015-03-31 15:50:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/582923408121442304\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/n57CCM64J4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBb1ks7WgAA79W2.jpg",
      "id_str" : "582923212675252224",
      "id" : 582923212675252224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBb1ks7WgAA79W2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n57CCM64J4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/aPWTyh38xF",
      "expanded_url" : "http:\/\/go.wh.gov\/climate-goal",
      "display_url" : "go.wh.gov\/climate-goal"
    } ]
  },
  "geo" : { },
  "id_str" : "582923408121442304",
  "text" : "President Obama's clean power plan would prevent up to 150,000 asthma attacks\/year in kids \u2192 http:\/\/t.co\/aPWTyh38xF http:\/\/t.co\/n57CCM64J4",
  "id" : 582923408121442304,
  "created_at" : "2015-03-31 15:12:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 22, 29 ],
      "id_str" : "571202103",
      "id" : 571202103
    }, {
      "name" : "UN Climate Action",
      "screen_name" : "UNFCCC",
      "indices" : [ 93, 100 ],
      "id_str" : "17463923",
      "id" : 17463923
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 67, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/xXzagPzfLh",
      "expanded_url" : "https:\/\/medium.com\/@Deese44\/we-re-taking-action-on-climate-change-and-the-world-is-joining-us-2bf44a62b9b9",
      "display_url" : "medium.com\/@Deese44\/we-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582917829617389569",
  "text" : "RT @Deese44: Big news @Medium: The US just submitted our post-2020 #ActOnClimate goal to the @UNFCCC: https:\/\/t.co\/xXzagPzfLh http:\/\/t.co\/j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 9, 16 ],
        "id_str" : "571202103",
        "id" : 571202103
      }, {
        "name" : "UN Climate Action",
        "screen_name" : "UNFCCC",
        "indices" : [ 80, 87 ],
        "id_str" : "17463923",
        "id" : 17463923
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/582906498436726784\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/j2gnWqAcLY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBbmANkVAAIMPCF.jpg",
        "id_str" : "582906093107478530",
        "id" : 582906093107478530,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBbmANkVAAIMPCF.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/j2gnWqAcLY"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 54, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/xXzagPzfLh",
        "expanded_url" : "https:\/\/medium.com\/@Deese44\/we-re-taking-action-on-climate-change-and-the-world-is-joining-us-2bf44a62b9b9",
        "display_url" : "medium.com\/@Deese44\/we-re\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "582906498436726784",
    "text" : "Big news @Medium: The US just submitted our post-2020 #ActOnClimate goal to the @UNFCCC: https:\/\/t.co\/xXzagPzfLh http:\/\/t.co\/j2gnWqAcLY",
    "id" : 582906498436726784,
    "created_at" : "2015-03-31 14:05:13 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 582917829617389569,
  "created_at" : "2015-03-31 14:50:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/582907379806785536\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/yqaM9MMwgt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBbmrMDUsAAif7E.jpg",
      "id_str" : "582906831434985472",
      "id" : 582906831434985472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBbmrMDUsAAif7E.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yqaM9MMwgt"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 27, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/Ft0xj1KpIJ",
      "expanded_url" : "https:\/\/medium.com\/@Deese44\/we-re-taking-action-on-climate-change-and-the-world-is-joining-us-2bf44a62b9b9",
      "display_url" : "medium.com\/@Deese44\/we-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582907379806785536",
  "text" : "America is taking steps to #ActOnClimate, and the world is joining us \u2192 https:\/\/t.co\/Ft0xj1KpIJ http:\/\/t.co\/yqaM9MMwgt",
  "id" : 582907379806785536,
  "created_at" : "2015-03-31 14:08:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/s7HVSsfwFB",
      "expanded_url" : "https:\/\/medium.com\/@VPOTUS\/five-things-i-ll-always-remember-about-teddy-kennedy-7b1541e53787",
      "display_url" : "medium.com\/@VPOTUS\/five-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "582663501979631616",
  "text" : "RT @VP: Teddy Kennedy was always there for me. Here\u2019s what I\u2019ll remember about my good friend. \u2013vp https:\/\/t.co\/s7HVSsfwFB http:\/\/t.co\/CnrB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/582663379166216193\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/CnrBMpjIAU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBYJQWYUMAAXl6q.jpg",
        "id_str" : "582663378281181184",
        "id" : 582663378281181184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBYJQWYUMAAXl6q.jpg",
        "sizes" : [ {
          "h" : 1009,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1408,
          "resize" : "fit",
          "w" : 1429
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/CnrBMpjIAU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/s7HVSsfwFB",
        "expanded_url" : "https:\/\/medium.com\/@VPOTUS\/five-things-i-ll-always-remember-about-teddy-kennedy-7b1541e53787",
        "display_url" : "medium.com\/@VPOTUS\/five-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "582663379166216193",
    "text" : "Teddy Kennedy was always there for me. Here\u2019s what I\u2019ll remember about my good friend. \u2013vp https:\/\/t.co\/s7HVSsfwFB http:\/\/t.co\/CnrBMpjIAU",
    "id" : 582663379166216193,
    "created_at" : "2015-03-30 21:59:09 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 582663501979631616,
  "created_at" : "2015-03-30 21:59:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "indices" : [ 3, 9 ],
      "id_str" : "15460572",
      "id" : 15460572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/fZjhaFGyAy",
      "expanded_url" : "http:\/\/bit.ly\/1E8n9qg",
      "display_url" : "bit.ly\/1E8n9qg"
    } ]
  },
  "geo" : { },
  "id_str" : "582645786976083968",
  "text" : "RT @ONDCP: Director Botticelli shares how personal experience has helped his work to stop U.S. opioid epidemic: http:\/\/t.co\/fZjhaFGyAy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/fZjhaFGyAy",
        "expanded_url" : "http:\/\/bit.ly\/1E8n9qg",
        "display_url" : "bit.ly\/1E8n9qg"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.8997456655427, -77.03971479385406 ]
    },
    "id_str" : "581523547270578176",
    "text" : "Director Botticelli shares how personal experience has helped his work to stop U.S. opioid epidemic: http:\/\/t.co\/fZjhaFGyAy",
    "id" : 581523547270578176,
    "created_at" : "2015-03-27 18:29:52 +0000",
    "user" : {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "protected" : false,
      "id_str" : "15460572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446652455552430080\/t6umtSs5_normal.png",
      "id" : 15460572,
      "verified" : true
    }
  },
  "id" : 582645786976083968,
  "created_at" : "2015-03-30 20:49:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Kennedy Institute",
      "screen_name" : "emkinstitute",
      "indices" : [ 37, 50 ],
      "id_str" : "69297657",
      "id" : 69297657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582602747519766528",
  "text" : "RT @JohnKerry: Sad I couldn't attend @emkinstitute dedication. I miss Teddy every day. No better friend or public servant. http:\/\/t.co\/ZBGG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kennedy Institute",
        "screen_name" : "emkinstitute",
        "indices" : [ 22, 35 ],
        "id_str" : "69297657",
        "id" : 69297657
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/582602424034037761\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/ZBGGOOYGgk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBXR0SWWEAAdfMj.jpg",
        "id_str" : "582602423023308800",
        "id" : 582602423023308800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBXR0SWWEAAdfMj.jpg",
        "sizes" : [ {
          "h" : 271,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 963
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 963
        } ],
        "display_url" : "pic.twitter.com\/ZBGGOOYGgk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "582602424034037761",
    "text" : "Sad I couldn't attend @emkinstitute dedication. I miss Teddy every day. No better friend or public servant. http:\/\/t.co\/ZBGGOOYGgk",
    "id" : 582602424034037761,
    "created_at" : "2015-03-30 17:56:56 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 582602747519766528,
  "created_at" : "2015-03-30 17:58:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582583378160934912",
  "text" : "RT @WHLive: \"May we all remember the times this American family has challenged us\u2014to ask what we can do; to dream and say why not\" \u2014Obama #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EMKInstitute",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "582583341448192000",
    "text" : "\"May we all remember the times this American family has challenged us\u2014to ask what we can do; to dream and say why not\" \u2014Obama #EMKInstitute",
    "id" : 582583341448192000,
    "created_at" : "2015-03-30 16:41:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 582583378160934912,
  "created_at" : "2015-03-30 16:41:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582583119649329153",
  "text" : "\"For all the imperfections of our democracy, the capacity to reach across our differences is something that\u2019s entirely up to us.\" \u2014Obama",
  "id" : 582583119649329153,
  "created_at" : "2015-03-30 16:40:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EMKInstitute",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582582681453654016",
  "text" : "\"We can come together on some things. And those 'somethings' can mean everything to a whole lot of people.\" \u2014President Obama #EMKInstitute",
  "id" : 582582681453654016,
  "created_at" : "2015-03-30 16:38:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582581820572618753",
  "text" : "RT @WHLive: \"His life\u2019s work was not to champion those with wealth or power or connections\u2026it was to give a voice to the people\" \u2014Obama #EM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EMKInstitute",
        "indices" : [ 124, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "582581789253722112",
    "text" : "\"His life\u2019s work was not to champion those with wealth or power or connections\u2026it was to give a voice to the people\" \u2014Obama #EMKInstitute",
    "id" : 582581789253722112,
    "created_at" : "2015-03-30 16:34:57 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 582581820572618753,
  "created_at" : "2015-03-30 16:35:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/582581369060102144\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/pMytACXOn4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBW-jEtU0AAatBW.jpg",
      "id_str" : "582581236582895616",
      "id" : 582581236582895616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBW-jEtU0AAatBW.jpg",
      "sizes" : [ {
        "h" : 264,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1416,
        "resize" : "fit",
        "w" : 1821
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/pMytACXOn4"
    } ],
    "hashtags" : [ {
      "text" : "EMKInstitute",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582581369060102144",
  "text" : "\"He was my friend. I owe him a lot.\" \u2014President Obama on Senator Ted Kennedy #EMKInstitute http:\/\/t.co\/pMytACXOn4",
  "id" : 582581369060102144,
  "created_at" : "2015-03-30 16:33:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EMKInstitute",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/4sMaHl9D3r",
      "expanded_url" : "http:\/\/go.wh.gov\/ZcCj37",
      "display_url" : "go.wh.gov\/ZcCj37"
    } ]
  },
  "geo" : { },
  "id_str" : "582581050850746369",
  "text" : "\"Ted understood that the only point in running for office was to get something done.\" \u2014President Obama: http:\/\/t.co\/4sMaHl9D3r #EMKInstitute",
  "id" : 582581050850746369,
  "created_at" : "2015-03-30 16:32:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Schultz44\/status\/582580060756033536\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/ZdwVbROlpm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBW9cRbWUAAoJIL.jpg",
      "id_str" : "582580020226445312",
      "id" : 582580020226445312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBW9cRbWUAAoJIL.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZdwVbROlpm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582580131413299200",
  "text" : "RT @Schultz44: President Obama: \"What if we carried ourselves more like Ted Kennedy?\" http:\/\/t.co\/ZdwVbROlpm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Schultz44\/status\/582580060756033536\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/ZdwVbROlpm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBW9cRbWUAAoJIL.jpg",
        "id_str" : "582580020226445312",
        "id" : 582580020226445312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBW9cRbWUAAoJIL.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZdwVbROlpm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.34953624853469, -71.07017065980567 ]
    },
    "id_str" : "582580060756033536",
    "text" : "President Obama: \"What if we carried ourselves more like Ted Kennedy?\" http:\/\/t.co\/ZdwVbROlpm",
    "id" : 582580060756033536,
    "created_at" : "2015-03-30 16:28:04 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 582580131413299200,
  "created_at" : "2015-03-30 16:28:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EMKInstitute",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/4sMaHl9D3r",
      "expanded_url" : "http:\/\/go.wh.gov\/ZcCj37",
      "display_url" : "go.wh.gov\/ZcCj37"
    } ]
  },
  "geo" : { },
  "id_str" : "582578661485735936",
  "text" : "\"No one made the Senate come alive like Ted Kennedy.\" \u2014President Obama: http:\/\/t.co\/4sMaHl9D3r #EMKInstitute",
  "id" : 582578661485735936,
  "created_at" : "2015-03-30 16:22:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582578186296283136",
  "text" : "RT @WHLive: \"Their legacies are as alive as ever together right here in Boston\" \u2014President Obama on President Kennedy and Sen. Ted Kennedy \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EMKInstitute",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "582578107988623360",
    "text" : "\"Their legacies are as alive as ever together right here in Boston\" \u2014President Obama on President Kennedy and Sen. Ted Kennedy #EMKInstitute",
    "id" : 582578107988623360,
    "created_at" : "2015-03-30 16:20:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 582578186296283136,
  "created_at" : "2015-03-30 16:20:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EMKInstitute",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/4sMaHlres1",
      "expanded_url" : "http:\/\/go.wh.gov\/ZcCj37",
      "display_url" : "go.wh.gov\/ZcCj37"
    } ]
  },
  "geo" : { },
  "id_str" : "582576813509124096",
  "text" : "Watch live: President Obama speaks at the dedication of the Edward M. Kennedy Institute \u2192 http:\/\/t.co\/4sMaHlres1 #EMKInstitute",
  "id" : 582576813509124096,
  "created_at" : "2015-03-30 16:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582569862091784192",
  "text" : "RT @VP: \"I watched him fight tooth and nail for equal justice for all.\" -VP Biden speaking about Senator Teddy Kennedy http:\/\/t.co\/5u6k3PFU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/582569811126849536\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/5u6k3PFU84",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBW0J3lVEAA7xwj.jpg",
        "id_str" : "582569808446689280",
        "id" : 582569808446689280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBW0J3lVEAA7xwj.jpg",
        "sizes" : [ {
          "h" : 1403,
          "resize" : "fit",
          "w" : 1098
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1308,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5u6k3PFU84"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "582569811126849536",
    "text" : "\"I watched him fight tooth and nail for equal justice for all.\" -VP Biden speaking about Senator Teddy Kennedy http:\/\/t.co\/5u6k3PFU84",
    "id" : 582569811126849536,
    "created_at" : "2015-03-30 15:47:21 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 582569862091784192,
  "created_at" : "2015-03-30 15:47:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/4sMaHl9D3r",
      "expanded_url" : "http:\/\/go.wh.gov\/ZcCj37",
      "display_url" : "go.wh.gov\/ZcCj37"
    } ]
  },
  "geo" : { },
  "id_str" : "582559688618745858",
  "text" : "At 11:25am ET, watch President Obama speak at the dedication of the Edward M. Kennedy Institute for the U.S. Senate \u2192 http:\/\/t.co\/4sMaHl9D3r",
  "id" : 582559688618745858,
  "created_at" : "2015-03-30 15:07:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2015",
      "indices" : [ 65, 73 ]
    }, {
      "text" : "StarttheSpark",
      "indices" : [ 86, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582536524669042688",
  "text" : "RT @NSCPress: BREAKING: In July, President Obama will attend the #GES2015 in Kenya to #StarttheSpark for entrepreneurs in Africa and the wo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GES2015",
        "indices" : [ 51, 59 ]
      }, {
        "text" : "StarttheSpark",
        "indices" : [ 72, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "582536456763146240",
    "text" : "BREAKING: In July, President Obama will attend the #GES2015 in Kenya to #StarttheSpark for entrepreneurs in Africa and the world.",
    "id" : 582536456763146240,
    "created_at" : "2015-03-30 13:34:48 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 582536524669042688,
  "created_at" : "2015-03-30 13:35:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 33, 44 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StarttheSpark",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "582529624879468544",
  "text" : "RT @NSCPress: Thanks for joining @WhiteHouse's chat on entrepreneurship - Let's go to your questions on how to #StarttheSpark across Africa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 19, 30 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StarttheSpark",
        "indices" : [ 97, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "582528800531025921",
    "text" : "Thanks for joining @WhiteHouse's chat on entrepreneurship - Let's go to your questions on how to #StarttheSpark across Africa &amp; globally...",
    "id" : 582528800531025921,
    "created_at" : "2015-03-30 13:04:23 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 582529624879468544,
  "created_at" : "2015-03-30 13:07:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/jECNkVmudF",
      "expanded_url" : "http:\/\/go.wh.gov\/kYgTpM",
      "display_url" : "go.wh.gov\/kYgTpM"
    } ]
  },
  "geo" : { },
  "id_str" : "582301301607825408",
  "text" : "\"Our top priority should be helping everybody who works hard get ahead.\" \u2014President Obama: http:\/\/t.co\/jECNkVmudF",
  "id" : 582301301607825408,
  "created_at" : "2015-03-29 22:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/jECNkVmudF",
      "expanded_url" : "http:\/\/go.wh.gov\/kYgTpM",
      "display_url" : "go.wh.gov\/kYgTpM"
    } ]
  },
  "geo" : { },
  "id_str" : "582255991158255616",
  "text" : "\"Protecting working Americans\u2019 paychecks shouldn\u2019t be a partisan issue.\" \u2014President Obama on reforming payday loans: http:\/\/t.co\/jECNkVmudF",
  "id" : 582255991158255616,
  "created_at" : "2015-03-29 19:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/jECNkV4Tm7",
      "expanded_url" : "http:\/\/go.wh.gov\/kYgTpM",
      "display_url" : "go.wh.gov\/kYgTpM"
    } ]
  },
  "geo" : { },
  "id_str" : "582213631263281152",
  "text" : "\"If you\u2019re a payday lender...you should make sure that the borrower can afford to pay it back first.\" \u2014Obama: http:\/\/t.co\/jECNkV4Tm7",
  "id" : 582213631263281152,
  "created_at" : "2015-03-29 16:12:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 111, 116 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/jECNkVmudF",
      "expanded_url" : "http:\/\/go.wh.gov\/kYgTpM",
      "display_url" : "go.wh.gov\/kYgTpM"
    } ]
  },
  "geo" : { },
  "id_str" : "581923813920636928",
  "text" : "\"They\u2019ve already put $5 billion back in the pockets of more than 15 million families.\" \u2014President Obama on the @CFPB: http:\/\/t.co\/jECNkVmudF",
  "id" : 581923813920636928,
  "created_at" : "2015-03-28 21:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/jECNkVmudF",
      "expanded_url" : "http:\/\/go.wh.gov\/kYgTpM",
      "display_url" : "go.wh.gov\/kYgTpM"
    } ]
  },
  "geo" : { },
  "id_str" : "581878545493835776",
  "text" : "\"We passed historic Wall Street reform to end the era of bailouts and too big to fail.\" \u2014President Obama: http:\/\/t.co\/jECNkVmudF",
  "id" : 581878545493835776,
  "created_at" : "2015-03-28 18:00:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 70, 81 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Africa",
      "indices" : [ 27, 34 ]
    }, {
      "text" : "Entrpreneurship",
      "indices" : [ 41, 57 ]
    }, {
      "text" : "YALICHAT",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/N5NAX0gR2O",
      "expanded_url" : "https:\/\/youngafricanleaders.state.gov\/white-house-yalichat-on-entrepreneurship-in-africa\/",
      "display_url" : "youngafricanleaders.state.gov\/white-house-ya\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581841790296301568",
  "text" : "RT @macon44: Interested in #Africa &amp; #Entrpreneurship? Don't miss @WhiteHouse #YALICHAT on Monday at 1300 UTC https:\/\/t.co\/N5NAX0gR2O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 57, 68 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Africa",
        "indices" : [ 14, 21 ]
      }, {
        "text" : "Entrpreneurship",
        "indices" : [ 28, 44 ]
      }, {
        "text" : "YALICHAT",
        "indices" : [ 69, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/N5NAX0gR2O",
        "expanded_url" : "https:\/\/youngafricanleaders.state.gov\/white-house-yalichat-on-entrepreneurship-in-africa\/",
        "display_url" : "youngafricanleaders.state.gov\/white-house-ya\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "581510601219936256",
    "text" : "Interested in #Africa &amp; #Entrpreneurship? Don't miss @WhiteHouse #YALICHAT on Monday at 1300 UTC https:\/\/t.co\/N5NAX0gR2O",
    "id" : 581510601219936256,
    "created_at" : "2015-03-27 17:38:25 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 581841790296301568,
  "created_at" : "2015-03-28 15:34:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/jECNkV4Tm7",
      "expanded_url" : "http:\/\/go.wh.gov\/kYgTpM",
      "display_url" : "go.wh.gov\/kYgTpM"
    } ]
  },
  "geo" : { },
  "id_str" : "581836154279972864",
  "text" : "President Obama's weekly address: Protecting working American's paychecks \u2192 http:\/\/t.co\/jECNkV4Tm7",
  "id" : 581836154279972864,
  "created_at" : "2015-03-28 15:12:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/OEGu1I524t",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2015\/03\/27\/statement-press-secretary-mexico-s-climate-announcement",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581575457864175616",
  "text" : "RT @lacasablanca: The US welcomes the effort made by the Mexican government to combat climate change: https:\/\/t.co\/OEGu1I524t http:\/\/t.co\/B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lacasablanca\/status\/581541049094447104\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/B5i6xEqSIS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBIMgC-U0AAquRx.jpg",
        "id_str" : "581541046577844224",
        "id" : 581541046577844224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBIMgC-U0AAquRx.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/B5i6xEqSIS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/OEGu1I524t",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2015\/03\/27\/statement-press-secretary-mexico-s-climate-announcement",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "581541049094447104",
    "text" : "The US welcomes the effort made by the Mexican government to combat climate change: https:\/\/t.co\/OEGu1I524t http:\/\/t.co\/B5i6xEqSIS",
    "id" : 581541049094447104,
    "created_at" : "2015-03-27 19:39:25 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 581575457864175616,
  "created_at" : "2015-03-27 21:56:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Deese44\/status\/581549591469821952\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/dcEIahBVgE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBIT6KCU0AAG9a9.png",
      "id_str" : "581549191731662848",
      "id" : 581549191731662848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBIT6KCU0AAG9a9.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 135,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/dcEIahBVgE"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581559106130968576",
  "text" : "Good news: Mexico is joining the U.S. in taking steps to reduce carbon pollution and #ActOnClimate. http:\/\/t.co\/dcEIahBVgE",
  "id" : 581559106130968576,
  "created_at" : "2015-03-27 20:51:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 12, 28 ],
      "id_str" : "65647594",
      "id" : 65647594
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 53, 67 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/581549770080047104\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/TDzl0B4RE9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBITzwiVEAAzhtf.jpg",
      "id_str" : "581549081807360000",
      "id" : 581549081807360000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBITzwiVEAAzhtf.jpg",
      "sizes" : [ {
        "h" : 1491,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 763,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TDzl0B4RE9"
    } ],
    "hashtags" : [ {
      "text" : "YearInSpace",
      "indices" : [ 76, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/34ZfA49jDU",
      "expanded_url" : "http:\/\/go.nasa.gov\/1xFtpnu",
      "display_url" : "go.nasa.gov\/1xFtpnu"
    } ]
  },
  "geo" : { },
  "id_str" : "581549770080047104",
  "text" : "Congrats to @StationCDRKelly as he takes off for the @Space_Station and his #YearInSpace! http:\/\/t.co\/34ZfA49jDU http:\/\/t.co\/TDzl0B4RE9",
  "id" : 581549770080047104,
  "created_at" : "2015-03-27 20:14:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 34, 44 ],
      "id_str" : "180505807",
      "id" : 180505807
    }, {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 80, 96 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInSpace",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/34ZfA49jDU",
      "expanded_url" : "http:\/\/go.nasa.gov\/1xFtpnu",
      "display_url" : "go.nasa.gov\/1xFtpnu"
    } ]
  },
  "geo" : { },
  "id_str" : "581543407966781440",
  "text" : "\"Good luck, Captain. Make sure to @Instagram it. We\u2019re proud of you.\" \u2014Obama to @StationCDRKelly on his #YearInSpace: http:\/\/t.co\/34ZfA49jDU",
  "id" : 581543407966781440,
  "created_at" : "2015-03-27 19:48:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 27, 43 ],
      "id_str" : "65647594",
      "id" : 65647594
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 66, 80 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/581541385762775040\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/onDpKmWV6E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBILEXGUwAEKJ6I.jpg",
      "id_str" : "581539471432138753",
      "id" : 581539471432138753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBILEXGUwAEKJ6I.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/onDpKmWV6E"
    } ],
    "hashtags" : [ {
      "text" : "YearInSpace",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/XDVgGiL890",
      "expanded_url" : "http:\/\/www.nasa.gov\/nasatv",
      "display_url" : "nasa.gov\/nasatv"
    } ]
  },
  "geo" : { },
  "id_str" : "581541385762775040",
  "text" : "Take off at 3:42pm ET with @StationCDRKelly as he launches to the @Space_Station: http:\/\/t.co\/XDVgGiL890 #YearInSpace http:\/\/t.co\/onDpKmWV6E",
  "id" : 581541385762775040,
  "created_at" : "2015-03-27 19:40:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 27, 38 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DaughtersAndSons",
      "indices" : [ 87, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581521425330085888",
  "text" : "RT @Cecilia44: Can't wait! @WhiteHouse will invite DC youth to participate in Take Our #DaughtersAndSons to Work Day on 4\/23 http:\/\/t.co\/Z2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 12, 23 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DaughtersAndSons",
        "indices" : [ 72, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/Z2dmPwpeSG",
        "expanded_url" : "http:\/\/WH.gov\/DaughtersAndSons",
        "display_url" : "WH.gov\/DaughtersAndSo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "581508058544668672",
    "text" : "Can't wait! @WhiteHouse will invite DC youth to participate in Take Our #DaughtersAndSons to Work Day on 4\/23 http:\/\/t.co\/Z2dmPwpeSG",
    "id" : 581508058544668672,
    "created_at" : "2015-03-27 17:28:19 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 581521425330085888,
  "created_at" : "2015-03-27 18:21:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/hPyuIRVuo2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ntLMkXXJoao",
      "display_url" : "youtube.com\/watch?v=ntLMkX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581512923794644992",
  "text" : "RT @SenatorReid: Thank you, Mr. President. You're a great friend and a great leader. http:\/\/t.co\/hPyuIRVuo2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/hPyuIRVuo2",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ntLMkXXJoao",
        "display_url" : "youtube.com\/watch?v=ntLMkX\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "581508804409470976",
    "text" : "Thank you, Mr. President. You're a great friend and a great leader. http:\/\/t.co\/hPyuIRVuo2",
    "id" : 581508804409470976,
    "created_at" : "2015-03-27 17:31:17 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 581512923794644992,
  "created_at" : "2015-03-27 17:47:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ZhnH3gA5pM",
      "expanded_url" : "http:\/\/wb.md\/1HQDy0l",
      "display_url" : "wb.md\/1HQDy0l"
    } ]
  },
  "geo" : { },
  "id_str" : "581493323757719553",
  "text" : "\"Antibiotic resistance is one of the most pressing public health issues facing the world today\" \u2014President Obama: http:\/\/t.co\/ZhnH3gA5pM",
  "id" : 581493323757719553,
  "created_at" : "2015-03-27 16:29:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 20, 36 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YearInSpace",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581482353433935872",
  "text" : "RT @DrBiden: Today, @StationCDRKelly will rocket away from earth for a #YearInSpace mission on ISS. Safe travels, Captain! \u2013Jill http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Scott Kelly",
        "screen_name" : "StationCDRKelly",
        "indices" : [ 7, 23 ],
        "id_str" : "65647594",
        "id" : 65647594
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/581455907168632832\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/qgE8MGhMJ8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBG_EGOUYAI_ruW.jpg",
        "id_str" : "581455904018554882",
        "id" : 581455904018554882,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBG_EGOUYAI_ruW.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qgE8MGhMJ8"
      } ],
      "hashtags" : [ {
        "text" : "YearInSpace",
        "indices" : [ 58, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581455907168632832",
    "text" : "Today, @StationCDRKelly will rocket away from earth for a #YearInSpace mission on ISS. Safe travels, Captain! \u2013Jill http:\/\/t.co\/qgE8MGhMJ8",
    "id" : 581455907168632832,
    "created_at" : "2015-03-27 14:01:05 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 581482353433935872,
  "created_at" : "2015-03-27 15:46:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581480144075812864",
  "text" : "RT @SenatorReid: My life\u2019s work has been to make Nevada and our nation better. Thank you for giving me that wonderful opportunity. https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/dwy2rDWYhO",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=MqPWTECMIQo",
        "display_url" : "youtube.com\/watch?v=MqPWTE\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "581422891285245952",
    "text" : "My life\u2019s work has been to make Nevada and our nation better. Thank you for giving me that wonderful opportunity. https:\/\/t.co\/dwy2rDWYhO",
    "id" : 581422891285245952,
    "created_at" : "2015-03-27 11:49:54 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 581480144075812864,
  "created_at" : "2015-03-27 15:37:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 65, 77 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/581477640470704128\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/nmLIDl8hco",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBHSkmiVAAAtnQQ.png",
      "id_str" : "581477353169158144",
      "id" : 581477353169158144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBHSkmiVAAAtnQQ.png",
      "sizes" : [ {
        "h" : 308,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 1155
      }, {
        "h" : 102,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nmLIDl8hco"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581477640470704128",
  "text" : "\"Harry Reid is a fighter.\" \u2014President Obama on the retirement of @SenatorReid http:\/\/t.co\/nmLIDl8hco",
  "id" : 581477640470704128,
  "created_at" : "2015-03-27 15:27:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/oaHGKjBt2B",
      "expanded_url" : "https:\/\/youtu.be\/xWY79JCfhjw",
      "display_url" : "youtu.be\/xWY79JCfhjw"
    } ]
  },
  "geo" : { },
  "id_str" : "581450504296861696",
  "text" : "If you're a fan of The Wire, watch this:\nPresident Obama and David Simon discuss criminal justice reform \u2192 https:\/\/t.co\/oaHGKjBt2B",
  "id" : 581450504296861696,
  "created_at" : "2015-03-27 13:39:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/oaHGKjjRE1",
      "expanded_url" : "https:\/\/youtu.be\/xWY79JCfhjw",
      "display_url" : "youtu.be\/xWY79JCfhjw"
    } ]
  },
  "geo" : { },
  "id_str" : "581225420256772098",
  "text" : "President Obama \u2713\nDavid Simon \u2713\nThe Wire \u2713\nWatch their conversation on criminal justice reform \u2192 https:\/\/t.co\/oaHGKjjRE1",
  "id" : 581225420256772098,
  "created_at" : "2015-03-26 22:45:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "indices" : [ 23, 35 ],
      "id_str" : "293131808",
      "id" : 293131808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581214543742824448",
  "text" : "RT @vj44: Great to see @PattyMurray's amdt to increase access to paid sick leave pass w bipartisan support. A step in the right direction!#\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Patty Murray",
        "screen_name" : "PattyMurray",
        "indices" : [ 13, 25 ],
        "id_str" : "293131808",
        "id" : 293131808
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581212732155924480",
    "text" : "Great to see @PattyMurray's amdt to increase access to paid sick leave pass w bipartisan support. A step in the right direction!#LeadOnLeave",
    "id" : 581212732155924480,
    "created_at" : "2015-03-26 21:54:48 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 581214543742824448,
  "created_at" : "2015-03-26 22:02:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/oaHGKjBt2B",
      "expanded_url" : "https:\/\/youtu.be\/xWY79JCfhjw",
      "display_url" : "youtu.be\/xWY79JCfhjw"
    } ]
  },
  "geo" : { },
  "id_str" : "581207193300701185",
  "text" : "Watch President Obama's conversation on criminal justice reform with David Simon, the creator of The Wire \u2192 https:\/\/t.co\/oaHGKjBt2B",
  "id" : 581207193300701185,
  "created_at" : "2015-03-26 21:32:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 106, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581197283745644544",
  "text" : "\"In America, hard work should pay off and responsibility should be rewarded.\" \u2014President Obama in Alabama #OpportunityForAll",
  "id" : 581197283745644544,
  "created_at" : "2015-03-26 20:53:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 133, 138 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581195114954952704",
  "text" : "RT @WHLive: \"They\u2019ve already put more than $5 billion back in the pockets of more than 15 million families.\" \u2014President Obama on the @CFPB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "consumerfinance.gov",
        "screen_name" : "CFPB",
        "indices" : [ 121, 126 ],
        "id_str" : "234826866",
        "id" : 234826866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581195087683538945",
    "text" : "\"They\u2019ve already put more than $5 billion back in the pockets of more than 15 million families.\" \u2014President Obama on the @CFPB",
    "id" : 581195087683538945,
    "created_at" : "2015-03-26 20:44:41 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 581195114954952704,
  "created_at" : "2015-03-26 20:44:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581194250802458624",
  "text" : "RT @WHLive: \"I don\u2019t think our top economic priority should be helping a tiny number of Americans who are already doing really really well\"\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581194226475642880",
    "text" : "\"I don\u2019t think our top economic priority should be helping a tiny number of Americans who are already doing really really well\" \u2014Obama",
    "id" : 581194226475642880,
    "created_at" : "2015-03-26 20:41:16 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 581194250802458624,
  "created_at" : "2015-03-26 20:41:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/581193855116005376\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/dzteJxBKGC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBDQolWUIAAS9p3.jpg",
      "id_str" : "581193747569844224",
      "id" : 581193747569844224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBDQolWUIAAS9p3.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dzteJxBKGC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/NddfumDPzi",
      "expanded_url" : "http:\/\/go.wh.gov\/HcEZLf",
      "display_url" : "go.wh.gov\/HcEZLf"
    } ]
  },
  "geo" : { },
  "id_str" : "581193855116005376",
  "text" : "\u201CThe deficit\u2019s come down by two-thirds since I\u2019ve been President.\u201D \u2014Obama in Alabama: http:\/\/t.co\/NddfumDPzi http:\/\/t.co\/dzteJxBKGC",
  "id" : 581193855116005376,
  "created_at" : "2015-03-26 20:39:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 107, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581193408661745664",
  "text" : "\"Two years of community college should be as free and universal as high school is today.\" \u2014President Obama #FreeCommunityCollege",
  "id" : 581193408661745664,
  "created_at" : "2015-03-26 20:38:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/581193280940969984\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/6QQ1l63oxw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBDQLlzUcAAnhoj.jpg",
      "id_str" : "581193249475293184",
      "id" : 581193249475293184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBDQLlzUcAAnhoj.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6QQ1l63oxw"
    } ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 79, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581193280940969984",
  "text" : "\"I want to bring down the cost of community college to zero.\" \u2014President Obama #FreeCommunityCollege http:\/\/t.co\/6QQ1l63oxw",
  "id" : 581193280940969984,
  "created_at" : "2015-03-26 20:37:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581192935011561472",
  "text" : "RT @WHLive: \"It\u2019s time to follow the example of states, cities &amp; companies that are raising America\u2019s minimum wage.\" \u2014Obama http:\/\/t.co\/u0g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/581192913918431232\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/u0gbpcH6oh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBDP3nsUMAAjrdg.jpg",
        "id_str" : "581192906385403904",
        "id" : 581192906385403904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBDP3nsUMAAjrdg.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/u0gbpcH6oh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581192913918431232",
    "text" : "\"It\u2019s time to follow the example of states, cities &amp; companies that are raising America\u2019s minimum wage.\" \u2014Obama http:\/\/t.co\/u0gbpcH6oh",
    "id" : 581192913918431232,
    "created_at" : "2015-03-26 20:36:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 581192935011561472,
  "created_at" : "2015-03-26 20:36:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/581192089867722752\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/0V7ZnrZ1wO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBDPFzmVEAA9cdH.jpg",
      "id_str" : "581192050588061696",
      "id" : 581192050588061696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBDPFzmVEAA9cdH.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0V7ZnrZ1wO"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 91, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581192089867722752",
  "text" : "\"More than 16 million uninsured Americans have gained the security of health care.\" \u2014Obama #BetterWithObamacare http:\/\/t.co\/0V7ZnrZ1wO",
  "id" : 581192089867722752,
  "created_at" : "2015-03-26 20:32:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/581191774346956800\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/5WbGJVo53K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBDO0hmUMAExe1v.jpg",
      "id_str" : "581191753698390017",
      "id" : 581191753698390017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBDO0hmUMAExe1v.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5WbGJVo53K"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581191774346956800",
  "text" : "\"Right now, we\u2019re in a 60-month streak of private-sector job creation\u2026we\u2019ve created 12 million new jobs.\" \u2014Obama http:\/\/t.co\/5WbGJVo53K",
  "id" : 581191774346956800,
  "created_at" : "2015-03-26 20:31:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Baracketology",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581191584575782912",
  "text" : "\"I didn\u2019t have UAB making it out of the first round. My bracket is so busted.\" \u2014Obama in Alabama on his NCAA bracket #Baracketology",
  "id" : 581191584575782912,
  "created_at" : "2015-03-26 20:30:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/NddfumDPzi",
      "expanded_url" : "http:\/\/go.wh.gov\/HcEZLf",
      "display_url" : "go.wh.gov\/HcEZLf"
    } ]
  },
  "geo" : { },
  "id_str" : "581190991744344064",
  "text" : "Happening now: President Obama speaks on the economy in Birmingham, Alabama \u2192 http:\/\/t.co\/NddfumDPzi",
  "id" : 581190991744344064,
  "created_at" : "2015-03-26 20:28:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 80, 87 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Opioid",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581172352781717504",
  "text" : "RT @SecBurwell: #Opioid drug abuse is a devastating epidemic facing our nation. @HHSGov is ready to tackle this crisis: http:\/\/t.co\/CpYaoMm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HHS.gov",
        "screen_name" : "HHSGov",
        "indices" : [ 64, 71 ],
        "id_str" : "44783853",
        "id" : 44783853
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Opioid",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/CpYaoMmuGZ",
        "expanded_url" : "http:\/\/1.usa.gov\/1HOHVcd",
        "display_url" : "1.usa.gov\/1HOHVcd"
      } ]
    },
    "geo" : { },
    "id_str" : "581157483521118208",
    "text" : "#Opioid drug abuse is a devastating epidemic facing our nation. @HHSGov is ready to tackle this crisis: http:\/\/t.co\/CpYaoMmuGZ.",
    "id" : 581157483521118208,
    "created_at" : "2015-03-26 18:15:16 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 581172352781717504,
  "created_at" : "2015-03-26 19:14:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "indices" : [ 13, 23 ],
      "id_str" : "74286565",
      "id" : 74286565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/qbVJxXRPdc",
      "expanded_url" : "http:\/\/nyti.ms\/1HKClaO",
      "display_url" : "nyti.ms\/1HKClaO"
    } ]
  },
  "geo" : { },
  "id_str" : "581121206142803968",
  "text" : "Great to see @Microsoft doing the right thing by extending paid leave benefits to contractors \u2192 http:\/\/t.co\/qbVJxXRPdc #LeadOnLeave",
  "id" : 581121206142803968,
  "created_at" : "2015-03-26 15:51:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPressSec",
      "indices" : [ 32, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581106606454239232",
  "text" : "RT @PressSec: Join me today for #AskPressSec from 12:30-1:00pm ET, send any questions you may have my way!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPressSec",
        "indices" : [ 18, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581105550429188096",
    "text" : "Join me today for #AskPressSec from 12:30-1:00pm ET, send any questions you may have my way!",
    "id" : 581105550429188096,
    "created_at" : "2015-03-26 14:48:54 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 581106606454239232,
  "created_at" : "2015-03-26 14:53:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "indices" : [ 15, 25 ],
      "id_str" : "74286565",
      "id" : 74286565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnleave",
      "indices" : [ 37, 49 ]
    }, {
      "text" : "PaidLeave",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581101267780501505",
  "text" : "RT @LaborSec: .@Microsoft taking the #LeadOnleave by extending #PaidLeave to all contractors. Right thing for workers and business: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Microsoft",
        "screen_name" : "Microsoft",
        "indices" : [ 1, 11 ],
        "id_str" : "74286565",
        "id" : 74286565
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnleave",
        "indices" : [ 23, 35 ]
      }, {
        "text" : "PaidLeave",
        "indices" : [ 49, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/00OmS0N0nS",
        "expanded_url" : "http:\/\/nyti.ms\/1HKClaO",
        "display_url" : "nyti.ms\/1HKClaO"
      } ]
    },
    "geo" : { },
    "id_str" : "581094324659740672",
    "text" : ".@Microsoft taking the #LeadOnleave by extending #PaidLeave to all contractors. Right thing for workers and business: http:\/\/t.co\/00OmS0N0nS",
    "id" : 581094324659740672,
    "created_at" : "2015-03-26 14:04:17 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 581101267780501505,
  "created_at" : "2015-03-26 14:31:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 34, 41 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 81, 90 ],
      "id_str" : "500704345",
      "id" : 500704345
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 98, 109 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "581092941503950848",
  "text" : "RT @PressSec: President Obama and @FLOTUS look forward to welcoming His Holiness @Pontifex to the @WhiteHouse on September 23 http:\/\/t.co\/w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 20, 27 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Pope Francis",
        "screen_name" : "Pontifex",
        "indices" : [ 67, 76 ],
        "id_str" : "500704345",
        "id" : 500704345
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 84, 95 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/581092731201720320\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/w9Wg0SiCgO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBB0wlOWkAMBlZC.png",
        "id_str" : "581092729905647619",
        "id" : 581092729905647619,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBB0wlOWkAMBlZC.png",
        "sizes" : [ {
          "h" : 368,
          "resize" : "fit",
          "w" : 745
        }, {
          "h" : 168,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 745
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/w9Wg0SiCgO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "581092731201720320",
    "text" : "President Obama and @FLOTUS look forward to welcoming His Holiness @Pontifex to the @WhiteHouse on September 23 http:\/\/t.co\/w9Wg0SiCgO",
    "id" : 581092731201720320,
    "created_at" : "2015-03-26 13:57:57 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 581092941503950848,
  "created_at" : "2015-03-26 13:58:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "indices" : [ 33, 43 ],
      "id_str" : "74286565",
      "id" : 74286565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/yFoVIsfSKM",
      "expanded_url" : "http:\/\/nyti.ms\/1HKClaO",
      "display_url" : "nyti.ms\/1HKClaO"
    } ]
  },
  "geo" : { },
  "id_str" : "581084546273316864",
  "text" : "RT @vj44: Huge announcement from @Microsoft that they'll require paid sick\/family leave for contractors: http:\/\/t.co\/yFoVIsfSKM #LeadOnLeav\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Microsoft",
        "screen_name" : "Microsoft",
        "indices" : [ 23, 33 ],
        "id_str" : "74286565",
        "id" : 74286565
      }, {
        "name" : "Brad Smith",
        "screen_name" : "BradSmi",
        "indices" : [ 131, 139 ],
        "id_str" : "14505546",
        "id" : 14505546
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 118, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/yFoVIsfSKM",
        "expanded_url" : "http:\/\/nyti.ms\/1HKClaO",
        "display_url" : "nyti.ms\/1HKClaO"
      } ]
    },
    "geo" : { },
    "id_str" : "581083605105033216",
    "text" : "Huge announcement from @Microsoft that they'll require paid sick\/family leave for contractors: http:\/\/t.co\/yFoVIsfSKM #LeadOnLeave @BradSmi",
    "id" : 581083605105033216,
    "created_at" : "2015-03-26 13:21:42 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 581084546273316864,
  "created_at" : "2015-03-26 13:25:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580856790767665152\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/DIc1wiGLqK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA-dTr5UcAApvRF.jpg",
      "id_str" : "580855838480297984",
      "id" : 580855838480297984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA-dTr5UcAApvRF.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/DIc1wiGLqK"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 91, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/2Enu2aQvNt",
      "expanded_url" : "http:\/\/go.wh.gov\/uLTGia",
      "display_url" : "go.wh.gov\/uLTGia"
    } ]
  },
  "geo" : { },
  "id_str" : "580856790767665152",
  "text" : "\"You can no longer be charged more just for being a woman.\" \u2014Obama: http:\/\/t.co\/2Enu2aQvNt #BetterWithObamacare http:\/\/t.co\/DIc1wiGLqK",
  "id" : 580856790767665152,
  "created_at" : "2015-03-25 22:20:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SELF Magazine",
      "screen_name" : "SELFmagazine",
      "indices" : [ 65, 78 ],
      "id_str" : "23798922",
      "id" : 23798922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 104, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/ud3B4h3DTM",
      "expanded_url" : "http:\/\/on.self.com\/1OxRqBL",
      "display_url" : "on.self.com\/1OxRqBL"
    } ]
  },
  "geo" : { },
  "id_str" : "580847944414318592",
  "text" : "Read how the Affordable Care Act changed three women's lives via @SELFmagazine \u2192 http:\/\/t.co\/ud3B4h3DTM #BetterWithObamacare",
  "id" : 580847944414318592,
  "created_at" : "2015-03-25 21:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/580834761872142336\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/Xu4esDJpFV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA-KI0PWQAAHr_f.jpg",
      "id_str" : "580834761020686336",
      "id" : 580834761020686336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA-KI0PWQAAHr_f.jpg",
      "sizes" : [ {
        "h" : 795,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 466,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3156,
        "resize" : "fit",
        "w" : 4065
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Xu4esDJpFV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580843383729434624",
  "text" : "RT @repjohnlewis: 50 years ago today, the march from Selma arrived in Montgomery. http:\/\/t.co\/Xu4esDJpFV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/580834761872142336\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/Xu4esDJpFV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CA-KI0PWQAAHr_f.jpg",
        "id_str" : "580834761020686336",
        "id" : 580834761020686336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA-KI0PWQAAHr_f.jpg",
        "sizes" : [ {
          "h" : 795,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 466,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 3156,
          "resize" : "fit",
          "w" : 4065
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Xu4esDJpFV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580834761872142336",
    "text" : "50 years ago today, the march from Selma arrived in Montgomery. http:\/\/t.co\/Xu4esDJpFV",
    "id" : 580834761872142336,
    "created_at" : "2015-03-25 20:52:53 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 580843383729434624,
  "created_at" : "2015-03-25 21:27:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580837338298773504\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/2BdJmefYbP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA-MSG-U0AAzeea.jpg",
      "id_str" : "580837119691640832",
      "id" : 580837119691640832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA-MSG-U0AAzeea.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/2BdJmefYbP"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 94, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/2Enu2aQvNt",
      "expanded_url" : "http:\/\/go.wh.gov\/uLTGia",
      "display_url" : "go.wh.gov\/uLTGia"
    } ]
  },
  "geo" : { },
  "id_str" : "580837338298773504",
  "text" : "\"The ranks of the uninsured have dropped by nearly one-third.\" \u2014Obama: http:\/\/t.co\/2Enu2aQvNt #BetterWithObamacare http:\/\/t.co\/2BdJmefYbP",
  "id" : 580837338298773504,
  "created_at" : "2015-03-25 21:03:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EPA\/status\/580789556586373120\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/dm9kz1JAC5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA9hBhBWkAAUBrS.jpg",
      "id_str" : "580789555625889792",
      "id" : 580789555625889792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA9hBhBWkAAUBrS.jpg",
      "sizes" : [ {
        "h" : 253,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dm9kz1JAC5"
    } ],
    "hashtags" : [ {
      "text" : "EnergyStar",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/bh19jEHVSJ",
      "expanded_url" : "http:\/\/go.usa.gov\/3r6mH",
      "display_url" : "go.usa.gov\/3r6mH"
    } ]
  },
  "geo" : { },
  "id_str" : "580799775999533056",
  "text" : "RT @EPA: Does your city make the cut? Check out the top 25 #EnergyStar cities here: http:\/\/t.co\/bh19jEHVSJ http:\/\/t.co\/dm9kz1JAC5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EPA\/status\/580789556586373120\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/dm9kz1JAC5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CA9hBhBWkAAUBrS.jpg",
        "id_str" : "580789555625889792",
        "id" : 580789555625889792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA9hBhBWkAAUBrS.jpg",
        "sizes" : [ {
          "h" : 253,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dm9kz1JAC5"
      } ],
      "hashtags" : [ {
        "text" : "EnergyStar",
        "indices" : [ 50, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/bh19jEHVSJ",
        "expanded_url" : "http:\/\/go.usa.gov\/3r6mH",
        "display_url" : "go.usa.gov\/3r6mH"
      } ]
    },
    "geo" : { },
    "id_str" : "580789556586373120",
    "text" : "Does your city make the cut? Check out the top 25 #EnergyStar cities here: http:\/\/t.co\/bh19jEHVSJ http:\/\/t.co\/dm9kz1JAC5",
    "id" : 580789556586373120,
    "created_at" : "2015-03-25 17:53:15 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 580799775999533056,
  "created_at" : "2015-03-25 18:33:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580782802636906496",
  "text" : "RT @LaborSec: Next week I'll be hitting the road to talk with workers and biz about how we can #LeadOnLeave. First stop: Seattle \u2192 http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 81, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/wgxrPT8vqr",
        "expanded_url" : "http:\/\/linkd.in\/1HFt4Ec",
        "display_url" : "linkd.in\/1HFt4Ec"
      } ]
    },
    "geo" : { },
    "id_str" : "580763519588667392",
    "text" : "Next week I'll be hitting the road to talk with workers and biz about how we can #LeadOnLeave. First stop: Seattle \u2192 http:\/\/t.co\/wgxrPT8vqr",
    "id" : 580763519588667392,
    "created_at" : "2015-03-25 16:09:47 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 580782802636906496,
  "created_at" : "2015-03-25 17:26:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/6pJPd7hGgr",
      "expanded_url" : "http:\/\/go.wh.gov\/uLTGia",
      "display_url" : "go.wh.gov\/uLTGia"
    } ]
  },
  "geo" : { },
  "id_str" : "580765082650419200",
  "text" : "RT @Santillo44: Here are 4 ways the Affordable Care Act is improving the quality of health care in America \u2192 http:\/\/t.co\/6pJPd7hGgr #Better\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BetterWithObamacare",
        "indices" : [ 116, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/6pJPd7hGgr",
        "expanded_url" : "http:\/\/go.wh.gov\/uLTGia",
        "display_url" : "go.wh.gov\/uLTGia"
      } ]
    },
    "geo" : { },
    "id_str" : "580762908868505600",
    "text" : "Here are 4 ways the Affordable Care Act is improving the quality of health care in America \u2192 http:\/\/t.co\/6pJPd7hGgr #BetterWithObamacare",
    "id" : 580762908868505600,
    "created_at" : "2015-03-25 16:07:22 +0000",
    "user" : {
      "name" : "Katie Hill",
      "screen_name" : "Hill44",
      "protected" : false,
      "id_str" : "2151620534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658658579142959104\/85LEK24P_normal.jpg",
      "id" : 2151620534,
      "verified" : true
    }
  },
  "id" : 580765082650419200,
  "created_at" : "2015-03-25 16:16:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 96, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/NV3OeafQHp",
      "expanded_url" : "http:\/\/snpy.tv\/1HF9yYL",
      "display_url" : "snpy.tv\/1HF9yYL"
    } ]
  },
  "geo" : { },
  "id_str" : "580752980741365760",
  "text" : "Watch President Obama speak on how the Affordable Care Act is benefiting millions of Americans. #BetterWithObamacare http:\/\/t.co\/NV3OeafQHp",
  "id" : 580752980741365760,
  "created_at" : "2015-03-25 15:27:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580746003713671168",
  "text" : "RT @WHLive: \"We declared that in the United States of America, the security of quality, affordable health care was not a privilege, but a r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580745737199230976",
    "text" : "\"We declared that in the United States of America, the security of quality, affordable health care was not a privilege, but a right.\" \u2014Obama",
    "id" : 580745737199230976,
    "created_at" : "2015-03-25 14:59:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 580746003713671168,
  "created_at" : "2015-03-25 15:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 120, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580744012958724096",
  "text" : "RT @WHLive: \"This law is saving money for families and for businesses. This law is also saving lives.\" \u2014President Obama #BetterWithObamacare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BetterWithObamacare",
        "indices" : [ 108, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580743989613187073",
    "text" : "\"This law is saving money for families and for businesses. This law is also saving lives.\" \u2014President Obama #BetterWithObamacare",
    "id" : 580743989613187073,
    "created_at" : "2015-03-25 14:52:11 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 580744012958724096,
  "created_at" : "2015-03-25 14:52:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 104, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580743377550999552",
  "text" : "\"You can no longer be charged more just for being a woman.\" \u2014President Obama on the Affordable Care Act #BetterWithObamacare",
  "id" : 580743377550999552,
  "created_at" : "2015-03-25 14:49:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580743164635435008\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/BqbtGvJ427",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA82yz0UQAELN0x.jpg",
      "id_str" : "580743123485081601",
      "id" : 580743123485081601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA82yz0UQAELN0x.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BqbtGvJ427"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 93, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580743164635435008",
  "text" : "\"In just over one year, the ranks of the uninsured have dropped by nearly one-third.\" \u2014Obama #BetterWithObamacare http:\/\/t.co\/BqbtGvJ427",
  "id" : 580743164635435008,
  "created_at" : "2015-03-25 14:48:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580743039032799233\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/a0ZKHUGbTl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA82tCtUMAE_jOd.jpg",
      "id_str" : "580743024403034113",
      "id" : 580743024403034113,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA82tCtUMAE_jOd.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/a0ZKHUGbTl"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 89, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580743039032799233",
  "text" : "\"More than 16 million uninsured Americans have gained health coverage.\" \u2014President Obama #BetterWithObamacare http:\/\/t.co\/a0ZKHUGbTl",
  "id" : 580743039032799233,
  "created_at" : "2015-03-25 14:48:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 111, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580742721939247104",
  "text" : "RT @WHLive: \"This law means that you can no longer be charged more or denied coverage. Ever.\" \u2014President Obama #BetterWithObamacare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BetterWithObamacare",
        "indices" : [ 99, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580742696647540736",
    "text" : "\"This law means that you can no longer be charged more or denied coverage. Ever.\" \u2014President Obama #BetterWithObamacare",
    "id" : 580742696647540736,
    "created_at" : "2015-03-25 14:47:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 580742721939247104,
  "created_at" : "2015-03-25 14:47:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 94, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580742604754567168",
  "text" : "\"It\u2019s working better than many of us, including me, anticipated.\" \u2014President Obama on the ACA #BetterWithObamacare",
  "id" : 580742604754567168,
  "created_at" : "2015-03-25 14:46:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580742489918693376\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/qkQFRey5iQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA82HmbUMAEorOG.jpg",
      "id_str" : "580742381156184065",
      "id" : 580742381156184065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA82HmbUMAEorOG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qkQFRey5iQ"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 87, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580742489918693376",
  "text" : "\"It\u2019s making health coverage more affordable and more effective for all of us.\" \u2014Obama #BetterWithObamacare http:\/\/t.co\/qkQFRey5iQ",
  "id" : 580742489918693376,
  "created_at" : "2015-03-25 14:46:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 104, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580742299446968320",
  "text" : "\"It\u2019s a major reason we\u2019ve seen 50,000 fewer preventable patient deaths in hospitals.\" \u2014President Obama #BetterWithObamacare",
  "id" : 580742299446968320,
  "created_at" : "2015-03-25 14:45:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 120, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580741995800334336",
  "text" : "\"Just 5 years in\u2014the Affordable Care Act has already helped improve the quality of health care across the board\" \u2014Obama #BetterWithObamacare",
  "id" : 580741995800334336,
  "created_at" : "2015-03-25 14:44:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 107, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/9DwVTZyDqz",
      "expanded_url" : "http:\/\/go.wh.gov\/WumhqH",
      "display_url" : "go.wh.gov\/WumhqH"
    } ]
  },
  "geo" : { },
  "id_str" : "580741610952085504",
  "text" : "RT @WHLive: Happening now: Watch President Obama speak on the Affordable Care Act \u2192 http:\/\/t.co\/9DwVTZyDqz #BetterWithObamacare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BetterWithObamacare",
        "indices" : [ 95, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/9DwVTZyDqz",
        "expanded_url" : "http:\/\/go.wh.gov\/WumhqH",
        "display_url" : "go.wh.gov\/WumhqH"
      } ]
    },
    "geo" : { },
    "id_str" : "580741583609298945",
    "text" : "Happening now: Watch President Obama speak on the Affordable Care Act \u2192 http:\/\/t.co\/9DwVTZyDqz #BetterWithObamacare",
    "id" : 580741583609298945,
    "created_at" : "2015-03-25 14:42:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 580741610952085504,
  "created_at" : "2015-03-25 14:42:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580736868234477568\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/a8hm1NL5CG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA8xEExUgAA4xxH.jpg",
      "id_str" : "580736823023927296",
      "id" : 580736823023927296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA8xEExUgAA4xxH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/a8hm1NL5CG"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 94, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/PsEaTINbbW",
      "expanded_url" : "http:\/\/go.wh.gov\/WumhqH",
      "display_url" : "go.wh.gov\/WumhqH"
    } ]
  },
  "geo" : { },
  "id_str" : "580736868234477568",
  "text" : "Watch President Obama speak at 10:30am ET on the Affordable Care Act \u2192 http:\/\/t.co\/PsEaTINbbW #BetterWithObamacare http:\/\/t.co\/a8hm1NL5CG",
  "id" : 580736868234477568,
  "created_at" : "2015-03-25 14:23:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/neS4zI8PGo",
      "expanded_url" : "https:\/\/youtu.be\/jGQFdad__OU",
      "display_url" : "youtu.be\/jGQFdad__OU"
    } ]
  },
  "geo" : { },
  "id_str" : "580729713712238592",
  "text" : "\"On the 5-year anniversary of the Affordable Care Act, one thing couldn\u2019t be clearer: This law is working\" \u2014Obama: https:\/\/t.co\/neS4zI8PGo",
  "id" : 580729713712238592,
  "created_at" : "2015-03-25 13:55:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/580515863675211776\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/l8XRMcaFDL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA5oGXLWoAEofBg.jpg",
      "id_str" : "580515860487512065",
      "id" : 580515860487512065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA5oGXLWoAEofBg.jpg",
      "sizes" : [ {
        "h" : 762,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 762,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/l8XRMcaFDL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580516134685974529",
  "text" : "RT @petesouza: President Obama and President Ghani of Afghanistan today on the WH colonnade. http:\/\/t.co\/l8XRMcaFDL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/580515863675211776\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/l8XRMcaFDL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CA5oGXLWoAEofBg.jpg",
        "id_str" : "580515860487512065",
        "id" : 580515860487512065,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA5oGXLWoAEofBg.jpg",
        "sizes" : [ {
          "h" : 762,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 762,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/l8XRMcaFDL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580515863675211776",
    "text" : "President Obama and President Ghani of Afghanistan today on the WH colonnade. http:\/\/t.co\/l8XRMcaFDL",
    "id" : 580515863675211776,
    "created_at" : "2015-03-24 23:45:42 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 580516134685974529,
  "created_at" : "2015-03-24 23:46:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 11, 22 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580486543711866882",
  "text" : "RT @vj44: .@WhiteHouse checked in w\/ Marcelas who has grown up since this photo was taken. Proud of the young man he has become http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/580484621068058624\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/E9R7YAXLFM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CA5Lr-uWYAA8_d8.jpg",
        "id_str" : "580484620921233408",
        "id" : 580484620921233408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA5Lr-uWYAA8_d8.jpg",
        "sizes" : [ {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 787,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/E9R7YAXLFM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "418486228959244288",
    "geo" : { },
    "id_str" : "580484621068058624",
    "in_reply_to_user_id" : 30313925,
    "text" : ".@WhiteHouse checked in w\/ Marcelas who has grown up since this photo was taken. Proud of the young man he has become http:\/\/t.co\/E9R7YAXLFM",
    "id" : 580484621068058624,
    "in_reply_to_status_id" : 418486228959244288,
    "created_at" : "2015-03-24 21:41:33 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 580486543711866882,
  "created_at" : "2015-03-24 21:49:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikhil Basu Trivedi",
      "screen_name" : "nbt",
      "indices" : [ 3, 7 ],
      "id_str" : "24486938",
      "id" : 24486938
    }, {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 37, 45 ],
      "id_str" : "291",
      "id" : 291
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 50, 61 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialcivics",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580472562293084160",
  "text" : "RT @nbt: If I could pick 1 issue for @goldman and @WhiteHouse to work on to make America better: Immigration. #socialcivics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Goldman",
        "screen_name" : "goldman",
        "indices" : [ 28, 36 ],
        "id_str" : "291",
        "id" : 291
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 41, 52 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "socialcivics",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580441723643564032",
    "text" : "If I could pick 1 issue for @goldman and @WhiteHouse to work on to make America better: Immigration. #socialcivics",
    "id" : 580441723643564032,
    "created_at" : "2015-03-24 18:51:05 +0000",
    "user" : {
      "name" : "Nikhil Basu Trivedi",
      "screen_name" : "nbt",
      "protected" : false,
      "id_str" : "24486938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/709621493299216384\/D4bcjvjq_normal.jpg",
      "id" : 24486938,
      "verified" : false
    }
  },
  "id" : 580472562293084160,
  "created_at" : "2015-03-24 20:53:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/rlLXRXzRaH",
      "expanded_url" : "http:\/\/wh.gov\/iWorm",
      "display_url" : "wh.gov\/iWorm"
    }, {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/BOZtifz5Om",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=PF5c8JzJGeA",
      "display_url" : "youtube.com\/watch?v=PF5c8J\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580468968126836737",
  "text" : "RT @whitehouseostp: Highlights from the 2015 #WHScienceFair \u2192 http:\/\/t.co\/rlLXRXzRaH, https:\/\/t.co\/BOZtifz5Om",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 25, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/rlLXRXzRaH",
        "expanded_url" : "http:\/\/wh.gov\/iWorm",
        "display_url" : "wh.gov\/iWorm"
      }, {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/BOZtifz5Om",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=PF5c8JzJGeA",
        "display_url" : "youtube.com\/watch?v=PF5c8J\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580456636487213056",
    "text" : "Highlights from the 2015 #WHScienceFair \u2192 http:\/\/t.co\/rlLXRXzRaH, https:\/\/t.co\/BOZtifz5Om",
    "id" : 580456636487213056,
    "created_at" : "2015-03-24 19:50:21 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 580468968126836737,
  "created_at" : "2015-03-24 20:39:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580456207531421696",
  "text" : "RT @Brundage44: new state by state data shows harmful consequences of the Republican budget on middle class families - here https:\/\/t.co\/ak\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/ak6Ixz2UQX",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/03\/24\/map-consequences-republican-budget",
        "display_url" : "whitehouse.gov\/blog\/2015\/03\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580432447998980101",
    "text" : "new state by state data shows harmful consequences of the Republican budget on middle class families - here https:\/\/t.co\/ak6Ixz2UQX",
    "id" : 580432447998980101,
    "created_at" : "2015-03-24 18:14:14 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 580456207531421696,
  "created_at" : "2015-03-24 19:48:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580446557738307584",
  "text" : "\u201CIf there\u2019s an agreement it\u2019s going to be a good agreement that\u2019s good for America\u2019s security &amp; Israel\u2019s security\u201D \u2014Obama on talks with Iran",
  "id" : 580446557738307584,
  "created_at" : "2015-03-24 19:10:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580442774631251968",
  "text" : "\"We want to make sure we\u2019re doing everything we can to help Afghan security forces succeed, so we don\u2019t have to go back.\" \u2014President Obama",
  "id" : 580442774631251968,
  "created_at" : "2015-03-24 18:55:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/pcidJq7u2f",
      "expanded_url" : "http:\/\/snpy.tv\/1BKXXiq",
      "display_url" : "snpy.tv\/1BKXXiq"
    } ]
  },
  "geo" : { },
  "id_str" : "580441697492041730",
  "text" : "Watch President Obama's statement on the tragic plane crash in France. http:\/\/t.co\/pcidJq7u2f",
  "id" : 580441697492041730,
  "created_at" : "2015-03-24 18:50:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580439160961499137",
  "text" : "\"America will continue to be your partner in advancing the rights and dignity of all Afghans, including women and girls.\" \u2014Obama to Ghani",
  "id" : 580439160961499137,
  "created_at" : "2015-03-24 18:40:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580438364719042560",
  "text" : "RT @WHLive: \"We will maintain our current posture of 9,800 troops through the end of this year.\" \u2014President Obama on Afghanistan",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580438337351208960",
    "text" : "\"We will maintain our current posture of 9,800 troops through the end of this year.\" \u2014President Obama on Afghanistan",
    "id" : 580438337351208960,
    "created_at" : "2015-03-24 18:37:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 580438364719042560,
  "created_at" : "2015-03-24 18:37:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580438182069735424",
  "text" : "RT @WHLive: \"As part of the ongoing NATO mission, the United States will continue to train, advise and assist Afghan security forces.\" \u2014Pre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580438093863456768",
    "text" : "\"As part of the ongoing NATO mission, the United States will continue to train, advise and assist Afghan security forces.\" \u2014President Obama",
    "id" : 580438093863456768,
    "created_at" : "2015-03-24 18:36:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 580438182069735424,
  "created_at" : "2015-03-24 18:37:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580437547245047809",
  "text" : "\"On December 31st, after more than 13 years, America\u2019s combat mission in Afghanistan came to a responsible end.\" \u2014President Obama",
  "id" : 580437547245047809,
  "created_at" : "2015-03-24 18:34:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580437278016819200",
  "text" : "RT @WHLive: \"It is a great pleasure to welcome President Ghani to the White House.\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580437240695898113",
    "text" : "\"It is a great pleasure to welcome President Ghani to the White House.\" \u2014President Obama",
    "id" : 580437240695898113,
    "created_at" : "2015-03-24 18:33:16 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 580437278016819200,
  "created_at" : "2015-03-24 18:33:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580437138631733248",
  "text" : "\"It\u2019s particularly heartbreaking because it apparently includes the loss of so many children.\" \u2014Obama on the tragic plane crash in France",
  "id" : 580437138631733248,
  "created_at" : "2015-03-24 18:32:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580437043878215680",
  "text" : "\"Our thoughts &amp; prayers are with our friends in Europe, especially the people of Germany &amp; Spain\" \u2014Obama on the tragic plane crash in France",
  "id" : 580437043878215680,
  "created_at" : "2015-03-24 18:32:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/eWDehNzo6l",
      "expanded_url" : "http:\/\/go.wh.gov\/4QwAun",
      "display_url" : "go.wh.gov\/4QwAun"
    } ]
  },
  "geo" : { },
  "id_str" : "580436918401441792",
  "text" : "Watch live: President Obama holds a press conference with President Ghani of Afghanistan \u2192 http:\/\/t.co\/eWDehNzo6l",
  "id" : 580436918401441792,
  "created_at" : "2015-03-24 18:32:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bianca L. St.Louis",
      "screen_name" : "beLaurie",
      "indices" : [ 3, 12 ],
      "id_str" : "92143477",
      "id" : 92143477
    }, {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 14, 22 ],
      "id_str" : "291",
      "id" : 291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "socialcivics",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580426976340656128",
  "text" : "RT @beLaurie: @goldman congrats on new role! hope to see the WH use digital to reach the underserved and amplify their voices. #socialcivics",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Goldman",
        "screen_name" : "goldman",
        "indices" : [ 0, 8 ],
        "id_str" : "291",
        "id" : 291
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "socialcivics",
        "indices" : [ 113, 126 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "580401285515456512",
    "geo" : { },
    "id_str" : "580424244150083584",
    "in_reply_to_user_id" : 291,
    "text" : "@goldman congrats on new role! hope to see the WH use digital to reach the underserved and amplify their voices. #socialcivics",
    "id" : 580424244150083584,
    "in_reply_to_status_id" : 580401285515456512,
    "created_at" : "2015-03-24 17:41:38 +0000",
    "in_reply_to_screen_name" : "goldman",
    "in_reply_to_user_id_str" : "291",
    "user" : {
      "name" : "Bianca L. St.Louis",
      "screen_name" : "beLaurie",
      "protected" : false,
      "id_str" : "92143477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710333097326186496\/QcsTSTn0_normal.jpg",
      "id" : 92143477,
      "verified" : false
    }
  },
  "id" : 580426976340656128,
  "created_at" : "2015-03-24 17:52:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna Utgoff",
      "screen_name" : "autgoff",
      "indices" : [ 3, 11 ],
      "id_str" : "773083",
      "id" : 773083
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580419700275970048",
  "text" : "RT @autgoff: Would love to see the internet used to tell success stories of govt spending in ed, especially stories told by students. #soci\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "socialcivics",
        "indices" : [ 121, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580415882163261441",
    "text" : "Would love to see the internet used to tell success stories of govt spending in ed, especially stories told by students. #socialcivics",
    "id" : 580415882163261441,
    "created_at" : "2015-03-24 17:08:24 +0000",
    "user" : {
      "name" : "Anna Utgoff",
      "screen_name" : "autgoff",
      "protected" : false,
      "id_str" : "773083",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/340369602\/watermellonj_normal.jpg",
      "id" : 773083,
      "verified" : false
    }
  },
  "id" : 580419700275970048,
  "created_at" : "2015-03-24 17:23:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "indices" : [ 3, 11 ],
      "id_str" : "291",
      "id" : 291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/VG3IdEmdwp",
      "expanded_url" : "http:\/\/www.politico.com\/story\/2015\/03\/barack-obama-names-two-new-top-aides-116349.html?hp=lc2_4",
      "display_url" : "politico.com\/story\/2015\/03\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580405505266442240",
  "text" : "RT @goldman: Today I'm excited and honored to announce that I am joining the White House as Chief Digital Officer. http:\/\/t.co\/VG3IdEmdwp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/VG3IdEmdwp",
        "expanded_url" : "http:\/\/www.politico.com\/story\/2015\/03\/barack-obama-names-two-new-top-aides-116349.html?hp=lc2_4",
        "display_url" : "politico.com\/story\/2015\/03\/\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "580400569975635968",
    "geo" : { },
    "id_str" : "580401027234467840",
    "in_reply_to_user_id" : 291,
    "text" : "Today I'm excited and honored to announce that I am joining the White House as Chief Digital Officer. http:\/\/t.co\/VG3IdEmdwp",
    "id" : 580401027234467840,
    "in_reply_to_status_id" : 580400569975635968,
    "created_at" : "2015-03-24 16:09:22 +0000",
    "in_reply_to_screen_name" : "goldman",
    "in_reply_to_user_id_str" : "291",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "goldman",
      "protected" : false,
      "id_str" : "291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/594270111781023744\/FZYZhFBQ_normal.jpg",
      "id" : 291,
      "verified" : false
    }
  },
  "id" : 580405505266442240,
  "created_at" : "2015-03-24 16:27:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arianna Huffington",
      "screen_name" : "ariannahuff",
      "indices" : [ 3, 15 ],
      "id_str" : "21982720",
      "id" : 21982720
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HuffPostPol\/status\/580103249371500545\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/F3gTcXaqZW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAzw1OMWUAEn4VD.jpg",
      "id_str" : "580103249157574657",
      "id" : 580103249157574657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAzw1OMWUAEn4VD.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/F3gTcXaqZW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/khUw5XKkh6",
      "expanded_url" : "http:\/\/huff.to\/1N27oCB",
      "display_url" : "huff.to\/1N27oCB"
    } ]
  },
  "geo" : { },
  "id_str" : "580400651408171008",
  "text" : "RT @ariannahuff: Obama to young scientists: \"Keep asking why\" http:\/\/t.co\/khUw5XKkh6 http:\/\/t.co\/F3gTcXaqZW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HuffPostPol\/status\/580103249371500545\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/F3gTcXaqZW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAzw1OMWUAEn4VD.jpg",
        "id_str" : "580103249157574657",
        "id" : 580103249157574657,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAzw1OMWUAEn4VD.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/F3gTcXaqZW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/khUw5XKkh6",
        "expanded_url" : "http:\/\/huff.to\/1N27oCB",
        "display_url" : "huff.to\/1N27oCB"
      } ]
    },
    "geo" : { },
    "id_str" : "580397535031853056",
    "text" : "Obama to young scientists: \"Keep asking why\" http:\/\/t.co\/khUw5XKkh6 http:\/\/t.co\/F3gTcXaqZW",
    "id" : 580397535031853056,
    "created_at" : "2015-03-24 15:55:30 +0000",
    "user" : {
      "name" : "Arianna Huffington",
      "screen_name" : "ariannahuff",
      "protected" : false,
      "id_str" : "21982720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765947806582468608\/Ywa0eYRp_normal.jpg",
      "id" : 21982720,
      "verified" : true
    }
  },
  "id" : 580400651408171008,
  "created_at" : "2015-03-24 16:07:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Victor Cruz",
      "screen_name" : "TeamVic",
      "indices" : [ 93, 101 ],
      "id_str" : "19548850",
      "id" : 19548850
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 42, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/mOpC5wf65S",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/03\/23\/incredible-kid-ingenuity-display-5th-white-house-science-fair",
      "display_url" : "whitehouse.gov\/blog\/2015\/03\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580387204507156480",
  "text" : "RT @VP: What you might have missed at the #WHScienceFair \u2192 VP met w\/ students, teachers, and @TeamVic https:\/\/t.co\/mOpC5wf65S http:\/\/t.co\/7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Victor Cruz",
        "screen_name" : "TeamVic",
        "indices" : [ 85, 93 ],
        "id_str" : "19548850",
        "id" : 19548850
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/580381229616254976\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/7O4GXpH8uz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CA3tpwLUkAA2CQZ.jpg",
        "id_str" : "580381228563468288",
        "id" : 580381228563468288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA3tpwLUkAA2CQZ.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7O4GXpH8uz"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 34, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/mOpC5wf65S",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/03\/23\/incredible-kid-ingenuity-display-5th-white-house-science-fair",
        "display_url" : "whitehouse.gov\/blog\/2015\/03\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580381229616254976",
    "text" : "What you might have missed at the #WHScienceFair \u2192 VP met w\/ students, teachers, and @TeamVic https:\/\/t.co\/mOpC5wf65S http:\/\/t.co\/7O4GXpH8uz",
    "id" : 580381229616254976,
    "created_at" : "2015-03-24 14:50:42 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 580387204507156480,
  "created_at" : "2015-03-24 15:14:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580366431667122176\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/tKtGNaSEK8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA3f_3nUYAAPSCu.jpg",
      "id_str" : "580366215354277888",
      "id" : 580366215354277888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA3f_3nUYAAPSCu.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tKtGNaSEK8"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 85, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580366431667122176",
  "text" : "76 million Americans are benefiting from preventive care coverage thanks to the ACA. #BetterWithObamacare http:\/\/t.co\/tKtGNaSEK8",
  "id" : 580366431667122176,
  "created_at" : "2015-03-24 13:51:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/580157304676311040\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/H02JWWVy38",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA0aqx0UgAAywYq.jpg",
      "id_str" : "580149249230274560",
      "id" : 580149249230274560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA0aqx0UgAAywYq.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/H02JWWVy38"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/h8h3EKfYki",
      "expanded_url" : "http:\/\/wh.gov\/science-fair",
      "display_url" : "wh.gov\/science-fair"
    } ]
  },
  "geo" : { },
  "id_str" : "580157304676311040",
  "text" : "Keep exploring.\nKeep dreaming.\nKeep asking why.\nDon\u2019t settle for what you already know.\nhttp:\/\/t.co\/h8h3EKfYki http:\/\/t.co\/H02JWWVy38",
  "id" : 580157304676311040,
  "created_at" : "2015-03-24 00:00:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580146443618516992\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/9Lfjfo7xPB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA0Xk8hUYAAu0VG.jpg",
      "id_str" : "580145850489266176",
      "id" : 580145850489266176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA0Xk8hUYAAu0VG.jpg",
      "sizes" : [ {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1189,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 812,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9Lfjfo7xPB"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 47, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/h8h3EKxzIS",
      "expanded_url" : "http:\/\/wh.gov\/science-fair",
      "display_url" : "wh.gov\/science-fair"
    } ]
  },
  "geo" : { },
  "id_str" : "580146443618516992",
  "text" : "Girls change the world: http:\/\/t.co\/h8h3EKxzIS #WHScienceFair http:\/\/t.co\/9Lfjfo7xPB",
  "id" : 580146443618516992,
  "created_at" : "2015-03-23 23:17:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580141339293040640\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/irVhesNAY8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CA0QrOxUsAE3k0a.jpg",
      "id_str" : "580138261886054401",
      "id" : 580138261886054401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CA0QrOxUsAE3k0a.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/irVhesNAY8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/BtiivUeZzZ",
      "expanded_url" : "http:\/\/go.wh.gov\/w9yd5r",
      "display_url" : "go.wh.gov\/w9yd5r"
    } ]
  },
  "geo" : { },
  "id_str" : "580141339293040640",
  "text" : "RT if you agree: Every student should be able to access the world's information \u2192 http:\/\/t.co\/BtiivUeZzZ http:\/\/t.co\/irVhesNAY8",
  "id" : 580141339293040640,
  "created_at" : "2015-03-23 22:57:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 116, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/neS4zI8PGo",
      "expanded_url" : "https:\/\/youtu.be\/jGQFdad__OU",
      "display_url" : "youtu.be\/jGQFdad__OU"
    } ]
  },
  "geo" : { },
  "id_str" : "580129778369318912",
  "text" : "Up to 129 million Americans can no longer be denied coverage for a pre-existing condition \u2192 https:\/\/t.co\/neS4zI8PGo #BetterWithObamacare",
  "id" : 580129778369318912,
  "created_at" : "2015-03-23 22:11:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580087258532966402\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/0hy163WyP2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAziPf1UsAA9wFU.jpg",
      "id_str" : "580087207895019520",
      "id" : 580087207895019520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAziPf1UsAA9wFU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0hy163WyP2"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 78, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580087258532966402",
  "text" : "America's uninsured rate has gone down by about one-third since October 2013. #BetterWithObamacare http:\/\/t.co\/0hy163WyP2",
  "id" : 580087258532966402,
  "created_at" : "2015-03-23 19:22:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580079223299178496\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/K2ot7Pp3l9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAza5b4UgAAtjeZ.jpg",
      "id_str" : "580079132295331840",
      "id" : 580079132295331840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAza5b4UgAAtjeZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/K2ot7Pp3l9"
    } ],
    "hashtags" : [ {
      "text" : "SelectUSA",
      "indices" : [ 94, 104 ]
    }, {
      "text" : "LeadOnTrade",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580079223299178496",
  "text" : "\"We can work together on bipartisan\u2026new trade deals...that aren\u2019t just free, but fair\" \u2014Obama #SelectUSA #LeadOnTrade http:\/\/t.co\/K2ot7Pp3l9",
  "id" : 580079223299178496,
  "created_at" : "2015-03-23 18:50:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/580078178665938944\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/z461GwS5I1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAzaBmcUcAEwe3A.jpg",
      "id_str" : "580078173058002945",
      "id" : 580078173058002945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAzaBmcUcAEwe3A.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/z461GwS5I1"
    } ],
    "hashtags" : [ {
      "text" : "SelectUSA",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580078212044050432",
  "text" : "RT @WHLive: \"Our deficits have shrunk significantly.\" \u2014President Obama #SelectUSA http:\/\/t.co\/z461GwS5I1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/580078178665938944\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/z461GwS5I1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAzaBmcUcAEwe3A.jpg",
        "id_str" : "580078173058002945",
        "id" : 580078173058002945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAzaBmcUcAEwe3A.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/z461GwS5I1"
      } ],
      "hashtags" : [ {
        "text" : "SelectUSA",
        "indices" : [ 59, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580078178665938944",
    "text" : "\"Our deficits have shrunk significantly.\" \u2014President Obama #SelectUSA http:\/\/t.co\/z461GwS5I1",
    "id" : 580078178665938944,
    "created_at" : "2015-03-23 18:46:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 580078212044050432,
  "created_at" : "2015-03-23 18:46:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/580077772552318976\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/CJHOzwy9WS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAzZpH_UgAA8oeN.jpg",
      "id_str" : "580077752566448128",
      "id" : 580077752566448128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAzZpH_UgAA8oeN.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/CJHOzwy9WS"
    } ],
    "hashtags" : [ {
      "text" : "SelectUSA",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580077807910309888",
  "text" : "RT @WHLive: \"Our high school graduation rate is now at an all-time high.\" \u2014President Obama #SelectUSA http:\/\/t.co\/CJHOzwy9WS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/580077772552318976\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/CJHOzwy9WS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAzZpH_UgAA8oeN.jpg",
        "id_str" : "580077752566448128",
        "id" : 580077752566448128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAzZpH_UgAA8oeN.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/CJHOzwy9WS"
      } ],
      "hashtags" : [ {
        "text" : "SelectUSA",
        "indices" : [ 79, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580077772552318976",
    "text" : "\"Our high school graduation rate is now at an all-time high.\" \u2014President Obama #SelectUSA http:\/\/t.co\/CJHOzwy9WS",
    "id" : 580077772552318976,
    "created_at" : "2015-03-23 18:44:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 580077807910309888,
  "created_at" : "2015-03-23 18:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580077323988275201\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/zU0goXMxlM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAzZOxdUkAEEDQK.jpg",
      "id_str" : "580077299841667073",
      "id" : 580077299841667073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAzZOxdUkAEEDQK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zU0goXMxlM"
    } ],
    "hashtags" : [ {
      "text" : "SelectUSA",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580077323988275201",
  "text" : "\"After a decade of outsourcing, we\u2019re starting to bring back good jobs to America.\" \u2014President Obama #SelectUSA http:\/\/t.co\/zU0goXMxlM",
  "id" : 580077323988275201,
  "created_at" : "2015-03-23 18:43:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/580077079993024512\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Vccg9MT4oK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAzY-NFUMAAtV8u.jpg",
      "id_str" : "580077015199395840",
      "id" : 580077015199395840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAzY-NFUMAAtV8u.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Vccg9MT4oK"
    } ],
    "hashtags" : [ {
      "text" : "SelectUSA",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580077079993024512",
  "text" : "\"America is now in the midst of the longest streak of private-sector job growth on record.\" \u2014Obama #SelectUSA http:\/\/t.co\/Vccg9MT4oK",
  "id" : 580077079993024512,
  "created_at" : "2015-03-23 18:42:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SelectUSA",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/pQNZZa7ppD",
      "expanded_url" : "http:\/\/go.wh.gov\/Select-USA",
      "display_url" : "go.wh.gov\/Select-USA"
    } ]
  },
  "geo" : { },
  "id_str" : "580076537984106497",
  "text" : "Happening now: Watch President Obama speak at the #SelectUSA Summit \u2192 http:\/\/t.co\/pQNZZa7ppD",
  "id" : 580076537984106497,
  "created_at" : "2015-03-23 18:39:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAisworking",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580066827331452928",
  "text" : "RT @NancyPelosi: Thanks to the Affordable Care Act, being a woman is no longer a pre-existing condition. #ACAisworking http:\/\/t.co\/XoRFwRAa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/580063446236078082\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/XoRFwRAaQX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAzMoWBU0AAcKr-.jpg",
        "id_str" : "580063445501923328",
        "id" : 580063445501923328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAzMoWBU0AAcKr-.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/XoRFwRAaQX"
      } ],
      "hashtags" : [ {
        "text" : "ACAisworking",
        "indices" : [ 88, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580063446236078082",
    "text" : "Thanks to the Affordable Care Act, being a woman is no longer a pre-existing condition. #ACAisworking http:\/\/t.co\/XoRFwRAaQX",
    "id" : 580063446236078082,
    "created_at" : "2015-03-23 17:47:57 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 580066827331452928,
  "created_at" : "2015-03-23 18:01:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBiden",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/ZpKeRNs08t",
      "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/031915-being-biden-aca-5-year-1-2",
      "display_url" : "soundcloud.com\/whitehouse\/031\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580063121865314304",
  "text" : "RT @VP: \"Let me tell you about this picture.\" -VP #BeingBiden on the 5 yrs of the Affordable Care Act https:\/\/t.co\/ZpKeRNs08t http:\/\/t.co\/w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/580061769516736512\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/wkcnrGeLAl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAzLGkFUsAAeUfS.jpg",
        "id_str" : "580061765649608704",
        "id" : 580061765649608704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAzLGkFUsAAeUfS.jpg",
        "sizes" : [ {
          "h" : 534,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 534,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/wkcnrGeLAl"
      } ],
      "hashtags" : [ {
        "text" : "BeingBiden",
        "indices" : [ 42, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/ZpKeRNs08t",
        "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/031915-being-biden-aca-5-year-1-2",
        "display_url" : "soundcloud.com\/whitehouse\/031\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "580061769516736512",
    "text" : "\"Let me tell you about this picture.\" -VP #BeingBiden on the 5 yrs of the Affordable Care Act https:\/\/t.co\/ZpKeRNs08t http:\/\/t.co\/wkcnrGeLAl",
    "id" : 580061769516736512,
    "created_at" : "2015-03-23 17:41:17 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 580063121865314304,
  "created_at" : "2015-03-23 17:46:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580045514848112640",
  "text" : "\"Science is for all of us. And we want our classrooms and labs and workplaces and media to reflect that.\" \u2014President Obama #WHScienceFair",
  "id" : 580045514848112640,
  "created_at" : "2015-03-23 16:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580045152414121986",
  "text" : "\"We don\u2019t just want to increase the number of American students in STEM\u2026we want to increase the diversity students\" \u2014Obama #WHScienceFair",
  "id" : 580045152414121986,
  "created_at" : "2015-03-23 16:35:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580044450614886400",
  "text" : "\"No young person in America should miss out on the chance to excel in these fields just because they don\u2019t have the resources.\" \u2014Obama #STEM",
  "id" : 580044450614886400,
  "created_at" : "2015-03-23 16:32:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580044074310221824",
  "text" : "\"Today, I can announce that we have achieved that goal.\" \u2014Obama on providing 98% of Americans with access to high-speed wireless internet",
  "id" : 580044074310221824,
  "created_at" : "2015-03-23 16:30:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 109, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580043984761917440",
  "text" : "\"America is going to be stronger, smarter...and a much more interesting place because of you.\" \u2014Obama to the #WHScienceFair exhibitors",
  "id" : 580043984761917440,
  "created_at" : "2015-03-23 16:30:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580041772279078912",
  "text" : "\"We\u2019ve got to celebrate the winners of our science fairs as much as the winners of football or basketball\" \u2014President Obama #WHScienceFair",
  "id" : 580041772279078912,
  "created_at" : "2015-03-23 16:21:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580040997205217280",
  "text" : "\"That\u2019s why we love science: It\u2019s more than a school subject, or the periodic table...it is an approach to the world.\" \u2014Obama #WHScienceFair",
  "id" : 580040997205217280,
  "created_at" : "2015-03-23 16:18:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580040878091210752",
  "text" : "\"There\u2019s always more to learn, to try, to imagine\u2014and\u2026it\u2019s never too early, or too late, to create or discover something new.\" \u2014Obama",
  "id" : 580040878091210752,
  "created_at" : "2015-03-23 16:18:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580040373449277441\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/S47uMq3jgv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAy3kmCVEAAgAU4.jpg",
      "id_str" : "580040291337441280",
      "id" : 580040291337441280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAy3kmCVEAAgAU4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/S47uMq3jgv"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 50, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/h8h3EKfYki",
      "expanded_url" : "http:\/\/wh.gov\/science-fair",
      "display_url" : "wh.gov\/science-fair"
    } ]
  },
  "geo" : { },
  "id_str" : "580040373449277441",
  "text" : "Happening now: Watch President Obama speak at the #WHScienceFair \u2192 http:\/\/t.co\/h8h3EKfYki http:\/\/t.co\/S47uMq3jgv",
  "id" : 580040373449277441,
  "created_at" : "2015-03-23 16:16:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580035147627548672\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/nI4vPTUKMB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAyy1_HUsAAjF-b.png",
      "id_str" : "580035092568911872",
      "id" : 580035092568911872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAyy1_HUsAAjF-b.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 943
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 943
      } ],
      "display_url" : "pic.twitter.com\/nI4vPTUKMB"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580035147627548672",
  "text" : "President Obama checks out a battery-powered page turner from the \u201CSupergirls\u201D Lego League Team. #WHScienceFair http:\/\/t.co\/nI4vPTUKMB",
  "id" : 580035147627548672,
  "created_at" : "2015-03-23 15:55:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalPuppyDay",
      "indices" : [ 6, 23 ]
    }, {
      "text" : "WHScienceFair",
      "indices" : [ 30, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/h8h3EKfYki",
      "expanded_url" : "http:\/\/wh.gov\/science-fair",
      "display_url" : "wh.gov\/science-fair"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/WQFMyeKMVu",
      "expanded_url" : "https:\/\/vine.co\/v\/OY9iHiDg51x",
      "display_url" : "vine.co\/v\/OY9iHiDg51x"
    } ]
  },
  "geo" : { },
  "id_str" : "580029345118363648",
  "text" : "Happy #NationalPuppyDay!\nThis #WHScienceFair pup is celebrating with 3D-printed paws \u2192 http:\/\/t.co\/h8h3EKfYki \uD83D\uDC36 https:\/\/t.co\/WQFMyeKMVu",
  "id" : 580029345118363648,
  "created_at" : "2015-03-23 15:32:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580026624600592384\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/2cpPKh9dbr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAyrDzLUQAA9k9j.png",
      "id_str" : "580026533789581312",
      "id" : 580026533789581312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAyrDzLUQAA9k9j.png",
      "sizes" : [ {
        "h" : 526,
        "resize" : "fit",
        "w" : 943
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 943
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2cpPKh9dbr"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 46, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/h8h3EKxzIS",
      "expanded_url" : "http:\/\/wh.gov\/science-fair",
      "display_url" : "wh.gov\/science-fair"
    } ]
  },
  "geo" : { },
  "id_str" : "580026624600592384",
  "text" : "Watch live: President Obama tours this year's #WHScienceFair projects \u2192 http:\/\/t.co\/h8h3EKxzIS http:\/\/t.co\/2cpPKh9dbr",
  "id" : 580026624600592384,
  "created_at" : "2015-03-23 15:21:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 30, 41 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 42, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/t1WKCvivVS",
      "expanded_url" : "http:\/\/1.usa.gov\/1N0KFa1",
      "display_url" : "1.usa.gov\/1N0KFa1"
    } ]
  },
  "geo" : { },
  "id_str" : "580025255932088321",
  "text" : "RT @NASA: Admin. Bolden is at @WhiteHouse #WHScienceFair &amp; so is a student experiment flown in space! http:\/\/t.co\/t1WKCvivVS http:\/\/t.co\/gk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 20, 31 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/580010986561748992\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/gkdzEh9wHc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAycKoGUQAE0vow.jpg",
        "id_str" : "580010158400487425",
        "id" : 580010158400487425,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAycKoGUQAE0vow.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 976
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 307,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 174,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 976
        } ],
        "display_url" : "pic.twitter.com\/gkdzEh9wHc"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 32, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/t1WKCvivVS",
        "expanded_url" : "http:\/\/1.usa.gov\/1N0KFa1",
        "display_url" : "1.usa.gov\/1N0KFa1"
      } ]
    },
    "geo" : { },
    "id_str" : "580010986561748992",
    "text" : "Admin. Bolden is at @WhiteHouse #WHScienceFair &amp; so is a student experiment flown in space! http:\/\/t.co\/t1WKCvivVS http:\/\/t.co\/gkdzEh9wHc",
    "id" : 580010986561748992,
    "created_at" : "2015-03-23 14:19:29 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 580025255932088321,
  "created_at" : "2015-03-23 15:16:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 41, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/h8h3EKxzIS",
      "expanded_url" : "http:\/\/wh.gov\/science-fair",
      "display_url" : "wh.gov\/science-fair"
    }, {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/S9ATE4UmBy",
      "expanded_url" : "https:\/\/vine.co\/v\/bPZJTgQPjjP",
      "display_url" : "vine.co\/v\/bPZJTgQPjjP"
    } ]
  },
  "geo" : { },
  "id_str" : "580019339874734080",
  "text" : "Don't miss President Obama's tour of the #WHScienceFair projects at 11:10am ET \u2192 http:\/\/t.co\/h8h3EKxzIS https:\/\/t.co\/S9ATE4UmBy",
  "id" : 580019339874734080,
  "created_at" : "2015-03-23 14:52:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/580002534301020160\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/SdpywMEhoF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAyVKZPWcAEhqPr.jpg",
      "id_str" : "580002457830453249",
      "id" : 580002457830453249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAyVKZPWcAEhqPr.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SdpywMEhoF"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 50, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580014159011528704",
  "text" : "RT @whitehouseostp: This pup has 3D-printed paws. #WHScienceFair http:\/\/t.co\/SdpywMEhoF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/580002534301020160\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/SdpywMEhoF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAyVKZPWcAEhqPr.jpg",
        "id_str" : "580002457830453249",
        "id" : 580002457830453249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAyVKZPWcAEhqPr.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/SdpywMEhoF"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 30, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580002534301020160",
    "text" : "This pup has 3D-printed paws. #WHScienceFair http:\/\/t.co\/SdpywMEhoF",
    "id" : 580002534301020160,
    "created_at" : "2015-03-23 13:45:54 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 580014159011528704,
  "created_at" : "2015-03-23 14:32:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "indices" : [ 3, 11 ],
      "id_str" : "37710752",
      "id" : 37710752
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 28, 39 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BillNye\/status\/580006766223704064\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/qm2GMbgMsh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAyZDtFWYAA_MwX.jpg",
      "id_str" : "580006740944642048",
      "id" : 580006740944642048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAyZDtFWYAA_MwX.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qm2GMbgMsh"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 40, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/wnMjxcvvm9",
      "expanded_url" : "http:\/\/whitehouse.gov",
      "display_url" : "whitehouse.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "580012731614380032",
  "text" : "RT @BillNye: Live streaming @WhiteHouse #WHScienceFair http:\/\/t.co\/wnMjxcvvm9 http:\/\/t.co\/qm2GMbgMsh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 15, 26 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BillNye\/status\/580006766223704064\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/qm2GMbgMsh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAyZDtFWYAA_MwX.jpg",
        "id_str" : "580006740944642048",
        "id" : 580006740944642048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAyZDtFWYAA_MwX.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/qm2GMbgMsh"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 27, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/wnMjxcvvm9",
        "expanded_url" : "http:\/\/whitehouse.gov",
        "display_url" : "whitehouse.gov"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.89509844106541, -77.03327978701739 ]
    },
    "id_str" : "580006766223704064",
    "text" : "Live streaming @WhiteHouse #WHScienceFair http:\/\/t.co\/wnMjxcvvm9 http:\/\/t.co\/qm2GMbgMsh",
    "id" : 580006766223704064,
    "created_at" : "2015-03-23 14:02:43 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 580012731614380032,
  "created_at" : "2015-03-23 14:26:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Victor Cruz",
      "screen_name" : "TeamVic",
      "indices" : [ 25, 33 ],
      "id_str" : "19548850",
      "id" : 19548850
    }, {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "indices" : [ 34, 42 ],
      "id_str" : "37710752",
      "id" : 37710752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/GMGxtQ3E66",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/science-fair",
      "display_url" : "whitehouse.gov\/science-fair"
    } ]
  },
  "geo" : { },
  "id_str" : "580009981623332864",
  "text" : "RT @whitehouseostp: Now! @TeamVic @BillNye interview amazing students live from #WHScienceFair: http:\/\/t.co\/GMGxtQ3E66 http:\/\/t.co\/oy0zMgHO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Victor Cruz",
        "screen_name" : "TeamVic",
        "indices" : [ 5, 13 ],
        "id_str" : "19548850",
        "id" : 19548850
      }, {
        "name" : "Bill Nye",
        "screen_name" : "BillNye",
        "indices" : [ 14, 22 ],
        "id_str" : "37710752",
        "id" : 37710752
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/580009722339786752\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/oy0zMgHO1W",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAybutTWYAALFA9.jpg",
        "id_str" : "580009678760992768",
        "id" : 580009678760992768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAybutTWYAALFA9.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oy0zMgHO1W"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 60, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/GMGxtQ3E66",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/science-fair",
        "display_url" : "whitehouse.gov\/science-fair"
      } ]
    },
    "geo" : { },
    "id_str" : "580009722339786752",
    "text" : "Now! @TeamVic @BillNye interview amazing students live from #WHScienceFair: http:\/\/t.co\/GMGxtQ3E66 http:\/\/t.co\/oy0zMgHO1W",
    "id" : 580009722339786752,
    "created_at" : "2015-03-23 14:14:28 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 580009981623332864,
  "created_at" : "2015-03-23 14:15:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/580006557393379329\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/7SKN4WPsXh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAyY2K1VIAEaAMS.jpg",
      "id_str" : "580006508412346369",
      "id" : 580006508412346369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAyY2K1VIAEaAMS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7SKN4WPsXh"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 80, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580006557393379329",
  "text" : "105 million Americans no longer have a lifetime limit on their health coverage. #BetterWithObamacare http:\/\/t.co\/7SKN4WPsXh",
  "id" : 580006557393379329,
  "created_at" : "2015-03-23 14:01:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 115, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/neS4zHReOQ",
      "expanded_url" : "https:\/\/youtu.be\/jGQFdad__OU",
      "display_url" : "youtu.be\/jGQFdad__OU"
    } ]
  },
  "geo" : { },
  "id_str" : "579999491769704448",
  "text" : "5 years ago, we declared that quality, affordable health care is a right, not a privilege: https:\/\/t.co\/neS4zHReOQ #BetterWithObamacare \u2013bo",
  "id" : 579999491769704448,
  "created_at" : "2015-03-23 13:33:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/579791235809824768\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/yDOri1dm2C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAvUzV_UQAAoN7v.jpg",
      "id_str" : "579790955588370432",
      "id" : 579790955588370432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAvUzV_UQAAoN7v.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yDOri1dm2C"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 94, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579791235809824768",
  "text" : "More than 16 million Americans have gained health coverage thanks to the Affordable Care Act. #BetterWithObamacare. http:\/\/t.co\/yDOri1dm2C",
  "id" : 579791235809824768,
  "created_at" : "2015-03-22 23:46:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/579782722358525952\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/3yGio1B5TJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAvNO0NUYAATfHd.jpg",
      "id_str" : "579782631463608320",
      "id" : 579782631463608320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAvNO0NUYAATfHd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3yGio1B5TJ"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 93, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579782722358525952",
  "text" : "FACT: We've seen the largest drop in the uninsured rate in decades since the ACA became law. #BetterWithObamacare http:\/\/t.co\/3yGio1B5TJ",
  "id" : 579782722358525952,
  "created_at" : "2015-03-22 23:12:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 111, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/neS4zHReOQ",
      "expanded_url" : "https:\/\/youtu.be\/jGQFdad__OU",
      "display_url" : "youtu.be\/jGQFdad__OU"
    } ]
  },
  "geo" : { },
  "id_str" : "579776013707689985",
  "text" : "The Affordable Care Act is turning 5: Watch how millions of Americans are benefiting \u2192 https:\/\/t.co\/neS4zHReOQ #BetterWithObamacare",
  "id" : 579776013707689985,
  "created_at" : "2015-03-22 22:45:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/aPpBj58kZ4",
      "expanded_url" : "http:\/\/go.wh.gov\/mjmiic",
      "display_url" : "go.wh.gov\/mjmiic"
    } ]
  },
  "geo" : { },
  "id_str" : "579689086476136448",
  "text" : "\"End the longest confirmation process for an Attorney General in three decades &amp; give Loretta Lynch a vote.\" \u2014Obama: http:\/\/t.co\/aPpBj58kZ4",
  "id" : 579689086476136448,
  "created_at" : "2015-03-22 17:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/579666430557224960\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/WkXqsMUo5X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAtfKAnUYAAwBiL.jpg",
      "id_str" : "579661602615484416",
      "id" : 579661602615484416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAtfKAnUYAAwBiL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/WkXqsMUo5X"
    } ],
    "hashtags" : [ {
      "text" : "WHInstaMeet",
      "indices" : [ 59, 71 ]
    }, {
      "text" : "WWIM11",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/SE5jrE5oKR",
      "expanded_url" : "http:\/\/go.wh.gov\/8YJu8h",
      "display_url" : "go.wh.gov\/8YJu8h"
    } ]
  },
  "geo" : { },
  "id_str" : "579666430557224960",
  "text" : "Filter your way around the White House with a recap of the #WHInstaMeet \u2192 http:\/\/t.co\/SE5jrE5oKR #WWIM11 http:\/\/t.co\/WkXqsMUo5X",
  "id" : 579666430557224960,
  "created_at" : "2015-03-22 15:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/aPpBj4QK7w",
      "expanded_url" : "http:\/\/go.wh.gov\/mjmiic",
      "display_url" : "go.wh.gov\/mjmiic"
    } ]
  },
  "geo" : { },
  "id_str" : "579657312169758721",
  "text" : "\"No one can claim she\u2019s unqualified. No one\u2019s saying she can\u2019t do the job.\" \u2014Obama on AG nominee Loretta Lynch: http:\/\/t.co\/aPpBj4QK7w",
  "id" : 579657312169758721,
  "created_at" : "2015-03-22 14:54:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/aPpBj58kZ4",
      "expanded_url" : "http:\/\/go.wh.gov\/mjmiic",
      "display_url" : "go.wh.gov\/mjmiic"
    } ]
  },
  "geo" : { },
  "id_str" : "579349336850477057",
  "text" : "\"She\u2019s jailed some of New York\u2019s most violent and notorious mobsters and gang members.\" \u2014Obama on Loretta Lynch: http:\/\/t.co\/aPpBj58kZ4",
  "id" : 579349336850477057,
  "created_at" : "2015-03-21 18:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConfirmLynch",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/aPpBj58kZ4",
      "expanded_url" : "http:\/\/go.wh.gov\/mjmiic",
      "display_url" : "go.wh.gov\/mjmiic"
    } ]
  },
  "geo" : { },
  "id_str" : "579319294896439296",
  "text" : "\"For 30 years, Loretta has distinguished herself as a tough, fair, and independent attorney.\" \u2014Obama: http:\/\/t.co\/aPpBj58kZ4 #ConfirmLynch",
  "id" : 579319294896439296,
  "created_at" : "2015-03-21 16:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConfirmLynch",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/aPpBj4QK7w",
      "expanded_url" : "http:\/\/go.wh.gov\/mjmiic",
      "display_url" : "go.wh.gov\/mjmiic"
    } ]
  },
  "geo" : { },
  "id_str" : "579302735759208448",
  "text" : "President Obama's weekly address: It's time to confirm Attorney General nominee Loretta Lynch \u2192 http:\/\/t.co\/aPpBj4QK7w #ConfirmLynch",
  "id" : 579302735759208448,
  "created_at" : "2015-03-21 15:25:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 3, 14 ],
      "id_str" : "44615672",
      "id" : 44615672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trade",
      "indices" : [ 42, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/BowXRQko6x",
      "expanded_url" : "http:\/\/bit.ly\/1GAbMoo",
      "display_url" : "bit.ly\/1GAbMoo"
    } ]
  },
  "geo" : { },
  "id_str" : "579035892360314880",
  "text" : "RT @USTradeRep: See how President Obama's #trade deal will protect our environment and tackle illegal fishing: http:\/\/t.co\/BowXRQko6x http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USTradeRep\/status\/579031618670620673\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/L2apd0oM81",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAkiL_dUMAAztiQ.jpg",
        "id_str" : "579031616502116352",
        "id" : 579031616502116352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAkiL_dUMAAztiQ.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/L2apd0oM81"
      } ],
      "hashtags" : [ {
        "text" : "trade",
        "indices" : [ 26, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/BowXRQko6x",
        "expanded_url" : "http:\/\/bit.ly\/1GAbMoo",
        "display_url" : "bit.ly\/1GAbMoo"
      } ]
    },
    "geo" : { },
    "id_str" : "579031618670620673",
    "text" : "See how President Obama's #trade deal will protect our environment and tackle illegal fishing: http:\/\/t.co\/BowXRQko6x http:\/\/t.co\/L2apd0oM81",
    "id" : 579031618670620673,
    "created_at" : "2015-03-20 21:27:50 +0000",
    "user" : {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "protected" : false,
      "id_str" : "44615672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662636758509596672\/O-ShXHZB_normal.png",
      "id" : 44615672,
      "verified" : true
    }
  },
  "id" : 579035892360314880,
  "created_at" : "2015-03-20 21:44:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/579026868122185730\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/qnoyV7CNWI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAkduDaU0AAvQUn.jpg",
      "id_str" : "579026704120729600",
      "id" : 579026704120729600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAkduDaU0AAvQUn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qnoyV7CNWI"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 56, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/RfVuefYDy3",
      "expanded_url" : "http:\/\/go.wh.gov\/QdgusY",
      "display_url" : "go.wh.gov\/QdgusY"
    } ]
  },
  "geo" : { },
  "id_str" : "579026868122185730",
  "text" : "Get the latest on how President Obama's taking steps to #ActOnClimate \u2192 http:\/\/t.co\/RfVuefYDy3 http:\/\/t.co\/qnoyV7CNWI",
  "id" : 579026868122185730,
  "created_at" : "2015-03-20 21:08:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/579010923341434880\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/VXA2EWWNQk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAkO6cUUIAAPN3i.jpg",
      "id_str" : "579010424290418688",
      "id" : 579010424290418688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAkO6cUUIAAPN3i.jpg",
      "sizes" : [ {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VXA2EWWNQk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "579010923341434880",
  "text" : "Thanks for everything, @JPalm44. You will be missed. http:\/\/t.co\/VXA2EWWNQk",
  "id" : 579010923341434880,
  "created_at" : "2015-03-20 20:05:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/eZwdRbEJQc",
      "expanded_url" : "http:\/\/wh.gov\/FilmFest",
      "display_url" : "wh.gov\/FilmFest"
    }, {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Sm5ptHUQnl",
      "expanded_url" : "https:\/\/youtu.be\/N6IsVgVesqQ",
      "display_url" : "youtu.be\/N6IsVgVesqQ"
    } ]
  },
  "geo" : { },
  "id_str" : "578995681051832320",
  "text" : "Watch all 15 of the Official Selections from this year's #WHFilmFest \u2192 http:\/\/t.co\/eZwdRbEJQc https:\/\/t.co\/Sm5ptHUQnl",
  "id" : 578995681051832320,
  "created_at" : "2015-03-20 19:05:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SAG-AFTRA",
      "screen_name" : "sagaftra",
      "indices" : [ 34, 43 ],
      "id_str" : "19658506",
      "id" : 19658506
    }, {
      "name" : "AFI",
      "screen_name" : "AmericanFilm",
      "indices" : [ 50, 63 ],
      "id_str" : "24254832",
      "id" : 24254832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CallToArts",
      "indices" : [ 9, 20 ]
    }, {
      "text" : "WHFilmFest",
      "indices" : [ 133, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/jjecTrfx8O",
      "expanded_url" : "http:\/\/Serve.gov\/CallToArts",
      "display_url" : "Serve.gov\/CallToArts"
    } ]
  },
  "geo" : { },
  "id_str" : "578992341362573312",
  "text" : "Join the #CallToArts: Pledge with @SAGAFTRA &amp; @AmericanFilm to mentor the next generation's storytellers: http:\/\/t.co\/jjecTrfx8O #WHFilmFest",
  "id" : 578992341362573312,
  "created_at" : "2015-03-20 18:51:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578990997314617344\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ycncAJyrw2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAj9M95UkAAUO9H.jpg",
      "id_str" : "578990951332352000",
      "id" : 578990951332352000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAj9M95UkAAUO9H.jpg",
      "sizes" : [ {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1005
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1005
      } ],
      "display_url" : "pic.twitter.com\/ycncAJyrw2"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578990997314617344",
  "text" : "\"When we expect free WiFi with our coffee, then we should at least have it in our schools\" \u2014Obama #WHFilmFest http:\/\/t.co\/ycncAJyrw2",
  "id" : 578990997314617344,
  "created_at" : "2015-03-20 18:46:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578989444952256512",
  "text" : "\"If we give all of our kids the best opportunities and technologies and resources\u2014there\u2019s no telling what they\u2019ll create\" \u2014Obama #WHFilmFest",
  "id" : 578989444952256512,
  "created_at" : "2015-03-20 18:40:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/AfRoD9YPvw",
      "expanded_url" : "http:\/\/wh.gov\/FilmFest",
      "display_url" : "wh.gov\/FilmFest"
    } ]
  },
  "geo" : { },
  "id_str" : "578988975450300416",
  "text" : "RT @WHLive: \"Hello everybody, and welcome to the second annual White House Student Film Festival.\" \u2014President Obama: http:\/\/t.co\/AfRoD9YPvw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHFilmFest",
        "indices" : [ 128, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/AfRoD9YPvw",
        "expanded_url" : "http:\/\/wh.gov\/FilmFest",
        "display_url" : "wh.gov\/FilmFest"
      } ]
    },
    "geo" : { },
    "id_str" : "578988946094325760",
    "text" : "\"Hello everybody, and welcome to the second annual White House Student Film Festival.\" \u2014President Obama: http:\/\/t.co\/AfRoD9YPvw #WHFilmFest",
    "id" : 578988946094325760,
    "created_at" : "2015-03-20 18:38:16 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 578988975450300416,
  "created_at" : "2015-03-20 18:38:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578988663977033729\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/CWkKqRtZ3Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAj7GupVEAEeb-4.jpg",
      "id_str" : "578988645136273409",
      "id" : 578988645136273409,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAj7GupVEAEeb-4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CWkKqRtZ3Q"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/eZwdRbEJQc",
      "expanded_url" : "http:\/\/wh.gov\/FilmFest",
      "display_url" : "wh.gov\/FilmFest"
    } ]
  },
  "geo" : { },
  "id_str" : "578988663977033729",
  "text" : "Happening now: President Obama speaks at the White House Student Film Festival \u2192 http:\/\/t.co\/eZwdRbEJQc #WHFilmFest http:\/\/t.co\/CWkKqRtZ3Q",
  "id" : 578988663977033729,
  "created_at" : "2015-03-20 18:37:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578987672070307840",
  "text" : "RT @VP: Lucy Coffey was a pioneer for women in the armed forces, and her legacy will live on. I was honored to meet her. -vp http:\/\/t.co\/Sc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/578979971546263552\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/ScpZ1yZ8bB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAjzNz4WEAAH1tK.png",
        "id_str" : "578979970707492864",
        "id" : 578979970707492864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAjzNz4WEAAH1tK.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ScpZ1yZ8bB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "578979971546263552",
    "text" : "Lucy Coffey was a pioneer for women in the armed forces, and her legacy will live on. I was honored to meet her. -vp http:\/\/t.co\/ScpZ1yZ8bB",
    "id" : 578979971546263552,
    "created_at" : "2015-03-20 18:02:36 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 578987672070307840,
  "created_at" : "2015-03-20 18:33:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578979773248045056\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/gRL8QxpeZg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAjywhDUsAAv3kb.png",
      "id_str" : "578979467437060096",
      "id" : 578979467437060096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAjywhDUsAAv3kb.png",
      "sizes" : [ {
        "h" : 97,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gRL8QxpeZg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578979773248045056",
  "text" : "President Obama on the passing of Lucy Coffey, who was America's oldest living woman veteran. http:\/\/t.co\/gRL8QxpeZg",
  "id" : 578979773248045056,
  "created_at" : "2015-03-20 18:01:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 42, 53 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/5i8WFDG3jd",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "578976677797212160",
  "text" : "RT @kerrywashington: Watch the 2nd Annual @whitehouse Film Festival now: https:\/\/t.co\/5i8WFDG3jd -krew",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 21, 32 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/5i8WFDG3jd",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "578976523597664256",
    "text" : "Watch the 2nd Annual @whitehouse Film Festival now: https:\/\/t.co\/5i8WFDG3jd -krew",
    "id" : 578976523597664256,
    "created_at" : "2015-03-20 17:48:54 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 578976677797212160,
  "created_at" : "2015-03-20 17:49:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578976067811168256",
  "text" : "RT @Deese44: \"Are you paying attention?\" 6-year-old Noah asks at start of WH film fest video urging policymakers to #ActOnClimate https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/XaMxK79XSc",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=b2y8_UDrGjQ",
        "display_url" : "youtube.com\/watch?v=b2y8_U\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "578975745269227520",
    "text" : "\"Are you paying attention?\" 6-year-old Noah asks at start of WH film fest video urging policymakers to #ActOnClimate https:\/\/t.co\/XaMxK79XSc",
    "id" : 578975745269227520,
    "created_at" : "2015-03-20 17:45:49 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 578976067811168256,
  "created_at" : "2015-03-20 17:47:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578950491276767232\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Z7uFQRWvj2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAjYFBwUYAAMv4z.jpg",
      "id_str" : "578950132999151616",
      "id" : 578950132999151616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAjYFBwUYAAMv4z.jpg",
      "sizes" : [ {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Z7uFQRWvj2"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/eZwdRbn8YE",
      "expanded_url" : "http:\/\/wh.gov\/FilmFest",
      "display_url" : "wh.gov\/FilmFest"
    } ]
  },
  "geo" : { },
  "id_str" : "578950491276767232",
  "text" : "Tune in at 1pm ET for some amazing short films at the 2015 #WHFilmFest \u2192 http:\/\/t.co\/eZwdRbn8YE http:\/\/t.co\/Z7uFQRWvj2",
  "id" : 578950491276767232,
  "created_at" : "2015-03-20 16:05:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578939594449678337\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/oRO756tcPt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAjObTKVEAAbA1l.jpg",
      "id_str" : "578939520512495616",
      "id" : 578939520512495616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAjObTKVEAAbA1l.jpg",
      "sizes" : [ {
        "h" : 175,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1132
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oRO756tcPt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/aSFkWrJuRt",
      "expanded_url" : "http:\/\/go.wh.gov\/xc8US4",
      "display_url" : "go.wh.gov\/xc8US4"
    } ]
  },
  "geo" : { },
  "id_str" : "578939594449678337",
  "text" : "President Obama on American citizens detained or missing in Iran \u2192 http:\/\/t.co\/aSFkWrJuRt http:\/\/t.co\/oRO756tcPt",
  "id" : 578939594449678337,
  "created_at" : "2015-03-20 15:22:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/V4U7NaGBj1",
      "expanded_url" : "http:\/\/go.wh.gov\/ot3JNV",
      "display_url" : "go.wh.gov\/ot3JNV"
    } ]
  },
  "geo" : { },
  "id_str" : "578934890135228416",
  "text" : "RT @FLOTUS: In Kyoto, the First Lady tried her hand at taiko drumming. Check out her travel journal\u2192 http:\/\/t.co\/V4U7NaGBj1 http:\/\/t.co\/tjV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/578934068743557120\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/tjVKCcrmTw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAjJdaJU0AAVoXR.jpg",
        "id_str" : "578934059188932608",
        "id" : 578934059188932608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAjJdaJU0AAVoXR.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/tjVKCcrmTw"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/578934068743557120\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/tjVKCcrmTw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAjJd1AVEAA4zJz.jpg",
        "id_str" : "578934066398957568",
        "id" : 578934066398957568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAjJd1AVEAA4zJz.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/tjVKCcrmTw"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/578934068743557120\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/tjVKCcrmTw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAjJcQBUsAEIM7T.jpg",
        "id_str" : "578934039291146241",
        "id" : 578934039291146241,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAjJcQBUsAEIM7T.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/tjVKCcrmTw"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/V4U7NaGBj1",
        "expanded_url" : "http:\/\/go.wh.gov\/ot3JNV",
        "display_url" : "go.wh.gov\/ot3JNV"
      } ]
    },
    "geo" : { },
    "id_str" : "578934068743557120",
    "text" : "In Kyoto, the First Lady tried her hand at taiko drumming. Check out her travel journal\u2192 http:\/\/t.co\/V4U7NaGBj1 http:\/\/t.co\/tjVKCcrmTw",
    "id" : 578934068743557120,
    "created_at" : "2015-03-20 15:00:12 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 578934890135228416,
  "created_at" : "2015-03-20 15:03:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Schakowsky",
      "screen_name" : "janschakowsky",
      "indices" : [ 3, 17 ],
      "id_str" : "24195214",
      "id" : 24195214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPbudget",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578921526461759488",
  "text" : "RT @janschakowsky: I oppose the #GOPbudget that would take away quality, affordable health insurance coverage for millions of Americans. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/janschakowsky\/status\/578913236659101696\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/V5UdTFcZIX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAi2hWMUcAAfHGx.jpg",
        "id_str" : "578913236126298112",
        "id" : 578913236126298112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAi2hWMUcAAfHGx.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/V5UdTFcZIX"
      } ],
      "hashtags" : [ {
        "text" : "GOPbudget",
        "indices" : [ 13, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "578913236659101696",
    "text" : "I oppose the #GOPbudget that would take away quality, affordable health insurance coverage for millions of Americans. http:\/\/t.co\/V5UdTFcZIX",
    "id" : 578913236659101696,
    "created_at" : "2015-03-20 13:37:25 +0000",
    "user" : {
      "name" : "Jan Schakowsky",
      "screen_name" : "janschakowsky",
      "protected" : false,
      "id_str" : "24195214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778943630123958276\/Tg3a8mgI_normal.jpg",
      "id" : 24195214,
      "verified" : true
    }
  },
  "id" : 578921526461759488,
  "created_at" : "2015-03-20 14:10:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/578704012830076928\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/RgcAo2Z5jT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAf4FH7UYAA8I7h.jpg",
      "id_str" : "578703844051279872",
      "id" : 578703844051279872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAf4FH7UYAA8I7h.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RgcAo2Z5jT"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/eZwdRbEJQc",
      "expanded_url" : "http:\/\/wh.gov\/FilmFest",
      "display_url" : "wh.gov\/FilmFest"
    } ]
  },
  "geo" : { },
  "id_str" : "578704012830076928",
  "text" : "Get your popcorn ready: Tune in tomorrow at 1pm ET for the #WHFilmFest \u2192 http:\/\/t.co\/eZwdRbEJQc http:\/\/t.co\/RgcAo2Z5jT",
  "id" : 578704012830076928,
  "created_at" : "2015-03-19 23:46:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/578621515014373376\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/aBgKdPsu5E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAetM5eUkAAxnuj.jpg",
      "id_str" : "578621514238431232",
      "id" : 578621514238431232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAetM5eUkAAxnuj.jpg",
      "sizes" : [ {
        "h" : 2022,
        "resize" : "fit",
        "w" : 2884
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aBgKdPsu5E"
    } ],
    "hashtags" : [ {
      "text" : "WomensHistoryMonth",
      "indices" : [ 88, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/ga4Gd5PuH0",
      "expanded_url" : "http:\/\/on.doi.gov\/1xfpPQD",
      "display_url" : "on.doi.gov\/1xfpPQD"
    } ]
  },
  "geo" : { },
  "id_str" : "578687312541786113",
  "text" : "RT @Interior: Meet 93 y\/o Betty Soskin\u2014oldest active park ranger http:\/\/t.co\/ga4Gd5PuH0 #WomensHistoryMonth http:\/\/t.co\/aBgKdPsu5E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/578621515014373376\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/aBgKdPsu5E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAetM5eUkAAxnuj.jpg",
        "id_str" : "578621514238431232",
        "id" : 578621514238431232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAetM5eUkAAxnuj.jpg",
        "sizes" : [ {
          "h" : 2022,
          "resize" : "fit",
          "w" : 2884
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 718,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/aBgKdPsu5E"
      } ],
      "hashtags" : [ {
        "text" : "WomensHistoryMonth",
        "indices" : [ 74, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/ga4Gd5PuH0",
        "expanded_url" : "http:\/\/on.doi.gov\/1xfpPQD",
        "display_url" : "on.doi.gov\/1xfpPQD"
      } ]
    },
    "geo" : { },
    "id_str" : "578621515014373376",
    "text" : "Meet 93 y\/o Betty Soskin\u2014oldest active park ranger http:\/\/t.co\/ga4Gd5PuH0 #WomensHistoryMonth http:\/\/t.co\/aBgKdPsu5E",
    "id" : 578621515014373376,
    "created_at" : "2015-03-19 18:18:14 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 578687312541786113,
  "created_at" : "2015-03-19 22:39:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/8ti5euwBon",
      "expanded_url" : "http:\/\/go.wh.gov\/QdgusY",
      "display_url" : "go.wh.gov\/QdgusY"
    } ]
  },
  "geo" : { },
  "id_str" : "578655711959330818",
  "text" : "RT @Cecilia44: FACT: President Obama is taking action to save taxpayers up to $18 billion in energy costs \u2192 http:\/\/t.co\/8ti5euwBon http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cecilia44\/status\/578654565479948288\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/B9dVoZ23ik",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAfLQl0WQAA1Uxr.jpg",
        "id_str" : "578654563030417408",
        "id" : 578654563030417408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAfLQl0WQAA1Uxr.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/B9dVoZ23ik"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/8ti5euwBon",
        "expanded_url" : "http:\/\/go.wh.gov\/QdgusY",
        "display_url" : "go.wh.gov\/QdgusY"
      } ]
    },
    "geo" : { },
    "id_str" : "578654565479948288",
    "text" : "FACT: President Obama is taking action to save taxpayers up to $18 billion in energy costs \u2192 http:\/\/t.co\/8ti5euwBon http:\/\/t.co\/B9dVoZ23ik",
    "id" : 578654565479948288,
    "created_at" : "2015-03-19 20:29:33 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 578655711959330818,
  "created_at" : "2015-03-19 20:34:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Villanova University",
      "screen_name" : "VillanovaU",
      "indices" : [ 38, 49 ],
      "id_str" : "63143087",
      "id" : 63143087
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMarchNOVA",
      "indices" : [ 110, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578648134739501056",
  "text" : "RT @DrBiden: Glad to see POTUS picked @VillanovaU for the championship game but my alma mater will win it all #LetsMarchNOVA -Jill http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Villanova University",
        "screen_name" : "VillanovaU",
        "indices" : [ 25, 36 ],
        "id_str" : "63143087",
        "id" : 63143087
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/578647755524034560\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/QHYUYyPUZL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAfFEDnWYAE6nTg.jpg",
        "id_str" : "578647750620897281",
        "id" : 578647750620897281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAfFEDnWYAE6nTg.jpg",
        "sizes" : [ {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2056,
          "resize" : "fit",
          "w" : 2880
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/QHYUYyPUZL"
      } ],
      "hashtags" : [ {
        "text" : "LetsMarchNOVA",
        "indices" : [ 97, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "578647755524034560",
    "text" : "Glad to see POTUS picked @VillanovaU for the championship game but my alma mater will win it all #LetsMarchNOVA -Jill http:\/\/t.co\/QHYUYyPUZL",
    "id" : 578647755524034560,
    "created_at" : "2015-03-19 20:02:30 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 578648134739501056,
  "created_at" : "2015-03-19 20:04:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 127, 139 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/nYGzWOPHiQ",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/03\/19\/leading-example-climate-change-our-new-federal-sustainability-plan",
      "display_url" : "whitehouse.gov\/blog\/2015\/03\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "578643973188648960",
  "text" : "RT @GinaEPA: Big news! President Obama signed an EO to cut federal govt's CO2 emissions: https:\/\/t.co\/nYGzWOPHiQ #ActOnClimate @ErnestMoniz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ernest Moniz",
        "screen_name" : "ErnestMoniz",
        "indices" : [ 114, 126 ],
        "id_str" : "1393155566",
        "id" : 1393155566
      }, {
        "name" : "Denise Turner Roth",
        "screen_name" : "DeniseUSGSA",
        "indices" : [ 127, 139 ],
        "id_str" : "1323110707",
        "id" : 1323110707
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/nYGzWOPHiQ",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/03\/19\/leading-example-climate-change-our-new-federal-sustainability-plan",
        "display_url" : "whitehouse.gov\/blog\/2015\/03\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "578628204606410752",
    "text" : "Big news! President Obama signed an EO to cut federal govt's CO2 emissions: https:\/\/t.co\/nYGzWOPHiQ #ActOnClimate @ErnestMoniz @DeniseUSGSA",
    "id" : 578628204606410752,
    "created_at" : "2015-03-19 18:44:49 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 578643973188648960,
  "created_at" : "2015-03-19 19:47:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578630199442595840\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/hJHqg6PuIN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAe07yvU8AEJ90U.jpg",
      "id_str" : "578630016465956865",
      "id" : 578630016465956865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAe07yvU8AEJ90U.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hJHqg6PuIN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/RfVueggeWD",
      "expanded_url" : "http:\/\/go.wh.gov\/QdgusY",
      "display_url" : "go.wh.gov\/QdgusY"
    } ]
  },
  "geo" : { },
  "id_str" : "578630199442595840",
  "text" : "President Obama just took action to cut the Federal Government's carbon pollution emissions \u2192 http:\/\/t.co\/RfVueggeWD http:\/\/t.co\/hJHqg6PuIN",
  "id" : 578630199442595840,
  "created_at" : "2015-03-19 18:52:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578625535992987648\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xfKvv4adeM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAewZx6U8AA6bkK.jpg",
      "id_str" : "578625034081595392",
      "id" : 578625034081595392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAewZx6U8AA6bkK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xfKvv4adeM"
    } ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/B8WgyYX47L",
      "expanded_url" : "http:\/\/go.wh.gov\/WQEd6m",
      "display_url" : "go.wh.gov\/WQEd6m"
    } ]
  },
  "geo" : { },
  "id_str" : "578625535992987648",
  "text" : "Take our quiz to share what you'd do if you were in charge of America's budget \u2192 http:\/\/t.co\/B8WgyYX47L #HouseOfCuts http:\/\/t.co\/xfKvv4adeM",
  "id" : 578625535992987648,
  "created_at" : "2015-03-19 18:34:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 32, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578617444660486144",
  "text" : "RT @FLOTUS: How do Bo and Sunny #GimmeFive to get ready for the Easter Egg Roll? \nRun \u2713\nFetch \u2713\nStairs \u2713\nPlay \u2713\nLaps \u2713\nhttps:\/\/t.co\/oFayxjJ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GimmeFive",
        "indices" : [ 20, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/oFayxjJKph",
        "expanded_url" : "https:\/\/youtu.be\/xxLuj4ve-XI",
        "display_url" : "youtu.be\/xxLuj4ve-XI"
      } ]
    },
    "geo" : { },
    "id_str" : "578608286183763969",
    "text" : "How do Bo and Sunny #GimmeFive to get ready for the Easter Egg Roll? \nRun \u2713\nFetch \u2713\nStairs \u2713\nPlay \u2713\nLaps \u2713\nhttps:\/\/t.co\/oFayxjJKph",
    "id" : 578608286183763969,
    "created_at" : "2015-03-19 17:25:40 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 578617444660486144,
  "created_at" : "2015-03-19 18:02:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578595155738955776\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/kEC6JWaBDY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAeVM0BUsAA3vdW.jpg",
      "id_str" : "578595124495560704",
      "id" : 578595124495560704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAeVM0BUsAA3vdW.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kEC6JWaBDY"
    } ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/IWAoMASTT9",
      "expanded_url" : "http:\/\/go.wh.gov\/GOP-budget",
      "display_url" : "go.wh.gov\/GOP-budget"
    } ]
  },
  "geo" : { },
  "id_str" : "578595155738955776",
  "text" : "The House GOP budget would eliminate health coverage for millions of Americans \u2192 http:\/\/t.co\/IWAoMASTT9 #HouseOfCuts http:\/\/t.co\/kEC6JWaBDY",
  "id" : 578595155738955776,
  "created_at" : "2015-03-19 16:33:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "18F",
      "screen_name" : "18F",
      "indices" : [ 3, 7 ],
      "id_str" : "2366194867",
      "id" : 2366194867
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/18F\/status\/578563466018963456\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Np8XShRBox",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAd4Z-XUcAAXehx.png",
      "id_str" : "578563464773267456",
      "id" : 578563464773267456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAd4Z-XUcAAXehx.png",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 962
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 962
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Np8XShRBox"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/mf7cmeGxZf",
      "expanded_url" : "https:\/\/analytics.usa.gov",
      "display_url" : "analytics.usa.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "578583555548164096",
  "text" : "RT @18F: LAUNCH DAY! Check out https:\/\/t.co\/mf7cmeGxZf, the new public dashboard for the US government's web traffic! http:\/\/t.co\/Np8XShRBox",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/18F\/status\/578563466018963456\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/Np8XShRBox",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAd4Z-XUcAAXehx.png",
        "id_str" : "578563464773267456",
        "id" : 578563464773267456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAd4Z-XUcAAXehx.png",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 962
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 962
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Np8XShRBox"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/mf7cmeGxZf",
        "expanded_url" : "https:\/\/analytics.usa.gov",
        "display_url" : "analytics.usa.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "578563466018963456",
    "text" : "LAUNCH DAY! Check out https:\/\/t.co\/mf7cmeGxZf, the new public dashboard for the US government's web traffic! http:\/\/t.co\/Np8XShRBox",
    "id" : 578563466018963456,
    "created_at" : "2015-03-19 14:27:34 +0000",
    "user" : {
      "name" : "18F",
      "screen_name" : "18F",
      "protected" : false,
      "id_str" : "2366194867",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730841873808392192\/9ubCh8KI_normal.jpg",
      "id" : 2366194867,
      "verified" : true
    }
  },
  "id" : 578583555548164096,
  "created_at" : "2015-03-19 15:47:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578572415711592448\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/w5FguEeNu6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAeAac-U8AA8j88.jpg",
      "id_str" : "578572269082963968",
      "id" : 578572269082963968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAeAac-U8AA8j88.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/w5FguEeNu6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578572415711592448",
  "text" : "President Obama's budget would make college more affordable.\nThe House GOP budget would make it harder to afford. http:\/\/t.co\/w5FguEeNu6",
  "id" : 578572415711592448,
  "created_at" : "2015-03-19 15:03:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Denali National Park",
      "screen_name" : "DenaliNPS",
      "indices" : [ 93, 103 ],
      "id_str" : "45943457",
      "id" : 45943457
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/578320961096806400\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/tul5SqHOzR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAab1ijXEAIgJsn.jpg",
      "id_str" : "578320946274177026",
      "id" : 578320946274177026,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAab1ijXEAIgJsn.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tul5SqHOzR"
    } ],
    "hashtags" : [ {
      "text" : "Alaska",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578336667238588416",
  "text" : "RT @Interior: The northern lights put on a spectacular show last night. Aurora borealis over @DenaliNPS #Alaska http:\/\/t.co\/tul5SqHOzR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Denali National Park",
        "screen_name" : "DenaliNPS",
        "indices" : [ 79, 89 ],
        "id_str" : "45943457",
        "id" : 45943457
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/578320961096806400\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/tul5SqHOzR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAab1ijXEAIgJsn.jpg",
        "id_str" : "578320946274177026",
        "id" : 578320946274177026,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAab1ijXEAIgJsn.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tul5SqHOzR"
      } ],
      "hashtags" : [ {
        "text" : "Alaska",
        "indices" : [ 90, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "578320961096806400",
    "text" : "The northern lights put on a spectacular show last night. Aurora borealis over @DenaliNPS #Alaska http:\/\/t.co\/tul5SqHOzR",
    "id" : 578320961096806400,
    "created_at" : "2015-03-18 22:23:56 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 578336667238588416,
  "created_at" : "2015-03-18 23:26:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578316620642193408\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Ryd67WtLvp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAaXueVUIAAhfUc.jpg",
      "id_str" : "578316426835927040",
      "id" : 578316426835927040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAaXueVUIAAhfUc.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ryd67WtLvp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578316620642193408",
  "text" : "The House GOP budget would:\nCut taxes for millionaires \u2713\nRaise taxes for 26 million working families and students \u2713 http:\/\/t.co\/Ryd67WtLvp",
  "id" : 578316620642193408,
  "created_at" : "2015-03-18 22:06:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578293737945739264\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Yvg4WeUY53",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAaC137UUAAtcuh.jpg",
      "id_str" : "578293464221110272",
      "id" : 578293464221110272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAaC137UUAAtcuh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Yvg4WeUY53"
    } ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578293737945739264",
  "text" : "The choice on health care:\nHelping more Americans gain coverage vs. Eliminating coverage for millions. #HouseOfCuts http:\/\/t.co\/Yvg4WeUY53",
  "id" : 578293737945739264,
  "created_at" : "2015-03-18 20:35:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578284573466963968\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/2Kf7BYQLJ5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZ5dtPUcAECGqB.jpg",
      "id_str" : "578283153430704129",
      "id" : 578283153430704129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZ5dtPUcAECGqB.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/2Kf7BYQLJ5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578284573466963968",
  "text" : "\u201CWe shouldn\u2019t be making it harder to vote. We should be making it easier to vote.\u201D \u2014President Obama http:\/\/t.co\/2Kf7BYQLJ5",
  "id" : 578284573466963968,
  "created_at" : "2015-03-18 19:59:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578280950301376513",
  "text" : "\u201CMy most important advice is worry more about what you want to do rather than what you want to be.\u201D \u2014President Obama to young Americans",
  "id" : 578280950301376513,
  "created_at" : "2015-03-18 19:44:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The City Club",
      "screen_name" : "TheCityClub",
      "indices" : [ 69, 81 ],
      "id_str" : "38253336",
      "id" : 38253336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/4Yt7TBHjQ8",
      "expanded_url" : "http:\/\/go.wh.gov\/DP1iMe",
      "display_url" : "go.wh.gov\/DP1iMe"
    } ]
  },
  "geo" : { },
  "id_str" : "578277152757538816",
  "text" : "RT @WHLive: Watch President Obama answer questions on the economy at @TheCityClub in Cleveland \u2192 http:\/\/t.co\/4Yt7TBHjQ8 http:\/\/t.co\/pHw1aN5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The City Club",
        "screen_name" : "TheCityClub",
        "indices" : [ 57, 69 ],
        "id_str" : "38253336",
        "id" : 38253336
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/578277125561548801\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/pHw1aN5urm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZzyUsUgAACdEl.png",
        "id_str" : "578276910548942848",
        "id" : 578276910548942848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZzyUsUgAACdEl.png",
        "sizes" : [ {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 515,
          "resize" : "fit",
          "w" : 931
        }, {
          "h" : 515,
          "resize" : "fit",
          "w" : 931
        } ],
        "display_url" : "pic.twitter.com\/pHw1aN5urm"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/4Yt7TBHjQ8",
        "expanded_url" : "http:\/\/go.wh.gov\/DP1iMe",
        "display_url" : "go.wh.gov\/DP1iMe"
      } ]
    },
    "geo" : { },
    "id_str" : "578277125561548801",
    "text" : "Watch President Obama answer questions on the economy at @TheCityClub in Cleveland \u2192 http:\/\/t.co\/4Yt7TBHjQ8 http:\/\/t.co\/pHw1aN5urm",
    "id" : 578277125561548801,
    "created_at" : "2015-03-18 19:29:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 578277152757538816,
  "created_at" : "2015-03-18 19:29:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578275339501207552",
  "text" : "RT @WHLive: \"We can keep growing our exports and protect our workers with strong new trade deals.\" \u2014President Obama #LeadOnTrade http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/578275312175316992\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/VELGzGtnG1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZyTiNVAAAoKvB.jpg",
        "id_str" : "578275282089476096",
        "id" : 578275282089476096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZyTiNVAAAoKvB.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VELGzGtnG1"
      } ],
      "hashtags" : [ {
        "text" : "LeadOnTrade",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "578275312175316992",
    "text" : "\"We can keep growing our exports and protect our workers with strong new trade deals.\" \u2014President Obama #LeadOnTrade http:\/\/t.co\/VELGzGtnG1",
    "id" : 578275312175316992,
    "created_at" : "2015-03-18 19:22:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 578275339501207552,
  "created_at" : "2015-03-18 19:22:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578274767209295872\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/v7CuYO9AFE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZxzxHUcAAfM7f.jpg",
      "id_str" : "578274736334991360",
      "id" : 578274736334991360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZxzxHUcAAfM7f.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/v7CuYO9AFE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578274767209295872",
  "text" : "\"I\u2019ve proposed making two years of community college as free and universal as high school is today.\" \u2014Obama http:\/\/t.co\/v7CuYO9AFE",
  "id" : 578274767209295872,
  "created_at" : "2015-03-18 19:20:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578273873365434368\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/XLP60TYJOB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZw0stU0AAukZV.jpg",
      "id_str" : "578273652820463616",
      "id" : 578273652820463616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZw0stU0AAukZV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XLP60TYJOB"
    } ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578273873365434368",
  "text" : "Obama: The House GOP budget would kick \"tens of millions of Americans off their health insurance.\" #HouseOfCuts http:\/\/t.co\/XLP60TYJOB",
  "id" : 578273873365434368,
  "created_at" : "2015-03-18 19:16:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578273061947969536\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/bk3HMbp60L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZwK3FVIAABlDN.jpg",
      "id_str" : "578272934050996224",
      "id" : 578272934050996224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZwK3FVIAABlDN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bk3HMbp60L"
    } ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578273061947969536",
  "text" : "\"Investments in education would be cut to their lowest levels since 2000\" \u2014Obama on the House GOP budget #HouseOfCuts http:\/\/t.co\/bk3HMbp60L",
  "id" : 578273061947969536,
  "created_at" : "2015-03-18 19:13:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578271287316983808\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/74AbNcGeJt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZuodAUwAAXFTO.jpg",
      "id_str" : "578271243423498240",
      "id" : 578271243423498240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZuodAUwAAXFTO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/74AbNcGeJt"
    } ],
    "hashtags" : [ {
      "text" : "HouseOfCuts",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578271287316983808",
  "text" : "\"Trickle-down economics doesn\u2019t work. Middle-class economics does.\" \u2014President Obama #HouseOfCuts http:\/\/t.co\/74AbNcGeJt",
  "id" : 578271287316983808,
  "created_at" : "2015-03-18 19:06:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578270691864154112\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/Nvw8mrdyzP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZuAQBUgAA9qMn.jpg",
      "id_str" : "578270552743247872",
      "id" : 578270552743247872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZuAQBUgAA9qMn.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Nvw8mrdyzP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/wSiiHMHg1G",
      "expanded_url" : "http:\/\/go.wh.gov\/DP1iMe",
      "display_url" : "go.wh.gov\/DP1iMe"
    } ]
  },
  "geo" : { },
  "id_str" : "578270691864154112",
  "text" : "\"America does better...when the middle class does better.\" \u2014President Obama: http:\/\/t.co\/wSiiHMHg1G http:\/\/t.co\/Nvw8mrdyzP",
  "id" : 578270691864154112,
  "created_at" : "2015-03-18 19:04:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578269295479656448\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/KWhAA9KgXv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZsyPuUkAAIfKz.jpg",
      "id_str" : "578269212633763840",
      "id" : 578269212633763840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZsyPuUkAAIfKz.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KWhAA9KgXv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578269295479656448",
  "text" : "\"Since I took office, we\u2019ve cut our deficits as a share of our economy by about two-thirds.\" \u2014President Obama http:\/\/t.co\/KWhAA9KgXv",
  "id" : 578269295479656448,
  "created_at" : "2015-03-18 18:58:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578268946794577920\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/2cS8qx5SPo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZshBCVAAA_ez-.jpg",
      "id_str" : "578268916633370624",
      "id" : 578268916633370624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZshBCVAAA_ez-.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2cS8qx5SPo"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578268946794577920",
  "text" : "\"More than 16 million uninsured Americans have gained the security of health coverage.\" \u2014President Obama #ACAWorks http:\/\/t.co\/2cS8qx5SPo",
  "id" : 578268946794577920,
  "created_at" : "2015-03-18 18:57:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578268687259430912\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/IbgXMOlCEA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZsS3eVEAABASY.jpg",
      "id_str" : "578268673548292096",
      "id" : 578268673548292096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZsS3eVEAABASY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IbgXMOlCEA"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578268687259430912",
  "text" : "\"Factories are opening their doors at the fastest pace in nearly two decades.\" \u2014President Obama #MadeInAmerica http:\/\/t.co\/IbgXMOlCEA",
  "id" : 578268687259430912,
  "created_at" : "2015-03-18 18:56:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/578268271213850624\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/B11m5YinuR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZr6KmUUAAsqxG.jpg",
      "id_str" : "578268249185341440",
      "id" : 578268249185341440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZr6KmUUAAsqxG.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/B11m5YinuR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "578268271213850624",
  "text" : "\"Today, there are more job openings in the United States than at any time since 2001.\" \u2014President Obama http:\/\/t.co\/B11m5YinuR",
  "id" : 578268271213850624,
  "created_at" : "2015-03-18 18:54:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/578267176462757888\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/AUIWPXeQEZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZq6ddVIAAfRGj.jpg",
      "id_str" : "578267154736291840",
      "id" : 578267154736291840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZq6ddVIAAfRGj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1201
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AUIWPXeQEZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/wSiiHMHg1G",
      "expanded_url" : "http:\/\/go.wh.gov\/DP1iMe",
      "display_url" : "go.wh.gov\/DP1iMe"
    } ]
  },
  "geo" : { },
  "id_str" : "578267176462757888",
  "text" : "Watch live: President Obama speaks on the importance of middle-class economics \u2192 http:\/\/t.co\/wSiiHMHg1G http:\/\/t.co\/AUIWPXeQEZ",
  "id" : 578267176462757888,
  "created_at" : "2015-03-18 18:50:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Deese44\/status\/578233125710401536\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ESjaGPzC2Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZL9lbUMAASFcA.jpg",
      "id_str" : "578233123554471936",
      "id" : 578233123554471936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZL9lbUMAASFcA.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ESjaGPzC2Y"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/WutetufL9n",
      "expanded_url" : "http:\/\/nyti.ms\/18H0ljF",
      "display_url" : "nyti.ms\/18H0ljF"
    } ]
  },
  "geo" : { },
  "id_str" : "578233369709936640",
  "text" : "RT @Deese44: CA drought a taste of possible things to come if we fail to #ActOnClimate http:\/\/t.co\/WutetufL9n http:\/\/t.co\/ESjaGPzC2Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Deese44\/status\/578233125710401536\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/ESjaGPzC2Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAZL9lbUMAASFcA.jpg",
        "id_str" : "578233123554471936",
        "id" : 578233123554471936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAZL9lbUMAASFcA.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ESjaGPzC2Y"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/WutetufL9n",
        "expanded_url" : "http:\/\/nyti.ms\/18H0ljF",
        "display_url" : "nyti.ms\/18H0ljF"
      } ]
    },
    "geo" : { },
    "id_str" : "578233125710401536",
    "text" : "CA drought a taste of possible things to come if we fail to #ActOnClimate http:\/\/t.co\/WutetufL9n http:\/\/t.co\/ESjaGPzC2Y",
    "id" : 578233125710401536,
    "created_at" : "2015-03-18 16:34:54 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 578233369709936640,
  "created_at" : "2015-03-18 16:35:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchMadness",
      "indices" : [ 37, 50 ]
    }, {
      "text" : "ItsOnUs",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/hNausrQQAW",
      "expanded_url" : "http:\/\/es.pn\/1FAnG3t",
      "display_url" : "es.pn\/1FAnG3t"
    } ]
  },
  "geo" : { },
  "id_str" : "578203730350366720",
  "text" : "Watch President Obama announce a new #MarchMadness contest to help prevent sexual assault \u2192 http:\/\/t.co\/hNausrQQAW #ItsOnUs",
  "id" : 578203730350366720,
  "created_at" : "2015-03-18 14:38:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/578189256205709312\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/gYREANLa6P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAYijKLWwAA8I0e.jpg",
      "id_str" : "578187589586436096",
      "id" : 578187589586436096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAYijKLWwAA8I0e.jpg",
      "sizes" : [ {
        "h" : 779,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1141,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/gYREANLa6P"
    } ],
    "hashtags" : [ {
      "text" : "Baracketology",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ENqqesV08s",
      "expanded_url" : "http:\/\/go.wh.gov\/bracket",
      "display_url" : "go.wh.gov\/bracket"
    } ]
  },
  "geo" : { },
  "id_str" : "578189256205709312",
  "text" : "All the President's picks: Check out his NCAA Tournament Bracket \u2192 http:\/\/t.co\/ENqqesV08s #Baracketology http:\/\/t.co\/gYREANLa6P",
  "id" : 578189256205709312,
  "created_at" : "2015-03-18 13:40:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/577985821799628800\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/JScbYjLpWy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAVq_SqU0AA9WQG.jpg",
      "id_str" : "577985762760642560",
      "id" : 577985762760642560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAVq_SqU0AA9WQG.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JScbYjLpWy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577987407540305920",
  "text" : "RT @FLOTUS: A stunning view flying over Alaska's Chugach Mountains. http:\/\/t.co\/JScbYjLpWy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/577985821799628800\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/JScbYjLpWy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAVq_SqU0AA9WQG.jpg",
        "id_str" : "577985762760642560",
        "id" : 577985762760642560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAVq_SqU0AA9WQG.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JScbYjLpWy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "577985821799628800",
    "text" : "A stunning view flying over Alaska's Chugach Mountains. http:\/\/t.co\/JScbYjLpWy",
    "id" : 577985821799628800,
    "created_at" : "2015-03-18 00:12:13 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 577987407540305920,
  "created_at" : "2015-03-18 00:18:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/577973764987727872\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/EHitVeJ6mb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAVf-LpVIAAM0MU.jpg",
      "id_str" : "577973649069645824",
      "id" : 577973649069645824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAVf-LpVIAAM0MU.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 910,
        "resize" : "fit",
        "w" : 1365
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/EHitVeJ6mb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577973764987727872",
  "text" : "Happy St. Patrick's Day! http:\/\/t.co\/EHitVeJ6mb",
  "id" : 577973764987727872,
  "created_at" : "2015-03-17 23:24:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyStPatricksDay",
      "indices" : [ 121, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577947783916883968",
  "text" : "\"The story of the Irish in America is a story of overcoming hardship through strength, and sacrifice, and faith.\" \u2014Obama #HappyStPatricksDay",
  "id" : 577947783916883968,
  "created_at" : "2015-03-17 21:41:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/577947314477772801\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/80hbeYM1T6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAVH-RsVIAAVIPH.png",
      "id_str" : "577947262413774848",
      "id" : 577947262413774848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAVH-RsVIAAVIPH.png",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 522,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 522,
        "resize" : "fit",
        "w" : 932
      } ],
      "display_url" : "pic.twitter.com\/80hbeYM1T6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/qAgwIwSCn5",
      "expanded_url" : "http:\/\/go.wh.gov\/qMY3Zw",
      "display_url" : "go.wh.gov\/qMY3Zw"
    } ]
  },
  "geo" : { },
  "id_str" : "577947314477772801",
  "text" : "\u201CHappy Saint Patrick's Day, everybody!\u201D \u2014President Obama: http:\/\/t.co\/qAgwIwSCn5 http:\/\/t.co\/80hbeYM1T6",
  "id" : 577947314477772801,
  "created_at" : "2015-03-17 21:39:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/qAgwIwB0Yv",
      "expanded_url" : "http:\/\/go.wh.gov\/qMY3Zw",
      "display_url" : "go.wh.gov\/qMY3Zw"
    } ]
  },
  "geo" : { },
  "id_str" : "577946270989348864",
  "text" : "Happening now: President Obama hosts a St. Patrick's Day reception at the White House \u2192 http:\/\/t.co\/qAgwIwB0Yv",
  "id" : 577946270989348864,
  "created_at" : "2015-03-17 21:35:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Tammy Baldwin",
      "screen_name" : "SenatorBaldwin",
      "indices" : [ 3, 18 ],
      "id_str" : "1074518754",
      "id" : 1074518754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577924525934845952",
  "text" : "RT @SenatorBaldwin: Note: GOP holds off confirming 1st African-American woman AG to vote on denying health services for human trafficking v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ConfirmLynch",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "577895714367242240",
    "text" : "Note: GOP holds off confirming 1st African-American woman AG to vote on denying health services for human trafficking victims. #ConfirmLynch",
    "id" : 577895714367242240,
    "created_at" : "2015-03-17 18:14:09 +0000",
    "user" : {
      "name" : "Sen. Tammy Baldwin",
      "screen_name" : "SenatorBaldwin",
      "protected" : false,
      "id_str" : "1074518754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656152457756692481\/jq9YvUuw_normal.jpg",
      "id" : 1074518754,
      "verified" : true
    }
  },
  "id" : 577924525934845952,
  "created_at" : "2015-03-17 20:08:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsten Gillibrand",
      "screen_name" : "SenGillibrand",
      "indices" : [ 3, 17 ],
      "id_str" : "72198806",
      "id" : 72198806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577922407274405888",
  "text" : "RT @SenGillibrand: Loretta Lynch has waited 129 days for Senate to vote on her nom as AG, despite having bipartisan support. Long past time\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "confirmLynch",
        "indices" : [ 124, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "577900964033728513",
    "text" : "Loretta Lynch has waited 129 days for Senate to vote on her nom as AG, despite having bipartisan support. Long past time to #confirmLynch.",
    "id" : 577900964033728513,
    "created_at" : "2015-03-17 18:35:01 +0000",
    "user" : {
      "name" : "Kirsten Gillibrand",
      "screen_name" : "SenGillibrand",
      "protected" : false,
      "id_str" : "72198806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748266569323659264\/Kv9U6DgK_normal.jpg",
      "id" : 72198806,
      "verified" : true
    }
  },
  "id" : 577922407274405888,
  "created_at" : "2015-03-17 20:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Y16qjmJa6F",
      "expanded_url" : "http:\/\/go.wh.gov\/GA8WC2",
      "display_url" : "go.wh.gov\/GA8WC2"
    } ]
  },
  "geo" : { },
  "id_str" : "577917945311064064",
  "text" : "RT @FLOTUS: \u2708 Wheels up! \u2708\nFollow along with the First Lady's trip to Japan and Cambodia: http:\/\/t.co\/Y16qjmJa6F #LetGirlsLearn http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/577916280042352640\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/lAdlJbCwhL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAUrTh0UcAAz79y.jpg",
        "id_str" : "577915741682298880",
        "id" : 577915741682298880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAUrTh0UcAAz79y.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lAdlJbCwhL"
      } ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 101, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/Y16qjmJa6F",
        "expanded_url" : "http:\/\/go.wh.gov\/GA8WC2",
        "display_url" : "go.wh.gov\/GA8WC2"
      } ]
    },
    "geo" : { },
    "id_str" : "577916280042352640",
    "text" : "\u2708 Wheels up! \u2708\nFollow along with the First Lady's trip to Japan and Cambodia: http:\/\/t.co\/Y16qjmJa6F #LetGirlsLearn http:\/\/t.co\/lAdlJbCwhL",
    "id" : 577916280042352640,
    "created_at" : "2015-03-17 19:35:52 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 577917945311064064,
  "created_at" : "2015-03-17 19:42:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/577903932120424448\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/tf7jlfgVWN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAUgOYrUQAAVfFd.jpg",
      "id_str" : "577903558701367296",
      "id" : 577903558701367296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAUgOYrUQAAVfFd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tf7jlfgVWN"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/1braHBsHtV",
      "expanded_url" : "http:\/\/go.wh.gov\/jAnLL5",
      "display_url" : "go.wh.gov\/jAnLL5"
    } ]
  },
  "geo" : { },
  "id_str" : "577903932120424448",
  "text" : "FACT: Wind energy has the potential to support 600,000 jobs by 2050 \u2192 http:\/\/t.co\/1braHBsHtV #ActOnClimate http:\/\/t.co\/tf7jlfgVWN",
  "id" : 577903932120424448,
  "created_at" : "2015-03-17 18:46:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 3, 14 ],
      "id_str" : "44615672",
      "id" : 44615672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trade",
      "indices" : [ 27, 33 ]
    }, {
      "text" : "WorkersFirst",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/gkGUM7eWxY",
      "expanded_url" : "http:\/\/t.usnews.com\/Z7paox",
      "display_url" : "t.usnews.com\/Z7paox"
    } ]
  },
  "geo" : { },
  "id_str" : "577892518714556416",
  "text" : "RT @USTradeRep: How modern #trade deals can deliver for American workers and the middle class: http:\/\/t.co\/gkGUM7eWxY #WorkersFirst http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USTradeRep\/status\/577891903741378560\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/1nd4CTepcW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAUVnzlVIAAuxCB.jpg",
        "id_str" : "577891900792840192",
        "id" : 577891900792840192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAUVnzlVIAAuxCB.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/1nd4CTepcW"
      } ],
      "hashtags" : [ {
        "text" : "trade",
        "indices" : [ 11, 17 ]
      }, {
        "text" : "WorkersFirst",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/gkGUM7eWxY",
        "expanded_url" : "http:\/\/t.usnews.com\/Z7paox",
        "display_url" : "t.usnews.com\/Z7paox"
      } ]
    },
    "geo" : { },
    "id_str" : "577891903741378560",
    "text" : "How modern #trade deals can deliver for American workers and the middle class: http:\/\/t.co\/gkGUM7eWxY #WorkersFirst http:\/\/t.co\/1nd4CTepcW",
    "id" : 577891903741378560,
    "created_at" : "2015-03-17 17:59:01 +0000",
    "user" : {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "protected" : false,
      "id_str" : "44615672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662636758509596672\/O-ShXHZB_normal.png",
      "id" : 44615672,
      "verified" : true
    }
  },
  "id" : 577892518714556416,
  "created_at" : "2015-03-17 18:01:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/577874430149455872\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/0k0phjyyTu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAUFroAUcAAt_JU.jpg",
      "id_str" : "577874374218248192",
      "id" : 577874374218248192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAUFroAUcAAt_JU.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0k0phjyyTu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577874430149455872",
  "text" : "Thanks to the ACA:\n16.4 million more Americans have health coverage \u2713\nThe uninsured rate = \u2193 35% since October 2013 http:\/\/t.co\/0k0phjyyTu",
  "id" : 577874430149455872,
  "created_at" : "2015-03-17 16:49:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/577845669714513920\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/ngf50W4Ntu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CATrIQyUkAEV5uS.jpg",
      "id_str" : "577845179387777025",
      "id" : 577845179387777025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CATrIQyUkAEV5uS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ngf50W4Ntu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577845669714513920",
  "text" : "President O'bama is ready for St. Patrick's Day. http:\/\/t.co\/ngf50W4Ntu",
  "id" : 577845669714513920,
  "created_at" : "2015-03-17 14:55:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VICE News",
      "screen_name" : "vicenews",
      "indices" : [ 30, 39 ],
      "id_str" : "1630896181",
      "id" : 1630896181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/klSeXjw4QV",
      "expanded_url" : "https:\/\/youtu.be\/2a01Rg2g2Z8",
      "display_url" : "youtu.be\/2a01Rg2g2Z8"
    } ]
  },
  "geo" : { },
  "id_str" : "577586489036386306",
  "text" : "President Obama sat down with @ViceNews to discuss everything from climate change to foreign policy.\nWatch \u2192 https:\/\/t.co\/klSeXjw4QV",
  "id" : 577586489036386306,
  "created_at" : "2015-03-16 21:45:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VICE",
      "screen_name" : "VICE",
      "indices" : [ 3, 8 ],
      "id_str" : "23818581",
      "id" : 23818581
    }, {
      "name" : "shane smith",
      "screen_name" : "shanesmith30",
      "indices" : [ 16, 29 ],
      "id_str" : "88975905",
      "id" : 88975905
    }, {
      "name" : "VICE News",
      "screen_name" : "vicenews",
      "indices" : [ 76, 85 ],
      "id_str" : "1630896181",
      "id" : 1630896181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/s6VoWaefDp",
      "expanded_url" : "http:\/\/bit.ly\/1EkEmro",
      "display_url" : "bit.ly\/1EkEmro"
    } ]
  },
  "geo" : { },
  "id_str" : "577581668397109248",
  "text" : "RT @VICE: Watch @shanesmith30's full interview with President Obama, now on @vicenews: http:\/\/t.co\/s6VoWaefDp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "shane smith",
        "screen_name" : "shanesmith30",
        "indices" : [ 6, 19 ],
        "id_str" : "88975905",
        "id" : 88975905
      }, {
        "name" : "VICE News",
        "screen_name" : "vicenews",
        "indices" : [ 66, 75 ],
        "id_str" : "1630896181",
        "id" : 1630896181
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/s6VoWaefDp",
        "expanded_url" : "http:\/\/bit.ly\/1EkEmro",
        "display_url" : "bit.ly\/1EkEmro"
      } ]
    },
    "geo" : { },
    "id_str" : "577569110952919040",
    "text" : "Watch @shanesmith30's full interview with President Obama, now on @vicenews: http:\/\/t.co\/s6VoWaefDp",
    "id" : 577569110952919040,
    "created_at" : "2015-03-16 20:36:21 +0000",
    "user" : {
      "name" : "VICE",
      "screen_name" : "VICE",
      "protected" : false,
      "id_str" : "23818581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672036189273120768\/4_Esv2H4_normal.jpg",
      "id" : 23818581,
      "verified" : true
    }
  },
  "id" : 577581668397109248,
  "created_at" : "2015-03-16 21:26:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/577578446676729857\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Xf5xlHyJh8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAP4UWaUUAIq-Zy.jpg",
      "id_str" : "577578205730590722",
      "id" : 577578205730590722,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAP4UWaUUAIq-Zy.jpg",
      "sizes" : [ {
        "h" : 834,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 973,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 973,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Xf5xlHyJh8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/D1ElR6Z2EN",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/asked-and-answered-matthew-s-letter-to-the-president-82ca1e916662",
      "display_url" : "medium.com\/@WhiteHouse\/as\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "577578446676729857",
  "text" : "\u201CPlaying basketball in high school taught me about who I was and what I could do\" \u2014Obama: https:\/\/t.co\/D1ElR6Z2EN http:\/\/t.co\/Xf5xlHyJh8",
  "id" : 577578446676729857,
  "created_at" : "2015-03-16 21:13:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VICE News",
      "screen_name" : "vicenews",
      "indices" : [ 3, 12 ],
      "id_str" : "1630896181",
      "id" : 1630896181
    }, {
      "name" : "shane smith",
      "screen_name" : "shanesmith30",
      "indices" : [ 15, 28 ],
      "id_str" : "88975905",
      "id" : 88975905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/90ftf50hnp",
      "expanded_url" : "http:\/\/bit.ly\/1EWe8k3",
      "display_url" : "bit.ly\/1EWe8k3"
    } ]
  },
  "geo" : { },
  "id_str" : "577571094808285184",
  "text" : "RT @vicenews: .@shanesmith30 sits with President Obama to talk about everything from the climate to Iran: http:\/\/t.co\/90ftf50hnp http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "shane smith",
        "screen_name" : "shanesmith30",
        "indices" : [ 1, 14 ],
        "id_str" : "88975905",
        "id" : 88975905
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vicenews\/status\/577568626447900672\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/e5M9w89luP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAPvmuOU8AAKkgU.jpg",
        "id_str" : "577568625755746304",
        "id" : 577568625755746304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAPvmuOU8AAKkgU.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/e5M9w89luP"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/90ftf50hnp",
        "expanded_url" : "http:\/\/bit.ly\/1EWe8k3",
        "display_url" : "bit.ly\/1EWe8k3"
      } ]
    },
    "geo" : { },
    "id_str" : "577568626447900672",
    "text" : ".@shanesmith30 sits with President Obama to talk about everything from the climate to Iran: http:\/\/t.co\/90ftf50hnp http:\/\/t.co\/e5M9w89luP",
    "id" : 577568626447900672,
    "created_at" : "2015-03-16 20:34:25 +0000",
    "user" : {
      "name" : "VICE News",
      "screen_name" : "vicenews",
      "protected" : false,
      "id_str" : "1630896181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785208513177985024\/Guc3ohmz_normal.jpg",
      "id" : 1630896181,
      "verified" : true
    }
  },
  "id" : 577571094808285184,
  "created_at" : "2015-03-16 20:44:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577562761468624896",
  "text" : "RT @VP: With Teddy, it was always about serving others. On 3\/30, VP Biden will help dedicate the Edward Kennedy Institute. http:\/\/t.co\/PF4D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/577560300104343553\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/PF4DoTmaa9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAPoB_VUkAAf2Wx.jpg",
        "id_str" : "577560298111930368",
        "id" : 577560298111930368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAPoB_VUkAAf2Wx.jpg",
        "sizes" : [ {
          "h" : 1403,
          "resize" : "fit",
          "w" : 1098
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1308,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/PF4DoTmaa9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "577560300104343553",
    "text" : "With Teddy, it was always about serving others. On 3\/30, VP Biden will help dedicate the Edward Kennedy Institute. http:\/\/t.co\/PF4DoTmaa9",
    "id" : 577560300104343553,
    "created_at" : "2015-03-16 20:01:20 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 577562761468624896,
  "created_at" : "2015-03-16 20:11:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/577558272699293697\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ePwwmpSZ1C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAPkO9XUwAAO8JA.jpg",
      "id_str" : "577556122875248640",
      "id" : 577556122875248640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAPkO9XUwAAO8JA.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ePwwmpSZ1C"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/3bvB2QSEux",
      "expanded_url" : "http:\/\/bit.ly\/1Eqt2MO",
      "display_url" : "bit.ly\/1Eqt2MO"
    } ]
  },
  "geo" : { },
  "id_str" : "577558272699293697",
  "text" : "FACT: The uninsured rate has dropped by 35% since October 2013 \u2192 http:\/\/t.co\/3bvB2QSEux #ACAWorks http:\/\/t.co\/ePwwmpSZ1C",
  "id" : 577558272699293697,
  "created_at" : "2015-03-16 19:53:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/577545592827580416\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/QwsfcrtSPX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAPZoD6UcAAg4Kl.jpg",
      "id_str" : "577544459501465600",
      "id" : 577544459501465600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAPZoD6UcAAg4Kl.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QwsfcrtSPX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577545592827580416",
  "text" : "The work goes on.\nThe cause endures.\nThe hope still lives.\nAnd the dream shall never die. http:\/\/t.co\/QwsfcrtSPX",
  "id" : 577545592827580416,
  "created_at" : "2015-03-16 19:02:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/577541217396748288\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/X3QAQCiEbB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAPWoShUgAAHwnU.jpg",
      "id_str" : "577541164888260608",
      "id" : 577541164888260608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAPWoShUgAAHwnU.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/X3QAQCiEbB"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577541217396748288",
  "text" : "RT to spread the word: 16.4 million Americans have gained health coverage under the Affordable Care Act. #ACAWorks http:\/\/t.co\/X3QAQCiEbB",
  "id" : 577541217396748288,
  "created_at" : "2015-03-16 18:45:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "indices" : [ 29, 35 ],
      "id_str" : "2888895350",
      "id" : 2888895350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSW",
      "indices" : [ 82, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/7d1cOZ9p00",
      "expanded_url" : "http:\/\/sxsw.com\/live",
      "display_url" : "sxsw.com\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "577524467275972608",
  "text" : "RT @OMBPress: Happening now! @USCTO Megan Smith talks \"How Innovation Happens\" at #SXSW watch live: http:\/\/t.co\/7d1cOZ9p00 http:\/\/t.co\/CcqY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Megan Smith",
        "screen_name" : "USCTO",
        "indices" : [ 15, 21 ],
        "id_str" : "2888895350",
        "id" : 2888895350
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OMBPress\/status\/577524093391523840\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/CcqY2zE7tT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAPHBrrU8AASjEs.jpg",
        "id_str" : "577524008951803904",
        "id" : 577524008951803904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAPHBrrU8AASjEs.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/CcqY2zE7tT"
      } ],
      "hashtags" : [ {
        "text" : "SXSW",
        "indices" : [ 68, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/7d1cOZ9p00",
        "expanded_url" : "http:\/\/sxsw.com\/live",
        "display_url" : "sxsw.com\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "577524093391523840",
    "text" : "Happening now! @USCTO Megan Smith talks \"How Innovation Happens\" at #SXSW watch live: http:\/\/t.co\/7d1cOZ9p00 http:\/\/t.co\/CcqY2zE7tT",
    "id" : 577524093391523840,
    "created_at" : "2015-03-16 17:37:28 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 577524467275972608,
  "created_at" : "2015-03-16 17:38:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/577516690663178241\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/7Ts6Jv2XLx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAPANcnUwAANTd2.jpg",
      "id_str" : "577516514485518336",
      "id" : 577516514485518336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAPANcnUwAANTd2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7Ts6Jv2XLx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/2VtyhRCInc",
      "expanded_url" : "http:\/\/go.wh.gov\/GLKX8Z",
      "display_url" : "go.wh.gov\/GLKX8Z"
    } ]
  },
  "geo" : { },
  "id_str" : "577516690663178241",
  "text" : "President Obama's trade deal will help tackle illegal fishing and protect our environment \u2192 http:\/\/t.co\/2VtyhRCInc http:\/\/t.co\/7Ts6Jv2XLx",
  "id" : 577516690663178241,
  "created_at" : "2015-03-16 17:08:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 58, 66 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/577508531869356033\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/pKNVqMokYz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAO44RtVIAE6Cy9.jpg",
      "id_str" : "577508454199271425",
      "id" : 577508454199271425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAO44RtVIAE6Cy9.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pKNVqMokYz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/AhPrrxH7yx",
      "expanded_url" : "http:\/\/go.wh.gov\/F88Ewk",
      "display_url" : "go.wh.gov\/F88Ewk"
    } ]
  },
  "geo" : { },
  "id_str" : "577508531869356033",
  "text" : "\"The deficit is falling at the fastest rate in decades.\" \u2014@Deese44: http:\/\/t.co\/AhPrrxH7yx http:\/\/t.co\/pKNVqMokYz",
  "id" : 577508531869356033,
  "created_at" : "2015-03-16 16:35:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 85, 93 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/577492220481118208\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/jYanPwH2ug",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAOqDBcUYAEp5UW.jpg",
      "id_str" : "577492146137096193",
      "id" : 577492146137096193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAOqDBcUYAEp5UW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jYanPwH2ug"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/AhPrrxH7yx",
      "expanded_url" : "http:\/\/go.wh.gov\/F88Ewk",
      "display_url" : "go.wh.gov\/F88Ewk"
    } ]
  },
  "geo" : { },
  "id_str" : "577492220481118208",
  "text" : "\"The economy performs best when the benefits of economic growth are broadly shared\" \u2014@Deese44: http:\/\/t.co\/AhPrrxH7yx http:\/\/t.co\/jYanPwH2ug",
  "id" : 577492220481118208,
  "created_at" : "2015-03-16 15:30:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 14, 22 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/577485517622808576\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Bgh9MRHfq6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAOi770VEAACvY9.jpg",
      "id_str" : "577484327786713088",
      "id" : 577484327786713088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAOi770VEAACvY9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Bgh9MRHfq6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/AhPrrxpwGZ",
      "expanded_url" : "http:\/\/go.wh.gov\/F88Ewk",
      "display_url" : "go.wh.gov\/F88Ewk"
    } ]
  },
  "geo" : { },
  "id_str" : "577485517622808576",
  "text" : "Worth a read: @Deese44 on how President Obama is building on a uniquely American recovery \u2192 http:\/\/t.co\/AhPrrxpwGZ http:\/\/t.co\/Bgh9MRHfq6",
  "id" : 577485517622808576,
  "created_at" : "2015-03-16 15:04:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "VICE News",
      "screen_name" : "vicenews",
      "indices" : [ 47, 56 ],
      "id_str" : "1630896181",
      "id" : 1630896181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/UNCfIZvYu8",
      "expanded_url" : "http:\/\/bit.ly\/1BhCUUt",
      "display_url" : "bit.ly\/1BhCUUt"
    } ]
  },
  "geo" : { },
  "id_str" : "577468756575805440",
  "text" : "RT @Simas44: Make sure you check out the POTUS @vicenews interview that posts today. Here's a sneak peek. http:\/\/t.co\/UNCfIZvYu8 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "VICE News",
        "screen_name" : "vicenews",
        "indices" : [ 34, 43 ],
        "id_str" : "1630896181",
        "id" : 1630896181
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Simas44\/status\/577468481542569986\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/JRF0yPNKYl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAOUhMmWsAEXCZL.jpg",
        "id_str" : "577468475272245249",
        "id" : 577468475272245249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAOUhMmWsAEXCZL.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/JRF0yPNKYl"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/UNCfIZvYu8",
        "expanded_url" : "http:\/\/bit.ly\/1BhCUUt",
        "display_url" : "bit.ly\/1BhCUUt"
      } ]
    },
    "geo" : { },
    "id_str" : "577468481542569986",
    "text" : "Make sure you check out the POTUS @vicenews interview that posts today. Here's a sneak peek. http:\/\/t.co\/UNCfIZvYu8 http:\/\/t.co\/JRF0yPNKYl",
    "id" : 577468481542569986,
    "created_at" : "2015-03-16 13:56:29 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 577468756575805440,
  "created_at" : "2015-03-16 13:57:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/575441837969698817\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/J9ZZL5NuCc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_xhGMCUwAElOYz.jpg",
      "id_str" : "575441611334664193",
      "id" : 575441611334664193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_xhGMCUwAElOYz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/J9ZZL5NuCc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/IgEiBaTpny",
      "expanded_url" : "http:\/\/WhiteHouse.gov\/CollegeOpportunity",
      "display_url" : "WhiteHouse.gov\/CollegeOpportu\u2026"
    }, {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/GZtlN1DYPW",
      "expanded_url" : "http:\/\/go.wh.gov\/PoAkQW",
      "display_url" : "go.wh.gov\/PoAkQW"
    } ]
  },
  "geo" : { },
  "id_str" : "577241921837359105",
  "text" : "\"I\u2019m asking you to visit http:\/\/t.co\/IgEiBaTpny. Sign your name to this declaration.\" \u2014Obama: http:\/\/t.co\/GZtlN1DYPW http:\/\/t.co\/J9ZZL5NuCc",
  "id" : 577241921837359105,
  "created_at" : "2015-03-15 22:56:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/575358093342699520\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/HEk1PA8nhb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wVHYOUIAAUxrg.jpg",
      "id_str" : "575358068902338560",
      "id" : 575358068902338560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wVHYOUIAAUxrg.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HEk1PA8nhb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/GZtlN1DYPW",
      "expanded_url" : "http:\/\/go.wh.gov\/PoAkQW",
      "display_url" : "go.wh.gov\/PoAkQW"
    } ]
  },
  "geo" : { },
  "id_str" : "577213977479884800",
  "text" : "\"I\u2019ve sent Congress my plan to bring the cost of community college down to zero.\" \u2014Obama: http:\/\/t.co\/GZtlN1DYPW http:\/\/t.co\/HEk1PA8nhb",
  "id" : 577213977479884800,
  "created_at" : "2015-03-15 21:05:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575358093342699520\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/HEk1PA8nhb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wVHYOUIAAUxrg.jpg",
      "id_str" : "575358068902338560",
      "id" : 575358068902338560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wVHYOUIAAUxrg.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HEk1PA8nhb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/GZtlN1DYPW",
      "expanded_url" : "http:\/\/go.wh.gov\/PoAkQW",
      "display_url" : "go.wh.gov\/PoAkQW"
    } ]
  },
  "geo" : { },
  "id_str" : "577201650529497089",
  "text" : "\"Two years of higher education should be as free &amp; universal as high school is today.\" \u2014Obama: http:\/\/t.co\/GZtlN1DYPW http:\/\/t.co\/HEk1PA8nhb",
  "id" : 577201650529497089,
  "created_at" : "2015-03-15 20:16:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 111, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/GZtlN1DYPW",
      "expanded_url" : "http:\/\/go.wh.gov\/PoAkQW",
      "display_url" : "go.wh.gov\/PoAkQW"
    } ]
  },
  "geo" : { },
  "id_str" : "577185550014136320",
  "text" : "\"A higher education cannot be a privilege reserved for only the few.\" \u2014President Obama: http:\/\/t.co\/GZtlN1DYPW #CollegeOpportunity",
  "id" : 577185550014136320,
  "created_at" : "2015-03-15 19:12:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575357438481694720\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/tAP6w2LvzC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wUf29UgAAIbvo.jpg",
      "id_str" : "575357389957791744",
      "id" : 575357389957791744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wUf29UgAAIbvo.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tAP6w2LvzC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/GZtlN1DYPW",
      "expanded_url" : "http:\/\/go.wh.gov\/PoAkQW",
      "display_url" : "go.wh.gov\/PoAkQW"
    } ]
  },
  "geo" : { },
  "id_str" : "577168912241942529",
  "text" : "\"We\u2019ve acted to let millions of graduates cap loan payments at 10% of their income\" \u2014Obama: http:\/\/t.co\/GZtlN1DYPW http:\/\/t.co\/tAP6w2LvzC",
  "id" : 577168912241942529,
  "created_at" : "2015-03-15 18:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/GZtlN1mnYo",
      "expanded_url" : "http:\/\/go.wh.gov\/PoAkQW",
      "display_url" : "go.wh.gov\/PoAkQW"
    } ]
  },
  "geo" : { },
  "id_str" : "577153167739240448",
  "text" : "\"We expanded tax credits and Pell Grants, enacted the largest reform to student loan programs in history\" \u2014Obama: http:\/\/t.co\/GZtlN1mnYo",
  "id" : 577153167739240448,
  "created_at" : "2015-03-15 17:03:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/GZtlN1DYPW",
      "expanded_url" : "http:\/\/go.wh.gov\/PoAkQW",
      "display_url" : "go.wh.gov\/PoAkQW"
    } ]
  },
  "geo" : { },
  "id_str" : "576872746002427904",
  "text" : "\"In an economy increasingly built on innovation, the most important skill you can sell is your knowledge.\" \u2014Obama: http:\/\/t.co\/GZtlN1DYPW",
  "id" : 576872746002427904,
  "created_at" : "2015-03-14 22:29:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575441837969698817\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/J9ZZL5NuCc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_xhGMCUwAElOYz.jpg",
      "id_str" : "575441611334664193",
      "id" : 575441611334664193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_xhGMCUwAElOYz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/J9ZZL5NuCc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/GZtlN1DYPW",
      "expanded_url" : "http:\/\/go.wh.gov\/PoAkQW",
      "display_url" : "go.wh.gov\/PoAkQW"
    } ]
  },
  "geo" : { },
  "id_str" : "576857347122851840",
  "text" : "\"Every student should be able to access the resources to pay for college.\" \u2014President Obama: http:\/\/t.co\/GZtlN1DYPW http:\/\/t.co\/J9ZZL5NuCc",
  "id" : 576857347122851840,
  "created_at" : "2015-03-14 21:28:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575441837969698817\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/J9ZZL5NuCc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_xhGMCUwAElOYz.jpg",
      "id_str" : "575441611334664193",
      "id" : 575441611334664193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_xhGMCUwAElOYz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/J9ZZL5NuCc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/GZtlN1DYPW",
      "expanded_url" : "http:\/\/go.wh.gov\/PoAkQW",
      "display_url" : "go.wh.gov\/PoAkQW"
    } ]
  },
  "geo" : { },
  "id_str" : "576836472042450946",
  "text" : "\"Every student deserves access to a quality, affordable education.\" \u2014President Obama: http:\/\/t.co\/GZtlN1DYPW http:\/\/t.co\/J9ZZL5NuCc",
  "id" : 576836472042450946,
  "created_at" : "2015-03-14 20:05:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 119, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/GZtlN1DYPW",
      "expanded_url" : "http:\/\/go.wh.gov\/PoAkQW",
      "display_url" : "go.wh.gov\/PoAkQW"
    } ]
  },
  "geo" : { },
  "id_str" : "576813808192131072",
  "text" : "\"Higher education is, more than ever, the surest ticket to the middle class.\" \u2014President Obama: http:\/\/t.co\/GZtlN1DYPW #CollegeOpportunity",
  "id" : 576813808192131072,
  "created_at" : "2015-03-14 18:35:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/576795719530602497\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/AbTlNxVJNi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAEwlqOUcAEHD4N.jpg",
      "id_str" : "576795650827776001",
      "id" : 576795650827776001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAEwlqOUcAEHD4N.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AbTlNxVJNi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/iqH1kQ5wKI",
      "expanded_url" : "http:\/\/wh.gov\/iDFzd",
      "display_url" : "wh.gov\/iDFzd"
    } ]
  },
  "geo" : { },
  "id_str" : "576795719530602497",
  "text" : "3.141592653589793238462643383279502884197169399375105820974944592307816406286\n\nHappy Pi Day! http:\/\/t.co\/iqH1kQ5wKI http:\/\/t.co\/AbTlNxVJNi",
  "id" : 576795719530602497,
  "created_at" : "2015-03-14 17:23:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "GlacierNationalPark",
      "screen_name" : "GlacierNPS",
      "indices" : [ 71, 82 ],
      "id_str" : "32887168",
      "id" : 32887168
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/576523841435996160\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/tFPSwgxEGi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CAA5WbWUcAAzh66.jpg",
      "id_str" : "576523809764700160",
      "id" : 576523809764700160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAA5WbWUcAAzh66.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tFPSwgxEGi"
    } ],
    "hashtags" : [ {
      "text" : "Montana",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576524087956127744",
  "text" : "RT @Interior: Imagine waking up to the this spectacular view every day @GlacierNPS in #Montana http:\/\/t.co\/tFPSwgxEGi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GlacierNationalPark",
        "screen_name" : "GlacierNPS",
        "indices" : [ 57, 68 ],
        "id_str" : "32887168",
        "id" : 32887168
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/576523841435996160\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/tFPSwgxEGi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAA5WbWUcAAzh66.jpg",
        "id_str" : "576523809764700160",
        "id" : 576523809764700160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAA5WbWUcAAzh66.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tFPSwgxEGi"
      } ],
      "hashtags" : [ {
        "text" : "Montana",
        "indices" : [ 72, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "576523841435996160",
    "text" : "Imagine waking up to the this spectacular view every day @GlacierNPS in #Montana http:\/\/t.co\/tFPSwgxEGi",
    "id" : 576523841435996160,
    "created_at" : "2015-03-13 23:22:49 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 576524087956127744,
  "created_at" : "2015-03-13 23:23:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 93, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/gpP3sNFoEs",
      "expanded_url" : "http:\/\/wpo.st\/uqX80",
      "display_url" : "wpo.st\/uqX80"
    } ]
  },
  "geo" : { },
  "id_str" : "576508823420182528",
  "text" : "RT @lacasablanca: Why pro-immigration states are fighting back in support of the President's #ImmigrationAction: http:\/\/t.co\/gpP3sNFoEs htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/576475689198600192\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/DGvo03rhWH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAANlY4UwAAdLs8.jpg",
        "id_str" : "576475688288436224",
        "id" : 576475688288436224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAANlY4UwAAdLs8.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DGvo03rhWH"
      } ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 75, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/gpP3sNFoEs",
        "expanded_url" : "http:\/\/wpo.st\/uqX80",
        "display_url" : "wpo.st\/uqX80"
      } ]
    },
    "geo" : { },
    "id_str" : "576475689198600192",
    "text" : "Why pro-immigration states are fighting back in support of the President's #ImmigrationAction: http:\/\/t.co\/gpP3sNFoEs http:\/\/t.co\/DGvo03rhWH",
    "id" : 576475689198600192,
    "created_at" : "2015-03-13 20:11:29 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 576508823420182528,
  "created_at" : "2015-03-13 22:23:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576507117147803648",
  "text" : "RT @Simas44: POTUS surprises American hero Cory Remsburg at his new home. Thank you for your service Sergeant First Class Remsburg http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/576497054068834304\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/egDMP8ih85",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CAAhBB_UMAAubxE.jpg",
        "id_str" : "576497053901008896",
        "id" : 576497053901008896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CAAhBB_UMAAubxE.jpg",
        "sizes" : [ {
          "h" : 852,
          "resize" : "fit",
          "w" : 1136
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/egDMP8ih85"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "576497054068834304",
    "text" : "POTUS surprises American hero Cory Remsburg at his new home. Thank you for your service Sergeant First Class Remsburg http:\/\/t.co\/egDMP8ih85",
    "id" : 576497054068834304,
    "created_at" : "2015-03-13 21:36:23 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 576507117147803648,
  "created_at" : "2015-03-13 22:16:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 104, 111 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/xurqnZhTt0",
      "expanded_url" : "http:\/\/vine.co\/v\/O9TEhID2O2U",
      "display_url" : "vine.co\/v\/O9TEhID2O2U"
    } ]
  },
  "geo" : { },
  "id_str" : "576458086249951232",
  "text" : "RT @VP: A million arm curls \u2713\nCalls with world leaders \u2713\nAll in a day's work.\nWatch VP Biden respond to @FLOTUS: http:\/\/t.co\/xurqnZhTt0 #Gi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 96, 103 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GimmeFive",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/xurqnZhTt0",
        "expanded_url" : "http:\/\/vine.co\/v\/O9TEhID2O2U",
        "display_url" : "vine.co\/v\/O9TEhID2O2U"
      } ]
    },
    "geo" : { },
    "id_str" : "576457578756046850",
    "text" : "A million arm curls \u2713\nCalls with world leaders \u2713\nAll in a day's work.\nWatch VP Biden respond to @FLOTUS: http:\/\/t.co\/xurqnZhTt0 #GimmeFive",
    "id" : 576457578756046850,
    "created_at" : "2015-03-13 18:59:31 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 576458086249951232,
  "created_at" : "2015-03-13 19:01:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/576441604556374017\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/KQ0sETElmh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B__ud-cUYAEYp0y.jpg",
      "id_str" : "576441476072103937",
      "id" : 576441476072103937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B__ud-cUYAEYp0y.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KQ0sETElmh"
    } ],
    "hashtags" : [ {
      "text" : "WorkersFirst",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/9Li1HCfxMV",
      "expanded_url" : "http:\/\/wpo.st\/ooW80",
      "display_url" : "wpo.st\/ooW80"
    } ]
  },
  "geo" : { },
  "id_str" : "576441604556374017",
  "text" : "President Obama is fighting for a trade deal that protects American workers \u2192 http:\/\/t.co\/9Li1HCfxMV #WorkersFirst http:\/\/t.co\/KQ0sETElmh",
  "id" : 576441604556374017,
  "created_at" : "2015-03-13 17:56:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmy Kimmel Live",
      "screen_name" : "JimmyKimmelLive",
      "indices" : [ 98, 114 ],
      "id_str" : "34036028",
      "id" : 34036028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/oizDUEFw8V",
      "expanded_url" : "https:\/\/youtu.be\/RDocnbkHjhI",
      "display_url" : "youtu.be\/RDocnbkHjhI"
    } ]
  },
  "geo" : { },
  "id_str" : "576420057216995328",
  "text" : "\"You know, the 'LOL' is redundant when you have the 'haha.'\"\nPresident Obama reads Mean Tweets on @JimmyKimmelLive \u2192 https:\/\/t.co\/oizDUEFw8V",
  "id" : 576420057216995328,
  "created_at" : "2015-03-13 16:30:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "indices" : [ 3, 9 ],
      "id_str" : "390320946",
      "id" : 390320946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/lSQiTbLlw4",
      "expanded_url" : "http:\/\/wpo.st\/ooW80",
      "display_url" : "wpo.st\/ooW80"
    } ]
  },
  "geo" : { },
  "id_str" : "576416231370022912",
  "text" : "RT @WHWeb: President Obama's trade deal would help preserve a free and open internet for our businesses\u2192 http:\/\/t.co\/lSQiTbLlw4 http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHWeb\/status\/576414291219193857\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Iz42BuNlIC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B__VvkBUcAAs5OJ.jpg",
        "id_str" : "576414290426490880",
        "id" : 576414290426490880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B__VvkBUcAAs5OJ.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Iz42BuNlIC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/lSQiTbLlw4",
        "expanded_url" : "http:\/\/wpo.st\/ooW80",
        "display_url" : "wpo.st\/ooW80"
      } ]
    },
    "geo" : { },
    "id_str" : "576414291219193857",
    "text" : "President Obama's trade deal would help preserve a free and open internet for our businesses\u2192 http:\/\/t.co\/lSQiTbLlw4 http:\/\/t.co\/Iz42BuNlIC",
    "id" : 576414291219193857,
    "created_at" : "2015-03-13 16:07:30 +0000",
    "user" : {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "protected" : false,
      "id_str" : "390320946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618051538582310913\/0xcdHiQS_normal.jpg",
      "id" : 390320946,
      "verified" : true
    }
  },
  "id" : 576416231370022912,
  "created_at" : "2015-03-13 16:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/576404624137175040\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/cKJ0LsZGbE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B__M7OjUUAEEfAG.jpg",
      "id_str" : "576404595217289217",
      "id" : 576404595217289217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B__M7OjUUAEEfAG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cKJ0LsZGbE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/9Li1HCfxMV",
      "expanded_url" : "http:\/\/wpo.st\/ooW80",
      "display_url" : "wpo.st\/ooW80"
    } ]
  },
  "geo" : { },
  "id_str" : "576404624137175040",
  "text" : "Here's why President Obama's key trade deal with Asia would be good for American workers \u2192 http:\/\/t.co\/9Li1HCfxMV http:\/\/t.co\/cKJ0LsZGbE",
  "id" : 576404624137175040,
  "created_at" : "2015-03-13 15:29:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/576372092742082560\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/fUjHKWMuRV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_-vXRMWYAEqEEF.jpg",
      "id_str" : "576372091613765633",
      "id" : 576372091613765633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_-vXRMWYAEqEEF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fUjHKWMuRV"
    } ],
    "hashtags" : [ {
      "text" : "WHScienceFair",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/4ZbovGEZ7m",
      "expanded_url" : "http:\/\/wh.gov\/iDfQU",
      "display_url" : "wh.gov\/iDfQU"
    } ]
  },
  "geo" : { },
  "id_str" : "576378690419974144",
  "text" : "RT @whitehouseostp: Announcing the 5th White House Science Fair! March 23. http:\/\/t.co\/4ZbovGEZ7m #WHScienceFair http:\/\/t.co\/fUjHKWMuRV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/576372092742082560\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/fUjHKWMuRV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_-vXRMWYAEqEEF.jpg",
        "id_str" : "576372091613765633",
        "id" : 576372091613765633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_-vXRMWYAEqEEF.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/fUjHKWMuRV"
      } ],
      "hashtags" : [ {
        "text" : "WHScienceFair",
        "indices" : [ 78, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/4ZbovGEZ7m",
        "expanded_url" : "http:\/\/wh.gov\/iDfQU",
        "display_url" : "wh.gov\/iDfQU"
      } ]
    },
    "geo" : { },
    "id_str" : "576372092742082560",
    "text" : "Announcing the 5th White House Science Fair! March 23. http:\/\/t.co\/4ZbovGEZ7m #WHScienceFair http:\/\/t.co\/fUjHKWMuRV",
    "id" : 576372092742082560,
    "created_at" : "2015-03-13 13:19:50 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 576378690419974144,
  "created_at" : "2015-03-13 13:46:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VICE News",
      "screen_name" : "vicenews",
      "indices" : [ 3, 12 ],
      "id_str" : "1630896181",
      "id" : 1630896181
    }, {
      "name" : "shane smith",
      "screen_name" : "shanesmith30",
      "indices" : [ 37, 50 ],
      "id_str" : "88975905",
      "id" : 88975905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/CCZ0ra0LAu",
      "expanded_url" : "http:\/\/bit.ly\/1AjFNVr",
      "display_url" : "bit.ly\/1AjFNVr"
    } ]
  },
  "geo" : { },
  "id_str" : "576377334879502337",
  "text" : "RT @vicenews: Here's a sneak peek at @shanesmith30's interview with President Obama coming Monday: http:\/\/t.co\/CCZ0ra0LAu http:\/\/t.co\/RSoQ4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "shane smith",
        "screen_name" : "shanesmith30",
        "indices" : [ 23, 36 ],
        "id_str" : "88975905",
        "id" : 88975905
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vicenews\/status\/576370776753987584\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/RSoQ4WwaCp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_-uKsrUUAAdiB_.jpg",
        "id_str" : "576370776141484032",
        "id" : 576370776141484032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_-uKsrUUAAdiB_.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RSoQ4WwaCp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/CCZ0ra0LAu",
        "expanded_url" : "http:\/\/bit.ly\/1AjFNVr",
        "display_url" : "bit.ly\/1AjFNVr"
      } ]
    },
    "geo" : { },
    "id_str" : "576370776753987584",
    "text" : "Here's a sneak peek at @shanesmith30's interview with President Obama coming Monday: http:\/\/t.co\/CCZ0ra0LAu http:\/\/t.co\/RSoQ4WwaCp",
    "id" : 576370776753987584,
    "created_at" : "2015-03-13 13:14:36 +0000",
    "user" : {
      "name" : "VICE News",
      "screen_name" : "vicenews",
      "protected" : false,
      "id_str" : "1630896181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785208513177985024\/Guc3ohmz_normal.jpg",
      "id" : 1630896181,
      "verified" : true
    }
  },
  "id" : 576377334879502337,
  "created_at" : "2015-03-13 13:40:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "NASA MMS #MagRecon",
      "screen_name" : "NASA_MMS",
      "indices" : [ 39, 48 ],
      "id_str" : "243362336",
      "id" : 243362336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MagRecon",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/TZKSZMQKkm",
      "expanded_url" : "http:\/\/1.usa.gov\/AN75",
      "display_url" : "1.usa.gov\/AN75"
    } ]
  },
  "geo" : { },
  "id_str" : "576172359494676480",
  "text" : "RT @NASA: LIVE NOW: Launch Coverage of @NASA_MMS is now on NASA TV, set to launch at 10:44p ET\nhttp:\/\/t.co\/TZKSZMQKkm\n#MagRecon http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA MMS #MagRecon",
        "screen_name" : "NASA_MMS",
        "indices" : [ 29, 38 ],
        "id_str" : "243362336",
        "id" : 243362336
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/576171364178092032\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xxEU6UXdAM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_74wycUQAE6Vqn.jpg",
        "id_str" : "576171319407951873",
        "id" : 576171319407951873,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_74wycUQAE6Vqn.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xxEU6UXdAM"
      } ],
      "hashtags" : [ {
        "text" : "MagRecon",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/TZKSZMQKkm",
        "expanded_url" : "http:\/\/1.usa.gov\/AN75",
        "display_url" : "1.usa.gov\/AN75"
      } ]
    },
    "geo" : { },
    "id_str" : "576171364178092032",
    "text" : "LIVE NOW: Launch Coverage of @NASA_MMS is now on NASA TV, set to launch at 10:44p ET\nhttp:\/\/t.co\/TZKSZMQKkm\n#MagRecon http:\/\/t.co\/xxEU6UXdAM",
    "id" : 576171364178092032,
    "created_at" : "2015-03-13 00:02:12 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 576172359494676480,
  "created_at" : "2015-03-13 00:06:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/576161379578613760\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/3EFGk1I9Fx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_7vBBMUQAADOW5.jpg",
      "id_str" : "576160603129004032",
      "id" : 576160603129004032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_7vBBMUQAADOW5.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 997,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3EFGk1I9Fx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Ff0glfFR5K",
      "expanded_url" : "http:\/\/go.wh.gov\/ibSRfH",
      "display_url" : "go.wh.gov\/ibSRfH"
    } ]
  },
  "geo" : { },
  "id_str" : "576161379578613760",
  "text" : "Good news for our oceans: President Obama is expanding sanctuaries off California's coast \u2192 http:\/\/t.co\/Ff0glfFR5K http:\/\/t.co\/3EFGk1I9Fx",
  "id" : 576161379578613760,
  "created_at" : "2015-03-12 23:22:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/576147554771058688\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/cWx2G9IFoe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_7jEFKVEAAs0Lm.jpg",
      "id_str" : "576147461594484736",
      "id" : 576147461594484736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_7jEFKVEAAs0Lm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cWx2G9IFoe"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/1braHBsHtV",
      "expanded_url" : "http:\/\/go.wh.gov\/jAnLL5",
      "display_url" : "go.wh.gov\/jAnLL5"
    } ]
  },
  "geo" : { },
  "id_str" : "576147554771058688",
  "text" : "FACT: The wind energy industry could support 600,000 jobs by 2050 \u2192 http:\/\/t.co\/1braHBsHtV #ActOnClimate http:\/\/t.co\/cWx2G9IFoe",
  "id" : 576147554771058688,
  "created_at" : "2015-03-12 22:27:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/576109563948171264\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/0pDFilkZZu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_7AYXPU8AAaVtd.jpg",
      "id_str" : "576109327137697792",
      "id" : 576109327137697792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_7AYXPU8AAaVtd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0pDFilkZZu"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/1braHBsHtV",
      "expanded_url" : "http:\/\/go.wh.gov\/jAnLL5",
      "display_url" : "go.wh.gov\/jAnLL5"
    } ]
  },
  "geo" : { },
  "id_str" : "576109563948171264",
  "text" : "Here's how wind power can help us create jobs and #ActOnClimate \u2192 http:\/\/t.co\/1braHBsHtV http:\/\/t.co\/0pDFilkZZu",
  "id" : 576109563948171264,
  "created_at" : "2015-03-12 19:56:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/576094619206856704\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/o5HYLkYvoR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_6y_0KWwAEnFfU.jpg",
      "id_str" : "576094611753582593",
      "id" : 576094611753582593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_6y_0KWwAEnFfU.jpg",
      "sizes" : [ {
        "h" : 947,
        "resize" : "fit",
        "w" : 725
      }, {
        "h" : 784,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 444,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 947,
        "resize" : "fit",
        "w" : 725
      } ],
      "display_url" : "pic.twitter.com\/o5HYLkYvoR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576102803950690305",
  "text" : "RT @vj44: So many women (and men) stand on the shoulders of Rev. Barrow.  I will miss you \"Little Warrior\". http:\/\/t.co\/o5HYLkYvoR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/576094619206856704\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/o5HYLkYvoR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_6y_0KWwAEnFfU.jpg",
        "id_str" : "576094611753582593",
        "id" : 576094611753582593,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_6y_0KWwAEnFfU.jpg",
        "sizes" : [ {
          "h" : 947,
          "resize" : "fit",
          "w" : 725
        }, {
          "h" : 784,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 947,
          "resize" : "fit",
          "w" : 725
        } ],
        "display_url" : "pic.twitter.com\/o5HYLkYvoR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "576094619206856704",
    "text" : "So many women (and men) stand on the shoulders of Rev. Barrow.  I will miss you \"Little Warrior\". http:\/\/t.co\/o5HYLkYvoR",
    "id" : 576094619206856704,
    "created_at" : "2015-03-12 18:57:15 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 576102803950690305,
  "created_at" : "2015-03-12 19:29:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/576084561299394560\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/sKhJKzKMZ0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_6pZEqUYAAynAR.jpg",
      "id_str" : "576084050563063808",
      "id" : 576084050563063808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_6pZEqUYAAynAR.jpg",
      "sizes" : [ {
        "h" : 326,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sKhJKzKMZ0"
    } ],
    "hashtags" : [ {
      "text" : "WHDemoDay",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/KRSAIN4TU0",
      "expanded_url" : "http:\/\/wh.gov\/demo-day",
      "display_url" : "wh.gov\/demo-day"
    } ]
  },
  "geo" : { },
  "id_str" : "576084561299394560",
  "text" : "The first-ever #WHDemoDay will bring together entrepreneurs from across the country \u2192 http:\/\/t.co\/KRSAIN4TU0 http:\/\/t.co\/sKhJKzKMZ0",
  "id" : 576084561299394560,
  "created_at" : "2015-03-12 18:17:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ENERGY\/status\/576050232020090880\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/4KunOeShu9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_6Koj6WUAAu2ep.jpg",
      "id_str" : "576050231789375488",
      "id" : 576050231789375488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_6Koj6WUAAu2ep.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4KunOeShu9"
    } ],
    "hashtags" : [ {
      "text" : "WindVision",
      "indices" : [ 16, 27 ]
    }, {
      "text" : "wind",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "USA",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/0NuoqOe0dZ",
      "expanded_url" : "http:\/\/go.usa.gov\/3aHGW",
      "display_url" : "go.usa.gov\/3aHGW"
    } ]
  },
  "geo" : { },
  "id_str" : "576076473607409664",
  "text" : "RT @ENERGY: New #WindVision report shows big potential for #wind energy in the #USA \u2192 http:\/\/t.co\/0NuoqOe0dZ http:\/\/t.co\/4KunOeShu9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ENERGY\/status\/576050232020090880\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/4KunOeShu9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_6Koj6WUAAu2ep.jpg",
        "id_str" : "576050231789375488",
        "id" : 576050231789375488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_6Koj6WUAAu2ep.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4KunOeShu9"
      } ],
      "hashtags" : [ {
        "text" : "WindVision",
        "indices" : [ 4, 15 ]
      }, {
        "text" : "wind",
        "indices" : [ 47, 52 ]
      }, {
        "text" : "USA",
        "indices" : [ 67, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/0NuoqOe0dZ",
        "expanded_url" : "http:\/\/go.usa.gov\/3aHGW",
        "display_url" : "go.usa.gov\/3aHGW"
      } ]
    },
    "geo" : { },
    "id_str" : "576050232020090880",
    "text" : "New #WindVision report shows big potential for #wind energy in the #USA \u2192 http:\/\/t.co\/0NuoqOe0dZ http:\/\/t.co\/4KunOeShu9",
    "id" : 576050232020090880,
    "created_at" : "2015-03-12 16:00:52 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 576076473607409664,
  "created_at" : "2015-03-12 17:45:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/576058895124189184\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/oPXhsEAH4a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_6QLG1VAAAHH3t.png",
      "id_str" : "576056322837250048",
      "id" : 576056322837250048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_6QLG1VAAAHH3t.png",
      "sizes" : [ {
        "h" : 451,
        "resize" : "fit",
        "w" : 941
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 941
      } ],
      "display_url" : "pic.twitter.com\/oPXhsEAH4a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576058895124189184",
  "text" : "\"I condemn violence against any public safety officials in the strongest terms\" \u2014Attorney General Holder http:\/\/t.co\/oPXhsEAH4a",
  "id" : 576058895124189184,
  "created_at" : "2015-03-12 16:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576052412651188225",
  "text" : "Violence against police is unacceptable. Our prayers are with the officers in MO. Path to justice is one all of us must travel together. \u2013bo",
  "id" : 576052412651188225,
  "created_at" : "2015-03-12 16:09:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575794521826586624",
  "text" : "RT @PressSec: 47 Republicans sent a letter to Iran\u2019s leaders that undermines the President, see coverage from across the U.S. \u2192 https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/B82QUrr3MM",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/03\/11\/round-editorial-boards-around-country-respond-47-republican-senators",
        "display_url" : "whitehouse.gov\/blog\/2015\/03\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "575793929360121857",
    "text" : "47 Republicans sent a letter to Iran\u2019s leaders that undermines the President, see coverage from across the U.S. \u2192 https:\/\/t.co\/B82QUrr3MM",
    "id" : 575793929360121857,
    "created_at" : "2015-03-11 23:02:25 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 575794521826586624,
  "created_at" : "2015-03-11 23:04:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575780538147082242\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/0EUIj0Sgnd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_2U3_JUwAAYLjs.jpg",
      "id_str" : "575780016937549824",
      "id" : 575780016937549824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_2U3_JUwAAYLjs.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0EUIj0Sgnd"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 97, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/nr1M53ijUD",
      "expanded_url" : "http:\/\/go.wh.gov\/h1mneL",
      "display_url" : "go.wh.gov\/h1mneL"
    } ]
  },
  "geo" : { },
  "id_str" : "575780538147082242",
  "text" : "Every student deserves access to a quality, affordable higher education \u2192 http:\/\/t.co\/nr1M53ijUD #CollegeOpportunity http:\/\/t.co\/0EUIj0Sgnd",
  "id" : 575780538147082242,
  "created_at" : "2015-03-11 22:09:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 3, 11 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575778336447725568",
  "text" : "RT @Cabinet: Check out OPM\u2019s work to ensure the fed govt remains diverse and a model employer of people with disabilities at http:\/\/t.co\/ZE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/ZEumzq0GO8",
        "expanded_url" : "http:\/\/goo.gl\/2mSsK9",
        "display_url" : "goo.gl\/2mSsK9"
      } ]
    },
    "geo" : { },
    "id_str" : "575777394981666817",
    "text" : "Check out OPM\u2019s work to ensure the fed govt remains diverse and a model employer of people with disabilities at http:\/\/t.co\/ZEumzq0GO8",
    "id" : 575777394981666817,
    "created_at" : "2015-03-11 21:56:43 +0000",
    "user" : {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "protected" : false,
      "id_str" : "1854981890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000444833438\/6f96900dcf05562d4e699ae28d7861c6_normal.jpeg",
      "id" : 1854981890,
      "verified" : true
    }
  },
  "id" : 575778336447725568,
  "created_at" : "2015-03-11 22:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Diamond",
      "screen_name" : "Rob44",
      "indices" : [ 3, 9 ],
      "id_str" : "3065348142",
      "id" : 3065348142
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575766016573100032",
  "text" : "RT @Rob44: Proud to join the @WhiteHouse team and working to build an economy to last. 12 million jobs and counting... http:\/\/t.co\/UKeAwTVO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 18, 29 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Rob44\/status\/575764418996408320\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/UKeAwTVOvf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_2Gr_gVEAA-OrS.jpg",
        "id_str" : "575764417712820224",
        "id" : 575764417712820224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_2Gr_gVEAA-OrS.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/UKeAwTVOvf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "575764418996408320",
    "text" : "Proud to join the @WhiteHouse team and working to build an economy to last. 12 million jobs and counting... http:\/\/t.co\/UKeAwTVOvf",
    "id" : 575764418996408320,
    "created_at" : "2015-03-11 21:05:09 +0000",
    "user" : {
      "name" : "Rob Diamond",
      "screen_name" : "Rob44",
      "protected" : false,
      "id_str" : "3065348142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628268968214724608\/D4RYPQmQ_normal.jpg",
      "id" : 3065348142,
      "verified" : true
    }
  },
  "id" : 575766016573100032,
  "created_at" : "2015-03-11 21:11:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Today's Document",
      "screen_name" : "TodaysDocument",
      "indices" : [ 3, 18 ],
      "id_str" : "22656792",
      "id" : 22656792
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 53, 64 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "LBJ Library",
      "screen_name" : "LBJLibrary",
      "indices" : [ 124, 135 ],
      "id_str" : "113729414",
      "id" : 113729414
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sitin",
      "indices" : [ 39, 45 ]
    }, {
      "text" : "TDiH",
      "indices" : [ 76, 81 ]
    }, {
      "text" : "Selma50",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/wWHrKnmOkp",
      "expanded_url" : "http:\/\/todaysdocument.tumblr.com\/post\/113337833652\/civil-rights-protesters-stage-a-sit-in-at-the",
      "display_url" : "todaysdocument.tumblr.com\/post\/113337833\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575740500277379073",
  "text" : "RT @TodaysDocument: Protesters stage a #sitin at the @WhiteHouse 50 yrs ago #TDiH 1965: http:\/\/t.co\/wWHrKnmOkp #Selma50 via @LBJLibrary htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 33, 44 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "LBJ Library",
        "screen_name" : "LBJLibrary",
        "indices" : [ 104, 115 ],
        "id_str" : "113729414",
        "id" : 113729414
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TodaysDocument\/status\/575641971089276928\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/x8dPuMXuKD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_0XUkOUcAE9UFb.jpg",
        "id_str" : "575641969461850113",
        "id" : 575641969461850113,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_0XUkOUcAE9UFb.jpg",
        "sizes" : [ {
          "h" : 1022,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1278,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/x8dPuMXuKD"
      } ],
      "hashtags" : [ {
        "text" : "sitin",
        "indices" : [ 19, 25 ]
      }, {
        "text" : "TDiH",
        "indices" : [ 56, 61 ]
      }, {
        "text" : "Selma50",
        "indices" : [ 91, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/wWHrKnmOkp",
        "expanded_url" : "http:\/\/todaysdocument.tumblr.com\/post\/113337833652\/civil-rights-protesters-stage-a-sit-in-at-the",
        "display_url" : "todaysdocument.tumblr.com\/post\/113337833\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "575641971089276928",
    "text" : "Protesters stage a #sitin at the @WhiteHouse 50 yrs ago #TDiH 1965: http:\/\/t.co\/wWHrKnmOkp #Selma50 via @LBJLibrary http:\/\/t.co\/x8dPuMXuKD",
    "id" : 575641971089276928,
    "created_at" : "2015-03-11 12:58:35 +0000",
    "user" : {
      "name" : "Today's Document",
      "screen_name" : "TodaysDocument",
      "protected" : false,
      "id_str" : "22656792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1208582961\/app_icon_v2_normal.jpg",
      "id" : 22656792,
      "verified" : true
    }
  },
  "id" : 575740500277379073,
  "created_at" : "2015-03-11 19:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "EIA",
      "screen_name" : "EIAgov",
      "indices" : [ 34, 41 ],
      "id_str" : "57111966",
      "id" : 57111966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575736077773893632",
  "text" : "RT @Deese44: Not blowing hot air: @EIAgov predicting another big year for new wind, solar capacity in 2015. #ActOnClimate http:\/\/t.co\/2Wau6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EIA",
        "screen_name" : "EIAgov",
        "indices" : [ 21, 28 ],
        "id_str" : "57111966",
        "id" : 57111966
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Deese44\/status\/575718605637091329\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/2Wau6xTzy9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_0k053UsAEd--a.png",
        "id_str" : "575656818677952513",
        "id" : 575656818677952513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_0k053UsAEd--a.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/2Wau6xTzy9"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 95, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "575718605637091329",
    "text" : "Not blowing hot air: @EIAgov predicting another big year for new wind, solar capacity in 2015. #ActOnClimate http:\/\/t.co\/2Wau6xTzy9",
    "id" : 575718605637091329,
    "created_at" : "2015-03-11 18:03:06 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 575736077773893632,
  "created_at" : "2015-03-11 19:12:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/575718027926224896\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/DOxWwTkMSz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_1cfrYUYAAwa1e.jpg",
      "id_str" : "575718026663714816",
      "id" : 575718026663714816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_1cfrYUYAAwa1e.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DOxWwTkMSz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575723138693996544",
  "text" : "RT @VP: \"Last week, we announced that 295,000 private sector jobs were created in the country in February.\" -VP Biden http:\/\/t.co\/DOxWwTkMSz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/575718027926224896\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/DOxWwTkMSz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_1cfrYUYAAwa1e.jpg",
        "id_str" : "575718026663714816",
        "id" : 575718026663714816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_1cfrYUYAAwa1e.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DOxWwTkMSz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "575718027926224896",
    "text" : "\"Last week, we announced that 295,000 private sector jobs were created in the country in February.\" -VP Biden http:\/\/t.co\/DOxWwTkMSz",
    "id" : 575718027926224896,
    "created_at" : "2015-03-11 18:00:48 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 575723138693996544,
  "created_at" : "2015-03-11 18:21:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 26, 36 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHEdChat",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/853XDLAy6g",
      "expanded_url" : "http:\/\/go.wh.gov\/WHEdChat",
      "display_url" : "go.wh.gov\/WHEdChat"
    } ]
  },
  "geo" : { },
  "id_str" : "575707750216384512",
  "text" : "RT @WHLive: At 1:30pm ET, @Cecilia44 will answer your Q's on paying for college. Ask with #WHEdChat \u2192 http:\/\/t.co\/853XDLAy6g http:\/\/t.co\/Mi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cecilia Mu\u00F1oz",
        "screen_name" : "Cecilia44",
        "indices" : [ 14, 24 ],
        "id_str" : "1613223313",
        "id" : 1613223313
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/575707713507835904\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/MiuozCkqcR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_1TEsiUcAAZ_GJ.jpg",
        "id_str" : "575707667512979456",
        "id" : 575707667512979456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_1TEsiUcAAZ_GJ.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MiuozCkqcR"
      } ],
      "hashtags" : [ {
        "text" : "WHEdChat",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/853XDLAy6g",
        "expanded_url" : "http:\/\/go.wh.gov\/WHEdChat",
        "display_url" : "go.wh.gov\/WHEdChat"
      } ]
    },
    "geo" : { },
    "id_str" : "575707713507835904",
    "text" : "At 1:30pm ET, @Cecilia44 will answer your Q's on paying for college. Ask with #WHEdChat \u2192 http:\/\/t.co\/853XDLAy6g http:\/\/t.co\/MiuozCkqcR",
    "id" : 575707713507835904,
    "created_at" : "2015-03-11 17:19:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 575707750216384512,
  "created_at" : "2015-03-11 17:19:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575705787294728192\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/YSXEHovTn5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_1RJObUsAAjyxR.jpg",
      "id_str" : "575705546306662400",
      "id" : 575705546306662400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_1RJObUsAAjyxR.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/YSXEHovTn5"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 97, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/nr1M53ijUD",
      "expanded_url" : "http:\/\/go.wh.gov\/h1mneL",
      "display_url" : "go.wh.gov\/h1mneL"
    } ]
  },
  "geo" : { },
  "id_str" : "575705787294728192",
  "text" : "Stand with President Obama in support of the Student Aid Bill of Rights \u2192 http:\/\/t.co\/nr1M53ijUD #CollegeOpportunity http:\/\/t.co\/YSXEHovTn5",
  "id" : 575705787294728192,
  "created_at" : "2015-03-11 17:12:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 42, 52 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/575685155932672001\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/ALGvaxTu2B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_06zAHUgAAYslo.jpg",
      "id_str" : "575680975251734528",
      "id" : 575680975251734528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_06zAHUgAAYslo.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ALGvaxTu2B"
    } ],
    "hashtags" : [ {
      "text" : "WHEdChat",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/tHWQpMp2p0",
      "expanded_url" : "http:\/\/go.wh.gov\/WHEdChat",
      "display_url" : "go.wh.gov\/WHEdChat"
    } ]
  },
  "geo" : { },
  "id_str" : "575685155932672001",
  "text" : "Have questions on paying for college? Ask @Cecilia44 using #WHEdChat before her 1:30pm ET Q&amp;A: http:\/\/t.co\/tHWQpMp2p0 http:\/\/t.co\/ALGvaxTu2B",
  "id" : 575685155932672001,
  "created_at" : "2015-03-11 15:50:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHEdChat",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ESXrLjCGWt",
      "expanded_url" : "http:\/\/go.wh.gov\/WHEdChat",
      "display_url" : "go.wh.gov\/WHEdChat"
    } ]
  },
  "geo" : { },
  "id_str" : "575680089897111552",
  "text" : "RT @Cecilia44: Excited to answer your Qs on the Student Aid Bill of Rights at 1:30pm ET! Ask with #WHEdChat: http:\/\/t.co\/ESXrLjCGWt http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cecilia44\/status\/575679879229890560\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/bP7iTwFrBi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_05zLJUIAAS4OF.jpg",
        "id_str" : "575679878701260800",
        "id" : 575679878701260800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_05zLJUIAAS4OF.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/bP7iTwFrBi"
      } ],
      "hashtags" : [ {
        "text" : "WHEdChat",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/ESXrLjCGWt",
        "expanded_url" : "http:\/\/go.wh.gov\/WHEdChat",
        "display_url" : "go.wh.gov\/WHEdChat"
      } ]
    },
    "geo" : { },
    "id_str" : "575679879229890560",
    "text" : "Excited to answer your Qs on the Student Aid Bill of Rights at 1:30pm ET! Ask with #WHEdChat: http:\/\/t.co\/ESXrLjCGWt http:\/\/t.co\/bP7iTwFrBi",
    "id" : 575679879229890560,
    "created_at" : "2015-03-11 15:29:13 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 575680089897111552,
  "created_at" : "2015-03-11 15:30:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575658072485527552\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/oUqunWKWYT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_0l73GU8AAxAh6.jpg",
      "id_str" : "575658037706289152",
      "id" : 575658037706289152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_0l73GU8AAxAh6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oUqunWKWYT"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 93, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575658072485527552",
  "text" : "Every student in America should be able to choose an affordable student loan repayment plan. #CollegeOpportunity http:\/\/t.co\/oUqunWKWYT",
  "id" : 575658072485527552,
  "created_at" : "2015-03-11 14:02:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "indices" : [ 3, 9 ],
      "id_str" : "390320946",
      "id" : 390320946
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/V14GDg1Ne1",
      "expanded_url" : "https:\/\/www.WhiteHouse.gov",
      "display_url" : "WhiteHouse.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "575654622251126785",
  "text" : "RT @WHWeb: The @Whitehouse is taking steps to improve your privacy. Starting today we use HTTPS by default: https:\/\/t.co\/V14GDg1Ne1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/V14GDg1Ne1",
        "expanded_url" : "https:\/\/www.WhiteHouse.gov",
        "display_url" : "WhiteHouse.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "575509388133335041",
    "text" : "The @Whitehouse is taking steps to improve your privacy. Starting today we use HTTPS by default: https:\/\/t.co\/V14GDg1Ne1",
    "id" : 575509388133335041,
    "created_at" : "2015-03-11 04:11:45 +0000",
    "user" : {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "protected" : false,
      "id_str" : "390320946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618051538582310913\/0xcdHiQS_normal.jpg",
      "id" : 390320946,
      "verified" : true
    }
  },
  "id" : 575654622251126785,
  "created_at" : "2015-03-11 13:48:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575449852147970048\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/5cPzBc6okM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_xmAzwUIAEVSUN.jpg",
      "id_str" : "575447016475467777",
      "id" : 575447016475467777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_xmAzwUIAEVSUN.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/5cPzBc6okM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/nr1M530Iw3",
      "expanded_url" : "http:\/\/go.wh.gov\/h1mneL",
      "display_url" : "go.wh.gov\/h1mneL"
    } ]
  },
  "geo" : { },
  "id_str" : "575449852147970048",
  "text" : "Add your name if you agree: Every student deserves access to a quality, affordable education \u2192 http:\/\/t.co\/nr1M530Iw3 http:\/\/t.co\/5cPzBc6okM",
  "id" : 575449852147970048,
  "created_at" : "2015-03-11 00:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575441837969698817\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/J9ZZL5NuCc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_xhGMCUwAElOYz.jpg",
      "id_str" : "575441611334664193",
      "id" : 575441611334664193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_xhGMCUwAElOYz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/J9ZZL5NuCc"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 88, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575441837969698817",
  "text" : "Every student should be able to easily find the resources they need to pay for college. #CollegeOpportunity http:\/\/t.co\/J9ZZL5NuCc",
  "id" : 575441837969698817,
  "created_at" : "2015-03-10 23:43:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575404270331109376\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/m3TBiT6yT4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_w-kwkUwAAcQvb.jpg",
      "id_str" : "575403653630050304",
      "id" : 575403653630050304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_w-kwkUwAAcQvb.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/m3TBiT6yT4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575404270331109376",
  "text" : "RT the news: Nearly 11.7 million people are \u270D up for private health coverage through the Affordable Care Act. http:\/\/t.co\/m3TBiT6yT4",
  "id" : 575404270331109376,
  "created_at" : "2015-03-10 21:14:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575377700275228672\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/kH9AeMHtdI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wm05OU0AAHuBF.jpg",
      "id_str" : "575377542552539136",
      "id" : 575377542552539136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wm05OU0AAHuBF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kH9AeMHtdI"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 84, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/nr1M53ijUD",
      "expanded_url" : "http:\/\/go.wh.gov\/h1mneL",
      "display_url" : "go.wh.gov\/h1mneL"
    } ]
  },
  "geo" : { },
  "id_str" : "575377700275228672",
  "text" : "Add your name in support of the Student Aid Bill of Rights \u2192 http:\/\/t.co\/nr1M53ijUD #CollegeOpportunity http:\/\/t.co\/kH9AeMHtdI",
  "id" : 575377700275228672,
  "created_at" : "2015-03-10 19:28:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeorgiaTech",
      "screen_name" : "GeorgiaTech",
      "indices" : [ 96, 108 ],
      "id_str" : "19080617",
      "id" : 19080617
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 109, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575360563754110976",
  "text" : "\u201CInspire us. Lead us. Be the Americans that we need you to be.\" \u2014President Obama to students at @GeorgiaTech #CollegeOpportunity",
  "id" : 575360563754110976,
  "created_at" : "2015-03-10 18:20:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575359906607321088\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/kPmUfM9DEH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wWmOMUYAA6V1V.jpg",
      "id_str" : "575359698297184256",
      "id" : 575359698297184256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wWmOMUYAA6V1V.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kPmUfM9DEH"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 95, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/nr1M530Iw3",
      "expanded_url" : "http:\/\/go.wh.gov\/h1mneL",
      "display_url" : "go.wh.gov\/h1mneL"
    } ]
  },
  "geo" : { },
  "id_str" : "575359906607321088",
  "text" : "\"If you believe in a Student Aid Bill of Rights\u2026sign your name\u201D \u2014Obama: http:\/\/t.co\/nr1M530Iw3 #CollegeOpportunity http:\/\/t.co\/kPmUfM9DEH",
  "id" : 575359906607321088,
  "created_at" : "2015-03-10 18:17:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/T8DaTNfIAo",
      "expanded_url" : "http:\/\/go.wh.gov\/h1mneL",
      "display_url" : "go.wh.gov\/h1mneL"
    } ]
  },
  "geo" : { },
  "id_str" : "575359152626651136",
  "text" : "RT @WHLive: \"Every student should be able to access the resources to pay for college.\" \u2014President Obama: http:\/\/t.co\/T8DaTNfIAo #CollegeOpp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 116, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/T8DaTNfIAo",
        "expanded_url" : "http:\/\/go.wh.gov\/h1mneL",
        "display_url" : "go.wh.gov\/h1mneL"
      } ]
    },
    "geo" : { },
    "id_str" : "575358916273405952",
    "text" : "\"Every student should be able to access the resources to pay for college.\" \u2014President Obama: http:\/\/t.co\/T8DaTNfIAo #CollegeOpportunity",
    "id" : 575358916273405952,
    "created_at" : "2015-03-10 18:13:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 575359152626651136,
  "created_at" : "2015-03-10 18:14:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575358777639104512\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/gohFDvXXAm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wVsLfUYAAjxwr.jpg",
      "id_str" : "575358701139156992",
      "id" : 575358701139156992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wVsLfUYAAjxwr.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gohFDvXXAm"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 85, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575358777639104512",
  "text" : "\"Every student deserves access to a quality, affordable education.\" \u2014President Obama #CollegeOpportunity http:\/\/t.co\/gohFDvXXAm",
  "id" : 575358777639104512,
  "created_at" : "2015-03-10 18:13:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/575358093342699520\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/HEk1PA8nhb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wVHYOUIAAUxrg.jpg",
      "id_str" : "575358068902338560",
      "id" : 575358068902338560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wVHYOUIAAUxrg.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HEk1PA8nhb"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 95, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575358093342699520",
  "text" : "\"We want to make\u2026community college just as free and universal as high school is today.\" \u2014Obama #CollegeOpportunity http:\/\/t.co\/HEk1PA8nhb",
  "id" : 575358093342699520,
  "created_at" : "2015-03-10 18:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 104, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575357973477855232",
  "text" : "\"I sent Congress a bold new plan to bring down the cost of community college to zero.\" \u2014President Obama #CollegeOpportunity",
  "id" : 575357973477855232,
  "created_at" : "2015-03-10 18:10:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575357438481694720\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/tAP6w2LvzC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wUf29UgAAIbvo.jpg",
      "id_str" : "575357389957791744",
      "id" : 575357389957791744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wUf29UgAAIbvo.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tAP6w2LvzC"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 97, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575357438481694720",
  "text" : "\"We...acted to let millions of graduates cap their loan payments at 10% of their incomes\" \u2014Obama #CollegeOpportunity http:\/\/t.co\/tAP6w2LvzC",
  "id" : 575357438481694720,
  "created_at" : "2015-03-10 18:07:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/575357212266201088\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/25to0Z2u90",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wUUrwUsAAiym2.jpg",
      "id_str" : "575357197971927040",
      "id" : 575357197971927040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wUUrwUsAAiym2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/25to0Z2u90"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 80, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575357212266201088",
  "text" : "\"We\u2019ve acted again and again to make college more affordable.\" \u2014President Obama #CollegeOpportunity http:\/\/t.co\/25to0Z2u90",
  "id" : 575357212266201088,
  "created_at" : "2015-03-10 18:07:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 120, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575356961857777664",
  "text" : "\"I am only standing here today\u2014and Michelle is only who she is today\u2014because of scholarships and student loans.\" \u2014Obama #CollegeOpportunity",
  "id" : 575356961857777664,
  "created_at" : "2015-03-10 18:06:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575356874675085312",
  "text" : "\"America is a place where higher education must be available for every single person who\u2019s willing to work for it.\" \u2014President Obama",
  "id" : 575356874675085312,
  "created_at" : "2015-03-10 18:05:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575356096954654720\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/302HU4dLv9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wTQHtUgAA5bYP.jpg",
      "id_str" : "575356020064550912",
      "id" : 575356020064550912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wTQHtUgAA5bYP.jpg",
      "sizes" : [ {
        "h" : 1327,
        "resize" : "fit",
        "w" : 1991
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/302HU4dLv9"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 95, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575356096954654720",
  "text" : "\"Your most valuable asset is...your knowledge\" \u2014President Obama on the importance of expanding #CollegeOpportunity http:\/\/t.co\/302HU4dLv9",
  "id" : 575356096954654720,
  "created_at" : "2015-03-10 18:02:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575355396321320960\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/xc1tOcvvSS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wSqIKUsAAN6Sr.jpg",
      "id_str" : "575355367351169024",
      "id" : 575355367351169024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wSqIKUsAAN6Sr.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xc1tOcvvSS"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 96, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575355396321320960",
  "text" : "\"Today, a college degree is the surest ticket to the middle class and beyond.\" \u2014President Obama #CollegeOpportunity http:\/\/t.co\/xc1tOcvvSS",
  "id" : 575355396321320960,
  "created_at" : "2015-03-10 17:59:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/575355127067865088\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/92BfmlHPQO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wSbeiUwAEA1b7.jpg",
      "id_str" : "575355115659378689",
      "id" : 575355115659378689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wSbeiUwAEA1b7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/92BfmlHPQO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575355159536099328",
  "text" : "RT @WHLive: \"Over the past 5 years, our businesses have created 12 million new jobs.\" \u2014President Obama http:\/\/t.co\/92BfmlHPQO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/575355127067865088\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/92BfmlHPQO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wSbeiUwAEA1b7.jpg",
        "id_str" : "575355115659378689",
        "id" : 575355115659378689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wSbeiUwAEA1b7.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/92BfmlHPQO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "575355127067865088",
    "text" : "\"Over the past 5 years, our businesses have created 12 million new jobs.\" \u2014President Obama http:\/\/t.co\/92BfmlHPQO",
    "id" : 575355127067865088,
    "created_at" : "2015-03-10 17:58:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 575355159536099328,
  "created_at" : "2015-03-10 17:58:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 113, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575354740952817664",
  "text" : "\"I believe that higher education...is one of the best investments that anybody can make in their future.\" \u2014Obama #CollegeOpportunity",
  "id" : 575354740952817664,
  "created_at" : "2015-03-10 17:57:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GeorgiaTech",
      "screen_name" : "GeorgiaTech",
      "indices" : [ 59, 71 ],
      "id_str" : "19080617",
      "id" : 19080617
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 96, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/VlCYAmTcd7",
      "expanded_url" : "http:\/\/go.wh.gov\/GwHFdF",
      "display_url" : "go.wh.gov\/GwHFdF"
    } ]
  },
  "geo" : { },
  "id_str" : "575353700467765248",
  "text" : "\"Hello Atlanta! Hello Yellow Jackets!\" \u2014President Obama at @GeorgiaTech: http:\/\/t.co\/VlCYAmTcd7 #CollegeOpportunity",
  "id" : 575353700467765248,
  "created_at" : "2015-03-10 17:53:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 92, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/VlCYAmTcd7",
      "expanded_url" : "http:\/\/go.wh.gov\/GwHFdF",
      "display_url" : "go.wh.gov\/GwHFdF"
    } ]
  },
  "geo" : { },
  "id_str" : "575353337345916928",
  "text" : "Watch live: President Obama introduces a Student Aid Bill of Rights and new steps to expand #CollegeOpportunity \u2192 http:\/\/t.co\/VlCYAmTcd7",
  "id" : 575353337345916928,
  "created_at" : "2015-03-10 17:51:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "GeorgiaTech",
      "screen_name" : "GeorgiaTech",
      "indices" : [ 33, 45 ],
      "id_str" : "19080617",
      "id" : 19080617
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Schultz44\/status\/575340381145055232\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/YHymaZGMVu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wFBe6U0AEMzn1.jpg",
      "id_str" : "575340375432286209",
      "id" : 575340375432286209,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wFBe6U0AEMzn1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YHymaZGMVu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575342768223973376",
  "text" : "RT @Schultz44: Packed crowd here @GeorgiaTech awaiting POTUS announcement of Student Aid Bill of Rights http:\/\/t.co\/YHymaZGMVu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GeorgiaTech",
        "screen_name" : "GeorgiaTech",
        "indices" : [ 18, 30 ],
        "id_str" : "19080617",
        "id" : 19080617
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Schultz44\/status\/575340381145055232\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/YHymaZGMVu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_wFBe6U0AEMzn1.jpg",
        "id_str" : "575340375432286209",
        "id" : 575340375432286209,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_wFBe6U0AEMzn1.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/YHymaZGMVu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 33.7805684388761, -84.39288257819467 ]
    },
    "id_str" : "575340381145055232",
    "text" : "Packed crowd here @GeorgiaTech awaiting POTUS announcement of Student Aid Bill of Rights http:\/\/t.co\/YHymaZGMVu",
    "id" : 575340381145055232,
    "created_at" : "2015-03-10 17:00:10 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 575342768223973376,
  "created_at" : "2015-03-10 17:09:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575333429358694400\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/iqzCvARfJ6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_v8AZPUwAAVXIO.jpg",
      "id_str" : "575330461125230592",
      "id" : 575330461125230592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_v8AZPUwAAVXIO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iqzCvARfJ6"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 90, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575333429358694400",
  "text" : "RT if you agree: Every student deserves access to a quality, affordable higher education. #CollegeOpportunity http:\/\/t.co\/iqzCvARfJ6",
  "id" : 575333429358694400,
  "created_at" : "2015-03-10 16:32:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/575326480420442112\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/VOEk7TZ9dl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_v4W_KUgAI33X9.jpg",
      "id_str" : "575326451215400962",
      "id" : 575326451215400962,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_v4W_KUgAI33X9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VOEk7TZ9dl"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 85, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/s6dIfohcJ0",
      "expanded_url" : "http:\/\/go.wh.gov\/SUNZM3",
      "display_url" : "go.wh.gov\/SUNZM3"
    } ]
  },
  "geo" : { },
  "id_str" : "575326480420442112",
  "text" : "President Obama is introducing a Student Aid Bill of Rights \u2192 http:\/\/t.co\/s6dIfohcJ0 #CollegeOpportunity http:\/\/t.co\/VOEk7TZ9dl",
  "id" : 575326480420442112,
  "created_at" : "2015-03-10 16:04:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/E5WS4nOHGf",
      "expanded_url" : "https:\/\/medium.com\/@VPOTUS\/the-vice-president-on-the-march-9th-letter-from-republican-senators-to-the-islamic-republic-of-iran-86299d0bb526",
      "display_url" : "medium.com\/@VPOTUS\/the-vi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575310819665125376",
  "text" : "RT @VP: \u201CHonorable people can disagree over policy. But this is no way to make America safer or stronger.\" \u2013VP Biden https:\/\/t.co\/E5WS4nOHGf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/E5WS4nOHGf",
        "expanded_url" : "https:\/\/medium.com\/@VPOTUS\/the-vice-president-on-the-march-9th-letter-from-republican-senators-to-the-islamic-republic-of-iran-86299d0bb526",
        "display_url" : "medium.com\/@VPOTUS\/the-vi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "575309908624568322",
    "text" : "\u201CHonorable people can disagree over policy. But this is no way to make America safer or stronger.\" \u2013VP Biden https:\/\/t.co\/E5WS4nOHGf",
    "id" : 575309908624568322,
    "created_at" : "2015-03-10 14:59:05 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 575310819665125376,
  "created_at" : "2015-03-10 15:02:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 82, 89 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/BJpzvSI8HW",
      "expanded_url" : "https:\/\/medium.com\/@VPOTUS",
      "display_url" : "medium.com\/@VPOTUS"
    } ]
  },
  "geo" : { },
  "id_str" : "575309622615015424",
  "text" : "RT @VP: For all things Vice President Biden on the Internet, check out the new VP @Medium account \u2192 https:\/\/t.co\/BJpzvSI8HW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 74, 81 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/BJpzvSI8HW",
        "expanded_url" : "https:\/\/medium.com\/@VPOTUS",
        "display_url" : "medium.com\/@VPOTUS"
      } ]
    },
    "geo" : { },
    "id_str" : "575309071659614208",
    "text" : "For all things Vice President Biden on the Internet, check out the new VP @Medium account \u2192 https:\/\/t.co\/BJpzvSI8HW",
    "id" : 575309071659614208,
    "created_at" : "2015-03-10 14:55:46 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 575309622615015424,
  "created_at" : "2015-03-10 14:57:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/EVI62HWYrR",
      "expanded_url" : "http:\/\/go.wh.gov\/Selma-photos",
      "display_url" : "go.wh.gov\/Selma-photos"
    } ]
  },
  "geo" : { },
  "id_str" : "575142627034660866",
  "text" : "RT @FLOTUS: We honor those who walked so we could run. We must run so our children soar. http:\/\/t.co\/EVI62HWYrR #MarchOn http:\/\/t.co\/bByU7B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/575121962487406593\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/bByU7Bw8uF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_s-WsLUIAER-0l.jpg",
        "id_str" : "575121936956530689",
        "id" : 575121936956530689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_s-WsLUIAER-0l.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/bByU7Bw8uF"
      } ],
      "hashtags" : [ {
        "text" : "MarchOn",
        "indices" : [ 100, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/EVI62HWYrR",
        "expanded_url" : "http:\/\/go.wh.gov\/Selma-photos",
        "display_url" : "go.wh.gov\/Selma-photos"
      } ]
    },
    "geo" : { },
    "id_str" : "575121962487406593",
    "text" : "We honor those who walked so we could run. We must run so our children soar. http:\/\/t.co\/EVI62HWYrR #MarchOn http:\/\/t.co\/bByU7Bw8uF",
    "id" : 575121962487406593,
    "created_at" : "2015-03-10 02:32:15 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 575142627034660866,
  "created_at" : "2015-03-10 03:54:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VICE News",
      "screen_name" : "vicenews",
      "indices" : [ 3, 12 ],
      "id_str" : "1630896181",
      "id" : 1630896181
    }, {
      "name" : "shane smith",
      "screen_name" : "shanesmith30",
      "indices" : [ 24, 37 ],
      "id_str" : "88975905",
      "id" : 88975905
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vicenews\/status\/575058375005880320\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/dR3HkMrjKH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_sEd-sUgAAnDzD.jpg",
      "id_str" : "575058290511478784",
      "id" : 575058290511478784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_sEd-sUgAAnDzD.jpg",
      "sizes" : [ {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2168,
        "resize" : "fit",
        "w" : 3136
      }, {
        "h" : 708,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dR3HkMrjKH"
    } ],
    "hashtags" : [ {
      "text" : "vicemeetsobama",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/VPkkist4XW",
      "expanded_url" : "http:\/\/bit.ly\/1BZXfD5",
      "display_url" : "bit.ly\/1BZXfD5"
    } ]
  },
  "geo" : { },
  "id_str" : "575058674810511360",
  "text" : "RT @vicenews: Tomorrow, @ShaneSmith30 is sitting down with President Obama: http:\/\/t.co\/VPkkist4XW #vicemeetsobama http:\/\/t.co\/dR3HkMrjKH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "shane smith",
        "screen_name" : "shanesmith30",
        "indices" : [ 10, 23 ],
        "id_str" : "88975905",
        "id" : 88975905
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vicenews\/status\/575058375005880320\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/dR3HkMrjKH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_sEd-sUgAAnDzD.jpg",
        "id_str" : "575058290511478784",
        "id" : 575058290511478784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_sEd-sUgAAnDzD.jpg",
        "sizes" : [ {
          "h" : 235,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2168,
          "resize" : "fit",
          "w" : 3136
        }, {
          "h" : 708,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/dR3HkMrjKH"
      } ],
      "hashtags" : [ {
        "text" : "vicemeetsobama",
        "indices" : [ 85, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/VPkkist4XW",
        "expanded_url" : "http:\/\/bit.ly\/1BZXfD5",
        "display_url" : "bit.ly\/1BZXfD5"
      } ]
    },
    "geo" : { },
    "id_str" : "575058375005880320",
    "text" : "Tomorrow, @ShaneSmith30 is sitting down with President Obama: http:\/\/t.co\/VPkkist4XW #vicemeetsobama http:\/\/t.co\/dR3HkMrjKH",
    "id" : 575058375005880320,
    "created_at" : "2015-03-09 22:19:35 +0000",
    "user" : {
      "name" : "VICE News",
      "screen_name" : "vicenews",
      "protected" : false,
      "id_str" : "1630896181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785208513177985024\/Guc3ohmz_normal.jpg",
      "id" : 1630896181,
      "verified" : true
    }
  },
  "id" : 575058674810511360,
  "created_at" : "2015-03-09 22:20:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575045191318573057\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/PbH0mxJ5vm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_r4WpJUYAA1VZ-.jpg",
      "id_str" : "575044970328907776",
      "id" : 575044970328907776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_r4WpJUYAA1VZ-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PbH0mxJ5vm"
    } ],
    "hashtags" : [ {
      "text" : "TechHire",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/vVE7Dn2ivG",
      "expanded_url" : "http:\/\/wh.gov\/TechHire",
      "display_url" : "wh.gov\/TechHire"
    } ]
  },
  "geo" : { },
  "id_str" : "575045191318573057",
  "text" : "FACT: America has about 5 million job openings, more than at any point since 2001 \u2192 http:\/\/t.co\/vVE7Dn2ivG #TechHire http:\/\/t.co\/PbH0mxJ5vm",
  "id" : 575045191318573057,
  "created_at" : "2015-03-09 21:27:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/575014939737223168\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/msMl0Y7s5K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_rc4OmUgAAuBnN.jpg",
      "id_str" : "575014760992768000",
      "id" : 575014760992768000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_rc4OmUgAAuBnN.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/msMl0Y7s5K"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/luETleJFqd",
      "expanded_url" : "http:\/\/wh.gov\/Selma-photos",
      "display_url" : "wh.gov\/Selma-photos"
    } ]
  },
  "geo" : { },
  "id_str" : "575014939737223168",
  "text" : "\"There\u2019s nothing America can\u2019t handle if we actually look squarely at the problem.\" \u2014Obama: http:\/\/t.co\/luETleJFqd http:\/\/t.co\/msMl0Y7s5K",
  "id" : 575014939737223168,
  "created_at" : "2015-03-09 19:26:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/574993289041944577\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/dtI3ut0tBS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_rJGRCUwAAmwRY.jpg",
      "id_str" : "574993011932708864",
      "id" : 574993011932708864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_rJGRCUwAAmwRY.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dtI3ut0tBS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/vVE7DmKH76",
      "expanded_url" : "http:\/\/wh.gov\/TechHire",
      "display_url" : "wh.gov\/TechHire"
    } ]
  },
  "geo" : { },
  "id_str" : "574993289041944577",
  "text" : "RIGHT NOW: There are more than 500,000 job openings in IT.\nLet's train more workers for them \u2192 http:\/\/t.co\/vVE7DmKH76 http:\/\/t.co\/dtI3ut0tBS",
  "id" : 574993289041944577,
  "created_at" : "2015-03-09 18:00:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/574978669736755201\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/zuydM04JB7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_q7JpPUcAMrepc.jpg",
      "id_str" : "574977676806483971",
      "id" : 574977676806483971,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_q7JpPUcAMrepc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1615,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 827,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zuydM04JB7"
    } ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 80, 88 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 89, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/uVWBvryy1E",
      "expanded_url" : "http:\/\/go.wh.gov\/Selma-photos",
      "display_url" : "go.wh.gov\/Selma-photos"
    } ]
  },
  "geo" : { },
  "id_str" : "574978669736755201",
  "text" : "Our march is not yet finished, but we're getting closer.\nhttp:\/\/t.co\/uVWBvryy1E\n#Selma50 #MarchOn http:\/\/t.co\/zuydM04JB7",
  "id" : 574978669736755201,
  "created_at" : "2015-03-09 17:02:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TechHire",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/vVE7Dn2ivG",
      "expanded_url" : "http:\/\/wh.gov\/TechHire",
      "display_url" : "wh.gov\/TechHire"
    } ]
  },
  "geo" : { },
  "id_str" : "574960853587509248",
  "text" : "\"It doesn\u2019t matter where you learn to code, it should matter how good you are at writing code.\" \u2014Obama: http:\/\/t.co\/vVE7Dn2ivG #TechHire",
  "id" : 574960853587509248,
  "created_at" : "2015-03-09 15:52:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/574959909533417472\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/eZXnHZfoIr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_qq59IU8AElNUX.png",
      "id_str" : "574959815081914369",
      "id" : 574959815081914369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_qq59IU8AElNUX.png",
      "sizes" : [ {
        "h" : 326,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eZXnHZfoIr"
    } ],
    "hashtags" : [ {
      "text" : "TechHire",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/vVE7DmKH76",
      "expanded_url" : "http:\/\/wh.gov\/TechHire",
      "display_url" : "wh.gov\/TechHire"
    } ]
  },
  "geo" : { },
  "id_str" : "574959909533417472",
  "text" : "\"These tech jobs pay 50% more than the average private-sector wage.\" \u2014Obama: http:\/\/t.co\/vVE7DmKH76 #TechHire http:\/\/t.co\/eZXnHZfoIr",
  "id" : 574959909533417472,
  "created_at" : "2015-03-09 15:48:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TechHire",
      "indices" : [ 114, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/vVE7DmKH76",
      "expanded_url" : "http:\/\/wh.gov\/TechHire",
      "display_url" : "wh.gov\/TechHire"
    } ]
  },
  "geo" : { },
  "id_str" : "574959206937165825",
  "text" : "\"Right now, America has more job openings than at any point since 2001.\" \u2014President Obama: http:\/\/t.co\/vVE7DmKH76 #TechHire",
  "id" : 574959206937165825,
  "created_at" : "2015-03-09 15:45:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/574958989814927361\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/RSqZcGgZhL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_qqIAwUgAE1Jrm.jpg",
      "id_str" : "574958957061505025",
      "id" : 574958957061505025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_qqIAwUgAE1Jrm.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RSqZcGgZhL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574958989814927361",
  "text" : "\"Over the past 2 years, more than 20 cities and counties have taken action to raise workers\u2019 wages.\" \u2014President Obama http:\/\/t.co\/RSqZcGgZhL",
  "id" : 574958989814927361,
  "created_at" : "2015-03-09 15:44:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574958387697356803",
  "text" : "\"The unemployment rate ticked down to 5.5%\u2014the lowest it\u2019s been since the spring of 2008.\" \u2014President Obama",
  "id" : 574958387697356803,
  "created_at" : "2015-03-09 15:42:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/574958153332195328\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/EtQDelcuoK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_qpX5nUIAA7iLR.jpg",
      "id_str" : "574958130510962688",
      "id" : 574958130510962688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_qpX5nUIAA7iLR.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EtQDelcuoK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574958153332195328",
  "text" : "\"Last month, our economy created nearly 300,000 new jobs.\" \u2014President Obama http:\/\/t.co\/EtQDelcuoK",
  "id" : 574958153332195328,
  "created_at" : "2015-03-09 15:41:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TechHire",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/IyDLN5oLoy",
      "expanded_url" : "http:\/\/go.wh.gov\/McTWsy",
      "display_url" : "go.wh.gov\/McTWsy"
    } ]
  },
  "geo" : { },
  "id_str" : "574957745524375552",
  "text" : "Watch live: President Obama announces new steps to train more Americans for good-paying technology jobs \u2192 http:\/\/t.co\/IyDLN5oLoy #TechHire",
  "id" : 574957745524375552,
  "created_at" : "2015-03-09 15:39:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 87, 94 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 53, 61 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/aUatvOipk9",
      "expanded_url" : "http:\/\/youtu.be\/SnaLQNwfejg",
      "display_url" : "youtu.be\/SnaLQNwfejg"
    } ]
  },
  "geo" : { },
  "id_str" : "574946227059470338",
  "text" : "Watch some powerful behind-the-scenes reflections on #Selma50 from President Obama and @FLOTUS \u2192 http:\/\/t.co\/aUatvOipk9 #MarchOn",
  "id" : 574946227059470338,
  "created_at" : "2015-03-09 14:53:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 118, 126 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/aUatvO0OsB",
      "expanded_url" : "http:\/\/youtu.be\/SnaLQNwfejg",
      "display_url" : "youtu.be\/SnaLQNwfejg"
    } ]
  },
  "geo" : { },
  "id_str" : "574747665679978498",
  "text" : "\"If there's one thing to take away from Selma, it's that there is power in that vote.\" \u2014Obama: http:\/\/t.co\/aUatvO0OsB #Selma50 #MarchOn",
  "id" : 574747665679978498,
  "created_at" : "2015-03-09 01:44:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InternationalWomensDay",
      "indices" : [ 103, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574744242746228738",
  "text" : "RT @vj44: A world in which girls are treated equal to boys is safer, more stable, and more prosperous  #InternationalWomensDay http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/574693235077038080\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/K7Gyi91B5N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_m4b5aWcAAXeTs.jpg",
        "id_str" : "574693216873771008",
        "id" : 574693216873771008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_m4b5aWcAAXeTs.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 208,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 924
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 924
        } ],
        "display_url" : "pic.twitter.com\/K7Gyi91B5N"
      } ],
      "hashtags" : [ {
        "text" : "InternationalWomensDay",
        "indices" : [ 93, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574693235077038080",
    "text" : "A world in which girls are treated equal to boys is safer, more stable, and more prosperous  #InternationalWomensDay http:\/\/t.co\/K7Gyi91B5N",
    "id" : 574693235077038080,
    "created_at" : "2015-03-08 22:08:39 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 574744242746228738,
  "created_at" : "2015-03-09 01:31:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyWomensDay",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/hTUeq5N0tr",
      "expanded_url" : "http:\/\/go.wh.gov\/4B3gt1",
      "display_url" : "go.wh.gov\/4B3gt1"
    } ]
  },
  "geo" : { },
  "id_str" : "574736465176875008",
  "text" : "\"We want to make sure that no girl out there is denied her chance to learn\" \u2014President Obama: http:\/\/t.co\/hTUeq5N0tr #HappyWomensDay",
  "id" : 574736465176875008,
  "created_at" : "2015-03-09 01:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/574654901835468800\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/4CE22ZvBDA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_mVfriUcAAZiQe.jpg",
      "id_str" : "574654798961602560",
      "id" : 574654798961602560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_mVfriUcAAZiQe.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1035
      }, {
        "h" : 1484,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 870,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 493,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4CE22ZvBDA"
    } ],
    "hashtags" : [ {
      "text" : "DearMe",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574658110108860417",
  "text" : "RT @FLOTUS: \"A good education can lift you up into a life you never could have imagined.\" \u2014The First Lady #DearMe http:\/\/t.co\/4CE22ZvBDA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/574654901835468800\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/4CE22ZvBDA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_mVfriUcAAZiQe.jpg",
        "id_str" : "574654798961602560",
        "id" : 574654798961602560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_mVfriUcAAZiQe.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1035
        }, {
          "h" : 1484,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 870,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 493,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4CE22ZvBDA"
      } ],
      "hashtags" : [ {
        "text" : "DearMe",
        "indices" : [ 94, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574654901835468800",
    "text" : "\"A good education can lift you up into a life you never could have imagined.\" \u2014The First Lady #DearMe http:\/\/t.co\/4CE22ZvBDA",
    "id" : 574654901835468800,
    "created_at" : "2015-03-08 19:36:19 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 574658110108860417,
  "created_at" : "2015-03-08 19:49:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyInternationalWomensDay",
      "indices" : [ 97, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574654953278607360",
  "text" : "RT @VP: Women hold up half the sky, and they deserve every right &amp; opportunity given to men. #HappyInternationalWomensDay http:\/\/t.co\/W575J\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/574653070220492800\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/W575JD4DdG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_mT7AOU0AAoC4P.jpg",
        "id_str" : "574653069348098048",
        "id" : 574653069348098048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_mT7AOU0AAoC4P.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        } ],
        "display_url" : "pic.twitter.com\/W575JD4DdG"
      } ],
      "hashtags" : [ {
        "text" : "HappyInternationalWomensDay",
        "indices" : [ 89, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574653070220492800",
    "text" : "Women hold up half the sky, and they deserve every right &amp; opportunity given to men. #HappyInternationalWomensDay http:\/\/t.co\/W575JD4DdG",
    "id" : 574653070220492800,
    "created_at" : "2015-03-08 19:29:03 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 574654953278607360,
  "created_at" : "2015-03-08 19:36:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/574650102062706689\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/MGEAmd92qy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_mQp6aUcAACKVk.jpg",
      "id_str" : "574649477195132928",
      "id" : 574649477195132928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_mQp6aUcAACKVk.jpg",
      "sizes" : [ {
        "h" : 404,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1378,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MGEAmd92qy"
    } ],
    "hashtags" : [ {
      "text" : "HappyInternationalWomensDay",
      "indices" : [ 0, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/rR5MuQPPCV",
      "expanded_url" : "http:\/\/go.wh.gov\/womens-day",
      "display_url" : "go.wh.gov\/womens-day"
    } ]
  },
  "geo" : { },
  "id_str" : "574650102062706689",
  "text" : "#HappyInternationalWomensDay! http:\/\/t.co\/rR5MuQPPCV http:\/\/t.co\/MGEAmd92qy",
  "id" : 574650102062706689,
  "created_at" : "2015-03-08 19:17:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DearMe",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/CN0DV2qhZz",
      "expanded_url" : "http:\/\/on.doi.gov\/1wbFsb0",
      "display_url" : "on.doi.gov\/1wbFsb0"
    } ]
  },
  "geo" : { },
  "id_str" : "574643457278541825",
  "text" : "RT @SecretaryJewell: #DearMe: Don't let others tell you what to be when you grow up. Be who you want to be. SJ http:\/\/t.co\/CN0DV2qhZz #Inte\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DearMe",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "InternationalWomensDay",
        "indices" : [ 113, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/CN0DV2qhZz",
        "expanded_url" : "http:\/\/on.doi.gov\/1wbFsb0",
        "display_url" : "on.doi.gov\/1wbFsb0"
      } ]
    },
    "geo" : { },
    "id_str" : "574607612546842624",
    "text" : "#DearMe: Don't let others tell you what to be when you grow up. Be who you want to be. SJ http:\/\/t.co\/CN0DV2qhZz #InternationalWomensDay",
    "id" : 574607612546842624,
    "created_at" : "2015-03-08 16:28:25 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 574643457278541825,
  "created_at" : "2015-03-08 18:50:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/hTUeq5N0tr",
      "expanded_url" : "http:\/\/go.wh.gov\/4B3gt1",
      "display_url" : "go.wh.gov\/4B3gt1"
    } ]
  },
  "geo" : { },
  "id_str" : "574623165386633217",
  "text" : "\"Places where women &amp; girls are treated as full &amp; equal citizens tend to be more stable and more democratic.\" \u2014Obama: http:\/\/t.co\/hTUeq5N0tr",
  "id" : 574623165386633217,
  "created_at" : "2015-03-08 17:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/hTUeq5N0tr",
      "expanded_url" : "http:\/\/go.wh.gov\/4B3gt1",
      "display_url" : "go.wh.gov\/4B3gt1"
    } ]
  },
  "geo" : { },
  "id_str" : "574608784636542977",
  "text" : "\"In too many parts of the world, girls are still valued more for their bodies than for their minds.\" \u2014Obama: http:\/\/t.co\/hTUeq5N0tr",
  "id" : 574608784636542977,
  "created_at" : "2015-03-08 16:33:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyWomensDay",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/hTUeq5N0tr",
      "expanded_url" : "http:\/\/go.wh.gov\/4B3gt1",
      "display_url" : "go.wh.gov\/4B3gt1"
    } ]
  },
  "geo" : { },
  "id_str" : "574593597091131392",
  "text" : "\"When girls are educated, their future children are healthier and better nourished\" \u2014President Obama: http:\/\/t.co\/hTUeq5N0tr #HappyWomensDay",
  "id" : 574593597091131392,
  "created_at" : "2015-03-08 15:32:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573151280740368384\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/DfuOxoO09b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Q-CEcVIAAYUUL.jpg",
      "id_str" : "573151257856122880",
      "id" : 573151257856122880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Q-CEcVIAAYUUL.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/DfuOxoO09b"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 95, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/hTUeq5N0tr",
      "expanded_url" : "http:\/\/go.wh.gov\/4B3gt1",
      "display_url" : "go.wh.gov\/4B3gt1"
    } ]
  },
  "geo" : { },
  "id_str" : "574570875577487362",
  "text" : "\"Right now, 62 million girls who should be in school, are not.\" \u2014Obama: http:\/\/t.co\/hTUeq5N0tr #LetGirlsLearn http:\/\/t.co\/DfuOxoO09b",
  "id" : 574570875577487362,
  "created_at" : "2015-03-08 14:02:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyWomensDay",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/hTUeq5N0tr",
      "expanded_url" : "http:\/\/go.wh.gov\/4B3gt1",
      "display_url" : "go.wh.gov\/4B3gt1"
    } ]
  },
  "geo" : { },
  "id_str" : "574547689746001921",
  "text" : "\"Every girl deserves our respect, and every girl deserves an education.\" \u2014President Obama: http:\/\/t.co\/hTUeq5N0tr #HappyWomensDay",
  "id" : 574547689746001921,
  "created_at" : "2015-03-08 12:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/574373904153710592\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/ir0p6Zotgu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_iVv-tU8AAscX2.jpg",
      "id_str" : "574373604009242624",
      "id" : 574373604009242624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_iVv-tU8AAscX2.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ir0p6Zotgu"
    } ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 69, 77 ]
    }, {
      "text" : "Selma50",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/2qwxHksVTc",
      "expanded_url" : "http:\/\/go.wh.gov\/Selma-speech",
      "display_url" : "go.wh.gov\/Selma-speech"
    } ]
  },
  "geo" : { },
  "id_str" : "574373904153710592",
  "text" : "We the people.\nWe shall overcome.\nYes we can.\nhttp:\/\/t.co\/2qwxHksVTc\n#MarchOn #Selma50 http:\/\/t.co\/ir0p6Zotgu",
  "id" : 574373904153710592,
  "created_at" : "2015-03-08 00:59:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574359217081032704",
  "text" : "RT @FLOTUS: What a privilege to stand on the Edmund Pettus Bridge today. We all honor Selma's legacy by how we #MarchOn. http:\/\/t.co\/fdEx9H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MarchOn",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/fdEx9H8l4B",
        "expanded_url" : "http:\/\/wh.gov\/Selma",
        "display_url" : "wh.gov\/Selma"
      } ]
    },
    "geo" : { },
    "id_str" : "574358086359642112",
    "text" : "What a privilege to stand on the Edmund Pettus Bridge today. We all honor Selma's legacy by how we #MarchOn. http:\/\/t.co\/fdEx9H8l4B -mo",
    "id" : 574358086359642112,
    "created_at" : "2015-03-07 23:56:53 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 574359217081032704,
  "created_at" : "2015-03-08 00:01:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/574346077052235776\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ojdaBPiTmF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_h8epZUwAAkBgA.jpg",
      "id_str" : "574345818439729152",
      "id" : 574345818439729152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_h8epZUwAAkBgA.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ojdaBPiTmF"
    } ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 95, 103 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574346077052235776",
  "text" : "\"50 years from Bloody Sunday, our march is not yet finished, but we\u2019re getting closer.\" \u2014Obama #Selma50 #MarchOn http:\/\/t.co\/ojdaBPiTmF",
  "id" : 574346077052235776,
  "created_at" : "2015-03-07 23:09:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574327746064707584",
  "text" : "RT @rhodes44: That's President Obama at his absolute best.  A speech about how - and why - we love America so much. #Selma",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Selma",
        "indices" : [ 102, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574315008651231232",
    "text" : "That's President Obama at his absolute best.  A speech about how - and why - we love America so much. #Selma",
    "id" : 574315008651231232,
    "created_at" : "2015-03-07 21:05:42 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 574327746064707584,
  "created_at" : "2015-03-07 21:56:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574317035271942146",
  "text" : "RT @repjohnlewis: When people tell me nothing has changed, I say come walk in my shoes and I will show you change. #Selma50 http:\/\/t.co\/9Nv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/574304057378078720\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/9NvfJdSo8r",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_hWfthUgAA3gg0.jpg",
        "id_str" : "574304055285022720",
        "id" : 574304055285022720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_hWfthUgAA3gg0.jpg",
        "sizes" : [ {
          "h" : 1092,
          "resize" : "fit",
          "w" : 1687
        }, {
          "h" : 663,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 220,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 388,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/9NvfJdSo8r"
      } ],
      "hashtags" : [ {
        "text" : "Selma50",
        "indices" : [ 97, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574304057378078720",
    "text" : "When people tell me nothing has changed, I say come walk in my shoes and I will show you change. #Selma50 http:\/\/t.co\/9NvfJdSo8r",
    "id" : 574304057378078720,
    "created_at" : "2015-03-07 20:22:11 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 574317035271942146,
  "created_at" : "2015-03-07 21:13:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574316155311112192",
  "text" : "RT @arneduncan: The spirit of Selma should live in all of us &amp; keep us working hard until all kids have same access to educational opportun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Selma50",
        "indices" : [ 133, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574313176361127936",
    "text" : "The spirit of Selma should live in all of us &amp; keep us working hard until all kids have same access to educational opportunities #Selma50",
    "id" : 574313176361127936,
    "created_at" : "2015-03-07 20:58:26 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 574316155311112192,
  "created_at" : "2015-03-07 21:10:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 111, 119 ]
    }, {
      "text" : "Selma50",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574315357999079424",
  "text" : "RT @VP: We march for a future more whole &amp; just. We march for America's character and vision. Together, we #MarchOn. #Selma50 http:\/\/t.co\/R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/574315004280856576\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/RmxE2Kqx50",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_hgcfUUsAAuFOS.jpg",
        "id_str" : "574314995049082880",
        "id" : 574314995049082880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_hgcfUUsAAuFOS.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/RmxE2Kqx50"
      } ],
      "hashtags" : [ {
        "text" : "MarchOn",
        "indices" : [ 103, 111 ]
      }, {
        "text" : "Selma50",
        "indices" : [ 113, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574315004280856576",
    "text" : "We march for a future more whole &amp; just. We march for America's character and vision. Together, we #MarchOn. #Selma50 http:\/\/t.co\/RmxE2Kqx50",
    "id" : 574315004280856576,
    "created_at" : "2015-03-07 21:05:41 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 574315357999079424,
  "created_at" : "2015-03-07 21:07:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 96, 104 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574311180191272962",
  "text" : "\"We honor those who walked so we could run. We must run so our children soar.\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574311180191272962,
  "created_at" : "2015-03-07 20:50:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574311104739958784",
  "text" : "\"Our job\u2019s easier because somebody already got us through that first mile. Somebody already got us over that bridge.\" \u2014Obama #MarchOn",
  "id" : 574311104739958784,
  "created_at" : "2015-03-07 20:50:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574311024159031296",
  "text" : "\"239 years after this nation\u2019s founding, our union is not yet perfect. But we are getting closer.\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574311024159031296,
  "created_at" : "2015-03-07 20:49:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574310927727726593",
  "text" : "\"Fifty years from Bloody Sunday, our march is not yet finished. But we\u2019re getting closer.\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574310927727726593,
  "created_at" : "2015-03-07 20:49:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 115, 123 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574310855678017536",
  "text" : "\"Oh, what a glorious task we are given, to continually try to improve this great nation of ours.\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574310855678017536,
  "created_at" : "2015-03-07 20:49:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574310745661444096",
  "text" : "\"The single most powerful word in our democracy is...\u201Cwe.\u201D WE the people. WE shall overcome. Yes WE can. It is owned by no one.\" \u2014Obama",
  "id" : 574310745661444096,
  "created_at" : "2015-03-07 20:48:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 135, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574310558436102146",
  "text" : "\"Everywhere in this country, there are first steps to be taken, and new ground to cover &amp; bridges to be crossed.\" \u2014President Obama #MarchOn",
  "id" : 574310558436102146,
  "created_at" : "2015-03-07 20:48:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 135, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574310442450944000",
  "text" : "\"That\u2019s what the young people here today &amp; listening all across the country must take away from this day. You are America.\" \u2014Obama #MarchOn",
  "id" : 574310442450944000,
  "created_at" : "2015-03-07 20:47:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "Selma50",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574310368585064448",
  "text" : "\"We respect the past, but we don\u2019t pine for the past. We don\u2019t fear the future, we grab for it.\" \u2014President Obama #MarchOn #Selma50",
  "id" : 574310368585064448,
  "created_at" : "2015-03-07 20:47:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574310128947757056",
  "text" : "\"We are Jackie Robinson, enduring...spiked cleats and pitches...straight to his head, and stealing home in the World Series anyway.\" \u2014Obama",
  "id" : 574310128947757056,
  "created_at" : "2015-03-07 20:46:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574310014690705409",
  "text" : "\"We are the gay Americans whose blood ran on the streets of San Francisco and New York, just as blood ran down this bridge.\" \u2014Obama #MarchOn",
  "id" : 574310014690705409,
  "created_at" : "2015-03-07 20:45:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574309933287665665",
  "text" : "\"We\u2019re the firefighters who rushed into those buildings on 9\/11 &amp; the volunteers who signed up to fight in Afghanistan &amp; Iraq\" \u2014Obama",
  "id" : 574309933287665665,
  "created_at" : "2015-03-07 20:45:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 92, 100 ]
    }, {
      "text" : "Selma50",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574309805092921346",
  "text" : "\"We\u2019re the slaves who built the @WhiteHouse and the economy of the South.\" \u2014President Obama #MarchOn #Selma50",
  "id" : 574309805092921346,
  "created_at" : "2015-03-07 20:45:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 103, 111 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574309459750682624",
  "text" : "\"They loved this country so much that they\u2019d risk everything to realize its promise.\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574309459750682624,
  "created_at" : "2015-03-07 20:43:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574308985593069568",
  "text" : "\"What's our excuse today for not voting? How do we so casually discard the right for which so many fought?\" \u2014Obama urging Americans to vote",
  "id" : 574308985593069568,
  "created_at" : "2015-03-07 20:41:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574308475351752704",
  "text" : "\"Right now, in 2015, 50 years after Selma, there are laws across this country designed to make it harder for people to vote\" \u2014Obama #Selma50",
  "id" : 574308475351752704,
  "created_at" : "2015-03-07 20:39:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574308406787465216",
  "text" : "\"With effort, we can protect the foundation stone of our democracy for which so many marched across this bridge...the right to vote.\" \u2014Obama",
  "id" : 574308406787465216,
  "created_at" : "2015-03-07 20:39:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 126, 134 ]
    }, {
      "text" : "Selma50",
      "indices" : [ 135, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574308348100763648",
  "text" : "\"We can make sure every person willing to work has the dignity of a job, and a fair wage &amp; a real voice\" \u2014President Obama #MarchOn #Selma50",
  "id" : 574308348100763648,
  "created_at" : "2015-03-07 20:39:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574307950023602177",
  "text" : "\"All of us need to recognize, as they did, that change depends on our actions, on our attitudes.\" \u2014President Obama #MarchOn",
  "id" : 574307950023602177,
  "created_at" : "2015-03-07 20:37:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574307761544163330",
  "text" : "\"If we want to honor the courage of those who marched that day then all of us are called to possess their moral imagination\" \u2014Obama #MarchOn",
  "id" : 574307761544163330,
  "created_at" : "2015-03-07 20:36:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574307661036060673",
  "text" : "RT @WHLive: \"We know the march is not yet over, the race is not yet won\" \u2014President Obama #Selma50 #MarchOn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Selma50",
        "indices" : [ 78, 86 ]
      }, {
        "text" : "MarchOn",
        "indices" : [ 87, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574307609836154880",
    "text" : "\"We know the march is not yet over, the race is not yet won\" \u2014President Obama #Selma50 #MarchOn",
    "id" : 574307609836154880,
    "created_at" : "2015-03-07 20:36:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 574307661036060673,
  "created_at" : "2015-03-07 20:36:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574307507272835072",
  "text" : "\"We just need to open our eyes, and ears, and hearts, to know that this nation\u2019s racial history still casts its long shadow upon us.\" \u2014Obama",
  "id" : 574307507272835072,
  "created_at" : "2015-03-07 20:35:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 115, 123 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574307361063571456",
  "text" : "\"Ask your gay friend if it\u2019s easier to be out and proud in America now than it was 30 years ago.\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574307361063571456,
  "created_at" : "2015-03-07 20:35:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 118, 126 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574307289064194048",
  "text" : "\"Ask the female CEO who once might have been assigned to the secretarial pool if nothing\u2019s changed.\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574307289064194048,
  "created_at" : "2015-03-07 20:35:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574307225298145280",
  "text" : "\"If you think nothing\u2019s changed in the past 50 years, ask somebody who lived through the Selma or Chicago...of the 1950s\" \u2014Obama #Selma50",
  "id" : 574307225298145280,
  "created_at" : "2015-03-07 20:34:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 107, 115 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574307041428250624",
  "text" : "\"When it comes to the pursuit of justice, we can afford neither complacency nor despair.\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574307041428250624,
  "created_at" : "2015-03-07 20:34:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574306923996123136",
  "text" : "\"Selma teaches us, as well, that action requires that we shed our cynicism\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574306923996123136,
  "created_at" : "2015-03-07 20:33:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 108, 116 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574306802898239488",
  "text" : "\"We have to recognize that one day\u2019s commemoration, no matter how special, is not enough.\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574306802898239488,
  "created_at" : "2015-03-07 20:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574306646542979072",
  "text" : "\"Because of what they did, the doors of opportunity swung open not just for black folks, but for every American.\" \u2014President Obama #Selma50",
  "id" : 574306646542979072,
  "created_at" : "2015-03-07 20:32:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 130, 138 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 139, 147 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574306496693059584",
  "text" : "\"Because of campaigns like this, a Voting Rights Act was passed. Political &amp; economic &amp; social barriers came down\" \u2014Obama #Selma50 #MarchOn",
  "id" : 574306496693059584,
  "created_at" : "2015-03-07 20:31:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 112, 120 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574306113132359682",
  "text" : "\"Loving this country requires more than singing its praises or avoiding uncomfortable truths.\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574306113132359682,
  "created_at" : "2015-03-07 20:30:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574305866821865475",
  "text" : "\"That\u2019s what we celebrate here in Selma. That\u2019s what this movement was all about\u2014one leg in our long journey toward freedom\" \u2014Obama #Selma50",
  "id" : 574305866821865475,
  "created_at" : "2015-03-07 20:29:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574305739625361408",
  "text" : "\"'We hold these truths to be self-evident, that all men are created equal.'\"\n\"These are not just words. They are...a call to action\" \u2014Obama",
  "id" : 574305739625361408,
  "created_at" : "2015-03-07 20:28:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574305614878347266",
  "text" : "\"Each successive generation can look upon our imperfections and decide that it is in our power to remake this nation\" \u2014Obama #MarchOn",
  "id" : 574305614878347266,
  "created_at" : "2015-03-07 20:28:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 104, 112 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574305275093606400",
  "text" : "\"They proved that nonviolent change is possible; that love and hope can conquer hate.\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574305275093606400,
  "created_at" : "2015-03-07 20:27:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574305178381389826",
  "text" : "\"They didn\u2019t seek special treatment, just the equal treatment promised to them almost a century before.\" \u2014President Obama #Selma50",
  "id" : 574305178381389826,
  "created_at" : "2015-03-07 20:26:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 118, 126 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574305013247377408",
  "text" : "\"The Americans who crossed this bridge, they were not physically imposing. But they gave courage to millions.\" \u2014Obama #Selma50 #MarchOn",
  "id" : 574305013247377408,
  "created_at" : "2015-03-07 20:25:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574304940308455424",
  "text" : "\"What enormous faith these men and women had. Faith in God, but also faith in America.\" \u2014Obama on those who marched 50 years ago #Selma50",
  "id" : 574304940308455424,
  "created_at" : "2015-03-07 20:25:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 140, 148 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574304682891472896",
  "text" : "\"They went back again and again. When the trumpet call sounded for more to join, the people came\u2014black &amp; white, young &amp; old\" \u2014Obama #Selma50",
  "id" : 574304682891472896,
  "created_at" : "2015-03-07 20:24:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 122, 130 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574304597000458240",
  "text" : "\"They did as Scripture instructed: 'Rejoice in hope, be patient in tribulation, be constant in prayer.'\" \u2014President Obama #Selma50 #MarchOn",
  "id" : 574304597000458240,
  "created_at" : "2015-03-07 20:24:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574304457372073984",
  "text" : "RT @WHLive: \"We gather here to honor the courage of ordinary Americans willing to endure billy clubs and the chastening rod\" \u2014Obama #Selma5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Selma50",
        "indices" : [ 120, 128 ]
      }, {
        "text" : "MarchOn",
        "indices" : [ 129, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574304426917261312",
    "text" : "\"We gather here to honor the courage of ordinary Americans willing to endure billy clubs and the chastening rod\" \u2014Obama #Selma50 #MarchOn",
    "id" : 574304426917261312,
    "created_at" : "2015-03-07 20:23:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 574304457372073984,
  "created_at" : "2015-03-07 20:23:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574304092773838848",
  "text" : "\"It was not a clash of armies, but a clash of wills; a contest to determine the true meaning of America.\" \u2014President Obama on #Selma50",
  "id" : 574304092773838848,
  "created_at" : "2015-03-07 20:22:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 119, 127 ]
    }, {
      "text" : "MarchOn",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574303862384885760",
  "text" : "\"There are places and moments in America where this nation\u2019s destiny has been decided...Selma is such a place.\" \u2014Obama #Selma50 #MarchOn",
  "id" : 574303862384885760,
  "created_at" : "2015-03-07 20:21:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574303626350452736",
  "text" : "RT @WHLive: \"His knapsack stocked with an apple, a toothbrush, and a book on government...John Lewis led them...on a mission to change Amer\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574303584579371008",
    "text" : "\"His knapsack stocked with an apple, a toothbrush, and a book on government...John Lewis led them...on a mission to change America.\" \u2014Obama",
    "id" : 574303584579371008,
    "created_at" : "2015-03-07 20:20:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 574303626350452736,
  "created_at" : "2015-03-07 20:20:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 117, 125 ]
    }, {
      "text" : "Selma50",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574303117837213696",
  "text" : "\"It is a rare honor in this life to follow one of your heroes. And John Lewis is one of my heroes.\" \u2014President Obama #MarchOn #Selma50",
  "id" : 574303117837213696,
  "created_at" : "2015-03-07 20:18:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma50",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/3SsOWZ8iSo",
      "expanded_url" : "http:\/\/wh.gov\/Selma",
      "display_url" : "wh.gov\/Selma"
    } ]
  },
  "geo" : { },
  "id_str" : "574302922827304960",
  "text" : "Watch live: President Obama commemorates the 50th anniversary of the marches from Selma to Montgomery \u2192 http:\/\/t.co\/3SsOWZ8iSo #Selma50",
  "id" : 574302922827304960,
  "created_at" : "2015-03-07 20:17:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma",
      "indices" : [ 41, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574288488109113345",
  "text" : "RT @PressSec: POTUS motorcade arrives in #Selma.  He will address the crowd here in a half-hour or so. Worth watching. http:\/\/t.co\/SAMUxztz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/574288108650434561\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/SAMUxztzfZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_hH_fDWwAAr_Dx.jpg",
        "id_str" : "574288108482641920",
        "id" : 574288108482641920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_hH_fDWwAAr_Dx.jpg",
        "sizes" : [ {
          "h" : 784,
          "resize" : "fit",
          "w" : 784
        }, {
          "h" : 784,
          "resize" : "fit",
          "w" : 784
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/SAMUxztzfZ"
      } ],
      "hashtags" : [ {
        "text" : "Selma",
        "indices" : [ 27, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574288108650434561",
    "text" : "POTUS motorcade arrives in #Selma.  He will address the crowd here in a half-hour or so. Worth watching. http:\/\/t.co\/SAMUxztzfZ",
    "id" : 574288108650434561,
    "created_at" : "2015-03-07 19:18:49 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 574288488109113345,
  "created_at" : "2015-03-07 19:20:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574286581948874753",
  "text" : "RT @vj44: On AF1, POTUS signed HR 431 awarding Congressional Gold Medals to the foot soldiers who participated in the Selma marches. #March\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MarchOn",
        "indices" : [ 123, 131 ]
      }, {
        "text" : "Selma50",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574280518021345281",
    "text" : "On AF1, POTUS signed HR 431 awarding Congressional Gold Medals to the foot soldiers who participated in the Selma marches. #MarchOn #Selma50",
    "id" : 574280518021345281,
    "created_at" : "2015-03-07 18:48:39 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 574286581948874753,
  "created_at" : "2015-03-07 19:12:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Selma",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574279341657493504",
  "text" : "RT @AmbassadorRice: Our work is not yet finished @ home, but the values &amp; rights pursued in #Selma are those we're working to spread &amp; secu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Selma",
        "indices" : [ 76, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574276978007674881",
    "text" : "Our work is not yet finished @ home, but the values &amp; rights pursued in #Selma are those we're working to spread &amp; secure around the world.",
    "id" : 574276978007674881,
    "created_at" : "2015-03-07 18:34:35 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 574279341657493504,
  "created_at" : "2015-03-07 18:43:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574247919622176768",
  "text" : "RT @repjohnlewis: 50 yrs ago today, we set out to march from Selma to Montgomery to dramatize to the nation that people of color were denie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574231423579766784",
    "text" : "50 yrs ago today, we set out to march from Selma to Montgomery to dramatize to the nation that people of color were denied the right to vote",
    "id" : 574231423579766784,
    "created_at" : "2015-03-07 15:33:34 +0000",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 574247919622176768,
  "created_at" : "2015-03-07 16:39:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/hTUeq5vpBT",
      "expanded_url" : "http:\/\/go.wh.gov\/4B3gt1",
      "display_url" : "go.wh.gov\/4B3gt1"
    } ]
  },
  "geo" : { },
  "id_str" : "574231034201534465",
  "text" : "\"A world in which girls are educated is a safer, more stable, more prosperous place.\" \u2014Obama: http:\/\/t.co\/hTUeq5vpBT #LetGirlsLearn",
  "id" : 574231034201534465,
  "created_at" : "2015-03-07 15:32:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/3SsOWYQHtO",
      "expanded_url" : "http:\/\/wh.gov\/Selma",
      "display_url" : "wh.gov\/Selma"
    } ]
  },
  "geo" : { },
  "id_str" : "573978935907627008",
  "text" : "Tomorrow, President Obama will commemorate the 50th anniversary of the marches from Selma to Montgomery: http:\/\/t.co\/3SsOWYQHtO #MarchOn",
  "id" : 573978935907627008,
  "created_at" : "2015-03-06 22:50:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 71, 82 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Dan Pfeiffer",
      "screen_name" : "danpfeiffer",
      "indices" : [ 90, 102 ],
      "id_str" : "2922928743",
      "id" : 2922928743
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573972422019313664\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/PuwUM2yDlS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_cn_OZUYAEj1Zk.jpg",
      "id_str" : "573971444662558721",
      "id" : 573971444662558721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_cn_OZUYAEj1Zk.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PuwUM2yDlS"
    } ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 84, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573972422019313664",
  "text" : "Nearly 3,000 days of service to the President \u2713\nThanks for everything, @Pfeiffer44.\n#FF \u2192 @DanPfeiffer http:\/\/t.co\/PuwUM2yDlS",
  "id" : 573972422019313664,
  "created_at" : "2015-03-06 22:24:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573959093414719488\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/6ysHGSNjPA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_ccpXqUsAAYmmG.jpg",
      "id_str" : "573958974564773888",
      "id" : 573958974564773888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_ccpXqUsAAYmmG.jpg",
      "sizes" : [ {
        "h" : 281,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6ysHGSNjPA"
    } ],
    "hashtags" : [ {
      "text" : "MarchOn",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/3SsOWZ8iSo",
      "expanded_url" : "http:\/\/wh.gov\/Selma",
      "display_url" : "wh.gov\/Selma"
    } ]
  },
  "geo" : { },
  "id_str" : "573959093414719488",
  "text" : "Half a century later, take a look back at the marches from Selma to Montgomery \u2192 http:\/\/t.co\/3SsOWZ8iSo #MarchOn http:\/\/t.co\/6ysHGSNjPA",
  "id" : 573959093414719488,
  "created_at" : "2015-03-06 21:31:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573941036520620032\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/czH4fvKjxl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_cLmK1UcAAdzax.png",
      "id_str" : "573940227883954176",
      "id" : 573940227883954176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_cLmK1UcAAdzax.png",
      "sizes" : [ {
        "h" : 334,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 933
      }, {
        "h" : 519,
        "resize" : "fit",
        "w" : 933
      } ],
      "display_url" : "pic.twitter.com\/czH4fvKjxl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/tvUK6YnK8C",
      "expanded_url" : "http:\/\/go.wh.gov\/TBVMLQ",
      "display_url" : "go.wh.gov\/TBVMLQ"
    } ]
  },
  "geo" : { },
  "id_str" : "573941036520620032",
  "text" : "\u201COur goal should be to stop circumstances such as what happened in Ferguson\" \u2014President Obama: http:\/\/t.co\/tvUK6YnK8C http:\/\/t.co\/czH4fvKjxl",
  "id" : 573941036520620032,
  "created_at" : "2015-03-06 20:19:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573935182832500736\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/V81wWtz1Et",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_cG1xmU8AAe3Gp.png",
      "id_str" : "573934998429954048",
      "id" : 573934998429954048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_cG1xmU8AAe3Gp.png",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 933
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 933
      } ],
      "display_url" : "pic.twitter.com\/V81wWtz1Et"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573935182832500736",
  "text" : "\u201CI might just be warming up the seat for you.\u201D \u2014Obama to a 10-year-old who is \"thinking about\" running for President http:\/\/t.co\/V81wWtz1Et",
  "id" : 573935182832500736,
  "created_at" : "2015-03-06 19:56:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573934155576143872\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/jI1ny0D01j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_cF-czUcAAAiOO.png",
      "id_str" : "573934047954497536",
      "id" : 573934047954497536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_cF-czUcAAAiOO.png",
      "sizes" : [ {
        "h" : 521,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/jI1ny0D01j"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573934155576143872",
  "text" : "\"Think about more than just yourself. Think about how you can have an impact beyond just yourself.\" \u2014President Obama http:\/\/t.co\/jI1ny0D01j",
  "id" : 573934155576143872,
  "created_at" : "2015-03-06 19:52:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedict College",
      "screen_name" : "BenedictEDU",
      "indices" : [ 117, 129 ],
      "id_str" : "1670686340",
      "id" : 1670686340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573933298277335040",
  "text" : "\u201CWe\u2019ve still got to fight to make sure that every child, not just some, have equal opportunity.\u201D \u2014President Obama at @BenedictEDU",
  "id" : 573933298277335040,
  "created_at" : "2015-03-06 19:48:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benedict College",
      "screen_name" : "BenedictEDU",
      "indices" : [ 80, 92 ],
      "id_str" : "1670686340",
      "id" : 1670686340
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573932277459120129\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/oRBdFILRhk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_cEPOnUYAAfGKX.png",
      "id_str" : "573932137180585984",
      "id" : 573932137180585984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_cEPOnUYAAfGKX.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 514,
        "resize" : "fit",
        "w" : 929
      }, {
        "h" : 514,
        "resize" : "fit",
        "w" : 929
      } ],
      "display_url" : "pic.twitter.com\/oRBdFILRhk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573932277459120129",
  "text" : "\u201CDo not get cynical about what\u2019s possible.\" \u2014President Obama to young people at @BenedictEDU http:\/\/t.co\/oRBdFILRhk",
  "id" : 573932277459120129,
  "created_at" : "2015-03-06 19:44:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 119, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573930632667000832",
  "text" : "\u201CUltimately, I want the first two years of community college to be like public high schools are now.\u201D \u2014President Obama #FreeCommunityCollege",
  "id" : 573930632667000832,
  "created_at" : "2015-03-06 19:38:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573930278068031488\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/M0FQU7rA58",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_cCcmRUwAAXaT6.jpg",
      "id_str" : "573930167845830656",
      "id" : 573930167845830656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_cCcmRUwAAXaT6.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/M0FQU7rA58"
    } ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 62, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573930278068031488",
  "text" : "\u201CLet\u2019s make community colleges free.\u201D \u2014President Obama on his #FreeCommunityCollege proposal http:\/\/t.co\/M0FQU7rA58",
  "id" : 573930278068031488,
  "created_at" : "2015-03-06 19:36:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573929888987488256\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/exuNhIr2rS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_cCKidUIAAIFmg.jpg",
      "id_str" : "573929857584734208",
      "id" : 573929857584734208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_cCKidUIAAIFmg.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/exuNhIr2rS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573929888987488256",
  "text" : "\u201CWe capped the percentage of your income that you have to pay in repaying your student loans.\u201D \u2014President Obama http:\/\/t.co\/exuNhIr2rS",
  "id" : 573929888987488256,
  "created_at" : "2015-03-06 19:35:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573928367700992000",
  "text" : "\u201CIt\u2019s not science fiction. It\u2019s not speculation. This is what the science tells us.\u201D \u2014President Obama on why it's time to #ActOnClimate",
  "id" : 573928367700992000,
  "created_at" : "2015-03-06 19:29:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573925967887994880",
  "text" : "\u201COur businesses have added more than 200,000 jobs a month for the past year, and we have not seen a streak like that in 37 years.\" \u2014Obama",
  "id" : 573925967887994880,
  "created_at" : "2015-03-06 19:19:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/573925684042670081\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/URqot1KF0P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_b-WJvUcAAOR5C.jpg",
      "id_str" : "573925659061284864",
      "id" : 573925659061284864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_b-WJvUcAAOR5C.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/URqot1KF0P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573925684042670081",
  "text" : "\"Our economy created nearly 300,000 new jobs last month.\" \u2014President Obama http:\/\/t.co\/URqot1KF0P",
  "id" : 573925684042670081,
  "created_at" : "2015-03-06 19:18:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573925170617831424",
  "text" : "\"Selma\u2019s about each of us asking ourselves what we can do to make America better.\" \u2014President Obama",
  "id" : 573925170617831424,
  "created_at" : "2015-03-06 19:16:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/prbZ0gVsX6",
      "expanded_url" : "http:\/\/go.wh.gov\/pSiSn8",
      "display_url" : "go.wh.gov\/pSiSn8"
    } ]
  },
  "geo" : { },
  "id_str" : "573925049633275904",
  "text" : "\"Selma isn\u2019t just about commemorating our past...Selma is now. \u201C \u2014President Obama\nWatch \u2192 http:\/\/t.co\/prbZ0gVsX6",
  "id" : 573925049633275904,
  "created_at" : "2015-03-06 19:16:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573924513638977537",
  "text" : "\"Tomorrow, I\u2019ll be visiting Selma, Alabama, for the 50th anniversary of the march.\" \u2014President Obama",
  "id" : 573924513638977537,
  "created_at" : "2015-03-06 19:14:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/prbZ0hd3OE",
      "expanded_url" : "http:\/\/go.wh.gov\/pSiSn8",
      "display_url" : "go.wh.gov\/pSiSn8"
    } ]
  },
  "geo" : { },
  "id_str" : "573923839211515904",
  "text" : "Watch live: President Obama speaks at a town hall at Benedict College in South Carolina \u2192 http:\/\/t.co\/prbZ0hd3OE",
  "id" : 573923839211515904,
  "created_at" : "2015-03-06 19:11:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "HumanRightsCampaign",
      "screen_name" : "HRC",
      "indices" : [ 123, 127 ],
      "id_str" : "19608297",
      "id" : 19608297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573917216162344960",
  "text" : "RT @VP: \"We now live...in a nation where 224 million Americans in 37 states live where same sex marriage is legal.\" -VP at @HRC #EqualityCo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HumanRightsCampaign",
        "screen_name" : "HRC",
        "indices" : [ 115, 119 ],
        "id_str" : "19608297",
        "id" : 19608297
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualityConvention",
        "indices" : [ 120, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573911535849893888",
    "text" : "\"We now live...in a nation where 224 million Americans in 37 states live where same sex marriage is legal.\" -VP at @HRC #EqualityConvention",
    "id" : 573911535849893888,
    "created_at" : "2015-03-06 18:22:27 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 573917216162344960,
  "created_at" : "2015-03-06 18:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/573903288627650560\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/iI8l9RwSDf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_bpzX4UsAAJO4D.jpg",
      "id_str" : "573903071329169408",
      "id" : 573903071329169408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_bpzX4UsAAJO4D.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/iI8l9RwSDf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/EzVcwTKKqD",
      "expanded_url" : "http:\/\/go.wh.gov\/xc6jEj",
      "display_url" : "go.wh.gov\/xc6jEj"
    } ]
  },
  "geo" : { },
  "id_str" : "573903288627650560",
  "text" : "FACT: U.S. manufacturers have added 877,000 jobs since February 2010 \u2192 http:\/\/t.co\/EzVcwTKKqD http:\/\/t.co\/iI8l9RwSDf",
  "id" : 573903288627650560,
  "created_at" : "2015-03-06 17:49:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David E. Price",
      "screen_name" : "RepDavidEPrice",
      "indices" : [ 3, 18 ],
      "id_str" : "155669457",
      "id" : 155669457
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleClassFirst",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573892832412495872",
  "text" : "RT @RepDavidEPrice: Last month, businesses added 288k jobs; last year, 3.2 million; over the last 5 years, 12 million. #MiddleClassFirst ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RepDavidEPrice\/status\/573875996954353665\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/4oj7Orph52",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_bRLaNWcAAqc5Y.jpg",
        "id_str" : "573875996480401408",
        "id" : 573875996480401408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_bRLaNWcAAqc5Y.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4oj7Orph52"
      } ],
      "hashtags" : [ {
        "text" : "MiddleClassFirst",
        "indices" : [ 99, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573875996954353665",
    "text" : "Last month, businesses added 288k jobs; last year, 3.2 million; over the last 5 years, 12 million. #MiddleClassFirst http:\/\/t.co\/4oj7Orph52",
    "id" : 573875996954353665,
    "created_at" : "2015-03-06 16:01:14 +0000",
    "user" : {
      "name" : "David E. Price",
      "screen_name" : "RepDavidEPrice",
      "protected" : false,
      "id_str" : "155669457",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/990224608\/David_Price_normal.jpg",
      "id" : 155669457,
      "verified" : true
    }
  },
  "id" : 573892832412495872,
  "created_at" : "2015-03-06 17:08:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573880808169066497\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3DsKczCdTr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_bQTjFUYAAanQw.jpg",
      "id_str" : "573875036789956608",
      "id" : 573875036789956608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_bQTjFUYAAanQw.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3DsKczCdTr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/EzVcwTKKqD",
      "expanded_url" : "http:\/\/go.wh.gov\/xc6jEj",
      "display_url" : "go.wh.gov\/xc6jEj"
    } ]
  },
  "geo" : { },
  "id_str" : "573880808169066497",
  "text" : "FACT: The unemployment rate has fallen 1.2 percentage points over the last 12 months to 5.5%. http:\/\/t.co\/EzVcwTKKqD http:\/\/t.co\/3DsKczCdTr",
  "id" : 573880808169066497,
  "created_at" : "2015-03-06 16:20:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Tonko",
      "screen_name" : "RepPaulTonko",
      "indices" : [ 3, 16 ],
      "id_str" : "84119348",
      "id" : 84119348
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573863969120776193\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/CMoMui1Yej",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_bGHEuUwAAlGCF.jpg",
      "id_str" : "573863827365740544",
      "id" : 573863827365740544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_bGHEuUwAAlGCF.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CMoMui1Yej"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/xVHqAeBUhF",
      "expanded_url" : "http:\/\/go.wh.gov\/xc6jEj",
      "display_url" : "go.wh.gov\/xc6jEj"
    } ]
  },
  "geo" : { },
  "id_str" : "573875733132537857",
  "text" : "RT @RepPaulTonko: U.S. manufacturers have added 877,000 jobs since February 2010 \u2192 http:\/\/t.co\/xVHqAeBUhF http:\/\/t.co\/CMoMui1Yej",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573863969120776193\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/CMoMui1Yej",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_bGHEuUwAAlGCF.jpg",
        "id_str" : "573863827365740544",
        "id" : 573863827365740544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_bGHEuUwAAlGCF.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CMoMui1Yej"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/xVHqAeBUhF",
        "expanded_url" : "http:\/\/go.wh.gov\/xc6jEj",
        "display_url" : "go.wh.gov\/xc6jEj"
      } ]
    },
    "geo" : { },
    "id_str" : "573874157718487040",
    "text" : "U.S. manufacturers have added 877,000 jobs since February 2010 \u2192 http:\/\/t.co\/xVHqAeBUhF http:\/\/t.co\/CMoMui1Yej",
    "id" : 573874157718487040,
    "created_at" : "2015-03-06 15:53:55 +0000",
    "user" : {
      "name" : "Paul Tonko",
      "screen_name" : "RepPaulTonko",
      "protected" : false,
      "id_str" : "84119348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1899423387\/7816_169238546404_164036221404_4308792_5415270_n_normal.jpg",
      "id" : 84119348,
      "verified" : true
    }
  },
  "id" : 573875733132537857,
  "created_at" : "2015-03-06 16:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573867793289871360\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/HhkVpRnlVK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_bJjsjVEAACWSu.jpg",
      "id_str" : "573867617628262400",
      "id" : 573867617628262400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_bJjsjVEAACWSu.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HhkVpRnlVK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/EzVcwTKKqD",
      "expanded_url" : "http:\/\/go.wh.gov\/xc6jEj",
      "display_url" : "go.wh.gov\/xc6jEj"
    } ]
  },
  "geo" : { },
  "id_str" : "573867793289871360",
  "text" : "2014 was the best year of job growth since the late 1990s, and 2015 has continued that pace \u2192 http:\/\/t.co\/EzVcwTKKqD http:\/\/t.co\/HhkVpRnlVK",
  "id" : 573867793289871360,
  "created_at" : "2015-03-06 15:28:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573863969120776193\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/iY7Pb9l3vG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_bGHEuUwAAlGCF.jpg",
      "id_str" : "573863827365740544",
      "id" : 573863827365740544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_bGHEuUwAAlGCF.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iY7Pb9l3vG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573863969120776193",
  "text" : "America's businesses have added at least 200,000 jobs in 12 straight months, the 1st time that's happened since 1977. http:\/\/t.co\/iY7Pb9l3vG",
  "id" : 573863969120776193,
  "created_at" : "2015-03-06 15:13:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 109, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/ISMQ8Sfxph",
      "expanded_url" : "http:\/\/youtu.be\/V2eTZrVePpY",
      "display_url" : "youtu.be\/V2eTZrVePpY"
    } ]
  },
  "geo" : { },
  "id_str" : "573607448554172416",
  "text" : "Find out how you can make a difference in the lives of some incredible young people \u2192 http:\/\/t.co\/ISMQ8Sfxph #MyBrothersKeeper",
  "id" : 573607448554172416,
  "created_at" : "2015-03-05 22:14:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573557495387582465\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/yOE5b6fn3Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Wve9oWIAA8HQm.jpg",
      "id_str" : "573557474034327552",
      "id" : 573557474034327552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Wve9oWIAA8HQm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yOE5b6fn3Z"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573557495387582465",
  "text" : "Here's how the Trans-Pacific Partnership will help level the playing field for American workers. #LeadOnTrade http:\/\/t.co\/yOE5b6fn3Z",
  "id" : 573557495387582465,
  "created_at" : "2015-03-05 18:55:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 4, 14 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/573522214022156288\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/PgBKawohQ3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_WPKKRVAAAryJA.jpg",
      "id_str" : "573521932278104064",
      "id" : 573521932278104064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_WPKKRVAAAryJA.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PgBKawohQ3"
    } ],
    "hashtags" : [ {
      "text" : "WWIM11",
      "indices" : [ 62, 69 ]
    }, {
      "text" : "WHInstaMeet",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/jV8SV6Zpve",
      "expanded_url" : "http:\/\/go.wh.gov\/Instameet",
      "display_url" : "go.wh.gov\/Instameet"
    } ]
  },
  "geo" : { },
  "id_str" : "573522214022156288",
  "text" : "Hey @Instagram users: Apply to join us at the White House for #WWIM11 \u2192 http:\/\/t.co\/jV8SV6Zpve #WHInstaMeet http:\/\/t.co\/PgBKawohQ3",
  "id" : 573522214022156288,
  "created_at" : "2015-03-05 16:35:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573506685823795200\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/V0lEyyZ6hC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_WAzgZU8AAZ7o8.png",
      "id_str" : "573506149917454336",
      "id" : 573506149917454336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_WAzgZU8AAZ7o8.png",
      "sizes" : [ {
        "h" : 205,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 847
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 847
      } ],
      "display_url" : "pic.twitter.com\/V0lEyyZ6hC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/uBDs9t3VPs",
      "expanded_url" : "http:\/\/go.wh.gov\/sXEiat",
      "display_url" : "go.wh.gov\/sXEiat"
    } ]
  },
  "geo" : { },
  "id_str" : "573506685823795200",
  "text" : "\"The United States seeks the peace and security of a world without nuclear weapons.\" \u2014Obama: http:\/\/t.co\/uBDs9t3VPs http:\/\/t.co\/V0lEyyZ6hC",
  "id" : 573506685823795200,
  "created_at" : "2015-03-05 15:33:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573501314518360065\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/RD63gWjyN2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_V8SuHVEAAPp76.jpg",
      "id_str" : "573501188617867264",
      "id" : 573501188617867264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_V8SuHVEAAPp76.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/RD63gWjyN2"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573501314518360065",
  "text" : "More exports = more jobs.\nU.S. exports supported 11.7 million American jobs in 2014. #LeadOnTrade http:\/\/t.co\/RD63gWjyN2",
  "id" : 573501314518360065,
  "created_at" : "2015-03-05 15:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573263087312248832\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/FbeQcI9gPx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_SjoUPU0AACqU9.jpg",
      "id_str" : "573262965605978112",
      "id" : 573262965605978112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_SjoUPU0AACqU9.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1360,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/FbeQcI9gPx"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/cEWIR52NSE",
      "expanded_url" : "http:\/\/wh.gov\/LetGirlsLearn",
      "display_url" : "wh.gov\/LetGirlsLearn"
    } ]
  },
  "geo" : { },
  "id_str" : "573263087312248832",
  "text" : "\"Every girl is precious. Every girl deserves an education.\" \u2014President Obama: http:\/\/t.co\/cEWIR52NSE #LetGirlsLearn http:\/\/t.co\/FbeQcI9gPx",
  "id" : 573263087312248832,
  "created_at" : "2015-03-04 23:25:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573245407850983424\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/z6dbQOBlpW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_STov1UwAAbywW.jpg",
      "id_str" : "573245380827070464",
      "id" : 573245380827070464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_STov1UwAAbywW.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/z6dbQOBlpW"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573245407850983424",
  "text" : "It's time for a trade deal that helps American workers and protects our environment. #LeadOnTrade http:\/\/t.co\/z6dbQOBlpW",
  "id" : 573245407850983424,
  "created_at" : "2015-03-04 22:15:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/573224900246278144\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/h7OOWWOivf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_SA-m3UoAAjosa.jpg",
      "id_str" : "573224865655726080",
      "id" : 573224865655726080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_SA-m3UoAAjosa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/h7OOWWOivf"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573224900246278144",
  "text" : "President Obama is fighting for a trade deal that preserves a free &amp; open internet for U.S. businesses. #LeadOnTrade http:\/\/t.co\/h7OOWWOivf",
  "id" : 573224900246278144,
  "created_at" : "2015-03-04 20:54:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573211378145615872",
  "text" : "RT @Simas44: President Obama is fighting for a trade deal that protects American workers &amp; helps sell U.S. goods around the world. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/573198287232212994\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/yW1pFNxS8w",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Roy9cVIAAQlan.jpg",
        "id_str" : "573198277279031296",
        "id" : 573198277279031296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Roy9cVIAAQlan.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/yW1pFNxS8w"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573198287232212994",
    "text" : "President Obama is fighting for a trade deal that protects American workers &amp; helps sell U.S. goods around the world. http:\/\/t.co\/yW1pFNxS8w",
    "id" : 573198287232212994,
    "created_at" : "2015-03-04 19:08:15 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 573211378145615872,
  "created_at" : "2015-03-04 20:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 3, 14 ],
      "id_str" : "44615672",
      "id" : 44615672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "exports",
      "indices" : [ 31, 39 ]
    }, {
      "text" : "LeadOnTrade",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/f2IFo5oBCA",
      "expanded_url" : "http:\/\/go.wh.gov\/CCFb1z",
      "display_url" : "go.wh.gov\/CCFb1z"
    } ]
  },
  "geo" : { },
  "id_str" : "573196481903005697",
  "text" : "RT @USTradeRep: FACT: American #exports supported more than 11.7 million U.S. jobs in 2014 \u2192 http:\/\/t.co\/f2IFo5oBCA #LeadOnTrade http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USTradeRep\/status\/573184466446729216\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/6QuDwPxADY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_RcO79UQAAvgJx.jpg",
        "id_str" : "573184464265691136",
        "id" : 573184464265691136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_RcO79UQAAvgJx.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6QuDwPxADY"
      } ],
      "hashtags" : [ {
        "text" : "exports",
        "indices" : [ 15, 23 ]
      }, {
        "text" : "LeadOnTrade",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/f2IFo5oBCA",
        "expanded_url" : "http:\/\/go.wh.gov\/CCFb1z",
        "display_url" : "go.wh.gov\/CCFb1z"
      } ]
    },
    "geo" : { },
    "id_str" : "573184466446729216",
    "text" : "FACT: American #exports supported more than 11.7 million U.S. jobs in 2014 \u2192 http:\/\/t.co\/f2IFo5oBCA #LeadOnTrade http:\/\/t.co\/6QuDwPxADY",
    "id" : 573184466446729216,
    "created_at" : "2015-03-04 18:13:20 +0000",
    "user" : {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "protected" : false,
      "id_str" : "44615672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662636758509596672\/O-ShXHZB_normal.png",
      "id" : 44615672,
      "verified" : true
    }
  },
  "id" : 573196481903005697,
  "created_at" : "2015-03-04 19:01:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573184744717987840\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/vsSlYsmImR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_RcdKhUQAAZwHe.jpg",
      "id_str" : "573184708692951040",
      "id" : 573184708692951040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_RcdKhUQAAZwHe.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vsSlYsmImR"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/t1CKT7PjOA",
      "expanded_url" : "http:\/\/go.wh.gov\/CCFb1z",
      "display_url" : "go.wh.gov\/CCFb1z"
    } ]
  },
  "geo" : { },
  "id_str" : "573184744717987840",
  "text" : "President Obama is fighting for a trade deal that protects American workers \u2192 http:\/\/t.co\/t1CKT7PjOA #LeadOnTrade http:\/\/t.co\/vsSlYsmImR",
  "id" : 573184744717987840,
  "created_at" : "2015-03-04 18:14:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573180201732980736\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/T0IXj1hAWC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_RYQCMVEAELiYJ.jpg",
      "id_str" : "573180085072629761",
      "id" : 573180085072629761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_RYQCMVEAELiYJ.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/T0IXj1hAWC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/t1CKT7xIq0",
      "expanded_url" : "http:\/\/go.wh.gov\/CCFb1z",
      "display_url" : "go.wh.gov\/CCFb1z"
    } ]
  },
  "geo" : { },
  "id_str" : "573180201732980736",
  "text" : "Helping our businesses sell more American goods around the world = more jobs here at home: http:\/\/t.co\/t1CKT7xIq0 http:\/\/t.co\/T0IXj1hAWC",
  "id" : 573180201732980736,
  "created_at" : "2015-03-04 17:56:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573164762365857792\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/A7DOT9sS3T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_RKPQhUQAAQt6n.jpg",
      "id_str" : "573164678576095232",
      "id" : 573164678576095232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_RKPQhUQAAQt6n.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/A7DOT9sS3T"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/cEWIR52NSE",
      "expanded_url" : "http:\/\/wh.gov\/LetGirlsLearn",
      "display_url" : "wh.gov\/LetGirlsLearn"
    } ]
  },
  "geo" : { },
  "id_str" : "573164762365857792",
  "text" : "It's time to increase access to education and empower girls around the world \u2192 http:\/\/t.co\/cEWIR52NSE #LetGirlsLearn http:\/\/t.co\/A7DOT9sS3T",
  "id" : 573164762365857792,
  "created_at" : "2015-03-04 16:55:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/573151280740368384\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/DfuOxoO09b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Q-CEcVIAAYUUL.jpg",
      "id_str" : "573151257856122880",
      "id" : 573151257856122880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Q-CEcVIAAYUUL.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/DfuOxoO09b"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "573151280740368384",
  "text" : "Let's break down barriers to girls' education around the world so they can build a brighter future. #LetGirlsLearn http:\/\/t.co\/DfuOxoO09b",
  "id" : 573151280740368384,
  "created_at" : "2015-03-04 16:01:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "indices" : [ 3, 17 ],
      "id_str" : "308573576",
      "id" : 308573576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 51, 56 ]
    }, {
      "text" : "exports",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/IBVo4oMvwi",
      "expanded_url" : "http:\/\/1.usa.gov\/1AImrbH",
      "display_url" : "1.usa.gov\/1AImrbH"
    } ]
  },
  "geo" : { },
  "id_str" : "573144983340888064",
  "text" : "RT @PennyPritzker: BREAKING: 11.7 million American #jobs are supported by #exports in 2014 http:\/\/t.co\/IBVo4oMvwi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 32, 37 ]
      }, {
        "text" : "exports",
        "indices" : [ 55, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/IBVo4oMvwi",
        "expanded_url" : "http:\/\/1.usa.gov\/1AImrbH",
        "display_url" : "1.usa.gov\/1AImrbH"
      } ]
    },
    "geo" : { },
    "id_str" : "573133508069232641",
    "text" : "BREAKING: 11.7 million American #jobs are supported by #exports in 2014 http:\/\/t.co\/IBVo4oMvwi",
    "id" : 573133508069232641,
    "created_at" : "2015-03-04 14:50:51 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 573144983340888064,
  "created_at" : "2015-03-04 15:36:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572898388741509120\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/axk3hFrPUK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_NXKd_UQAAECOw.jpg",
      "id_str" : "572897414966689792",
      "id" : 572897414966689792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_NXKd_UQAAECOw.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/axk3hFrPUK"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572898388741509120",
  "text" : "70% of the 1 billion people living in extreme poverty are women and girls.\nEducation can change that. #LetGirlsLearn http:\/\/t.co\/axk3hFrPUK",
  "id" : 572898388741509120,
  "created_at" : "2015-03-03 23:16:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572890998889697280\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/MAeL47egOK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_NRIgGUoAAawJp.jpg",
      "id_str" : "572890784103440384",
      "id" : 572890784103440384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_NRIgGUoAAawJp.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/MAeL47egOK"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 82, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/cEWIR52NSE",
      "expanded_url" : "http:\/\/wh.gov\/LetGirlsLearn",
      "display_url" : "wh.gov\/LetGirlsLearn"
    } ]
  },
  "geo" : { },
  "id_str" : "572890998889697280",
  "text" : "RT if you agree: Every girl deserves a quality education \u2192 http:\/\/t.co\/cEWIR52NSE #LetGirlsLearn http:\/\/t.co\/MAeL47egOK",
  "id" : 572890998889697280,
  "created_at" : "2015-03-03 22:47:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572881344037978112\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/vlHzYc3PVv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_NIgMTUsAAPc-H.jpg",
      "id_str" : "572881295501471744",
      "id" : 572881295501471744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_NIgMTUsAAPc-H.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/vlHzYc3PVv"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572881344037978112",
  "text" : "\"Wherever they live, whoever they are, every girl on this planet has value.\" \u2014President Obama #LetGirlsLearn http:\/\/t.co\/vlHzYc3PVv",
  "id" : 572881344037978112,
  "created_at" : "2015-03-03 22:08:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/572851987252834304\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/l4UpB9XiDk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Mt1lxUoAE4uy5.jpg",
      "id_str" : "572851976301486081",
      "id" : 572851976301486081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Mt1lxUoAE4uy5.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 804
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 804
      } ],
      "display_url" : "pic.twitter.com\/l4UpB9XiDk"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 82, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572860501291491328",
  "text" : "RT @vj44: Every child is precious. Every girl is precious. Let's work together to #LetGirlsLearn http:\/\/t.co\/l4UpB9XiDk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/572851987252834304\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/l4UpB9XiDk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Mt1lxUoAE4uy5.jpg",
        "id_str" : "572851976301486081",
        "id" : 572851976301486081,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Mt1lxUoAE4uy5.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 804
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 764,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 804
        } ],
        "display_url" : "pic.twitter.com\/l4UpB9XiDk"
      } ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 72, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572851987252834304",
    "text" : "Every child is precious. Every girl is precious. Let's work together to #LetGirlsLearn http:\/\/t.co\/l4UpB9XiDk",
    "id" : 572851987252834304,
    "created_at" : "2015-03-03 20:12:11 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 572860501291491328,
  "created_at" : "2015-03-03 20:46:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 24, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572854614401261568",
  "text" : "RT @FLOTUS: \"As part of #LetGirlsLearn, we\u2019re going to be launching a new, community-focused girls\u2019 education initiative\" \u2014FLOTUS http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/572852987258773505\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ND2SS8cT6m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_MuupDU0AA9_Li.jpg",
        "id_str" : "572852956434845696",
        "id" : 572852956434845696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_MuupDU0AA9_Li.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1367,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ND2SS8cT6m"
      } ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 12, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572852987258773505",
    "text" : "\"As part of #LetGirlsLearn, we\u2019re going to be launching a new, community-focused girls\u2019 education initiative\" \u2014FLOTUS http:\/\/t.co\/ND2SS8cT6m",
    "id" : 572852987258773505,
    "created_at" : "2015-03-03 20:16:09 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 572854614401261568,
  "created_at" : "2015-03-03 20:22:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 33, 47 ]
    }, {
      "text" : "LetGirlsLearn",
      "indices" : [ 91, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/cEWIR5koKc",
      "expanded_url" : "http:\/\/wh.gov\/LetGirlsLearn",
      "display_url" : "wh.gov\/LetGirlsLearn"
    } ]
  },
  "geo" : { },
  "id_str" : "572852010774503424",
  "text" : "\"That\u2019s our message to the world\u2014#LetGirlsLearn.\" \u2014President Obama: http:\/\/t.co\/cEWIR5koKc #LetGirlsLearn",
  "id" : 572852010774503424,
  "created_at" : "2015-03-03 20:12:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572851842268327936\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/5XbVjsIjOM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_MtrG8U4AAc0GI.jpg",
      "id_str" : "572851796227448832",
      "id" : 572851796227448832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_MtrG8U4AAc0GI.jpg",
      "sizes" : [ {
        "h" : 250,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/5XbVjsIjOM"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/cEWIR5koKc",
      "expanded_url" : "http:\/\/wh.gov\/LetGirlsLearn",
      "display_url" : "wh.gov\/LetGirlsLearn"
    } ]
  },
  "geo" : { },
  "id_str" : "572851842268327936",
  "text" : "\"Every girl is precious. Every girl deserves an education.\" \u2014President Obama: http:\/\/t.co\/cEWIR5koKc #LetGirlsLearn http:\/\/t.co\/5XbVjsIjOM",
  "id" : 572851842268327936,
  "created_at" : "2015-03-03 20:11:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/572851621165580288\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/xmv6SCMTtc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_MtfvrUQAAG3CO.jpg",
      "id_str" : "572851601003528192",
      "id" : 572851601003528192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_MtfvrUQAAG3CO.jpg",
      "sizes" : [ {
        "h" : 1542,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1360
      }, {
        "h" : 904,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xmv6SCMTtc"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 93, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572851621165580288",
  "text" : "\"We want to make sure that no girl out there is denied her chance to learn\" \u2014President Obama #LetGirlsLearn http:\/\/t.co\/xmv6SCMTtc",
  "id" : 572851621165580288,
  "created_at" : "2015-03-03 20:10:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 112, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572851471798173696",
  "text" : "\"What an extraordinary privilege it is to be the father of girls\u2014to watch them learn and grow\" \u2014President Obama #LetGirlsLearn",
  "id" : 572851471798173696,
  "created_at" : "2015-03-03 20:10:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572850850789507072\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/eQnfvFDh49",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_MsyuFUwAA_5am.jpg",
      "id_str" : "572850827481628672",
      "id" : 572850827481628672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_MsyuFUwAA_5am.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1360,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/eQnfvFDh49"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 93, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572850850789507072",
  "text" : "\"A world in which girls are educated is a safer, more stable, more prosperous place.\" \u2014Obama #LetGirlsLearn http:\/\/t.co\/eQnfvFDh49",
  "id" : 572850850789507072,
  "created_at" : "2015-03-03 20:07:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 112, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572850561193648129",
  "text" : "\"In too many parts of the world, girls are valued more for their bodies than for their minds.\" \u2014President Obama #LetGirlsLearn",
  "id" : 572850561193648129,
  "created_at" : "2015-03-03 20:06:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572850497775775747\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/BYY5iaOqLf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Msdg1VIAAXsJw.jpg",
      "id_str" : "572850463147630592",
      "id" : 572850463147630592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Msdg1VIAAXsJw.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/BYY5iaOqLf"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/cEWIR5koKc",
      "expanded_url" : "http:\/\/wh.gov\/LetGirlsLearn",
      "display_url" : "wh.gov\/LetGirlsLearn"
    } ]
  },
  "geo" : { },
  "id_str" : "572850497775775747",
  "text" : "\"62 million girls around the world who should be in school, aren\u2019t.\" \u2014Obama: http:\/\/t.co\/cEWIR5koKc #LetGirlsLearn http:\/\/t.co\/BYY5iaOqLf",
  "id" : 572850497775775747,
  "created_at" : "2015-03-03 20:06:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/cEWIR5koKc",
      "expanded_url" : "http:\/\/wh.gov\/LetGirlsLearn",
      "display_url" : "wh.gov\/LetGirlsLearn"
    } ]
  },
  "geo" : { },
  "id_str" : "572850386932928512",
  "text" : "\"Every girl on this planet deserves to be treated with dignity.\" \u2014President Obama: http:\/\/t.co\/cEWIR5koKc #LetGirlsLearn",
  "id" : 572850386932928512,
  "created_at" : "2015-03-03 20:05:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572850320025378816\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/9rqaFRsvf6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_MsT07UQAEQIY2.jpg",
      "id_str" : "572850296742756353",
      "id" : 572850296742756353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_MsT07UQAEQIY2.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1360,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/9rqaFRsvf6"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572850320025378816",
  "text" : "\"Wherever they live, whoever they are, every girl on this planet has value.\" \u2014President Obama #LetGirlsLearn http:\/\/t.co\/9rqaFRsvf6",
  "id" : 572850320025378816,
  "created_at" : "2015-03-03 20:05:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572850065389174784",
  "text" : "\"I\u2019m here to introduce...a passionate advocate for girls in the United States...around the globe\u2014Michelle Obama\" \u2014Obama #LetGirlsLearn",
  "id" : 572850065389174784,
  "created_at" : "2015-03-03 20:04:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 32, 39 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 67, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/cEWIR52NSE",
      "expanded_url" : "http:\/\/wh.gov\/LetGirlsLearn",
      "display_url" : "wh.gov\/LetGirlsLearn"
    } ]
  },
  "geo" : { },
  "id_str" : "572849444133179393",
  "text" : "Watch live: President Obama and @FLOTUS announce new steps to help #LetGirlsLearn around the world \u2192 http:\/\/t.co\/cEWIR52NSE",
  "id" : 572849444133179393,
  "created_at" : "2015-03-03 20:02:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572841526587486208",
  "text" : "RT @FLOTUS: Watch President Obama and the First Lady announce new steps to help #LetGirlsLearn around the world at 2:50pm ET \u2192 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 68, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/KWmnO70jFu",
        "expanded_url" : "http:\/\/wh.gov\/LetGirlsLearn",
        "display_url" : "wh.gov\/LetGirlsLearn"
      } ]
    },
    "geo" : { },
    "id_str" : "572838956296888321",
    "text" : "Watch President Obama and the First Lady announce new steps to help #LetGirlsLearn around the world at 2:50pm ET \u2192 http:\/\/t.co\/KWmnO70jFu",
    "id" : 572838956296888321,
    "created_at" : "2015-03-03 19:20:24 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 572841526587486208,
  "created_at" : "2015-03-03 19:30:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572829179001098241\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/MZBCLA9y5z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_MZBryVEAEc5eN.jpg",
      "id_str" : "572829094330568705",
      "id" : 572829094330568705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_MZBryVEAEc5eN.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/MZBCLA9y5z"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/cEWIR52NSE",
      "expanded_url" : "http:\/\/wh.gov\/LetGirlsLearn",
      "display_url" : "wh.gov\/LetGirlsLearn"
    } ]
  },
  "geo" : { },
  "id_str" : "572829179001098241",
  "text" : "Educating girls changes lives and communities. Join us \u2192 http:\/\/t.co\/cEWIR52NSE #LetGirlsLearn http:\/\/t.co\/MZBCLA9y5z",
  "id" : 572829179001098241,
  "created_at" : "2015-03-03 18:41:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/IldEFrMx9w",
      "expanded_url" : "http:\/\/u.pw\/1B5bSmx",
      "display_url" : "u.pw\/1B5bSmx"
    } ]
  },
  "geo" : { },
  "id_str" : "572824837913235457",
  "text" : "RT @FLOTUS: \"We owe these girls and girls like them around the world an education worthy of their dreams\" \u2014FLOTUS: http:\/\/t.co\/IldEFrMx9w #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/IldEFrMx9w",
        "expanded_url" : "http:\/\/u.pw\/1B5bSmx",
        "display_url" : "u.pw\/1B5bSmx"
      } ]
    },
    "geo" : { },
    "id_str" : "572820059040559104",
    "text" : "\"We owe these girls and girls like them around the world an education worthy of their dreams\" \u2014FLOTUS: http:\/\/t.co\/IldEFrMx9w #LetGirlsLearn",
    "id" : 572820059040559104,
    "created_at" : "2015-03-03 18:05:19 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 572824837913235457,
  "created_at" : "2015-03-03 18:24:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572812605326168065\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/jnI349p4tD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_MJ_dqVIAEkgVw.jpg",
      "id_str" : "572812563504766977",
      "id" : 572812563504766977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_MJ_dqVIAEkgVw.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/jnI349p4tD"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/cEWIR5koKc",
      "expanded_url" : "http:\/\/wh.gov\/LetGirlsLearn",
      "display_url" : "wh.gov\/LetGirlsLearn"
    } ]
  },
  "geo" : { },
  "id_str" : "572812605326168065",
  "text" : "62 million girls around the world are not in school. Let's help fix that \u2192 http:\/\/t.co\/cEWIR5koKc #LetGirlsLearn http:\/\/t.co\/jnI349p4tD",
  "id" : 572812605326168065,
  "created_at" : "2015-03-03 17:35:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572792708932091904\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/QcLvfoOHtP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_L31Y1VEAEZhX9.jpg",
      "id_str" : "572792599200731137",
      "id" : 572792599200731137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_L31Y1VEAEZhX9.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/QcLvfoOHtP"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/cEWIR5koKc",
      "expanded_url" : "http:\/\/wh.gov\/LetGirlsLearn",
      "display_url" : "wh.gov\/LetGirlsLearn"
    } ]
  },
  "geo" : { },
  "id_str" : "572792708932091904",
  "text" : "It's time to help more girls around the world get the education they deserve \u2192 http:\/\/t.co\/cEWIR5koKc #LetGirlsLearn http:\/\/t.co\/QcLvfoOHtP",
  "id" : 572792708932091904,
  "created_at" : "2015-03-03 16:16:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 34, 49 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontShutDownOurSecurity",
      "indices" : [ 106, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572779309431013376",
  "text" : "RT @NancyPelosi: RT if you agree: @SpeakerBoehner must bring up clean, long-term, Senate-passed DHS bill. #DontShutDownOurSecurity http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 17, 32 ],
        "id_str" : "7713202",
        "id" : 7713202
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/572749979699314688\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/H2nGnqp0uO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_LREllW0AAstAK.jpg",
        "id_str" : "572749979367952384",
        "id" : 572749979367952384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_LREllW0AAstAK.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/H2nGnqp0uO"
      } ],
      "hashtags" : [ {
        "text" : "DontShutDownOurSecurity",
        "indices" : [ 89, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572749979699314688",
    "text" : "RT if you agree: @SpeakerBoehner must bring up clean, long-term, Senate-passed DHS bill. #DontShutDownOurSecurity http:\/\/t.co\/H2nGnqp0uO",
    "id" : 572749979699314688,
    "created_at" : "2015-03-03 13:26:50 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 572779309431013376,
  "created_at" : "2015-03-03 15:23:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572534605426888704\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/m1jJJTaXJ7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_IL7R_UQAA58mo.jpg",
      "id_str" : "572533215698632704",
      "id" : 572533215698632704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_IL7R_UQAA58mo.jpg",
      "sizes" : [ {
        "h" : 389,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 664,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 972,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/m1jJJTaXJ7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/MaXmI1SZqB",
      "expanded_url" : "http:\/\/go.wh.gov\/ZH9UVL",
      "display_url" : "go.wh.gov\/ZH9UVL"
    } ]
  },
  "geo" : { },
  "id_str" : "572534605426888704",
  "text" : "Find out about new recommendations to help build trust between communities &amp; law enforcement: http:\/\/t.co\/MaXmI1SZqB http:\/\/t.co\/m1jJJTaXJ7",
  "id" : 572534605426888704,
  "created_at" : "2015-03-02 23:11:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Barbara Mikulski",
      "screen_name" : "SenatorBarb",
      "indices" : [ 36, 48 ],
      "id_str" : "132278386",
      "id" : 132278386
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/572499117533990912\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/2P3PiPg0hd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Hs5qsWsAALJT3.jpg",
      "id_str" : "572499103109787648",
      "id" : 572499103109787648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Hs5qsWsAALJT3.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2P3PiPg0hd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572528747519328256",
  "text" : "RT @VP: I am proud to have served w\/@SenatorBarb who changed the way we think about each other in this country. \u2013vp http:\/\/t.co\/2P3PiPg0hd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barbara Mikulski",
        "screen_name" : "SenatorBarb",
        "indices" : [ 28, 40 ],
        "id_str" : "132278386",
        "id" : 132278386
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/572499117533990912\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/2P3PiPg0hd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_Hs5qsWsAALJT3.jpg",
        "id_str" : "572499103109787648",
        "id" : 572499103109787648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_Hs5qsWsAALJT3.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2P3PiPg0hd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572499117533990912",
    "text" : "I am proud to have served w\/@SenatorBarb who changed the way we think about each other in this country. \u2013vp http:\/\/t.co\/2P3PiPg0hd",
    "id" : 572499117533990912,
    "created_at" : "2015-03-02 20:50:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 572528747519328256,
  "created_at" : "2015-03-02 22:47:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 4, 8 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572484270050029568\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/GiHwBNXcjL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_HewhPU4AAIJP8.png",
      "id_str" : "572483552790503424",
      "id" : 572483552790503424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_HewhPU4AAIJP8.png",
      "sizes" : [ {
        "h" : 304,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 135,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 304,
        "resize" : "fit",
        "w" : 764
      } ],
      "display_url" : "pic.twitter.com\/GiHwBNXcjL"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 107, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/MgdTxc5oc2",
      "expanded_url" : "http:\/\/wh.gov\/net-neutrality",
      "display_url" : "wh.gov\/net-neutrality"
    } ]
  },
  "geo" : { },
  "id_str" : "572484270050029568",
  "text" : "The @FCC voted last week to keep the internet open &amp; free.\nSee how we got here: http:\/\/t.co\/MgdTxc5oc2 #NetNeutrality http:\/\/t.co\/GiHwBNXcjL",
  "id" : 572484270050029568,
  "created_at" : "2015-03-02 19:51:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 41, 45 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/572460158476951554\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/BeJU7fl1oV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_HFB2kU8AAj4vU.jpg",
      "id_str" : "572455263271186432",
      "id" : 572455263271186432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_HFB2kU8AAj4vU.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BeJU7fl1oV"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 60, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/MgdTxc5oc2",
      "expanded_url" : "http:\/\/wh.gov\/net-neutrality",
      "display_url" : "wh.gov\/net-neutrality"
    } ]
  },
  "geo" : { },
  "id_str" : "572460158476951554",
  "text" : "A win for an open and free internet: The @FCC is protecting #NetNeutrality \u2192 http:\/\/t.co\/MgdTxc5oc2 http:\/\/t.co\/BeJU7fl1oV",
  "id" : 572460158476951554,
  "created_at" : "2015-03-02 18:15:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Mikulski",
      "screen_name" : "SenatorBarb",
      "indices" : [ 95, 107 ],
      "id_str" : "132278386",
      "id" : 132278386
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572453118400577536\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/4h4LfZ1OoC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_HDBShUwAAlgPm.png",
      "id_str" : "572453054571659264",
      "id" : 572453054571659264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_HDBShUwAAlgPm.png",
      "sizes" : [ {
        "h" : 188,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 1037
      }, {
        "h" : 107,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/4h4LfZ1OoC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572453118400577536",
  "text" : "\"Her leadership serves as an inspiration to millions of women &amp; girls\" \u2014President Obama on @SenatorBarb's retirement http:\/\/t.co\/4h4LfZ1OoC",
  "id" : 572453118400577536,
  "created_at" : "2015-03-02 17:47:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 36, 41 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 61, 75 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/572433830642102273\/video\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/CPuKKCQaXt",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/572433656750338048\/pu\/img\/P2iPC0h_9cMFGTEY.jpg",
      "id_str" : "572433656750338048",
      "id" : 572433656750338048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/572433656750338048\/pu\/img\/P2iPC0h_9cMFGTEY.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 864
      } ],
      "display_url" : "pic.twitter.com\/CPuKKCQaXt"
    } ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 12, 21 ]
    }, {
      "text" : "GimmeFive",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572443508230922242",
  "text" : "RT @FLOTUS: #LetsMove in space? Hey @NASA: Beam me up to the @Space_Station and #GimmeFive zero-gravity somersaults! http:\/\/t.co\/CPuKKCQaXt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 24, 29 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "Intl. Space Station",
        "screen_name" : "Space_Station",
        "indices" : [ 49, 63 ],
        "id_str" : "1451773004",
        "id" : 1451773004
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/572433830642102273\/video\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/CPuKKCQaXt",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/572433656750338048\/pu\/img\/P2iPC0h_9cMFGTEY.jpg",
        "id_str" : "572433656750338048",
        "id" : 572433656750338048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/572433656750338048\/pu\/img\/P2iPC0h_9cMFGTEY.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 864
        } ],
        "display_url" : "pic.twitter.com\/CPuKKCQaXt"
      } ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "GimmeFive",
        "indices" : [ 68, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572433830642102273",
    "text" : "#LetsMove in space? Hey @NASA: Beam me up to the @Space_Station and #GimmeFive zero-gravity somersaults! http:\/\/t.co\/CPuKKCQaXt",
    "id" : 572433830642102273,
    "created_at" : "2015-03-02 16:30:35 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 572443508230922242,
  "created_at" : "2015-03-02 17:09:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572433530812293120\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/MdiFy3JsBD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_GxKuzVEAAHKdU.jpg",
      "id_str" : "572433425572892672",
      "id" : 572433425572892672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_GxKuzVEAAHKdU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MdiFy3JsBD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/igihBy05Ki",
      "expanded_url" : "http:\/\/youtu.be\/09Gij5hKrxg",
      "display_url" : "youtu.be\/09Gij5hKrxg"
    } ]
  },
  "geo" : { },
  "id_str" : "572433530812293120",
  "text" : "Every $1 million in U.S. exports supports an average of more than 5,000 jobs here at home \u2192 http:\/\/t.co\/igihBy05Ki http:\/\/t.co\/MdiFy3JsBD",
  "id" : 572433530812293120,
  "created_at" : "2015-03-02 16:29:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572415022883721216",
  "text" : "RT @VP: The security and prosperity of Central America is fundamentally linked to our own here in the United States. Watch: http:\/\/t.co\/tcT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/tcTSnnGc0P",
        "expanded_url" : "http:\/\/youtu.be\/E3xcinVeIik",
        "display_url" : "youtu.be\/E3xcinVeIik"
      } ]
    },
    "geo" : { },
    "id_str" : "572412871163961344",
    "text" : "The security and prosperity of Central America is fundamentally linked to our own here in the United States. Watch: http:\/\/t.co\/tcTSnnGc0P",
    "id" : 572412871163961344,
    "created_at" : "2015-03-02 15:07:18 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 572415022883721216,
  "created_at" : "2015-03-02 15:15:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/572175996763430912\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/rU07opBOyQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_DGKyYUoAA2-7e.jpg",
      "id_str" : "572175041300832256",
      "id" : 572175041300832256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_DGKyYUoAA2-7e.jpg",
      "sizes" : [ {
        "h" : 425,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 751,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1281,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2940,
        "resize" : "fit",
        "w" : 2350
      } ],
      "display_url" : "pic.twitter.com\/rU07opBOyQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/gNTzZroLtl",
      "expanded_url" : "http:\/\/go.wh.gov\/aYa26N",
      "display_url" : "go.wh.gov\/aYa26N"
    } ]
  },
  "geo" : { },
  "id_str" : "572175996763430912",
  "text" : "\"Minnie\u2019s quintessentially American story embodies far more than a plaque ever could.\" \u2014Obama: http:\/\/t.co\/gNTzZroLtl http:\/\/t.co\/rU07opBOyQ",
  "id" : 572175996763430912,
  "created_at" : "2015-03-01 23:26:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 100, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/nioxuPjOeA",
      "expanded_url" : "http:\/\/go.wh.gov\/iQJoeL",
      "display_url" : "go.wh.gov\/iQJoeL"
    } ]
  },
  "geo" : { },
  "id_str" : "572162158475124738",
  "text" : "Back-door payments &amp; hidden fees on retirement funds are hurting the middle class. It's time to #ProtectYourSavings \u2192 http:\/\/t.co\/nioxuPjOeA",
  "id" : 572162158475124738,
  "created_at" : "2015-03-01 22:31:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 36, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/nioxuPjOeA",
      "expanded_url" : "http:\/\/go.wh.gov\/iQJoeL",
      "display_url" : "go.wh.gov\/iQJoeL"
    } ]
  },
  "geo" : { },
  "id_str" : "572139624157454336",
  "text" : "President Obama is taking action to #ProtectYourSavings from a conflict of interest \u2192 http:\/\/t.co\/nioxuPjOeA",
  "id" : 572139624157454336,
  "created_at" : "2015-03-01 21:01:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "YellowstoneNPS",
      "screen_name" : "YellowstoneNPS",
      "indices" : [ 35, 50 ],
      "id_str" : "44992488",
      "id" : 44992488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572136546792570880",
  "text" : "RT @Interior: On this day in 1872, @YellowstoneNPS became the 1st national park. RT to wish them happy 143rd birthday! http:\/\/t.co\/aUcrHj7G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YellowstoneNPS",
        "screen_name" : "YellowstoneNPS",
        "indices" : [ 21, 36 ],
        "id_str" : "44992488",
        "id" : 44992488
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/572066605242437632\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/aUcrHj7GUW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B_BjhM-W4AAllEq.jpg",
        "id_str" : "572066574745657344",
        "id" : 572066574745657344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_BjhM-W4AAllEq.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/aUcrHj7GUW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "572066605242437632",
    "text" : "On this day in 1872, @YellowstoneNPS became the 1st national park. RT to wish them happy 143rd birthday! http:\/\/t.co\/aUcrHj7GUW",
    "id" : 572066605242437632,
    "created_at" : "2015-03-01 16:11:21 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 572136546792570880,
  "created_at" : "2015-03-01 20:49:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/nioxuPjOeA",
      "expanded_url" : "http:\/\/go.wh.gov\/iQJoeL",
      "display_url" : "go.wh.gov\/iQJoeL"
    } ]
  },
  "geo" : { },
  "id_str" : "572120419035033600",
  "text" : "\"I will never stop fighting for an economy where everyone who works hard has the chance to get ahead.\" \u2014Obama: http:\/\/t.co\/nioxuPjOeA",
  "id" : 572120419035033600,
  "created_at" : "2015-03-01 19:45:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/572114756879970304\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/KitHSZodcm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_CPTS1VEAA74Mv.jpg",
      "id_str" : "572114714311856128",
      "id" : 572114714311856128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_CPTS1VEAA74Mv.jpg",
      "sizes" : [ {
        "h" : 437,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KitHSZodcm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572114756879970304",
  "text" : "\"For South Siders and Sox fans all across the country...Minnie Minoso is and will always be 'Mr. White Sox.'\" \u2014Obama: http:\/\/t.co\/KitHSZodcm",
  "id" : 572114756879970304,
  "created_at" : "2015-03-01 19:22:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/nioxuPjOeA",
      "expanded_url" : "http:\/\/go.wh.gov\/iQJoeL",
      "display_url" : "go.wh.gov\/iQJoeL"
    } ]
  },
  "geo" : { },
  "id_str" : "572107806632853504",
  "text" : "\"If you\u2019re working hard...you should have the peace of mind that...financial advice you\u2019re getting is sound\" \u2014Obama: http:\/\/t.co\/nioxuPjOeA",
  "id" : 572107806632853504,
  "created_at" : "2015-03-01 18:55:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]