Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "indices" : [ 18, 32 ],
      "id_str" : "28576135",
      "id" : 28576135
    }, {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 63, 77 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86601590173208576",
  "text" : "Photo of the Day: @thejointstaff Adm. Mullen, President Obama, @DeptofDefense Sec. Gates salute troops: http:\/\/twitpic.com\/5janr7",
  "id" : 86601590173208576,
  "created_at" : "2011-07-01 01:06:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/lescWYK",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/tweetup",
      "display_url" : "whitehouse.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "86588420096397312",
  "text" : "Hey followers - sign up now for your chance to attend the 1st White House Tweetup\/ Twitter Town Hall on 7\/6: http:\/\/t.co\/lescWYK",
  "id" : 86588420096397312,
  "created_at" : "2011-07-01 00:14:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 60, 68 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/ekFbqux",
      "expanded_url" : "http:\/\/wh.gov\/1At",
      "display_url" : "wh.gov\/1At"
    } ]
  },
  "geo" : { },
  "id_str" : "86552185189572608",
  "text" : "Bringing transparency to college costs: A new resource from @usedgov to help students make informed decisions: http:\/\/t.co\/ekFbqux",
  "id" : 86552185189572608,
  "created_at" : "2011-06-30 21:50:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seattle Storm",
      "screen_name" : "seattlestorm",
      "indices" : [ 1, 14 ],
      "id_str" : "18167574",
      "id" : 18167574
    }, {
      "name" : "Brent Bjornsen",
      "screen_name" : "scouted",
      "indices" : [ 66, 74 ],
      "id_str" : "14527608",
      "id" : 14527608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86508066492792832",
  "text" : ".@seattlestorm hosts a youth basketball clinic at the WH & thanks @scouted, @OneHedge2011 for helping kids. Video: http:\/\/twitpic.com\/5j67kc",
  "id" : 86508066492792832,
  "created_at" : "2011-06-30 18:55:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Preston ",
      "screen_name" : "nyt_jenpreston",
      "indices" : [ 3, 18 ],
      "id_str" : "851372762",
      "id" : 851372762
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 30, 42 ],
      "id_str" : "813286",
      "id" : 813286
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 70, 81 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askobama",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86495670273445888",
  "text" : "RT @NYT_JenPreston: President @barackobama hosts Tweetup next week at @whitehouse. Inivites followers; your questions #askobama. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 10, 22 ],
        "id_str" : "813286",
        "id" : 813286
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 50, 61 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askobama",
        "indices" : [ 98, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86485683262324736",
    "text" : "President @barackobama hosts Tweetup next week at @whitehouse. Inivites followers; your questions #askobama. http:\/\/nyti.ms\/kfO4KM @townhall",
    "id" : 86485683262324736,
    "created_at" : "2011-06-30 17:26:08 +0000",
    "user" : {
      "name" : "Jennifer Preston",
      "screen_name" : "JenniferPreston",
      "protected" : false,
      "id_str" : "37759047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707549703395799040\/s1AkA2hb_normal.jpg",
      "id" : 37759047,
      "verified" : true
    }
  },
  "id" : 86495670273445888,
  "created_at" : "2011-06-30 18:05:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 35, 46 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/LZBQ0p3",
      "expanded_url" : "http:\/\/wh.gov\/17t",
      "display_url" : "wh.gov\/17t"
    } ]
  },
  "geo" : { },
  "id_str" : "86495265456001025",
  "text" : "Announcing WH Tweetups! Some lucky @whitehouse followers will get invites to the Twitter @townhall @ the WH: http:\/\/t.co\/LZBQ0p3",
  "id" : 86495265456001025,
  "created_at" : "2011-06-30 18:04:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jeffersonians",
      "screen_name" : "jeffersonians",
      "indices" : [ 51, 65 ],
      "id_str" : "1403846557",
      "id" : 1403846557
    }, {
      "name" : "Amanda McGill",
      "screen_name" : "amanda_mcgill",
      "indices" : [ 98, 112 ],
      "id_str" : "2845215667",
      "id" : 2845215667
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/hAj0rYB",
      "expanded_url" : "http:\/\/wh.gov\/17v",
      "display_url" : "wh.gov\/17v"
    } ]
  },
  "geo" : { },
  "id_str" : "86486563369914368",
  "text" : "Young elected officials #AtTheWH: Hear from OR Rep @jeffersonians, CO Councilman Herndon & NE Sen @amanda_mcgill: http:\/\/t.co\/hAj0rYB",
  "id" : 86486563369914368,
  "created_at" : "2011-06-30 17:29:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskObama",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/Uk04H97",
      "expanded_url" : "https:\/\/askobama.twitter.com",
      "display_url" : "askobama.twitter.com"
    } ]
  },
  "geo" : { },
  "id_str" : "86449093542543360",
  "text" : "BREAKING: 1st Twitter @townhall w\/ Pres Obama at the WH on 7\/6 @ 2ET. #AskObama your Qs on the economy & jobs: http:\/\/t.co\/Uk04H97",
  "id" : 86449093542543360,
  "created_at" : "2011-06-30 15:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "86426746433441793",
  "text" : "Happening Now: President Obama speaks at the Armed Forces Farewell Tribute in honor of Secretary Gates. Watch: http:\/\/t.co\/hOlVdV1",
  "id" : 86426746433441793,
  "created_at" : "2011-06-30 13:31:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/nW6WgyU",
      "expanded_url" : "http:\/\/wh.gov\/1GY",
      "display_url" : "wh.gov\/1GY"
    } ]
  },
  "geo" : { },
  "id_str" : "86222406615699456",
  "text" : "\"Now is the time to go ahead and make the tough choices\" -President Obama on our economy & the debt limit: http:\/\/t.co\/nW6WgyU",
  "id" : 86222406615699456,
  "created_at" : "2011-06-29 23:59:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lgbt",
      "indices" : [ 29, 34 ]
    }, {
      "text" : "pride",
      "indices" : [ 35, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86196464203739136",
  "text" : "RT @jesseclee44: Obama at WH #lgbt #pride: \"in a matter of weeks, not months, I expect to certify the change\u2026end \u201CDon\u2019t Ask, Don\u2019t Tell\u201D ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lgbt",
        "indices" : [ 12, 17 ]
      }, {
        "text" : "pride",
        "indices" : [ 18, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86193357335969792",
    "text" : "Obama at WH #lgbt #pride: \"in a matter of weeks, not months, I expect to certify the change\u2026end \u201CDon\u2019t Ask, Don\u2019t Tell\u201D once & for all\"",
    "id" : 86193357335969792,
    "created_at" : "2011-06-29 22:04:32 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 86196464203739136,
  "created_at" : "2011-06-29 22:16:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/MdaCm5H",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/29\/key-legal-victory-health-care-0",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "86174185331769346",
  "text" : "A Key Legal Victory for Health Care: Today, the Affordable Care Act won an important victory in court: http:\/\/t.co\/MdaCm5H",
  "id" : 86174185331769346,
  "created_at" : "2011-06-29 20:48:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seattle Storm",
      "screen_name" : "seattlestorm",
      "indices" : [ 9, 22 ],
      "id_str" : "18167574",
      "id" : 18167574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86133646842535936",
  "text" : "The WNBA @seattlestorm are hosting a basketball clinic for kids at the WH. What are you doing in your community to help kids stay healthy?",
  "id" : 86133646842535936,
  "created_at" : "2011-06-29 18:07:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http:\/\/t.co\/iN549H3",
      "expanded_url" : "http:\/\/wh.gov\/1fX",
      "display_url" : "wh.gov\/1fX"
    } ]
  },
  "geo" : { },
  "id_str" : "86123148801622016",
  "text" : "President Obama\u2019s National Strategy for Counterterrorism: http:\/\/t.co\/iN549H3",
  "id" : 86123148801622016,
  "created_at" : "2011-06-29 17:25:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    }, {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 117, 131 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOT",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86113688611860480",
  "text" : "RT @USArmy: Sec. Robert Gates sends farewell message to Troops, thanking them for their service. http:\/\/goo.gl\/Ovndr @DeptofDefense #SOT ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Dept of Defense",
        "screen_name" : "DeptofDefense",
        "indices" : [ 105, 119 ],
        "id_str" : "66369181",
        "id" : 66369181
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOT",
        "indices" : [ 120, 124 ]
      }, {
        "text" : "USArmy",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "86109610150338560",
    "text" : "Sec. Robert Gates sends farewell message to Troops, thanking them for their service. http:\/\/goo.gl\/Ovndr @DeptofDefense #SOT #USArmy",
    "id" : 86109610150338560,
    "created_at" : "2011-06-29 16:31:45 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 86113688611860480,
  "created_at" : "2011-06-29 16:47:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/qKVzPav",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "86096435665305600",
  "text" : "Happening now: The President holds a news conference from the East Room of the WH. Watch live: http:\/\/t.co\/qKVzPav",
  "id" : 86096435665305600,
  "created_at" : "2011-06-29 15:39:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "86086446984863744",
  "text" : "Live at 11:30 AM ET: President Obama holds a news conference from the East Room of the WH. Watch it here: http:\/\/t.co\/hOlVdV1",
  "id" : 86086446984863744,
  "created_at" : "2011-06-29 14:59:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energymatters",
      "indices" : [ 88, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "86079716712394753",
  "text" : "RT @ENERGY: Join us today at 2pm ET for a live chat about U.S. energy independence. Use #energymatters to send us your questions. http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "energymatters",
        "indices" : [ 76, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 137 ],
        "url" : "http:\/\/t.co\/PtsnfFn",
        "expanded_url" : "http:\/\/go.usa.gov\/Zi5",
        "display_url" : "go.usa.gov\/Zi5"
      } ]
    },
    "geo" : { },
    "id_str" : "86072561795997696",
    "text" : "Join us today at 2pm ET for a live chat about U.S. energy independence. Use #energymatters to send us your questions. http:\/\/t.co\/PtsnfFn",
    "id" : 86072561795997696,
    "created_at" : "2011-06-29 14:04:32 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 86079716712394753,
  "created_at" : "2011-06-29 14:32:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alcoa",
      "screen_name" : "Alcoa",
      "indices" : [ 95, 101 ],
      "id_str" : "15085627",
      "id" : 15085627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/Bc57HXb",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/28\/president-obama-tours-alcoa-and-talks-manufacturing-iowa",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "86069703302320128",
  "text" : "\"A big part of our future has to be a robust & growing manufacturing sector.\" -President Obama @Alcoa in Iowa. Video: http:\/\/t.co\/Bc57HXb",
  "id" : 86069703302320128,
  "created_at" : "2011-06-29 13:53:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http:\/\/t.co\/qKVzPav",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    }, {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/Sh6qeUJ",
      "expanded_url" : "http:\/\/apps.facebook.com\/whitehouselive\/",
      "display_url" : "apps.facebook.com\/whitehouselive\/"
    } ]
  },
  "geo" : { },
  "id_str" : "85801785066913792",
  "text" : "Starting Now: Open for Questions on the way forward in Afghanistan. Watch Live: http:\/\/t.co\/qKVzPav or ask a question http:\/\/t.co\/Sh6qeUJ",
  "id" : 85801785066913792,
  "created_at" : "2011-06-28 20:08:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alcoa",
      "screen_name" : "Alcoa",
      "indices" : [ 79, 85 ],
      "id_str" : "15085627",
      "id" : 15085627
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "85767284760657920",
  "text" : "Live at 2 ET: President Obama speaks on strengthening the manufacturing sector @Alcoa in Bettendorf, Iowa: http:\/\/t.co\/hOlVdV1",
  "id" : 85767284760657920,
  "created_at" : "2011-06-28 17:51:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brittney Giorgini",
      "screen_name" : "RapidsSoccer",
      "indices" : [ 1, 14 ],
      "id_str" : "1580544199",
      "id" : 1580544199
    }, {
      "name" : "Candace Lehew",
      "screen_name" : "whitelight71",
      "indices" : [ 57, 70 ],
      "id_str" : "36395738",
      "id" : 36395738
    }, {
      "name" : "Hollie Staten Mercha",
      "screen_name" : "HollieSeven",
      "indices" : [ 75, 87 ],
      "id_str" : "52864160",
      "id" : 52864160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85750845148377088",
  "text" : ".@RapidsSoccer hosts military kids & thanks WH followers @whitelight71 and @HollieSeven for giving back. Video: http:\/\/twitpic.com\/5i6zfp",
  "id" : 85750845148377088,
  "created_at" : "2011-06-28 16:46:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/IlLsndQ",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/24\/open-questions-live-chat-way-forward-afghanistan",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "85730498298654723",
  "text" : "Open for Questions on the way forward in Afghanistan today at 4 PM ET. Ask questions now, join live later: http:\/\/t.co\/IlLsndQ",
  "id" : 85730498298654723,
  "created_at" : "2011-06-28 15:25:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85438595388801024",
  "text" : "Photo of the Day: President Obama jokes w\/ military personnel before boarding Air Force One in Pittsburgh, PA http:\/\/twitpic.com\/5hsjmt",
  "id" : 85438595388801024,
  "created_at" : "2011-06-27 20:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85410177750274048",
  "text" : "MLS champion Colorado Rapids are hosting a soccer clinic for the kids of military families on the South Lawn.  What are you doing to help?",
  "id" : 85410177750274048,
  "created_at" : "2011-06-27 18:12:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/JukAtWo",
      "expanded_url" : "http:\/\/wh.gov\/1Vh",
      "display_url" : "wh.gov\/1Vh"
    } ]
  },
  "geo" : { },
  "id_str" : "85381318929686528",
  "text" : "National HIV Testing Day reminds each of us to do our part in fighting HIV\/AIDS & get tested. President's statement: http:\/\/t.co\/JukAtWo",
  "id" : 85381318929686528,
  "created_at" : "2011-06-27 16:17:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHSJournal",
      "screen_name" : "DHSJournal",
      "indices" : [ 15, 26 ],
      "id_str" : "376234273",
      "id" : 376234273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "85370449143402497",
  "text" : "Happening Now: @DHSJournal Sec Napolitano & Howard Schmidt announce Stop.Think.Connect. PSA challenge winners:\nhttp:\/\/t.co\/hOlVdV1",
  "id" : 85370449143402497,
  "created_at" : "2011-06-27 15:34:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/uneaZG1",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=lLKuNd4RmTU&feature=player_embedded",
      "display_url" : "youtube.com\/watch?v=lLKuNd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "85353806463905792",
  "text" : "In case you missed it: Obama's weekly address on the role advanced manufacturing will have in strengthening our economy. http:\/\/t.co\/uneaZG1",
  "id" : 85353806463905792,
  "created_at" : "2011-06-27 14:28:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carnegie Mellon",
      "screen_name" : "CarnegieMellon",
      "indices" : [ 3, 18 ],
      "id_str" : "17631078",
      "id" : 17631078
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CMUObama",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84376307554725888",
  "text" : "RT @CarnegieMellon: \"It seems like every time I'm here I learn something,\" said President Obama. Video: http:\/\/ht.ly\/5pQbo #CMUObama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CMUObama",
        "indices" : [ 103, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "84337422472716288",
    "text" : "\"It seems like every time I'm here I learn something,\" said President Obama. Video: http:\/\/ht.ly\/5pQbo #CMUObama",
    "id" : 84337422472716288,
    "created_at" : "2011-06-24 19:09:43 +0000",
    "user" : {
      "name" : "Carnegie Mellon",
      "screen_name" : "CarnegieMellon",
      "protected" : false,
      "id_str" : "17631078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/583587004316647424\/2pjjWvhP_normal.png",
      "id" : 17631078,
      "verified" : true
    }
  },
  "id" : 84376307554725888,
  "created_at" : "2011-06-24 21:44:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HIV",
      "indices" : [ 95, 99 ]
    }, {
      "text" : "AIDS",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/wSdpWuT",
      "expanded_url" : "http:\/\/go.usa.gov\/WSh",
      "display_url" : "go.usa.gov\/WSh"
    } ]
  },
  "geo" : { },
  "id_str" : "84347572004716544",
  "text" : "RT @StateDept: First Lady Michelle Obama highlights importance of youth leadership in fighting #HIV #AIDS. http:\/\/t.co\/wSdpWuT via @USPE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HIV",
        "indices" : [ 80, 84 ]
      }, {
        "text" : "AIDS",
        "indices" : [ 85, 90 ]
      }, {
        "text" : "YoungAfrica",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 111 ],
        "url" : "http:\/\/t.co\/wSdpWuT",
        "expanded_url" : "http:\/\/go.usa.gov\/WSh",
        "display_url" : "go.usa.gov\/WSh"
      } ]
    },
    "geo" : { },
    "id_str" : "84327304704180224",
    "text" : "First Lady Michelle Obama highlights importance of youth leadership in fighting #HIV #AIDS. http:\/\/t.co\/wSdpWuT via @USPEPFAR #YoungAfrica",
    "id" : 84327304704180224,
    "created_at" : "2011-06-24 18:29:30 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 84347572004716544,
  "created_at" : "2011-06-24 19:50:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YoungAfrica",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/eWdLedI",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/0\/GPUnhq1h3NU",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "84347326646321152",
  "text" : "Obama Ye-Le-Le! Botswana welcomes First Lady Michelle Obama: http:\/\/t.co\/eWdLedI #YoungAfrica",
  "id" : 84347326646321152,
  "created_at" : "2011-06-24 19:49:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 81 ],
      "url" : "http:\/\/t.co\/IsBrobf",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=MbwdPQMmFBU&feature=channel_video_title",
      "display_url" : "youtube.com\/watch?v=MbwdPQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "84297401757728768",
  "text" : "Welcome to the West Wing Week. Check out \"The Receding Tide\": http:\/\/t.co\/IsBrobf",
  "id" : 84297401757728768,
  "created_at" : "2011-06-24 16:30:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 110 ],
      "url" : "http:\/\/t.co\/hOlVdV1",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "84274852088918016",
  "text" : "Happening Now: President Obama speaks on the global competitiveness of U.S. manufacturing: http:\/\/t.co\/hOlVdV1",
  "id" : 84274852088918016,
  "created_at" : "2011-06-24 15:01:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youngafrica",
      "indices" : [ 30, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/XbYQryc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=9k-DCrhVQ3U&feature=player_embedded",
      "display_url" : "youtube.com\/watch?v=9k-DCr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "84012844626087936",
  "text" : "The First Lady sits down with #youngafrica women & talks about meeting Nelson Mandela, offers advice: http:\/\/t.co\/XbYQryc",
  "id" : 84012844626087936,
  "created_at" : "2011-06-23 21:39:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84002197423136769",
  "text" : "Infographic: Troop levels in Afghanistan & Iraq under the Obama Administration: http:\/\/wh.gov\/1Uz Pic: http:\/\/twitpic.com\/5fsr65",
  "id" : 84002197423136769,
  "created_at" : "2011-06-23 20:57:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/aEUbNCf",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/0\/zpy4F70otJY",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "83919376193036289",
  "text" : "\"We're keeping our promises\": Vice President Biden on Afghanistan, Iraq & our commitment to defeat al Qaeda: http:\/\/t.co\/aEUbNCf",
  "id" : 83919376193036289,
  "created_at" : "2011-06-23 15:28:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http:\/\/t.co\/22kdOzn",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/22\/president-obama-way-forward-afghanistan",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "83730375075053568",
  "text" : "Video: President Obama on the way forward in Afghanistan: http:\/\/t.co\/22kdOzn",
  "id" : 83730375075053568,
  "created_at" : "2011-06-23 02:57:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83689504984150016",
  "text" : "\"Let us go about the work of extending the promise of America \u2013 for this generation, and the next.\" -President Obama",
  "id" : 83689504984150016,
  "created_at" : "2011-06-23 00:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83689361526366208",
  "text" : "\"Let us finish the work at hand. Let us responsibly end these wars & reclaim the American Dream that is at the center of our story.\" -Obama",
  "id" : 83689361526366208,
  "created_at" : "2011-06-23 00:14:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83688916028370944",
  "text" : "\"America, it is time to focus on nation building here at home.\" -President Obama",
  "id" : 83688916028370944,
  "created_at" : "2011-06-23 00:12:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83688853793292288",
  "text" : "\"Now, we must invest in America\u2019s greatest resource \u2013 our people.\" -President Obama",
  "id" : 83688853793292288,
  "created_at" : "2011-06-23 00:12:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83688605456924673",
  "text" : "\"We must remember that what sets America apart is not solely our power \u2013 it is the principles upon which our union was founded.\" -Obama",
  "id" : 83688605456924673,
  "created_at" : "2011-06-23 00:11:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83688049921376257",
  "text" : "\"Yet tonight, we take comfort in knowing that the tide of war is receding.\" -President Obama on Afghanistan",
  "id" : 83688049921376257,
  "created_at" : "2011-06-23 00:09:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83687708173672448",
  "text" : "\"What we can do, and will do, is build a partnership with the Afghan people that endures.\" -President Obama",
  "id" : 83687708173672448,
  "created_at" : "2011-06-23 00:07:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83687333358075904",
  "text" : "RT @pfeiffer44: POTUS: Our mission will change from combat to support.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83686914611351553",
    "text" : "POTUS: Our mission will change from combat to support.",
    "id" : 83686914611351553,
    "created_at" : "2011-06-23 00:04:49 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 83687333358075904,
  "created_at" : "2011-06-23 00:06:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83687284507029505",
  "text" : "\"This is the beginning \u2013 but not the end \u2013 of our effort to wind down this war.\" -President Obama on Afghanistan",
  "id" : 83687284507029505,
  "created_at" : "2011-06-23 00:06:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/Uiy95hC",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "83686776069296128",
  "text" : "\u201CStarting next month, we will be able to remove 10,000 of our troops from Afghanistan by the end of this year\u201D -Obama http:\/\/t.co\/Uiy95hC",
  "id" : 83686776069296128,
  "created_at" : "2011-06-23 00:04:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/Uiy95hC",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "83686315589242881",
  "text" : "Just started - President Obama address to the nation. Watch live: http:\/\/t.co\/Uiy95hC",
  "id" : 83686315589242881,
  "created_at" : "2011-06-23 00:02:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 92 ],
      "url" : "http:\/\/t.co\/Uiy95hC",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "83683926748577792",
  "text" : "Coming up at 8 EDT: President Obama's address to the nation. Watch Live: http:\/\/t.co\/Uiy95hC",
  "id" : 83683926748577792,
  "created_at" : "2011-06-22 23:52:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/Uiy95hC",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "83640414493609984",
  "text" : "Tonight, the President will address the nation on his plan to draw down US troops from Afghanistan. Watch at 8 EDT: http:\/\/t.co\/Uiy95hC",
  "id" : 83640414493609984,
  "created_at" : "2011-06-22 21:00:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apartheid Museum",
      "screen_name" : "apartheidmuseum",
      "indices" : [ 56, 72 ],
      "id_str" : "92811009",
      "id" : 92811009
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youngafrica",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/IOhDJP8",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/0\/X6j_T5WUMZU",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "83562858209738752",
  "text" : "Day one with the First Lady in South Africa - visit the @apartheidmuseum, meet #youngafrica leaders & more. Video: http:\/\/t.co\/IOhDJP8",
  "id" : 83562858209738752,
  "created_at" : "2011-06-22 15:51:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBA",
      "indices" : [ 105, 109 ],
      "id_str" : "2679888750",
      "id" : 2679888750
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImpactEconomy",
      "indices" : [ 29, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/Uiy95hC",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "83536814866055168",
  "text" : "Happening now: Discussion on #ImpactEconomy w\/ Melody Barnes, Gene Sperling, Bill Daley & Karen Mills of @SBA http:\/\/t.co\/Uiy95hC",
  "id" : 83536814866055168,
  "created_at" : "2011-06-22 14:08:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83211878293188608",
  "text" : "RT @PressSec: The President will speak to the nation from the White House, 8 pm tomorrow, re his plan for drawing down US forces from Af ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83208420085338112",
    "text" : "The President will speak to the nation from the White House, 8 pm tomorrow, re his plan for drawing down US forces from Afghanistan.",
    "id" : 83208420085338112,
    "created_at" : "2011-06-21 16:23:27 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 83211878293188608,
  "created_at" : "2011-06-21 16:37:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cigwarnings",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/goA3xBg",
      "expanded_url" : "http:\/\/goo.gl\/LDaEF",
      "display_url" : "goo.gl\/LDaEF"
    } ]
  },
  "geo" : { },
  "id_str" : "83195984498266112",
  "text" : "RT @HHSGov: Final 9 graphic health warnings to appear on every pack of cigarettes unveiled today http:\/\/t.co\/goA3xBg #cigwarnings  @FDAT ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FDA Tobacco",
        "screen_name" : "FDATobacco",
        "indices" : [ 119, 130 ],
        "id_str" : "158006058",
        "id" : 158006058
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cigwarnings",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 104 ],
        "url" : "http:\/\/t.co\/goA3xBg",
        "expanded_url" : "http:\/\/goo.gl\/LDaEF",
        "display_url" : "goo.gl\/LDaEF"
      } ]
    },
    "geo" : { },
    "id_str" : "83167203289079808",
    "text" : "Final 9 graphic health warnings to appear on every pack of cigarettes unveiled today http:\/\/t.co\/goA3xBg #cigwarnings  @FDATobacco",
    "id" : 83167203289079808,
    "created_at" : "2011-06-21 13:39:41 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 83195984498266112,
  "created_at" : "2011-06-21 15:34:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youngafrica",
      "indices" : [ 24, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83183924469170176",
  "text" : "RT @USAID: The women of #youngafrica are talking! And they want FLOTUS to know they are agents of change!  http:\/\/twitpic.com\/5equqa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "youngafrica",
        "indices" : [ 13, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83172247984025600",
    "text" : "The women of #youngafrica are talking! And they want FLOTUS to know they are agents of change!  http:\/\/twitpic.com\/5equqa",
    "id" : 83172247984025600,
    "created_at" : "2011-06-21 13:59:43 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 83183924469170176,
  "created_at" : "2011-06-21 14:46:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YoungAfrica",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/Aw6wSFs",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/youngafrica",
      "display_url" : "whitehouse.gov\/youngafrica"
    } ]
  },
  "geo" : { },
  "id_str" : "82962525045526528",
  "text" : "The First Lady just arrived in South Africa - a visit to engage young people. Follow the trip: http:\/\/t.co\/Aw6wSFs #YoungAfrica",
  "id" : 82962525045526528,
  "created_at" : "2011-06-21 00:06:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/mU6Fa3H",
      "expanded_url" : "http:\/\/go.usa.gov\/Wfp",
      "display_url" : "go.usa.gov\/Wfp"
    } ]
  },
  "geo" : { },
  "id_str" : "82958178534424576",
  "text" : "RT @ENERGY: Where are we at on getting solar panels on the White House roof? http:\/\/t.co\/mU6Fa3H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 84 ],
        "url" : "http:\/\/t.co\/mU6Fa3H",
        "expanded_url" : "http:\/\/go.usa.gov\/Wfp",
        "display_url" : "go.usa.gov\/Wfp"
      } ]
    },
    "geo" : { },
    "id_str" : "82940148433698818",
    "text" : "Where are we at on getting solar panels on the White House roof? http:\/\/t.co\/mU6Fa3H",
    "id" : 82940148433698818,
    "created_at" : "2011-06-20 22:37:26 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 82958178534424576,
  "created_at" : "2011-06-20 23:49:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82956859698462720",
  "text" : "RT @JoiningForces: Dr. Biden visits w\/ National Guard families in Chicago - their pride, contagious; their courage, awe-inspiring: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 131 ],
        "url" : "http:\/\/t.co\/cf42YL2",
        "expanded_url" : "http:\/\/wh.gov\/15O",
        "display_url" : "wh.gov\/15O"
      } ]
    },
    "geo" : { },
    "id_str" : "82921104276078593",
    "text" : "Dr. Biden visits w\/ National Guard families in Chicago - their pride, contagious; their courage, awe-inspiring: http:\/\/t.co\/cf42YL2",
    "id" : 82921104276078593,
    "created_at" : "2011-06-20 21:21:46 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 82956859698462720,
  "created_at" : "2011-06-20 23:43:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 13, 23 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 86 ],
      "url" : "http:\/\/t.co\/qAG3VN9",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/20\/photostream-behind-scenes-may",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "82886320321605632",
  "text" : "Photostream: @PeteSouza gives you a behind the scenes look at May: http:\/\/t.co\/qAG3VN9",
  "id" : 82886320321605632,
  "created_at" : "2011-06-20 19:03:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/poYQyIH",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/20\/promoting-open-investment-policy-create-jobs-and-grow-economy",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "82871730577735681",
  "text" : "New report from CEA on the benefits of companies abroad investing in the US to create jobs, grow the economy:\nhttp:\/\/t.co\/poYQyIH",
  "id" : 82871730577735681,
  "created_at" : "2011-06-20 18:05:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 59, 70 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 72, 78 ],
      "id_str" : "36683668",
      "id" : 36683668
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 82, 92 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YoungAfrica",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82804761316954113",
  "text" : "RT @AFAsstSecy: You haven't missed it...LIVE NOW Chat with @whitehouse, @USAID, & @StateDept about #YoungAfrica Women Leaders http:\/\/tl. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 43, 54 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "USAID",
        "screen_name" : "USAID",
        "indices" : [ 56, 62 ],
        "id_str" : "36683668",
        "id" : 36683668
      }, {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 66, 76 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YoungAfrica",
        "indices" : [ 83, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "82797059048095744",
    "text" : "You haven't missed it...LIVE NOW Chat with @whitehouse, @USAID, & @StateDept about #YoungAfrica Women Leaders http:\/\/tl.gd\/b7ue5h",
    "id" : 82797059048095744,
    "created_at" : "2011-06-20 13:08:51 +0000",
    "user" : {
      "name" : "A\/SThomas-Greenfield",
      "screen_name" : "StateAfrica",
      "protected" : false,
      "id_str" : "238197721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461535903349874688\/yNjbjV6v_normal.jpeg",
      "id" : 238197721,
      "verified" : true
    }
  },
  "id" : 82804761316954113,
  "created_at" : "2011-06-20 13:39:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 108 ],
      "url" : "http:\/\/t.co\/NlYm1VT",
      "expanded_url" : "http:\/\/wh.gov\/1XE",
      "display_url" : "wh.gov\/1XE"
    } ]
  },
  "geo" : { },
  "id_str" : "82494469739528193",
  "text" : "Happy Father's Day! The President kicks off the year of Strong Fathers, Strong Families: http:\/\/t.co\/NlYm1VT",
  "id" : 82494469739528193,
  "created_at" : "2011-06-19 17:06:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/vOOvAm4",
      "expanded_url" : "http:\/\/www.youtube.com\/whitehouse#p\/u\/0\/736bOQTEKAU",
      "display_url" : "youtube.com\/whitehouse#p\/u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "82136848574578688",
  "text" : "Weekly Address: President Obama takes a few min to discuss the hardest, but most rewarding job \u2013 being a dad. http:\/\/t.co\/vOOvAm4",
  "id" : 82136848574578688,
  "created_at" : "2011-06-18 17:25:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "FedScoop",
      "screen_name" : "fedscoop",
      "indices" : [ 17, 26 ],
      "id_str" : "1477949676",
      "id" : 1477949676
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 50, 61 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 62, 70 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 73, 82 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infographic",
      "indices" : [ 33, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81873176291844096",
  "text" : "RT @macon44: Wow @fedscoop, this #infographic abt @whitehouse @twitter & @facebook is terrific! Based on: http:\/\/1.usa.gov\/mvz33c http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FedScoop",
        "screen_name" : "fedscoop",
        "indices" : [ 4, 13 ],
        "id_str" : "1477949676",
        "id" : 1477949676
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 37, 48 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 49, 57 ],
        "id_str" : "783214",
        "id" : 783214
      }, {
        "name" : "Facebook",
        "screen_name" : "facebook",
        "indices" : [ 60, 69 ],
        "id_str" : "2425151",
        "id" : 2425151
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/81872517786120194\/photo\/1",
        "indices" : [ 117, 136 ],
        "url" : "http:\/\/t.co\/NSTQLrL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ASLenwPCMAAyUlC.png",
        "id_str" : "81872517790314496",
        "id" : 81872517790314496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ASLenwPCMAAyUlC.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 412,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1152
        } ],
        "display_url" : "pic.twitter.com\/NSTQLrL"
      } ],
      "hashtags" : [ {
        "text" : "infographic",
        "indices" : [ 20, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81872517786120194",
    "text" : "Wow @fedscoop, this #infographic abt @whitehouse @twitter & @facebook is terrific! Based on: http:\/\/1.usa.gov\/mvz33c http:\/\/t.co\/NSTQLrL",
    "id" : 81872517786120194,
    "created_at" : "2011-06-17 23:55:06 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 81873176291844096,
  "created_at" : "2011-06-17 23:57:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 13, 22 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "solar",
      "indices" : [ 54, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http:\/\/t.co\/VmtxPvk",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/17\/investing-america-s-new-energy-frontier",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "81832377344733184",
  "text" : "Secretary of @Interior Salazar on the world's largest #solar project: http:\/\/t.co\/VmtxPvk",
  "id" : 81832377344733184,
  "created_at" : "2011-06-17 21:15:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/EqEbsfr",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ekGXgcYLvWU&feature=channel_video_title",
      "display_url" : "youtube.com\/watch?v=ekGXgc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "81812230789808129",
  "text" : "Checked out West Wing Week yet? Stick with it until the end (funny moment w\/ President, First Lady & crying baby): http:\/\/t.co\/EqEbsfr",
  "id" : 81812230789808129,
  "created_at" : "2011-06-17 19:55:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 94 ],
      "url" : "http:\/\/t.co\/5leDnL8",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/16\/president-obama-announces-how-make-change-series-young-americans",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "81753587079847936",
  "text" : "President Obama announces \u201CHow to Make Change\u201D series for young Americans: http:\/\/t.co\/5leDnL8",
  "id" : 81753587079847936,
  "created_at" : "2011-06-17 16:02:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/JuVTgws",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=95ozkRjINIQ&feature=channel_video_title",
      "display_url" : "youtube.com\/watch?v=95ozkR\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "81583293115539456",
  "text" : "West Wing Week: Walk with President Obama as he meets on jobs in NC, calms crying baby at WH & lots more: http:\/\/t.co\/JuVTgws",
  "id" : 81583293115539456,
  "created_at" : "2011-06-17 04:45:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BET",
      "screen_name" : "BET",
      "indices" : [ 3, 7 ],
      "id_str" : "16560657",
      "id" : 16560657
    }, {
      "name" : "#106andPark",
      "screen_name" : "106andpark",
      "indices" : [ 52, 63 ],
      "id_str" : "30309979",
      "id" : 30309979
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81504656987127808",
  "text" : "RT @BET: Did you catch First Lady Michelle Obama on @106andpark? Click here to learn more abt her Africa trip & why she's so cool http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "#106andPark",
        "screen_name" : "106andpark",
        "indices" : [ 43, 54 ],
        "id_str" : "30309979",
        "id" : 30309979
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81503959260467200",
    "text" : "Did you catch First Lady Michelle Obama on @106andpark? Click here to learn more abt her Africa trip & why she's so cool http:\/\/ow.ly\/5jKUr",
    "id" : 81503959260467200,
    "created_at" : "2011-06-16 23:30:32 +0000",
    "user" : {
      "name" : "BET",
      "screen_name" : "BET",
      "protected" : false,
      "id_str" : "16560657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798866886561845248\/YBNIp--5_normal.jpg",
      "id" : 16560657,
      "verified" : true
    }
  },
  "id" : 81504656987127808,
  "created_at" : "2011-06-16 23:33:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81495306872692736",
  "text" : "Photo of the Day: The First Lady reacts as President Obama soothes a crying baby @ the Congressional Picnic: http:\/\/twitpic.com\/5cirvs",
  "id" : 81495306872692736,
  "created_at" : "2011-06-16 22:56:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81441869711683585",
  "text" : "RT @JoiningForces: President Obama hosts an early Father's Day movie screening for military dads & kids: http:\/\/wh.gov\/1Zs Pic: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81422056385822720",
    "text" : "President Obama hosts an early Father's Day movie screening for military dads & kids: http:\/\/wh.gov\/1Zs Pic: http:\/\/twitpic.com\/5cfj3u",
    "id" : 81422056385822720,
    "created_at" : "2011-06-16 18:05:05 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 81441869711683585,
  "created_at" : "2011-06-16 19:23:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 1, 8 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/VnzAsHK",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/16\/small-manufacturers-are-creating-good-american-jobs",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "81396525615427585",
  "text" : ".@SBAgov on small manufacturers creating good American jobs: http:\/\/t.co\/VnzAsHK",
  "id" : 81396525615427585,
  "created_at" : "2011-06-16 16:23:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81381311016747009",
  "text" : "RT @petesouza: New behind-the-scenes photos of President Obama from last two weeks of May. Includes recent European trip. http:\/\/t.co\/Po ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 126 ],
        "url" : "http:\/\/t.co\/PoCPlei",
        "expanded_url" : "http:\/\/bit.ly\/l0GZB7",
        "display_url" : "bit.ly\/l0GZB7"
      } ]
    },
    "geo" : { },
    "id_str" : "81354913946419201",
    "text" : "New behind-the-scenes photos of President Obama from last two weeks of May. Includes recent European trip. http:\/\/t.co\/PoCPlei",
    "id" : 81354913946419201,
    "created_at" : "2011-06-16 13:38:17 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 81381311016747009,
  "created_at" : "2011-06-16 15:23:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/ecxYGJE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/15\/more-just-history",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "81068887805927424",
  "text" : "More than just history... President Obama on status, job creation & education during his visit to Puerto Rico: http:\/\/t.co\/ecxYGJE",
  "id" : 81068887805927424,
  "created_at" : "2011-06-15 18:41:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Business Roundtable",
      "screen_name" : "BizRoundtable",
      "indices" : [ 17, 31 ],
      "id_str" : "44682276",
      "id" : 44682276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81019292308619264",
  "text" : "RT @SecLocke: At @BizRoundtable to announce SelectUSA - new initiative to drive business growth and job creation in the US http:\/\/bit.ly ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Business Roundtable",
        "screen_name" : "BizRoundtable",
        "indices" : [ 3, 17 ],
        "id_str" : "44682276",
        "id" : 44682276
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81005781331353600",
    "text" : "At @BizRoundtable to announce SelectUSA - new initiative to drive business growth and job creation in the US http:\/\/bit.ly\/k3zs5a",
    "id" : 81005781331353600,
    "created_at" : "2011-06-15 14:30:57 +0000",
    "user" : {
      "name" : "Amb Gary Locke",
      "screen_name" : "AmbLocke",
      "protected" : false,
      "id_str" : "76936279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/433441935\/seclockesmallcropped_normal.jpg",
      "id" : 76936279,
      "verified" : true
    }
  },
  "id" : 81019292308619264,
  "created_at" : "2011-06-15 15:24:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80788363317231617",
  "text" : "Today, President Obama visited Puerto Rico: http:\/\/wh.gov\/1Wh Photo: Remarks at arrival ceremony in San Juan: http:\/\/twitpic.com\/5bnqba",
  "id" : 80788363317231617,
  "created_at" : "2011-06-15 00:07:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 3, 15 ],
      "id_str" : "110541296",
      "id" : 110541296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80693456380497921",
  "text" : "RT @CommerceGov: Using Green Technology to Turn Carbon Dioxide into Cement (and Jobs) - http:\/\/1.usa.gov\/iZAD7A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80684169805570049",
    "text" : "Using Green Technology to Turn Carbon Dioxide into Cement (and Jobs) - http:\/\/1.usa.gov\/iZAD7A",
    "id" : 80684169805570049,
    "created_at" : "2011-06-14 17:12:59 +0000",
    "user" : {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "protected" : false,
      "id_str" : "110541296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/645983513712459776\/3Q0H2IVF_normal.jpg",
      "id" : 110541296,
      "verified" : true
    }
  },
  "id" : 80693456380497921,
  "created_at" : "2011-06-14 17:49:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GoArmy",
      "screen_name" : "GoArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "44961317",
      "id" : 44961317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80664474402553856",
  "text" : "RT @GoArmy: Over 236 yrs of Army history, Soldiers & their families have displayed remarkable resilience & we owe them all a debt of gra ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ArmyBDay",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80643322544271361",
    "text" : "Over 236 yrs of Army history, Soldiers & their families have displayed remarkable resilience & we owe them all a debt of gratitude #ArmyBDay",
    "id" : 80643322544271361,
    "created_at" : "2011-06-14 14:30:41 +0000",
    "user" : {
      "name" : "GoArmy",
      "screen_name" : "GoArmy",
      "protected" : false,
      "id_str" : "44961317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713376386841325570\/pHk4Pnze_normal.jpg",
      "id" : 44961317,
      "verified" : true
    }
  },
  "id" : 80664474402553856,
  "created_at" : "2011-06-14 15:54:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHWomenInScience",
      "indices" : [ 54, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/t2vt46I",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/13\/us-international-dialogue-women-stem-livecast-tomorrow-614-11-am-edt",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80647638797664256",
  "text" : "Have a question about women in science? Ask now using #WHWomenInScience & watch live at 11ET: WH.gov\/live For more info: http:\/\/t.co\/t2vt46I",
  "id" : 80647638797664256,
  "created_at" : "2011-06-14 14:47:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHWomenInScience",
      "indices" : [ 30, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/t2vt46I",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/13\/us-international-dialogue-women-stem-livecast-tomorrow-614-11-am-edt",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80646277267849217",
  "text" : "We're open for questions: Use #WHWomenInScience to ask your Q's now for a live chat on women in STEM. http:\/\/t.co\/t2vt46I",
  "id" : 80646277267849217,
  "created_at" : "2011-06-14 14:42:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHWomenInScience",
      "indices" : [ 64, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http:\/\/t.co\/t2vt46I",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/13\/us-international-dialogue-women-stem-livecast-tomorrow-614-11-am-edt",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80642838848737280",
  "text" : "Live @ 11ET: Join a dialogue on women in science. Ask Qs now w\/ #WHWomenInScience & watch live: WH.gov\/live http:\/\/t.co\/t2vt46I",
  "id" : 80642838848737280,
  "created_at" : "2011-06-14 14:28:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80403434423058432",
  "text" : "There's a new sheriff in town: http:\/\/wh.gov\/12h Vice President Biden announces the Campaign to Cut Waste: http:\/\/twitpic.com\/5b77dj",
  "id" : 80403434423058432,
  "created_at" : "2011-06-13 22:37:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvasivePlants",
      "indices" : [ 92, 107 ]
    }, {
      "text" : "FiddlinForesters",
      "indices" : [ 108, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 91 ],
      "url" : "http:\/\/t.co\/WPLSN9x",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/13\/toomanywebsitesgov",
      "display_url" : "whitehouse.gov\/blog\/2011\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80352807936471040",
  "text" : "RT @macon44: Is CampaignToCutWaste.gov not working for you? Here's why: http:\/\/t.co\/WPLSN9x #InvasivePlants #FiddlinForesters #Centennia ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InvasivePlants",
        "indices" : [ 79, 94 ]
      }, {
        "text" : "FiddlinForesters",
        "indices" : [ 95, 112 ]
      }, {
        "text" : "CentennialofFlight",
        "indices" : [ 113, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 78 ],
        "url" : "http:\/\/t.co\/WPLSN9x",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/06\/13\/toomanywebsitesgov",
        "display_url" : "whitehouse.gov\/blog\/2011\/06\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "80352534157471744",
    "text" : "Is CampaignToCutWaste.gov not working for you? Here's why: http:\/\/t.co\/WPLSN9x #InvasivePlants #FiddlinForesters #CentennialofFlight",
    "id" : 80352534157471744,
    "created_at" : "2011-06-13 19:15:11 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 80352807936471040,
  "created_at" : "2011-06-13 19:16:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 108 ],
      "url" : "http:\/\/t.co\/d69mju0",
      "expanded_url" : "http:\/\/wh.gov\/14w",
      "display_url" : "wh.gov\/14w"
    } ]
  },
  "geo" : { },
  "id_str" : "80317846713937920",
  "text" : "President Obama is meeting w\/ his Council on Jobs & Competitiveness in Durham, NC today: http:\/\/t.co\/d69mju0",
  "id" : 80317846713937920,
  "created_at" : "2011-06-13 16:57:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/9t8zAk0",
      "expanded_url" : "http:\/\/wh.gov\/12E",
      "display_url" : "wh.gov\/12E"
    } ]
  },
  "geo" : { },
  "id_str" : "80291140649234432",
  "text" : "WATCH LIVE: Vice President Biden speaks on new efforts to increase accountability & cut waste across govt: http:\/\/t.co\/9t8zAk0",
  "id" : 80291140649234432,
  "created_at" : "2011-06-13 15:11:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 82, 93 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 49 ],
      "url" : "http:\/\/t.co\/XGCxRx7",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "80273303499059200",
  "text" : "RT @whitehouseostp: Tune into http:\/\/t.co\/XGCxRx7 at 10am EDT this morning for an @whitehouse event on Building the 21st Century Grid",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 62, 73 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 10, 29 ],
        "url" : "http:\/\/t.co\/XGCxRx7",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "80256847981985792",
    "text" : "Tune into http:\/\/t.co\/XGCxRx7 at 10am EDT this morning for an @whitehouse event on Building the 21st Century Grid",
    "id" : 80256847981985792,
    "created_at" : "2011-06-13 12:54:58 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 80273303499059200,
  "created_at" : "2011-06-13 14:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http:\/\/t.co\/uMqKzgi",
      "expanded_url" : "http:\/\/wh.gov\/14p",
      "display_url" : "wh.gov\/14p"
    } ]
  },
  "geo" : { },
  "id_str" : "80266325003472896",
  "text" : "VIDEO: President Obama & Vice President Biden launch the Campaign to Cut Waste: http:\/\/t.co\/uMqKzgi",
  "id" : 80266325003472896,
  "created_at" : "2011-06-13 13:32:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/Wtyu3w2",
      "expanded_url" : "http:\/\/bit.ly\/kYnzRZ",
      "display_url" : "bit.ly\/kYnzRZ"
    } ]
  },
  "geo" : { },
  "id_str" : "79570345601933312",
  "text" : "President Obama's Weekly Address: Govt partnering w\/ the private sector to train workers & spur hiring: http:\/\/t.co\/Wtyu3w2",
  "id" : 79570345601933312,
  "created_at" : "2011-06-11 15:27:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 93 ],
      "url" : "http:\/\/t.co\/oPKozx8",
      "expanded_url" : "http:\/\/bit.ly\/hNqevL",
      "display_url" : "bit.ly\/hNqevL"
    }, {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/tJb81hb",
      "expanded_url" : "http:\/\/bit.ly\/gZw36h",
      "display_url" : "bit.ly\/gZw36h"
    } ]
  },
  "geo" : { },
  "id_str" : "79264373813690368",
  "text" : "Do you have the White House app for your phone? Download app for Android: http:\/\/t.co\/oPKozx8 or iPhone: http:\/\/t.co\/tJb81hb",
  "id" : 79264373813690368,
  "created_at" : "2011-06-10 19:11:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 91, 99 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/xOveYLk",
      "expanded_url" : "http:\/\/wh.gov\/1Y0",
      "display_url" : "wh.gov\/1Y0"
    } ]
  },
  "geo" : { },
  "id_str" : "79229814250287104",
  "text" : "The survey results are in: A few interesting things we\u2019ve learned from our facebook fans & @twitter followers: http:\/\/t.co\/xOveYLk",
  "id" : 79229814250287104,
  "created_at" : "2011-06-10 16:53:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79182117589876736",
  "text" : "Photo of the Day: President Obama greets kids after daughter Sasha's 4th grade graduation: http:\/\/twitpic.com\/59juni",
  "id" : 79182117589876736,
  "created_at" : "2011-06-10 13:44:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/BYob6mg",
      "expanded_url" : "http:\/\/bit.ly\/jdt40b",
      "display_url" : "bit.ly\/jdt40b"
    } ]
  },
  "geo" : { },
  "id_str" : "79045835136040960",
  "text" : "Fresh West Wing Week: Visit an auto plant in Toledo, meet Spelling Bee champs in the Oval & more: http:\/\/t.co\/BYob6mg",
  "id" : 79045835136040960,
  "created_at" : "2011-06-10 04:42:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPAGov",
      "indices" : [ 3, 10 ],
      "id_str" : "1604108887",
      "id" : 1604108887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EPA",
      "indices" : [ 73, 77 ]
    }, {
      "text" : "gov20",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78905875942752256",
  "text" : "RT @EPAgov: Developers, start your engines! Show us what you can do with #EPA data in a mobile app: http:\/\/1.usa.gov\/m4YZEk #gov20",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EPA",
        "indices" : [ 61, 65 ]
      }, {
        "text" : "gov20",
        "indices" : [ 112, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78833700070096896",
    "text" : "Developers, start your engines! Show us what you can do with #EPA data in a mobile app: http:\/\/1.usa.gov\/m4YZEk #gov20",
    "id" : 78833700070096896,
    "created_at" : "2011-06-09 14:39:53 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 78905875942752256,
  "created_at" : "2011-06-09 19:26:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78885836682309632",
  "text" : "Photo of the Day: President Obama & Vice President Biden head to the Oval Office dining room for lunch: http:\/\/twitpic.com\/597eky",
  "id" : 78885836682309632,
  "created_at" : "2011-06-09 18:07:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/9YTFMEm",
      "expanded_url" : "http:\/\/wh.gov\/1Cz",
      "display_url" : "wh.gov\/1Cz"
    } ]
  },
  "geo" : { },
  "id_str" : "78855800830951426",
  "text" : "\u201CStrong rural communities are key to a stronger America\u201D -President Obama on the new WH Rural Council: http:\/\/t.co\/9YTFMEm",
  "id" : 78855800830951426,
  "created_at" : "2011-06-09 16:07:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/HcxU7xd",
      "expanded_url" : "http:\/\/wh.gov\/1aE",
      "display_url" : "wh.gov\/1aE"
    } ]
  },
  "geo" : { },
  "id_str" : "78600932656545792",
  "text" : "President Obama welcomes the 2010 BCS National Champion Auburn Tigers to the White House. Video: http:\/\/t.co\/HcxU7xd",
  "id" : 78600932656545792,
  "created_at" : "2011-06-08 23:14:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/HcxU7xd",
      "expanded_url" : "http:\/\/wh.gov\/1aE",
      "display_url" : "wh.gov\/1aE"
    } ]
  },
  "geo" : { },
  "id_str" : "78600463343292417",
  "text" : "President Obama welcomes the 2010 BCS National Champion Auburn Tigers to the White House. Video: http:\/\/t.co\/HcxU7xd",
  "id" : 78600463343292417,
  "created_at" : "2011-06-08 23:13:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nova",
      "screen_name" : "novaaccess",
      "indices" : [ 67, 78 ],
      "id_str" : "783412670007357442",
      "id" : 783412670007357442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78556143324114944",
  "text" : "Obama announces initiatives to improve our manufacturing workforce @NovaAccess: http:\/\/wh.gov\/1xg Pic: http:\/\/twitpic.com\/58t7xk",
  "id" : 78556143324114944,
  "created_at" : "2011-06-08 20:16:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78545051571060737",
  "text" : "RT @letsmove: Introducing Let's Move! Child Care: Tools for child & day care centers to help our children get off to a healthy start htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78539203738206209",
    "text" : "Introducing Let's Move! Child Care: Tools for child & day care centers to help our children get off to a healthy start http:\/\/goo.gl\/epV0O",
    "id" : 78539203738206209,
    "created_at" : "2011-06-08 19:09:40 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 78545051571060737,
  "created_at" : "2011-06-08 19:32:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 34, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78522544763842560",
  "text" : "Slideshow: Germany Official Visit #AtTheWH: http:\/\/wh.gov\/1Oq Photo of the Day: Marine Sentries ready: http:\/\/twitpic.com\/58rrng",
  "id" : 78522544763842560,
  "created_at" : "2011-06-08 18:03:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Get Schooled",
      "screen_name" : "getschooled",
      "indices" : [ 3, 15 ],
      "id_str" : "20691360",
      "id" : 20691360
    }, {
      "name" : "BET",
      "screen_name" : "BET",
      "indices" : [ 114, 118 ],
      "id_str" : "16560657",
      "id" : 16560657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78510886796533760",
  "text" : "RT @getschooled: Today's the day! The Commencement Challenge Special ft. BTWHS students & Obama will air tonight (@BET 7:30p ET simulcas ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BET",
        "screen_name" : "BET",
        "indices" : [ 97, 101 ],
        "id_str" : "16560657",
        "id" : 16560657
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78457577423380480",
    "text" : "Today's the day! The Commencement Challenge Special ft. BTWHS students & Obama will air tonight (@BET 7:30p ET simulcast) http:\/\/ow.ly\/5cDaI",
    "id" : 78457577423380480,
    "created_at" : "2011-06-08 13:45:18 +0000",
    "user" : {
      "name" : "Get Schooled",
      "screen_name" : "getschooled",
      "protected" : false,
      "id_str" : "20691360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738094942753423361\/2mF-E0mi_normal.jpg",
      "id" : 20691360,
      "verified" : true
    }
  },
  "id" : 78510886796533760,
  "created_at" : "2011-06-08 17:17:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Energy and Commerce",
      "screen_name" : "HouseCommerce",
      "indices" : [ 20, 34 ],
      "id_str" : "114756202",
      "id" : 114756202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78500585338437632",
  "text" : "RT @whitehouseostp: @HouseCommerce An Important Bipartisan Milestone for Spectrum Policy http:\/\/go.usa.gov\/DeN",
  "id" : 78500585338437632,
  "created_at" : "2011-06-08 16:36:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78236261495746562",
  "text" : "VIDEO: The German State Dinner uses veg & herbs from the WH garden. Peek inside the kitchen for dinner prep: http:\/\/bit.ly\/mFNkWY",
  "id" : 78236261495746562,
  "created_at" : "2011-06-07 23:05:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 48, 63 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78165563142193152",
  "text" : "RT @pfeiffer44: WH Blog post: Fact checking the @washingtonpost Factchecker on Autos. Even the factcheckers get it wrong sometimes.  htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 32, 47 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "78126967806889984",
    "text" : "WH Blog post: Fact checking the @washingtonpost Factchecker on Autos. Even the factcheckers get it wrong sometimes.  http:\/\/goo.gl\/egiF0",
    "id" : 78126967806889984,
    "created_at" : "2011-06-07 15:51:35 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 78165563142193152,
  "created_at" : "2011-06-07 18:24:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78119678827962368",
  "text" : "President Obama led his monthly Afghanistan & Pakistan meeting yesterday. Readout: http:\/\/wh.gov\/1l0 Photo: http:\/\/twitpic.com\/58add8",
  "id" : 78119678827962368,
  "created_at" : "2011-06-07 15:22:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Becky Mezzanotte",
      "screen_name" : "DirectedByBecky",
      "indices" : [ 55, 71 ],
      "id_str" : "17784969",
      "id" : 17784969
    }, {
      "name" : "Ashley Estill",
      "screen_name" : "ashleyestill",
      "indices" : [ 72, 85 ],
      "id_str" : "47222770",
      "id" : 47222770
    }, {
      "name" : "Patrick McDermott",
      "screen_name" : "pdmcdermott",
      "indices" : [ 100, 112 ],
      "id_str" : "12633642",
      "id" : 12633642
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78113236880326657",
  "text" : "Lots of folks #AtTheWH welcomed the German delegation: @DirectedByBecky @ashleyestill @BecomingADoc @pdmcdermott & more discussing.",
  "id" : 78113236880326657,
  "created_at" : "2011-06-07 14:57:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78109666848153601",
  "text" : "WATCH: US Chief of Protocol talks to us from Blair House just after the arrival of the German delegation: http:\/\/bit.ly\/iU2jea",
  "id" : 78109666848153601,
  "created_at" : "2011-06-07 14:42:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "statevisit",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78088259066007553",
  "text" : "Now: President Obama welcomes Chancellor Merkel of Germany to the WH for an Official Visit: http:\/\/www.wh.gov\/live #statevisit",
  "id" : 78088259066007553,
  "created_at" : "2011-06-07 13:17:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78086425853177857",
  "text" : "Thousands of people #AtTheWH for the Official Arrival Ceremony of Chancellor Merkel of Germany. Watch it live: http:\/\/www.wh.gov\/live",
  "id" : 78086425853177857,
  "created_at" : "2011-06-07 13:10:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77850040072286208",
  "text" : "RT @JoiningForces: The VP & Dr. Biden thank service members & families in Naples: http:\/\/wh.gov\/1qq Share your message of thanks: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77849756109504512",
    "text" : "The VP & Dr. Biden thank service members & families in Naples: http:\/\/wh.gov\/1qq Share your message of thanks: http:\/\/wh.gov\/aPv",
    "id" : 77849756109504512,
    "created_at" : "2011-06-06 21:30:02 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 77850040072286208,
  "created_at" : "2011-06-06 21:31:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPAGov",
      "indices" : [ 46, 53 ],
      "id_str" : "1604108887",
      "id" : 1604108887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77792291888173056",
  "text" : "Investing in our communities & creating jobs: @EPAgov announces clean-up grants for projects around the country: http:\/\/wh.gov\/1qX",
  "id" : 77792291888173056,
  "created_at" : "2011-06-06 17:41:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77766034131660800",
  "text" : "Photo of the Day: President Obama grabs lunch at Rudy\u2019s Hot Dog in Toledo, OH w\/ Toledo Mayor Bell: http:\/\/twitpic.com\/57vca5",
  "id" : 77766034131660800,
  "created_at" : "2011-06-06 15:57:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 74, 85 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77422988332498944",
  "text" : "We want your feedback. Take a short survey & tell us what you think about @whitehouse on twitter: http:\/\/wh.gov\/3IK",
  "id" : 77422988332498944,
  "created_at" : "2011-06-05 17:14:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 3, 18 ],
      "id_str" : "211921304",
      "id" : 211921304
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 70, 81 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "indices" : [ 94, 104 ],
      "id_str" : "25110374",
      "id" : 25110374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UrbanSummit",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77403137975123968",
  "text" : "RT @startupamerica: Big Day Tomorrow! Urban Entrepreneurship Summit w @WhiteHouse, Keynote by @UncleRUSH: http:\/\/ar.gy\/Q8C #UrbanSummit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/reach.me\" rel=\"nofollow\"\u003EReach.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 50, 61 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Russell Simmons",
        "screen_name" : "UncleRUSH",
        "indices" : [ 74, 84 ],
        "id_str" : "25110374",
        "id" : 25110374
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UrbanSummit",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "77397785955155968",
    "text" : "Big Day Tomorrow! Urban Entrepreneurship Summit w @WhiteHouse, Keynote by @UncleRUSH: http:\/\/ar.gy\/Q8C #UrbanSummit",
    "id" : 77397785955155968,
    "created_at" : "2011-06-05 15:34:04 +0000",
    "user" : {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "protected" : false,
      "id_str" : "211921304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1362197801\/120X120_ICON_normal.png",
      "id" : 211921304,
      "verified" : false
    }
  },
  "id" : 77403137975123968,
  "created_at" : "2011-06-05 15:55:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77126858709270529",
  "text" : "The President & Vice President on the passing of former Sec. of State Lawrence Eagleburger: http:\/\/www.wh.gov\/ChL",
  "id" : 77126858709270529,
  "created_at" : "2011-06-04 21:37:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77000178321719296",
  "text" : "\"We\u2019re a people who don\u2019t give up, who do big things, who shape our own destiny\" -President Obama. Video: http:\/\/bit.ly\/l1WAxW",
  "id" : 77000178321719296,
  "created_at" : "2011-06-04 13:14:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chrysler",
      "screen_name" : "Chrysler",
      "indices" : [ 42, 51 ],
      "id_str" : "119159695",
      "id" : 119159695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76787296623542272",
  "text" : "\u201CI placed my bet on you\u201D -President Obama @Chrysler Plant in Toledo. Remarks: http:\/\/wh.gov\/CS7 Pic: http:\/\/twitpic.com\/56iyix",
  "id" : 76787296623542272,
  "created_at" : "2011-06-03 23:08:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 44, 55 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 56, 64 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76767632405184512",
  "text" : "Hey followers - what do you think about the @whitehouse @twitter acct? Take this survey & tell us: http:\/\/wh.gov\/3IK",
  "id" : 76767632405184512,
  "created_at" : "2011-06-03 21:50:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76762870850920450",
  "text" : "RT @jesseclee44: Hard to sneak up on people as President: \"\u2026I got a little suspicious when I saw the 20 cop cars in our parking lot.\" ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76758446308990976",
    "text" : "Hard to sneak up on people as President: \"\u2026I got a little suspicious when I saw the 20 cop cars in our parking lot.\" http:\/\/bit.ly\/iXdgwI",
    "id" : 76758446308990976,
    "created_at" : "2011-06-03 21:13:34 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 76762870850920450,
  "created_at" : "2011-06-03 21:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 5, 20 ],
      "id_str" : "211921304",
      "id" : 211921304
    }, {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "indices" : [ 92, 102 ],
      "id_str" : "25110374",
      "id" : 25110374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UrbanSummit",
      "indices" : [ 68, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76758224988155904",
  "text" : "WH & @StartupAmerica kick off Urban Entrepreneurship Summit on Mon. #UrbanSummit keynote by @UncleRUSH: http:\/\/huff.to\/mAn8En",
  "id" : 76758224988155904,
  "created_at" : "2011-06-03 21:12:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76703349168287744",
  "text" : "The resurgence of the American automotive industry: Report: http:\/\/wh.gov\/CzO Infographic:   http:\/\/twitpic.com\/56f38q",
  "id" : 76703349168287744,
  "created_at" : "2011-06-03 17:34:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chrysler",
      "screen_name" : "Chrysler",
      "indices" : [ 36, 45 ],
      "id_str" : "119159695",
      "id" : 119159695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76700308058800128",
  "text" : "Now: The President talks to workers @Chrysler in Toledo, OH on the auto industry comeback: http:\/\/www.wh.gov\/live",
  "id" : 76700308058800128,
  "created_at" : "2011-06-03 17:22:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Joplin",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76639163834830848",
  "text" : "West Wing Week: Go to #Joplin, Poland, Arlington & the Situation Room w\/ President Obama: http:\/\/bit.ly\/mpHNdd",
  "id" : 76639163834830848,
  "created_at" : "2011-06-03 13:19:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 12, 19 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76409040929959936",
  "text" : "The Dept of @ENERGY is challenging cities to cut the red tape & help drive down the cost of solar energy: http:\/\/wh.gov\/Cu8",
  "id" : 76409040929959936,
  "created_at" : "2011-06-02 22:05:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76355371119284224",
  "text" : "President Obama's 100 Youth Roundtables: Detroit area young people make their voices heard: http:\/\/wh.gov\/CuQ",
  "id" : 76355371119284224,
  "created_at" : "2011-06-02 18:31:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Health",
      "screen_name" : "VeteransHealth",
      "indices" : [ 3, 18 ],
      "id_str" : "17346287",
      "id" : 17346287
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Veteran",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76337826899312641",
  "text" : "RT @VeteransHealth: If you are a caregiver for a #Veteran, visit the new VA Caregiver Support website for resources, tips and support: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Veteran",
        "indices" : [ 29, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76314654141452288",
    "text" : "If you are a caregiver for a #Veteran, visit the new VA Caregiver Support website for resources, tips and support: http:\/\/ow.ly\/58u1k",
    "id" : 76314654141452288,
    "created_at" : "2011-06-02 15:50:06 +0000",
    "user" : {
      "name" : "Veterans Health",
      "screen_name" : "VeteransHealth",
      "protected" : false,
      "id_str" : "17346287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261570144451\/6e587805e89b82ecf41c40375e28db37_normal.png",
      "id" : 17346287,
      "verified" : false
    }
  },
  "id" : 76337826899312641,
  "created_at" : "2011-06-02 17:22:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FoodIcon",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "MyPlate",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76323204506992640",
  "text" : "RT @letsmove: Check out this video about the new #FoodIcon, #MyPlate: http:\/\/goo.gl\/peAb2",
  "id" : 76323204506992640,
  "created_at" : "2011-06-02 16:24:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 10, 21 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76298730504060928",
  "text" : "How\u2019s the @whitehouse account doing? Things you like? Things it could do better? Take our survey: http:\/\/wh.gov\/3IK",
  "id" : 76298730504060928,
  "created_at" : "2011-06-02 14:46:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76037132501794816",
  "text" : "Photo: President Obama's briefing on federal prep for hurricane season in the Sit Room: http:\/\/twitpic.com\/55lqdj",
  "id" : 76037132501794816,
  "created_at" : "2011-06-01 21:27:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76002444705923072",
  "text" : "Now: Open for Questions on the 30th anniversary of the AIDS epidemic. Watch: wh.gov\/live Ask Qs on fb: http:\/\/bit.ly\/eZ2fG7",
  "id" : 76002444705923072,
  "created_at" : "2011-06-01 19:09:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lgbt",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 41 ],
      "url" : "http:\/\/t.co\/yRUWtHR",
      "expanded_url" : "http:\/\/wh.gov\/lgbt",
      "display_url" : "wh.gov\/lgbt"
    }, {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/FYcimBb",
      "expanded_url" : "http:\/\/1.usa.gov\/l0s4rB",
      "display_url" : "1.usa.gov\/l0s4rB"
    } ]
  },
  "geo" : { },
  "id_str" : "75998879409127424",
  "text" : "RT @jesseclee44: New: http:\/\/t.co\/yRUWtHR Includes updated doc on Obama #lgbt progress, more to do but worth a look: http:\/\/t.co\/FYcimBb ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lgbt",
        "indices" : [ 55, 60 ]
      }, {
        "text" : "pride",
        "indices" : [ 120, 126 ]
      }, {
        "text" : "p2",
        "indices" : [ 127, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 5, 24 ],
        "url" : "http:\/\/t.co\/yRUWtHR",
        "expanded_url" : "http:\/\/wh.gov\/lgbt",
        "display_url" : "wh.gov\/lgbt"
      }, {
        "indices" : [ 100, 119 ],
        "url" : "http:\/\/t.co\/FYcimBb",
        "expanded_url" : "http:\/\/1.usa.gov\/l0s4rB",
        "display_url" : "1.usa.gov\/l0s4rB"
      } ]
    },
    "geo" : { },
    "id_str" : "75996215715696641",
    "text" : "New: http:\/\/t.co\/yRUWtHR Includes updated doc on Obama #lgbt progress, more to do but worth a look: http:\/\/t.co\/FYcimBb #pride #p2",
    "id" : 75996215715696641,
    "created_at" : "2011-06-01 18:44:44 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 75998879409127424,
  "created_at" : "2011-06-01 18:55:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chrysler",
      "screen_name" : "Chrysler",
      "indices" : [ 23, 32 ],
      "id_str" : "119159695",
      "id" : 119159695
    }, {
      "name" : "General Motors",
      "screen_name" : "GM",
      "indices" : [ 35, 38 ],
      "id_str" : "10850192",
      "id" : 10850192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75954111501180928",
  "text" : "Obama's choice to help @Chrysler & @GM is helping drive American auto industry comeback. WH report: http:\/\/1.usa.gov\/mJmgfk",
  "id" : 75954111501180928,
  "created_at" : "2011-06-01 15:57:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 85, 96 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75924853324128256",
  "text" : "RT @macon44: Great write up from a Champion of Change of what it's like to visit the @whitehouse http:\/\/goo.gl\/pM4Ru",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 72, 83 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75923620035182592",
    "text" : "Great write up from a Champion of Change of what it's like to visit the @whitehouse http:\/\/goo.gl\/pM4Ru",
    "id" : 75923620035182592,
    "created_at" : "2011-06-01 13:56:16 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 75924853324128256,
  "created_at" : "2011-06-01 14:01:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 52, 67 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75923749416873985",
  "text" : "RT @pfeiffer44: Sec Geithner has an op ed in tmmw's @washingtonpost on the tough decisions made by POTUS to save the US auto industry  h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 36, 51 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "75759815984558080",
    "text" : "Sec Geithner has an op ed in tmmw's @washingtonpost on the tough decisions made by POTUS to save the US auto industry  http:\/\/wapo.st\/kRaprz",
    "id" : 75759815984558080,
    "created_at" : "2011-06-01 03:05:22 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 75923749416873985,
  "created_at" : "2011-06-01 13:56:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]