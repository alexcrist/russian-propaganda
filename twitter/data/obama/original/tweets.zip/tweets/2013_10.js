Grailbird.data.tweets_2013_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 31, 38 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/396103175255506944\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/SPFsNI29gc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX89vT_CQAEPIjU.jpg",
      "id_str" : "396103175259701249",
      "id" : 396103175259701249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX89vT_CQAEPIjU.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SPFsNI29gc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396103175255506944",
  "text" : "Happy Halloween from POTUS and @FLOTUS! http:\/\/t.co\/SPFsNI29gc",
  "id" : 396103175255506944,
  "created_at" : "2013-11-01 02:35:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/396027048604348416\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/18NpUnbMhz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX74gKICMAAmq_j.jpg",
      "id_str" : "396027048612737024",
      "id" : 396027048612737024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX74gKICMAAmq_j.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/18NpUnbMhz"
    } ],
    "hashtags" : [ {
      "text" : "TrickOrTreat",
      "indices" : [ 39, 52 ]
    }, {
      "text" : "HappyHalloween",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/TLuB0gLbmr",
      "expanded_url" : "http:\/\/go.wh.gov\/Xyw5Fz",
      "display_url" : "go.wh.gov\/Xyw5Fz"
    } ]
  },
  "geo" : { },
  "id_str" : "396027048604348416",
  "text" : "Watch local kids and military families #TrickOrTreat at the White House \u2014&gt; http:\/\/t.co\/TLuB0gLbmr #HappyHalloween, http:\/\/t.co\/18NpUnbMhz",
  "id" : 396027048604348416,
  "created_at" : "2013-10-31 21:33:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/396009722077138945\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/rcZpxD579B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX7ovnHCQAAInn2.jpg",
      "id_str" : "396009721905168384",
      "id" : 396009721905168384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX7ovnHCQAAInn2.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rcZpxD579B"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 52, 62 ]
    }, {
      "text" : "HappyHalloween",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "396009722077138945",
  "text" : "#GetCovered because\u2026zombies: http:\/\/t.co\/GNfbftrfo3 #Obamacare #HappyHalloween, http:\/\/t.co\/rcZpxD579B",
  "id" : 396009722077138945,
  "created_at" : "2013-10-31 20:24:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/395996152018907136\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/MuIQQzRhmd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX7cZvXCMAA_ly9.jpg",
      "id_str" : "395996152023101440",
      "id" : 395996152023101440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX7cZvXCMAA_ly9.jpg",
      "sizes" : [ {
        "h" : 623,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1972
      }, {
        "h" : 1063,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MuIQQzRhmd"
    } ],
    "hashtags" : [ {
      "text" : "Halloween",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396006286695071744",
  "text" : "RT @DrBiden: PHOTO: Happy #Halloween from Dr. Biden's office! http:\/\/t.co\/MuIQQzRhmd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/395996152018907136\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/MuIQQzRhmd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BX7cZvXCMAA_ly9.jpg",
        "id_str" : "395996152023101440",
        "id" : 395996152023101440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX7cZvXCMAA_ly9.jpg",
        "sizes" : [ {
          "h" : 623,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1972
        }, {
          "h" : 1063,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MuIQQzRhmd"
      } ],
      "hashtags" : [ {
        "text" : "Halloween",
        "indices" : [ 13, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395996152018907136",
    "text" : "PHOTO: Happy #Halloween from Dr. Biden's office! http:\/\/t.co\/MuIQQzRhmd",
    "id" : 395996152018907136,
    "created_at" : "2013-10-31 19:30:14 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 396006286695071744,
  "created_at" : "2013-10-31 20:10:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/395992144231424000\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/U0Co7HZ4CO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX7YwdNCYAACeRw.jpg",
      "id_str" : "395992144239812608",
      "id" : 395992144239812608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX7YwdNCYAACeRw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/U0Co7HZ4CO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395992144231424000",
  "text" : "Happy Halloween! http:\/\/t.co\/U0Co7HZ4CO",
  "id" : 395992144231424000,
  "created_at" : "2013-10-31 19:14:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395988367479164928",
  "text" : "RT @SecretaryJewell: We have a moral obligation to the next generation to leave our land, water, and wildlife better than we found it. #con\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "conservation",
        "indices" : [ 114, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395962999711612928",
    "text" : "We have a moral obligation to the next generation to leave our land, water, and wildlife better than we found it. #conservation",
    "id" : 395962999711612928,
    "created_at" : "2013-10-31 17:18:30 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 395988367479164928,
  "created_at" : "2013-10-31 18:59:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "indices" : [ 95, 105 ],
      "id_str" : "1099296103",
      "id" : 1099296103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395972969664491520",
  "text" : "\"There\u2019s no substitute for those three proud words: '#MadeInAmerica.'\" \u2014President Obama at the @SelectUSA summit",
  "id" : 395972969664491520,
  "created_at" : "2013-10-31 17:58:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 39, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395972352132919296",
  "text" : "President Obama: \"Let\u2019s fix our broken #immigration system so we\u2019re welcoming more talented workers &amp; entrepreneurs from around the world.\"",
  "id" : 395972352132919296,
  "created_at" : "2013-10-31 17:55:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395971940201930752",
  "text" : "Obama: \"It\u2019s time for Congress to focus on what the American people are focused on...creating good jobs that pay good wages\" #ABetterBargain",
  "id" : 395971940201930752,
  "created_at" : "2013-10-31 17:54:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395971671862951936",
  "text" : "RT @WHLive: Obama: \"For the 1st time, companies who want to do business in America [will] have a single point of contact...to cut through r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395971590015307777",
    "text" : "Obama: \"For the 1st time, companies who want to do business in America [will] have a single point of contact...to cut through red tape.\"",
    "id" : 395971590015307777,
    "created_at" : "2013-10-31 17:52:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 395971671862951936,
  "created_at" : "2013-10-31 17:52:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "indices" : [ 46, 56 ],
      "id_str" : "1099296103",
      "id" : 1099296103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395971211424849920",
  "text" : "President Obama: \"I\u2019m expanding and enhancing @SelectUSA...to recruit businesses to invest and create new jobs in the U.S.\"",
  "id" : 395971211424849920,
  "created_at" : "2013-10-31 17:51:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 53, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395970759639564288",
  "text" : "RT @WHLive: President Obama: \"Today, more Hondas are #MadeInAmerica than anywhere else in the world.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 41, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395970686423818240",
    "text" : "President Obama: \"Today, more Hondas are #MadeInAmerica than anywhere else in the world.\"",
    "id" : 395970686423818240,
    "created_at" : "2013-10-31 17:49:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 395970759639564288,
  "created_at" : "2013-10-31 17:49:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395970644359139328",
  "text" : "RT @WHLive: President Obama: \"Caterpillar is bringing jobs back from Japan. Ford is bringing jobs back from Mexico.\" #MadeInAmerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 105, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395970453488939008",
    "text" : "President Obama: \"Caterpillar is bringing jobs back from Japan. Ford is bringing jobs back from Mexico.\" #MadeInAmerica",
    "id" : 395970453488939008,
    "created_at" : "2013-10-31 17:48:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 395970644359139328,
  "created_at" : "2013-10-31 17:48:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395970319598374912",
  "text" : "Obama: \"America is open for business...after a decade in which many jobs left the U.S. to go overseas\u2014many companies are bringing jobs back\"",
  "id" : 395970319598374912,
  "created_at" : "2013-10-31 17:47:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/395969633800302592\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/3iUZJJaFnY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX7ESKgCEAAcs1J.jpg",
      "id_str" : "395969633590579200",
      "id" : 395969633590579200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX7ESKgCEAAcs1J.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/3iUZJJaFnY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395969633800302592",
  "text" : "President Obama: \"Over the past three and half years, our businesses have created more than 7.5 million jobs.\" http:\/\/t.co\/3iUZJJaFnY",
  "id" : 395969633800302592,
  "created_at" : "2013-10-31 17:44:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395969377201164288",
  "text" : "President Obama: \"Creating good-paying American jobs and strengthening the middle class. There\u2019s nothing more important right now.\"",
  "id" : 395969377201164288,
  "created_at" : "2013-10-31 17:43:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "indices" : [ 23, 33 ],
      "id_str" : "1099296103",
      "id" : 1099296103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395969148267671552",
  "text" : "President Obama at the @SelectUSA summit: \"As President, I\u2019ve gone all over the world to go to bat for American exports &amp; American workers.\"",
  "id" : 395969148267671552,
  "created_at" : "2013-10-31 17:42:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "indices" : [ 41, 51 ],
      "id_str" : "1099296103",
      "id" : 1099296103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "395969051383455744",
  "text" : "Right now: President Obama speaks at the @SelectUSA summit on bringing more investment and jobs to the U.S. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 395969051383455744,
  "created_at" : "2013-10-31 17:42:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "indices" : [ 52, 62 ],
      "id_str" : "1099296103",
      "id" : 1099296103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/DX9bLGw3GZ",
      "expanded_url" : "http:\/\/go.wh.gov\/XhcV3g",
      "display_url" : "go.wh.gov\/XhcV3g"
    } ]
  },
  "geo" : { },
  "id_str" : "395965483121246208",
  "text" : "At 1:30pm ET, watch President Obama's speech at the @SelectUSA summit on bringing more investment &amp; jobs to the U.S. http:\/\/t.co\/DX9bLGw3GZ",
  "id" : 395965483121246208,
  "created_at" : "2013-10-31 17:28:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/cYOx89hTQ2",
      "expanded_url" : "http:\/\/go.wh.gov\/dkhTA3",
      "display_url" : "go.wh.gov\/dkhTA3"
    } ]
  },
  "geo" : { },
  "id_str" : "395954050132226048",
  "text" : "\"I can finally take off the scarlet letter D that has marked me as a pre-existing diabetic.\" \u2014Karmel on #Obamacare: http:\/\/t.co\/cYOx89hTQ2",
  "id" : 395954050132226048,
  "created_at" : "2013-10-31 16:42:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 63, 71 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThrowbackThursday",
      "indices" : [ 18, 36 ]
    }, {
      "text" : "Halloween",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395947417897824256",
  "text" : "RT @VP: A special #ThrowbackThursday for #Halloween \u2013 VP &amp; @DrBiden in NH last year, bringing home their (36 lb!) pumpkin: http:\/\/t.co\/HKym\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 55, 63 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/395943286486999041\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/HKymwzXetq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BX6sUj7CIAElIqo.jpg",
        "id_str" : "395943286495387649",
        "id" : 395943286495387649,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX6sUj7CIAElIqo.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HKymwzXetq"
      } ],
      "hashtags" : [ {
        "text" : "ThrowbackThursday",
        "indices" : [ 10, 28 ]
      }, {
        "text" : "Halloween",
        "indices" : [ 33, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395943286486999041",
    "text" : "A special #ThrowbackThursday for #Halloween \u2013 VP &amp; @DrBiden in NH last year, bringing home their (36 lb!) pumpkin: http:\/\/t.co\/HKymwzXetq",
    "id" : 395943286486999041,
    "created_at" : "2013-10-31 16:00:10 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 395947417897824256,
  "created_at" : "2013-10-31 16:16:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 87, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/WfwjZnNypA",
      "expanded_url" : "http:\/\/go.wh.gov\/18N5Xm",
      "display_url" : "go.wh.gov\/18N5Xm"
    } ]
  },
  "geo" : { },
  "id_str" : "395935796659617792",
  "text" : "Karmel's story: \"I no longer fear my 'pre-existing condition.'\" http:\/\/t.co\/WfwjZnNypA #ThanksObamacare",
  "id" : 395935796659617792,
  "created_at" : "2013-10-31 15:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toby Ziegler",
      "screen_name" : "Toby_Ziegler",
      "indices" : [ 17, 30 ],
      "id_str" : "180105135",
      "id" : 180105135
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GadgetsFly",
      "indices" : [ 56, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/9AFswjPkl4",
      "expanded_url" : "http:\/\/go.wh.gov\/vH4pDd",
      "display_url" : "go.wh.gov\/vH4pDd"
    } ]
  },
  "geo" : { },
  "id_str" : "395925827142955008",
  "text" : "\"You're welcome, @Toby_Ziegler.\" http:\/\/t.co\/9AFswjPkl4 #GadgetsFly",
  "id" : 395925827142955008,
  "created_at" : "2013-10-31 14:50:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/395914487544287232\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/s4PcsHgbBD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX6SIOoCIAIWK5s.jpg",
      "id_str" : "395914487317798914",
      "id" : 395914487317798914,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX6SIOoCIAIWK5s.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/s4PcsHgbBD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/5NOJD61kL0",
      "expanded_url" : "http:\/\/go.wh.gov\/gtC8DY",
      "display_url" : "go.wh.gov\/gtC8DY"
    } ]
  },
  "geo" : { },
  "id_str" : "395914487544287232",
  "text" : "FACT: Since President Obama took office, we've cut the deficit by more than half \u2014&gt; http:\/\/t.co\/5NOJD61kL0, http:\/\/t.co\/s4PcsHgbBD",
  "id" : 395914487544287232,
  "created_at" : "2013-10-31 14:05:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/395706733647396864\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/eDqekoqCnf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX3VLWeIQAI9Juu.jpg",
      "id_str" : "395706733265698818",
      "id" : 395706733265698818,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX3VLWeIQAI9Juu.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eDqekoqCnf"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395706733647396864",
  "text" : "No more dropping coverage if you get sick.\n\nNo more denying coverage for a pre-existing condition.\n\n#Obamacare, http:\/\/t.co\/eDqekoqCnf",
  "id" : 395706733647396864,
  "created_at" : "2013-10-31 00:20:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/395696759428497408\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/nCG4aiEExT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX3MGzECQAAkDIa.png",
      "id_str" : "395696759436886016",
      "id" : 395696759436886016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX3MGzECQAAkDIa.png",
      "sizes" : [ {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      } ],
      "display_url" : "pic.twitter.com\/nCG4aiEExT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/S2v6GDh2Vw",
      "expanded_url" : "http:\/\/go.wh.gov\/tqPQ7c",
      "display_url" : "go.wh.gov\/tqPQ7c"
    } ]
  },
  "geo" : { },
  "id_str" : "395696759428497408",
  "text" : "Brought to you by the letters F-L-O-T-U-S \u2014&gt; http:\/\/t.co\/S2v6GDh2Vw, http:\/\/t.co\/nCG4aiEExT",
  "id" : 395696759428497408,
  "created_at" : "2013-10-30 23:40:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395695271629172738",
  "text" : "RT @CEAChair: The federal gov\u2019t ended fy13 with a deficit of 4.1% of GDP, less than half inherited deficit of 9.2% of GDP in 2009 http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/395690271603568642\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/2uGqqXJ4oP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BX3GNKCCMAAJQSa.jpg",
        "id_str" : "395690271611957248",
        "id" : 395690271611957248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX3GNKCCMAAJQSa.jpg",
        "sizes" : [ {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2uGqqXJ4oP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395690271603568642",
    "text" : "The federal gov\u2019t ended fy13 with a deficit of 4.1% of GDP, less than half inherited deficit of 9.2% of GDP in 2009 http:\/\/t.co\/2uGqqXJ4oP",
    "id" : 395690271603568642,
    "created_at" : "2013-10-30 23:14:47 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 395695271629172738,
  "created_at" : "2013-10-30 23:34:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Sesame Street",
      "screen_name" : "sesamestreet",
      "indices" : [ 22, 35 ],
      "id_str" : "86330674",
      "id" : 86330674
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 71, 82 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395676260195905536",
  "text" : "RT @FLOTUS: Thanks to @sesamestreet's Elmo and Rosita for visiting the @WhiteHouse today to help show kids that healthy food can be fun &amp; t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sesame Street",
        "screen_name" : "sesamestreet",
        "indices" : [ 10, 23 ],
        "id_str" : "86330674",
        "id" : 86330674
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 59, 70 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395671113763520512",
    "text" : "Thanks to @sesamestreet's Elmo and Rosita for visiting the @WhiteHouse today to help show kids that healthy food can be fun &amp; tasty too! -mo",
    "id" : 395671113763520512,
    "created_at" : "2013-10-30 21:58:39 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 395676260195905536,
  "created_at" : "2013-10-30 22:19:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kynectky",
      "screen_name" : "kynectky",
      "indices" : [ 3, 12 ],
      "id_str" : "1336773938",
      "id" : 1336773938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kynect",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/yKWvy78t1f",
      "expanded_url" : "http:\/\/goo.gl\/3QHL9d",
      "display_url" : "goo.gl\/3QHL9d"
    } ]
  },
  "geo" : { },
  "id_str" : "395669620776271872",
  "text" : "RT @kynectky: Over 31,000 Kentuckians are enrolled in new affordable healthcare coverage through #kynect! http:\/\/t.co\/yKWvy78t1f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kynect",
        "indices" : [ 83, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/yKWvy78t1f",
        "expanded_url" : "http:\/\/goo.gl\/3QHL9d",
        "display_url" : "goo.gl\/3QHL9d"
      } ]
    },
    "geo" : { },
    "id_str" : "395662748895698945",
    "text" : "Over 31,000 Kentuckians are enrolled in new affordable healthcare coverage through #kynect! http:\/\/t.co\/yKWvy78t1f",
    "id" : 395662748895698945,
    "created_at" : "2013-10-30 21:25:25 +0000",
    "user" : {
      "name" : "kynectky",
      "screen_name" : "kynectky",
      "protected" : false,
      "id_str" : "1336773938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796379675496947713\/anQEFeAp_normal.jpg",
      "id" : 1336773938,
      "verified" : false
    }
  },
  "id" : 395669620776271872,
  "created_at" : "2013-10-30 21:52:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/395664375224098816\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/6sctc86jeo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX2upygCYAEwPPO.jpg",
      "id_str" : "395664375232487425",
      "id" : 395664375232487425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX2upygCYAEwPPO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/6sctc86jeo"
    } ],
    "hashtags" : [ {
      "text" : "Progress",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/sdmyCcspIP",
      "expanded_url" : "http:\/\/go.wh.gov\/GVsFBL",
      "display_url" : "go.wh.gov\/GVsFBL"
    } ]
  },
  "geo" : { },
  "id_str" : "395664375224098816",
  "text" : "RT the good news: Since 2009, we've reduced the deficit by more than half \u2014&gt; http:\/\/t.co\/sdmyCcspIP #Progress, http:\/\/t.co\/6sctc86jeo",
  "id" : 395664375224098816,
  "created_at" : "2013-10-30 21:31:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395650156957151232",
  "text" : "President Obama: \"As a country, we can accomplish great things that we can't accomplish alone.\"",
  "id" : 395650156957151232,
  "created_at" : "2013-10-30 20:35:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395649219047849984",
  "text" : "Obama: \"This debate was never about right or left. It\u2019s about the helplessness a parent feels when she can\u2019t cover a sick child.\" #Obamacare",
  "id" : 395649219047849984,
  "created_at" : "2013-10-30 20:31:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395648933478670336",
  "text" : "Obama: \"If Republicans in Congress were as eager to help Americans #GetCovered as some GOP governors...we could make a lot more progress.\"",
  "id" : 395648933478670336,
  "created_at" : "2013-10-30 20:30:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395648539776139264",
  "text" : "Obama on helping people get health insurance: \"It's the right thing to do. It's worth it. And we're going to keep moving forward\" #Obamacare",
  "id" : 395648539776139264,
  "created_at" : "2013-10-30 20:28:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395647258747600896",
  "text" : "Obama: \"No insurance company will ever be able to deny you coverage or drop you as a customer altogether. Those days are over.\" #Obamacare",
  "id" : 395647258747600896,
  "created_at" : "2013-10-30 20:23:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395646853720449025",
  "text" : "President Obama: Insurance companies \"can\u2019t use allergies or pregnancy or the fact that you\u2019re a woman to charge you more.\" #Obamacare",
  "id" : 395646853720449025,
  "created_at" : "2013-10-30 20:22:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395646254148907008",
  "text" : "RT @WHLive: Obama: \"One of the things health care reform was designed to do was to help not only the uninsured, but the underinsured.\" #Oba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 123, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395646153359765504",
    "text" : "Obama: \"One of the things health care reform was designed to do was to help not only the uninsured, but the underinsured.\" #Obamacare",
    "id" : 395646153359765504,
    "created_at" : "2013-10-30 20:19:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 395646254148907008,
  "created_at" : "2013-10-30 20:19:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395645887889698816",
  "text" : "Obama: \"Oregon has covered 10% of its uninsured citizens already...Arkansas has covered almost 14% of its uninsured.\" #Obamacare",
  "id" : 395645887889698816,
  "created_at" : "2013-10-30 20:18:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/395645562428465152\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/UEYN40B4ee",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX2divDCUAAuBsG.jpg",
      "id_str" : "395645562348785664",
      "id" : 395645562348785664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX2divDCUAAuBsG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/UEYN40B4ee"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395645562428465152",
  "text" : "President Obama: \"Nearly 6 in 10 uninsured Americans may find coverage for $100\/month or less.\" #Obamacare, http:\/\/t.co\/UEYN40B4ee",
  "id" : 395645562428465152,
  "created_at" : "2013-10-30 20:17:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395645152401694720",
  "text" : "President Obama: \"Nearly half of all single, uninsured 18-34 year olds may be able to buy insurance for $50\/month or less.\" #Obamacare",
  "id" : 395645152401694720,
  "created_at" : "2013-10-30 20:15:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 108, 118 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "395644775178584064",
  "text" : "\"I take full responsibility for making sure it gets fixed ASAP.\" \u2014President Obama on http:\/\/t.co\/GNfbftrfo3 #Obamacare #GetCovered",
  "id" : 395644775178584064,
  "created_at" : "2013-10-30 20:13:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395644303784951808",
  "text" : "Obama: \"If you\u2019ve been sick, you finally have the same chance to buy quality, affordable health care as everyone else.\" #Obamacare",
  "id" : 395644303784951808,
  "created_at" : "2013-10-30 20:12:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395644183072886784",
  "text" : "President Obama: \"Young people can stay on their parents\u2019 plans until they turn 26.\" #Obamacare",
  "id" : 395644183072886784,
  "created_at" : "2013-10-30 20:11:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395643890339827712",
  "text" : "Obama: \"No more dropping your policy when you get sick and need it most. No more lifetime limits or restrictive annual limits.\" #Obamacare",
  "id" : 395643890339827712,
  "created_at" : "2013-10-30 20:10:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 84, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395643780763631616",
  "text" : "President Obama: \"No more discriminating against kids with preexisting conditions.\" #ThanksObamacare",
  "id" : 395643780763631616,
  "created_at" : "2013-10-30 20:10:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395643537124896768",
  "text" : "Obama in Boston: \"We built the Affordable Care Act on the template of this proven, bipartisan success. Your law was the model.\" #Obamacare",
  "id" : 395643537124896768,
  "created_at" : "2013-10-30 20:09:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395643302063509504",
  "text" : "Obama: \"Today, there is nearly universal coverage in Massachusetts, and the vast majority of its citizens are happy with their coverage.\"",
  "id" : 395643302063509504,
  "created_at" : "2013-10-30 20:08:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395643206135599104",
  "text" : "RT @WHLive: Obama: \"Health reform in this state was a success, but\u2026there were early problems to solve &amp; changes to make.\" #Obamacare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 114, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "395643139064463360",
    "text" : "Obama: \"Health reform in this state was a success, but\u2026there were early problems to solve &amp; changes to make.\" #Obamacare",
    "id" : 395643139064463360,
    "created_at" : "2013-10-30 20:07:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 395643206135599104,
  "created_at" : "2013-10-30 20:07:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395642684158668800",
  "text" : "Obama: \"Seven years ago, Democrats and Republicans came together to make health reform a reality for the people of Massachusetts.\"",
  "id" : 395642684158668800,
  "created_at" : "2013-10-30 20:05:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldSeries",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395642504063614976",
  "text" : "\"I tried to grow a beard, but Michelle, she wasn't having it.\" \u2014President Obama in Boston #WorldSeries",
  "id" : 395642504063614976,
  "created_at" : "2013-10-30 20:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 98, 108 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Dgsqcvaag6",
      "expanded_url" : "http:\/\/go.wh.gov\/7VRWna",
      "display_url" : "go.wh.gov\/7VRWna"
    } ]
  },
  "geo" : { },
  "id_str" : "395641474240372736",
  "text" : "Right now: President Obama speaks about health care in Boston. Watch \u2014&gt; http:\/\/t.co\/Dgsqcvaag6 #Obamacare #GetCovered",
  "id" : 395641474240372736,
  "created_at" : "2013-10-30 20:00:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/Wj5gNv2aXR",
      "expanded_url" : "http:\/\/go.wh.gov\/Bg922n",
      "display_url" : "go.wh.gov\/Bg922n"
    } ]
  },
  "geo" : { },
  "id_str" : "395629115664900096",
  "text" : "Don't miss President Obama's speech on health care at 4pm ET. Watch here \u2014&gt; http:\/\/t.co\/Wj5gNv2aXR #Obamacare",
  "id" : 395629115664900096,
  "created_at" : "2013-10-30 19:11:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/395617622764433408\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/SmRPVzh0hA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX2EIbbCQAAPnEd.jpg",
      "id_str" : "395617622613442560",
      "id" : 395617622613442560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX2EIbbCQAAPnEd.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SmRPVzh0hA"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 7, 17 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395617622764433408",
  "text" : "Before #Obamacare, Gregg couldn't afford health insurance.\n\nNow, he's covered for just $32\/month.\n\n#GetCovered, http:\/\/t.co\/SmRPVzh0hA",
  "id" : 395617622764433408,
  "created_at" : "2013-10-30 18:26:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/515RQx9Vft",
      "expanded_url" : "http:\/\/bit.ly\/18yMN1T",
      "display_url" : "bit.ly\/18yMN1T"
    } ]
  },
  "geo" : { },
  "id_str" : "395600993217282049",
  "text" : "\"My wife would not have insurance coverage at all as of Jan 1 if not for #Obamacare...we now are saving $8,000\/year.\" http:\/\/t.co\/515RQx9Vft",
  "id" : 395600993217282049,
  "created_at" : "2013-10-30 17:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 54, 64 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Hii0YvgwW9",
      "expanded_url" : "http:\/\/bit.ly\/19esbzn",
      "display_url" : "bit.ly\/19esbzn"
    } ]
  },
  "geo" : { },
  "id_str" : "395591249064759296",
  "text" : "Rikhi pays $950\/month to insure his family. Thanks to #Obamacare he can buy a similar plan for $400 less: http:\/\/t.co\/Hii0YvgwW9 #GetCovered",
  "id" : 395591249064759296,
  "created_at" : "2013-10-30 16:41:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/395580273955307520\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/5XaokQ574p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX1iKc3CAAE1XyJ.jpg",
      "id_str" : "395580273963696129",
      "id" : 395580273963696129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX1iKc3CAAE1XyJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/5XaokQ574p"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 75, 86 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395580273955307520",
  "text" : "Worth a RT: Half of single, uninsured young adults between 18 &amp; 34 can #GetCovered for $50\/month or less. #Obamacare http:\/\/t.co\/5XaokQ574p",
  "id" : 395580273955307520,
  "created_at" : "2013-10-30 15:57:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/x1supcMyeW",
      "expanded_url" : "http:\/\/bit.ly\/HseJz6",
      "display_url" : "bit.ly\/HseJz6"
    } ]
  },
  "geo" : { },
  "id_str" : "395567002997100547",
  "text" : "Great story: Thanks to #Obamacare, a Pittsburgh woman with diabetes cut her monthly premium by more than $500 \u2014&gt; http:\/\/t.co\/x1supcMyeW",
  "id" : 395567002997100547,
  "created_at" : "2013-10-30 15:04:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 97, 105 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/hoLOKgtb5G",
      "expanded_url" : "http:\/\/go.wh.gov\/wBXad1",
      "display_url" : "go.wh.gov\/wBXad1"
    } ]
  },
  "geo" : { },
  "id_str" : "395562500709560320",
  "text" : "Affordable health care is \"truly going to be accessible for people all throughout the country.\" \u2014@Simas44: http:\/\/t.co\/hoLOKgtb5G #Obamacare",
  "id" : 395562500709560320,
  "created_at" : "2013-10-30 14:47:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395546367655182337",
  "text" : "RT @Simas44: \"Turbo-charged hypocrisy.\" A good reminder of GOP's coordinated efforts to obstruct access to health care. http:\/\/t.co\/BBa9RSR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/BBa9RSRxko",
        "expanded_url" : "http:\/\/bit.ly\/1aohQE4",
        "display_url" : "bit.ly\/1aohQE4"
      } ]
    },
    "geo" : { },
    "id_str" : "395530677325541376",
    "text" : "\"Turbo-charged hypocrisy.\" A good reminder of GOP's coordinated efforts to obstruct access to health care. http:\/\/t.co\/BBa9RSRxko",
    "id" : 395530677325541376,
    "created_at" : "2013-10-30 12:40:36 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 395546367655182337,
  "created_at" : "2013-10-30 13:42:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 30, 42 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/395340934860140544\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/TUwoglZwVY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXyIfFPCcAAhoj8.jpg",
      "id_str" : "395340934864334848",
      "id" : 395340934864334848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXyIfFPCcAAhoj8.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/TUwoglZwVY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395340934860140544",
  "text" : "President Obama and President @BillClinton before the memorial service for former House Speaker Tom Foley: http:\/\/t.co\/TUwoglZwVY",
  "id" : 395340934860140544,
  "created_at" : "2013-10-30 00:06:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/395322071913222144\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/vfWpwLQuSk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXx3VHSCUAAzP-g.jpg",
      "id_str" : "395322071917416448",
      "id" : 395322071917416448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXx3VHSCUAAzP-g.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/vfWpwLQuSk"
    } ],
    "hashtags" : [ {
      "text" : "NationalBestFriendDay",
      "indices" : [ 9, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395322071913222144",
  "text" : "Besties. #NationalBestFriendDay, http:\/\/t.co\/vfWpwLQuSk",
  "id" : 395322071913222144,
  "created_at" : "2013-10-29 22:51:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/RBRba5Wt5j",
      "expanded_url" : "http:\/\/cnnmon.ie\/Ho4HyL",
      "display_url" : "cnnmon.ie\/Ho4HyL"
    } ]
  },
  "geo" : { },
  "id_str" : "395302389458014209",
  "text" : "Thanks to #Obamacare, Bryan's paying about $100\/month less for health coverage w\/ better benefits than he had before: http:\/\/t.co\/RBRba5Wt5j",
  "id" : 395302389458014209,
  "created_at" : "2013-10-29 21:33:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fusion",
      "screen_name" : "ThisIsFusion",
      "indices" : [ 19, 32 ],
      "id_str" : "726088145180217345",
      "id" : 726088145180217345
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/shNa9Mbesa",
      "expanded_url" : "http:\/\/fus.in\/1dFA1qi",
      "display_url" : "fus.in\/1dFA1qi"
    } ]
  },
  "geo" : { },
  "id_str" : "395297692277940224",
  "text" : "President Obama to @ThisIsFusion on how young Americans can #GetCovered for \"less than your cell phone bill\" \u2014&gt; http:\/\/t.co\/shNa9Mbesa",
  "id" : 395297692277940224,
  "created_at" : "2013-10-29 21:14:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "395281891038740480",
  "text" : "Watch live: President Obama speaks at a memorial service for former Speaker of the House Tom Foley \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 395281891038740480,
  "created_at" : "2013-10-29 20:12:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/f9KWDoMIPt",
      "expanded_url" : "http:\/\/bo.st\/15eA1sg",
      "display_url" : "bo.st\/15eA1sg"
    } ]
  },
  "geo" : { },
  "id_str" : "395280488245387264",
  "text" : "Thanks to #Obamacare, Deborah &amp; her husband will now pay about $550 less than before for a plan with better benefits: http:\/\/t.co\/f9KWDoMIPt",
  "id" : 395280488245387264,
  "created_at" : "2013-10-29 20:06:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395274333909553152",
  "text" : "RT @jesseclee44: \"My wife would not have insurance coverage at all as of Jan 1 if not for #Obamacare...we now are saving $8,000\/year.\" http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 73, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/VbZ59Am2bV",
        "expanded_url" : "http:\/\/bit.ly\/18yMN1T",
        "display_url" : "bit.ly\/18yMN1T"
      } ]
    },
    "geo" : { },
    "id_str" : "395274123615543296",
    "text" : "\"My wife would not have insurance coverage at all as of Jan 1 if not for #Obamacare...we now are saving $8,000\/year.\" http:\/\/t.co\/VbZ59Am2bV",
    "id" : 395274123615543296,
    "created_at" : "2013-10-29 19:41:09 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 395274333909553152,
  "created_at" : "2013-10-29 19:41:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/2LYitOmVgW",
      "expanded_url" : "http:\/\/bit.ly\/16UnB9T",
      "display_url" : "bit.ly\/16UnB9T"
    } ]
  },
  "geo" : { },
  "id_str" : "395267375261437952",
  "text" : "RT @Cecilia44: \"I enrolled in a plan that will save me more than $200\/month.\" \u2014Michelle from Nevada: http:\/\/t.co\/2LYitOmVgW #Obamacare #Get\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 109, 119 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 120, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/2LYitOmVgW",
        "expanded_url" : "http:\/\/bit.ly\/16UnB9T",
        "display_url" : "bit.ly\/16UnB9T"
      } ]
    },
    "geo" : { },
    "id_str" : "395260405158649856",
    "text" : "\"I enrolled in a plan that will save me more than $200\/month.\" \u2014Michelle from Nevada: http:\/\/t.co\/2LYitOmVgW #Obamacare #GetCovered",
    "id" : 395260405158649856,
    "created_at" : "2013-10-29 18:46:38 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 395267375261437952,
  "created_at" : "2013-10-29 19:14:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395263152323313664",
  "text" : "RT @Simas44: \"I\u2019m thrilled! To get something this good at that price?\u201D \u2014Daniel on paying $70\/month for health coverage: http:\/\/t.co\/EbuaIBQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/EbuaIBQyod",
        "expanded_url" : "http:\/\/bit.ly\/18YouMQ",
        "display_url" : "bit.ly\/18YouMQ"
      } ]
    },
    "geo" : { },
    "id_str" : "395261055082835968",
    "text" : "\"I\u2019m thrilled! To get something this good at that price?\u201D \u2014Daniel on paying $70\/month for health coverage: http:\/\/t.co\/EbuaIBQyod #Obamacare",
    "id" : 395261055082835968,
    "created_at" : "2013-10-29 18:49:13 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 395263152323313664,
  "created_at" : "2013-10-29 18:57:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/2au1XfaBgP",
      "expanded_url" : "http:\/\/lat.ms\/1g9CGcD",
      "display_url" : "lat.ms\/1g9CGcD"
    } ]
  },
  "geo" : { },
  "id_str" : "395260712177500160",
  "text" : "29-year-old substitute teacher couldn\u2019t afford health insurance since Jan 2012. Now he's paying $32\/month: http:\/\/t.co\/2au1XfaBgP #Obamacare",
  "id" : 395260712177500160,
  "created_at" : "2013-10-29 18:47:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 97, 105 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/byS8JaB1KN",
      "expanded_url" : "http:\/\/go.wh.gov\/Mj7guA",
      "display_url" : "go.wh.gov\/Mj7guA"
    } ]
  },
  "geo" : { },
  "id_str" : "395257592592605185",
  "text" : "\"Nearly 50% of young adults will be eligible for a plan under $50\/month\u2026that's an amazing rate\" \u2014@Simas44: http:\/\/t.co\/byS8JaB1KN #Obamacare",
  "id" : 395257592592605185,
  "created_at" : "2013-10-29 18:35:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/395211351926505472\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/sjqHyPpqhL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXwSoVcIgAMm6gY.jpg",
      "id_str" : "395211351460970499",
      "id" : 395211351460970499,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXwSoVcIgAMm6gY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/sjqHyPpqhL"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 67, 78 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395211351926505472",
  "text" : "FACT: Half of uninsured, single young adults between 18 and 35 can #GetCovered for $50\/month or less. #Obamacare, http:\/\/t.co\/sjqHyPpqhL",
  "id" : 395211351926505472,
  "created_at" : "2013-10-29 15:31:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/395202208410529793\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/SBUzS1nwYv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXwKUITCUAIqXXP.jpg",
      "id_str" : "395202208242749442",
      "id" : 395202208242749442,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXwKUITCUAIqXXP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/SBUzS1nwYv"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 71, 82 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395202208410529793",
  "text" : "Need affordable health coverage?\nBetween 18 and 35?\nYou may be able to #GetCovered for $50\/month or less.\n#Obamacare http:\/\/t.co\/SBUzS1nwYv",
  "id" : 395202208410529793,
  "created_at" : "2013-10-29 14:55:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/395185899618992128\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/M6qJyPacuZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXv7e1QIEAAT47p.png",
      "id_str" : "395185899434414080",
      "id" : 395185899434414080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXv7e1QIEAAT47p.png",
      "sizes" : [ {
        "h" : 548,
        "resize" : "fit",
        "w" : 687
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 271,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 687
      } ],
      "display_url" : "pic.twitter.com\/M6qJyPacuZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395185899618992128",
  "text" : "President Obama on the one-year anniversary of Hurricane Sandy \u2014&gt; http:\/\/t.co\/M6qJyPacuZ",
  "id" : 395185899618992128,
  "created_at" : "2013-10-29 13:50:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "395182445386944512",
  "text" : "\"Today, we remember our fellow Americans who lost their lives to that storm.\" \u2014President Obama on the anniversary of Hurricane Sandy",
  "id" : 395182445386944512,
  "created_at" : "2013-10-29 13:36:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394982066678280192",
  "text" : "FACT: Thanks to #Obamacare, insurance companies can't put annual limits on benefits or drop people's coverage when they get sick.",
  "id" : 394982066678280192,
  "created_at" : "2013-10-29 00:20:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394978292215726080",
  "text" : "FACT: Thanks to #Obamacare, women can't be charged more than men for the same health coverage.",
  "id" : 394978292215726080,
  "created_at" : "2013-10-29 00:05:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 132, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394973261949190144",
  "text" : "FACT: 43% of people with individual market insurance have a pre-existing condition &amp; can no longer be denied coverage thanks to #Obamacare.",
  "id" : 394973261949190144,
  "created_at" : "2013-10-28 23:45:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394970597823754242",
  "text" : "RT @Schultz44: Don't be foooled. Nothing in the ACA forces people out of their plans. No change is required unless ins companies change the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394963042212921344",
    "text" : "Don't be foooled. Nothing in the ACA forces people out of their plans. No change is required unless ins companies change their existing plan",
    "id" : 394963042212921344,
    "created_at" : "2013-10-28 23:05:01 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 394970597823754242,
  "created_at" : "2013-10-28 23:35:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/394950741103632384\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/jFl1Rt5jw8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXslm0QCYAAPzkm.jpg",
      "id_str" : "394950741116215296",
      "id" : 394950741116215296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXslm0QCYAAPzkm.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/jFl1Rt5jw8"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "PeaceOfMind",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394950741103632384",
  "text" : "Thanks to #Obamacare, millions of women can get mammograms at no extra cost. #PeaceOfMind, http:\/\/t.co\/jFl1Rt5jw8",
  "id" : 394950741103632384,
  "created_at" : "2013-10-28 22:16:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 109, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394931738331197440",
  "text" : "FACT: 2.8 million Americans on Medicare have saved an average of $834 on their prescription drugs this year. #ThanksObamacare",
  "id" : 394931738331197440,
  "created_at" : "2013-10-28 21:00:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/394923055652171776\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/8PLBYkLBmE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXsMbTgCQAA6ReB.jpg",
      "id_str" : "394923055555690496",
      "id" : 394923055555690496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXsMbTgCQAA6ReB.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8PLBYkLBmE"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394923055652171776",
  "text" : "Great news: More than 7.1 million Americans on Medicare have saved $8.3 billion on prescription drugs. #Obamacare, http:\/\/t.co\/8PLBYkLBmE",
  "id" : 394923055652171776,
  "created_at" : "2013-10-28 20:26:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/394904372418605056\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/eeG8EZXMSR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXr7bzcCcAA7tx0.jpg",
      "id_str" : "394904372431187968",
      "id" : 394904372431187968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXr7bzcCcAA7tx0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/eeG8EZXMSR"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 102, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394904372418605056",
  "text" : "1. Well-woman visits: $0.\n2. Cervical cancer screenings: $0.\n3. Birth control: $0.\n4. Mammograms: $0.\n#Obamacare, http:\/\/t.co\/eeG8EZXMSR",
  "id" : 394904372418605056,
  "created_at" : "2013-10-28 19:11:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394869131700215808",
  "text" : "RT @WHLive: \"I\u2019m absolutely confident that this agency will continue to flourish with Jim at the helm.\u201D \u2014President Obama on new FBI Directo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394867826776743936",
    "text" : "\"I\u2019m absolutely confident that this agency will continue to flourish with Jim at the helm.\u201D \u2014President Obama on new FBI Director James Comey",
    "id" : 394867826776743936,
    "created_at" : "2013-10-28 16:46:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 394869131700215808,
  "created_at" : "2013-10-28 16:51:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394866797024792578",
  "text" : "\"Our country asks and expects a lot from you, and we should make sure you have the resources you need to do the job.\" \u2014Obama at the FBI",
  "id" : 394866797024792578,
  "created_at" : "2013-10-28 16:42:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394865267433431040",
  "text" : "\"We\u2019re here to welcome a remarkable new leader for this remarkable institution...Mr. Jim Comey.\" \u2014President Obama on the new FBI Director",
  "id" : 394865267433431040,
  "created_at" : "2013-10-28 16:36:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394864970820644864",
  "text" : "President Obama: \"I am so proud to be here &amp; stand once again with so many dedicated men &amp; women of the FBI. You are the best of the best.\"",
  "id" : 394864970820644864,
  "created_at" : "2013-10-28 16:35:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "394864712849960960",
  "text" : "Right now: President Obama speaks at the installation of FBI Director James Comey. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 394864712849960960,
  "created_at" : "2013-10-28 16:34:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "394844689859223552",
  "text" : "At 12pm ET, President Obama speaks at the installation of FBI Director James Comey. Watch here \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 394844689859223552,
  "created_at" : "2013-10-28 15:14:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nobel",
      "indices" : [ 78, 84 ]
    }, {
      "text" : "STEM",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/X5govFaNZi",
      "expanded_url" : "http:\/\/wh.gov\/lWZvz",
      "display_url" : "wh.gov\/lWZvz"
    } ]
  },
  "geo" : { },
  "id_str" : "394837664643690496",
  "text" : "RT @whitehouseostp: Congrats to the extraordinary American scientists who won #Nobel Prizes this year --&gt; http:\/\/t.co\/X5govFaNZi #STEM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nobel",
        "indices" : [ 58, 64 ]
      }, {
        "text" : "STEM",
        "indices" : [ 112, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/X5govFaNZi",
        "expanded_url" : "http:\/\/wh.gov\/lWZvz",
        "display_url" : "wh.gov\/lWZvz"
      } ]
    },
    "geo" : { },
    "id_str" : "394833236041285632",
    "text" : "Congrats to the extraordinary American scientists who won #Nobel Prizes this year --&gt; http:\/\/t.co\/X5govFaNZi #STEM",
    "id" : 394833236041285632,
    "created_at" : "2013-10-28 14:29:13 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 394837664643690496,
  "created_at" : "2013-10-28 14:46:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "394831507447357440",
  "text" : "RT @AmbassadorRice: Religious freedom is central to who we are as Americans. On International Religious Freedom Day, we affirm this inheren\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "394595762652205056",
    "text" : "Religious freedom is central to who we are as Americans. On International Religious Freedom Day, we affirm this inherent right of all people",
    "id" : 394595762652205056,
    "created_at" : "2013-10-27 22:45:35 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 394831507447357440,
  "created_at" : "2013-10-28 14:22:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 46, 57 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 61, 71 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHInstaMeet",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/DJEgdBdrHN",
      "expanded_url" : "http:\/\/go.wh.gov\/42NsU3",
      "display_url" : "go.wh.gov\/42NsU3"
    } ]
  },
  "geo" : { },
  "id_str" : "394558283945504768",
  "text" : "Today, a few photo enthusiasts who follow the @WhiteHouse on @Instagram toured the grounds and gardens: http:\/\/t.co\/DJEgdBdrHN #WHInstaMeet",
  "id" : 394558283945504768,
  "created_at" : "2013-10-27 20:16:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/y0o6pfBVDf",
      "expanded_url" : "http:\/\/go.wh.gov\/t8zmhK",
      "display_url" : "go.wh.gov\/t8zmhK"
    } ]
  },
  "geo" : { },
  "id_str" : "394154101748932608",
  "text" : "Obama: \"The security of health care is not a privilege for a fortunate few\u2014but a right for every one of us to enjoy.\" http:\/\/t.co\/y0o6pfBVDf",
  "id" : 394154101748932608,
  "created_at" : "2013-10-26 17:30:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/QWzg97fOsq",
      "expanded_url" : "http:\/\/go.wh.gov\/2q2LSA",
      "display_url" : "go.wh.gov\/2q2LSA"
    } ]
  },
  "geo" : { },
  "id_str" : "394131449118339073",
  "text" : "Obama: \"I\u2019ll never stop fighting to help more hardworking Americans know the economic security of health care.\" http:\/\/t.co\/QWzg97fOsq",
  "id" : 394131449118339073,
  "created_at" : "2013-10-26 16:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 112, 122 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/no5D9C7sH9",
      "expanded_url" : "http:\/\/go.wh.gov\/eGo1Lb",
      "display_url" : "go.wh.gov\/eGo1Lb"
    } ]
  },
  "geo" : { },
  "id_str" : "394101250129543168",
  "text" : "President Obama's Weekly Address: Enrolling in the Affordable Care Act Marketplace \u2014&gt; http:\/\/t.co\/no5D9C7sH9 #Obamacare #GetCovered",
  "id" : 394101250129543168,
  "created_at" : "2013-10-26 14:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 3, 15 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    }, {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "indices" : [ 45, 55 ],
      "id_str" : "1099296103",
      "id" : 1099296103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SelectUSA",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393866447145152513",
  "text" : "RT @CommerceSec: President Obama to speak at @SelectUSA Summit! America is open for business. The time to invest is now! #SelectUSA http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SelectUSA",
        "screen_name" : "SelectUSA",
        "indices" : [ 28, 38 ],
        "id_str" : "1099296103",
        "id" : 1099296103
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SelectUSA",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ytMV8d9RUb",
        "expanded_url" : "http:\/\/www.commerce.gov\/news\/press-releases\/2013\/10\/25\/statement-us-commerce-secretary-penny-pritzker-first-ever-select-usa-",
        "display_url" : "commerce.gov\/news\/press-rel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "393852938910584832",
    "text" : "President Obama to speak at @SelectUSA Summit! America is open for business. The time to invest is now! #SelectUSA http:\/\/t.co\/ytMV8d9RUb",
    "id" : 393852938910584832,
    "created_at" : "2013-10-25 21:33:52 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 393866447145152513,
  "created_at" : "2013-10-25 22:27:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393835482846474240",
  "text" : "Obama: \"That\u2019s a message worth sending to Washington: No more games, no more gridlock, no more gutting the things that help America grow.\"",
  "id" : 393835482846474240,
  "created_at" : "2013-10-25 20:24:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393833702964211712",
  "text" : "Obama: \"Don\u2019t tell me we can afford to shut down the government and cost our economy billions...but we can\u2019t afford to invest in our kids.\"",
  "id" : 393833702964211712,
  "created_at" : "2013-10-25 20:17:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393833377452670976",
  "text" : "Obama on the budget: \"The question can\u2019t be how much more we can cut. It\u2019s got to be how many more schools like P-TECH we can create.\"",
  "id" : 393833377452670976,
  "created_at" : "2013-10-25 20:16:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393833015928815616",
  "text" : "Obama at P-Tech: \"I just sat in on a lesson called 'Real-World Math,' which got me thinking: Is it too late to send Congress here?\"",
  "id" : 393833015928815616,
  "created_at" : "2013-10-25 20:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393832056125276160",
  "text" : "Obama: \"We should give every child an earlier start at success by making high-quality Pre-K available to every 4-year-old in America.\"",
  "id" : 393832056125276160,
  "created_at" : "2013-10-25 20:10:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393831638267752448",
  "text" : "\"Here\u2019s how much two years of college will cost P-TECH students and their families: nothing. It\u2019s a ticket into the middle class.\" \u2014Obama",
  "id" : 393831638267752448,
  "created_at" : "2013-10-25 20:09:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 129, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393830397865246720",
  "text" : "Obama: \"We should be doing everything we can to keep families from falling into poverty &amp; build more ladders of opportunity\" #ABetterBargain",
  "id" : 393830397865246720,
  "created_at" : "2013-10-25 20:04:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393830077676265473",
  "text" : "President Obama in Brooklyn: \"We should be doing everything we can to keep you safe and protect you from gun violence.\"",
  "id" : 393830077676265473,
  "created_at" : "2013-10-25 20:03:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 107, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393829803318464513",
  "text" : "President Obama: \"We should be doing everything we can to put college within reach for more young people.\" #MakeCollegeAffordable",
  "id" : 393829803318464513,
  "created_at" : "2013-10-25 20:01:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393829639207940096",
  "text" : "RT @WHLive: \"This country should be doing everything we can to give more kids the chance to go to schools like this.\" \u2014Obama at P-TECH in B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393829617334636545",
    "text" : "\"This country should be doing everything we can to give more kids the chance to go to schools like this.\" \u2014Obama at P-TECH in Brooklyn",
    "id" : 393829617334636545,
    "created_at" : "2013-10-25 20:01:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 393829639207940096,
  "created_at" : "2013-10-25 20:01:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393829483506974720",
  "text" : "\"When I was living here, Brooklyn was cool, but not this cool.\" \u2014President Obama at P-TECH High School",
  "id" : 393829483506974720,
  "created_at" : "2013-10-25 20:00:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "393828314852257792",
  "text" : "Right now: President Obama speaks in Brooklyn about the next generation of middle-class American entrepreneurs \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 393828314852257792,
  "created_at" : "2013-10-25 19:56:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/393814455173120001\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/bYcNL8z83j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXccKRSCAAAUVrO.png",
      "id_str" : "393814455181508608",
      "id" : 393814455181508608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXccKRSCAAAUVrO.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bYcNL8z83j"
    } ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 25, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/5eu1uWzCHB",
      "expanded_url" : "http:\/\/go.wh.gov\/7Hcg2w",
      "display_url" : "go.wh.gov\/7Hcg2w"
    } ]
  },
  "geo" : { },
  "id_str" : "393814455173120001",
  "text" : "Want more of this? Watch #WestWingWeek \u2014&gt; http:\/\/t.co\/5eu1uWzCHB, http:\/\/t.co\/bYcNL8z83j",
  "id" : 393814455173120001,
  "created_at" : "2013-10-25 19:00:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/SGAjS6mpxr",
      "expanded_url" : "http:\/\/go.wh.gov\/7jFgxa",
      "display_url" : "go.wh.gov\/7jFgxa"
    } ]
  },
  "geo" : { },
  "id_str" : "393799255317417984",
  "text" : "4 ways you can #GetCovered:\n1. http:\/\/t.co\/GNfbftrfo3\n2. Call 1-800-318-2596\n3. Mail a paper app\n4. Apply in person\nhttp:\/\/t.co\/SGAjS6mpxr",
  "id" : 393799255317417984,
  "created_at" : "2013-10-25 18:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/393792127035256832\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/6S7f4SjeRk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXcH2l6IMAAdVI1.jpg",
      "id_str" : "393792126888456192",
      "id" : 393792126888456192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXcH2l6IMAAdVI1.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/6S7f4SjeRk"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393792127035256832",
  "text" : "RT if you agree: It's time to focus on helping millions of uninsured Americans afford health insurance. #Obamacare, http:\/\/t.co\/6S7f4SjeRk",
  "id" : 393792127035256832,
  "created_at" : "2013-10-25 17:32:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/393784834612797440\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/pzqysei8qs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXcBOHiIgAApOrk.jpg",
      "id_str" : "393784834470215680",
      "id" : 393784834470215680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXcBOHiIgAApOrk.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/pzqysei8qs"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393784834612797440",
  "text" : "FACT: Nearly 6 in 10 uninsured Americans can now sign up for health coverage for less than $100\/month. #Obamacare, http:\/\/t.co\/pzqysei8qs",
  "id" : 393784834612797440,
  "created_at" : "2013-10-25 17:03:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 123, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/xrTTzRISqU",
      "expanded_url" : "http:\/\/go.wh.gov\/Vkxi3x",
      "display_url" : "go.wh.gov\/Vkxi3x"
    } ]
  },
  "geo" : { },
  "id_str" : "393776604872052737",
  "text" : "For millions of breast cancer survivors like Carol, mammograms at no extra cost can be life-saving: http:\/\/t.co\/xrTTzRISqU #ThanksObamacare",
  "id" : 393776604872052737,
  "created_at" : "2013-10-25 16:30:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Mf5SdaBzd9",
      "expanded_url" : "http:\/\/go.wh.gov\/9NVJx8",
      "display_url" : "go.wh.gov\/9NVJx8"
    } ]
  },
  "geo" : { },
  "id_str" : "393768460456443904",
  "text" : "Thanks to #Obamacare, Jennifer\u2014and millions of Americans\u2014no longer have lifetime limits on their health coverage: http:\/\/t.co\/Mf5SdaBzd9",
  "id" : 393768460456443904,
  "created_at" : "2013-10-25 15:58:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/393762709960790016\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/VSdyORROdw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXbtGTVCEAABC_Q.jpg",
      "id_str" : "393762709964984320",
      "id" : 393762709964984320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXbtGTVCEAABC_Q.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/VSdyORROdw"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/6TQtqK8cY7",
      "expanded_url" : "http:\/\/go.wh.gov\/dnVkSQ",
      "display_url" : "go.wh.gov\/dnVkSQ"
    } ]
  },
  "geo" : { },
  "id_str" : "393762709960790016",
  "text" : "FACT: Thanks to #Obamacare, birth control is covered with no co-pays or out-of-pocket costs: http:\/\/t.co\/6TQtqK8cY7, http:\/\/t.co\/VSdyORROdw",
  "id" : 393762709960790016,
  "created_at" : "2013-10-25 15:35:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 17, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393753968062377985",
  "text" : "FACT: The Senate #ImmigrationReform bill would grow our economy by $1.4 trillion and cut the deficit by nearly $1 trillion over two decades.",
  "id" : 393753968062377985,
  "created_at" : "2013-10-25 15:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 32, 50 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/Bb3472YVjs",
      "expanded_url" : "http:\/\/go.wh.gov\/zu81kT",
      "display_url" : "go.wh.gov\/zu81kT"
    } ]
  },
  "geo" : { },
  "id_str" : "393745926335918080",
  "text" : "President Obama: We should pass #ImmigrationReform, and we should do it this year \u2014&gt; http:\/\/t.co\/Bb3472YVjs #JustVote",
  "id" : 393745926335918080,
  "created_at" : "2013-10-25 14:28:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 25, 36 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreastCancerAwareness",
      "indices" : [ 61, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393548130689376256",
  "text" : "RT @FLOTUS: Tonight, the @WhiteHouse is lit pink in honor of #BreastCancerAwareness Month and the millions of families impacted. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 13, 24 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/393546559649890305\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/UN4zVBt6h7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXYogsFCYAElIDp.jpg",
        "id_str" : "393546559494709249",
        "id" : 393546559494709249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXYogsFCYAElIDp.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 718,
          "resize" : "fit",
          "w" : 1076
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/UN4zVBt6h7"
      } ],
      "hashtags" : [ {
        "text" : "BreastCancerAwareness",
        "indices" : [ 49, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393546559649890305",
    "text" : "Tonight, the @WhiteHouse is lit pink in honor of #BreastCancerAwareness Month and the millions of families impacted. http:\/\/t.co\/UN4zVBt6h7",
    "id" : 393546559649890305,
    "created_at" : "2013-10-25 01:16:26 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 393548130689376256,
  "created_at" : "2013-10-25 01:22:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Odsraq5Fa7",
      "expanded_url" : "http:\/\/go.wh.gov\/j96dPS",
      "display_url" : "go.wh.gov\/j96dPS"
    } ]
  },
  "geo" : { },
  "id_str" : "393519811549855744",
  "text" : "Obama: \"If there\u2019s a good reason not to pass this commonsense reform, I haven\u2019t heard it.\" http:\/\/t.co\/Odsraq5Fa7 #ImmigrationReform",
  "id" : 393519811549855744,
  "created_at" : "2013-10-24 23:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 114, 119 ],
      "id_str" : "61853389",
      "id" : 61853389
    }, {
      "name" : "40 Chances",
      "screen_name" : "40Chances",
      "indices" : [ 120, 130 ],
      "id_str" : "464234807",
      "id" : 464234807
    }, {
      "name" : "Agricultural Prize",
      "screen_name" : "Ag_Prize",
      "indices" : [ 131, 140 ],
      "id_str" : "1702834758",
      "id" : 1702834758
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ag",
      "indices" : [ 51, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/G6SqJznCr9",
      "expanded_url" : "http:\/\/wh.gov\/lDvQr",
      "display_url" : "wh.gov\/lDvQr"
    } ]
  },
  "geo" : { },
  "id_str" : "393513251591700480",
  "text" : "RT @whitehouseostp: Growing the Next Generation of #Ag Innovators and Entrepreneurs --&gt; http:\/\/t.co\/G6SqJznCr9 @USDA @40Chances @Ag_Prize",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dept. of Agriculture",
        "screen_name" : "USDA",
        "indices" : [ 94, 99 ],
        "id_str" : "61853389",
        "id" : 61853389
      }, {
        "name" : "40 Chances",
        "screen_name" : "40Chances",
        "indices" : [ 100, 110 ],
        "id_str" : "464234807",
        "id" : 464234807
      }, {
        "name" : "Agricultural Prize",
        "screen_name" : "Ag_Prize",
        "indices" : [ 111, 120 ],
        "id_str" : "1702834758",
        "id" : 1702834758
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ag",
        "indices" : [ 31, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/G6SqJznCr9",
        "expanded_url" : "http:\/\/wh.gov\/lDvQr",
        "display_url" : "wh.gov\/lDvQr"
      } ]
    },
    "geo" : { },
    "id_str" : "392995959296122880",
    "text" : "Growing the Next Generation of #Ag Innovators and Entrepreneurs --&gt; http:\/\/t.co\/G6SqJznCr9 @USDA @40Chances @Ag_Prize",
    "id" : 392995959296122880,
    "created_at" : "2013-10-23 12:48:32 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 393513251591700480,
  "created_at" : "2013-10-24 23:04:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/393479685184962560\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/kq0X1RlJMM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXXrsE_IcAAUNuD.jpg",
      "id_str" : "393479684950093824",
      "id" : 393479684950093824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXXrsE_IcAAUNuD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/kq0X1RlJMM"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393479685184962560",
  "text" : "Well-woman visits, birth control &amp; mammograms: All covered with no additional costs or co-pays thanks to #Obamacare. http:\/\/t.co\/kq0X1RlJMM",
  "id" : 393479685184962560,
  "created_at" : "2013-10-24 20:50:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/393470378867032064\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/lctqmFNSny",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXXjOZJCAAAcTPx.jpg",
      "id_str" : "393470378871226368",
      "id" : 393470378871226368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXXjOZJCAAAcTPx.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/lctqmFNSny"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/vZO59xFLev",
      "expanded_url" : "http:\/\/go.wh.gov\/KJSbNQ",
      "display_url" : "go.wh.gov\/KJSbNQ"
    } ]
  },
  "geo" : { },
  "id_str" : "393470378867032064",
  "text" : "Thanks to #Obamacare, mammograms are covered at no additional cost \u2014&gt; http:\/\/t.co\/vZO59xFLev #GetCovered, http:\/\/t.co\/lctqmFNSny",
  "id" : 393470378867032064,
  "created_at" : "2013-10-24 20:13:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/393405829841301505\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/AnVGue3tLM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXWohJSCMAAdz6B.jpg",
      "id_str" : "393405829845495808",
      "id" : 393405829845495808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXWohJSCMAAdz6B.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/AnVGue3tLM"
    } ],
    "hashtags" : [ {
      "text" : "BreastCancerAwareness",
      "indices" : [ 86, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393465138721742848",
  "text" : "RT @vj44: RT if you believe access to affordable &amp; quality healthcare saves lives #BreastCancerAwareness, http:\/\/t.co\/AnVGue3tLM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/393405829841301505\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/AnVGue3tLM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXWohJSCMAAdz6B.jpg",
        "id_str" : "393405829845495808",
        "id" : 393405829845495808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXWohJSCMAAdz6B.jpg",
        "sizes" : [ {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/AnVGue3tLM"
      } ],
      "hashtags" : [ {
        "text" : "BreastCancerAwareness",
        "indices" : [ 76, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393412946358837248",
    "text" : "RT if you believe access to affordable &amp; quality healthcare saves lives #BreastCancerAwareness, http:\/\/t.co\/AnVGue3tLM",
    "id" : 393412946358837248,
    "created_at" : "2013-10-24 16:25:30 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 393465138721742848,
  "created_at" : "2013-10-24 19:52:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/393444374446485504\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/2wH4wyYiOa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXXLkvKCMAAilPT.jpg",
      "id_str" : "393444374459068416",
      "id" : 393444374459068416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXXLkvKCMAAilPT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/2wH4wyYiOa"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393444374446485504",
  "text" : "Mammograms: $0. Birth control: $0. Preventive care you need to stay healthy at no extra cost: Priceless. #Obamacare, http:\/\/t.co\/2wH4wyYiOa",
  "id" : 393444374446485504,
  "created_at" : "2013-10-24 18:30:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 3, 15 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AffordableCareAct",
      "indices" : [ 45, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/9cRu7zoz8W",
      "expanded_url" : "http:\/\/wjcf.co\/17M2Cmr",
      "display_url" : "wjcf.co\/17M2Cmr"
    } ]
  },
  "geo" : { },
  "id_str" : "393441243814182912",
  "text" : "RT @billclinton: A new report shows that the #AffordableCareAct will save $190B over the next 10 years: http:\/\/t.co\/9cRu7zoz8W",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AffordableCareAct",
        "indices" : [ 28, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/9cRu7zoz8W",
        "expanded_url" : "http:\/\/wjcf.co\/17M2Cmr",
        "display_url" : "wjcf.co\/17M2Cmr"
      } ]
    },
    "geo" : { },
    "id_str" : "393405963778011136",
    "text" : "A new report shows that the #AffordableCareAct will save $190B over the next 10 years: http:\/\/t.co\/9cRu7zoz8W",
    "id" : 393405963778011136,
    "created_at" : "2013-10-24 15:57:45 +0000",
    "user" : {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "protected" : false,
      "id_str" : "1330457336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451207149478096896\/HoMUOmyu_normal.jpeg",
      "id" : 1330457336,
      "verified" : true
    }
  },
  "id" : 393441243814182912,
  "created_at" : "2013-10-24 18:17:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Woman's Day",
      "screen_name" : "WomansDay",
      "indices" : [ 3, 13 ],
      "id_str" : "25103000",
      "id" : 25103000
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 55, 60 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 61, 72 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BCA",
      "indices" : [ 43, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/IDnCy9tyVj",
      "expanded_url" : "http:\/\/www.womansday.com\/health-fitness\/daily-dose\/white-house-breast-cancer-awareness",
      "display_url" : "womansday.com\/health-fitness\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "393425936500420609",
  "text" : "RT @WomansDay: We're honored to share your #BCA story, @vj44 @WhiteHouse http:\/\/t.co\/IDnCy9tyVj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 40, 45 ],
        "id_str" : "595515713",
        "id" : 595515713
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 46, 57 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BCA",
        "indices" : [ 28, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/IDnCy9tyVj",
        "expanded_url" : "http:\/\/www.womansday.com\/health-fitness\/daily-dose\/white-house-breast-cancer-awareness",
        "display_url" : "womansday.com\/health-fitness\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "393379142479011842",
    "geo" : { },
    "id_str" : "393391302751961088",
    "in_reply_to_user_id" : 595515713,
    "text" : "We're honored to share your #BCA story, @vj44 @WhiteHouse http:\/\/t.co\/IDnCy9tyVj",
    "id" : 393391302751961088,
    "in_reply_to_status_id" : 393379142479011842,
    "created_at" : "2013-10-24 14:59:30 +0000",
    "in_reply_to_screen_name" : "vj44",
    "in_reply_to_user_id_str" : "595515713",
    "user" : {
      "name" : "Woman's Day",
      "screen_name" : "WomansDay",
      "protected" : false,
      "id_str" : "25103000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659002902774751232\/I8nXxLOR_normal.jpg",
      "id" : 25103000,
      "verified" : true
    }
  },
  "id" : 393425936500420609,
  "created_at" : "2013-10-24 17:17:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 98, 103 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/rIDLNhNItN",
      "expanded_url" : "http:\/\/go.wh.gov\/YQjYN2",
      "display_url" : "go.wh.gov\/YQjYN2"
    } ]
  },
  "geo" : { },
  "id_str" : "393417885248262145",
  "text" : "\"My mother is a breast cancer survivor and...access to high quality health care saved her life.\" \u2014@VJ44: http:\/\/t.co\/rIDLNhNItN #Obamacare",
  "id" : 393417885248262145,
  "created_at" : "2013-10-24 16:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 11, 22 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreastCancerAwareness",
      "indices" : [ 60, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/JCbYR5AglZ",
      "expanded_url" : "http:\/\/ow.ly\/q8jya",
      "display_url" : "ow.ly\/q8jya"
    } ]
  },
  "geo" : { },
  "id_str" : "393413137992404993",
  "text" : "RT @vj44: .@Whitehouse will be illuminated pink tonight for #BreastCancerAwareness month! \u2014 read more http:\/\/t.co\/JCbYR5AglZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BreastCancerAwareness",
        "indices" : [ 50, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/JCbYR5AglZ",
        "expanded_url" : "http:\/\/ow.ly\/q8jya",
        "display_url" : "ow.ly\/q8jya"
      } ]
    },
    "geo" : { },
    "id_str" : "393379142479011842",
    "text" : ".@Whitehouse will be illuminated pink tonight for #BreastCancerAwareness month! \u2014 read more http:\/\/t.co\/JCbYR5AglZ",
    "id" : 393379142479011842,
    "created_at" : "2013-10-24 14:11:10 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 393413137992404993,
  "created_at" : "2013-10-24 16:26:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/393405829841301505\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/YOA8ly20yn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXWohJSCMAAdz6B.jpg",
      "id_str" : "393405829845495808",
      "id" : 393405829845495808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXWohJSCMAAdz6B.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/YOA8ly20yn"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 33, 43 ]
    }, {
      "text" : "BreastCancerAwareness",
      "indices" : [ 86, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393405829841301505",
  "text" : "RT to spread the word: Thanks to #Obamacare, mammograms are covered at no extra cost. #BreastCancerAwareness, http:\/\/t.co\/YOA8ly20yn",
  "id" : 393405829841301505,
  "created_at" : "2013-10-24 15:57:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 103, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393391671271882752",
  "text" : "\"It is time. Let's go get it done!\" \u2014President Obama on fixing our broken immigration system this year #ImmigrationReform",
  "id" : 393391671271882752,
  "created_at" : "2013-10-24 15:00:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 84, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393390808704897024",
  "text" : "\"What we can't do is sweep this problem under the rug.\" \u2014President Obama on passing #ImmigrationReform this year",
  "id" : 393390808704897024,
  "created_at" : "2013-10-24 14:57:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 34, 52 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393390002857467904",
  "text" : "\"The Senate has already passed an #ImmigrationReform bill by a wide, bipartisan majority.\" \u2014Obama on why the House should #JustVote",
  "id" : 393390002857467904,
  "created_at" : "2013-10-24 14:54:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 111, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393389217994113024",
  "text" : "\"It's good for our economy, good for our national security...and we should do it this year.\" \u2014Obama on passing #ImmigrationReform",
  "id" : 393389217994113024,
  "created_at" : "2013-10-24 14:51:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 91, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393388947729965056",
  "text" : "\"This is a moment when we should be able to get the job done.\" \u2014President Obama on passing #ImmigrationReform",
  "id" : 393388947729965056,
  "created_at" : "2013-10-24 14:50:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "393388425442652160",
  "text" : "Right now: President Obama speaks on why it's time to fix our broken immigration system. Watch: http:\/\/t.co\/KvadYk9atb #ImmigrationReform",
  "id" : 393388425442652160,
  "created_at" : "2013-10-24 14:48:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 34, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "393375627165700096",
  "text" : "RT if you agree it's time to pass #ImmigrationReform\u2014then tune in for President Obama's speech at 10:35am ET: http:\/\/t.co\/KvadYk9atb",
  "id" : 393375627165700096,
  "created_at" : "2013-10-24 13:57:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "autumn",
      "indices" : [ 43, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393125583766683648",
  "text" : "RT @Interior: Looking 4 a photo that shows #autumn in America's great outdoors? This Rocky Mountain NP pic is the perfect choice. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/393122654330585088\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Ooyr9tNgjB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXSm-JhIQAAxSY8.jpg",
        "id_str" : "393122654125047808",
        "id" : 393122654125047808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXSm-JhIQAAxSY8.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Ooyr9tNgjB"
      } ],
      "hashtags" : [ {
        "text" : "autumn",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393122654330585088",
    "text" : "Looking 4 a photo that shows #autumn in America's great outdoors? This Rocky Mountain NP pic is the perfect choice. http:\/\/t.co\/Ooyr9tNgjB",
    "id" : 393122654330585088,
    "created_at" : "2013-10-23 21:11:59 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 393125583766683648,
  "created_at" : "2013-10-23 21:23:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/wAnfkg1qtx",
      "expanded_url" : "http:\/\/go.wh.gov\/Ew2fC1",
      "display_url" : "go.wh.gov\/Ew2fC1"
    } ]
  },
  "geo" : { },
  "id_str" : "393085690994360320",
  "text" : "Janice's new policy \"contains so many more preventive health care measures than what [she] had before.\" http:\/\/t.co\/wAnfkg1qtx #Obamacare",
  "id" : 393085690994360320,
  "created_at" : "2013-10-23 18:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 85, 95 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/QP6LVRbOYQ",
      "expanded_url" : "http:\/\/go.wh.gov\/tW1drk",
      "display_url" : "go.wh.gov\/tW1drk"
    } ]
  },
  "geo" : { },
  "id_str" : "393079397168603137",
  "text" : "\"Cobra was $600, and now an equivalent plan of what I had is $350.\" \u2014David, who used #Obamacare to #GetCovered: http:\/\/t.co\/QP6LVRbOYQ",
  "id" : 393079397168603137,
  "created_at" : "2013-10-23 18:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/2ACX3Qfobu",
      "expanded_url" : "http:\/\/go.wh.gov\/diSjRN",
      "display_url" : "go.wh.gov\/diSjRN"
    } ]
  },
  "geo" : { },
  "id_str" : "393073719016304640",
  "text" : "Watch what people around the country are saying about signing up for affordable health coverage through #Obamacare \u2014&gt; http:\/\/t.co\/2ACX3Qfobu",
  "id" : 393073719016304640,
  "created_at" : "2013-10-23 17:57:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/393060416965709824\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/7OV4RXoXdu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXRuXdWCQAAOSDa.jpg",
      "id_str" : "393060416781172736",
      "id" : 393060416781172736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXRuXdWCQAAOSDa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/7OV4RXoXdu"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393060416965709824",
  "text" : "Thanks to #Obamacare, nearly 6 in 10 uninsured Americans will have access to health coverage for $100\/month or less. http:\/\/t.co\/7OV4RXoXdu",
  "id" : 393060416965709824,
  "created_at" : "2013-10-23 17:04:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "393008895360110592",
  "text" : "RT @NSCPress: We remember &amp; honor the 220 Marines, 18 sailors, 3 soldiers who lost their lives 30 years ago today in Beirut. http:\/\/t.co\/qe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/392997819625115649\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/qecb3JR6ud",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXQ1b0zCEAAEhQD.jpg",
        "id_str" : "392997819633504256",
        "id" : 392997819633504256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXQ1b0zCEAAEhQD.jpg",
        "sizes" : [ {
          "h" : 550,
          "resize" : "fit",
          "w" : 1243
        }, {
          "h" : 150,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 265,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/qecb3JR6ud"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392997819625115649",
    "text" : "We remember &amp; honor the 220 Marines, 18 sailors, 3 soldiers who lost their lives 30 years ago today in Beirut. http:\/\/t.co\/qecb3JR6ud",
    "id" : 392997819625115649,
    "created_at" : "2013-10-23 12:55:56 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 393008895360110592,
  "created_at" : "2013-10-23 13:39:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/392803347499331584\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/zxgnwsMdRJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXOEkCUIUAAsZaC.jpg",
      "id_str" : "392803347142823936",
      "id" : 392803347142823936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXOEkCUIUAAsZaC.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zxgnwsMdRJ"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 93, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392803347499331584",
  "text" : "RT if you're rooting for hardworking, uninsured Americans to get affordable health coverage. #GetCovered, http:\/\/t.co\/zxgnwsMdRJ",
  "id" : 392803347499331584,
  "created_at" : "2013-10-23 00:03:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/taGCtC9E0s",
      "expanded_url" : "http:\/\/go.wh.gov\/5GRdVx",
      "display_url" : "go.wh.gov\/5GRdVx"
    } ]
  },
  "geo" : { },
  "id_str" : "392787473996075009",
  "text" : "Watch how #Obamacare benefits you and your family, whether you already have health insurance or not \u2014&gt; http:\/\/t.co\/taGCtC9E0s #GetCovered",
  "id" : 392787473996075009,
  "created_at" : "2013-10-22 23:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/392777661120249856\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/bqm394yIrH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXNtM5xIUAAAqn0.jpg",
      "id_str" : "392777660944109568",
      "id" : 392777660944109568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXNtM5xIUAAAqn0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/bqm394yIrH"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 67, 77 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 78, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392777661120249856",
  "text" : "Every American deserves access to affordable, quality health care. #Obamacare #GetCovered, http:\/\/t.co\/bqm394yIrH",
  "id" : 392777661120249856,
  "created_at" : "2013-10-22 22:21:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392770543826788352",
  "text" : "RT @CEABetsey: \"The government shutdown and debt limit brinksmanship have had a substantial negative impact on the economy.\"\nhttp:\/\/t.co\/pD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/pDDosSqj2o",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/10\/22\/economic-activity-during-government-shutdown-and-debt-limit-brinksmanship",
        "display_url" : "whitehouse.gov\/blog\/2013\/10\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392767449688322048",
    "text" : "\"The government shutdown and debt limit brinksmanship have had a substantial negative impact on the economy.\"\nhttp:\/\/t.co\/pDDosSqj2o",
    "id" : 392767449688322048,
    "created_at" : "2013-10-22 21:40:31 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 392770543826788352,
  "created_at" : "2013-10-22 21:52:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/dL6FbzhjcY",
      "expanded_url" : "http:\/\/go.wh.gov\/q9dfxk",
      "display_url" : "go.wh.gov\/q9dfxk"
    } ]
  },
  "geo" : { },
  "id_str" : "392746321330720768",
  "text" : "Worth sharing: If you need affordable health insurance, here are 4 easy ways you can #GetCovered \u2014&gt; http:\/\/t.co\/dL6FbzhjcY #Obamacare",
  "id" : 392746321330720768,
  "created_at" : "2013-10-22 20:16:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viagra n tayac. Dagr",
      "screen_name" : "DagVega44",
      "indices" : [ 3, 13 ],
      "id_str" : "2785789802",
      "id" : 2785789802
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 100, 111 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "betterlatethannever",
      "indices" : [ 113, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392743454322987009",
  "text" : "RT @DagVega44: Hello Twitterverse! Looking fwd to tweeting about TV news and surrogates here at the @WhiteHouse. #betterlatethannever",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 85, 96 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "betterlatethannever",
        "indices" : [ 98, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392721668482666496",
    "text" : "Hello Twitterverse! Looking fwd to tweeting about TV news and surrogates here at the @WhiteHouse. #betterlatethannever",
    "id" : 392721668482666496,
    "created_at" : "2013-10-22 18:38:36 +0000",
    "user" : {
      "name" : "Rob O'Donnell",
      "screen_name" : "RODonnell44",
      "protected" : false,
      "id_str" : "1873091689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664483086738952192\/UukL2zFT_normal.jpg",
      "id" : 1873091689,
      "verified" : true
    }
  },
  "id" : 392743454322987009,
  "created_at" : "2013-10-22 20:05:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 3, 13 ],
      "id_str" : "180505807",
      "id" : 180505807
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 36, 47 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 62, 72 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/fSCVxEkEFt",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/10\/21\/youre-invited-join-white-house-fall-garden-instagram-meetup",
      "display_url" : "whitehouse.gov\/blog\/2013\/10\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392728681820721152",
  "text" : "RT @instagram: On Sunday, 10\/27 the @WhiteHouse is hosting an @Instagram meetup! Learn more here: http:\/\/t.co\/fSCVxEkEFt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 21, 32 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Instagram",
        "screen_name" : "instagram",
        "indices" : [ 47, 57 ],
        "id_str" : "180505807",
        "id" : 180505807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/fSCVxEkEFt",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/10\/21\/youre-invited-join-white-house-fall-garden-instagram-meetup",
        "display_url" : "whitehouse.gov\/blog\/2013\/10\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392678344698757121",
    "text" : "On Sunday, 10\/27 the @WhiteHouse is hosting an @Instagram meetup! Learn more here: http:\/\/t.co\/fSCVxEkEFt",
    "id" : 392678344698757121,
    "created_at" : "2013-10-22 15:46:27 +0000",
    "user" : {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "protected" : false,
      "id_str" : "180505807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786681705981673472\/T5OKNZ1-_normal.jpg",
      "id" : 180505807,
      "verified" : true
    }
  },
  "id" : 392728681820721152,
  "created_at" : "2013-10-22 19:06:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KYdtJ6ptpG",
      "expanded_url" : "http:\/\/bit.ly\/1eFbjE7",
      "display_url" : "bit.ly\/1eFbjE7"
    } ]
  },
  "geo" : { },
  "id_str" : "392722098260422657",
  "text" : "Great news: More than 35,000 Washington state residents have already enrolled in health coverage through #Obamacare. http:\/\/t.co\/KYdtJ6ptpG",
  "id" : 392722098260422657,
  "created_at" : "2013-10-22 18:40:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/kDGniOjjml",
      "expanded_url" : "http:\/\/go.wh.gov\/6326u9",
      "display_url" : "go.wh.gov\/6326u9"
    } ]
  },
  "geo" : { },
  "id_str" : "392717004144005120",
  "text" : "The unemployment rate fell to 7.2%, the lowest since November 2008, but there's more work to do: http:\/\/t.co\/kDGniOjjml",
  "id" : 392717004144005120,
  "created_at" : "2013-10-22 18:20:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/392706405423013888\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/d9KEGasAWb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXMsZSTCYAANo19.jpg",
      "id_str" : "392706405431402496",
      "id" : 392706405431402496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXMsZSTCYAANo19.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/d9KEGasAWb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/DbljaVSafr",
      "expanded_url" : "http:\/\/go.wh.gov\/qVg5Qa",
      "display_url" : "go.wh.gov\/qVg5Qa"
    } ]
  },
  "geo" : { },
  "id_str" : "392706405423013888",
  "text" : "RT the news: Our economy has added 7.6 million private-sector jobs over 43 straight months. http:\/\/t.co\/DbljaVSafr, http:\/\/t.co\/d9KEGasAWb",
  "id" : 392706405423013888,
  "created_at" : "2013-10-22 17:37:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 5, 14 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 140, 147 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392675204381433856",
  "text" : "Join @CEAChair and @CEABetsey at 12pm ET for a Twitter Q&amp;A on jobs, the economy &amp; impacts of the shutdown. Ask your questions using #WHChat.",
  "id" : 392675204381433856,
  "created_at" : "2013-10-22 15:33:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/392657661419737088\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ge8a2azMQK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXMAEAvCUAA6vE5.jpg",
      "id_str" : "392657661428125696",
      "id" : 392657661428125696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXMAEAvCUAA6vE5.jpg",
      "sizes" : [ {
        "h" : 660,
        "resize" : "fit",
        "w" : 911
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 246,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 911
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ge8a2azMQK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/7LtRyOIvy9",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/10\/22\/employment-situation-september",
      "display_url" : "whitehouse.gov\/blog\/2013\/10\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "392670050202976256",
  "text" : "RT @CEAChair: Today we learned businesses added 7.6 million jobs over past 43 months. More at http:\/\/t.co\/7LtRyOIvy9 http:\/\/t.co\/ge8a2azMQK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/392657661419737088\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/ge8a2azMQK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXMAEAvCUAA6vE5.jpg",
        "id_str" : "392657661428125696",
        "id" : 392657661428125696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXMAEAvCUAA6vE5.jpg",
        "sizes" : [ {
          "h" : 660,
          "resize" : "fit",
          "w" : 911
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 911
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ge8a2azMQK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/7LtRyOIvy9",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/10\/22\/employment-situation-september",
        "display_url" : "whitehouse.gov\/blog\/2013\/10\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392657661419737088",
    "text" : "Today we learned businesses added 7.6 million jobs over past 43 months. More at http:\/\/t.co\/7LtRyOIvy9 http:\/\/t.co\/ge8a2azMQK",
    "id" : 392657661419737088,
    "created_at" : "2013-10-22 14:24:16 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 392670050202976256,
  "created_at" : "2013-10-22 15:13:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Maley",
      "screen_name" : "Maley44",
      "indices" : [ 3, 11 ],
      "id_str" : "1881128166",
      "id" : 1881128166
    }, {
      "name" : "Former Enquirer home",
      "screen_name" : "Cincienquirer",
      "indices" : [ 70, 84 ],
      "id_str" : "21678658",
      "id" : 21678658
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Maley44\/status\/392665721399832576\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/wtPQoKzD1B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXMHZKfCcAAkbVz.jpg",
      "id_str" : "392665721404026880",
      "id" : 392665721404026880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXMHZKfCcAAkbVz.jpg",
      "sizes" : [ {
        "h" : 978,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 978,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 838,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wtPQoKzD1B"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 85, 95 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 96, 107 ]
    }, {
      "text" : "OHNews",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392668001012838400",
  "text" : "RT @Maley44: \"They're covered: 330,000 More Ohioans Now Eligible\" via @Cincienquirer #Obamacare #GetCovered #OHNews http:\/\/t.co\/wtPQoKzD1B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Former Enquirer home",
        "screen_name" : "Cincienquirer",
        "indices" : [ 57, 71 ],
        "id_str" : "21678658",
        "id" : 21678658
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Maley44\/status\/392665721399832576\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/wtPQoKzD1B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BXMHZKfCcAAkbVz.jpg",
        "id_str" : "392665721404026880",
        "id" : 392665721404026880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXMHZKfCcAAkbVz.jpg",
        "sizes" : [ {
          "h" : 978,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 978,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 838,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/wtPQoKzD1B"
      } ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 72, 82 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 83, 94 ]
      }, {
        "text" : "OHNews",
        "indices" : [ 95, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392665721399832576",
    "text" : "\"They're covered: 330,000 More Ohioans Now Eligible\" via @Cincienquirer #Obamacare #GetCovered #OHNews http:\/\/t.co\/wtPQoKzD1B",
    "id" : 392665721399832576,
    "created_at" : "2013-10-22 14:56:18 +0000",
    "user" : {
      "name" : "Keith Maley",
      "screen_name" : "Maley44",
      "protected" : false,
      "id_str" : "1881128166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725086933961957376\/v5WvYCOW_normal.jpg",
      "id" : 1881128166,
      "verified" : true
    }
  },
  "id" : 392668001012838400,
  "created_at" : "2013-10-22 15:05:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/392440565272707072\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/B02cwQqrGe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXI6nV7IEAAHTUM.jpg",
      "id_str" : "392440565109100544",
      "id" : 392440565109100544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXI6nV7IEAAHTUM.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/B02cwQqrGe"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 92, 102 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392440565272707072",
  "text" : "RT if you're rooting for millions of uninsured Americans to get affordable health coverage. #Obamacare #GetCovered, http:\/\/t.co\/B02cwQqrGe",
  "id" : 392440565272707072,
  "created_at" : "2013-10-22 00:01:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/9lBHmuGogp",
      "expanded_url" : "http:\/\/go.wh.gov\/RuwQ3p",
      "display_url" : "go.wh.gov\/RuwQ3p"
    } ]
  },
  "geo" : { },
  "id_str" : "392428847137714176",
  "text" : "\"If one thing is worth the wait, it\u2019s the safety and security of health care that you can afford.\" \u2014Obama: http:\/\/t.co\/9lBHmuGogp #Obamacare",
  "id" : 392428847137714176,
  "created_at" : "2013-10-21 23:15:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 84, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/cYvfJhVlVK",
      "expanded_url" : "http:\/\/bit.ly\/1cNY2IS",
      "display_url" : "bit.ly\/1cNY2IS"
    } ]
  },
  "geo" : { },
  "id_str" : "392423281141481472",
  "text" : "RT @Simas44: Biggest ACA story of the day ... Ohio! Peace of mind for 275k Ohioans. #GetCovered  http:\/\/t.co\/cYvfJhVlVK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 71, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/cYvfJhVlVK",
        "expanded_url" : "http:\/\/bit.ly\/1cNY2IS",
        "display_url" : "bit.ly\/1cNY2IS"
      } ]
    },
    "geo" : { },
    "id_str" : "392420296008806400",
    "text" : "Biggest ACA story of the day ... Ohio! Peace of mind for 275k Ohioans. #GetCovered  http:\/\/t.co\/cYvfJhVlVK",
    "id" : 392420296008806400,
    "created_at" : "2013-10-21 22:41:04 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 392423281141481472,
  "created_at" : "2013-10-21 22:52:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 91, 102 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/LHJf7VR1jx",
      "expanded_url" : "http:\/\/go.wh.gov\/rMjKXZ",
      "display_url" : "go.wh.gov\/rMjKXZ"
    } ]
  },
  "geo" : { },
  "id_str" : "392419340487639041",
  "text" : "Here's what we're doing to make http:\/\/t.co\/GNfbftrfo3 better \u2014&gt; http:\/\/t.co\/LHJf7VR1jx #GetCovered #Obamacare",
  "id" : 392419340487639041,
  "created_at" : "2013-10-21 22:37:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "indices" : [ 3, 13 ],
      "id_str" : "1712989040",
      "id" : 1712989040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Orlando",
      "indices" : [ 15, 23 ]
    }, {
      "text" : "ObamaCare",
      "indices" : [ 100, 110 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 111, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392416702832840704",
  "text" : "RT @Rosholm44: #Orlando native Daniel tells his story about finding affordable coverage for $70\/mo. #ObamaCare #GetCovered http:\/\/t.co\/KEAG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Orlando",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "ObamaCare",
        "indices" : [ 85, 95 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 96, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/KEAGJ0ypLh",
        "expanded_url" : "http:\/\/www.hhs.gov\/healthcare\/facts\/blog\/2013\/10\/marketplace-affordable-coverage.html",
        "display_url" : "hhs.gov\/healthcare\/fac\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "392387529195810816",
    "text" : "#Orlando native Daniel tells his story about finding affordable coverage for $70\/mo. #ObamaCare #GetCovered http:\/\/t.co\/KEAGJ0ypLh",
    "id" : 392387529195810816,
    "created_at" : "2013-10-21 20:30:51 +0000",
    "user" : {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "protected" : false,
      "id_str" : "1712989040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755544708483538944\/h-5gKL6u_normal.jpg",
      "id" : 1712989040,
      "verified" : true
    }
  },
  "id" : 392416702832840704,
  "created_at" : "2013-10-21 22:26:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Progress",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 58, 69 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/pyfjJQMUiC",
      "expanded_url" : "http:\/\/go.wh.gov\/thNLFY",
      "display_url" : "go.wh.gov\/thNLFY"
    } ]
  },
  "geo" : { },
  "id_str" : "392410337225351168",
  "text" : "#Progress \u2014&gt; 270,000 previously uninsured Ohioans will #GetCovered next year\u2014many for the first time: http:\/\/t.co\/pyfjJQMUiC #Obamacare",
  "id" : 392410337225351168,
  "created_at" : "2013-10-21 22:01:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mattison",
      "screen_name" : "Mattison",
      "indices" : [ 3, 12 ],
      "id_str" : "4214321",
      "id" : 4214321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/TEo30lX9hO",
      "expanded_url" : "http:\/\/healthconnect.vermont.gov",
      "display_url" : "healthconnect.vermont.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "392396020359122944",
  "text" : "RT @Mattison: Just enrolled at http:\/\/t.co\/TEo30lX9hO . I'm saving $552\/yr for plan incl. prescription coverage I haven't had for past 8yrs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "vt",
        "indices" : [ 127, 130 ]
      }, {
        "text" : "btv",
        "indices" : [ 131, 135 ]
      }, {
        "text" : "ACA",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/TEo30lX9hO",
        "expanded_url" : "http:\/\/healthconnect.vermont.gov",
        "display_url" : "healthconnect.vermont.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "392354016014786560",
    "text" : "Just enrolled at http:\/\/t.co\/TEo30lX9hO . I'm saving $552\/yr for plan incl. prescription coverage I haven't had for past 8yrs. #vt #btv #ACA",
    "id" : 392354016014786560,
    "created_at" : "2013-10-21 18:17:41 +0000",
    "user" : {
      "name" : "Mattison",
      "screen_name" : "Mattison",
      "protected" : false,
      "id_str" : "4214321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685424885368111104\/bTKOP_Dh_normal.jpg",
      "id" : 4214321,
      "verified" : false
    }
  },
  "id" : 392396020359122944,
  "created_at" : "2013-10-21 21:04:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392385889735049216",
  "text" : "RT @CEAChair: Hey everyone! Follow along for the latest on the economy, tax policy, job creation, and occasional facts on the greatness of \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392384816596787200",
    "text" : "Hey everyone! Follow along for the latest on the economy, tax policy, job creation, and occasional facts on the greatness of Greek yogurt.",
    "id" : 392384816596787200,
    "created_at" : "2013-10-21 20:20:05 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 392385889735049216,
  "created_at" : "2013-10-21 20:24:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392384150717857792",
  "text" : "RT @CEABetsey: Excited to be tweeting from CEA! Follow for insights on the economy &amp; its impact on families from a working mom w\/ 2 small k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392382610283831297",
    "text" : "Excited to be tweeting from CEA! Follow for insights on the economy &amp; its impact on families from a working mom w\/ 2 small kids.",
    "id" : 392382610283831297,
    "created_at" : "2013-10-21 20:11:19 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 392384150717857792,
  "created_at" : "2013-10-21 20:17:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Maley",
      "screen_name" : "Maley44",
      "indices" : [ 3, 11 ],
      "id_str" : "1881128166",
      "id" : 1881128166
    }, {
      "name" : "RepKevinBrady",
      "screen_name" : "RepKevinBrady",
      "indices" : [ 20, 34 ],
      "id_str" : "19926675",
      "id" : 19926675
    }, {
      "name" : "Morning Joe",
      "screen_name" : "Morning_Joe",
      "indices" : [ 38, 50 ],
      "id_str" : "254117355",
      "id" : 254117355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392381790461362176",
  "text" : "RT @Maley44: TX Rep @RepKevinBrady on @Morning_Joe asked if he'll help uninsured: \"Its the law, and if our constituents need help, we'll gi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RepKevinBrady",
        "screen_name" : "RepKevinBrady",
        "indices" : [ 7, 21 ],
        "id_str" : "19926675",
        "id" : 19926675
      }, {
        "name" : "Morning Joe",
        "screen_name" : "Morning_Joe",
        "indices" : [ 25, 37 ],
        "id_str" : "254117355",
        "id" : 254117355
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392363752386875392",
    "text" : "TX Rep @RepKevinBrady on @Morning_Joe asked if he'll help uninsured: \"Its the law, and if our constituents need help, we'll give it to them\"",
    "id" : 392363752386875392,
    "created_at" : "2013-10-21 18:56:22 +0000",
    "user" : {
      "name" : "Keith Maley",
      "screen_name" : "Maley44",
      "protected" : false,
      "id_str" : "1881128166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725086933961957376\/v5WvYCOW_normal.jpg",
      "id" : 1881128166,
      "verified" : true
    }
  },
  "id" : 392381790461362176,
  "created_at" : "2013-10-21 20:08:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/392365338160930817\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/WwVkBz2LkP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BXH2MjxCIAAKWIW.jpg",
      "id_str" : "392365338177708032",
      "id" : 392365338177708032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BXH2MjxCIAAKWIW.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/WwVkBz2LkP"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "392365338160930817",
  "text" : "RT the news: More than 500,000 Americans have applied for coverage through #Obamacare \u2014&gt; http:\/\/t.co\/GNfbftrfo3, http:\/\/t.co\/WwVkBz2LkP",
  "id" : 392365338160930817,
  "created_at" : "2013-10-21 19:02:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 104, 115 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/l1dx48VJRe",
      "expanded_url" : "http:\/\/nyti.ms\/17Yroio",
      "display_url" : "nyti.ms\/17Yroio"
    } ]
  },
  "geo" : { },
  "id_str" : "392337055524478976",
  "text" : "\"It is time to put an end to governing by crisis &amp; focus on...economic growth &amp; job creation.\" \u2014@USTreasury Sec. Lew: http:\/\/t.co\/l1dx48VJRe",
  "id" : 392337055524478976,
  "created_at" : "2013-10-21 17:10:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Conyers, Jr.",
      "screen_name" : "RepJohnConyers",
      "indices" : [ 3, 18 ],
      "id_str" : "138770045",
      "id" : 138770045
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/I9fut78d3a",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "392334482826461185",
  "text" : "RT @repjohnconyers: #Obamacare is more than a website - it's access to affordable, quality health insurance for all. http:\/\/t.co\/I9fut78d3a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/I9fut78d3a",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "392308636565114880",
    "text" : "#Obamacare is more than a website - it's access to affordable, quality health insurance for all. http:\/\/t.co\/I9fut78d3a probs are temporary.",
    "id" : 392308636565114880,
    "created_at" : "2013-10-21 15:17:22 +0000",
    "user" : {
      "name" : "John Conyers, Jr.",
      "screen_name" : "RepJohnConyers",
      "protected" : false,
      "id_str" : "138770045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780883237342150656\/dxNk5zEp_normal.jpg",
      "id" : 138770045,
      "verified" : true
    }
  },
  "id" : 392334482826461185,
  "created_at" : "2013-10-21 17:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 133, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392319959134519296",
  "text" : "Obama: \"Health care is not a privilege for a fortunate few, but a right for all to enjoy &amp; I intend to deliver on that promise.\" #Obamacare",
  "id" : 392319959134519296,
  "created_at" : "2013-10-21 16:02:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392319417331113985",
  "text" : "Obama: \"We fought so hard to pass this law...to lift from the American people the crushing burden of unaffordable health care.\" #Obamacare",
  "id" : 392319417331113985,
  "created_at" : "2013-10-21 16:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 9, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392318893852618752",
  "text" : "Obama on #Obamacare: \"It\u2019s time for folks to stop rooting for its failure, because...middle-class families are rooting for its success.\"",
  "id" : 392318893852618752,
  "created_at" : "2013-10-21 15:58:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 113, 124 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392318400510193665",
  "text" : "Obama: \"We did not wage this long and contentious battle just around a website. That's not what this was about.\" #GetCovered #Obamacare",
  "id" : 392318400510193665,
  "created_at" : "2013-10-21 15:56:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392317894157029376",
  "text" : "Obama: \"Nobody's madder than me that the website isn't working as well as it should, which means it's going to get fixed.\" #Obamacare",
  "id" : 392317894157029376,
  "created_at" : "2013-10-21 15:54:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 112, 123 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392317472767881216",
  "text" : "Obama: \"It usually takes about 25 minutes for an individual to apply for coverage and 45 minutes for a family.\" #GetCovered #Obamacare",
  "id" : 392317472767881216,
  "created_at" : "2013-10-21 15:52:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392317223412314112",
  "text" : "Obama: \"We\u2019ve also added more staff to the call centers where you can apply for insurance over the phone.\" Call: 1-800-318-2596 #GetCovered",
  "id" : 392317223412314112,
  "created_at" : "2013-10-21 15:51:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 117, 128 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "392316842791804929",
  "text" : "President Obama on http:\/\/t.co\/GNfbftrfo3: \"We are doing everything we possibly can to get the site working better.\" #GetCovered #Obamacare",
  "id" : 392316842791804929,
  "created_at" : "2013-10-21 15:49:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392316579670552577",
  "text" : "RT @WHLive: President Obama: \"Everybody who wants insurance through the marketplace will get insurance \u2013 period.\" #GetCovered",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 102, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392316542819393536",
    "text" : "President Obama: \"Everybody who wants insurance through the marketplace will get insurance \u2013 period.\" #GetCovered",
    "id" : 392316542819393536,
    "created_at" : "2013-10-21 15:48:47 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 392316579670552577,
  "created_at" : "2013-10-21 15:48:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/vGCx3dwIDQ",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "392316250048573440",
  "text" : "RT @WHLive: President Obama: \"Even with all the problems at http:\/\/t.co\/vGCx3dwIDQ, the website is still working for a lot of people.\" #Get\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 123, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/vGCx3dwIDQ",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "392316208336220161",
    "text" : "President Obama: \"Even with all the problems at http:\/\/t.co\/vGCx3dwIDQ, the website is still working for a lot of people.\" #GetCovered",
    "id" : 392316208336220161,
    "created_at" : "2013-10-21 15:47:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 392316250048573440,
  "created_at" : "2013-10-21 15:47:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392315572374863872",
  "text" : "Obama: \"Every day, women are finally buying coverage that doesn\u2019t charge them higher premiums than men for the same care.\" #Obamacare",
  "id" : 392315572374863872,
  "created_at" : "2013-10-21 15:44:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 115, 126 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392315306795753472",
  "text" : "President Obama: \"More than half a million consumers across the country have successfully submitted applications.\" #GetCovered #Obamacare",
  "id" : 392315306795753472,
  "created_at" : "2013-10-21 15:43:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 92, 103 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "392315130387501058",
  "text" : "President Obama: \"So far, http:\/\/t.co\/GNfbftrfo3 has been visited nearly 20 million times.\" #GetCovered #Obamacare",
  "id" : 392315130387501058,
  "created_at" : "2013-10-21 15:43:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/BI7CMZpdHb",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "392314879736307712",
  "text" : "President Obama: \"Nearly 6 in 10 uninsured Americans will find that they can #GetCovered for $100 a month or less.\" http:\/\/t.co\/BI7CMZpdHb",
  "id" : 392314879736307712,
  "created_at" : "2013-10-21 15:42:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 87, 98 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392314398678593536",
  "text" : "Obama: \"In Oregon...56,000 more Americans...finally know the security of health care.\" #GetCovered #Obamacare",
  "id" : 392314398678593536,
  "created_at" : "2013-10-21 15:40:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392314107694546944",
  "text" : "President Obama: \"Because of the Affordable Care Act, preventive care like mammograms and birth control are free.\" #Obamacare",
  "id" : 392314107694546944,
  "created_at" : "2013-10-21 15:39:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392313961153982464",
  "text" : "Obama: \"Because of the Affordable Care Act, young people...have been able to stay on their parents\u2019 plans until they\u2019re 26.\" #Obamacare",
  "id" : 392313961153982464,
  "created_at" : "2013-10-21 15:38:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 55, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392313900948938753",
  "text" : "RT @WHLive: Obama to those with health insurance: \"The #ACA already provides you with new benefits &amp; protections that have been in place fo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 43, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392313860943667201",
    "text" : "Obama to those with health insurance: \"The #ACA already provides you with new benefits &amp; protections that have been in place for some time.\"",
    "id" : 392313860943667201,
    "created_at" : "2013-10-21 15:38:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 392313900948938753,
  "created_at" : "2013-10-21 15:38:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 84, 95 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392313738620968960",
  "text" : "RT @WHLive: President Obama: \"The Affordable Care Act is much more than a website.\" #GetCovered #Obamacare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 72, 83 ]
      }, {
        "text" : "Obamacare",
        "indices" : [ 84, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392313662423048193",
    "text" : "President Obama: \"The Affordable Care Act is much more than a website.\" #GetCovered #Obamacare",
    "id" : 392313662423048193,
    "created_at" : "2013-10-21 15:37:20 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 392313738620968960,
  "created_at" : "2013-10-21 15:37:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392313587827343360",
  "text" : "Obama: \"For those who\u2019ve had some problems with the website, I want to tell you what we\u2019re doing to make it work better.\" #GetCovered",
  "id" : 392313587827343360,
  "created_at" : "2013-10-21 15:37:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392313394293780480",
  "text" : "RT @WHLive: Obama: \"Many Americans with a pre-existing condition\u2026are discovering that they can finally get health insurance like anyone els\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "392313375075475456",
    "text" : "Obama: \"Many Americans with a pre-existing condition\u2026are discovering that they can finally get health insurance like anyone else.\"",
    "id" : 392313375075475456,
    "created_at" : "2013-10-21 15:36:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 392313394293780480,
  "created_at" : "2013-10-21 15:36:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 110, 121 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "392313306427314178",
  "text" : "President Obama on http:\/\/t.co\/GNfbftrfo3: \"Thousands of people are signing up and saving money as we speak.\" #GetCovered #Obamacare",
  "id" : 392313306427314178,
  "created_at" : "2013-10-21 15:35:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392313177582477313",
  "text" : "President Obama on #Obamacare: \"Today, I want to talk about how we\u2019re going to get the marketplaces running at full steam.\" #GetCovered",
  "id" : 392313177582477313,
  "created_at" : "2013-10-21 15:35:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 111, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "392312499766173696",
  "text" : "Right now: President Obama speaks on #Obamacare and http:\/\/t.co\/GNfbftrfo3. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb #GetCovered",
  "id" : 392312499766173696,
  "created_at" : "2013-10-21 15:32:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 80, 90 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "392308049446043648",
  "text" : "FACT: Nearly 500,000 Americans have already applied for health coverage through #Obamacare. #GetCovered",
  "id" : 392308049446043648,
  "created_at" : "2013-10-21 15:15:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 39, 49 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "392302737926283264",
  "text" : "Don\u2019t miss President Obama speak about #Obamacare and http:\/\/t.co\/GNfbftrfo3. Watch at 11:25am ET: http:\/\/t.co\/KvadYk9atb #GetCovered",
  "id" : 392302737926283264,
  "created_at" : "2013-10-21 14:53:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/vsFHL5ObnM",
      "expanded_url" : "http:\/\/go.wh.gov\/JY8QAM",
      "display_url" : "go.wh.gov\/JY8QAM"
    } ]
  },
  "geo" : { },
  "id_str" : "392296650191806464",
  "text" : "Worth sharing: Here's how we're working to improve http:\/\/t.co\/GNfbftrfo3 so more Americans can #GetCovered \u2014&gt; http:\/\/t.co\/vsFHL5ObnM",
  "id" : 392296650191806464,
  "created_at" : "2013-10-21 14:29:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ZiVJLubQvk",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "392067088141266945",
  "text" : "RT @HHSGov: We're bringing in the best &amp; brightest from inside &amp; outside government to help improve http:\/\/t.co\/ZiVJLubQvk READ:  http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/ZiVJLubQvk",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      }, {
        "indices" : [ 126, 148 ],
        "url" : "http:\/\/t.co\/YhM8LeaE98",
        "expanded_url" : "http:\/\/www.hhs.gov\/digitalstrategy\/doing-better-making-improvements-healthcaregov.html",
        "display_url" : "hhs.gov\/digitalstrateg\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "391975493244682242",
    "text" : "We're bringing in the best &amp; brightest from inside &amp; outside government to help improve http:\/\/t.co\/ZiVJLubQvk READ:  http:\/\/t.co\/YhM8LeaE98",
    "id" : 391975493244682242,
    "created_at" : "2013-10-20 17:13:34 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 392067088141266945,
  "created_at" : "2013-10-20 23:17:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 23, 31 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391955207804170242",
  "text" : "RT @Schultz44: Today's @nytimes chronicles the great, impressive work happening in Kentucky to help the uninsured get covered: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 8, 16 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/rgnIqVzchq",
        "expanded_url" : "http:\/\/nyti.ms\/1a0lQul",
        "display_url" : "nyti.ms\/1a0lQul"
      } ]
    },
    "geo" : { },
    "id_str" : "391937531047997440",
    "text" : "Today's @nytimes chronicles the great, impressive work happening in Kentucky to help the uninsured get covered: http:\/\/t.co\/rgnIqVzchq",
    "id" : 391937531047997440,
    "created_at" : "2013-10-20 14:42:43 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 391955207804170242,
  "created_at" : "2013-10-20 15:52:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/vfg2GF7G0T",
      "expanded_url" : "http:\/\/abcn.ws\/1gVv4JD",
      "display_url" : "abcn.ws\/1gVv4JD"
    } ]
  },
  "geo" : { },
  "id_str" : "391741924467437568",
  "text" : "RT the news: Nearly half a million Americans apply for quality, affordable health care in less than three weeks: http:\/\/t.co\/vfg2GF7G0T",
  "id" : 391741924467437568,
  "created_at" : "2013-10-20 01:45:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/muZaiQCDEY",
      "expanded_url" : "http:\/\/go.wh.gov\/ku8YFs",
      "display_url" : "go.wh.gov\/ku8YFs"
    } ]
  },
  "geo" : { },
  "id_str" : "391642299169402880",
  "text" : "\"The way business is done in Washington has to change.\" \u2014President Obama in his Weekly Address: http:\/\/t.co\/muZaiQCDEY",
  "id" : 391642299169402880,
  "created_at" : "2013-10-19 19:09:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/4ylPVemMp2",
      "expanded_url" : "http:\/\/go.wh.gov\/ziPd4B",
      "display_url" : "go.wh.gov\/ziPd4B"
    } ]
  },
  "geo" : { },
  "id_str" : "391573235742932992",
  "text" : "\"We need to focus on what the majority of Americans sent us here to do\u2014grow the economy, create good jobs.\" \u2014Obama: http:\/\/t.co\/4ylPVemMp2",
  "id" : 391573235742932992,
  "created_at" : "2013-10-19 14:35:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 124, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/a5gjfSH9Bf",
      "expanded_url" : "http:\/\/bit.ly\/16VnVW7",
      "display_url" : "bit.ly\/16VnVW7"
    } ]
  },
  "geo" : { },
  "id_str" : "391329059889627137",
  "text" : "\"It's just the right thing to do.\" \u2014Gov. Kasich on expanding Medicaid to cover 275,000 more Ohioans: http:\/\/t.co\/a5gjfSH9Bf #ThanksObamacare",
  "id" : 391329059889627137,
  "created_at" : "2013-10-18 22:24:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James E. Clyburn",
      "screen_name" : "Clyburn",
      "indices" : [ 3, 11 ],
      "id_str" : "188019606",
      "id" : 188019606
    }, {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 64, 71 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391318009887080448",
  "text" : "RT @Clyburn: I applaud the appointment of Jeh Johnson as Sec of @DHSgov. I know him well. He's a good guy who I expect will do an outstandi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Homeland Security",
        "screen_name" : "DHSgov",
        "indices" : [ 51, 58 ],
        "id_str" : "15647676",
        "id" : 15647676
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391280650545659905",
    "text" : "I applaud the appointment of Jeh Johnson as Sec of @DHSgov. I know him well. He's a good guy who I expect will do an outstanding job.",
    "id" : 391280650545659905,
    "created_at" : "2013-10-18 19:12:31 +0000",
    "user" : {
      "name" : "James E. Clyburn",
      "screen_name" : "Clyburn",
      "protected" : false,
      "id_str" : "188019606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1120632391\/JEC_Photo_-_Twitter_normal.jpg",
      "id" : 188019606,
      "verified" : true
    }
  },
  "id" : 391318009887080448,
  "created_at" : "2013-10-18 21:40:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "John Kirby",
      "screen_name" : "statedeptspox",
      "indices" : [ 107, 121 ],
      "id_str" : "1967216306",
      "id" : 1967216306
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391312672613867520",
  "text" : "RT @PressSec: Get wise about the world, U.S. foreign policy and SecState John Kerry by following Jen Psaki @statedeptspox. You'll be glad y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kirby",
        "screen_name" : "statedeptspox",
        "indices" : [ 93, 107 ],
        "id_str" : "1967216306",
        "id" : 1967216306
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391300473287745536",
    "text" : "Get wise about the world, U.S. foreign policy and SecState John Kerry by following Jen Psaki @statedeptspox. You'll be glad you did!",
    "id" : 391300473287745536,
    "created_at" : "2013-10-18 20:31:17 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 391312672613867520,
  "created_at" : "2013-10-18 21:19:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 132, 145 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/vqJG7glWEX",
      "expanded_url" : "http:\/\/go.wh.gov\/LE9nYE",
      "display_url" : "go.wh.gov\/LE9nYE"
    } ]
  },
  "geo" : { },
  "id_str" : "391307936380620801",
  "text" : "Go behind-the-scenes with President Obama: Ending the shutdown, awarding the Medal of Honor &amp; more \u2014&gt; http:\/\/t.co\/vqJG7glWEX #WestWingWeek",
  "id" : 391307936380620801,
  "created_at" : "2013-10-18 21:00:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 91, 101 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391300383936491521",
  "text" : "FACT: Since Oct. 1st, nearly 10,000 Kentuckians have enrolled in health coverage thanks to #Obamacare. #GetCovered",
  "id" : 391300383936491521,
  "created_at" : "2013-10-18 20:30:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 89, 99 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391292840455598081",
  "text" : "FACT: Nearly 9,500 people in Washington state have enrolled in health coverage thanks to #Obamacare. #GetCovered",
  "id" : 391292840455598081,
  "created_at" : "2013-10-18 20:00:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 105, 115 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391285288665755648",
  "text" : "FACT: In just 2 weeks, nearly 100,000 Californians have started health coverage applications through the #Obamacare marketplace. #GetCovered",
  "id" : 391285288665755648,
  "created_at" : "2013-10-18 19:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/4VBzjSZ1bI",
      "expanded_url" : "http:\/\/go.wh.gov\/EWSCTK",
      "display_url" : "go.wh.gov\/EWSCTK"
    } ]
  },
  "geo" : { },
  "id_str" : "391275506357661696",
  "text" : "\"Today, America has lost a legend of the United States Congress.\" \u2014President Obama on the passing of Tom Foley: http:\/\/t.co\/4VBzjSZ1bI",
  "id" : 391275506357661696,
  "created_at" : "2013-10-18 18:52:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 87, 97 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391273961100546048",
  "text" : "FACT: More than 40,000 New Yorkers have already signed up for health insurance through #Obamacare. #GetCovered",
  "id" : 391273961100546048,
  "created_at" : "2013-10-18 18:45:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391265640708710400",
  "text" : "Obama: \"Jeh understands that this country is worth protecting\u2014not because of what we build or what we own\u2014but because of who we are.\"",
  "id" : 391265640708710400,
  "created_at" : "2013-10-18 18:12:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391265286608793600",
  "text" : "RT @WHLive: Obama: \"Jeh believes in a deep...way that keeping America safe also means upholding the values and civil liberties that make Am\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391265138327552000",
    "text" : "Obama: \"Jeh believes in a deep...way that keeping America safe also means upholding the values and civil liberties that make America great.\"",
    "id" : 391265138327552000,
    "created_at" : "2013-10-18 18:10:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 391265286608793600,
  "created_at" : "2013-10-18 18:11:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 49, 56 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391264142335557632",
  "text" : "Obama: \"I\u2019m proud to announce my choice to lead [@DHSGov]\u2014an outstanding public servant who I\u2019ve known &amp; trusted for years\u2014Mr. Jeh Johnson.\"",
  "id" : 391264142335557632,
  "created_at" : "2013-10-18 18:06:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "391263651996266496",
  "text" : "Right now: President Obama nominates Jeh Johnson to be the Secretary of Homeland Security. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 391263651996266496,
  "created_at" : "2013-10-18 18:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 94, 104 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Ff2yLgQvdg",
      "expanded_url" : "http:\/\/go.wh.gov\/TBHYG8",
      "display_url" : "go.wh.gov\/TBHYG8"
    } ]
  },
  "geo" : { },
  "id_str" : "391247534401662977",
  "text" : "Share these stories from Americans who are already getting affordable health coverage through #Obamacare: http:\/\/t.co\/Ff2yLgQvdg #GetCovered",
  "id" : 391247534401662977,
  "created_at" : "2013-10-18 17:00:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 29, 36 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "391237107231883264",
  "text" : "Don't miss President Obama's @DHSGov personnel announcement at 2pm ET \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 391237107231883264,
  "created_at" : "2013-10-18 16:19:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/391227913443373056\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/UekEn7Pbv8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BW3rtueCcAACFin.jpg",
      "id_str" : "391227913451761664",
      "id" : 391227913451761664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BW3rtueCcAACFin.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/UekEn7Pbv8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391227913443373056",
  "text" : "Disagreement cannot mean dysfunction. Let's focus on growing our economy and strengthening the middle class: http:\/\/t.co\/UekEn7Pbv8",
  "id" : 391227913443373056,
  "created_at" : "2013-10-18 15:42:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ZW8D9CDSFA",
      "expanded_url" : "http:\/\/go.wh.gov\/rAGEvo",
      "display_url" : "go.wh.gov\/rAGEvo"
    } ]
  },
  "geo" : { },
  "id_str" : "391220860503089152",
  "text" : "Obama on how Congress can help grow our economy:\n1. Pass a budget\n2. Immigration reform\n3. Pass a farm bill\nhttp:\/\/t.co\/ZW8D9CDSFA\n#JustVote",
  "id" : 391220860503089152,
  "created_at" : "2013-10-18 15:14:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Zoo",
      "screen_name" : "NationalZoo",
      "indices" : [ 3, 15 ],
      "id_str" : "17045060",
      "id" : 17045060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391218167806427136",
  "text" : "RT @NationalZoo: We are OPEN! Come visit the animals!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "391209813453336576",
    "text" : "We are OPEN! Come visit the animals!",
    "id" : 391209813453336576,
    "created_at" : "2013-10-18 14:31:02 +0000",
    "user" : {
      "name" : "National Zoo",
      "screen_name" : "NationalZoo",
      "protected" : false,
      "id_str" : "17045060",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671384071294070784\/HCjIdoN9_normal.jpg",
      "id" : 17045060,
      "verified" : true
    }
  },
  "id" : 391218167806427136,
  "created_at" : "2013-10-18 15:04:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/390994439466135552\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/g4hfgaAIYo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BW0XXvVIYAAcupd.jpg",
      "id_str" : "390994439260626944",
      "id" : 390994439260626944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BW0XXvVIYAAcupd.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/g4hfgaAIYo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/X79XQIvrgl",
      "expanded_url" : "http:\/\/go.wh.gov\/hWEqNR",
      "display_url" : "go.wh.gov\/hWEqNR"
    } ]
  },
  "geo" : { },
  "id_str" : "390994439466135552",
  "text" : "It's time to work together to change the way business is done in Washington \u2014&gt; http:\/\/t.co\/X79XQIvrgl, http:\/\/t.co\/g4hfgaAIYo",
  "id" : 390994439466135552,
  "created_at" : "2013-10-18 00:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "colorado",
      "indices" : [ 103, 112 ]
    }, {
      "text" : "autumn",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390985029662171136",
  "text" : "RT @Interior: How about some fall color to end your day? Here's a recent photo from Rocky Mountain NP. #colorado #autumn http:\/\/t.co\/deEoST\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/390955697133080576\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/deEoSTS9IC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWz0Io8IEAASwIV.jpg",
        "id_str" : "390955696940126208",
        "id" : 390955696940126208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWz0Io8IEAASwIV.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/deEoSTS9IC"
      } ],
      "hashtags" : [ {
        "text" : "colorado",
        "indices" : [ 89, 98 ]
      }, {
        "text" : "autumn",
        "indices" : [ 99, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "390955697133080576",
    "text" : "How about some fall color to end your day? Here's a recent photo from Rocky Mountain NP. #colorado #autumn http:\/\/t.co\/deEoSTS9IC",
    "id" : 390955697133080576,
    "created_at" : "2013-10-17 21:41:16 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 390985029662171136,
  "created_at" : "2013-10-17 23:37:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/390975031167037440\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/TTDnudqES3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BW0FuB3CEAAKNWm.jpg",
      "id_str" : "390975030982479872",
      "id" : 390975030982479872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BW0FuB3CEAAKNWm.jpg",
      "sizes" : [ {
        "h" : 689,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 404,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 689,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TTDnudqES3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390977742331600896",
  "text" : "RT @FLOTUS: Thank you to Malala Yousafzai for her incredible work on behalf of girls education in Pakistan. http:\/\/t.co\/TTDnudqES3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/390975031167037440\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/TTDnudqES3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BW0FuB3CEAAKNWm.jpg",
        "id_str" : "390975030982479872",
        "id" : 390975030982479872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BW0FuB3CEAAKNWm.jpg",
        "sizes" : [ {
          "h" : 689,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 689,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/TTDnudqES3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "390975031167037440",
    "text" : "Thank you to Malala Yousafzai for her incredible work on behalf of girls education in Pakistan. http:\/\/t.co\/TTDnudqES3",
    "id" : 390975031167037440,
    "created_at" : "2013-10-17 22:58:06 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 390977742331600896,
  "created_at" : "2013-10-17 23:08:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 27, 30 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 55, 59 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/p5GVkU6pOo",
      "expanded_url" : "http:\/\/go.wh.gov\/HubCch",
      "display_url" : "go.wh.gov\/HubCch"
    } ]
  },
  "geo" : { },
  "id_str" : "390957217966354432",
  "text" : "\"Welcome back everybody!\" \u2014@VP Biden greets furloughed @EPA employees coming back to work with muffins: http:\/\/t.co\/p5GVkU6pOo",
  "id" : 390957217966354432,
  "created_at" : "2013-10-17 21:47:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ojgXgoGNTb",
      "expanded_url" : "http:\/\/go.wh.gov\/d9RUEW",
      "display_url" : "go.wh.gov\/d9RUEW"
    } ]
  },
  "geo" : { },
  "id_str" : "390945546937982977",
  "text" : "President Obama: \"We honor the American in that video\u2014the soldier who went back in\u2014Captain William Swenson.\" http:\/\/t.co\/ojgXgoGNTb",
  "id" : 390945546937982977,
  "created_at" : "2013-10-17 21:00:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 114, 130 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 131, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Aqf0u3PUfG",
      "expanded_url" : "http:\/\/bit.ly\/1cyCbF8",
      "display_url" : "bit.ly\/1cyCbF8"
    } ]
  },
  "geo" : { },
  "id_str" : "390934214205386752",
  "text" : "Great news: The number of Oregonians without health insurance dropped 10% in 2 weeks \u2014&gt; http:\/\/t.co\/Aqf0u3PUfG #ThanksObamacare #GetCovered",
  "id" : 390934214205386752,
  "created_at" : "2013-10-17 20:15:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "indices" : [ 3, 13 ],
      "id_str" : "1729062162",
      "id" : 1729062162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390929682121502720",
  "text" : "RT @Racusen44: What #Obamacare is all about --&gt; Oregon cuts tally of people lacking health insurance by 10% in 2 weeks:http:\/\/t.co\/UrTPN64D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 5, 15 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 130, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/UrTPN64Dcp",
        "expanded_url" : "http:\/\/www.oregonlive.com\/health\/index.ssf\/2013\/10\/oregon_has_cut_tally_of_those.html",
        "display_url" : "oregonlive.com\/health\/index.s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "390923026818019328",
    "text" : "What #Obamacare is all about --&gt; Oregon cuts tally of people lacking health insurance by 10% in 2 weeks:http:\/\/t.co\/UrTPN64Dcp #GetCovered",
    "id" : 390923026818019328,
    "created_at" : "2013-10-17 19:31:27 +0000",
    "user" : {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "protected" : false,
      "id_str" : "1729062162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411689100\/e84b5f12ff73878aa785c296671e9ef8_normal.png",
      "id" : 1729062162,
      "verified" : true
    }
  },
  "id" : 390929682121502720,
  "created_at" : "2013-10-17 19:57:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/390922925018066944\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/zWfFd8uHIg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWzWVEDCMAAWyUH.jpg",
      "id_str" : "390922925026455552",
      "id" : 390922925026455552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWzWVEDCMAAWyUH.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/zWfFd8uHIg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390922925018066944",
  "text" : "RT if you agree: It's time for Washington to focus on the hopes and dreams of the American people. http:\/\/t.co\/zWfFd8uHIg",
  "id" : 390922925018066944,
  "created_at" : "2013-10-17 19:31:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Diana Nyad",
      "screen_name" : "diananyad",
      "indices" : [ 11, 21 ],
      "id_str" : "158504581",
      "id" : 158504581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390914908348354560",
  "text" : "RT @vj44: .@Diananyad told POTUS \u201CIt was never about swimming. It was about dreaming big &amp; being bold, &amp; living life boldly.\" http:\/\/t.co\/m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Diana Nyad",
        "screen_name" : "diananyad",
        "indices" : [ 1, 11 ],
        "id_str" : "158504581",
        "id" : 158504581
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/390911813434343424\/photo\/1",
        "indices" : [ 124, 146 ],
        "url" : "http:\/\/t.co\/mZzAHfmOEP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWzMOSKCAAA2kx6.jpg",
        "id_str" : "390911813438537728",
        "id" : 390911813438537728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWzMOSKCAAA2kx6.jpg",
        "sizes" : [ {
          "h" : 1934,
          "resize" : "fit",
          "w" : 1267
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 916,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1563,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mZzAHfmOEP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "390911813434343424",
    "text" : ".@Diananyad told POTUS \u201CIt was never about swimming. It was about dreaming big &amp; being bold, &amp; living life boldly.\" http:\/\/t.co\/mZzAHfmOEP",
    "id" : 390911813434343424,
    "created_at" : "2013-10-17 18:46:54 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 390914908348354560,
  "created_at" : "2013-10-17 18:59:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SpiritDay",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/AIpvrECPCO",
      "expanded_url" : "http:\/\/StopBullying.gov",
      "display_url" : "StopBullying.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "390906710832865280",
  "text" : "RT if you agree no child should have to face bullying because of who they are\u2014then learn how you can help: http:\/\/t.co\/AIpvrECPCO #SpiritDay",
  "id" : 390906710832865280,
  "created_at" : "2013-10-17 18:26:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/hvIvClhprW",
      "expanded_url" : "http:\/\/bit.ly\/H69Drj",
      "display_url" : "bit.ly\/H69Drj"
    } ]
  },
  "geo" : { },
  "id_str" : "390890819231551488",
  "text" : "Our government is open for business \u2014&gt; http:\/\/t.co\/hvIvClhprW",
  "id" : 390890819231551488,
  "created_at" : "2013-10-17 17:23:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 20, 23 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 38, 42 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390871745517076480",
  "text" : "RT @GinaEPA: Thanks @VP for coming to @EPA HQ this morning to greet staff returning to work. And thanks for the muffins! http:\/\/t.co\/FS9kAI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 7, 10 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 25, 29 ],
        "id_str" : "14615871",
        "id" : 14615871
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GinaEPA\/status\/390857822545526784\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/FS9kAIOUf2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWybHmbCQAAW5Qp.jpg",
        "id_str" : "390857822549721088",
        "id" : 390857822549721088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWybHmbCQAAW5Qp.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 850,
          "resize" : "fit",
          "w" : 1277
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FS9kAIOUf2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "390857822545526784",
    "text" : "Thanks @VP for coming to @EPA HQ this morning to greet staff returning to work. And thanks for the muffins! http:\/\/t.co\/FS9kAIOUf2",
    "id" : 390857822545526784,
    "created_at" : "2013-10-17 15:12:21 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 390871745517076480,
  "created_at" : "2013-10-17 16:07:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390861471212531713",
  "text" : "President Obama to Congress: \"Disagreement cannot mean dysfunction. The American people\u2019s hopes and dreams are what matters, not ours.\"",
  "id" : 390861471212531713,
  "created_at" : "2013-10-17 15:26:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390859905277497344",
  "text" : "President Obama: \"I have a simple message for all the dedicated and patriotic federal workers...thank you for your service. Welcome back.\"",
  "id" : 390859905277497344,
  "created_at" : "2013-10-17 15:20:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390859627388096512",
  "text" : "President Obama: \"You don\u2019t like a particular policy, or a particular President, then argue for your position and win an election.\"",
  "id" : 390859627388096512,
  "created_at" : "2013-10-17 15:19:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390859315893903360",
  "text" : "President Obama: \"Let\u2019s work together to make government better, instead of treating it like an enemy, or purposely making it work worse.\"",
  "id" : 390859315893903360,
  "created_at" : "2013-10-17 15:18:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390858688249876480",
  "text" : "President Obama: \"Third, we should pass a farm bill\u2014one that America\u2019s farmers and ranchers can depend on.\"",
  "id" : 390858688249876480,
  "created_at" : "2013-10-17 15:15:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 134, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390858166944030721",
  "text" : "Obama on CIR: \"The vast majority of Americans think this is the right thing to do &amp; it's sitting there for the House to pass it.\" #JustVote",
  "id" : 390858166944030721,
  "created_at" : "2013-10-17 15:13:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 93, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390857789142089728",
  "text" : "President Obama: \"Second, we should finish the job of fixing our broken immigration system.\" #ImmigrationReform",
  "id" : 390857789142089728,
  "created_at" : "2013-10-17 15:12:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390857603351187457",
  "text" : "Obama: \"The key now is a budget that...frees up resources for the things that do help us grow, like education, infrastructure, and research.",
  "id" : 390857603351187457,
  "created_at" : "2013-10-17 15:11:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390857155156271105",
  "text" : "Obama: \"We need a budget that deals with the issue that most Americans are focused on: creating more good jobs that pay better wages.\"",
  "id" : 390857155156271105,
  "created_at" : "2013-10-17 15:09:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390856816856272896",
  "text" : "President Obama: \"First, in the coming days and weeks, we should sit down and pursue a balanced approach to a responsible budget.\"",
  "id" : 390856816856272896,
  "created_at" : "2013-10-17 15:08:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390856515227107328",
  "text" : "President Obama: \"To all my friends in Congress, understand that how business is done in this town has to change.\"",
  "id" : 390856515227107328,
  "created_at" : "2013-10-17 15:07:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390855703838990336",
  "text" : "Obama: \"At a moment when our economic recovery demands more jobs and more momentum, yet another self-inflicted crisis set our economy back.\"",
  "id" : 390855703838990336,
  "created_at" : "2013-10-17 15:03:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shutdown",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390855407213633537",
  "text" : "President Obama: \"There are no winners here. These last few weeks have inflicted completely unnecessary damage upon our economy.\" #Shutdown",
  "id" : 390855407213633537,
  "created_at" : "2013-10-17 15:02:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390855122848198656",
  "text" : "President Obama: \"Because Democrats and responsible Republicans came together, the first government #shutdown in 17 years is now over.\"",
  "id" : 390855122848198656,
  "created_at" : "2013-10-17 15:01:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "390854916727504896",
  "text" : "Right now: President Obama delivers a statement from the White House. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 390854916727504896,
  "created_at" : "2013-10-17 15:00:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "390835947064946688",
  "text" : "Don't miss President Obama's statement from the White House at 10:35am ET \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 390835947064946688,
  "created_at" : "2013-10-17 13:45:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/4Veofg5GFK",
      "expanded_url" : "http:\/\/go.wh.gov\/TNCmAx",
      "display_url" : "go.wh.gov\/TNCmAx"
    } ]
  },
  "geo" : { },
  "id_str" : "390248610731806720",
  "text" : "RT to show your support for Captain William Swenson, Medal of Honor recipient --&gt; http:\/\/t.co\/4Veofg5GFK",
  "id" : 390248610731806720,
  "created_at" : "2013-10-15 22:51:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalofHonor",
      "indices" : [ 18, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390189027376115712",
  "text" : "RT @vj44: Today\u2019s #MedalofHonor to Capt. Will Swenson was a reminder to all of us what patriotism looks like, what service means.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalofHonor",
        "indices" : [ 8, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "390184447351345152",
    "text" : "Today\u2019s #MedalofHonor to Capt. Will Swenson was a reminder to all of us what patriotism looks like, what service means.",
    "id" : 390184447351345152,
    "created_at" : "2013-10-15 18:36:36 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 390189027376115712,
  "created_at" : "2013-10-15 18:54:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mI08VNxgrc",
      "expanded_url" : "http:\/\/WhiteHouse.gov\/live",
      "display_url" : "WhiteHouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "390156256276529153",
  "text" : "Happening at 2:10pm ET today: President Obama awards Captain William Swenson, U.S. Army, the Medal of Honor. Watch at http:\/\/t.co\/mI08VNxgrc",
  "id" : 390156256276529153,
  "created_at" : "2013-10-15 16:44:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/389891053215420416\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/imm2HLzyJA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWkr2OBCEAAx80O.jpg",
      "id_str" : "389891053219614720",
      "id" : 389891053219614720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWkr2OBCEAAx80O.jpg",
      "sizes" : [ {
        "h" : 222,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 669,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 784,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/imm2HLzyJA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "390102971662729216",
  "text" : "RT @petesouza: Photo of Pres Obama and VP Biden today after mtg in Rose Garden http:\/\/t.co\/imm2HLzyJA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/389891053215420416\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/imm2HLzyJA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWkr2OBCEAAx80O.jpg",
        "id_str" : "389891053219614720",
        "id" : 389891053219614720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWkr2OBCEAAx80O.jpg",
        "sizes" : [ {
          "h" : 222,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 784,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/imm2HLzyJA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "389891053215420416",
    "text" : "Photo of Pres Obama and VP Biden today after mtg in Rose Garden http:\/\/t.co\/imm2HLzyJA",
    "id" : 389891053215420416,
    "created_at" : "2013-10-14 23:10:45 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 390102971662729216,
  "created_at" : "2013-10-15 13:12:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389792319932624896",
  "text" : "RT @vj44: Hester is worried about losing clients, paying employees.What did other sm biz owners say to the President on Friday? http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/okW2l8stHQ",
        "expanded_url" : "http:\/\/1.usa.gov\/15BRf2W",
        "display_url" : "1.usa.gov\/15BRf2W"
      } ]
    },
    "geo" : { },
    "id_str" : "389791862841565185",
    "text" : "Hester is worried about losing clients, paying employees.What did other sm biz owners say to the President on Friday? http:\/\/t.co\/okW2l8stHQ",
    "id" : 389791862841565185,
    "created_at" : "2013-10-14 16:36:36 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 389792319932624896,
  "created_at" : "2013-10-14 16:38:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/ZijiLjhI7x",
      "expanded_url" : "http:\/\/go.wh.gov\/nZvajG",
      "display_url" : "go.wh.gov\/nZvajG"
    } ]
  },
  "geo" : { },
  "id_str" : "389091565697634304",
  "text" : "Watch President Obama discuss his meetings with Congress and the need to reopen the government and avoid default \u2014&gt; http:\/\/t.co\/ZijiLjhI7x",
  "id" : 389091565697634304,
  "created_at" : "2013-10-12 18:13:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Malala",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "389081091128033280",
  "text" : "RT @vj44: Today with #Malala Yousafzai in the Oval.Courageous young woman. An inspirational role model to leaders of tomorrow. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/388822234153758720\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/xiLwED32Zx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWVfwwwCMAEyz1j.jpg",
        "id_str" : "388822234162147329",
        "id" : 388822234162147329,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWVfwwwCMAEyz1j.jpg",
        "sizes" : [ {
          "h" : 673,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 673,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/xiLwED32Zx"
      } ],
      "hashtags" : [ {
        "text" : "Malala",
        "indices" : [ 11, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388822234153758720",
    "text" : "Today with #Malala Yousafzai in the Oval.Courageous young woman. An inspirational role model to leaders of tomorrow. http:\/\/t.co\/xiLwED32Zx",
    "id" : 388822234153758720,
    "created_at" : "2013-10-12 00:23:39 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 389081091128033280,
  "created_at" : "2013-10-12 17:32:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388776210173419520",
  "text" : "RT @Schultz44: California Ocare enrollment: in first 5 days, 16K apps, covering 29K people, another 27K have started applications http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/SjDw4sd6X3",
        "expanded_url" : "http:\/\/nyti.ms\/15tDrY8",
        "display_url" : "nyti.ms\/15tDrY8"
      } ]
    },
    "geo" : { },
    "id_str" : "388769715570499585",
    "text" : "California Ocare enrollment: in first 5 days, 16K apps, covering 29K people, another 27K have started applications http:\/\/t.co\/SjDw4sd6X3",
    "id" : 388769715570499585,
    "created_at" : "2013-10-11 20:54:57 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 388776210173419520,
  "created_at" : "2013-10-11 21:20:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 42, 51 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388712543520161792",
  "text" : "RT to show your support: 11 days into the #shutdown, and a majority of Congress could still #JustVote to reopen the government.",
  "id" : 388712543520161792,
  "created_at" : "2013-10-11 17:07:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/pmGGFHYwio",
      "expanded_url" : "http:\/\/1.usa.gov\/184vz0m",
      "display_url" : "1.usa.gov\/184vz0m"
    } ]
  },
  "geo" : { },
  "id_str" : "388672194038886400",
  "text" : "RT @vj44: So proud that Potus marks 1st Intl Day of the Girl with a Proclamation. Support the day with a RT! http:\/\/t.co\/pmGGFHYwio  #DayOf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DayOfTheGirl",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/pmGGFHYwio",
        "expanded_url" : "http:\/\/1.usa.gov\/184vz0m",
        "display_url" : "1.usa.gov\/184vz0m"
      } ]
    },
    "geo" : { },
    "id_str" : "388667405771091968",
    "text" : "So proud that Potus marks 1st Intl Day of the Girl with a Proclamation. Support the day with a RT! http:\/\/t.co\/pmGGFHYwio  #DayOfTheGirl",
    "id" : 388667405771091968,
    "created_at" : "2013-10-11 14:08:25 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 388672194038886400,
  "created_at" : "2013-10-11 14:27:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/388659287188578304\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/5sN7Kux5x5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWTLj_UIYAA1jvH.jpg",
      "id_str" : "388659287012433920",
      "id" : 388659287012433920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWTLj_UIYAA1jvH.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 695
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 884,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 695
      } ],
      "display_url" : "pic.twitter.com\/5sN7Kux5x5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388670273559334913",
  "text" : "RT @petesouza: President Obama framed thru the arm of CoS Denis McDonough during mtg in Oval Office yesterday http:\/\/t.co\/5sN7Kux5x5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/388659287188578304\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/5sN7Kux5x5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWTLj_UIYAA1jvH.jpg",
        "id_str" : "388659287012433920",
        "id" : 388659287012433920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWTLj_UIYAA1jvH.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 695
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 884,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 695
        } ],
        "display_url" : "pic.twitter.com\/5sN7Kux5x5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388659287188578304",
    "text" : "President Obama framed thru the arm of CoS Denis McDonough during mtg in Oval Office yesterday http:\/\/t.co\/5sN7Kux5x5",
    "id" : 388659287188578304,
    "created_at" : "2013-10-11 13:36:09 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 388670273559334913,
  "created_at" : "2013-10-11 14:19:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/J47ocuIwKQ",
      "expanded_url" : "http:\/\/at.wh.gov\/2AD9uR",
      "display_url" : "at.wh.gov\/2AD9uR"
    } ]
  },
  "geo" : { },
  "id_str" : "388658490949898241",
  "text" : "Check out the latest edition of West Wing Week: The Shutdown Edition: Week Two --&gt; http:\/\/t.co\/J47ocuIwKQ",
  "id" : 388658490949898241,
  "created_at" : "2013-10-11 13:32:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388444060785971200",
  "text" : "RT @Jordan44: What's driving down GOP metrics in NBC\/WSJ poll? Only 23% support the GOP's plan to continue the govt shutdown to try to sabo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388438586141310976",
    "text" : "What's driving down GOP metrics in NBC\/WSJ poll? Only 23% support the GOP's plan to continue the govt shutdown to try to sabotage #Obamacare",
    "id" : 388438586141310976,
    "created_at" : "2013-10-10 22:59:10 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 388444060785971200,
  "created_at" : "2013-10-10 23:20:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "indices" : [ 3, 12 ],
      "id_str" : "1712961397",
      "id" : 1712961397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388443075258757120",
  "text" : "RT @Jordan44: What happens when you drive a strategy that ~70% of Americans disagree with --&gt; \"NBC\/WSJ poll: Shutdown debate damages GOP\" #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "consequences",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388436386065293312",
    "text" : "What happens when you drive a strategy that ~70% of Americans disagree with --&gt; \"NBC\/WSJ poll: Shutdown debate damages GOP\" #consequences",
    "id" : 388436386065293312,
    "created_at" : "2013-10-10 22:50:25 +0000",
    "user" : {
      "name" : "Jordan Burke",
      "screen_name" : "Jordan44",
      "protected" : false,
      "id_str" : "1712961397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000385970607\/bf630bbde77a51756719364980202c71_normal.png",
      "id" : 1712961397,
      "verified" : true
    }
  },
  "id" : 388443075258757120,
  "created_at" : "2013-10-10 23:17:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/388386127867961344\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/EgdPr7lt9n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWPTICPCYAEyk_L.jpg",
      "id_str" : "388386127876349953",
      "id" : 388386127876349953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWPTICPCYAEyk_L.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EgdPr7lt9n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388391153604624384",
  "text" : "RT @VP: PHOTO: VP Biden talks with Finance Minister Yair Lapid of Israel, after their meeting in his West Wing office http:\/\/t.co\/EgdPr7lt9n",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/388386127867961344\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/EgdPr7lt9n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BWPTICPCYAEyk_L.jpg",
        "id_str" : "388386127876349953",
        "id" : 388386127876349953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWPTICPCYAEyk_L.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EgdPr7lt9n"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "388386127867961344",
    "text" : "PHOTO: VP Biden talks with Finance Minister Yair Lapid of Israel, after their meeting in his West Wing office http:\/\/t.co\/EgdPr7lt9n",
    "id" : 388386127867961344,
    "created_at" : "2013-10-10 19:30:43 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 388391153604624384,
  "created_at" : "2013-10-10 19:50:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/RaJagAGUF3",
      "expanded_url" : "http:\/\/go.wh.gov\/VUDrpi",
      "display_url" : "go.wh.gov\/VUDrpi"
    } ]
  },
  "geo" : { },
  "id_str" : "388356395961040896",
  "text" : "Check out the dangers of default: some Republicans extreme positions vs. financial experts. --&gt; http:\/\/t.co\/RaJagAGUF3",
  "id" : 388356395961040896,
  "created_at" : "2013-10-10 17:32:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/X7PzdFsJwx",
      "expanded_url" : "http:\/\/goo.gl\/e05ly6",
      "display_url" : "goo.gl\/e05ly6"
    } ]
  },
  "geo" : { },
  "id_str" : "388332968566980608",
  "text" : "RT @Cecilia44: Will never understand shutting down the govt to prevent this http:\/\/t.co\/X7PzdFsJwx \"Obamacare Saved My Family From Financia\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/X7PzdFsJwx",
        "expanded_url" : "http:\/\/goo.gl\/e05ly6",
        "display_url" : "goo.gl\/e05ly6"
      } ]
    },
    "geo" : { },
    "id_str" : "388306753219088384",
    "text" : "Will never understand shutting down the govt to prevent this http:\/\/t.co\/X7PzdFsJwx \"Obamacare Saved My Family From Financial Ruin\" #ACA",
    "id" : 388306753219088384,
    "created_at" : "2013-10-10 14:15:19 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 388332968566980608,
  "created_at" : "2013-10-10 15:59:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/388100729262452736\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/3gWJORALAG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BWLPjoZCMAEdVk3.jpg",
      "id_str" : "388100728952074241",
      "id" : 388100728952074241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BWLPjoZCMAEdVk3.jpg",
      "sizes" : [ {
        "h" : 911,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1994,
        "resize" : "fit",
        "w" : 1314
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1554,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3gWJORALAG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/4k2sOP8wfD",
      "expanded_url" : "http:\/\/go.wh.gov\/1m5AzK",
      "display_url" : "go.wh.gov\/1m5AzK"
    } ]
  },
  "geo" : { },
  "id_str" : "388100729262452736",
  "text" : "President Obama introduces the new Fed Chair nominee --&gt; http:\/\/t.co\/4k2sOP8wfD http:\/\/t.co\/3gWJORALAG",
  "id" : 388100729262452736,
  "created_at" : "2013-10-10 00:36:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "388048580805529600",
  "text" : "RT @HealthCareTara: In Belleville, IL, a cook could ge bronze plan for $23 a mo. or a silver plan for $89 a month, after the tax credit. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/5BacCD3TFs",
        "expanded_url" : "http:\/\/bit.ly\/18PL1wJ",
        "display_url" : "bit.ly\/18PL1wJ"
      } ]
    },
    "geo" : { },
    "id_str" : "388044920797147136",
    "text" : "In Belleville, IL, a cook could ge bronze plan for $23 a mo. or a silver plan for $89 a month, after the tax credit. http:\/\/t.co\/5BacCD3TFs",
    "id" : 388044920797147136,
    "created_at" : "2013-10-09 20:54:53 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 388048580805529600,
  "created_at" : "2013-10-09 21:09:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/LHdFZ2YvGb",
      "expanded_url" : "http:\/\/youtu.be\/kB4d9lAr53E",
      "display_url" : "youtu.be\/kB4d9lAr53E"
    } ]
  },
  "geo" : { },
  "id_str" : "388044008305348609",
  "text" : "RT @DeptVetAffairs: Sec. Shinseki explains how the government shutdown impacts millions of Veterans http:\/\/t.co\/LHdFZ2YvGb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/LHdFZ2YvGb",
        "expanded_url" : "http:\/\/youtu.be\/kB4d9lAr53E",
        "display_url" : "youtu.be\/kB4d9lAr53E"
      } ]
    },
    "geo" : { },
    "id_str" : "388022878530068480",
    "text" : "Sec. Shinseki explains how the government shutdown impacts millions of Veterans http:\/\/t.co\/LHdFZ2YvGb",
    "id" : 388022878530068480,
    "created_at" : "2013-10-09 19:27:18 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 388044008305348609,
  "created_at" : "2013-10-09 20:51:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387987223586435073",
  "text" : "RT @Simas44: Worth a read. GOP refused budget negotiations b\/c they believed they'd get better deal threatening default. http:\/\/t.co\/htDWuz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JustVote",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/htDWuzakRz",
        "expanded_url" : "http:\/\/nym.ag\/1bbt2AZ",
        "display_url" : "nym.ag\/1bbt2AZ"
      } ]
    },
    "geo" : { },
    "id_str" : "387971200116224000",
    "text" : "Worth a read. GOP refused budget negotiations b\/c they believed they'd get better deal threatening default. http:\/\/t.co\/htDWuzakRz #JustVote",
    "id" : 387971200116224000,
    "created_at" : "2013-10-09 16:01:56 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 387987223586435073,
  "created_at" : "2013-10-09 17:05:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/F85mfo3EQR",
      "expanded_url" : "http:\/\/go.wh.gov\/T5hAuZ",
      "display_url" : "go.wh.gov\/T5hAuZ"
    } ]
  },
  "geo" : { },
  "id_str" : "387706657754476544",
  "text" : "Watch the President explain why he won't allow Congress to hold the economy ransom. #JustVote --&gt; http:\/\/t.co\/F85mfo3EQR",
  "id" : 387706657754476544,
  "created_at" : "2013-10-08 22:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 109, 113 ],
      "id_str" : "28785486",
      "id" : 28785486
    }, {
      "name" : "CNN",
      "screen_name" : "CNN",
      "indices" : [ 114, 118 ],
      "id_str" : "759251",
      "id" : 759251
    }, {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "indices" : [ 119, 127 ],
      "id_str" : "14173315",
      "id" : 14173315
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387649679833309184",
  "text" : "RT @Schultz44: These four news outlets all report enough House members support clean CR it would pass today: @ABC @CNN @NBCNews @washington\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ABC News",
        "screen_name" : "ABC",
        "indices" : [ 94, 98 ],
        "id_str" : "28785486",
        "id" : 28785486
      }, {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 99, 103 ],
        "id_str" : "759251",
        "id" : 759251
      }, {
        "name" : "NBC News",
        "screen_name" : "NBCNews",
        "indices" : [ 104, 112 ],
        "id_str" : "14173315",
        "id" : 14173315
      }, {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 113, 128 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387646073059020800",
    "text" : "These four news outlets all report enough House members support clean CR it would pass today: @ABC @CNN @NBCNews @washingtonpost",
    "id" : 387646073059020800,
    "created_at" : "2013-10-08 18:30:00 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 387649679833309184,
  "created_at" : "2013-10-08 18:44:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387646374168104960",
  "text" : "RT if you agree with President Obama that we can't make extortion routine as part of our democracy. #JustVote",
  "id" : 387646374168104960,
  "created_at" : "2013-10-08 18:31:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387644921181532160",
  "text" : "Obama: \"Nobody in the past has ever seriously threatened to breach the debt ceiling until the last two years.\"",
  "id" : 387644921181532160,
  "created_at" : "2013-10-08 18:25:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 23, 32 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387643767475294208",
  "text" : "Obama: \"Let's end this #shutdown and put people back to work... that vote could take place today.\" #JustVote",
  "id" : 387643767475294208,
  "created_at" : "2013-10-08 18:20:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/62dHpBUgwJ",
      "expanded_url" : "http:\/\/whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "387613393684676608",
  "text" : "Happening today: at 2pm ET, the President will answer questions from the White House. Watch live at: http:\/\/t.co\/62dHpBUgwJ",
  "id" : 387613393684676608,
  "created_at" : "2013-10-08 16:20:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 28, 43 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/tQIhPqS77R",
      "expanded_url" : "http:\/\/go.wh.gov\/Au43NP",
      "display_url" : "go.wh.gov\/Au43NP"
    } ]
  },
  "geo" : { },
  "id_str" : "387607432249098241",
  "text" : "See what the President told @SpeakerBoehner earlier today: http:\/\/t.co\/tQIhPqS77R #JustVote",
  "id" : 387607432249098241,
  "created_at" : "2013-10-08 15:56:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 17, 32 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 54, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/0qXmJ26xBi",
      "expanded_url" : "http:\/\/on.cnn.com\/1a7tq19",
      "display_url" : "on.cnn.com\/1a7tq19"
    } ]
  },
  "geo" : { },
  "id_str" : "387580902642958337",
  "text" : "Still a FACT: if @SpeakerBoehner allowed the House to #JustVote, we could end the shutdown today. --&gt; http:\/\/t.co\/0qXmJ26xBi",
  "id" : 387580902642958337,
  "created_at" : "2013-10-08 14:11:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 63, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/q8kxfiJ5gq",
      "expanded_url" : "http:\/\/go.wh.gov\/wuwTT2",
      "display_url" : "go.wh.gov\/wuwTT2"
    } ]
  },
  "geo" : { },
  "id_str" : "387351826036580352",
  "text" : "President Obama at FEMA: \"Hold a vote. Call a vote right now.\" #JustVote --&gt; http:\/\/t.co\/q8kxfiJ5gq",
  "id" : 387351826036580352,
  "created_at" : "2013-10-07 23:00:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387303486989152256",
  "text" : "RT @Sebelius: With better coverage at a better price Kate &amp; Caroline are enrolling in the Health Insurance Marketplace http:\/\/t.co\/makirUeu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 132, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/makirUeuJR",
        "expanded_url" : "http:\/\/1.usa.gov\/1fdsIGN",
        "display_url" : "1.usa.gov\/1fdsIGN"
      } ]
    },
    "geo" : { },
    "id_str" : "387293847396438016",
    "text" : "With better coverage at a better price Kate &amp; Caroline are enrolling in the Health Insurance Marketplace http:\/\/t.co\/makirUeuJR #GetCovered",
    "id" : 387293847396438016,
    "created_at" : "2013-10-07 19:10:23 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 387303486989152256,
  "created_at" : "2013-10-07 19:48:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 16, 21 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387290235811282944",
  "text" : "RT @vj44: Potus @FEMA \"The reason Speaker Boehner won't hold a vote at the moment is apparently he doesn't want the shutdown to end.\" #Just\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FEMA",
        "screen_name" : "fema",
        "indices" : [ 6, 11 ],
        "id_str" : "16669075",
        "id" : 16669075
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JustVote",
        "indices" : [ 124, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387271122124685312",
    "text" : "Potus @FEMA \"The reason Speaker Boehner won't hold a vote at the moment is apparently he doesn't want the shutdown to end.\" #JustVote",
    "id" : 387271122124685312,
    "created_at" : "2013-10-07 17:40:05 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 387290235811282944,
  "created_at" : "2013-10-07 18:56:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "387240290026651649",
  "text" : "RT @Simas44: Fact: Speaker Boehner has the power to end the shutdown today. A majority of the House is on the record supporting a clean CR.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JustVote",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "387237815597027328",
    "text" : "Fact: Speaker Boehner has the power to end the shutdown today. A majority of the House is on the record supporting a clean CR. #JustVote",
    "id" : 387237815597027328,
    "created_at" : "2013-10-07 15:27:44 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 387240290026651649,
  "created_at" : "2013-10-07 15:37:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/386584769422561281\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/R1nMioTfvz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BV1szKvCMAEisTo.jpg",
      "id_str" : "386584769334489089",
      "id" : 386584769334489089,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BV1szKvCMAEisTo.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/R1nMioTfvz"
    } ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386584769422561281",
  "text" : "\"You don't save money by not paying your bills... you're a deadbeat.\" RT if you agree Congress should #JustVote. http:\/\/t.co\/R1nMioTfvz",
  "id" : 386584769422561281,
  "created_at" : "2013-10-05 20:12:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GovernmentShutdown",
      "indices" : [ 43, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/PeA2ymUv2d",
      "expanded_url" : "http:\/\/go.wh.gov\/Jmc8FG",
      "display_url" : "go.wh.gov\/Jmc8FG"
    } ]
  },
  "geo" : { },
  "id_str" : "386581203135893505",
  "text" : "President Obama's Weekly Address: End This #GovernmentShutdown --&gt; http:\/\/t.co\/PeA2ymUv2d",
  "id" : 386581203135893505,
  "created_at" : "2013-10-05 19:58:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 48, 57 ]
    }, {
      "text" : "Shutdown",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386253840497930240",
  "text" : "RT if you agree: It's past time for Congress to #JustVote and end this #Shutdown.",
  "id" : 386253840497930240,
  "created_at" : "2013-10-04 22:17:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/3Or8R79jPD",
      "expanded_url" : "http:\/\/go.wh.gov\/YhJvog",
      "display_url" : "go.wh.gov\/YhJvog"
    } ]
  },
  "geo" : { },
  "id_str" : "386245440460443648",
  "text" : "Check out the \"#JustVote, and end this shutdown\" edition of West Wing Week --&gt; http:\/\/t.co\/3Or8R79jPD",
  "id" : 386245440460443648,
  "created_at" : "2013-10-04 21:44:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/386171482021191680\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/VYWFNidY2U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVv06q8CAAESmB2.jpg",
      "id_str" : "386171481865977857",
      "id" : 386171481865977857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVv06q8CAAESmB2.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/VYWFNidY2U"
    } ],
    "hashtags" : [ {
      "text" : "Shutdown",
      "indices" : [ 36, 45 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/lyGKGAF0Vi",
      "expanded_url" : "http:\/\/go.wh.gov\/8ESBQ8",
      "display_url" : "go.wh.gov\/8ESBQ8"
    } ]
  },
  "geo" : { },
  "id_str" : "386171482021191680",
  "text" : "Make your voice heard: what has the #Shutdown meant for you? Let us know at: http:\/\/t.co\/lyGKGAF0Vi #JustVote http:\/\/t.co\/VYWFNidY2U",
  "id" : 386171482021191680,
  "created_at" : "2013-10-04 16:50:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 14, 21 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Yahoo Shine",
      "screen_name" : "YahooShine",
      "indices" : [ 65, 76 ],
      "id_str" : "3241885739",
      "id" : 3241885739
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/TxdxSFgm5r",
      "expanded_url" : "http:\/\/yhoo.it\/GCD2sO",
      "display_url" : "yhoo.it\/GCD2sO"
    } ]
  },
  "geo" : { },
  "id_str" : "386158997855666176",
  "text" : "Worth a read: @FLOTUS explains why mothers should #GetCovered in @YahooShine op-ed \u2014&gt; http:\/\/t.co\/TxdxSFgm5r",
  "id" : 386158997855666176,
  "created_at" : "2013-10-04 16:00:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GovernmentShutdown",
      "indices" : [ 15, 34 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386154177065279488",
  "text" : "FACT: Day 4 of #GovernmentShutdown and nothing has changed: if the House would #JustVote, a bipartisan majority would reopen the government.",
  "id" : 386154177065279488,
  "created_at" : "2013-10-04 15:41:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GovernmentShutdown",
      "indices" : [ 21, 40 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/lyGKGAF0Vi",
      "expanded_url" : "http:\/\/go.wh.gov\/8ESBQ8",
      "display_url" : "go.wh.gov\/8ESBQ8"
    } ]
  },
  "geo" : { },
  "id_str" : "386127535622221824",
  "text" : "Tell us: how has the #GovernmentShutdown affected you? \u2014&gt; http:\/\/t.co\/lyGKGAF0Vi #JustVote",
  "id" : 386127535622221824,
  "created_at" : "2013-10-04 13:55:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 112, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "386122049384505344",
  "text" : "RT @Simas44: Meet the AL Rand Paul Republican who bought an ACA plan and wants the GOP to stop the obstruction. #GetCovered http:\/\/t.co\/5C5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 99, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/5C5hseJf4Q",
        "expanded_url" : "http:\/\/bit.ly\/1hpKCmw",
        "display_url" : "bit.ly\/1hpKCmw"
      } ]
    },
    "geo" : { },
    "id_str" : "386118173902127104",
    "text" : "Meet the AL Rand Paul Republican who bought an ACA plan and wants the GOP to stop the obstruction. #GetCovered http:\/\/t.co\/5C5hseJf4Q",
    "id" : 386118173902127104,
    "created_at" : "2013-10-04 13:18:41 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 386122049384505344,
  "created_at" : "2013-10-04 13:34:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/MlsSyZW76r",
      "expanded_url" : "http:\/\/bit.ly\/18yBx8Z",
      "display_url" : "bit.ly\/18yBx8Z"
    } ]
  },
  "geo" : { },
  "id_str" : "385855624824643584",
  "text" : "RT @vj44: Check out Mama Care http:\/\/t.co\/MlsSyZW76r and #GetCovered",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 47, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/MlsSyZW76r",
        "expanded_url" : "http:\/\/bit.ly\/18yBx8Z",
        "display_url" : "bit.ly\/18yBx8Z"
      } ]
    },
    "geo" : { },
    "id_str" : "385853729737433089",
    "text" : "Check out Mama Care http:\/\/t.co\/MlsSyZW76r and #GetCovered",
    "id" : 385853729737433089,
    "created_at" : "2013-10-03 19:47:52 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 385855624824643584,
  "created_at" : "2013-10-03 19:55:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    }, {
      "name" : "Southwest Airlines",
      "screen_name" : "SouthwestAir",
      "indices" : [ 83, 96 ],
      "id_str" : "7212562",
      "id" : 7212562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/lTUYvKm3GB",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "385817788616425472",
  "text" : "RT @Sebelius: http:\/\/t.co\/lTUYvKm3GB: 7 mill visitors in two days. More than visit @SouthwestAir site in a month.  People are excited to  #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Southwest Airlines",
        "screen_name" : "SouthwestAir",
        "indices" : [ 69, 82 ],
        "id_str" : "7212562",
        "id" : 7212562
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 124, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/lTUYvKm3GB",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "385812428744704000",
    "text" : "http:\/\/t.co\/lTUYvKm3GB: 7 mill visitors in two days. More than visit @SouthwestAir site in a month.  People are excited to  #GetCovered",
    "id" : 385812428744704000,
    "created_at" : "2013-10-03 17:03:45 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 385817788616425472,
  "created_at" : "2013-10-03 17:25:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 85, 100 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOPshutdown",
      "indices" : [ 24, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/p8bUuCjNVB",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/wonkblog\/wp\/2013\/10\/03\/how-the-shutdown-hurts-the-economy-in-one-chart\/",
      "display_url" : "washingtonpost.com\/blogs\/wonkblog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "385799467317751808",
  "text" : "RT @PressSec: Effect of #GOPshutdown on economy, in 1 chart: http:\/\/t.co\/p8bUuCjNVB. @SpeakerBoehner can end this now by letting majority r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 71, 86 ],
        "id_str" : "7713202",
        "id" : 7713202
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOPshutdown",
        "indices" : [ 10, 22 ]
      }, {
        "text" : "JustVote",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/p8bUuCjNVB",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/wonkblog\/wp\/2013\/10\/03\/how-the-shutdown-hurts-the-economy-in-one-chart\/",
        "display_url" : "washingtonpost.com\/blogs\/wonkblog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "385795726921326594",
    "text" : "Effect of #GOPshutdown on economy, in 1 chart: http:\/\/t.co\/p8bUuCjNVB. @SpeakerBoehner can end this now by letting majority rule. #JustVote",
    "id" : 385795726921326594,
    "created_at" : "2013-10-03 15:57:23 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 385799467317751808,
  "created_at" : "2013-10-03 16:12:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 8, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385786556738326529",
  "text" : "Obama: \"#JustVote, end this shutdown today... we can get back to growing this economy, creating jobs, and strengthening the middle class.\"",
  "id" : 385786556738326529,
  "created_at" : "2013-10-03 15:20:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385785942637674496",
  "text" : "Obama: \"You don\u2019t get to demand ransom in exchange for keeping the government running... for doing your most basic job.\" #JustVote",
  "id" : 385785942637674496,
  "created_at" : "2013-10-03 15:18:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385785376201134080",
  "text" : "Obama: \"As reckless as a government shutdown is... an economic shutdown that results from default would be dramatically worse.\" #JustVote",
  "id" : 385785376201134080,
  "created_at" : "2013-10-03 15:16:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 111, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385783653155893248",
  "text" : "Obama: It's clear \"they do want health insurance...  More than six million people visited\" the day it opened.\" #GetCovered",
  "id" : 385783653155893248,
  "created_at" : "2013-10-03 15:09:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 47, 56 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385782752903061504",
  "text" : "Obama: \"Take a vote, stop this farce, end this #shutdown right now!\" #JustVote",
  "id" : 385782752903061504,
  "created_at" : "2013-10-03 15:05:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385782307291820032",
  "text" : "Obama: \"You already get to serve the American people.  There is no higher honor than that.\" #JustVote",
  "id" : 385782307291820032,
  "created_at" : "2013-10-03 15:04:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385780635635167232",
  "text" : "Obama: \"The American people elected their representatives to make their lives easier, not harder.\" #JustVote",
  "id" : 385780635635167232,
  "created_at" : "2013-10-03 14:57:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GovernmentShutdown",
      "indices" : [ 41, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/hnZyyGUP6c",
      "expanded_url" : "http:\/\/go.wh.gov\/bCCPP9",
      "display_url" : "go.wh.gov\/bCCPP9"
    } ]
  },
  "geo" : { },
  "id_str" : "385778855245406208",
  "text" : "Right now: President Obama speaks on the #GovernmentShutdown \u2014&gt; http:\/\/t.co\/hnZyyGUP6c",
  "id" : 385778855245406208,
  "created_at" : "2013-10-03 14:50:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 6, 21 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GovernmentShutdown",
      "indices" : [ 63, 82 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385775200819621888",
  "text" : "FACT: @SpeakerBoehner could pass a clean resolution to end the #GovernmentShutdown today. #JustVote",
  "id" : 385775200819621888,
  "created_at" : "2013-10-03 14:35:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/toebRaRZcb",
      "expanded_url" : "http:\/\/huff.to\/1brDbKM",
      "display_url" : "huff.to\/1brDbKM"
    } ]
  },
  "geo" : { },
  "id_str" : "385770737761386496",
  "text" : "FACT: At least 20 House Republicans have publicly supported a clean bill to reopen the government. #JustVote \u2014&gt; http:\/\/t.co\/toebRaRZcb",
  "id" : 385770737761386496,
  "created_at" : "2013-10-03 14:18:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Shutdown",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/hnZyyGUP6c",
      "expanded_url" : "http:\/\/go.wh.gov\/bCCPP9",
      "display_url" : "go.wh.gov\/bCCPP9"
    } ]
  },
  "geo" : { },
  "id_str" : "385765774939275265",
  "text" : "Watch at 10:40am ET: President Obama's remarks at M. Luis Construction Company \u2014&gt;  http:\/\/t.co\/hnZyyGUP6c #Shutdown",
  "id" : 385765774939275265,
  "created_at" : "2013-10-03 13:58:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385556179369205760",
  "text" : "RT @Simas44: \u201CI still am a very strong Republican, but this.. I\u2019m so happy that this came along,\u201D ACA saves $13k p\/yr. #GetCovered http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 106, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ApsHb9NJnZ",
        "expanded_url" : "http:\/\/bit.ly\/1g4F8j8",
        "display_url" : "bit.ly\/1g4F8j8"
      } ]
    },
    "geo" : { },
    "id_str" : "385515939313098752",
    "text" : "\u201CI still am a very strong Republican, but this.. I\u2019m so happy that this came along,\u201D ACA saves $13k p\/yr. #GetCovered http:\/\/t.co\/ApsHb9NJnZ",
    "id" : 385515939313098752,
    "created_at" : "2013-10-02 21:25:37 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 385556179369205760,
  "created_at" : "2013-10-03 00:05:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getcovered",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/4dcJv7cOyk",
      "expanded_url" : "http:\/\/www.healthcare.gov\/",
      "display_url" : "healthcare.gov"
    }, {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/m3ReJ5SQFN",
      "expanded_url" : "http:\/\/instagram.com\/p\/e-rdm9gBjx\/",
      "display_url" : "instagram.com\/p\/e-rdm9gBjx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "385528060495138816",
  "text" : "RT @kerrywashington: #getcovered\nhttp:\/\/t.co\/4dcJv7cOyk http:\/\/t.co\/m3ReJ5SQFN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getcovered",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/4dcJv7cOyk",
        "expanded_url" : "http:\/\/www.healthcare.gov\/",
        "display_url" : "healthcare.gov"
      }, {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/m3ReJ5SQFN",
        "expanded_url" : "http:\/\/instagram.com\/p\/e-rdm9gBjx\/",
        "display_url" : "instagram.com\/p\/e-rdm9gBjx\/"
      } ]
    },
    "geo" : { },
    "id_str" : "385510931754930176",
    "text" : "#getcovered\nhttp:\/\/t.co\/4dcJv7cOyk http:\/\/t.co\/m3ReJ5SQFN",
    "id" : 385510931754930176,
    "created_at" : "2013-10-02 21:05:43 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 385528060495138816,
  "created_at" : "2013-10-02 22:13:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/385513358180376576\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/if9d16ok9V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVmeW1MCYAAlCor.jpg",
      "id_str" : "385513358188765184",
      "id" : 385513358188765184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVmeW1MCYAAlCor.jpg",
      "sizes" : [ {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/if9d16ok9V"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/pnh5afe3tX",
      "expanded_url" : "http:\/\/www.healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "385516729050230784",
  "text" : "RT @vj44: Put your Mom at ease already, and #GetCovered!  Sign up for healthcare NOW at http:\/\/t.co\/pnh5afe3tX ! http:\/\/t.co\/if9d16ok9V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/385513358180376576\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/if9d16ok9V",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVmeW1MCYAAlCor.jpg",
        "id_str" : "385513358188765184",
        "id" : 385513358188765184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVmeW1MCYAAlCor.jpg",
        "sizes" : [ {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1529,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/if9d16ok9V"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 34, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/pnh5afe3tX",
        "expanded_url" : "http:\/\/www.healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "385513358180376576",
    "text" : "Put your Mom at ease already, and #GetCovered!  Sign up for healthcare NOW at http:\/\/t.co\/pnh5afe3tX ! http:\/\/t.co\/if9d16ok9V",
    "id" : 385513358180376576,
    "created_at" : "2013-10-02 21:15:21 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 385516729050230784,
  "created_at" : "2013-10-02 21:28:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "xoxo, Joanne",
      "screen_name" : "ladygaga",
      "indices" : [ 3, 12 ],
      "id_str" : "14230524",
      "id" : 14230524
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ladygaga\/status\/385505073033261056\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/K0vvb70yRG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVmW0kmCMAAbGYx.jpg",
      "id_str" : "385505073037455360",
      "id" : 385505073037455360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVmW0kmCMAAbGYx.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1529
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1372,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/K0vvb70yRG"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/SgKBFOZB7j",
      "expanded_url" : "http:\/\/www.HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "385506364774031360",
  "text" : "RT @ladygaga: It's time to #GetCovered at http:\/\/t.co\/SgKBFOZB7j. http:\/\/t.co\/K0vvb70yRG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ladygaga\/status\/385505073033261056\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/K0vvb70yRG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVmW0kmCMAAbGYx.jpg",
        "id_str" : "385505073037455360",
        "id" : 385505073037455360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVmW0kmCMAAbGYx.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1529
        }, {
          "h" : 804,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1372,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/K0vvb70yRG"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 13, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/SgKBFOZB7j",
        "expanded_url" : "http:\/\/www.HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "385505073033261056",
    "text" : "It's time to #GetCovered at http:\/\/t.co\/SgKBFOZB7j. http:\/\/t.co\/K0vvb70yRG",
    "id" : 385505073033261056,
    "created_at" : "2013-10-02 20:42:26 +0000",
    "user" : {
      "name" : "xoxo, Joanne",
      "screen_name" : "ladygaga",
      "protected" : false,
      "id_str" : "14230524",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798442802111598596\/irVLjTuo_normal.jpg",
      "id" : 14230524,
      "verified" : true
    }
  },
  "id" : 385506364774031360,
  "created_at" : "2013-10-02 20:47:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pharrell Williams",
      "screen_name" : "Pharrell",
      "indices" : [ 3, 12 ],
      "id_str" : "338084918",
      "id" : 338084918
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Pharrell\/status\/385479341104439298\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/A7XPcdHJK7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVl_axOIYAAc37U.jpg",
      "id_str" : "385479340982820864",
      "id" : 385479340982820864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVl_axOIYAAc37U.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/A7XPcdHJK7"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 35, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/UXOCXTcNYT",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "385483381670019072",
  "text" : "RT @Pharrell: No health insurance? #GetCovered at http:\/\/t.co\/UXOCXTcNYT http:\/\/t.co\/A7XPcdHJK7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Pharrell\/status\/385479341104439298\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/A7XPcdHJK7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BVl_axOIYAAc37U.jpg",
        "id_str" : "385479340982820864",
        "id" : 385479340982820864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVl_axOIYAAc37U.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/A7XPcdHJK7"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 21, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/UXOCXTcNYT",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "385479341104439298",
    "text" : "No health insurance? #GetCovered at http:\/\/t.co\/UXOCXTcNYT http:\/\/t.co\/A7XPcdHJK7",
    "id" : 385479341104439298,
    "created_at" : "2013-10-02 19:00:11 +0000",
    "user" : {
      "name" : "Pharrell Williams",
      "screen_name" : "Pharrell",
      "protected" : false,
      "id_str" : "338084918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777892792328531968\/aRbbZcMo_normal.jpg",
      "id" : 338084918,
      "verified" : true
    }
  },
  "id" : 385483381670019072,
  "created_at" : "2013-10-02 19:16:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/385476798948978688\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/AQqnexc71V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVl9GyyCAAEe2el.jpg",
      "id_str" : "385476798781194241",
      "id" : 385476798781194241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVl9GyyCAAEe2el.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/AQqnexc71V"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "385476798948978688",
  "text" : "Millions of Americans are checking out the new insurance options at http:\/\/t.co\/GNfbftrfo3. #GetCovered http:\/\/t.co\/AQqnexc71V",
  "id" : 385476798948978688,
  "created_at" : "2013-10-02 18:50:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/v1f3Ukk4lz",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "385431407490629632",
  "text" : "RT @Simas44: Huge Day 1:  4.7 million visitors to http:\/\/t.co\/v1f3Ukk4lz. 190k calls. Americans are enrolling. Millions want to #GetCovered",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 115, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/v1f3Ukk4lz",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "385430845286137856",
    "text" : "Huge Day 1:  4.7 million visitors to http:\/\/t.co\/v1f3Ukk4lz. 190k calls. Americans are enrolling. Millions want to #GetCovered",
    "id" : 385430845286137856,
    "created_at" : "2013-10-02 15:47:29 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 385431407490629632,
  "created_at" : "2013-10-02 15:49:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/uWqlYvWZiI",
      "expanded_url" : "http:\/\/bit.ly\/1eZvBuH",
      "display_url" : "bit.ly\/1eZvBuH"
    } ]
  },
  "geo" : { },
  "id_str" : "385396450219151362",
  "text" : "RT @Schultz44: Cover Oregon: New health exchange swamped by 80,000 online visitors\nhttp:\/\/t.co\/uWqlYvWZiI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/uWqlYvWZiI",
        "expanded_url" : "http:\/\/bit.ly\/1eZvBuH",
        "display_url" : "bit.ly\/1eZvBuH"
      } ]
    },
    "geo" : { },
    "id_str" : "385385646443229184",
    "text" : "Cover Oregon: New health exchange swamped by 80,000 online visitors\nhttp:\/\/t.co\/uWqlYvWZiI",
    "id" : 385385646443229184,
    "created_at" : "2013-10-02 12:47:52 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 385396450219151362,
  "created_at" : "2013-10-02 13:30:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "385179500457127936",
  "text" : "RT @pfeiffer44: Every person who signed up for health care today is someone the GOP must take health insurance away from to achieve their u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "385167196604755968",
    "text" : "Every person who signed up for health care today is someone the GOP must take health insurance away from to achieve their ultimate goal.",
    "id" : 385167196604755968,
    "created_at" : "2013-10-01 22:19:50 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 385179500457127936,
  "created_at" : "2013-10-01 23:08:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/385166466141548544\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ECh9MHFEj4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BVhi3C-CcAAYbEV.jpg",
      "id_str" : "385166465969582080",
      "id" : 385166465969582080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BVhi3C-CcAAYbEV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/ECh9MHFEj4"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 78, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "385166466141548544",
  "text" : "Worth a RT: The #Obamacare marketplaces are open for business. Learn more and #GetCovered at http:\/\/t.co\/GNfbftrfo3 http:\/\/t.co\/ECh9MHFEj4",
  "id" : 385166466141548544,
  "created_at" : "2013-10-01 22:16:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/v1f3Ukk4lz",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "385135266807029760",
  "text" : "RT @Simas44: Since midnight, 2.8 million visits to http:\/\/t.co\/v1f3Ukk4lz and 81k calls. Millions want to #GetCovered.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 93, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/v1f3Ukk4lz",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "385130644520452096",
    "text" : "Since midnight, 2.8 million visits to http:\/\/t.co\/v1f3Ukk4lz and 81k calls. Millions want to #GetCovered.",
    "id" : 385130644520452096,
    "created_at" : "2013-10-01 19:54:35 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 385135266807029760,
  "created_at" : "2013-10-01 20:12:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/rtTXtCPFY8",
      "expanded_url" : "http:\/\/cour.at\/15IU1Ai",
      "display_url" : "cour.at\/15IU1Ai"
    } ]
  },
  "geo" : { },
  "id_str" : "385122511421071360",
  "text" : "RT @HealthCareTara: One Man's Experience As Health Exchange Begins Enrollment: 'It Made My Day' - http:\/\/t.co\/rtTXtCPFY8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/rtTXtCPFY8",
        "expanded_url" : "http:\/\/cour.at\/15IU1Ai",
        "display_url" : "cour.at\/15IU1Ai"
      } ]
    },
    "geo" : { },
    "id_str" : "385121656261197824",
    "text" : "One Man's Experience As Health Exchange Begins Enrollment: 'It Made My Day' - http:\/\/t.co\/rtTXtCPFY8",
    "id" : 385121656261197824,
    "created_at" : "2013-10-01 19:18:52 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 385122511421071360,
  "created_at" : "2013-10-01 19:22:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "385087470280269824",
  "text" : "Happening now: President Obama delivers a statement from the White House. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 385087470280269824,
  "created_at" : "2013-10-01 17:03:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "385081691301093376",
  "text" : "At 1:30pm ET, President Obama delivers a statement from the White House. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 385081691301093376,
  "created_at" : "2013-10-01 16:40:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GovernmentShutdown",
      "indices" : [ 67, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/U8k2eyeafo",
      "expanded_url" : "http:\/\/go.wh.gov\/59ru6u",
      "display_url" : "go.wh.gov\/59ru6u"
    } ]
  },
  "geo" : { },
  "id_str" : "385075402567200768",
  "text" : "Worth a read: President Obama's letter to federal employees on the #GovernmentShutdown. http:\/\/t.co\/U8k2eyeafo",
  "id" : 385075402567200768,
  "created_at" : "2013-10-01 16:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/v1f3Ukk4lz",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "385069368163328000",
  "text" : "RT @Simas44: Huge day one traffic to http:\/\/t.co\/v1f3Ukk4lz. 1 million so far. For the first time, people can compare &amp; choose plans w\/out \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/v1f3Ukk4lz",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "385067054111285248",
    "text" : "Huge day one traffic to http:\/\/t.co\/v1f3Ukk4lz. 1 million so far. For the first time, people can compare &amp; choose plans w\/out being denied.",
    "id" : 385067054111285248,
    "created_at" : "2013-10-01 15:41:54 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 385069368163328000,
  "created_at" : "2013-10-01 15:51:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 68, 78 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "385038312894758914",
  "text" : "Thanks to the House GOP, the government is shutting down. Thanks to #Obamacare, uninsured Americans can #GetCovered: http:\/\/t.co\/GNfbftrfo3",
  "id" : 385038312894758914,
  "created_at" : "2013-10-01 13:47:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]