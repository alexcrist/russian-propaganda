Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/318557933363396608\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/J4ZQgQxWY3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGu-wKsCAAAFuF2.jpg",
      "id_str" : "318557933371785216",
      "id" : 318557933371785216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGu-wKsCAAAFuF2.jpg",
      "sizes" : [ {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 573,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 430,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 573,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/J4ZQgQxWY3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318557933363396608",
  "text" : "Photo of the Day: President Obama &amp; family walk from the White House to attend Easter Service at St. John's Church: http:\/\/t.co\/J4ZQgQxWY3",
  "id" : 318557933363396608,
  "created_at" : "2013-04-01 02:58:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/RTwtV09l6b",
      "expanded_url" : "http:\/\/youtu.be\/gUmvsyQp3Fc",
      "display_url" : "youtu.be\/gUmvsyQp3Fc"
    } ]
  },
  "geo" : { },
  "id_str" : "318377810899116032",
  "text" : "\"Michelle and I wish you a blessed and joyful Easter. \" -President Obama in his Weekly Address: http:\/\/t.co\/RTwtV09l6b",
  "id" : 318377810899116032,
  "created_at" : "2013-03-31 15:02:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/RTwtV09l6b",
      "expanded_url" : "http:\/\/youtu.be\/gUmvsyQp3Fc",
      "display_url" : "youtu.be\/gUmvsyQp3Fc"
    } ]
  },
  "geo" : { },
  "id_str" : "318104253933699073",
  "text" : "President Obama: \"This weekend, I hope we\u2019re all able to take a moment to pause and reflect.\" Weekly Address: http:\/\/t.co\/RTwtV09l6b",
  "id" : 318104253933699073,
  "created_at" : "2013-03-30 20:55:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/RTwtV09l6b",
      "expanded_url" : "http:\/\/youtu.be\/gUmvsyQp3Fc",
      "display_url" : "youtu.be\/gUmvsyQp3Fc"
    } ]
  },
  "geo" : { },
  "id_str" : "317980322950176770",
  "text" : "In this week's address, President Obama offers Easter &amp; Passover greetings: http:\/\/t.co\/RTwtV09l6b",
  "id" : 317980322950176770,
  "created_at" : "2013-03-30 12:43:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/317827052030013440\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/68VHP1jXjm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGkmBRjCMAA4Kq4.jpg",
      "id_str" : "317827052038402048",
      "id" : 317827052038402048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGkmBRjCMAA4Kq4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/68VHP1jXjm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317827052030013440",
  "text" : "\"Building better roads &amp; bridges and schools, that's not a partisan idea.\" -President Obama at the Port of Miami: http:\/\/t.co\/68VHP1jXjm",
  "id" : 317827052030013440,
  "created_at" : "2013-03-30 02:34:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/317796834909253634\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/5Lt8eGpTlA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGkKiaACcAETWxQ.jpg",
      "id_str" : "317796834917642241",
      "id" : 317796834917642241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGkKiaACcAETWxQ.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/5Lt8eGpTlA"
    } ],
    "hashtags" : [ {
      "text" : "infrastructure",
      "indices" : [ 67, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/NDlxGmsAJm",
      "expanded_url" : "http:\/\/on.wh.gov\/wpTsuI2",
      "display_url" : "on.wh.gov\/wpTsuI2"
    } ]
  },
  "geo" : { },
  "id_str" : "317796834909253634",
  "text" : "President Obama has a plan to create jobs by investing in American #infrastructure: http:\/\/t.co\/NDlxGmsAJm Chart: http:\/\/t.co\/5Lt8eGpTlA",
  "id" : 317796834909253634,
  "created_at" : "2013-03-30 00:34:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infrastructure",
      "indices" : [ 91, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/aHZYWZsqmh",
      "expanded_url" : "http:\/\/on.wh.gov\/l0jyWvk",
      "display_url" : "on.wh.gov\/l0jyWvk"
    } ]
  },
  "geo" : { },
  "id_str" : "317759419058360320",
  "text" : "Full video: President Obama talks about his plan to put people to work rebuilding American #infrastructure: http:\/\/t.co\/aHZYWZsqmh",
  "id" : 317759419058360320,
  "created_at" : "2013-03-29 22:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Infrastructure",
      "indices" : [ 77, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/mOz4zx5B8W",
      "expanded_url" : "http:\/\/on.wh.gov\/fOOuAWB",
      "display_url" : "on.wh.gov\/fOOuAWB"
    } ]
  },
  "geo" : { },
  "id_str" : "317727708253650944",
  "text" : "Everything you need to know about President Obama's plan to improve American #Infrastructure: http:\/\/t.co\/mOz4zx5B8W",
  "id" : 317727708253650944,
  "created_at" : "2013-03-29 19:59:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infrastructure",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "317692935049183232",
  "text" : "Happening now: President Obama discusses his plan to invest in #infrastructure &amp; create jobs from Miami. Watch live: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 317692935049183232,
  "created_at" : "2013-03-29 17:41:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Newtown",
      "indices" : [ 86, 94 ]
    }, {
      "text" : "Nowisthetime",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Lbp6xb2T32",
      "expanded_url" : "http:\/\/youtu.be\/9RkoNe0k3HY",
      "display_url" : "youtu.be\/9RkoNe0k3HY"
    } ]
  },
  "geo" : { },
  "id_str" : "317477600723337217",
  "text" : "\"Shame on us if we've forgotten. I haven't forgotten those kids.\" -President Obama on #Newtown: http:\/\/t.co\/Lbp6xb2T32 #Nowisthetime",
  "id" : 317477600723337217,
  "created_at" : "2013-03-29 03:25:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nowisthetime",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/ZDVcb0w3DT",
      "expanded_url" : "http:\/\/on.wh.gov\/KHE7Lik",
      "display_url" : "on.wh.gov\/KHE7Lik"
    } ]
  },
  "geo" : { },
  "id_str" : "317432677252866048",
  "text" : "Don't miss this moment from President Obama's speech today on protecting our kids from gun violence: http:\/\/t.co\/ZDVcb0w3DT #Nowisthetime",
  "id" : 317432677252866048,
  "created_at" : "2013-03-29 00:27:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/zpEwkqlOv3",
      "expanded_url" : "http:\/\/on.wh.gov\/Q0WChqd",
      "display_url" : "on.wh.gov\/Q0WChqd"
    } ]
  },
  "geo" : { },
  "id_str" : "317397775828541440",
  "text" : "Today, the President stood with mothers who are urging Congress to take action to protect children from gun violence: http:\/\/t.co\/zpEwkqlOv3",
  "id" : 317397775828541440,
  "created_at" : "2013-03-28 22:08:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317364433989017600",
  "text" : "RT @jesseclee44: The moment today when President Obama went off the remarks he\u2019d prepared on protecting our kids from gun violence: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/l1MqPrVfcn",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Dk4GHWuyiG0#t=9m37s",
        "display_url" : "youtube.com\/watch?v=Dk4GHW\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "317362436497887233",
    "text" : "The moment today when President Obama went off the remarks he\u2019d prepared on protecting our kids from gun violence: http:\/\/t.co\/l1MqPrVfcn",
    "id" : 317362436497887233,
    "created_at" : "2013-03-28 19:47:55 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 317364433989017600,
  "created_at" : "2013-03-28 19:55:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 15, 25 ]
    }, {
      "text" : "Maker",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "317352030794551297",
  "text" : "Happening now: #WHHangout w\/ WH Innovation advisor Tom Kalil &amp; leading innovators on the #Maker Movement. Watch live: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 317352030794551297,
  "created_at" : "2013-03-28 19:06:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dale Dougherty",
      "screen_name" : "dalepd",
      "indices" : [ 43, 50 ],
      "id_str" : "14405393",
      "id" : 14405393
    }, {
      "name" : "Tara Tiger Brown \u24CB",
      "screen_name" : "tara",
      "indices" : [ 51, 56 ],
      "id_str" : "10959642",
      "id" : 10959642
    }, {
      "name" : "Otherlab",
      "screen_name" : "otherlab",
      "indices" : [ 57, 66 ],
      "id_str" : "57534593",
      "id" : 57534593
    }, {
      "name" : "Super-Awesome Sylvia",
      "screen_name" : "MakerSylvia",
      "indices" : [ 83, 95 ],
      "id_str" : "564157285",
      "id" : 564157285
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 8, 18 ]
    }, {
      "text" : "Maker",
      "indices" : [ 24, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "317341418223972352",
  "text" : "At 3ET: #WHHangout: The #Maker Movement w\/ @Dalepd @tara @otherlab's Saul Griffith @MakerSylvia &amp; Venkatesh Prasad: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 317341418223972352,
  "created_at" : "2013-03-28 18:24:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Super-Awesome Sylvia",
      "screen_name" : "MakerSylvia",
      "indices" : [ 3, 15 ],
      "id_str" : "564157285",
      "id" : 564157285
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 56, 67 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MakerSylvia\/status\/317062331643359232\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/EsO2d3W5hc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGZugsHCcAAzCrC.jpg",
      "id_str" : "317062331651747840",
      "id" : 317062331651747840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGZugsHCcAAzCrC.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1229,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/EsO2d3W5hc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "317324732020187137",
  "text" : "MT @MakerSylvia 1st test of WaterColorBot's drawing for @whitehouse G+ hangout! http:\/\/t.co\/EsO2d3W5hc \/\/ Watch @ 3ET http:\/\/t.co\/b4tqL3nPDV",
  "id" : 317324732020187137,
  "created_at" : "2013-03-28 17:18:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Super-Awesome Sylvia",
      "screen_name" : "MakerSylvia",
      "indices" : [ 3, 15 ],
      "id_str" : "564157285",
      "id" : 564157285
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 30, 41 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Maker",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317317253043466240",
  "text" : "RT @MakerSylvia: I'll be on a @whitehouse G+ hangout talking about the #Maker Movement Thursday @ 12pm PDT! Don't miss it, it's going to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 13, 24 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Maker",
        "indices" : [ 54, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316998906129031168",
    "text" : "I'll be on a @whitehouse G+ hangout talking about the #Maker Movement Thursday @ 12pm PDT! Don't miss it, it's going to be Super-Awesome!!",
    "id" : 316998906129031168,
    "created_at" : "2013-03-27 19:43:23 +0000",
    "user" : {
      "name" : "Super-Awesome Sylvia",
      "screen_name" : "MakerSylvia",
      "protected" : false,
      "id_str" : "564157285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736302176943771648\/3XIH-s8V_normal.jpg",
      "id" : 564157285,
      "verified" : false
    }
  },
  "id" : 317317253043466240,
  "created_at" : "2013-03-28 16:48:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsThe",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317307672129064962",
  "text" : "\"We have cried enough. We have known enough heartbreak...#NowIsThe time to turn that heartbreak into something real.\" \u2014President Obama",
  "id" : 317307672129064962,
  "created_at" : "2013-03-28 16:10:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Eda4lTRrzZ",
      "expanded_url" : "http:\/\/wh.gov\/nowisthetime",
      "display_url" : "wh.gov\/nowisthetime"
    } ]
  },
  "geo" : { },
  "id_str" : "317306788951252992",
  "text" : "\"Nothing is more powerful than millions of voices calling for change.\" \u2014President Obama: http:\/\/t.co\/Eda4lTRrzZ #NowIsTheTime",
  "id" : 317306788951252992,
  "created_at" : "2013-03-28 16:06:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317306086468251648",
  "text" : "President Obama: \"Right now, 90% of Americans \u2013 90 percent \u2013 support background checks that will keep criminals...from buying a gun.\"",
  "id" : 317306086468251648,
  "created_at" : "2013-03-28 16:04:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317306025202040832",
  "text" : "RT @WHLive: Obama: \"Why wouldn\u2019t we want to close the loophole that allows as many as 40% of gun purchases to take place without a backg ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "317305980813733888",
    "text" : "Obama: \"Why wouldn\u2019t we want to close the loophole that allows as many as 40% of gun purchases to take place without a background check?\"",
    "id" : 317305980813733888,
    "created_at" : "2013-03-28 16:03:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 317306025202040832,
  "created_at" : "2013-03-28 16:03:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317305913860050944",
  "text" : "\"Why wouldn\u2019t we want to make it more difficult for a dangerous person to get his or her hands on a gun?\"\u2014President Obama",
  "id" : 317305913860050944,
  "created_at" : "2013-03-28 16:03:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/K4rtItMtDb",
      "expanded_url" : "http:\/\/wh.gov\/nowisthetime",
      "display_url" : "wh.gov\/nowisthetime"
    } ]
  },
  "geo" : { },
  "id_str" : "317305826563985408",
  "text" : "RT @WHLive: Obama: \"This is our best chance in more than a decade to take commonsense steps that will save lives\" http:\/\/t.co\/K4rtItMtDb ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nowisthetime",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/K4rtItMtDb",
        "expanded_url" : "http:\/\/wh.gov\/nowisthetime",
        "display_url" : "wh.gov\/nowisthetime"
      } ]
    },
    "geo" : { },
    "id_str" : "317305606392410115",
    "text" : "Obama: \"This is our best chance in more than a decade to take commonsense steps that will save lives\" http:\/\/t.co\/K4rtItMtDb #Nowisthetime",
    "id" : 317305606392410115,
    "created_at" : "2013-03-28 16:02:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 317305826563985408,
  "created_at" : "2013-03-28 16:02:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nowisthetime",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317305700156059650",
  "text" : "RT @WHLive: President Obama: \"It is our first impulse, as parents, to do everything we can to protect our children from harm.\" #Nowisthetime",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nowisthetime",
        "indices" : [ 115, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "317305295292469248",
    "text" : "President Obama: \"It is our first impulse, as parents, to do everything we can to protect our children from harm.\" #Nowisthetime",
    "id" : 317305295292469248,
    "created_at" : "2013-03-28 16:00:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 317305700156059650,
  "created_at" : "2013-03-28 16:02:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowIsTheTime",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "317303613271703552",
  "text" : "Starting now: President Obama speaks on common-sense measures to protect children from gun violence: http:\/\/t.co\/b4tqL3nPDV #NowIsTheTime",
  "id" : 317303613271703552,
  "created_at" : "2013-03-28 15:54:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/u0vu2Mmdsv",
      "expanded_url" : "http:\/\/at.wh.gov\/jxGP8",
      "display_url" : "at.wh.gov\/jxGP8"
    } ]
  },
  "geo" : { },
  "id_str" : "317287223991091201",
  "text" : "Happening at 11:40ET: President Obama speaks on common sense measures to protect children from gun violence. Watch: http:\/\/t.co\/u0vu2Mmdsv",
  "id" : 317287223991091201,
  "created_at" : "2013-03-28 14:49:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/317075834848567298\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/fmQeov0Twa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGZ6yreCYAARdyE.jpg",
      "id_str" : "317075834856955904",
      "id" : 317075834856955904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGZ6yreCYAARdyE.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1004,
        "resize" : "fit",
        "w" : 1506
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fmQeov0Twa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317075834848567298",
  "text" : "Photo of the Day: President Obama greets Council of Economic Advisers staff in the Rose Garden of the White House: http:\/\/t.co\/fmQeov0Twa",
  "id" : 317075834848567298,
  "created_at" : "2013-03-28 00:49:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Univ. of Delaware",
      "screen_name" : "UDelaware",
      "indices" : [ 22, 32 ],
      "id_str" : "29447487",
      "id" : 29447487
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/317060834977280000\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/T2kZSaLQo8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGZtJkmCcAAGmwZ.jpg",
      "id_str" : "317060834985668608",
      "id" : 317060834985668608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGZtJkmCcAAGmwZ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 904,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 904,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 556,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/T2kZSaLQo8"
    } ],
    "hashtags" : [ {
      "text" : "BlueHens",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/XeTdXB11G4",
      "expanded_url" : "http:\/\/wh.gov\/being-biden",
      "display_url" : "wh.gov\/being-biden"
    } ]
  },
  "geo" : { },
  "id_str" : "317060834977280000",
  "text" : "VP Biden met with the @UDelaware #BlueHens after their victory. Here's what he had to say: http:\/\/t.co\/XeTdXB11G4 http:\/\/t.co\/T2kZSaLQo8",
  "id" : 317060834977280000,
  "created_at" : "2013-03-27 23:49:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 20, 23 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/317031372306911232\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/IMazoFDFLC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGZSWnmCEAES4aD.jpg",
      "id_str" : "317031372315299841",
      "id" : 317031372315299841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGZSWnmCEAES4aD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 780
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 780
      } ],
      "display_url" : "pic.twitter.com\/IMazoFDFLC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/egXOC1ujUv",
      "expanded_url" : "http:\/\/on.wh.gov\/oURPNjE",
      "display_url" : "on.wh.gov\/oURPNjE"
    } ]
  },
  "geo" : { },
  "id_str" : "317031372306911232",
  "text" : "The President &amp; @VP administer the oath of office to new Secret Service Director Julia Pierson http:\/\/t.co\/egXOC1ujUv http:\/\/t.co\/IMazoFDFLC",
  "id" : 317031372306911232,
  "created_at" : "2013-03-27 21:52:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "#BlueHens",
      "screen_name" : "UDBlueHens",
      "indices" : [ 104, 115 ],
      "id_str" : "31540323",
      "id" : 31540323
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBiden",
      "indices" : [ 22, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "317026695473426432",
  "text" : "RT @VP: In the latest #BeingBiden, the Vice President takes you into the locker room after last night's @udbluehens victory: https:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "#BlueHens",
        "screen_name" : "UDBlueHens",
        "indices" : [ 96, 107 ],
        "id_str" : "31540323",
        "id" : 31540323
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeingBiden",
        "indices" : [ 14, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Q6AsETlLyI",
        "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/vol-3-my-alma-mater",
        "display_url" : "soundcloud.com\/whitehouse\/vol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "317026112796508161",
    "text" : "In the latest #BeingBiden, the Vice President takes you into the locker room after last night's @udbluehens victory: https:\/\/t.co\/Q6AsETlLyI",
    "id" : 317026112796508161,
    "created_at" : "2013-03-27 21:31:30 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 317026695473426432,
  "created_at" : "2013-03-27 21:33:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "indices" : [ 3, 14 ],
      "id_str" : "5971922",
      "id" : 5971922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/HOQy7H0F13",
      "expanded_url" : "http:\/\/dlvr.it\/385lpS",
      "display_url" : "dlvr.it\/385lpS"
    } ]
  },
  "geo" : { },
  "id_str" : "316954134479773696",
  "text" : "RT @BoingBoing: Thursday: White House\/Tom Kalil Google Hangout about the maker movement http:\/\/t.co\/HOQy7H0F13",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/HOQy7H0F13",
        "expanded_url" : "http:\/\/dlvr.it\/385lpS",
        "display_url" : "dlvr.it\/385lpS"
      } ]
    },
    "geo" : { },
    "id_str" : "316953531397570560",
    "text" : "Thursday: White House\/Tom Kalil Google Hangout about the maker movement http:\/\/t.co\/HOQy7H0F13",
    "id" : 316953531397570560,
    "created_at" : "2013-03-27 16:43:05 +0000",
    "user" : {
      "name" : "Boing Boing",
      "screen_name" : "BoingBoing",
      "protected" : false,
      "id_str" : "5971922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616924998226153472\/0EfZYjr2_normal.png",
      "id" : 5971922,
      "verified" : true
    }
  },
  "id" : 316954134479773696,
  "created_at" : "2013-03-27 16:45:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "March of Dimes",
      "screen_name" : "MarchofDimes",
      "indices" : [ 61, 74 ],
      "id_str" : "8539242",
      "id" : 8539242
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/316734576997306368\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/F4RHqJWoMr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGVEa26CEAEA5iM.jpg",
      "id_str" : "316734577005694977",
      "id" : 316734577005694977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGVEa26CEAEA5iM.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/F4RHqJWoMr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316734576997306368",
  "text" : "Photo of the Day: President Obama signs memorabilia for 2013 @MarchofDimes Ambassador, 8-year-old Nina Centofanti: http:\/\/t.co\/F4RHqJWoMr",
  "id" : 316734576997306368,
  "created_at" : "2013-03-27 02:13:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#LAKings",
      "screen_name" : "LAKings",
      "indices" : [ 82, 90 ],
      "id_str" : "19013887",
      "id" : 19013887
    }, {
      "name" : "LA Galaxy",
      "screen_name" : "LAGalaxy",
      "indices" : [ 97, 106 ],
      "id_str" : "23011345",
      "id" : 23011345
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/316685613065707521\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Ze85am7YZe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGUX4yDCIAAiQE1.jpg",
      "id_str" : "316685613074096128",
      "id" : 316685613074096128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGUX4yDCIAAiQE1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/Ze85am7YZe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316685613065707521",
  "text" : "President Obama tosses a soccer ball after honoring the 2012 Championship winning @LAKings &amp; @LAGalaxy at the WH: http:\/\/t.co\/Ze85am7YZe",
  "id" : 316685613065707521,
  "created_at" : "2013-03-26 22:58:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#LAKings",
      "screen_name" : "LAKings",
      "indices" : [ 63, 71 ],
      "id_str" : "19013887",
      "id" : 19013887
    }, {
      "name" : "LA Galaxy",
      "screen_name" : "LAGalaxy",
      "indices" : [ 95, 104 ],
      "id_str" : "23011345",
      "id" : 23011345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/QxORGSXDlM",
      "expanded_url" : "http:\/\/at.wh.gov\/jr8To",
      "display_url" : "at.wh.gov\/jr8To"
    } ]
  },
  "geo" : { },
  "id_str" : "316610232782565376",
  "text" : "Happening now: President Obama honors the Stanley Cup champion @LAKings &amp; MLS Cup champion @LAGalaxy at the WH: http:\/\/t.co\/QxORGSXDlM",
  "id" : 316610232782565376,
  "created_at" : "2013-03-26 17:58:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#LAKings",
      "screen_name" : "LAKings",
      "indices" : [ 68, 76 ],
      "id_str" : "19013887",
      "id" : 19013887
    }, {
      "name" : "LA Galaxy",
      "screen_name" : "LAGalaxy",
      "indices" : [ 100, 109 ],
      "id_str" : "23011345",
      "id" : 23011345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/rPPi2Y2D0Y",
      "expanded_url" : "http:\/\/at.wh.gov\/jqQxR",
      "display_url" : "at.wh.gov\/jqQxR"
    } ]
  },
  "geo" : { },
  "id_str" : "316581611229564928",
  "text" : "Starting at 1:45ET: President Obama honors the Stanley Cup champion @LAKings &amp; MLS Cup champion @LAGalaxy at the WH: http:\/\/t.co\/rPPi2Y2D0Y",
  "id" : 316581611229564928,
  "created_at" : "2013-03-26 16:05:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/Kj7DDLKdXd",
      "expanded_url" : "http:\/\/bit.ly\/YB2rJn",
      "display_url" : "bit.ly\/YB2rJn"
    } ]
  },
  "geo" : { },
  "id_str" : "316380645213483009",
  "text" : "RT @petesouza: Photo of POTUS at Passover Seder Dinner: http:\/\/t.co\/Kj7DDLKdXd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/Kj7DDLKdXd",
        "expanded_url" : "http:\/\/bit.ly\/YB2rJn",
        "display_url" : "bit.ly\/YB2rJn"
      } ]
    },
    "geo" : { },
    "id_str" : "316354434911334400",
    "text" : "Photo of POTUS at Passover Seder Dinner: http:\/\/t.co\/Kj7DDLKdXd",
    "id" : 316354434911334400,
    "created_at" : "2013-03-26 01:02:29 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 316380645213483009,
  "created_at" : "2013-03-26 02:46:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/z9IMpL3WWo",
      "expanded_url" : "http:\/\/at.wh.gov\/jpmtx",
      "display_url" : "at.wh.gov\/jpmtx"
    } ]
  },
  "geo" : { },
  "id_str" : "316376599253643264",
  "text" : "\"Immigration makes us a stronger. It keeps us vibrant. It keeps us hungry. It keeps us prosperous.\" \u2014President Obama: http:\/\/t.co\/z9IMpL3WWo",
  "id" : 316376599253643264,
  "created_at" : "2013-03-26 02:30:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/qLxKGsMIlP",
      "expanded_url" : "http:\/\/at.wh.gov\/jpdb4",
      "display_url" : "at.wh.gov\/jpdb4"
    } ]
  },
  "geo" : { },
  "id_str" : "316326280356323328",
  "text" : "Full video: President Obama speaks at a naturalization ceremony ceremony for active duty service members &amp; civilians: http:\/\/t.co\/qLxKGsMIlP",
  "id" : 316326280356323328,
  "created_at" : "2013-03-25 23:10:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Passover",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/0n9wTSvw4b",
      "expanded_url" : "http:\/\/at.wh.gov\/jpdO7",
      "display_url" : "at.wh.gov\/jpdO7"
    } ]
  },
  "geo" : { },
  "id_str" : "316306270716055552",
  "text" : "\"A story of perseverance amidst persecution\" \u2014President Obama reflects on the importance of #Passover: http:\/\/t.co\/0n9wTSvw4b",
  "id" : 316306270716055552,
  "created_at" : "2013-03-25 21:51:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/316288923120852992\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/kgE82v6BQZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGOvGY2CYAATClv.jpg",
      "id_str" : "316288923129241600",
      "id" : 316288923129241600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGOvGY2CYAATClv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/kgE82v6BQZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/oW3khH0qJn",
      "expanded_url" : "http:\/\/on.wh.gov\/oqZNBm8",
      "display_url" : "on.wh.gov\/oqZNBm8"
    } ]
  },
  "geo" : { },
  "id_str" : "316288923120852992",
  "text" : "Behind-the-scenes Photo Gallery: President Obama's Middle East trip: http:\/\/t.co\/oW3khH0qJn The President tours Petra http:\/\/t.co\/kgE82v6BQZ",
  "id" : 316288923120852992,
  "created_at" : "2013-03-25 20:42:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Monuments",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DRsbCPgdZ6",
      "expanded_url" : "http:\/\/on.doi.gov\/10detHb",
      "display_url" : "on.doi.gov\/10detHb"
    } ]
  },
  "geo" : { },
  "id_str" : "316270153321041920",
  "text" : "RT @Interior: Today, President Obama designated 5 new National #Monuments. See the full list, including photos here: http:\/\/t.co\/DRsbCPgdZ6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Monuments",
        "indices" : [ 49, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/DRsbCPgdZ6",
        "expanded_url" : "http:\/\/on.doi.gov\/10detHb",
        "display_url" : "on.doi.gov\/10detHb"
      } ]
    },
    "geo" : { },
    "id_str" : "316251120198623232",
    "text" : "Today, President Obama designated 5 new National #Monuments. See the full list, including photos here: http:\/\/t.co\/DRsbCPgdZ6",
    "id" : 316251120198623232,
    "created_at" : "2013-03-25 18:11:57 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 316270153321041920,
  "created_at" : "2013-03-25 19:27:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/piWK2kPF98",
      "expanded_url" : "http:\/\/at.wh.gov\/joRlw",
      "display_url" : "at.wh.gov\/joRlw"
    } ]
  },
  "geo" : { },
  "id_str" : "316251536219049984",
  "text" : "\"Michelle and I send our warmest wishes to all those celebrating Passover\" \u2014President Obama. Full statement: http:\/\/t.co\/piWK2kPF98",
  "id" : 316251536219049984,
  "created_at" : "2013-03-25 18:13:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 19, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316214160151154688",
  "text" : "President Obama on #ImmigrationReform: \"Let\u2019s get this done.  And let\u2019s do it in a way that keeps faith with our history and our values.\"",
  "id" : 316214160151154688,
  "created_at" : "2013-03-25 15:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigrationreform",
      "indices" : [ 46, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/Zn8x1DpIlx",
      "expanded_url" : "http:\/\/wh.gov\/immigration",
      "display_url" : "wh.gov\/immigration"
    } ]
  },
  "geo" : { },
  "id_str" : "316213760446590976",
  "text" : "\"The time has come for comprehensive sensible #immigrationreform.\" \u2014President Obama: http:\/\/t.co\/Zn8x1DpIlx",
  "id" : 316213760446590976,
  "created_at" : "2013-03-25 15:43:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316213431587987457",
  "text" : "President Obama: \"We\u2019ve always defined ourselves as a nation of immigrants. And we\u2019ve always been better off for it.\"",
  "id" : 316213431587987457,
  "created_at" : "2013-03-25 15:42:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316213362964967425",
  "text" : "President Obama: \"The point is: unless you\u2019re Native American, you came from somewhere else. \"",
  "id" : 316213362964967425,
  "created_at" : "2013-03-25 15:41:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316213024782434304",
  "text" : "RT @WHLive: Obama: \"In America, we look out for one another. We see citizenship not just as a collection of rights but also a set of res ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "316212942381146113",
    "text" : "Obama: \"In America, we look out for one another. We see citizenship not just as a collection of rights but also a set of responsibilities.\"",
    "id" : 316212942381146113,
    "created_at" : "2013-03-25 15:40:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 316213024782434304,
  "created_at" : "2013-03-25 15:40:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/Nm2eTQ8m4i",
      "expanded_url" : "http:\/\/at.wh.gov\/jonQ9",
      "display_url" : "at.wh.gov\/jonQ9"
    } ]
  },
  "geo" : { },
  "id_str" : "316210055907246081",
  "text" : "Happening now: President Obama speaks at a naturalization ceremony for active duty service members &amp; civilians. Watch http:\/\/t.co\/Nm2eTQ8m4i",
  "id" : 316210055907246081,
  "created_at" : "2013-03-25 15:28:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/5WwrtMYXwJ",
      "expanded_url" : "http:\/\/at.wh.gov\/joh25",
      "display_url" : "at.wh.gov\/joh25"
    } ]
  },
  "geo" : { },
  "id_str" : "316201369562390528",
  "text" : "Starting at 11:30ET: President Obama speaks at a naturalization ceremony for active duty service members &amp; civilians: http:\/\/t.co\/5WwrtMYXwJ",
  "id" : 316201369562390528,
  "created_at" : "2013-03-25 14:54:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/zor4YjVmtO",
      "expanded_url" : "http:\/\/1.usa.gov\/14nBKvJ",
      "display_url" : "1.usa.gov\/14nBKvJ"
    } ]
  },
  "geo" : { },
  "id_str" : "315935406061387776",
  "text" : "RT @petesouza: Slide show from the President's trip to the Middle East: http:\/\/t.co\/zor4YjVmtO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/zor4YjVmtO",
        "expanded_url" : "http:\/\/1.usa.gov\/14nBKvJ",
        "display_url" : "1.usa.gov\/14nBKvJ"
      } ]
    },
    "geo" : { },
    "id_str" : "315933981218598912",
    "text" : "Slide show from the President's trip to the Middle East: http:\/\/t.co\/zor4YjVmtO",
    "id" : 315933981218598912,
    "created_at" : "2013-03-24 21:11:45 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 315935406061387776,
  "created_at" : "2013-03-24 21:17:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/315642392671838210\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/fw74qKmSx9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BGFjFXOCYAE-Tqd.jpg",
      "id_str" : "315642392676032513",
      "id" : 315642392676032513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGFjFXOCYAE-Tqd.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fw74qKmSx9"
    } ],
    "hashtags" : [ {
      "text" : "acaturns3",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/S75wkIGd2m",
      "expanded_url" : "http:\/\/on.wh.gov\/z0zQu8m",
      "display_url" : "on.wh.gov\/z0zQu8m"
    } ]
  },
  "geo" : { },
  "id_str" : "315642392671838210",
  "text" : "Three years ago today, President Obama signed the Affordable Care Act into law: http:\/\/t.co\/S75wkIGd2m #acaturns3 http:\/\/t.co\/fw74qKmSx9",
  "id" : 315642392671838210,
  "created_at" : "2013-03-24 01:53:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9vrrWJgD1Y",
      "expanded_url" : "http:\/\/at.wh.gov\/jlW0S",
      "display_url" : "at.wh.gov\/jlW0S"
    } ]
  },
  "geo" : { },
  "id_str" : "315591640909758464",
  "text" : "\"No one should go broke just because they get sick.\" \u2014President Obama on the anniversary of the Affordable Care Act: http:\/\/t.co\/9vrrWJgD1Y",
  "id" : 315591640909758464,
  "created_at" : "2013-03-23 22:31:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/DvIjJOsjru",
      "expanded_url" : "http:\/\/youtu.be\/GpdoHwhhCf0",
      "display_url" : "youtu.be\/GpdoHwhhCf0"
    } ]
  },
  "geo" : { },
  "id_str" : "315547402536882176",
  "text" : "\"Right now, we have a real chance to reduce gun violence in America.\" -President Obama in his Weekly Address: http:\/\/t.co\/DvIjJOsjru",
  "id" : 315547402536882176,
  "created_at" : "2013-03-23 19:35:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/3SEmsQJxmS",
      "expanded_url" : "http:\/\/at.wh.gov\/jlTwt",
      "display_url" : "at.wh.gov\/jlTwt"
    } ]
  },
  "geo" : { },
  "id_str" : "315527090114015233",
  "text" : "Statement by President Obama on the Anniversary of the Affordable Care Act: http:\/\/t.co\/3SEmsQJxmS",
  "id" : 315527090114015233,
  "created_at" : "2013-03-23 18:14:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315520252937134080",
  "text" : "RT @NSCPress: Photo: President Obama pauses after adjusting a wreath in the Hall of Remembrance at the Yad Vashem Holocaust Museum http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/315479414056026113\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/l5uSb6Oeyp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BGDO2wlCAAAvu1h.jpg",
        "id_str" : "315479414064414720",
        "id" : 315479414064414720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BGDO2wlCAAAvu1h.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/l5uSb6Oeyp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "315479414056026113",
    "text" : "Photo: President Obama pauses after adjusting a wreath in the Hall of Remembrance at the Yad Vashem Holocaust Museum http:\/\/t.co\/l5uSb6Oeyp",
    "id" : 315479414056026113,
    "created_at" : "2013-03-23 15:05:28 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 315520252937134080,
  "created_at" : "2013-03-23 17:47:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/GDrchNbfbI",
      "expanded_url" : "http:\/\/at.wh.gov\/jliRT",
      "display_url" : "at.wh.gov\/jliRT"
    } ]
  },
  "geo" : { },
  "id_str" : "315424047527759872",
  "text" : "In this week's address, President Obama calls on Congress to pass commonsense measures to reduce gun violence: http:\/\/t.co\/GDrchNbfbI",
  "id" : 315424047527759872,
  "created_at" : "2013-03-23 11:25:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 50, 59 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/g06GgYDbwj",
      "expanded_url" : "http:\/\/on.wh.gov\/8bXOsh4",
      "display_url" : "on.wh.gov\/8bXOsh4"
    } ]
  },
  "geo" : { },
  "id_str" : "315291582586843136",
  "text" : "From the Rhodes: Deputy National Security Adviser @Rhodes44 checks in during the President's trip to the Middle East: http:\/\/t.co\/g06GgYDbwj",
  "id" : 315291582586843136,
  "created_at" : "2013-03-23 02:39:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/315247305215332352\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/UBq5eN9J6r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF_7wPxCUAA66vm.jpg",
      "id_str" : "315247305223720960",
      "id" : 315247305223720960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF_7wPxCUAA66vm.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UBq5eN9J6r"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315247305215332352",
  "text" : "Photo of the Day: President Obama tours the crypt containing the birthplace of Jesus in Bethlehem: http:\/\/t.co\/UBq5eN9J6r",
  "id" : 315247305215332352,
  "created_at" : "2013-03-22 23:43:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 111, 116 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/VWkew7VKDW",
      "expanded_url" : "http:\/\/at.wh.gov\/jl2Kz",
      "display_url" : "at.wh.gov\/jl2Kz"
    } ]
  },
  "geo" : { },
  "id_str" : "315228373859303424",
  "text" : "Today, General Austin became 1st African-American to lead US Central Command. More on his historic career from @vj44: http:\/\/t.co\/VWkew7VKDW",
  "id" : 315228373859303424,
  "created_at" : "2013-03-22 22:27:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/315202539882696704\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/c12OGpuAPz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF_TCj6CUAA1hU7.jpg",
      "id_str" : "315202539891085312",
      "id" : 315202539891085312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF_TCj6CUAA1hU7.jpg",
      "sizes" : [ {
        "h" : 380,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 868
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 868
      } ],
      "display_url" : "pic.twitter.com\/c12OGpuAPz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/0pzwXfbyoF",
      "expanded_url" : "http:\/\/on.wh.gov\/CVAlMrH",
      "display_url" : "on.wh.gov\/CVAlMrH"
    } ]
  },
  "geo" : { },
  "id_str" : "315202539882696704",
  "text" : "All the President's picks: President Obama's 2013 NCAA Women's Tournament Bracket is out: http:\/\/t.co\/0pzwXfbyoF http:\/\/t.co\/c12OGpuAPz",
  "id" : 315202539882696704,
  "created_at" : "2013-03-22 20:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 50, 59 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBiden",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/rpy4asuxSi",
      "expanded_url" : "http:\/\/at.wh.gov\/jkKxM",
      "display_url" : "at.wh.gov\/jkKxM"
    } ]
  },
  "geo" : { },
  "id_str" : "315185774553362433",
  "text" : ".@VP takes you inside his trip to the Vatican for @Pontifex Inauguration Mass for Vol. 2 of #BeingBiden. Listen: http:\/\/t.co\/rpy4asuxSi",
  "id" : 315185774553362433,
  "created_at" : "2013-03-22 19:38:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "indices" : [ 3, 14 ],
      "id_str" : "9109712",
      "id" : 9109712
    }, {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "indices" : [ 75, 86 ],
      "id_str" : "9109712",
      "id" : 9109712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ylTYs6d1bg",
      "expanded_url" : "http:\/\/bit.ly\/13gf6Wo",
      "display_url" : "bit.ly\/13gf6Wo"
    } ]
  },
  "geo" : { },
  "id_str" : "315166050318704640",
  "text" : "RT @PeaceCorps: We're celebrating 52 years of women making a difference as @PeaceCorps Volunteers http:\/\/t.co\/ylTYs6d1bg #WomensHistoryM ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peace Corps",
        "screen_name" : "PeaceCorps",
        "indices" : [ 59, 70 ],
        "id_str" : "9109712",
        "id" : 9109712
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomensHistoryMonth",
        "indices" : [ 105, 124 ]
      }, {
        "text" : "publicservice",
        "indices" : [ 125, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/ylTYs6d1bg",
        "expanded_url" : "http:\/\/bit.ly\/13gf6Wo",
        "display_url" : "bit.ly\/13gf6Wo"
      } ]
    },
    "geo" : { },
    "id_str" : "315144278215127040",
    "text" : "We're celebrating 52 years of women making a difference as @PeaceCorps Volunteers http:\/\/t.co\/ylTYs6d1bg #WomensHistoryMonth #publicservice",
    "id" : 315144278215127040,
    "created_at" : "2013-03-22 16:53:45 +0000",
    "user" : {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "protected" : false,
      "id_str" : "9109712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737985331815841793\/YS-240sx_normal.jpg",
      "id" : 9109712,
      "verified" : true
    }
  },
  "id" : 315166050318704640,
  "created_at" : "2013-03-22 18:20:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/TkcZlHuXAO",
      "expanded_url" : "http:\/\/at.wh.gov\/jkskB",
      "display_url" : "at.wh.gov\/jkskB"
    } ]
  },
  "geo" : { },
  "id_str" : "315151469030567938",
  "text" : "Happening Now: President Obama and his Majesty King Abdullah II hold a press conference from Amman, Jordan. Watch: http:\/\/t.co\/TkcZlHuXAO",
  "id" : 315151469030567938,
  "created_at" : "2013-03-22 17:22:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 35, 38 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBiden",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315114329513017345",
  "text" : "RT @VP: Vol. 2 of #BeingBiden: The @VP takes you to St. Peter's Basilica, just after the Inauguration Mass of Pope Francis https:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 27, 30 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeingBiden",
        "indices" : [ 10, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/YCbYTRSksY",
        "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/vol-2-a-good-omen?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter&utm_content=https:\/\/soundcloud.com\/whitehouse\/vol-2-a-good-omen",
        "display_url" : "soundcloud.com\/whitehouse\/vol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "315113628896473089",
    "text" : "Vol. 2 of #BeingBiden: The @VP takes you to St. Peter's Basilica, just after the Inauguration Mass of Pope Francis https:\/\/t.co\/YCbYTRSksY",
    "id" : 315113628896473089,
    "created_at" : "2013-03-22 14:51:58 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 315114329513017345,
  "created_at" : "2013-03-22 14:54:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "315102089279860736",
  "text" : "Watch live at 11:45 ET: President Obama and his Majesty King Abdullah II hold a press conference from Amman, Jordan: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 315102089279860736,
  "created_at" : "2013-03-22 14:06:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/315072806134104065\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/w1mD3HpYm8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF9dDECCQAEmaTd.jpg",
      "id_str" : "315072806142492673",
      "id" : 315072806142492673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF9dDECCQAEmaTd.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/w1mD3HpYm8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315096165802713088",
  "text" : "RT @rhodes44: Extraordinary and inspiring audience at the President's speech yesterday http:\/\/t.co\/w1mD3HpYm8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/315072806134104065\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/w1mD3HpYm8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BF9dDECCQAEmaTd.jpg",
        "id_str" : "315072806142492673",
        "id" : 315072806142492673,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF9dDECCQAEmaTd.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/w1mD3HpYm8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "315072806134104065",
    "text" : "Extraordinary and inspiring audience at the President's speech yesterday http:\/\/t.co\/w1mD3HpYm8",
    "id" : 315072806134104065,
    "created_at" : "2013-03-22 12:09:45 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 315096165802713088,
  "created_at" : "2013-03-22 13:42:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shimon Peres",
      "screen_name" : "PresidentPeres",
      "indices" : [ 23, 38 ],
      "id_str" : "406255275",
      "id" : 406255275
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314926831268663296",
  "text" : "RT @NSCPress: Tonight, @PresidentPeres hosted POTUS for a state dinner and presented him the Medal of Distinction. Remarks here: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shimon Peres",
        "screen_name" : "PresidentPeres",
        "indices" : [ 9, 24 ],
        "id_str" : "406255275",
        "id" : 406255275
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/VyLjAj8E2K",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2013\/03\/21\/remarks-president-and-president-peres-israel-state-dinner",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "314879062449471489",
    "text" : "Tonight, @PresidentPeres hosted POTUS for a state dinner and presented him the Medal of Distinction. Remarks here: http:\/\/t.co\/VyLjAj8E2K",
    "id" : 314879062449471489,
    "created_at" : "2013-03-21 23:19:53 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 314926831268663296,
  "created_at" : "2013-03-22 02:29:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/1txbWACCiF",
      "expanded_url" : "http:\/\/at.wh.gov\/jiPHd",
      "display_url" : "at.wh.gov\/jiPHd"
    } ]
  },
  "geo" : { },
  "id_str" : "314910600125898752",
  "text" : "President Obama: \"What I\u2019ve most looked forward to is the ability to speak directly to you, the Israeli people\" Watch http:\/\/t.co\/1txbWACCiF",
  "id" : 314910600125898752,
  "created_at" : "2013-03-22 01:25:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/314900012217819136\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/iiACnyyJ1o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF6_5IhCYAAP4lE.jpg",
      "id_str" : "314900012222013440",
      "id" : 314900012222013440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF6_5IhCYAAP4lE.jpg",
      "sizes" : [ {
        "h" : 415,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 553,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/iiACnyyJ1o"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/oEfuQEC9XH",
      "expanded_url" : "http:\/\/on.wh.gov\/CtkUg2y",
      "display_url" : "on.wh.gov\/CtkUg2y"
    } ]
  },
  "geo" : { },
  "id_str" : "314900012217819136",
  "text" : "Photo of the Day: President Obama waves after speaking to the Israeli people in Jerusalem: http:\/\/t.co\/oEfuQEC9XH http:\/\/t.co\/iiACnyyJ1o",
  "id" : 314900012217819136,
  "created_at" : "2013-03-22 00:43:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/jrIyMdB9JR",
      "expanded_url" : "http:\/\/at.wh.gov\/jiOcr",
      "display_url" : "at.wh.gov\/jiOcr"
    } ]
  },
  "geo" : { },
  "id_str" : "314877262371635200",
  "text" : "Today, President Obama spoke to the Israeli people from the Jerusalem International Convention Center. Watch: http:\/\/t.co\/jrIyMdB9JR",
  "id" : 314877262371635200,
  "created_at" : "2013-03-21 23:12:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314808270466469889",
  "text" : "RT @NSCPress: POTUS to young people in Israel: \"It falls to you to write the next chapter in the story of this great nation.\"  http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/ePSZfewtwQ",
        "expanded_url" : "http:\/\/wh.gov\/sH6t",
        "display_url" : "wh.gov\/sH6t"
      } ]
    },
    "geo" : { },
    "id_str" : "314807696442408960",
    "text" : "POTUS to young people in Israel: \"It falls to you to write the next chapter in the story of this great nation.\"  http:\/\/t.co\/ePSZfewtwQ",
    "id" : 314807696442408960,
    "created_at" : "2013-03-21 18:36:18 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 314808270466469889,
  "created_at" : "2013-03-21 18:38:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314760196641652736",
  "text" : "President Obama to the young people of Israel: \"It falls to you to write the next chapter in the story of this great nation.\"",
  "id" : 314760196641652736,
  "created_at" : "2013-03-21 15:27:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314758016832532481",
  "text" : "RT @WHLive: President Obama: \"That is where peace begins \u2013 not just in the plans of leaders, but in the hearts of people\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314757960482054144",
    "text" : "President Obama: \"That is where peace begins \u2013 not just in the plans of leaders, but in the hearts of people\"",
    "id" : 314757960482054144,
    "created_at" : "2013-03-21 15:18:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 314758016832532481,
  "created_at" : "2013-03-21 15:18:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314754321105448960",
  "text" : "President Obama to the people of Israel: \"So long as there is a United States of America, Ah-tem lo lah-vahd. You are not alone.\"",
  "id" : 314754321105448960,
  "created_at" : "2013-03-21 15:04:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314751441128538112",
  "text" : "RT @WHLive: Obama: \"I\u2019d like to focus on how we can work together to make progress in 3 areas that will define our times: security, peac ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314751389526024192",
    "text" : "Obama: \"I\u2019d like to focus on how we can work together to make progress in 3 areas that will define our times: security, peace &amp; prosperity\"",
    "id" : 314751389526024192,
    "created_at" : "2013-03-21 14:52:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 314751441128538112,
  "created_at" : "2013-03-21 14:52:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314751145232977920",
  "text" : "President Obama to young people \"No matter how great the challenges are, their idealism, their energy &amp; their ambition always gives me hope\"",
  "id" : 314751145232977920,
  "created_at" : "2013-03-21 14:51:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314750112360452096",
  "text" : "\"Every step of the way, Israel has built unbreakable bonds of friendship with my country, the United States of America.\" \u2014President Obama",
  "id" : 314750112360452096,
  "created_at" : "2013-03-21 14:47:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314748157865127937",
  "text" : "President Obama: \"Only in Israel could you see the Dead Sea Scrolls and the place where the technology on board the Mars Rover originated\"",
  "id" : 314748157865127937,
  "created_at" : "2013-03-21 14:39:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314747933549555712",
  "text" : "President Obama: \"Shalom. It is an honor to be here with you in Jerusalem\"",
  "id" : 314747933549555712,
  "created_at" : "2013-03-21 14:38:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "314747640933908480",
  "text" : "Happening now: President Obama speaks to the people of Israel from Jerusalem. Watch live: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 314747640933908480,
  "created_at" : "2013-03-21 14:37:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "314746951507787776",
  "text" : "Today at 11am ET, President Obama will address the people of Israel from the Convention Center in Jerusalem. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 314746951507787776,
  "created_at" : "2013-03-21 14:34:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314728849441173504",
  "text" : "RT @rhodes44: POTUS doing roundtable with eight Palestinian students in Ramallah. Chance to hear directly from young people from across  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314719475612123138",
    "text" : "POTUS doing roundtable with eight Palestinian students in Ramallah. Chance to hear directly from young people from across the West Bank",
    "id" : 314719475612123138,
    "created_at" : "2013-03-21 12:45:44 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 314728849441173504,
  "created_at" : "2013-03-21 13:22:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shimon Peres",
      "screen_name" : "PresidentPeres",
      "indices" : [ 30, 45 ],
      "id_str" : "406255275",
      "id" : 406255275
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/314524772228816896\/photo\/1",
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/ujxvhyIL8O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF1qnSpCYAAHY-Z.jpg",
      "id_str" : "314524772237205504",
      "id" : 314524772237205504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF1qnSpCYAAHY-Z.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/ujxvhyIL8O"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Fifg7jn4t9",
      "expanded_url" : "http:\/\/on.wh.gov\/QU0XmVJ",
      "display_url" : "on.wh.gov\/QU0XmVJ"
    } ]
  },
  "geo" : { },
  "id_str" : "314524772228816896",
  "text" : "President Obama &amp; Israeli @PresidentPeres during the official arrival ceremony in Tel Aviv: http:\/\/t.co\/Fifg7jn4t9 http:\/\/t.co\/ujxvhyIL8O",
  "id" : 314524772228816896,
  "created_at" : "2013-03-20 23:52:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Netanyahu",
      "screen_name" : "netanyahu",
      "indices" : [ 43, 53 ],
      "id_str" : "17061263",
      "id" : 17061263
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/314523168524091393\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/u8QCu6VPJJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BF1pJ8YCQAA6Yfp.jpg",
      "id_str" : "314523168532480000",
      "id" : 314523168532480000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF1pJ8YCQAA6Yfp.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 533
      } ],
      "display_url" : "pic.twitter.com\/u8QCu6VPJJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314523168524091393",
  "text" : "Photo of the Day: President Obama &amp; PM @Netanyahu walk across the tarmac at Ben Gurion Int'l Airport in Tel Aviv: http:\/\/t.co\/u8QCu6VPJJ",
  "id" : 314523168524091393,
  "created_at" : "2013-03-20 23:45:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/wXBn9XoXWA",
      "expanded_url" : "http:\/\/wh.gov\/sfYL",
      "display_url" : "wh.gov\/sfYL"
    } ]
  },
  "geo" : { },
  "id_str" : "314499606354464770",
  "text" : "RT @NSCPress: Today, President Obama delivered remarks during the official arrival ceremony in Tel Aviv: http:\/\/t.co\/wXBn9XoXWA http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/314481427662127106\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/WfGtKcie2U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BF1DMTjCQAAHfSv.jpg",
        "id_str" : "314481427670515712",
        "id" : 314481427670515712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF1DMTjCQAAHfSv.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/WfGtKcie2U"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/wXBn9XoXWA",
        "expanded_url" : "http:\/\/wh.gov\/sfYL",
        "display_url" : "wh.gov\/sfYL"
      } ]
    },
    "geo" : { },
    "id_str" : "314481427662127106",
    "text" : "Today, President Obama delivered remarks during the official arrival ceremony in Tel Aviv: http:\/\/t.co\/wXBn9XoXWA http:\/\/t.co\/WfGtKcie2U",
    "id" : 314481427662127106,
    "created_at" : "2013-03-20 20:59:49 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 314499606354464770,
  "created_at" : "2013-03-20 22:12:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "Benjamin Netanyahu",
      "screen_name" : "netanyahu",
      "indices" : [ 80, 90 ],
      "id_str" : "17061263",
      "id" : 17061263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314491526329823233",
  "text" : "RT @rhodes44: President Obama shakes hands with Israeli Prime Minister Benjamin @Netanyahu during the official arrival ceremony http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Benjamin Netanyahu",
        "screen_name" : "netanyahu",
        "indices" : [ 66, 76 ],
        "id_str" : "17061263",
        "id" : 17061263
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/314483454781833216\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/HAoLhCmk7O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BF1FCTJCQAANXfg.jpg",
        "id_str" : "314483454786027520",
        "id" : 314483454786027520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF1FCTJCQAANXfg.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/HAoLhCmk7O"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314483454781833216",
    "text" : "President Obama shakes hands with Israeli Prime Minister Benjamin @Netanyahu during the official arrival ceremony http:\/\/t.co\/HAoLhCmk7O",
    "id" : 314483454781833216,
    "created_at" : "2013-03-20 21:07:53 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 314491526329823233,
  "created_at" : "2013-03-20 21:39:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shimon Peres",
      "screen_name" : "PresidentPeres",
      "indices" : [ 21, 36 ],
      "id_str" : "406255275",
      "id" : 406255275
    }, {
      "name" : "Benjamin Netanyahu",
      "screen_name" : "netanyahu",
      "indices" : [ 46, 56 ],
      "id_str" : "17061263",
      "id" : 17061263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314481012409241600",
  "text" : "RT @NSCPress: POTUS, @PresidentPeres &amp; PM @Netanyahu listen to the playing of the U.S. national anthem at today's arrival ceremony.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shimon Peres",
        "screen_name" : "PresidentPeres",
        "indices" : [ 7, 22 ],
        "id_str" : "406255275",
        "id" : 406255275
      }, {
        "name" : "Benjamin Netanyahu",
        "screen_name" : "netanyahu",
        "indices" : [ 32, 42 ],
        "id_str" : "17061263",
        "id" : 17061263
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NSCPress\/status\/314479836884246528\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/UHOceXLj97",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BF1BvteCEAAoQ3Z.jpg",
        "id_str" : "314479836901019648",
        "id" : 314479836901019648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BF1BvteCEAAoQ3Z.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/UHOceXLj97"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314479836884246528",
    "text" : "POTUS, @PresidentPeres &amp; PM @Netanyahu listen to the playing of the U.S. national anthem at today's arrival ceremony. http:\/\/t.co\/UHOceXLj97",
    "id" : 314479836884246528,
    "created_at" : "2013-03-20 20:53:30 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 314481012409241600,
  "created_at" : "2013-03-20 20:58:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Benjamin Netanyahu",
      "screen_name" : "netanyahu",
      "indices" : [ 52, 62 ],
      "id_str" : "17061263",
      "id" : 17061263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/oPflTkkHep",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "314444590646194176",
  "text" : "RT @WHLive: Happening now: President Obama &amp; PM @netanyahu hold a press conference: http:\/\/t.co\/oPflTkkHep",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Benjamin Netanyahu",
        "screen_name" : "netanyahu",
        "indices" : [ 40, 50 ],
        "id_str" : "17061263",
        "id" : 17061263
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/oPflTkkHep",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "314444507477331968",
    "text" : "Happening now: President Obama &amp; PM @netanyahu hold a press conference: http:\/\/t.co\/oPflTkkHep",
    "id" : 314444507477331968,
    "created_at" : "2013-03-20 18:33:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 314444590646194176,
  "created_at" : "2013-03-20 18:33:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 41, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/EjfClz3RQD",
      "expanded_url" : "http:\/\/at.wh.gov\/jfhaa",
      "display_url" : "at.wh.gov\/jfhaa"
    } ]
  },
  "geo" : { },
  "id_str" : "314438806810005504",
  "text" : "FACT SHEET: The Economics of Commonsense #ImmigrationReform: http:\/\/t.co\/EjfClz3RQD",
  "id" : 314438806810005504,
  "created_at" : "2013-03-20 18:10:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "Benjamin Netanyahu",
      "screen_name" : "netanyahu",
      "indices" : [ 64, 74 ],
      "id_str" : "17061263",
      "id" : 17061263
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/ZBkpO1i6cZ",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "314407773146345472",
  "text" : "RT @rhodes44: Watch live at 2:00pm ET: President Obama &amp; PM @Netanyahu hold a press conference: http:\/\/t.co\/ZBkpO1i6cZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Benjamin Netanyahu",
        "screen_name" : "netanyahu",
        "indices" : [ 50, 60 ],
        "id_str" : "17061263",
        "id" : 17061263
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/ZBkpO1i6cZ",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "314402081270280192",
    "text" : "Watch live at 2:00pm ET: President Obama &amp; PM @Netanyahu hold a press conference: http:\/\/t.co\/ZBkpO1i6cZ",
    "id" : 314402081270280192,
    "created_at" : "2013-03-20 15:44:32 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 314407773146345472,
  "created_at" : "2013-03-20 16:07:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/314377105360171009\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/QRw5FchNG8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFzkT8sCMAA7X-g.jpg",
      "id_str" : "314377105368559616",
      "id" : 314377105368559616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFzkT8sCMAA7X-g.jpg",
      "sizes" : [ {
        "h" : 422,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1638,
        "resize" : "fit",
        "w" : 2328
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QRw5FchNG8"
    } ],
    "hashtags" : [ {
      "text" : "MarchMadness",
      "indices" : [ 29, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/4pbAo8DfNq",
      "expanded_url" : "http:\/\/on.wh.gov\/OvHsLDP",
      "display_url" : "on.wh.gov\/OvHsLDP"
    } ]
  },
  "geo" : { },
  "id_str" : "314377105360171009",
  "text" : "Filling out your bracket for #MarchMadness? Check out President Obama's NCAA Tournament picks: http:\/\/t.co\/4pbAo8DfNq http:\/\/t.co\/QRw5FchNG8",
  "id" : 314377105360171009,
  "created_at" : "2013-03-20 14:05:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/314164430315343873\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/gmzDynxpeR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFwi4oZCUAEmg7M.jpg",
      "id_str" : "314164430319538177",
      "id" : 314164430319538177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFwi4oZCUAEmg7M.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/gmzDynxpeR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/SgvhonkSin",
      "expanded_url" : "http:\/\/on.wh.gov\/ZD2PO1f",
      "display_url" : "on.wh.gov\/ZD2PO1f"
    } ]
  },
  "geo" : { },
  "id_str" : "314164430315343873",
  "text" : "Honoring Women's History Month at the White House: http:\/\/t.co\/SgvhonkSin http:\/\/t.co\/gmzDynxpeR",
  "id" : 314164430315343873,
  "created_at" : "2013-03-20 00:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 33, 41 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314140040500482048",
  "text" : "RT @rhodes44: Glad to be joining @Twitter in time for 1st foreign trip of 2nd term. Departing for Tel Aviv shortly. I'll be sharing upda ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 19, 27 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314139696341086210",
    "text" : "Glad to be joining @Twitter in time for 1st foreign trip of 2nd term. Departing for Tel Aviv shortly. I'll be sharing updates from the road.",
    "id" : 314139696341086210,
    "created_at" : "2013-03-19 22:21:54 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 314140040500482048,
  "created_at" : "2013-03-19 22:23:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 37, 44 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "314131055651221505",
  "text" : "Happening now: President Obama &amp; @FLOTUS Michelle Obama host a St. Patrick's Day reception: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 314131055651221505,
  "created_at" : "2013-03-19 21:47:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 116, 125 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314118256103395328",
  "text" : "RT @NSCPress: In the 1st foreign trip of his 2nd term, the President will visit Israel, the West Bank &amp; Jordan. @Rhodes44 previews:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Rhodes",
        "screen_name" : "rhodes44",
        "indices" : [ 102, 111 ],
        "id_str" : "249722522",
        "id" : 249722522
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/BBKZY5A2T4",
        "expanded_url" : "http:\/\/youtu.be\/J5pUVHW-Lhw",
        "display_url" : "youtu.be\/J5pUVHW-Lhw"
      } ]
    },
    "geo" : { },
    "id_str" : "314116724200988672",
    "text" : "In the 1st foreign trip of his 2nd term, the President will visit Israel, the West Bank &amp; Jordan. @Rhodes44 previews: http:\/\/t.co\/BBKZY5A2T4",
    "id" : 314116724200988672,
    "created_at" : "2013-03-19 20:50:37 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 314118256103395328,
  "created_at" : "2013-03-19 20:56:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Ls1ypIZuGl",
      "expanded_url" : "http:\/\/at.wh.gov\/jdtrb",
      "display_url" : "at.wh.gov\/jdtrb"
    } ]
  },
  "geo" : { },
  "id_str" : "314052517803745280",
  "text" : "Statement by President Obama on the 10th Anniversary of the #Iraq War: http:\/\/t.co\/Ls1ypIZuGl",
  "id" : 314052517803745280,
  "created_at" : "2013-03-19 16:35:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CitizensMedal",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/tPxaAZSj3S",
      "expanded_url" : "http:\/\/at.wh.gov\/jbGji",
      "display_url" : "at.wh.gov\/jbGji"
    } ]
  },
  "geo" : { },
  "id_str" : "313773337404919808",
  "text" : "Who is your hero? Help us recognize exemplary citizens by nominating them for the 2013 Presidential #CitizensMedal: http:\/\/t.co\/tPxaAZSj3S",
  "id" : 313773337404919808,
  "created_at" : "2013-03-18 22:06:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "313757012800446464",
  "text" : "Happening now: President Obama speaks at a Women's History Month reception at the White House. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 313757012800446464,
  "created_at" : "2013-03-18 21:01:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 64, 70 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/t9BosaEcv8",
      "expanded_url" : "http:\/\/wh.gov\/sNvn",
      "display_url" : "wh.gov\/sNvn"
    } ]
  },
  "geo" : { },
  "id_str" : "313749004305436672",
  "text" : "Today, President Obama nominated Tom Perez for Secretary of the @USDOL: http:\/\/t.co\/t9BosaEcv8",
  "id" : 313749004305436672,
  "created_at" : "2013-03-18 20:29:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "313726901363552256",
  "text" : "Today at 4:40 ET: President Obama speaks at a Women\u2019s History Month Reception. Watch live: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 313726901363552256,
  "created_at" : "2013-03-18 19:01:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "313677961935069184",
  "text" : "Happening now: President Obama makes a personnel announcement from the East Room. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 313677961935069184,
  "created_at" : "2013-03-18 15:47:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "313643779443810304",
  "text" : "This morning, President Obama will make a personnel announcement in the East Room. Watch live at 11:40 AM ET: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 313643779443810304,
  "created_at" : "2013-03-18 13:31:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/313379234569678848\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/oTyU06Vg9O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFlYwOUCcAAwPli.jpg",
      "id_str" : "313379234578067456",
      "id" : 313379234578067456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFlYwOUCcAAwPli.jpg",
      "sizes" : [ {
        "h" : 910,
        "resize" : "fit",
        "w" : 1365
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oTyU06Vg9O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313379234569678848",
  "text" : "From the Archives: President Obama grabs a pint of Guinness at an Irish pub in DC on St. Patrick's Day 2012 http:\/\/t.co\/oTyU06Vg9O",
  "id" : 313379234569678848,
  "created_at" : "2013-03-17 20:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/313296437645549568\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/22bTL5LuWU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFkNczuCIAAhWUL.jpg",
      "id_str" : "313296437649743872",
      "id" : 313296437649743872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFkNczuCIAAhWUL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/22bTL5LuWU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313296437645549568",
  "text" : "Happy St. Patrick's Day! http:\/\/t.co\/22bTL5LuWU",
  "id" : 313296437645549568,
  "created_at" : "2013-03-17 14:31:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/312591749577068546\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/7il0KG1fqr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFaMikICUAEhDl8.jpg",
      "id_str" : "312591749589651457",
      "id" : 312591749589651457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFaMikICUAEhDl8.jpg",
      "sizes" : [ {
        "h" : 1595,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1595,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 981,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 556,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7il0KG1fqr"
    } ],
    "hashtags" : [ {
      "text" : "Energy",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/17W5T4QtmN",
      "expanded_url" : "http:\/\/youtu.be\/mJZY3oqQnMI",
      "display_url" : "youtu.be\/mJZY3oqQnMI"
    } ]
  },
  "geo" : { },
  "id_str" : "312996705249423360",
  "text" : "Watch: President Obama calls on Congress to create an #Energy Security Trust: http:\/\/t.co\/17W5T4QtmN Infographic: http:\/\/t.co\/7il0KG1fqr",
  "id" : 312996705249423360,
  "created_at" : "2013-03-16 18:40:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Energy",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/17W5T4QtmN",
      "expanded_url" : "http:\/\/youtu.be\/mJZY3oqQnMI",
      "display_url" : "youtu.be\/mJZY3oqQnMI"
    } ]
  },
  "geo" : { },
  "id_str" : "312869642681065472",
  "text" : "President Obama's Weekly Address: It's Time to Create the #Energy Security Trust: http:\/\/t.co\/17W5T4QtmN",
  "id" : 312869642681065472,
  "created_at" : "2013-03-16 10:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/yVapm2RWzF",
      "expanded_url" : "http:\/\/at.wh.gov\/j1cQt",
      "display_url" : "at.wh.gov\/j1cQt"
    } ]
  },
  "geo" : { },
  "id_str" : "312721752939700226",
  "text" : "Full video: President Obama visits the Argonne National Research Lab to talk about American #energy security: http:\/\/t.co\/yVapm2RWzF",
  "id" : 312721752939700226,
  "created_at" : "2013-03-16 00:27:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312637255447613440",
  "text" : "\"When someone tells us we can\u2019t, we say yes, we can.\" \u2014President Obama",
  "id" : 312637255447613440,
  "created_at" : "2013-03-15 18:51:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/MxlUUV0n57",
      "expanded_url" : "http:\/\/wh.gov\/energy",
      "display_url" : "wh.gov\/energy"
    } ]
  },
  "geo" : { },
  "id_str" : "312636443610718208",
  "text" : "\"Let\u2019s keep moving on an all-of-the-above #energy strategy for America.\" \u2014President Obama, http:\/\/t.co\/MxlUUV0n57",
  "id" : 312636443610718208,
  "created_at" : "2013-03-15 18:48:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312636012113301504",
  "text" : "RT @WHLive: President Obama: \"This is about national security. Our reliance on oil makes us far too dependent on other parts of the world.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312635869301469184",
    "text" : "President Obama: \"This is about national security. Our reliance on oil makes us far too dependent on other parts of the world.\"",
    "id" : 312635869301469184,
    "created_at" : "2013-03-15 18:46:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 312636012113301504,
  "created_at" : "2013-03-15 18:46:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/312591749577068546\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/7il0KG1fqr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFaMikICUAEhDl8.jpg",
      "id_str" : "312591749589651457",
      "id" : 312591749589651457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFaMikICUAEhDl8.jpg",
      "sizes" : [ {
        "h" : 1595,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1595,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 981,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 556,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7il0KG1fqr"
    } ],
    "hashtags" : [ {
      "text" : "Energy",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312635874766643200",
  "text" : "\"In my State of the Union Address, I called on Congress to set up an #Energy Security Trust\" \u2014President Obama, http:\/\/t.co\/7il0KG1fqr",
  "id" : 312635874766643200,
  "created_at" : "2013-03-15 18:46:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/312634996655521793\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/AHhGcvLn3J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFaz34CCAAA5KY8.jpg",
      "id_str" : "312634996663910400",
      "id" : 312634996663910400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFaz34CCAAA5KY8.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/AHhGcvLn3J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312635321168822273",
  "text" : "RT @WHLive: \"By the middle of the next decade, our cars will go twice as far on a gallon of gas.\" \u2014President Obama, http:\/\/t.co\/AHhGcvLn3J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/312634996655521793\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/AHhGcvLn3J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BFaz34CCAAA5KY8.jpg",
        "id_str" : "312634996663910400",
        "id" : 312634996663910400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFaz34CCAAA5KY8.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/AHhGcvLn3J"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312634996655521793",
    "text" : "\"By the middle of the next decade, our cars will go twice as far on a gallon of gas.\" \u2014President Obama, http:\/\/t.co\/AHhGcvLn3J",
    "id" : 312634996655521793,
    "created_at" : "2013-03-15 18:42:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 312635321168822273,
  "created_at" : "2013-03-15 18:44:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sequester",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312634645126733825",
  "text" : "RT @WHLive: President Obama on the #sequester: \"These cuts will harm, not help, our economy. They aren\u2019t the smart way to cut our deficits.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sequester",
        "indices" : [ 23, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312634388372418562",
    "text" : "President Obama on the #sequester: \"These cuts will harm, not help, our economy. They aren\u2019t the smart way to cut our deficits.\"",
    "id" : 312634388372418562,
    "created_at" : "2013-03-15 18:40:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 312634645126733825,
  "created_at" : "2013-03-15 18:41:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312633997547171841",
  "text" : "RT @WHLive: President Obama: \"We need to keep investing in scientific research. We need to maintain our edge.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312633696748445696",
    "text" : "President Obama: \"We need to keep investing in scientific research. We need to maintain our edge.\"",
    "id" : 312633696748445696,
    "created_at" : "2013-03-15 18:37:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 312633997547171841,
  "created_at" : "2013-03-15 18:38:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/312633471946330112\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/nfB50mNk6Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFayfICCEAEwSGl.jpg",
      "id_str" : "312633471950524417",
      "id" : 312633471950524417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFayfICCEAEwSGl.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/nfB50mNk6Q"
    } ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312633886272258048",
  "text" : "\"We\u2019ve doubled the amount of renewable #energy we generate from sources like wind and solar\" \u2014President Obama, http:\/\/t.co\/nfB50mNk6Q",
  "id" : 312633886272258048,
  "created_at" : "2013-03-15 18:38:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312633422826852352",
  "text" : "President Obama: \"Our top priority as a nation: reigniting the true engine of America\u2019s economic growth \u2013 a rising, thriving middle class\"",
  "id" : 312633422826852352,
  "created_at" : "2013-03-15 18:36:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "312632102229258240",
  "text" : "Happening now: President Obama speaks on American #energy from the Argonne National Laboratory in IL. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 312632102229258240,
  "created_at" : "2013-03-15 18:31:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "312620981564895232",
  "text" : "At 2:30ET, President Obama speaks on American #energy from the Argonne National Laboratory in IL. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 312620981564895232,
  "created_at" : "2013-03-15 17:47:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/312591749577068546\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/7il0KG1fqr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFaMikICUAEhDl8.jpg",
      "id_str" : "312591749589651457",
      "id" : 312591749589651457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFaMikICUAEhDl8.jpg",
      "sizes" : [ {
        "h" : 1595,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1595,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 981,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 556,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7il0KG1fqr"
    } ],
    "hashtags" : [ {
      "text" : "Energy",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/IDNZkb0Z8e",
      "expanded_url" : "http:\/\/wh.gov\/oznG",
      "display_url" : "wh.gov\/oznG"
    } ]
  },
  "geo" : { },
  "id_str" : "312591749577068546",
  "text" : "INFOGRAPHIC: What You Need to Know About the #Energy Security Trust: http:\/\/t.co\/IDNZkb0Z8e, http:\/\/t.co\/7il0KG1fqr",
  "id" : 312591749577068546,
  "created_at" : "2013-03-15 15:50:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/312586718731698178\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/xiI2Oqd8gb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFaH9uwCAAIoupv.jpg",
      "id_str" : "312586718740086786",
      "id" : 312586718740086786,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFaH9uwCAAIoupv.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xiI2Oqd8gb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/LjL9kK5JC1",
      "expanded_url" : "http:\/\/on.wh.gov\/ZJjS9C0",
      "display_url" : "on.wh.gov\/ZJjS9C0"
    } ]
  },
  "geo" : { },
  "id_str" : "312586718731698178",
  "text" : "Photo Gallery: Behind the scenes in February: http:\/\/t.co\/LjL9kK5JC1 President Obama hugs pre-k students in GA: http:\/\/t.co\/xiI2Oqd8gb",
  "id" : 312586718731698178,
  "created_at" : "2013-03-15 15:30:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Hina",
      "screen_name" : "paulhina",
      "indices" : [ 3, 12 ],
      "id_str" : "15923197",
      "id" : 15923197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/8jOZyVPCZx",
      "expanded_url" : "http:\/\/www.journalgazette.net\/article\/20130313\/NEWS07\/303139938\/1067",
      "display_url" : "journalgazette.net\/article\/201303\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312569014205415424",
  "text" : "RT @paulhina: As a proud beneficiary of the Head Start program, these sequester cuts to the program break my heart. http:\/\/t.co\/8jOZyVPCZx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/8jOZyVPCZx",
        "expanded_url" : "http:\/\/www.journalgazette.net\/article\/20130313\/NEWS07\/303139938\/1067",
        "display_url" : "journalgazette.net\/article\/201303\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "312566683518763008",
    "text" : "As a proud beneficiary of the Head Start program, these sequester cuts to the program break my heart. http:\/\/t.co\/8jOZyVPCZx",
    "id" : 312566683518763008,
    "created_at" : "2013-03-15 14:11:19 +0000",
    "user" : {
      "name" : "Paul Hina",
      "screen_name" : "paulhina",
      "protected" : false,
      "id_str" : "15923197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474914441805324288\/B9Ik14sO_normal.jpeg",
      "id" : 15923197,
      "verified" : false
    }
  },
  "id" : 312569014205415424,
  "created_at" : "2013-03-15 14:20:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 22, 33 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 78, 81 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sequester",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/OV20WyaR8A",
      "expanded_url" : "http:\/\/bit.ly\/XNL6wR",
      "display_url" : "bit.ly\/XNL6wR"
    } ]
  },
  "geo" : { },
  "id_str" : "312565199402053633",
  "text" : "Those focused only on @WhiteHouse tours miss real #Sequester story. Read this @AP rpt: Outrageous &amp; important 2 share http:\/\/t.co\/OV20WyaR8A",
  "id" : 312565199402053633,
  "created_at" : "2013-03-15 14:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBiden",
      "indices" : [ 11, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/cK8XJz9PrG",
      "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/vol-1-the-sportsmans-ethic?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter&utm_content=https:\/\/soundcloud.com\/whitehouse\/vol-1-the-sportsmans-ethic",
      "display_url" : "soundcloud.com\/whitehouse\/vol\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "312356884512374785",
  "text" : "RT @VP: In #BeingBiden, the Vice President tells the story behind a photo. Listen to Vol. 1 \"The Sportsman's Ethic\" https:\/\/t.co\/cK8XJz9PrG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeingBiden",
        "indices" : [ 3, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/cK8XJz9PrG",
        "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/vol-1-the-sportsmans-ethic?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter&utm_content=https:\/\/soundcloud.com\/whitehouse\/vol-1-the-sportsmans-ethic",
        "display_url" : "soundcloud.com\/whitehouse\/vol\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "312356665536155648",
    "text" : "In #BeingBiden, the Vice President tells the story behind a photo. Listen to Vol. 1 \"The Sportsman's Ethic\" https:\/\/t.co\/cK8XJz9PrG",
    "id" : 312356665536155648,
    "created_at" : "2013-03-15 00:16:47 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 312356884512374785,
  "created_at" : "2013-03-15 00:17:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312317465134768128",
  "text" : "RT @VP: Encouraged by Senate Judiciary Committee action: Background checks, school safety, bans on assault weapons and high-capacity mag ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "312317181591441408",
    "text" : "Encouraged by Senate Judiciary Committee action: Background checks, school safety, bans on assault weapons and high-capacity magazines. \u2013VP",
    "id" : 312317181591441408,
    "created_at" : "2013-03-14 21:39:53 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 312317465134768128,
  "created_at" : "2013-03-14 21:41:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/0JPPzykXoI",
      "expanded_url" : "http:\/\/at.wh.gov\/iWTjd",
      "display_url" : "at.wh.gov\/iWTjd"
    } ]
  },
  "geo" : { },
  "id_str" : "312314477066477568",
  "text" : "Pres. Obama: \"I thank the Senate for taking another step forward in our common effort to help reduce gun violence\" http:\/\/t.co\/0JPPzykXoI",
  "id" : 312314477066477568,
  "created_at" : "2013-03-14 21:29:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BeingBiden",
      "indices" : [ 111, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312261932356882432",
  "text" : "RT @VP: In a new audio series, Vice President Biden tells the story behind a photo. Listen to the VP introduce #BeingBiden: https:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BeingBiden",
        "indices" : [ 103, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/DjdxXozTHP",
        "expanded_url" : "https:\/\/soundcloud.com\/whitehouse\/welcome-intro-to-being-biden?utm_source=soundcloud&utm_campaign=share&utm_medium=twitter&utm_content=https:\/\/soundcloud.com\/whitehouse\/welcome-intro-to-being-biden",
        "display_url" : "soundcloud.com\/whitehouse\/wel\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "312261228028375040",
    "text" : "In a new audio series, Vice President Biden tells the story behind a photo. Listen to the VP introduce #BeingBiden: https:\/\/t.co\/DjdxXozTHP",
    "id" : 312261228028375040,
    "created_at" : "2013-03-14 17:57:32 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 312261932356882432,
  "created_at" : "2013-03-14 18:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/YCskiu1cw3",
      "expanded_url" : "http:\/\/flic.kr\/p\/dH3LAX",
      "display_url" : "flic.kr\/p\/dH3LAX"
    } ]
  },
  "geo" : { },
  "id_str" : "312196782916521985",
  "text" : "Happy Pi Day! http:\/\/t.co\/YCskiu1cw3",
  "id" : 312196782916521985,
  "created_at" : "2013-03-14 13:41:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 45, 56 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/311987912390606849\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/vZG73wFaCR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFRnWnTCAAEsFCM.jpg",
      "id_str" : "311987912398995457",
      "id" : 311987912398995457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFRnWnTCAAEsFCM.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/vZG73wFaCR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311987912390606849",
  "text" : "Photo of the Day: President Obama talks with @USTreasury Secretary Jack Lew on the Colonnade of the White House: http:\/\/t.co\/vZG73wFaCR",
  "id" : 311987912390606849,
  "created_at" : "2013-03-13 23:51:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/gRNq97bGqf",
      "expanded_url" : "http:\/\/at.wh.gov\/iT0yb",
      "display_url" : "at.wh.gov\/iT0yb"
    } ]
  },
  "geo" : { },
  "id_str" : "311967450445004800",
  "text" : "Statement from President Obama on His Holiness Pope Francis: http:\/\/t.co\/gRNq97bGqf",
  "id" : 311967450445004800,
  "created_at" : "2013-03-13 22:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/GbwSChEYow",
      "expanded_url" : "http:\/\/at.wh.gov\/iT0lV",
      "display_url" : "at.wh.gov\/iT0lV"
    } ]
  },
  "geo" : { },
  "id_str" : "311938535391383554",
  "text" : "\"On behalf of the American people, Michelle &amp; I offer our warm wishes to His Holiness Pope Francis\" \u2014President Obama: http:\/\/t.co\/GbwSChEYow",
  "id" : 311938535391383554,
  "created_at" : "2013-03-13 20:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reddit",
      "screen_name" : "reddit",
      "indices" : [ 84, 91 ],
      "id_str" : "811377",
      "id" : 811377
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/311896949072748544\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/dLwgn21DD4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFQUn2hCYAAScZV.jpg",
      "id_str" : "311896949076942848",
      "id" : 311896949076942848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFQUn2hCYAAScZV.jpg",
      "sizes" : [ {
        "h" : 534,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/dLwgn21DD4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/aRoq8UBuFQ",
      "expanded_url" : "http:\/\/on.wh.gov\/SfWFxLL",
      "display_url" : "on.wh.gov\/SfWFxLL"
    } ]
  },
  "geo" : { },
  "id_str" : "311896949072748544",
  "text" : "At 2ET: Gene Sperling, Director of the NEC, participates in an \"Ask Me Anything\" on @Reddit: http:\/\/t.co\/aRoq8UBuFQ http:\/\/t.co\/dLwgn21DD4",
  "id" : 311896949072748544,
  "created_at" : "2013-03-13 17:50:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reddit",
      "screen_name" : "reddit",
      "indices" : [ 3, 10 ],
      "id_str" : "811377",
      "id" : 811377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/TFbx6fbs2O",
      "expanded_url" : "http:\/\/redd.it\/1a7tl2",
      "display_url" : "redd.it\/1a7tl2"
    } ]
  },
  "geo" : { },
  "id_str" : "311862287805853697",
  "text" : "RT @reddit: I'm Gene Sperling, Assistant to President Obama for Economic Policy. AMA. http:\/\/t.co\/TFbx6fbs2O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/TFbx6fbs2O",
        "expanded_url" : "http:\/\/redd.it\/1a7tl2",
        "display_url" : "redd.it\/1a7tl2"
      } ]
    },
    "geo" : { },
    "id_str" : "311856801350037505",
    "text" : "I'm Gene Sperling, Assistant to President Obama for Economic Policy. AMA. http:\/\/t.co\/TFbx6fbs2O",
    "id" : 311856801350037505,
    "created_at" : "2013-03-13 15:10:30 +0000",
    "user" : {
      "name" : "Reddit",
      "screen_name" : "reddit",
      "protected" : false,
      "id_str" : "811377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667516091330002944\/wOaS8FKS_normal.png",
      "id" : 811377,
      "verified" : true
    }
  },
  "id" : 311862287805853697,
  "created_at" : "2013-03-13 15:32:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/311659227888381952\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/1WJH0GLeUw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFM8aqGCcAAfukr.jpg",
      "id_str" : "311659227892576256",
      "id" : 311659227892576256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFM8aqGCcAAfukr.jpg",
      "sizes" : [ {
        "h" : 732,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/1WJH0GLeUw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311659227888381952",
  "text" : "Photo of the Day: President Obama waits for the rain to pass before returning to the West Wing of the White House: http:\/\/t.co\/1WJH0GLeUw",
  "id" : 311659227888381952,
  "created_at" : "2013-03-13 02:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/311615368672194562\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/PYKBGtvqLu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFMUhtzCMAA9V9C.jpg",
      "id_str" : "311615368680583168",
      "id" : 311615368680583168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFMUhtzCMAA9V9C.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/PYKBGtvqLu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/IY7tF9xUZ9",
      "expanded_url" : "http:\/\/on.wh.gov\/JtZRUzl",
      "display_url" : "on.wh.gov\/JtZRUzl"
    } ]
  },
  "geo" : { },
  "id_str" : "311615368672194562",
  "text" : "FACT: Under President Obama, the deficit is coming down faster than at any time since WWII: http:\/\/t.co\/IY7tF9xUZ9 http:\/\/t.co\/PYKBGtvqLu",
  "id" : 311615368672194562,
  "created_at" : "2013-03-12 23:11:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/311603371150831616\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/5lkzziouPZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFMJnXiCcAE_we3.jpg",
      "id_str" : "311603371155025921",
      "id" : 311603371155025921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFMJnXiCcAE_we3.jpg",
      "sizes" : [ {
        "h" : 732,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 732,
        "resize" : "fit",
        "w" : 533
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/5lkzziouPZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311604112485670912",
  "text" : "RT @petesouza: Photo of POTUS waiting out a downpour today http:\/\/t.co\/5lkzziouPZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/311603371150831616\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/5lkzziouPZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BFMJnXiCcAE_we3.jpg",
        "id_str" : "311603371155025921",
        "id" : 311603371155025921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFMJnXiCcAE_we3.jpg",
        "sizes" : [ {
          "h" : 732,
          "resize" : "fit",
          "w" : 533
        }, {
          "h" : 732,
          "resize" : "fit",
          "w" : 533
        }, {
          "h" : 732,
          "resize" : "fit",
          "w" : 533
        }, {
          "h" : 467,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/5lkzziouPZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311603371150831616",
    "text" : "Photo of POTUS waiting out a downpour today http:\/\/t.co\/5lkzziouPZ",
    "id" : 311603371150831616,
    "created_at" : "2013-03-12 22:23:27 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 311604112485670912,
  "created_at" : "2013-03-12 22:26:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 1, 10 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/C7aQFzfZhp",
      "expanded_url" : "http:\/\/at.wh.gov\/iPyNt",
      "display_url" : "at.wh.gov\/iPyNt"
    } ]
  },
  "geo" : { },
  "id_str" : "311565773443305472",
  "text" : ".@PressSec: \"While the House Republican budget aims to reduce the deficit, the math just doesn't add up.\" Statement: http:\/\/t.co\/C7aQFzfZhp",
  "id" : 311565773443305472,
  "created_at" : "2013-03-12 19:54:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "311483879552868352",
  "text" : "Happening now: President Obama Speaks at President\u2019s Export Council: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 311483879552868352,
  "created_at" : "2013-03-12 14:28:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 52, 59 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/311478258900271104\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/QgGhN0imQC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFKX04FCAAIoAEv.jpg",
      "id_str" : "311478258904465410",
      "id" : 311478258904465410,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFKX04FCAAIoAEv.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QgGhN0imQC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311478258900271104",
  "text" : "Photo of the Day: Bo, the Obama family dog, follows @FLOTUS Michelle Obama across the South Lawn of the White House: http:\/\/t.co\/QgGhN0imQC",
  "id" : 311478258900271104,
  "created_at" : "2013-03-12 14:06:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/311241336567250945\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/saL7L1xZ0z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFHAWLoCQAIafqQ.jpg",
      "id_str" : "311241336575639554",
      "id" : 311241336575639554,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFHAWLoCQAIafqQ.jpg",
      "sizes" : [ {
        "h" : 802,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 687,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/saL7L1xZ0z"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/gPSV3vgFpf",
      "expanded_url" : "http:\/\/on.wh.gov\/ybTy1Up",
      "display_url" : "on.wh.gov\/ybTy1Up"
    } ]
  },
  "geo" : { },
  "id_str" : "311241336567250945",
  "text" : "President Obama has a plan that would end the sequester's harmful budget cuts. Get the facts: http:\/\/t.co\/gPSV3vgFpf http:\/\/t.co\/saL7L1xZ0z",
  "id" : 311241336567250945,
  "created_at" : "2013-03-11 22:24:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 123, 130 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311196152865386496",
  "text" : "RT @Sebelius: Hello Twitterverse. I\u2019m looking forward to reaching out to you and talking about the great work happening at @hhsgov http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HHS.gov",
        "screen_name" : "HHSGov",
        "indices" : [ 109, 116 ],
        "id_str" : "44783853",
        "id" : 44783853
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Sebelius\/status\/311160957399351296\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/RFfIvFwuOF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BFF3Pf6CQAAtWBA.jpg",
        "id_str" : "311160957411934208",
        "id" : 311160957411934208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFF3Pf6CQAAtWBA.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1363,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/RFfIvFwuOF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311160957399351296",
    "text" : "Hello Twitterverse. I\u2019m looking forward to reaching out to you and talking about the great work happening at @hhsgov http:\/\/t.co\/RFfIvFwuOF",
    "id" : 311160957399351296,
    "created_at" : "2013-03-11 17:05:28 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 311196152865386496,
  "created_at" : "2013-03-11 19:25:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 15, 22 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 61, 70 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskFLOTUS",
      "indices" : [ 134, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/KcYykTUiKy",
      "expanded_url" : "http:\/\/at.wh.gov\/iLmTE",
      "display_url" : "at.wh.gov\/iLmTE"
    } ]
  },
  "geo" : { },
  "id_str" : "311187960831815682",
  "text" : "Earlier today, @FLOTUS Michelle Obama answered your Qs about @LetsMove on Twitter. Check out the full Q&amp;A: http:\/\/t.co\/KcYykTUiKy #AskFLOTUS",
  "id" : 311187960831815682,
  "created_at" : "2013-03-11 18:52:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 22, 29 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 62, 71 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskFLOTUS",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 125, 147 ],
      "url" : "http:\/\/t.co\/ND46xANDy4",
      "expanded_url" : "http:\/\/at.wh.gov\/iHYsQ",
      "display_url" : "at.wh.gov\/iHYsQ"
    } ]
  },
  "geo" : { },
  "id_str" : "310927511506780160",
  "text" : "On 3\/11 at 11ET: Join @FLOTUS Michelle Obama for a Q&amp;A on @LetsMove &amp; keeping kids healthy. Submit Qs w\/ #AskFLOTUS: http:\/\/t.co\/ND46xANDy4",
  "id" : 310927511506780160,
  "created_at" : "2013-03-11 01:37:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 66, 75 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310860205560840192",
  "text" : "RT @FLOTUS: Tomorrow at 11:05ET, I'll answer some questions about @LetsMove &amp; how we can improve the health of our kids. Join with # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 54, 63 ],
        "id_str" : "36719281",
        "id" : 36719281
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskFLOTUS",
        "indices" : [ 123, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310857841814675456",
    "text" : "Tomorrow at 11:05ET, I'll answer some questions about @LetsMove &amp; how we can improve the health of our kids. Join with #AskFLOTUS \u2013mo",
    "id" : 310857841814675456,
    "created_at" : "2013-03-10 21:00:59 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 310860205560840192,
  "created_at" : "2013-03-10 21:10:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/wiHec7JTkM",
      "expanded_url" : "http:\/\/at.wh.gov\/iCFlO",
      "display_url" : "at.wh.gov\/iCFlO"
    } ]
  },
  "geo" : { },
  "id_str" : "310486465773715456",
  "text" : "President Obama: \"I\u2019ve been reaching out to Republicans &amp; Democrats to see if we can untangle some of the gridlock.\" http:\/\/t.co\/wiHec7JTkM",
  "id" : 310486465773715456,
  "created_at" : "2013-03-09 20:25:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sequester",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/ozVS4ljH4c",
      "expanded_url" : "http:\/\/at.wh.gov\/iCECA",
      "display_url" : "at.wh.gov\/iCECA"
    } ]
  },
  "geo" : { },
  "id_str" : "310392872144887810",
  "text" : "President Obama's Weekly Address: End the #Sequester to Keep Growing the Economy: http:\/\/t.co\/ozVS4ljH4c",
  "id" : 310392872144887810,
  "created_at" : "2013-03-09 14:13:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 18, 21 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/HdkJWnpzVM",
      "expanded_url" : "http:\/\/flic.kr\/p\/e1yMir",
      "display_url" : "flic.kr\/p\/e1yMir"
    } ]
  },
  "geo" : { },
  "id_str" : "310189762457763840",
  "text" : "Photo of the Day: @VP Biden swears in CIA Director John Brennan with an original draft of the Constitution from 1787: http:\/\/t.co\/HdkJWnpzVM",
  "id" : 310189762457763840,
  "created_at" : "2013-03-09 00:46:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/310141307647586305\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/m0UqNqDEzd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BE3X4EjCcAATOi0.jpg",
      "id_str" : "310141307651780608",
      "id" : 310141307651780608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BE3X4EjCcAATOi0.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1079,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1259,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 1259,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/m0UqNqDEzd"
    } ],
    "hashtags" : [ {
      "text" : "DidYouKnow",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/DRFsn5VCG0",
      "expanded_url" : "http:\/\/wh.gov\/sequester",
      "display_url" : "wh.gov\/sequester"
    } ]
  },
  "geo" : { },
  "id_str" : "310141307647586305",
  "text" : "#DidYouKnow President Obama has a plan that would end the sequester's harmful budget cuts http:\/\/t.co\/DRFsn5VCG0 http:\/\/t.co\/m0UqNqDEzd",
  "id" : 310141307647586305,
  "created_at" : "2013-03-08 21:33:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensDay",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/JOJqOtSCO7",
      "expanded_url" : "http:\/\/at.wh.gov\/izQmd",
      "display_url" : "at.wh.gov\/izQmd"
    } ]
  },
  "geo" : { },
  "id_str" : "310110270401949698",
  "text" : "Empowering women isn\u2019t just the right thing to do \u2013 it\u2019s the smart thing to do.\" -President Obama on Intl #WomensDay: http:\/\/t.co\/JOJqOtSCO7",
  "id" : 310110270401949698,
  "created_at" : "2013-03-08 19:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 22, 27 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 82, 87 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/WG3Kj127I0",
      "expanded_url" : "http:\/\/at.wh.gov\/izWqR",
      "display_url" : "at.wh.gov\/izWqR"
    } ]
  },
  "geo" : { },
  "id_str" : "310082388136972289",
  "text" : "Today at 3:45ET: Join @VJ44 for WH Office Hours on the Violence Against Women Act #VAWA. Ask Q's now with #WHChat: http:\/\/t.co\/WG3Kj127I0",
  "id" : 310082388136972289,
  "created_at" : "2013-03-08 17:39:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensDay",
      "indices" : [ 46, 56 ]
    }, {
      "text" : "IWD",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/RNeFn7aZjv",
      "expanded_url" : "http:\/\/at.wh.gov\/izQ1H",
      "display_url" : "at.wh.gov\/izQ1H"
    } ]
  },
  "geo" : { },
  "id_str" : "310065306963955712",
  "text" : "Statement from the President on International #WomensDay: http:\/\/t.co\/RNeFn7aZjv #IWD",
  "id" : 310065306963955712,
  "created_at" : "2013-03-08 16:31:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/310055090599886848\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ddpFIUoPQy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BE2JdlCCAAAmvHz.jpg",
      "id_str" : "310055090608275456",
      "id" : 310055090608275456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BE2JdlCCAAAmvHz.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/ddpFIUoPQy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/M6D6wZGwxg",
      "expanded_url" : "http:\/\/at.wh.gov\/izom0",
      "display_url" : "at.wh.gov\/izom0"
    } ]
  },
  "geo" : { },
  "id_str" : "310055090599886848",
  "text" : "More than 6.35 million private sector jobs were added in the past 36 months; more work to do: http:\/\/t.co\/M6D6wZGwxg http:\/\/t.co\/ddpFIUoPQy",
  "id" : 310055090599886848,
  "created_at" : "2013-03-08 15:51:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310036152507826176",
  "text" : "RT @Simas44: Much more work to do, but over 6 million new jobs in 3 years is good news for middle class and people working to get into it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "310034211702730752",
    "text" : "Much more work to do, but over 6 million new jobs in 3 years is good news for middle class and people working to get into it.",
    "id" : 310034211702730752,
    "created_at" : "2013-03-08 14:28:10 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 310036152507826176,
  "created_at" : "2013-03-08 14:35:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310036022178217984",
  "text" : "RT @Simas44: More on the positive jobs report for working families with the revised jobs chart and analysis from Alan Krueger. http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/dgp4iBcqqa",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/03\/08\/employment-situation-february",
        "display_url" : "whitehouse.gov\/blog\/2013\/03\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "310035853487521792",
    "text" : "More on the positive jobs report for working families with the revised jobs chart and analysis from Alan Krueger. http:\/\/t.co\/dgp4iBcqqa",
    "id" : 310035853487521792,
    "created_at" : "2013-03-08 14:34:42 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 310036022178217984,
  "created_at" : "2013-03-08 14:35:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 35, 38 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 46, 51 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/309898812623831041\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/DcXCJ9AWzy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEz7VANCQAAqPhy.jpg",
      "id_str" : "309898812632219648",
      "id" : 309898812632219648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEz7VANCQAAqPhy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/DcXCJ9AWzy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309898812623831041",
  "text" : "Photo of the Day: President Obama, @VP Biden, @VJ44 &amp; Kathleen Biden walk on the South Lawn of the White House: http:\/\/t.co\/DcXCJ9AWzy",
  "id" : 309898812623831041,
  "created_at" : "2013-03-08 05:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/WNNYins1fW",
      "expanded_url" : "http:\/\/at.wh.gov\/ixKhq",
      "display_url" : "at.wh.gov\/ixKhq"
    } ]
  },
  "geo" : { },
  "id_str" : "309884959752060928",
  "text" : "\"All women deserve the right to live free from fear. And that is what today is all about.\" \u2014President Obama on #VAWA: http:\/\/t.co\/WNNYins1fW",
  "id" : 309884959752060928,
  "created_at" : "2013-03-08 04:35:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 22, 25 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 138, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/rZUvZzaxTy",
      "expanded_url" : "http:\/\/at.wh.gov\/ixKdN",
      "display_url" : "at.wh.gov\/ixKdN"
    } ]
  },
  "geo" : { },
  "id_str" : "309866961335099393",
  "text" : "President Obama &amp; @VP Biden speak before the signing of the Violence Against Women Act Reauthorization. Watch: http:\/\/t.co\/rZUvZzaxTy #VAWA",
  "id" : 309866961335099393,
  "created_at" : "2013-03-08 03:23:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 92, 101 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/309811888269713408\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/quBQA1RFMB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEysRVwCYAAYrN6.jpg",
      "id_str" : "309811888278102016",
      "id" : 309811888278102016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEysRVwCYAAYrN6.jpg",
      "sizes" : [ {
        "h" : 531,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/quBQA1RFMB"
    } ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309811888269713408",
  "text" : "Today, President Obama signed the Violence Against Women Reauthorization Act of 2013 at the @Interior Dept #VAWA Pic: http:\/\/t.co\/quBQA1RFMB",
  "id" : 309811888269713408,
  "created_at" : "2013-03-07 23:44:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 117, 122 ]
    }, {
      "text" : "1is2Many",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/DhFpNXxCTF",
      "expanded_url" : "http:\/\/at.wh.gov\/iwFtV",
      "display_url" : "at.wh.gov\/iwFtV"
    } ]
  },
  "geo" : { },
  "id_str" : "309752235296952320",
  "text" : "FACT SHEET: Key Provisions in the Violence Against Women Act signed today by President Obama: http:\/\/t.co\/DhFpNXxCTF #VAWA #1is2Many",
  "id" : 309752235296952320,
  "created_at" : "2013-03-07 19:47:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309750824194686976",
  "text" : "President Obama: \"I promise you this \u2013 not just as your President, but as a son, as a husband, as a father \u2013 I\u2019m going to keep at it\" #VAWA",
  "id" : 309750824194686976,
  "created_at" : "2013-03-07 19:42:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309750434275401728",
  "text" : "RT @WHLive: President Obama: \"We\u2019ve made incredible progress since 1994. But we can\u2019t let up. Not now.\" #VAWA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 92, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309750343217070082",
    "text" : "President Obama: \"We\u2019ve made incredible progress since 1994. But we can\u2019t let up. Not now.\" #VAWA",
    "id" : 309750343217070082,
    "created_at" : "2013-03-07 19:40:11 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 309750434275401728,
  "created_at" : "2013-03-07 19:40:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309750253396045824",
  "text" : "RT @WHLive: President Obama: \"Today is about all the survivors and advocates standing on this stage\" #VAWA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 89, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309750188338196480",
    "text" : "President Obama: \"Today is about all the survivors and advocates standing on this stage\" #VAWA",
    "id" : 309750188338196480,
    "created_at" : "2013-03-07 19:39:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 309750253396045824,
  "created_at" : "2013-03-07 19:39:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309749775652245505",
  "text" : "RT @WHLive: Obama: \"Today is about all the Americans who\u2019ve faced discrimination based on sexual orientation &amp; gender identity when  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309749536354627584",
    "text" : "Obama: \"Today is about all the Americans who\u2019ve faced discrimination based on sexual orientation &amp; gender identity when they seek help\"",
    "id" : 309749536354627584,
    "created_at" : "2013-03-07 19:36:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 309749775652245505,
  "created_at" : "2013-03-07 19:37:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309749718303535104",
  "text" : "\"All women deserve the right to live free from fear. That\u2019s what today is about.\" \u2014President Obama on the Violence Against Women Act #VAWA",
  "id" : 309749718303535104,
  "created_at" : "2013-03-07 19:37:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309749145801981952",
  "text" : "RT @WHLive: President Obama: \"Today is about the millions of women...who are out there right now looking for a lifeline\" #VAWA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 109, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309748968089333761",
    "text" : "President Obama: \"Today is about the millions of women...who are out there right now looking for a lifeline\" #VAWA",
    "id" : 309748968089333761,
    "created_at" : "2013-03-07 19:34:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 309749145801981952,
  "created_at" : "2013-03-07 19:35:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309748451376242688",
  "text" : "RT @WHLive: President Obama on #VAWA: \"One of the great legacies of this law is that it didn\u2019t just change the rules; it changed our cul ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 19, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309748337194708992",
    "text" : "President Obama on #VAWA: \"One of the great legacies of this law is that it didn\u2019t just change the rules; it changed our culture.\"",
    "id" : 309748337194708992,
    "created_at" : "2013-03-07 19:32:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 309748451376242688,
  "created_at" : "2013-03-07 19:32:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309747527069085696",
  "text" : "President Obama: \"This is your victory &amp; it shows that when the American people make their voices heard, Washington listens\" #VAWA",
  "id" : 309747527069085696,
  "created_at" : "2013-03-07 19:28:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 113, 116 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309746215401172994",
  "text" : "\"Because of the people in this room, every time we reauthorized the Violence Against Women Act, we improved it\" -@VP Biden #VAWA",
  "id" : 309746215401172994,
  "created_at" : "2013-03-07 19:23:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 37, 40 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/lkB4xDG2Hw",
      "expanded_url" : "http:\/\/at.wh.gov\/iw0sF",
      "display_url" : "at.wh.gov\/iw0sF"
    } ]
  },
  "geo" : { },
  "id_str" : "309744292853866496",
  "text" : "Happening now: President Obama &amp; @VP Biden Speak at the Violence Against Women Act Bill Signing: http:\/\/t.co\/lkB4xDG2Hw #VAWA",
  "id" : 309744292853866496,
  "created_at" : "2013-03-07 19:16:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/8DOQ2JXNUT",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/1is2many\/resources",
      "display_url" : "whitehouse.gov\/1is2many\/resou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309740463110381569",
  "text" : "RT @VP: Get more info on key provisions in the Violence Against Women Act being signed into law today: http:\/\/t.co\/8DOQ2JXNUT  #VAWA #1i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 119, 124 ]
      }, {
        "text" : "1is2Many",
        "indices" : [ 125, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/8DOQ2JXNUT",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/1is2many\/resources",
        "display_url" : "whitehouse.gov\/1is2many\/resou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "309735613043716098",
    "text" : "Get more info on key provisions in the Violence Against Women Act being signed into law today: http:\/\/t.co\/8DOQ2JXNUT  #VAWA #1is2Many",
    "id" : 309735613043716098,
    "created_at" : "2013-03-07 18:41:39 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 309740463110381569,
  "created_at" : "2013-03-07 19:00:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 39, 42 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 138, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/lkB4xDG2Hw",
      "expanded_url" : "http:\/\/at.wh.gov\/iw0sF",
      "display_url" : "at.wh.gov\/iw0sF"
    } ]
  },
  "geo" : { },
  "id_str" : "309703177903685635",
  "text" : "Today at 1:55ET: President Obama &amp; @VP Biden Speak at the Violence Against Women Act Bill Signing. Watch live: http:\/\/t.co\/lkB4xDG2Hw #VAWA",
  "id" : 309703177903685635,
  "created_at" : "2013-03-07 16:32:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 38, 41 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 58, 69 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/309681088672976896\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/BG8hJPPn4k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEw1TzRCUAIIhMa.jpg",
      "id_str" : "309681088677171202",
      "id" : 309681088677171202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEw1TzRCUAIIhMa.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BG8hJPPn4k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309681088672976896",
  "text" : "Photo of the Day: President Obama and @VP Biden meet with @USTreasury Secretary Jack Lew in the Oval Office: http:\/\/t.co\/BG8hJPPn4k",
  "id" : 309681088672976896,
  "created_at" : "2013-03-07 15:04:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/309475004263854080\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Tdji6Ih2TJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEt54HCCcAAif71.jpg",
      "id_str" : "309475004272242688",
      "id" : 309475004272242688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEt54HCCcAAif71.jpg",
      "sizes" : [ {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 381,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Tdji6Ih2TJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309475004263854080",
  "text" : "From the Archives: Bo plays in the snow during a blizzard on the south lawn of the White House, Feb. 10, 2010: http:\/\/t.co\/Tdji6Ih2TJ",
  "id" : 309475004263854080,
  "created_at" : "2013-03-07 01:26:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/6luDtUInoR",
      "expanded_url" : "http:\/\/at.wh.gov\/isVq7",
      "display_url" : "at.wh.gov\/isVq7"
    } ]
  },
  "geo" : { },
  "id_str" : "309415752539205635",
  "text" : "From the Archives: Record setting snowfall blankets the White House in February 2010: http:\/\/t.co\/6luDtUInoR",
  "id" : 309415752539205635,
  "created_at" : "2013-03-06 21:30:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/309362361314209792\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/l6RebAAj7H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEsTbbWCcAA3pjO.jpg",
      "id_str" : "309362361322598400",
      "id" : 309362361322598400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEsTbbWCcAA3pjO.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/l6RebAAj7H"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/DRFsn5VCG0",
      "expanded_url" : "http:\/\/wh.gov\/sequester",
      "display_url" : "wh.gov\/sequester"
    } ]
  },
  "geo" : { },
  "id_str" : "309362361314209792",
  "text" : "Republicans in Congress are making a choice. The President has a plan to resolve harmful cuts: http:\/\/t.co\/DRFsn5VCG0 http:\/\/t.co\/l6RebAAj7H",
  "id" : 309362361314209792,
  "created_at" : "2013-03-06 17:58:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/309322025854459906\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/lMst75xFOa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEruvmDCYAAhy07.jpg",
      "id_str" : "309322025862848512",
      "id" : 309322025862848512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEruvmDCYAAhy07.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/lMst75xFOa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309322025854459906",
  "text" : "Photo of the Day: President Obama lands at Walter Reed Military Medical Center to visit with Wounded Warriors: http:\/\/t.co\/lMst75xFOa",
  "id" : 309322025854459906,
  "created_at" : "2013-03-06 15:18:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/309063175117103105\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/aPQVw1YXPG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEoDUf5CYAALQmk.png",
      "id_str" : "309063175121297408",
      "id" : 309063175121297408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEoDUf5CYAALQmk.png",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 266
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 151
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 4404,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 454
      } ],
      "display_url" : "pic.twitter.com\/aPQVw1YXPG"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/NHEzwPXuak",
      "expanded_url" : "http:\/\/on.wh.gov\/L2Qwd9X",
      "display_url" : "on.wh.gov\/L2Qwd9X"
    } ]
  },
  "geo" : { },
  "id_str" : "309063175117103105",
  "text" : "INFOGRAPHIC: President Obama's judicial nominees: Historic successes, unprecedented delays: http:\/\/t.co\/NHEzwPXuak http:\/\/t.co\/aPQVw1YXPG",
  "id" : 309063175117103105,
  "created_at" : "2013-03-05 22:09:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/309015629300649985\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/8GRGVnDFp7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEnYE98CUAAOg3a.jpg",
      "id_str" : "309015629309038592",
      "id" : 309015629309038592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEnYE98CUAAOg3a.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/8GRGVnDFp7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/DRFsn5VCG0",
      "expanded_url" : "http:\/\/wh.gov\/sequester",
      "display_url" : "wh.gov\/sequester"
    } ]
  },
  "geo" : { },
  "id_str" : "309015629300649985",
  "text" : "Republicans in Congress are choosing tax breaks for millionaires over meals for seniors: http:\/\/t.co\/DRFsn5VCG0 http:\/\/t.co\/8GRGVnDFp7",
  "id" : 309015629300649985,
  "created_at" : "2013-03-05 19:00:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/308795145728425985\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/8ZtsFo2hn6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEkPjIoCAAE4hXn.jpg",
      "id_str" : "308795145736814593",
      "id" : 308795145736814593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEkPjIoCAAE4hXn.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/8ZtsFo2hn6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/CIKKshbzCe",
      "expanded_url" : "http:\/\/on.wh.gov\/0wLKMue",
      "display_url" : "on.wh.gov\/0wLKMue"
    } ]
  },
  "geo" : { },
  "id_str" : "308795145728425985",
  "text" : "Photo of the Day: President Obama holds a Cabinet meeting in the Cabinet Room of the WH: http:\/\/t.co\/CIKKshbzCe http:\/\/t.co\/8ZtsFo2hn6",
  "id" : 308795145728425985,
  "created_at" : "2013-03-05 04:24:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHackathon",
      "indices" : [ 131, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/HHksjJYbGG",
      "expanded_url" : "http:\/\/at.wh.gov\/ilNcT",
      "display_url" : "at.wh.gov\/ilNcT"
    } ]
  },
  "geo" : { },
  "id_str" : "308731151038685185",
  "text" : "See what happened when we invited 21 developers &amp; tech experts to the first ever White House Hackathon: http:\/\/t.co\/HHksjJYbGG #WHHackathon",
  "id" : 308731151038685185,
  "created_at" : "2013-03-05 00:10:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 6, 13 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 100, 109 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/nMMVp8TS5o",
      "expanded_url" : "http:\/\/at.wh.gov\/ilcVy",
      "display_url" : "at.wh.gov\/ilcVy"
    } ]
  },
  "geo" : { },
  "id_str" : "308687771399241728",
  "text" : "Today @FLOTUS Michelle Obama joined Americans across the country in her first Google+ Hangout about @LetsMove. Watch: http:\/\/t.co\/nMMVp8TS5o",
  "id" : 308687771399241728,
  "created_at" : "2013-03-04 21:17:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 63, 70 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPAGov",
      "indices" : [ 72, 79 ],
      "id_str" : "1604108887",
      "id" : 1604108887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/L6hwbrEIil",
      "expanded_url" : "http:\/\/at.wh.gov\/ikV5T",
      "display_url" : "at.wh.gov\/ikV5T"
    } ]
  },
  "geo" : { },
  "id_str" : "308646081523245057",
  "text" : "Today, President Obama announced his nominees for Secretary of @Energy, @EPAGov Administrator &amp; OMB Director: http:\/\/t.co\/L6hwbrEIil",
  "id" : 308646081523245057,
  "created_at" : "2013-03-04 18:32:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 83, 92 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308612284312338433",
  "text" : "RT @FLOTUS: Happening now: First Lady Michelle Obama joins a Google+ Hangout about @LetsMove with families around the country: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 71, 80 ],
        "id_str" : "36719281",
        "id" : 36719281
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/MMD0Viy4SQ",
        "expanded_url" : "http:\/\/at.wh.gov\/ikpPZ",
        "display_url" : "at.wh.gov\/ikpPZ"
      } ]
    },
    "geo" : { },
    "id_str" : "308612055286554624",
    "text" : "Happening now: First Lady Michelle Obama joins a Google+ Hangout about @LetsMove with families around the country: http:\/\/t.co\/MMD0Viy4SQ",
    "id" : 308612055286554624,
    "created_at" : "2013-03-04 16:17:02 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 308612284312338433,
  "created_at" : "2013-03-04 16:17:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 29, 36 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 90, 99 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/lHFLdfXZk1",
      "expanded_url" : "http:\/\/at.wh.gov\/ikjcd",
      "display_url" : "at.wh.gov\/ikjcd"
    } ]
  },
  "geo" : { },
  "id_str" : "308602493267484672",
  "text" : "Watch live today at 11:10ET: @FLOTUS Michelle Obama joins her first Google+ Hangout about @Letsmove: http:\/\/t.co\/lHFLdfXZk1",
  "id" : 308602493267484672,
  "created_at" : "2013-03-04 15:39:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "308599650150133761",
  "text" : "Starting now: President Obama makes a personnel announcement live from the White House. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 308599650150133761,
  "created_at" : "2013-03-04 15:27:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/yvZ8PkSl5s",
      "expanded_url" : "http:\/\/at.wh.gov\/ik56j",
      "display_url" : "at.wh.gov\/ik56j"
    } ]
  },
  "geo" : { },
  "id_str" : "308587195646742530",
  "text" : "Happening at 10:15 ET: President Obama makes a personnel announcement from the White House. Watch live: http:\/\/t.co\/yvZ8PkSl5s",
  "id" : 308587195646742530,
  "created_at" : "2013-03-04 14:38:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sequester",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308257320339640320",
  "text" : "RT @PressSec: Obama on #sequester: \"none of this is necessary. It\u2019s happening because Republicans in Congress chose this outcome\" http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sequester",
        "indices" : [ 9, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/iyFZuIQ3HK",
        "expanded_url" : "http:\/\/at.wh.gov\/iekRL",
        "display_url" : "at.wh.gov\/iekRL"
      } ]
    },
    "geo" : { },
    "id_str" : "308194644372643840",
    "text" : "Obama on #sequester: \"none of this is necessary. It\u2019s happening because Republicans in Congress chose this outcome\" http:\/\/t.co\/iyFZuIQ3HK",
    "id" : 308194644372643840,
    "created_at" : "2013-03-03 12:38:23 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 308257320339640320,
  "created_at" : "2013-03-03 16:47:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/63Ri0YD0ej",
      "expanded_url" : "http:\/\/at.wh.gov\/iekOk",
      "display_url" : "at.wh.gov\/iekOk"
    } ]
  },
  "geo" : { },
  "id_str" : "308029971769737216",
  "text" : "\"I still believe we can and must replace these cuts with a balanced approach\" \u2014President Obama in his Weekly Address: http:\/\/t.co\/63Ri0YD0ej",
  "id" : 308029971769737216,
  "created_at" : "2013-03-03 01:44:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sequester",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/vlMq8WkXGO",
      "expanded_url" : "http:\/\/at.wh.gov\/id9Uw",
      "display_url" : "at.wh.gov\/id9Uw"
    } ]
  },
  "geo" : { },
  "id_str" : "307909441049735168",
  "text" : "Weekly Address: Congress Must Compromise to Stop the Impact of the #Sequester: http:\/\/t.co\/vlMq8WkXGO",
  "id" : 307909441049735168,
  "created_at" : "2013-03-02 17:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/fyXzfJjkFB",
      "expanded_url" : "http:\/\/at.wh.gov\/ibOE0",
      "display_url" : "at.wh.gov\/ibOE0"
    } ]
  },
  "geo" : { },
  "id_str" : "307647230691639296",
  "text" : "President Obama: \"We can &amp; must replace harmful cuts with a balanced approach that asks something from everybody\" http:\/\/t.co\/fyXzfJjkFB",
  "id" : 307647230691639296,
  "created_at" : "2013-03-02 00:23:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307644018760757249",
  "text" : "RT @vj44: President Obama: \"These cuts will hurt our economy and cost us jobs. To set it right, both sides need to compromise\" http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/PCbAsPs8JA",
        "expanded_url" : "http:\/\/wh.gov\/wMOe",
        "display_url" : "wh.gov\/wMOe"
      } ]
    },
    "geo" : { },
    "id_str" : "307618891423686656",
    "text" : "President Obama: \"These cuts will hurt our economy and cost us jobs. To set it right, both sides need to compromise\" http:\/\/t.co\/PCbAsPs8JA",
    "id" : 307618891423686656,
    "created_at" : "2013-03-01 22:30:33 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 307644018760757249,
  "created_at" : "2013-03-02 00:10:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307598583740387329",
  "text" : "RT @PressSec: Thousands of middle class jobs are at risk because Congress made a choice to protect tax loopholes for wealthy: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/mSce8TumNe",
        "expanded_url" : "http:\/\/wh.gov\/sequester",
        "display_url" : "wh.gov\/sequester"
      } ]
    },
    "geo" : { },
    "id_str" : "307597716375080960",
    "text" : "Thousands of middle class jobs are at risk because Congress made a choice to protect tax loopholes for wealthy: http:\/\/t.co\/mSce8TumNe",
    "id" : 307597716375080960,
    "created_at" : "2013-03-01 21:06:25 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 307598583740387329,
  "created_at" : "2013-03-01 21:09:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/307584535976112128\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/lIZlgavhuR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BETCgX3CcAETg65.jpg",
      "id_str" : "307584535984500737",
      "id" : 307584535984500737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BETCgX3CcAETg65.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 806
      } ],
      "display_url" : "pic.twitter.com\/lIZlgavhuR"
    } ],
    "hashtags" : [ {
      "text" : "Sequester",
      "indices" : [ 36, 46 ]
    }, {
      "text" : "JediMindMeld",
      "indices" : [ 47, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307584535976112128",
  "text" : "We must bring balance to the Force. #Sequester #JediMindMeld http:\/\/t.co\/lIZlgavhuR",
  "id" : 307584535976112128,
  "created_at" : "2013-03-01 20:14:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307531764711190528",
  "text" : "Obama: \"We just need Republicans in Congress to catch up to their own party and their country on this, and we could make a lot of progress\"",
  "id" : 307531764711190528,
  "created_at" : "2013-03-01 16:44:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307531593768132608",
  "text" : "President Obama: \"I still believe we can and must replace these cuts with a balanced approach that asks something from everybody\"",
  "id" : 307531593768132608,
  "created_at" : "2013-03-01 16:43:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307531339660410882",
  "text" : "President Obama: \"Every time we get a piece of economic news, we\u2019ll know it could have been better if not for Congress\u2019 failure to act.\"",
  "id" : 307531339660410882,
  "created_at" : "2013-03-01 16:42:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307530994414653440",
  "text" : "Obama: \"Now, what\u2019s important to understand is that not everyone will feel the pain of these cuts right away. But the pain will be real.\"",
  "id" : 307530994414653440,
  "created_at" : "2013-03-01 16:41:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "307530492532621313",
  "text" : "Happening now: President Obama delivers a statement to the press. Watch: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 307530492532621313,
  "created_at" : "2013-03-01 16:39:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/b4tqL3nPDV",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "307526392394948608",
  "text" : "Happening at 11:35ET: President Obama delivers a statement from the Press Briefing Room. Watch live: http:\/\/t.co\/b4tqL3nPDV",
  "id" : 307526392394948608,
  "created_at" : "2013-03-01 16:23:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]