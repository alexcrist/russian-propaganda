Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Shilla Bakery & Cafe",
      "screen_name" : "ShillaBakery",
      "indices" : [ 57, 70 ],
      "id_str" : "26791420",
      "id" : 26791420
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 89, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406983235055677440",
  "text" : "RT @arneduncan: Our family loved the delicious treats at @ShillaBakery in Annandale, VA! #SmallBizSat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Shilla Bakery & Cafe",
        "screen_name" : "ShillaBakery",
        "indices" : [ 41, 54 ],
        "id_str" : "26791420",
        "id" : 26791420
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 73, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406900258195513344",
    "text" : "Our family loved the delicious treats at @ShillaBakery in Annandale, VA! #SmallBizSat",
    "id" : 406900258195513344,
    "created_at" : "2013-11-30 21:39:16 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 406983235055677440,
  "created_at" : "2013-12-01 03:08:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 3, 15 ],
      "id_str" : "110541296",
      "id" : 110541296
    }, {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 18, 30 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CommerceGov\/status\/406811263381934080\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/t8MjVvjOFZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaVIsEzCEAIlJ5M.jpg",
      "id_str" : "406811263386128386",
      "id" : 406811263386128386,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaVIsEzCEAIlJ5M.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/t8MjVvjOFZ"
    } ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406982589749399552",
  "text" : "RT @CommerceGov: .@CommerceSec supporting small businesses by shopping on Small Business Saturday #SmallBizSat http:\/\/t.co\/t8MjVvjOFZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CommerceSec",
        "screen_name" : "CommerceSec",
        "indices" : [ 1, 13 ],
        "id_str" : "2319148561",
        "id" : 2319148561
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CommerceGov\/status\/406811263381934080\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/t8MjVvjOFZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaVIsEzCEAIlJ5M.jpg",
        "id_str" : "406811263386128386",
        "id" : 406811263386128386,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaVIsEzCEAIlJ5M.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/t8MjVvjOFZ"
      } ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 81, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406811263381934080",
    "text" : ".@CommerceSec supporting small businesses by shopping on Small Business Saturday #SmallBizSat http:\/\/t.co\/t8MjVvjOFZ",
    "id" : 406811263381934080,
    "created_at" : "2013-11-30 15:45:38 +0000",
    "user" : {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "protected" : false,
      "id_str" : "110541296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/645983513712459776\/3Q0H2IVF_normal.jpg",
      "id" : 110541296,
      "verified" : true
    }
  },
  "id" : 406982589749399552,
  "created_at" : "2013-12-01 03:06:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tour du lich Da Lat",
      "screen_name" : "Politics_Prose",
      "indices" : [ 52, 67 ],
      "id_str" : "3390044115",
      "id" : 3390044115
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/406894874038788096\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/hwc82JcBtN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaWUu2xCYAEPWR-.jpg",
      "id_str" : "406894874042982401",
      "id" : 406894874042982401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaWUu2xCYAEPWR-.jpg",
      "sizes" : [ {
        "h" : 1370,
        "resize" : "fit",
        "w" : 930
      }, {
        "h" : 884,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 501,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1370,
        "resize" : "fit",
        "w" : 930
      } ],
      "display_url" : "pic.twitter.com\/hwc82JcBtN"
    } ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406894874038788096",
  "text" : "President Obama, Sasha, and Malia shop for books at @Politics_Prose\u2014a local bookstore in D.C. #SmallBizSat, http:\/\/t.co\/hwc82JcBtN",
  "id" : 406894874038788096,
  "created_at" : "2013-11-30 21:17:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBusinessSaturday",
      "indices" : [ 100, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406845628761657344",
  "text" : "RT @Cecilia44: The wonderful Lene and Abeba Tsegaye, owners of Kefa Cafe and neighborhood stalwarts #SmallBusinessSaturday http:\/\/t.co\/9l0E\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cecilia44\/status\/406832867973791744\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/9l0E6eQeaV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaVcVnpIgAA3LEL.jpg",
        "id_str" : "406832867835412480",
        "id" : 406832867835412480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaVcVnpIgAA3LEL.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/9l0E6eQeaV"
      } ],
      "hashtags" : [ {
        "text" : "SmallBusinessSaturday",
        "indices" : [ 85, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406832867973791744",
    "text" : "The wonderful Lene and Abeba Tsegaye, owners of Kefa Cafe and neighborhood stalwarts #SmallBusinessSaturday http:\/\/t.co\/9l0E6eQeaV",
    "id" : 406832867973791744,
    "created_at" : "2013-11-30 17:11:28 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 406845628761657344,
  "created_at" : "2013-11-30 18:02:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 82, 87 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/uNOlNQKBN5",
      "expanded_url" : "http:\/\/go.wh.gov\/LHc82L",
      "display_url" : "go.wh.gov\/LHc82L"
    } ]
  },
  "geo" : { },
  "id_str" : "406837613572538368",
  "text" : "\u201CSmall businesses are the engines of our economy, and the key to creating jobs.\u201D \u2014@VJ44: http:\/\/t.co\/uNOlNQKBN5 #SmallBizSat",
  "id" : 406837613572538368,
  "created_at" : "2013-11-30 17:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBusinessSaturday",
      "indices" : [ 97, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/BKUpgfLGOe",
      "expanded_url" : "http:\/\/ow.ly\/rjiEK",
      "display_url" : "ow.ly\/rjiEK"
    } ]
  },
  "geo" : { },
  "id_str" : "406823199054524418",
  "text" : "RT @vj44: When we support the dedication of our neighbors &amp; their businesses, everyone wins! #SmallBusinessSaturday http:\/\/t.co\/BKUpgfLGOe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBusinessSaturday",
        "indices" : [ 87, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/BKUpgfLGOe",
        "expanded_url" : "http:\/\/ow.ly\/rjiEK",
        "display_url" : "ow.ly\/rjiEK"
      } ]
    },
    "geo" : { },
    "id_str" : "406822660304166912",
    "text" : "When we support the dedication of our neighbors &amp; their businesses, everyone wins! #SmallBusinessSaturday http:\/\/t.co\/BKUpgfLGOe",
    "id" : 406822660304166912,
    "created_at" : "2013-11-30 16:30:55 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 406823199054524418,
  "created_at" : "2013-11-30 16:33:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406811392876871680",
  "text" : "When our small businesses do well, our communities do well. Join me and visit a small business near you today to celebrate #SmallBizSat. \u2013bo",
  "id" : 406811392876871680,
  "created_at" : "2013-11-30 15:46:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406514635668733952",
  "text" : "RT @lacasablanca: RT @fast4families President Obama, @FLOTUS &amp; the fasters today: \"it's not a matter of if, but of when\" #Fast4Families htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 35, 42 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/406509964510134273\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/lOQW2VIQVQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaQ2qKcIUAAxyOD.jpg",
        "id_str" : "406509964354932736",
        "id" : 406509964354932736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaQ2qKcIUAAxyOD.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/lOQW2VIQVQ"
      } ],
      "hashtags" : [ {
        "text" : "Fast4Families",
        "indices" : [ 107, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406509964510134273",
    "text" : "RT @fast4families President Obama, @FLOTUS &amp; the fasters today: \"it's not a matter of if, but of when\" #Fast4Families http:\/\/t.co\/lOQW2VIQVQ",
    "id" : 406509964510134273,
    "created_at" : "2013-11-29 19:48:22 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 406514635668733952,
  "created_at" : "2013-11-29 20:06:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/406505513170391040\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/aWuQnnqfpu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaQynEhCUAAXcnT.jpg",
      "id_str" : "406505513178779648",
      "id" : 406505513178779648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaQynEhCUAAXcnT.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/aWuQnnqfpu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406505513170391040",
  "text" : "Special delivery! The First Lady welcomes the official White House Christmas Tree to the North Portico. http:\/\/t.co\/aWuQnnqfpu",
  "id" : 406505513170391040,
  "created_at" : "2013-11-29 19:30:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ZHf60Z0Ruo",
      "expanded_url" : "http:\/\/go.wh.gov\/s6RHUG",
      "display_url" : "go.wh.gov\/s6RHUG"
    } ]
  },
  "geo" : { },
  "id_str" : "406158125566144512",
  "text" : "\"We give thanks to everyone who\u2019s doing their part to make the U.S. a better, more compassionate nation.\" \u2014Obama: http:\/\/t.co\/ZHf60Z0Ruo",
  "id" : 406158125566144512,
  "created_at" : "2013-11-28 20:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/C1OKjQVOv5",
      "expanded_url" : "http:\/\/go.wh.gov\/aPeksK",
      "display_url" : "go.wh.gov\/aPeksK"
    } ]
  },
  "geo" : { },
  "id_str" : "406135480426561536",
  "text" : "\"We are a people who are greater together than we are on our own. That\u2019s what today is about.\" \u2014Obama: http:\/\/t.co\/C1OKjQVOv5 #Thanksgiving",
  "id" : 406135480426561536,
  "created_at" : "2013-11-28 19:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/XWkyxswKm7",
      "expanded_url" : "http:\/\/go.wh.gov\/ZXyD1t",
      "display_url" : "go.wh.gov\/ZXyD1t"
    } ]
  },
  "geo" : { },
  "id_str" : "406120379933917185",
  "text" : "\"We give thanks for all our men &amp; women in uniform &amp; for their families...we\u2019re grateful for their sacrifice\" \u2014Obama: http:\/\/t.co\/XWkyxswKm7",
  "id" : 406120379933917185,
  "created_at" : "2013-11-28 18:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyThanksgiving",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406105507967938560",
  "text" : "Today, let's pledge to help our fellow Americans in need, because we are greater together than we are on our own. #HappyThanksgiving \u2013bo",
  "id" : 406105507967938560,
  "created_at" : "2013-11-28 17:01:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406097622034681856",
  "text" : "RT @FLOTUS: This #Thanksgiving, let's give thanks for all our brave men &amp; women in uniform and their families. We're so grateful for your s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Thanksgiving",
        "indices" : [ 5, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "406090172149673985",
    "text" : "This #Thanksgiving, let's give thanks for all our brave men &amp; women in uniform and their families. We're so grateful for your sacrifice. -mo",
    "id" : 406090172149673985,
    "created_at" : "2013-11-28 16:00:16 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 406097622034681856,
  "created_at" : "2013-11-28 16:29:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/DYA15O3EZv",
      "expanded_url" : "http:\/\/go.wh.gov\/HsFGkz",
      "display_url" : "go.wh.gov\/HsFGkz"
    } ]
  },
  "geo" : { },
  "id_str" : "406090181628801024",
  "text" : "\u201COn behalf of all the Obamas...I want to wish you a happy and healthy #Thanksgiving.\u201D \u2014President Obama: http:\/\/t.co\/DYA15O3EZv",
  "id" : 406090181628801024,
  "created_at" : "2013-11-28 16:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/406075518216585216\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/R8RYLDN16i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaKriDzIEAAustj.jpg",
      "id_str" : "406075518040412160",
      "id" : 406075518040412160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaKriDzIEAAustj.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/R8RYLDN16i"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406075518216585216",
  "text" : "Happy Thanksgiving! http:\/\/t.co\/R8RYLDN16i",
  "id" : 406075518216585216,
  "created_at" : "2013-11-28 15:02:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/405890312058331136\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/QtLOJeEdtD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaIDFnrCMAAODho.jpg",
      "id_str" : "405890311500476416",
      "id" : 405890311500476416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaIDFnrCMAAODho.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 1003
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1003
      } ],
      "display_url" : "pic.twitter.com\/QtLOJeEdtD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405895933868908544",
  "text" : "RT @petesouza: Pres Obama greets a young girl while volunteering at the Capital Area Food Bank in DC today http:\/\/t.co\/QtLOJeEdtD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/405890312058331136\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/QtLOJeEdtD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BaIDFnrCMAAODho.jpg",
        "id_str" : "405890311500476416",
        "id" : 405890311500476416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaIDFnrCMAAODho.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 1003
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1003
        } ],
        "display_url" : "pic.twitter.com\/QtLOJeEdtD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405890312058331136",
    "text" : "Pres Obama greets a young girl while volunteering at the Capital Area Food Bank in DC today http:\/\/t.co\/QtLOJeEdtD",
    "id" : 405890312058331136,
    "created_at" : "2013-11-28 02:46:06 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 405895933868908544,
  "created_at" : "2013-11-28 03:08:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/405846212307189761\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/Qyuj06UMhl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaHa-szCAAEDVrG.jpg",
      "id_str" : "405846212152000513",
      "id" : 405846212152000513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaHa-szCAAEDVrG.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/Qyuj06UMhl"
    } ],
    "hashtags" : [ {
      "text" : "TeamPopcorn",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405846212307189761",
  "text" : "President Obama: \u201CPopcorn, you have a full reprieve from cranberry sauce &amp; stuffing. We wish you well.\u201D #TeamPopcorn http:\/\/t.co\/Qyuj06UMhl",
  "id" : 405846212307189761,
  "created_at" : "2013-11-27 23:50:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/405819355927433216\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/O7KoHcUt4e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaHCjc6IgAEXVl6.jpg",
      "id_str" : "405819355751284737",
      "id" : 405819355751284737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaHCjc6IgAEXVl6.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/O7KoHcUt4e"
    } ],
    "hashtags" : [ {
      "text" : "SNAP",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/w1BsVPHBNn",
      "expanded_url" : "http:\/\/go.wh.gov\/sDBFgp",
      "display_url" : "go.wh.gov\/sDBFgp"
    } ]
  },
  "geo" : { },
  "id_str" : "405819355927433216",
  "text" : "FACT: The Farm Bill helped keep 5 million Americans out of poverty last year \u2014&gt; http:\/\/t.co\/w1BsVPHBNn #SNAP, http:\/\/t.co\/O7KoHcUt4e",
  "id" : 405819355927433216,
  "created_at" : "2013-11-27 22:04:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/BNwXD5M8uy",
      "expanded_url" : "http:\/\/go.wh.gov\/KrAvJ6",
      "display_url" : "go.wh.gov\/KrAvJ6"
    } ]
  },
  "geo" : { },
  "id_str" : "405809964368666624",
  "text" : "Here\u2019s how Congress can help keep millions of Americans out of poverty by helping them put food on the table \u2014&gt; http:\/\/t.co\/BNwXD5M8uy",
  "id" : 405809964368666624,
  "created_at" : "2013-11-27 21:26:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyHanukkah",
      "indices" : [ 82, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/wmnsMSFUDR",
      "expanded_url" : "http:\/\/go.wh.gov\/uWX78H",
      "display_url" : "go.wh.gov\/uWX78H"
    } ]
  },
  "geo" : { },
  "id_str" : "405784658777874434",
  "text" : "\u201CFrom my family to yours, Chag Sameach!\u201D \u2014President Obama: http:\/\/t.co\/wmnsMSFUDR #HappyHanukkah",
  "id" : 405784658777874434,
  "created_at" : "2013-11-27 19:46:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/405772724179460096\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/F2tNXdxpsN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaGYJIyCYAE1NJk.jpg",
      "id_str" : "405772724183654401",
      "id" : 405772724183654401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaGYJIyCYAE1NJk.jpg",
      "sizes" : [ {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/F2tNXdxpsN"
    } ],
    "hashtags" : [ {
      "text" : "TeamPopcorn",
      "indices" : [ 12, 24 ]
    }, {
      "text" : "DontWorryTheyBothLive",
      "indices" : [ 81, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405772724179460096",
  "text" : "Congrats to #TeamPopcorn! Your bird is this year\u2019s National Thanksgiving Turkey. #DontWorryTheyBothLive, http:\/\/t.co\/F2tNXdxpsN",
  "id" : 405772724179460096,
  "created_at" : "2013-11-27 18:58:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405768044183429120",
  "text" : "President Obama: \"On behalf of the entire Obama family, I want to wish you all a very Happy Thanksgiving.\"",
  "id" : 405768044183429120,
  "created_at" : "2013-11-27 18:40:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamCaramel",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405767015412928512",
  "text" : "RT @WHLive: President Obama: \"Just for the heck of it, I\u2019m giving Caramel a break and pardoning him too.\" #TeamCaramel",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamCaramel",
        "indices" : [ 94, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405766977588695040",
    "text" : "President Obama: \"Just for the heck of it, I\u2019m giving Caramel a break and pardoning him too.\" #TeamCaramel",
    "id" : 405766977588695040,
    "created_at" : "2013-11-27 18:36:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 405767015412928512,
  "created_at" : "2013-11-27 18:36:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405766930784481280",
  "text" : "RT @WHLive: President Obama: \"With the power vested in me, I grant Popcorn full reprieve from a future of stuffing and cranberry sauce.\" #T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamPopcorn",
        "indices" : [ 125, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405766863243579392",
    "text" : "President Obama: \"With the power vested in me, I grant Popcorn full reprieve from a future of stuffing and cranberry sauce.\" #TeamPopcorn",
    "id" : 405766863243579392,
    "created_at" : "2013-11-27 18:35:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 405766930784481280,
  "created_at" : "2013-11-27 18:35:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405766694632583168",
  "text" : "RT @WHLive: Obama: \"On this quintessentially American holiday, we give thanks for friends &amp; family; for citizens who show compassion to tho\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405766601296715776",
    "text" : "Obama: \"On this quintessentially American holiday, we give thanks for friends &amp; family; for citizens who show compassion to those in need.\"",
    "id" : 405766601296715776,
    "created_at" : "2013-11-27 18:34:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 405766694632583168,
  "created_at" : "2013-11-27 18:34:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405766465304793089",
  "text" : "President Obama: \"As for Caramel, he\u2019s sticking around, and he\u2019s already busy raising money for his next campaign.\"",
  "id" : 405766465304793089,
  "created_at" : "2013-11-27 18:33:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405766352519983104",
  "text" : "Obama: \"We can officially declare that Popcorn is the winner\u2014proving that even a turkey with a funny name can find a place in politics.\"",
  "id" : 405766352519983104,
  "created_at" : "2013-11-27 18:33:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405766237105319936",
  "text" : "Obama: \"After weeks of vocal practice &amp; prepping for the cameras...Caramel &amp; Popcorn went head-to-head...for America\u2019s vote as top gobbler.\"",
  "id" : 405766237105319936,
  "created_at" : "2013-11-27 18:33:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405766139059253248",
  "text" : "Obama: \"Thanksgiving is a bad day to be a turkey\u2014especially at a house with 2 dogs. So I salute our 2 guests of honor\u2014Caramel and Popcorn.\"",
  "id" : 405766139059253248,
  "created_at" : "2013-11-27 18:32:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamPopcorn",
      "indices" : [ 104, 116 ]
    }, {
      "text" : "TeamCaramel",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/mcO8uiLkPr",
      "expanded_url" : "http:\/\/go.wh.gov\/6cZVmp",
      "display_url" : "go.wh.gov\/6cZVmp"
    } ]
  },
  "geo" : { },
  "id_str" : "405765718659981312",
  "text" : "Right now: President Obama pardons the National Thanksgiving Turkey. Watch \u2014&gt; http:\/\/t.co\/mcO8uiLkPr #TeamPopcorn #TeamCaramel",
  "id" : 405765718659981312,
  "created_at" : "2013-11-27 18:31:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamPopcorn",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "TeamCaramel",
      "indices" : [ 13, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/srPkcXiPYP",
      "expanded_url" : "http:\/\/go.wh.gov\/7AMQQP",
      "display_url" : "go.wh.gov\/7AMQQP"
    } ]
  },
  "geo" : { },
  "id_str" : "405756348287045632",
  "text" : "#TeamPopcorn\n#TeamCaramel\nOnly one can be your National Thanksgiving Turkey.\nFind out who wins at 1:20pm ET \u2014&gt; http:\/\/t.co\/srPkcXiPYP",
  "id" : 405756348287045632,
  "created_at" : "2013-11-27 17:53:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 120, 125 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/HmbyVOX1Nu",
      "expanded_url" : "http:\/\/www.wh.gov\/wethegeeks",
      "display_url" : "wh.gov\/wethegeeks"
    } ]
  },
  "geo" : { },
  "id_str" : "405743752712445952",
  "text" : "RT @whitehouseostp: Starting shortly! #WeTheGeeks on the science of cooking http:\/\/t.co\/HmbyVOX1Nu\nSubmit your Q's now! @nasa @chefanneburr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 100, 105 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "anne burrell",
        "screen_name" : "chefanneburrell",
        "indices" : [ 106, 122 ],
        "id_str" : "128263500",
        "id" : 128263500
      }, {
        "name" : "Ron Garan",
        "screen_name" : "Astro_Ron",
        "indices" : [ 123, 133 ],
        "id_str" : "82453323",
        "id" : 82453323
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 18, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/HmbyVOX1Nu",
        "expanded_url" : "http:\/\/www.wh.gov\/wethegeeks",
        "display_url" : "wh.gov\/wethegeeks"
      } ]
    },
    "geo" : { },
    "id_str" : "405743151752949760",
    "text" : "Starting shortly! #WeTheGeeks on the science of cooking http:\/\/t.co\/HmbyVOX1Nu\nSubmit your Q's now! @nasa @chefanneburrell @Astro_Ron",
    "id" : 405743151752949760,
    "created_at" : "2013-11-27 17:01:20 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 405743752712445952,
  "created_at" : "2013-11-27 17:03:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/fHmgIWIEeA",
      "expanded_url" : "http:\/\/go.wh.gov\/piK3Ms",
      "display_url" : "go.wh.gov\/piK3Ms"
    } ]
  },
  "geo" : { },
  "id_str" : "405733141362376704",
  "text" : "Ready to talk turkey? Don\u2019t miss today\u2019s #WeTheGeeks hangout on the science of cooking at 12pm ET\u2014&gt; http:\/\/t.co\/fHmgIWIEeA",
  "id" : 405733141362376704,
  "created_at" : "2013-11-27 16:21:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamPopcorn",
      "indices" : [ 34, 46 ]
    }, {
      "text" : "TeamCaramel",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/tDhqHn2xJY",
      "expanded_url" : "http:\/\/go.wh.gov\/FDAm5t",
      "display_url" : "go.wh.gov\/FDAm5t"
    } ]
  },
  "geo" : { },
  "id_str" : "405721569722253314",
  "text" : "Don't miss the epic conclusion to #TeamPopcorn vs #TeamCaramel.\nPresident Obama announces the winner at 1:20pm ET \u2014&gt; http:\/\/t.co\/tDhqHn2xJY",
  "id" : 405721569722253314,
  "created_at" : "2013-11-27 15:35:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "indices" : [ 3, 13 ],
      "id_str" : "18622869",
      "id" : 18622869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/eVtfmRDlC6",
      "expanded_url" : "http:\/\/wapo.st\/1b39nRg",
      "display_url" : "wapo.st\/1b39nRg"
    } ]
  },
  "geo" : { },
  "id_str" : "405716337873678338",
  "text" : "RT @ezraklein: Obamacare really is starting to work better: http:\/\/t.co\/eVtfmRDlC6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/eVtfmRDlC6",
        "expanded_url" : "http:\/\/wapo.st\/1b39nRg",
        "display_url" : "wapo.st\/1b39nRg"
      } ]
    },
    "geo" : { },
    "id_str" : "405465620939956224",
    "text" : "Obamacare really is starting to work better: http:\/\/t.co\/eVtfmRDlC6",
    "id" : 405465620939956224,
    "created_at" : "2013-11-26 22:38:31 +0000",
    "user" : {
      "name" : "Ezra Klein",
      "screen_name" : "ezraklein",
      "protected" : false,
      "id_str" : "18622869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430528937022595072\/ivuRfUNj_normal.jpeg",
      "id" : 18622869,
      "verified" : true
    }
  },
  "id" : 405716337873678338,
  "created_at" : "2013-11-27 15:14:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamPopcorn",
      "indices" : [ 71, 83 ]
    }, {
      "text" : "TeamCaramel",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/oVcLKTHLoe",
      "expanded_url" : "http:\/\/www.wh.gov\/turkey",
      "display_url" : "wh.gov\/turkey"
    } ]
  },
  "geo" : { },
  "id_str" : "405486681597300737",
  "text" : "Just one hour left to help choose the National Thanksgiving Turkey!\n1. #TeamPopcorn\n2. #TeamCaramel\nVOTE \u2014&gt; http:\/\/t.co\/oVcLKTHLoe",
  "id" : 405486681597300737,
  "created_at" : "2013-11-27 00:02:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405482405676339200",
  "text" : "FACT: More than 7.3 million Americans with Medicare have saved an average of $1,137 each on prescription drugs thanks to #Obamacare.",
  "id" : 405482405676339200,
  "created_at" : "2013-11-26 23:45:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/EhCdtQTkYY",
      "expanded_url" : "http:\/\/go.wh.gov\/j98UCX",
      "display_url" : "go.wh.gov\/j98UCX"
    } ]
  },
  "geo" : { },
  "id_str" : "405478635387092992",
  "text" : "Thanks to #Obamacare, more than 7.3 million Americans w\/ Medicare have saved nearly $9 billion on prescription drugs. http:\/\/t.co\/EhCdtQTkYY",
  "id" : 405478635387092992,
  "created_at" : "2013-11-26 23:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecKerry",
      "indices" : [ 30, 39 ]
    }, {
      "text" : "Iran",
      "indices" : [ 81, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/StpjP6DJfp",
      "expanded_url" : "http:\/\/youtu.be\/xF7-TudQ9xA",
      "display_url" : "youtu.be\/xF7-TudQ9xA"
    } ]
  },
  "geo" : { },
  "id_str" : "405474457247956992",
  "text" : "RT @StateDept: Just released! #SecKerry\u2019s video message on the Geneva talks with #Iran: http:\/\/t.co\/StpjP6DJfp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecKerry",
        "indices" : [ 15, 24 ]
      }, {
        "text" : "Iran",
        "indices" : [ 66, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/StpjP6DJfp",
        "expanded_url" : "http:\/\/youtu.be\/xF7-TudQ9xA",
        "display_url" : "youtu.be\/xF7-TudQ9xA"
      } ]
    },
    "geo" : { },
    "id_str" : "405380759701053441",
    "text" : "Just released! #SecKerry\u2019s video message on the Geneva talks with #Iran: http:\/\/t.co\/StpjP6DJfp",
    "id" : 405380759701053441,
    "created_at" : "2013-11-26 17:01:19 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 405474457247956992,
  "created_at" : "2013-11-26 23:13:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/405468117905588224\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Wu5YCFqZXh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaCDGtFCMAE-KhQ.jpg",
      "id_str" : "405468117666508801",
      "id" : 405468117666508801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaCDGtFCMAE-KhQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Wu5YCFqZXh"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405468117905588224",
  "text" : "RT to spread the word: Americans with Medicare are saving millions on prescription drugs thanks to #Obamacare. http:\/\/t.co\/Wu5YCFqZXh",
  "id" : 405468117905588224,
  "created_at" : "2013-11-26 22:48:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 28, 41 ]
    }, {
      "text" : "TheGobble",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/gtaDs0VB1E",
      "expanded_url" : "http:\/\/instagram.com\/p\/hL-YYsQiqg\/",
      "display_url" : "instagram.com\/p\/hL-YYsQiqg\/"
    } ]
  },
  "geo" : { },
  "id_str" : "405459753595187202",
  "text" : "Help us choose the National #Thanksgiving Turkey! Meet the birds, then cast your vote. Watch #TheGobble\u2014&gt; http:\/\/t.co\/gtaDs0VB1E",
  "id" : 405459753595187202,
  "created_at" : "2013-11-26 22:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fast4Families",
      "indices" : [ 84, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405451576556273664",
  "text" : "RT @FLOTUS: As families begin to gather for Thanksgiving, I\u2019m thinking of the brave #Fast4Families immigration reform advocates. We're with\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Fast4Families",
        "indices" : [ 72, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405451531148734464",
    "text" : "As families begin to gather for Thanksgiving, I\u2019m thinking of the brave #Fast4Families immigration reform advocates. We're with you. -mo",
    "id" : 405451531148734464,
    "created_at" : "2013-11-26 21:42:32 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 405451576556273664,
  "created_at" : "2013-11-26 21:42:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405444909286453248",
  "text" : "Obama: \"We need to summon the courage to put politics aside once in a while &amp; remember we have more in common than our politics suggest. \"",
  "id" : 405444909286453248,
  "created_at" : "2013-11-26 21:16:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405442923518377984",
  "text" : "President Obama: \"Marlon Brando had it easy \u2013 when it comes to Congress, there\u2019s no such thing as an offer they can\u2019t refuse.\"",
  "id" : 405442923518377984,
  "created_at" : "2013-11-26 21:08:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405442637726896130",
  "text" : "Obama: \"Republican leaders handed out a piece of paper to their members, and on the top it said \u201CAgenda 2014,\u201D below that, it was blank.\"",
  "id" : 405442637726896130,
  "created_at" : "2013-11-26 21:07:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405442337930629120",
  "text" : "President Obama: \"We'd be a lot further along without all the dysfunction and obstruction in Washington.\"",
  "id" : 405442337930629120,
  "created_at" : "2013-11-26 21:06:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405441616858472449",
  "text" : "President Obama: \"Thanks in part to the Affordable Care Act, health care costs are growing at the slowest rate in 50 years.\"",
  "id" : 405441616858472449,
  "created_at" : "2013-11-26 21:03:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405441249483571200",
  "text" : "President Obama: \"Six years ago, only 5% of the world\u2019s smartphones ran on American operating systems. Today, more than 80% do.\"",
  "id" : 405441249483571200,
  "created_at" : "2013-11-26 21:01:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405441120751988736",
  "text" : "President Obama: \"For the first time in nearly 20 years, America now produces more of our own oil than we buy from other countries.\"",
  "id" : 405441120751988736,
  "created_at" : "2013-11-26 21:01:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeinAmerica",
      "indices" : [ 69, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405441045938200578",
  "text" : "President Obama: \"Today, our businesses sell more goods and services #MadeinAmerica to the rest of the world than ever before.\"",
  "id" : 405441045938200578,
  "created_at" : "2013-11-26 21:00:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405440970809819136",
  "text" : "President Obama: \"We\u2019ve made the tough choices required not just to help the economy recover, but to rebuild it on a new foundation.\"",
  "id" : 405440970809819136,
  "created_at" : "2013-11-26 21:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405440740668362752",
  "text" : "President Obama: \"There\u2019s still no better place to make movies and television and music than right here in the United States.\"",
  "id" : 405440740668362752,
  "created_at" : "2013-11-26 20:59:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405440681566404608",
  "text" : "President Obama: \"In a global race for jobs and industries, the thing we do better than anybody else is creativity.\"",
  "id" : 405440681566404608,
  "created_at" : "2013-11-26 20:59:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405439868131504134",
  "text" : "President Obama: \"And, believe it or not, entertainment is, in some ways, part of American diplomacy.\"",
  "id" : 405439868131504134,
  "created_at" : "2013-11-26 20:56:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405439826893082625",
  "text" : "Obama: \"Every time someone buys movie tickets or DVDs or distribution rights to a film, some of that money goes back into the local economy\"",
  "id" : 405439826893082625,
  "created_at" : "2013-11-26 20:56:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405439755225010176",
  "text" : "President Obama: \"Entertainment is one of America\u2019s biggest exports.\"",
  "id" : 405439755225010176,
  "created_at" : "2013-11-26 20:55:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405439593110962176",
  "text" : "President Obama in CA: \"I\u2019ve come here today because this is one of America\u2019s economic engines.\"",
  "id" : 405439593110962176,
  "created_at" : "2013-11-26 20:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/PrVmzyD94G",
      "expanded_url" : "http:\/\/go.wh.gov\/faPDMv",
      "display_url" : "go.wh.gov\/faPDMv"
    } ]
  },
  "geo" : { },
  "id_str" : "405437548366811137",
  "text" : "Happening now: President Obama speaks on growing our economy and strengthening the middle class \u2014&gt; http:\/\/t.co\/PrVmzyD94G",
  "id" : 405437548366811137,
  "created_at" : "2013-11-26 20:46:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/PrVmzyD94G",
      "expanded_url" : "http:\/\/go.wh.gov\/faPDMv",
      "display_url" : "go.wh.gov\/faPDMv"
    } ]
  },
  "geo" : { },
  "id_str" : "405418170808156160",
  "text" : "At 3:15pm ET, President Obama will speak on how we can keep growing our economy and strengthen the middle class \u2014&gt; http:\/\/t.co\/PrVmzyD94G",
  "id" : 405418170808156160,
  "created_at" : "2013-11-26 19:29:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 49, 62 ]
    }, {
      "text" : "TeamPopcorn",
      "indices" : [ 74, 86 ]
    }, {
      "text" : "TeamCaramel",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/BX92dZPkMd",
      "expanded_url" : "http:\/\/go.wh.gov\/XtzrCd",
      "display_url" : "go.wh.gov\/XtzrCd"
    } ]
  },
  "geo" : { },
  "id_str" : "405403134937157632",
  "text" : "Make your gobble heard: Help choose the National #Thanksgiving Turkey.\n1. #TeamPopcorn\n2. #TeamCaramel\nVOTE \u2014&gt; http:\/\/t.co\/BX92dZPkMd",
  "id" : 405403134937157632,
  "created_at" : "2013-11-26 18:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/405392431765409792\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/iiFzaa8fyI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaA-RNJCUAAEN_U.png",
      "id_str" : "405392431769604096",
      "id" : 405392431769604096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaA-RNJCUAAEN_U.png",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 633
      } ],
      "display_url" : "pic.twitter.com\/iiFzaa8fyI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/6GOsuOGzU2",
      "expanded_url" : "http:\/\/go.wh.gov\/GtY4Wn",
      "display_url" : "go.wh.gov\/GtY4Wn"
    } ]
  },
  "geo" : { },
  "id_str" : "405394963598307328",
  "text" : "Birth control should be a woman\u2019s decision, not her boss\u2019s \u2014&gt; http:\/\/t.co\/6GOsuOGzU2, http:\/\/t.co\/iiFzaa8fyI",
  "id" : 405394963598307328,
  "created_at" : "2013-11-26 17:57:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 13, 22 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/405392431765409792\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/iiFzaa8fyI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaA-RNJCUAAEN_U.png",
      "id_str" : "405392431769604096",
      "id" : 405392431769604096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaA-RNJCUAAEN_U.png",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 633
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 365,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 633
      } ],
      "display_url" : "pic.twitter.com\/iiFzaa8fyI"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/6GOsuOGzU2",
      "expanded_url" : "http:\/\/go.wh.gov\/GtY4Wn",
      "display_url" : "go.wh.gov\/GtY4Wn"
    } ]
  },
  "geo" : { },
  "id_str" : "405392431765409792",
  "text" : "Statement by @PressSec Jay Carney on Sebelius v. Hobby Lobby \u2014&gt; http:\/\/t.co\/6GOsuOGzU2, http:\/\/t.co\/iiFzaa8fyI",
  "id" : 405392431765409792,
  "created_at" : "2013-11-26 17:47:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "anne burrell",
      "screen_name" : "chefanneburrell",
      "indices" : [ 35, 51 ],
      "id_str" : "128263500",
      "id" : 128263500
    }, {
      "name" : "Ron Garan",
      "screen_name" : "Astro_Ron",
      "indices" : [ 52, 62 ],
      "id_str" : "82453323",
      "id" : 82453323
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405387295047835648",
  "text" : "RT @whitehouseostp: Tomorrow: Join @chefanneburrell @Astro_Ron for another #WeTheGeeks as we talk turkey and the raw science of cooking! ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "anne burrell",
        "screen_name" : "chefanneburrell",
        "indices" : [ 15, 31 ],
        "id_str" : "128263500",
        "id" : 128263500
      }, {
        "name" : "Ron Garan",
        "screen_name" : "Astro_Ron",
        "indices" : [ 32, 42 ],
        "id_str" : "82453323",
        "id" : 82453323
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 55, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/AeCJUa9KTu",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/11\/26\/we-geeks-talking-turkey-and-science-cooking",
        "display_url" : "whitehouse.gov\/blog\/2013\/11\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "405364617452351488",
    "text" : "Tomorrow: Join @chefanneburrell @Astro_Ron for another #WeTheGeeks as we talk turkey and the raw science of cooking! http:\/\/t.co\/AeCJUa9KTu",
    "id" : 405364617452351488,
    "created_at" : "2013-11-26 15:57:10 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 405387295047835648,
  "created_at" : "2013-11-26 17:27:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "indices" : [ 3, 13 ],
      "id_str" : "1712989040",
      "id" : 1712989040
    }, {
      "name" : "Allison Janney",
      "screen_name" : "AllisonBJanney",
      "indices" : [ 16, 31 ],
      "id_str" : "123015364",
      "id" : 123015364
    }, {
      "name" : "Tommy Vietor",
      "screen_name" : "TVietor08",
      "indices" : [ 122, 132 ],
      "id_str" : "155784594",
      "id" : 155784594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405381139835408384",
  "text" : "RT @Rosholm44: .@AllisonBJanney Thx to you my inbox is flooded re: rumors abt the fate of alternate turkey. BOTH live! CC @TVietor08 http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Allison Janney",
        "screen_name" : "AllisonBJanney",
        "indices" : [ 1, 16 ],
        "id_str" : "123015364",
        "id" : 123015364
      }, {
        "name" : "Tommy Vietor",
        "screen_name" : "TVietor08",
        "indices" : [ 107, 117 ],
        "id_str" : "155784594",
        "id" : 155784594
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ywO7TGy1Lr",
        "expanded_url" : "http:\/\/go.wh.gov\/QodyRi",
        "display_url" : "go.wh.gov\/QodyRi"
      } ]
    },
    "geo" : { },
    "id_str" : "405379845380534272",
    "text" : ".@AllisonBJanney Thx to you my inbox is flooded re: rumors abt the fate of alternate turkey. BOTH live! CC @TVietor08 http:\/\/t.co\/ywO7TGy1Lr",
    "id" : 405379845380534272,
    "created_at" : "2013-11-26 16:57:41 +0000",
    "user" : {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "protected" : false,
      "id_str" : "1712989040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755544708483538944\/h-5gKL6u_normal.jpg",
      "id" : 1712989040,
      "verified" : true
    }
  },
  "id" : 405381139835408384,
  "created_at" : "2013-11-26 17:02:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BEYONC\u00C9",
      "screen_name" : "Beyonce",
      "indices" : [ 80, 88 ],
      "id_str" : "31239408",
      "id" : 31239408
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/405368772829003776\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/4QfQjwxGTl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaAowEXCYAE--8x.jpg",
      "id_str" : "405368772732542977",
      "id" : 405368772732542977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaAowEXCYAE--8x.jpg",
      "sizes" : [ {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4QfQjwxGTl"
    } ],
    "hashtags" : [ {
      "text" : "TeamPopcorn",
      "indices" : [ 16, 28 ]
    }, {
      "text" : "TheGobble",
      "indices" : [ 89, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405368772829003776",
  "text" : "RT if you\u2019re on #TeamPopcorn:\n1. Eats corn\n2. Struts proudly\n3. Sings \u201CHalo\u201D by @Beyonce\n#TheGobble http:\/\/t.co\/4QfQjwxGTl",
  "id" : 405368772829003776,
  "created_at" : "2013-11-26 16:13:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#VoteHillary",
      "screen_name" : "ladygaga",
      "indices" : [ 78, 87 ],
      "id_str" : "14230524",
      "id" : 14230524
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/405363750716571648\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/UszhEf8XRX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BaAkLvUIMAAnH_W.jpg",
      "id_str" : "405363750561394688",
      "id" : 405363750561394688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BaAkLvUIMAAnH_W.jpg",
      "sizes" : [ {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/UszhEf8XRX"
    } ],
    "hashtags" : [ {
      "text" : "TeamCaramel",
      "indices" : [ 16, 28 ]
    }, {
      "text" : "TheGobble",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405363750716571648",
  "text" : "RT if you\u2019re on #TeamCaramel:\n1. Clear voice\n2. Soybean connoisseur\n3. One of @LadyGaga\u2019s little monsters\n#TheGobble http:\/\/t.co\/UszhEf8XRX",
  "id" : 405363750716571648,
  "created_at" : "2013-11-26 15:53:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamPopcorn",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "TeamCaramel",
      "indices" : [ 16, 28 ]
    }, {
      "text" : "TheGobble",
      "indices" : [ 133, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/4XK5ybSWCj",
      "expanded_url" : "http:\/\/go.wh.gov\/QodyRi",
      "display_url" : "go.wh.gov\/QodyRi"
    } ]
  },
  "geo" : { },
  "id_str" : "405354196704051200",
  "text" : "#TeamPopcorn or #TeamCaramel? Learn more &amp; cast your ballot for this year\u2019s National Thanksgiving Turkey: http:\/\/t.co\/4XK5ybSWCj #TheGobble",
  "id" : 405354196704051200,
  "created_at" : "2013-11-26 15:15:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/405139352894058496\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/EUaQwkCCL0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ9YGEKIQAAR7Mi.jpg",
      "id_str" : "405139352705318912",
      "id" : 405139352705318912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ9YGEKIQAAR7Mi.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/EUaQwkCCL0"
    } ],
    "hashtags" : [ {
      "text" : "ActOnReform",
      "indices" : [ 91, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405139352894058496",
  "text" : "Let\u2019s make sure that no matter where you come from, in America you can make it if you try. #ActOnReform, http:\/\/t.co\/EUaQwkCCL0",
  "id" : 405139352894058496,
  "created_at" : "2013-11-26 01:02:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/405124132691382272\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Z97A9Jckzq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ9KQISCcAAB0M8.jpg",
      "id_str" : "405124132448137216",
      "id" : 405124132448137216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ9KQISCcAAB0M8.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Z97A9Jckzq"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405124132691382272",
  "text" : "Let's give every young person in America the chance to earn their way into the American story. #ImmigrationReform, http:\/\/t.co\/Z97A9Jckzq",
  "id" : 405124132691382272,
  "created_at" : "2013-11-26 00:01:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Arizona",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405114426376069120",
  "text" : "RT @Interior: Many public lands are experiencing their 1st snow this fall. Here's a beautiful pic from Chiricahua NM in #Arizona http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/405024997787181056\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/rNNbeDeVJp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ7wFuSCMAAHV41.jpg",
        "id_str" : "405024997623607296",
        "id" : 405024997623607296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ7wFuSCMAAHV41.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/rNNbeDeVJp"
      } ],
      "hashtags" : [ {
        "text" : "Arizona",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405024997787181056",
    "text" : "Many public lands are experiencing their 1st snow this fall. Here's a beautiful pic from Chiricahua NM in #Arizona http:\/\/t.co\/rNNbeDeVJp",
    "id" : 405024997787181056,
    "created_at" : "2013-11-25 17:27:39 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 405114426376069120,
  "created_at" : "2013-11-25 23:23:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/405093434618150912\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/icpSsOvUlN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ8uVQHCIAA8C3p.jpg",
      "id_str" : "405093434123231232",
      "id" : 405093434123231232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ8uVQHCIAA8C3p.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/icpSsOvUlN"
    } ],
    "hashtags" : [ {
      "text" : "WHYouth",
      "indices" : [ 22, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/nzMX9JxN2n",
      "expanded_url" : "http:\/\/go.wh.gov\/4GuV3y",
      "display_url" : "go.wh.gov\/4GuV3y"
    } ]
  },
  "geo" : { },
  "id_str" : "405093434618150912",
  "text" : "You\u2019re invited to the #WHYouth Summit at the White House. Apply for your seat at the table: http:\/\/t.co\/nzMX9JxN2n, http:\/\/t.co\/icpSsOvUlN",
  "id" : 405093434618150912,
  "created_at" : "2013-11-25 21:59:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 3, 15 ],
      "id_str" : "110541296",
      "id" : 110541296
    }, {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 18, 30 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenForBusiness",
      "indices" : [ 92, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/kAtkhhvDxB",
      "expanded_url" : "http:\/\/fw.to\/ijrx05L",
      "display_url" : "fw.to\/ijrx05L"
    } ]
  },
  "geo" : { },
  "id_str" : "405088473155395584",
  "text" : "RT @CommerceGov: .@CommerceSec Op-Ed - The U.S. is open for business http:\/\/t.co\/kAtkhhvDxB #OpenForBusiness",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CommerceSec",
        "screen_name" : "CommerceSec",
        "indices" : [ 1, 13 ],
        "id_str" : "2319148561",
        "id" : 2319148561
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenForBusiness",
        "indices" : [ 75, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/kAtkhhvDxB",
        "expanded_url" : "http:\/\/fw.to\/ijrx05L",
        "display_url" : "fw.to\/ijrx05L"
      } ]
    },
    "geo" : { },
    "id_str" : "404991985670295552",
    "text" : ".@CommerceSec Op-Ed - The U.S. is open for business http:\/\/t.co\/kAtkhhvDxB #OpenForBusiness",
    "id" : 404991985670295552,
    "created_at" : "2013-11-25 15:16:28 +0000",
    "user" : {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "protected" : false,
      "id_str" : "110541296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/645983513712459776\/3Q0H2IVF_normal.jpg",
      "id" : 110541296,
      "verified" : true
    }
  },
  "id" : 405088473155395584,
  "created_at" : "2013-11-25 21:39:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ViolenceAgainstWomen",
      "indices" : [ 21, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405081594652020737",
  "text" : "RT @AmbassadorPower: #ViolenceAgainstWomen isn\u2019t cultural, it\u2019s criminal. Equality can't come eventually; we must fight for it now. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ViolenceAgainstWomen",
        "indices" : [ 0, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/JKGGIDH1TR",
        "expanded_url" : "http:\/\/go.usa.gov\/WGZ5",
        "display_url" : "go.usa.gov\/WGZ5"
      } ]
    },
    "geo" : { },
    "id_str" : "405073498181103617",
    "text" : "#ViolenceAgainstWomen isn\u2019t cultural, it\u2019s criminal. Equality can't come eventually; we must fight for it now. http:\/\/t.co\/JKGGIDH1TR",
    "id" : 405073498181103617,
    "created_at" : "2013-11-25 20:40:22 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 405081594652020737,
  "created_at" : "2013-11-25 21:12:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 21, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405069973975875585",
  "text" : "RT @WHLive: Obama on #ImmigrationReform: \u201CFor those of you who are committed...I\u2019m going to march with you...until we get this done.\u201D #ActO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationReform",
        "indices" : [ 9, 27 ]
      }, {
        "text" : "ActOnReform",
        "indices" : [ 122, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405069867453149184",
    "text" : "Obama on #ImmigrationReform: \u201CFor those of you who are committed...I\u2019m going to march with you...until we get this done.\u201D #ActOnReform",
    "id" : 405069867453149184,
    "created_at" : "2013-11-25 20:25:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 405069973975875585,
  "created_at" : "2013-11-25 20:26:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnReform",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405069506168365056",
  "text" : "President Obama: \"What makes us American is not a question of what we look like or what our names are.\" #ActOnReform",
  "id" : 405069506168365056,
  "created_at" : "2013-11-25 20:24:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnReform",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405068627797229568",
  "text" : "Obama: \"The Statue of Liberty doesn't have its back to the world. It faces the world, and raises its light to the world.\" #ActOnReform",
  "id" : 405068627797229568,
  "created_at" : "2013-11-25 20:21:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405068192906633216",
  "text" : "Obama: \"This reform comes as close as we\u2019ve gotten to something that will benefit everyone, now and for decades to come.\" #ImmigrationReform",
  "id" : 405068192906633216,
  "created_at" : "2013-11-25 20:19:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 100, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405068015592419328",
  "text" : "RT @WHLive: Obama: \"This past week, Speaker Boehner said that he is hopeful we can make progress on #ImmigrationReform. That\u2019s good news.\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationReform",
        "indices" : [ 88, 106 ]
      }, {
        "text" : "ActOnReform",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405067877465604096",
    "text" : "Obama: \"This past week, Speaker Boehner said that he is hopeful we can make progress on #ImmigrationReform. That\u2019s good news.\" #ActOnReform",
    "id" : 405067877465604096,
    "created_at" : "2013-11-25 20:18:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 405068015592419328,
  "created_at" : "2013-11-25 20:18:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 26, 44 ]
    }, {
      "text" : "ActOnReform",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405067416872312832",
  "text" : "Obama: \"We also know that #ImmigrationReform would boost our economy and shrink our deficits.\" #ActOnReform",
  "id" : 405067416872312832,
  "created_at" : "2013-11-25 20:16:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 29, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405066019099508736",
  "text" : "RT @WHLive: Obama on passing #ImmigrationReform: \"The only thing standing in our way...is the unwillingness of certain Republicans in Congr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationReform",
        "indices" : [ 17, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405065964854603776",
    "text" : "Obama on passing #ImmigrationReform: \"The only thing standing in our way...is the unwillingness of certain Republicans in Congress.\"",
    "id" : 405065964854603776,
    "created_at" : "2013-11-25 20:10:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 405066019099508736,
  "created_at" : "2013-11-25 20:10:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405065495071555584",
  "text" : "RT @WHLive: Obama: \"It is long past time to reform an immigration system that right now doesn't serve America as well as it should.\" #ActOn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnReform",
        "indices" : [ 121, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405065355833257984",
    "text" : "Obama: \"It is long past time to reform an immigration system that right now doesn't serve America as well as it should.\" #ActOnReform",
    "id" : 405065355833257984,
    "created_at" : "2013-11-25 20:08:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 405065495071555584,
  "created_at" : "2013-11-25 20:08:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnReform",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405064816579981312",
  "text" : "Obama: \"The story that drew so many of your ancestors here: That America is the place where you can make it if you try.\" #ActOnReform",
  "id" : 405064816579981312,
  "created_at" : "2013-11-25 20:05:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnReform",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405064312693071872",
  "text" : "President Obama: \"It\u2019s long past time to fix our broken immigration system.\" #ActOnReform",
  "id" : 405064312693071872,
  "created_at" : "2013-11-25 20:03:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405063866079379457",
  "text" : "RT @WHLive: Obama: \"We cannot rule out peaceful solutions to the world\u2019s problems. We cannot commit ourselves to an endless cycle of confli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iran",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405063808088948736",
    "text" : "Obama: \"We cannot rule out peaceful solutions to the world\u2019s problems. We cannot commit ourselves to an endless cycle of conflict.\" #Iran",
    "id" : 405063808088948736,
    "created_at" : "2013-11-25 20:01:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 405063866079379457,
  "created_at" : "2013-11-25 20:02:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405063737045831680",
  "text" : "President Obama: \"For the first time in a decade, we have halted the progress of the Iranian nuclear program.\" #Iran",
  "id" : 405063737045831680,
  "created_at" : "2013-11-25 20:01:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405063694507208704",
  "text" : "RT @WHLive: Obama: \"I firmly believe in what President Kennedy once said: 'Let us never negotiate out of fear. But let us never fear to neg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "405063648382423041",
    "text" : "Obama: \"I firmly believe in what President Kennedy once said: 'Let us never negotiate out of fear. But let us never fear to negotiate.'\"",
    "id" : 405063648382423041,
    "created_at" : "2013-11-25 20:01:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 405063694507208704,
  "created_at" : "2013-11-25 20:01:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 62, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405063335286018048",
  "text" : "President Obama: \"The United States reached an agreement with #Iran on a first-step toward resolving our concerns over its nuclear program.\"",
  "id" : 405063335286018048,
  "created_at" : "2013-11-25 19:59:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Batkid",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405063142700351488",
  "text" : "\"Good food, great people, beautiful scenery\u2014and no more super villains, because #Batkid cleaned up the streets.\" \u2014Obama on San Francisco",
  "id" : 405063142700351488,
  "created_at" : "2013-11-25 19:59:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnReform",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/l3YlLcm7Dr",
      "expanded_url" : "http:\/\/go.wh.gov\/ZSErAy",
      "display_url" : "go.wh.gov\/ZSErAy"
    } ]
  },
  "geo" : { },
  "id_str" : "405062824973447168",
  "text" : "Right now: President Obama speaks on fixing our broken immigration system. Watch \u2014&gt; http:\/\/t.co\/l3YlLcm7Dr #ActOnReform",
  "id" : 405062824973447168,
  "created_at" : "2013-11-25 19:57:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/7PGP4RKcv0",
      "expanded_url" : "http:\/\/go.wh.gov\/8ZWKCq",
      "display_url" : "go.wh.gov\/8ZWKCq"
    } ]
  },
  "geo" : { },
  "id_str" : "405053048575115264",
  "text" : "RT @WHLive: Watch President Obama speak at 2:35pm ET on why it\u2019s time to fix our broken immigration system \u2014&gt; http:\/\/t.co\/7PGP4RKcv0 #ActOn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnReform",
        "indices" : [ 124, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/7PGP4RKcv0",
        "expanded_url" : "http:\/\/go.wh.gov\/8ZWKCq",
        "display_url" : "go.wh.gov\/8ZWKCq"
      } ]
    },
    "geo" : { },
    "id_str" : "405053000638427136",
    "text" : "Watch President Obama speak at 2:35pm ET on why it\u2019s time to fix our broken immigration system \u2014&gt; http:\/\/t.co\/7PGP4RKcv0 #ActOnReform",
    "id" : 405053000638427136,
    "created_at" : "2013-11-25 19:18:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 405053048575115264,
  "created_at" : "2013-11-25 19:19:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/QSDy15YKr6",
      "expanded_url" : "http:\/\/nyti.ms\/1duQ6A2",
      "display_url" : "nyti.ms\/1duQ6A2"
    } ]
  },
  "geo" : { },
  "id_str" : "405040744567562240",
  "text" : "63% of Americans support a path to earned citizenship\u2014just one more reason why it's time to pass #ImmigrationReform: http:\/\/t.co\/QSDy15YKr6",
  "id" : 405040744567562240,
  "created_at" : "2013-11-25 18:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 11, 29 ]
    }, {
      "text" : "ActOnReform",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/BTHk06dMZ4",
      "expanded_url" : "http:\/\/go.wh.gov\/E8HEr7",
      "display_url" : "go.wh.gov\/E8HEr7"
    } ]
  },
  "geo" : { },
  "id_str" : "405033556516151296",
  "text" : "Bipartisan #ImmigrationReform would:\n1. Grow our economy\n2. Create jobs\n3. Cut the deficit\nWATCH \u2014&gt; http:\/\/t.co\/BTHk06dMZ4\n#ActOnReform",
  "id" : 405033556516151296,
  "created_at" : "2013-11-25 18:01:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/405026392275836928\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/P4gWidalt0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ7xW5GCQAAKU9N.jpg",
      "id_str" : "405026392095473664",
      "id" : 405026392095473664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ7xW5GCQAAKU9N.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/P4gWidalt0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/EUqP3Lv85u",
      "expanded_url" : "http:\/\/wh.gov\/FilmFestival",
      "display_url" : "wh.gov\/FilmFestival"
    } ]
  },
  "geo" : { },
  "id_str" : "405026392275836928",
  "text" : "Calling all student filmmakers: Submit your film for the 1st-ever White House Film Festival. http:\/\/t.co\/EUqP3Lv85u, http:\/\/t.co\/P4gWidalt0",
  "id" : 405026392275836928,
  "created_at" : "2013-11-25 17:33:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 29, 47 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405016667630993408",
  "text" : "The Senate passed bipartisan #ImmigrationReform.\n\nThe House could too if they would #JustVote.\n\nRT if you agree it's time to make it happen.",
  "id" : 405016667630993408,
  "created_at" : "2013-11-25 16:54:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/404992751483097089\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/QiXwvIEDLE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ7SwwFCEAAbrq5.png",
      "id_str" : "404992751491485696",
      "id" : 404992751491485696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ7SwwFCEAAbrq5.png",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QiXwvIEDLE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404992751483097089",
  "text" : "Air Force One \u2708 \u2708 \u2708 wheels down near Mt. Rainer. http:\/\/t.co\/QiXwvIEDLE",
  "id" : 404992751483097089,
  "created_at" : "2013-11-25 15:19:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7nc7pUxSmP",
      "expanded_url" : "http:\/\/go.wh.gov\/Wf8n2F",
      "display_url" : "go.wh.gov\/Wf8n2F"
    } ]
  },
  "geo" : { },
  "id_str" : "404746012343803904",
  "text" : "President Obama: \"For the first time in nearly a decade, we have halted the progress of the Iranian nuclear program.\" http:\/\/t.co\/7nc7pUxSmP",
  "id" : 404746012343803904,
  "created_at" : "2013-11-24 22:59:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/zcVDfOUu4P",
      "expanded_url" : "http:\/\/go.wh.gov\/CF9BBG",
      "display_url" : "go.wh.gov\/CF9BBG"
    } ]
  },
  "geo" : { },
  "id_str" : "404659942470057984",
  "text" : "Last night, President Obama spoke on the first step agreement on #Iran's nuclear program. Watch \u2014&gt; http:\/\/t.co\/zcVDfOUu4P",
  "id" : 404659942470057984,
  "created_at" : "2013-11-24 17:17:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/lCVmKzJA0u",
      "expanded_url" : "http:\/\/go.wh.gov\/CoBzsy",
      "display_url" : "go.wh.gov\/CoBzsy"
    } ]
  },
  "geo" : { },
  "id_str" : "404473337176281088",
  "text" : "Watch President Obama\u2019s statement on the first-step agreement to address concerns with #Iran\u2019s nuclear program \u2014&gt; http:\/\/t.co\/lCVmKzJA0u",
  "id" : 404473337176281088,
  "created_at" : "2013-11-24 04:55:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/404462890515562496\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/BzIlXtNYqW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZzw2xqCQAA4cxM.jpg",
      "id_str" : "404462890389749760",
      "id" : 404462890389749760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZzw2xqCQAA4cxM.jpg",
      "sizes" : [ {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1011,
        "resize" : "fit",
        "w" : 1467
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BzIlXtNYqW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404462890515562496",
  "text" : "\u201CWe have halted the progress of the Iranian nuclear program &amp; key parts of the program will be rolled back.\u201D \u2014Obama: http:\/\/t.co\/BzIlXtNYqW",
  "id" : 404462890515562496,
  "created_at" : "2013-11-24 04:14:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404454893353590786",
  "text" : "President Obama: \"I have a profound responsibility to try to resolve our differences peacefully, rather than rush towards conflict.\" #Iran",
  "id" : 404454893353590786,
  "created_at" : "2013-11-24 03:42:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404454653326143488",
  "text" : "President Obama: \"As President and Commander in Chief, I will do what is necessary to prevent #Iran from obtaining a nuclear weapon.\"",
  "id" : 404454653326143488,
  "created_at" : "2013-11-24 03:41:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404454458597191680",
  "text" : "President Obama: \"Now is not the time to move forward on new sanctions, because doing so would derail this promising first step.\" #Iran",
  "id" : 404454458597191680,
  "created_at" : "2013-11-24 03:40:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404454088969973760",
  "text" : "Obama: \"The U.S. &amp; our friends and allies have agreed to provide #Iran modest relief, while continuing to apply our toughest sanctions.\"",
  "id" : 404454088969973760,
  "created_at" : "2013-11-24 03:39:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404453882081722368",
  "text" : "RT @WHLive: President Obama: \"#Iran has committed to halting certain levels of enrichment, and neutralizing part of its stockpile.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iran",
        "indices" : [ 18, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "404453714120810496",
    "text" : "President Obama: \"#Iran has committed to halting certain levels of enrichment, and neutralizing part of its stockpile.\"",
    "id" : 404453714120810496,
    "created_at" : "2013-11-24 03:37:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 404453882081722368,
  "created_at" : "2013-11-24 03:38:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404453573406126080",
  "text" : "President Obama: \"For the first time in nearly a decade, we have halted the progress of the Iranian nuclear program.\" #Iran",
  "id" : 404453573406126080,
  "created_at" : "2013-11-24 03:37:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404453517277945858",
  "text" : "President Obama on #Iran: \"Today, that diplomacy opened up a new path toward a world that is more secure.\"",
  "id" : 404453517277945858,
  "created_at" : "2013-11-24 03:36:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404453390718992385",
  "text" : "Obama: \"As I have said many times, my strong preference is to resolve this issue peacefully\u2014we have extended the hand of diplomacy.\" #Iran",
  "id" : 404453390718992385,
  "created_at" : "2013-11-24 03:36:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "404453312398778368",
  "text" : "Obama: \"Since I took office, I have made clear my determination to prevent #Iran from obtaining a nuclear weapon.\" http:\/\/t.co\/KvadYk9atb",
  "id" : 404453312398778368,
  "created_at" : "2013-11-24 03:35:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404453179032481792",
  "text" : "Obama: \"The U.S....with our close allies &amp; partners\u2014took an important first step toward a comprehensive solution...#Iran\u2019s nuclear program.\"",
  "id" : 404453179032481792,
  "created_at" : "2013-11-24 03:35:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranTalks",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404448825076482048",
  "text" : "RT @StateDept: Agreement in Geneva: first step makes world safer. More work now. -JK #IranTalks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranTalks",
        "indices" : [ 70, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "404448081824862208",
    "text" : "Agreement in Geneva: first step makes world safer. More work now. -JK #IranTalks",
    "id" : 404448081824862208,
    "created_at" : "2013-11-24 03:15:11 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 404448825076482048,
  "created_at" : "2013-11-24 03:18:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/4OPJf3032u",
      "expanded_url" : "http:\/\/bit.ly\/17YEHk7",
      "display_url" : "bit.ly\/17YEHk7"
    } ]
  },
  "geo" : { },
  "id_str" : "404448479176441856",
  "text" : "RT @petesouza: Pres Obama meeting earlier today with natl sec advisors to discuss negotiations with Iran: http:\/\/t.co\/4OPJf3032u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/4OPJf3032u",
        "expanded_url" : "http:\/\/bit.ly\/17YEHk7",
        "display_url" : "bit.ly\/17YEHk7"
      } ]
    },
    "geo" : { },
    "id_str" : "404438613586219008",
    "text" : "Pres Obama meeting earlier today with natl sec advisors to discuss negotiations with Iran: http:\/\/t.co\/4OPJf3032u",
    "id" : 404438613586219008,
    "created_at" : "2013-11-24 02:37:34 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 404448479176441856,
  "created_at" : "2013-11-24 03:16:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404444836251832320",
  "text" : "RT @rhodes44: POTUS will make statement on P5+1-Iran agreement tonight from the White House",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "404436443382034432",
    "text" : "POTUS will make statement on P5+1-Iran agreement tonight from the White House",
    "id" : 404436443382034432,
    "created_at" : "2013-11-24 02:28:56 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 404444836251832320,
  "created_at" : "2013-11-24 03:02:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/404353067652354048\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/THitWJltbz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZyM-QGCEAAOksZ.jpg",
      "id_str" : "404353067656548352",
      "id" : 404353067656548352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZyM-QGCEAAOksZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/THitWJltbz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/5iul7PPoqb",
      "expanded_url" : "http:\/\/go.wh.gov\/sZm512",
      "display_url" : "go.wh.gov\/sZm512"
    } ]
  },
  "geo" : { },
  "id_str" : "404353067652354048",
  "text" : "\u201COur businesses have created 7.8 million new jobs in the past 44 months.\u201D \u2014President Obama: http:\/\/t.co\/5iul7PPoqb, http:\/\/t.co\/THitWJltbz",
  "id" : 404353067652354048,
  "created_at" : "2013-11-23 20:57:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/5iul7PPoqb",
      "expanded_url" : "http:\/\/go.wh.gov\/sZm512",
      "display_url" : "go.wh.gov\/sZm512"
    } ]
  },
  "geo" : { },
  "id_str" : "404254009256456193",
  "text" : "\u201CAs long as I\u2019m President, I\u2019ll keep doing everything I can to create jobs and grow the economy.\u201D \u2014President Obama: http:\/\/t.co\/5iul7PPoqb",
  "id" : 404254009256456193,
  "created_at" : "2013-11-23 14:24:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/404046916939288576\/photo\/1",
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/5DWulw6auI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZt2h7XCUAARmI1.jpg",
      "id_str" : "404046916821864448",
      "id" : 404046916821864448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZt2h7XCUAARmI1.jpg",
      "sizes" : [ {
        "h" : 425,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 963,
        "resize" : "fit",
        "w" : 770
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 963,
        "resize" : "fit",
        "w" : 770
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5DWulw6auI"
    } ],
    "hashtags" : [ {
      "text" : "SmithsonianPanda",
      "indices" : [ 48, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/GKiBcj1VUl",
      "expanded_url" : "http:\/\/s.si.edu\/1az9rb7",
      "display_url" : "s.si.edu\/1az9rb7"
    } ]
  },
  "geo" : { },
  "id_str" : "404046916939288576",
  "text" : "DEADLINE MIDNIGHT:\nLast chance to name the baby #SmithsonianPanda.\nTime to step up.\nVOTE \u2014&gt; http:\/\/t.co\/GKiBcj1VUl, http:\/\/t.co\/5DWulw6auI",
  "id" : 404046916939288576,
  "created_at" : "2013-11-23 00:41:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/tFuCe1Bpr0",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    }, {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Hl3EfPiBlN",
      "expanded_url" : "http:\/\/reut.rs\/18dZshu",
      "display_url" : "reut.rs\/18dZshu"
    } ]
  },
  "geo" : { },
  "id_str" : "404031199263219712",
  "text" : "RT @Simas44: Steady http:\/\/t.co\/tFuCe1Bpr0 progress. Capacity to double. http:\/\/t.co\/Hl3EfPiBlN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/tFuCe1Bpr0",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      }, {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/Hl3EfPiBlN",
        "expanded_url" : "http:\/\/reut.rs\/18dZshu",
        "display_url" : "reut.rs\/18dZshu"
      } ]
    },
    "geo" : { },
    "id_str" : "404028253104402432",
    "text" : "Steady http:\/\/t.co\/tFuCe1Bpr0 progress. Capacity to double. http:\/\/t.co\/Hl3EfPiBlN",
    "id" : 404028253104402432,
    "created_at" : "2013-11-22 23:26:56 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 404031199263219712,
  "created_at" : "2013-11-22 23:38:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JFK",
      "indices" : [ 53, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/iBJlXwty2k",
      "expanded_url" : "http:\/\/instagram.com\/p\/hCK7KBQipC\/",
      "display_url" : "instagram.com\/p\/hCK7KBQipC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "404016554313916416",
  "text" : "Thank you, President Kennedy. http:\/\/t.co\/iBJlXwty2k #JFK",
  "id" : 404016554313916416,
  "created_at" : "2013-11-22 22:40:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 46, 49 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 129, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/lhxIl6a5t8",
      "expanded_url" : "http:\/\/go.wh.gov\/LWWJhP",
      "display_url" : "go.wh.gov\/LWWJhP"
    } ]
  },
  "geo" : { },
  "id_str" : "404012650020864000",
  "text" : "Go behind-the-scenes with President Obama and @VP Biden for a recap of this week at the White House \u2014&gt; http:\/\/t.co\/lhxIl6a5t8 #WestWingWeek",
  "id" : 404012650020864000,
  "created_at" : "2013-11-22 22:24:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 3, 18 ],
      "id_str" : "14511951",
      "id" : 14511951
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 41, 52 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HuffingtonPost\/status\/403991325285957634\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/gr1sXUmAaS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZtD-ExCQAAKDtC.jpg",
      "id_str" : "403991325290151936",
      "id" : 403991325290151936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZtD-ExCQAAKDtC.jpg",
      "sizes" : [ {
        "h" : 658,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gr1sXUmAaS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403994459677147136",
  "text" : "RT @HuffingtonPost: And now for a bit of @WhiteHouse trivia! Click the image to reveal the answer. http:\/\/t.co\/gr1sXUmAaS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 21, 32 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HuffingtonPost\/status\/403991325285957634\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/gr1sXUmAaS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZtD-ExCQAAKDtC.jpg",
        "id_str" : "403991325290151936",
        "id" : 403991325290151936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZtD-ExCQAAKDtC.jpg",
        "sizes" : [ {
          "h" : 658,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 658,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 658,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/gr1sXUmAaS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403991325285957634",
    "text" : "And now for a bit of @WhiteHouse trivia! Click the image to reveal the answer. http:\/\/t.co\/gr1sXUmAaS",
    "id" : 403991325285957634,
    "created_at" : "2013-11-22 21:00:12 +0000",
    "user" : {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "protected" : false,
      "id_str" : "14511951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720642862551928832\/I58EQMCH_normal.jpg",
      "id" : 14511951,
      "verified" : true
    }
  },
  "id" : 403994459677147136,
  "created_at" : "2013-11-22 21:12:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/403985190772412416\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/RarBckRHfg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZs-Y_cCMAAckvL.jpg",
      "id_str" : "403985190646591488",
      "id" : 403985190646591488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZs-Y_cCMAAckvL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RarBckRHfg"
    } ],
    "hashtags" : [ {
      "text" : "filibuster",
      "indices" : [ 23, 34 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/Lnmtr78bzI",
      "expanded_url" : "http:\/\/go.wh.gov\/KtnZHX",
      "display_url" : "go.wh.gov\/KtnZHX"
    } ]
  },
  "geo" : { },
  "id_str" : "403985190772412416",
  "text" : "Here\u2019s why yesterday\u2019s #filibuster rules change is so important \u2014&gt; http:\/\/t.co\/Lnmtr78bzI #JustVote, http:\/\/t.co\/RarBckRHfg",
  "id" : 403985190772412416,
  "created_at" : "2013-11-22 20:35:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "Erin44",
      "indices" : [ 3, 10 ],
      "id_str" : "41044637",
      "id" : 41044637
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 78, 86 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 90, 100 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "TechWomen",
      "screen_name" : "TechWomen",
      "indices" : [ 114, 124 ],
      "id_str" : "197987694",
      "id" : 197987694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403982934514098176",
  "text" : "RT @Erin44: \"Making the world we share a better place, one woman at a time.\" \u2014@DrBiden on @StateDept's incredible @TechWomen: http:\/\/t.co\/v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 66, 74 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      }, {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 78, 88 ],
        "id_str" : "9624742",
        "id" : 9624742
      }, {
        "name" : "TechWomen",
        "screen_name" : "TechWomen",
        "indices" : [ 102, 112 ],
        "id_str" : "197987694",
        "id" : 197987694
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/vhyipBY9wG",
        "expanded_url" : "http:\/\/huff.to\/1bXYSTQ",
        "display_url" : "huff.to\/1bXYSTQ"
      } ]
    },
    "geo" : { },
    "id_str" : "403964763870220288",
    "text" : "\"Making the world we share a better place, one woman at a time.\" \u2014@DrBiden on @StateDept's incredible @TechWomen: http:\/\/t.co\/vhyipBY9wG",
    "id" : 403964763870220288,
    "created_at" : "2013-11-22 19:14:39 +0000",
    "user" : {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "protected" : false,
      "id_str" : "2169098419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632215085256081409\/_vjZ92WM_normal.jpg",
      "id" : 2169098419,
      "verified" : true
    }
  },
  "id" : 403982934514098176,
  "created_at" : "2013-11-22 20:26:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/403969657377280000\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/1irDH153L1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZswQ1DCAAAvJIa.jpg",
      "id_str" : "403969657255624704",
      "id" : 403969657255624704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZswQ1DCAAAvJIa.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1irDH153L1"
    } ],
    "hashtags" : [ {
      "text" : "JFK",
      "indices" : [ 90, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/04oGQiABZJ",
      "expanded_url" : "http:\/\/go.wh.gov\/j4dUY6",
      "display_url" : "go.wh.gov\/j4dUY6"
    } ]
  },
  "geo" : { },
  "id_str" : "403969657377280000",
  "text" : "President Obama on President Kennedy and the American spirit \u2014&gt; http:\/\/t.co\/04oGQiABZJ #JFK, http:\/\/t.co\/1irDH153L1",
  "id" : 403969657377280000,
  "created_at" : "2013-11-22 19:34:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/403962049635446784\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/AaF2WnvXz3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZspWAeCcAA-bR3.jpg",
      "id_str" : "403962049639641088",
      "id" : 403962049639641088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZspWAeCcAA-bR3.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AaF2WnvXz3"
    } ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/ltThsIyw8T",
      "expanded_url" : "http:\/\/go.wh.gov\/J3zny3",
      "display_url" : "go.wh.gov\/J3zny3"
    } ]
  },
  "geo" : { },
  "id_str" : "403962049635446784",
  "text" : "Starting now: Tune in for our #WeTheGeeks hangout on student startups \u2014&gt; http:\/\/t.co\/ltThsIyw8T, http:\/\/t.co\/AaF2WnvXz3",
  "id" : 403962049635446784,
  "created_at" : "2013-11-22 19:03:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JFK",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/VmSiuXyCXG",
      "expanded_url" : "http:\/\/go.wh.gov\/JZqdh6",
      "display_url" : "go.wh.gov\/JZqdh6"
    } ]
  },
  "geo" : { },
  "id_str" : "403956071959506945",
  "text" : "\"50 years later, John F. Kennedy stands for posterity as he did in life\u2014young, and bold, and daring.\" \u2014Obama on #JFK: http:\/\/t.co\/VmSiuXyCXG",
  "id" : 403956071959506945,
  "created_at" : "2013-11-22 18:40:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/403946564550664192\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/bNlH2jVTXP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZsbQpYIAAANohU.jpg",
      "id_str" : "403946564378689536",
      "id" : 403946564378689536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZsbQpYIAAANohU.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/bNlH2jVTXP"
    } ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 15, 26 ]
    }, {
      "text" : "NationalEntrepreneursDay",
      "indices" : [ 89, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/7ZUx4MGalL",
      "expanded_url" : "http:\/\/go.wh.gov\/SnpZow",
      "display_url" : "go.wh.gov\/SnpZow"
    } ]
  },
  "geo" : { },
  "id_str" : "403946564550664192",
  "text" : "Don't miss our #WeTheGeeks hangout on student startups at 2pm ET: http:\/\/t.co\/7ZUx4MGalL #NationalEntrepreneursDay, http:\/\/t.co\/bNlH2jVTXP",
  "id" : 403946564550664192,
  "created_at" : "2013-11-22 18:02:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 7, 15 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    }, {
      "name" : "John Temp",
      "screen_name" : "ShaunHUD",
      "indices" : [ 21, 30 ],
      "id_str" : "2687896501",
      "id" : 2687896501
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowFriday",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403938454288859136",
  "text" : "Follow @Cabinet Sec. @ShaunHUD for the latest on the housing recovery, reducing homelessness, community development and more. #FollowFriday",
  "id" : 403938454288859136,
  "created_at" : "2013-11-22 17:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Dm5WL0z06f",
      "expanded_url" : "http:\/\/nyti.ms\/19MBgg6",
      "display_url" : "nyti.ms\/19MBgg6"
    } ]
  },
  "geo" : { },
  "id_str" : "403932288418709504",
  "text" : "\u201CIt\u2019s going to save lives.\u201D \u2014GOP Gov. Kasich on expanding Medicaid in OH through the Affordable Care Act: http:\/\/t.co\/Dm5WL0z06f #Obamacare",
  "id" : 403932288418709504,
  "created_at" : "2013-11-22 17:05:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403924786541125632",
  "text" : "RT @DeptVetAffairs: FRAUD ALERT: Vets - be aware of a marketing scam targeting callers trying to reach VA. Learn more here http:\/\/t.co\/z69b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "consumerfinance.gov",
        "screen_name" : "CFPB",
        "indices" : [ 126, 131 ],
        "id_str" : "234826866",
        "id" : 234826866
      }, {
        "name" : "FTC",
        "screen_name" : "FTC",
        "indices" : [ 132, 136 ],
        "id_str" : "187993109",
        "id" : 187993109
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/z69bVukHQg",
        "expanded_url" : "http:\/\/on.fb.me\/1ekNcuI",
        "display_url" : "on.fb.me\/1ekNcuI"
      } ]
    },
    "geo" : { },
    "id_str" : "403646713262387200",
    "text" : "FRAUD ALERT: Vets - be aware of a marketing scam targeting callers trying to reach VA. Learn more here http:\/\/t.co\/z69bVukHQg @CFPB @FTC",
    "id" : 403646713262387200,
    "created_at" : "2013-11-21 22:10:50 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 403924786541125632,
  "created_at" : "2013-11-22 16:35:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/BccBERz25V",
      "expanded_url" : "http:\/\/cnn.it\/1e4SI3Q",
      "display_url" : "cnn.it\/1e4SI3Q"
    } ]
  },
  "geo" : { },
  "id_str" : "403916137269706752",
  "text" : "\u201CQuality coverage for me and my family. I will save $628 every month on premiums.\u201D \u2014Lori B. from CA: http:\/\/t.co\/BccBERz25V #GetCovered",
  "id" : 403916137269706752,
  "created_at" : "2013-11-22 16:01:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "indices" : [ 3, 14 ],
      "id_str" : "9109712",
      "id" : 9109712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/jr4DkOzMZI",
      "expanded_url" : "http:\/\/1.usa.gov\/1iAZu4N",
      "display_url" : "1.usa.gov\/1iAZu4N"
    } ]
  },
  "geo" : { },
  "id_str" : "403909828793606144",
  "text" : "RT @PeaceCorps: On the 50th anniversary of his passing, we honor the legacy of our founder President John F. Kennedy http:\/\/t.co\/jr4DkOzMZI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "publicservice",
        "indices" : [ 124, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/jr4DkOzMZI",
        "expanded_url" : "http:\/\/1.usa.gov\/1iAZu4N",
        "display_url" : "1.usa.gov\/1iAZu4N"
      } ]
    },
    "geo" : { },
    "id_str" : "403903733261934592",
    "text" : "On the 50th anniversary of his passing, we honor the legacy of our founder President John F. Kennedy http:\/\/t.co\/jr4DkOzMZI #publicservice",
    "id" : 403903733261934592,
    "created_at" : "2013-11-22 15:12:08 +0000",
    "user" : {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "protected" : false,
      "id_str" : "9109712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737985331815841793\/YS-240sx_normal.jpg",
      "id" : 9109712,
      "verified" : true
    }
  },
  "id" : 403909828793606144,
  "created_at" : "2013-11-22 15:36:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glenn Thrush",
      "screen_name" : "GlennThrush",
      "indices" : [ 3, 15 ],
      "id_str" : "19107878",
      "id" : 19107878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403904167678181378",
  "text" : "RT @GlennThrush: Most under-covered big story on ACA: It's the historic slowing of health care costs\/spending over last three years.http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Kjksrveoar",
        "expanded_url" : "http:\/\/finance.yahoo.com\/news\/drop-health-care-costs-elicits-181700926.html",
        "display_url" : "finance.yahoo.com\/news\/drop-heal\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "403883481203093504",
    "text" : "Most under-covered big story on ACA: It's the historic slowing of health care costs\/spending over last three years.http:\/\/t.co\/Kjksrveoar",
    "id" : 403883481203093504,
    "created_at" : "2013-11-22 13:51:40 +0000",
    "user" : {
      "name" : "Glenn Thrush",
      "screen_name" : "GlennThrush",
      "protected" : false,
      "id_str" : "19107878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784384532833185797\/VvdZpOz0_normal.jpg",
      "id" : 19107878,
      "verified" : true
    }
  },
  "id" : 403904167678181378,
  "created_at" : "2013-11-22 15:13:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/403697157989236736\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/69aLdZ8kpL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZo4bRiIMAACPBD.jpg",
      "id_str" : "403697157817249792",
      "id" : 403697157817249792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZo4bRiIMAACPBD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/69aLdZ8kpL"
    } ],
    "hashtags" : [ {
      "text" : "filibuster",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Sl4lKRMxpe",
      "expanded_url" : "http:\/\/go.wh.gov\/3rAP8v",
      "display_url" : "go.wh.gov\/3rAP8v"
    } ]
  },
  "geo" : { },
  "id_str" : "403697157989236736",
  "text" : "Everything you need to know about why today\u2019s #filibuster rule change is a really big deal: http:\/\/t.co\/Sl4lKRMxpe, http:\/\/t.co\/69aLdZ8kpL",
  "id" : 403697157989236736,
  "created_at" : "2013-11-22 01:31:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/Es170Yy9Wx",
      "expanded_url" : "http:\/\/go.wh.gov\/5mwETL",
      "display_url" : "go.wh.gov\/5mwETL"
    } ]
  },
  "geo" : { },
  "id_str" : "403685612860895232",
  "text" : "Find out how we're partnering with philanthropic and private investors to boost the return on taxpayer investments \u2014&gt; http:\/\/t.co\/Es170Yy9Wx",
  "id" : 403685612860895232,
  "created_at" : "2013-11-22 00:45:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 130, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/sFWyk1Qhrn",
      "expanded_url" : "http:\/\/reut.rs\/18bFqUQ",
      "display_url" : "reut.rs\/18bFqUQ"
    } ]
  },
  "geo" : { },
  "id_str" : "403674594671730688",
  "text" : "FACT: Nearly 80,000 Californians have already signed up for coverage through the Affordable Care Act \u2014&gt; http:\/\/t.co\/sFWyk1Qhrn #GetCovered",
  "id" : 403674594671730688,
  "created_at" : "2013-11-22 00:01:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/403659638513496064\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/pCUTYIVKlW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZoWTU9CcAAbH_l.jpg",
      "id_str" : "403659637901127680",
      "id" : 403659637901127680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZoWTU9CcAAbH_l.jpg",
      "sizes" : [ {
        "h" : 2274,
        "resize" : "fit",
        "w" : 1504
      }, {
        "h" : 907,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1548,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 514,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pCUTYIVKlW"
    } ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 86, 90 ]
    }, {
      "text" : "ThrowbackThursday",
      "indices" : [ 91, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403665715380498433",
  "text" : "RT @FLOTUS: Getting a good education is the best investment you can make in yourself. #TBT #ThrowbackThursday, http:\/\/t.co\/pCUTYIVKlW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/403659638513496064\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/pCUTYIVKlW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZoWTU9CcAAbH_l.jpg",
        "id_str" : "403659637901127680",
        "id" : 403659637901127680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZoWTU9CcAAbH_l.jpg",
        "sizes" : [ {
          "h" : 2274,
          "resize" : "fit",
          "w" : 1504
        }, {
          "h" : 907,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1548,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 514,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/pCUTYIVKlW"
      } ],
      "hashtags" : [ {
        "text" : "TBT",
        "indices" : [ 74, 78 ]
      }, {
        "text" : "ThrowbackThursday",
        "indices" : [ 79, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403659638513496064",
    "text" : "Getting a good education is the best investment you can make in yourself. #TBT #ThrowbackThursday, http:\/\/t.co\/pCUTYIVKlW",
    "id" : 403659638513496064,
    "created_at" : "2013-11-21 23:02:12 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 403665715380498433,
  "created_at" : "2013-11-21 23:26:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 3, 11 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Cabinet\/status\/403593640519274497\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/S3rBP5H4UF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZnaRxkCEAAnpWm.jpg",
      "id_str" : "403593640523468800",
      "id" : 403593640523468800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZnaRxkCEAAnpWm.jpg",
      "sizes" : [ {
        "h" : 324,
        "resize" : "fit",
        "w" : 473
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 473
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 473
      } ],
      "display_url" : "pic.twitter.com\/S3rBP5H4UF"
    } ],
    "hashtags" : [ {
      "text" : "tbt",
      "indices" : [ 64, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403655672484483072",
  "text" : "RT @Cabinet: Remembering a great and inspiring President today. #tbt http:\/\/t.co\/S3rBP5H4UF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cabinet\/status\/403593640519274497\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/S3rBP5H4UF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZnaRxkCEAAnpWm.jpg",
        "id_str" : "403593640523468800",
        "id" : 403593640523468800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZnaRxkCEAAnpWm.jpg",
        "sizes" : [ {
          "h" : 324,
          "resize" : "fit",
          "w" : 473
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 473
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 233,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 473
        } ],
        "display_url" : "pic.twitter.com\/S3rBP5H4UF"
      } ],
      "hashtags" : [ {
        "text" : "tbt",
        "indices" : [ 51, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403593640519274497",
    "text" : "Remembering a great and inspiring President today. #tbt http:\/\/t.co\/S3rBP5H4UF",
    "id" : 403593640519274497,
    "created_at" : "2013-11-21 18:39:57 +0000",
    "user" : {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "protected" : false,
      "id_str" : "1854981890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000444833438\/6f96900dcf05562d4e699ae28d7861c6_normal.jpeg",
      "id" : 1854981890,
      "verified" : true
    }
  },
  "id" : 403655672484483072,
  "created_at" : "2013-11-21 22:46:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/fcwpf9X6Mb",
      "expanded_url" : "http:\/\/go.wh.gov\/YeoFhc",
      "display_url" : "go.wh.gov\/YeoFhc"
    } ]
  },
  "geo" : { },
  "id_str" : "403634628323332096",
  "text" : "Insurers must now give consumers info on:\n1. Coverage options\n2. #Obamacare protections\n3. Keeping existing plans\nhttp:\/\/t.co\/fcwpf9X6Mb",
  "id" : 403634628323332096,
  "created_at" : "2013-11-21 21:22:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    }, {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "indices" : [ 27, 34 ],
      "id_str" : "19948202",
      "id" : 19948202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Veterans",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "PIT2013",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/qPJzVNF16u",
      "expanded_url" : "http:\/\/1.usa.gov\/1cHXi6M",
      "display_url" : "1.usa.gov\/1cHXi6M"
    } ]
  },
  "geo" : { },
  "id_str" : "403630742787223552",
  "text" : "RT @DeptVetAffairs: VA and @HUDgov announce 24% reduction in #Veterans' homelessness since 2010 #PIT2013 http:\/\/t.co\/qPJzVNF16u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HUDgov",
        "screen_name" : "HUDgov",
        "indices" : [ 7, 14 ],
        "id_str" : "19948202",
        "id" : 19948202
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Veterans",
        "indices" : [ 41, 50 ]
      }, {
        "text" : "PIT2013",
        "indices" : [ 76, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/qPJzVNF16u",
        "expanded_url" : "http:\/\/1.usa.gov\/1cHXi6M",
        "display_url" : "1.usa.gov\/1cHXi6M"
      } ]
    },
    "geo" : { },
    "id_str" : "403585310958706688",
    "text" : "VA and @HUDgov announce 24% reduction in #Veterans' homelessness since 2010 #PIT2013 http:\/\/t.co\/qPJzVNF16u",
    "id" : 403585310958706688,
    "created_at" : "2013-11-21 18:06:51 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 403630742787223552,
  "created_at" : "2013-11-21 21:07:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Covered California",
      "screen_name" : "CoveredCA",
      "indices" : [ 3, 13 ],
      "id_str" : "915514734",
      "id" : 915514734
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CoveredCA",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403622576502898688",
  "text" : "RT @CoveredCA: As of Nov. 19, 360,464 individual have completed #CoveredCA applications.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CoveredCA",
        "indices" : [ 49, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403615135106756608",
    "text" : "As of Nov. 19, 360,464 individual have completed #CoveredCA applications.",
    "id" : 403615135106756608,
    "created_at" : "2013-11-21 20:05:21 +0000",
    "user" : {
      "name" : "Covered California",
      "screen_name" : "CoveredCA",
      "protected" : false,
      "id_str" : "915514734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666321328752848896\/Mu0ckxNj_normal.jpg",
      "id" : 915514734,
      "verified" : true
    }
  },
  "id" : 403622576502898688,
  "created_at" : "2013-11-21 20:34:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/jniNNFPP25",
      "expanded_url" : "http:\/\/go.wh.gov\/tTcEqF",
      "display_url" : "go.wh.gov\/tTcEqF"
    } ]
  },
  "geo" : { },
  "id_str" : "403606492709797888",
  "text" : "President Obama on #ConnectED: \"We've got to bring our schools and our libraries into the 21st century.\" Watch \u2014&gt; http:\/\/t.co\/jniNNFPP25",
  "id" : 403606492709797888,
  "created_at" : "2013-11-21 19:31:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Filibuster",
      "indices" : [ 111, 122 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403601000113532928",
  "text" : "President Obama: \u201CIf you\u2019ve got a majority of folks who believe in something, then it should be able to pass.\u201D #Filibuster #JustVote",
  "id" : 403601000113532928,
  "created_at" : "2013-11-21 19:09:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Filibuster",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403600203644555264",
  "text" : "Obama: \"Enough is enough. The American people\u2019s business is far too important to keep falling prey\u2026to Washington politics.\" #Filibuster",
  "id" : 403600203644555264,
  "created_at" : "2013-11-21 19:06:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403600072245407744",
  "text" : "Obama on GOP filibusters: \"It\u2019s not because they oppose the person\u2026it\u2019s...because they oppose the policies the American people voted for.\"",
  "id" : 403600072245407744,
  "created_at" : "2013-11-21 19:05:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403599417464209409",
  "text" : "Obama: \"I support the step a majority of Senators took today to change the ways of Washington by changing the way Congress does business.\"",
  "id" : 403599417464209409,
  "created_at" : "2013-11-21 19:02:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403599379862282240",
  "text" : "RT @WHLive: Obama: \"A deliberate...effort to obstruct everything\u2014no matter the merits\u2014just to re-fight the results of an election, is not n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403599292947890176",
    "text" : "Obama: \"A deliberate...effort to obstruct everything\u2014no matter the merits\u2014just to re-fight the results of an election, is not normal.\"",
    "id" : 403599292947890176,
    "created_at" : "2013-11-21 19:02:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 403599379862282240,
  "created_at" : "2013-11-21 19:02:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Filibuster",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403599090967003136",
  "text" : "Obama: \"They have defeated action to help women fight for equal pay. To help striving young immigrants earn their citizenship.\" #Filibuster",
  "id" : 403599090967003136,
  "created_at" : "2013-11-21 19:01:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403599050965917697",
  "text" : "RT @WHLive: \"Repeated abuse of these tactics have blocked legislation to create jobs.\" \u2014President Obama on the Senate GOP's use of the #fil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "filibuster",
        "indices" : [ 123, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403598965678956544",
    "text" : "\"Repeated abuse of these tactics have blocked legislation to create jobs.\" \u2014President Obama on the Senate GOP's use of the #filibuster",
    "id" : 403598965678956544,
    "created_at" : "2013-11-21 19:01:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 403599050965917697,
  "created_at" : "2013-11-21 19:01:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403598874649968640",
  "text" : "Obama: \"An unprecedented pattern of obstruction in Congress has prevented too much of the American people\u2019s business from getting done.\"",
  "id" : 403598874649968640,
  "created_at" : "2013-11-21 19:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Filibuster",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Hs4rtqul97",
      "expanded_url" : "http:\/\/go.wh.gov\/A3fRPf",
      "display_url" : "go.wh.gov\/A3fRPf"
    } ]
  },
  "geo" : { },
  "id_str" : "403598630684086272",
  "text" : "Right now: President Obama speaks on the Senate's efforts to confirm Presidential nominees. Watch \u2014&gt; http:\/\/t.co\/Hs4rtqul97 #Filibuster",
  "id" : 403598630684086272,
  "created_at" : "2013-11-21 18:59:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Filibuster",
      "indices" : [ 130, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Hs4rtqul97",
      "expanded_url" : "http:\/\/go.wh.gov\/A3fRPf",
      "display_url" : "go.wh.gov\/A3fRPf"
    } ]
  },
  "geo" : { },
  "id_str" : "403593729589526528",
  "text" : "At 1:55pm ET, President Obama speaks on the Senate\u2019s efforts to confirm Presidential nominees. Watch \u2014&gt; http:\/\/t.co\/Hs4rtqul97 #Filibuster",
  "id" : 403593729589526528,
  "created_at" : "2013-11-21 18:40:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SenatorReid\/status\/403548538656677890\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/xbQfsftLGm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZmxQfaCQAAXTTH.png",
      "id_str" : "403548538493091840",
      "id" : 403548538493091840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZmxQfaCQAAXTTH.png",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xbQfsftLGm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403577342376693760",
  "text" : "RT @SenatorReid: 168 filibusters of nominees in our history. HALF of them have occurred during Obama years! http:\/\/t.co\/xbQfsftLGm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenatorReid\/status\/403548538656677890\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/xbQfsftLGm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZmxQfaCQAAXTTH.png",
        "id_str" : "403548538493091840",
        "id" : 403548538493091840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZmxQfaCQAAXTTH.png",
        "sizes" : [ {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xbQfsftLGm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403548538656677890",
    "text" : "168 filibusters of nominees in our history. HALF of them have occurred during Obama years! http:\/\/t.co\/xbQfsftLGm",
    "id" : 403548538656677890,
    "created_at" : "2013-11-21 15:40:43 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 403577342376693760,
  "created_at" : "2013-11-21 17:35:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 17, 35 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/K7cAloSpbQ",
      "expanded_url" : "http:\/\/go.wh.gov\/6dq6VH",
      "display_url" : "go.wh.gov\/6dq6VH"
    } ]
  },
  "geo" : { },
  "id_str" : "403571776040345600",
  "text" : "FACT: The Senate #ImmigrationReform bill has strong bipartisan support\u2014but the House GOP refuses to #JustVote \u2014&gt; http:\/\/t.co\/K7cAloSpbQ",
  "id" : 403571776040345600,
  "created_at" : "2013-11-21 17:13:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/403562207125831681\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/OGlbjJtttl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZm9sGeCcAEokf0.jpg",
      "id_str" : "403562206974865409",
      "id" : 403562206974865409,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZm9sGeCcAEokf0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/OGlbjJtttl"
    } ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403562207125831681",
  "text" : "RT if you agree: It's time for Republicans in Congress to stop obstructing progress &amp; #JustVote to grow our economy. http:\/\/t.co\/OGlbjJtttl",
  "id" : 403562207125831681,
  "created_at" : "2013-11-21 16:35:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/puxEMmcs7F",
      "expanded_url" : "http:\/\/cin.ci\/17ry4tt",
      "display_url" : "cin.ci\/17ry4tt"
    } ]
  },
  "geo" : { },
  "id_str" : "403557935730548736",
  "text" : "Here\u2019s just one example of how the Affordable Care Act is spurring innovation \u2014&gt; http:\/\/t.co\/puxEMmcs7F #Obamacare",
  "id" : 403557935730548736,
  "created_at" : "2013-11-21 16:18:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403320822158225408",
  "text" : "RT @WHLive: Obama: \"Fifty years later, John F. Kennedy stands for posterity as he did in life\u2014young, bold and daring.\" #MedalOfFreedom",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalOfFreedom",
        "indices" : [ 107, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403320741828890626",
    "text" : "Obama: \"Fifty years later, John F. Kennedy stands for posterity as he did in life\u2014young, bold and daring.\" #MedalOfFreedom",
    "id" : 403320741828890626,
    "created_at" : "2013-11-21 00:35:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 403320822158225408,
  "created_at" : "2013-11-21 00:35:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403319848282771456",
  "text" : "President Obama: \"Our triumph is not found simply in the exertion of our power. It\u2019s found in the example of our people.\" #MedalOfFreedom",
  "id" : 403319848282771456,
  "created_at" : "2013-11-21 00:31:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 129, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403319459605016576",
  "text" : "Obama: \"What makes us great is that we believe in a certain set of values that encourage freedom of expression &amp; aspiration\" #MedalOfFreedom",
  "id" : 403319459605016576,
  "created_at" : "2013-11-21 00:30:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 55, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ZYs9leLz4G",
      "expanded_url" : "http:\/\/go.wh.gov\/56kdQY",
      "display_url" : "go.wh.gov\/56kdQY"
    } ]
  },
  "geo" : { },
  "id_str" : "403318613542567936",
  "text" : "Right now: President Obama speaks at a dinner honoring #MedalOfFreedom awardees. Watch \u2014&gt; http:\/\/t.co\/ZYs9leLz4G",
  "id" : 403318613542567936,
  "created_at" : "2013-11-21 00:27:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oprah Winfrey",
      "screen_name" : "Oprah",
      "indices" : [ 25, 31 ],
      "id_str" : "19397785",
      "id" : 19397785
    }, {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 33, 45 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/403306331924230144\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/t5vhP816wy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZjU-NqCcAEsZyI.jpg",
      "id_str" : "403306331932618753",
      "id" : 403306331932618753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZjU-NqCcAEsZyI.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/t5vhP816wy"
    } ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 70, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403306331924230144",
  "text" : "President Obama presents @Oprah, @BillClinton, and 14 others with the #MedalOfFreedom. http:\/\/t.co\/t5vhP816wy",
  "id" : 403306331924230144,
  "created_at" : "2013-11-20 23:38:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/403294345823936512\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/j1kwOzvxab",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZjKEh8CYAEquQi.jpg",
      "id_str" : "403294345828130817",
      "id" : 403294345828130817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZjKEh8CYAEquQi.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/j1kwOzvxab"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403295593742614528",
  "text" : "RT @DrBiden: Happy birthday, Joe! Love you. \u2013Jill http:\/\/t.co\/j1kwOzvxab",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/403294345823936512\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/j1kwOzvxab",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZjKEh8CYAEquQi.jpg",
        "id_str" : "403294345828130817",
        "id" : 403294345828130817,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZjKEh8CYAEquQi.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/j1kwOzvxab"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403294345823936512",
    "text" : "Happy birthday, Joe! Love you. \u2013Jill http:\/\/t.co\/j1kwOzvxab",
    "id" : 403294345823936512,
    "created_at" : "2013-11-20 22:50:39 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 403295593742614528,
  "created_at" : "2013-11-20 22:55:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/403292481032167424\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/MZcjoUITdm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZjIX-nCMAAbTOU.jpg",
      "id_str" : "403292480918925312",
      "id" : 403292480918925312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZjIX-nCMAAbTOU.jpg",
      "sizes" : [ {
        "h" : 686,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 686,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MZcjoUITdm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403292481032167424",
  "text" : "The Obamas and Clintons honor President Kennedy at Arlington Cemetery. http:\/\/t.co\/MZcjoUITdm",
  "id" : 403292481032167424,
  "created_at" : "2013-11-20 22:43:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chelsea Clinton",
      "screen_name" : "ChelseaClinton",
      "indices" : [ 3, 18 ],
      "id_str" : "757303975",
      "id" : 757303975
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalofFreedom",
      "indices" : [ 74, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403289842064179200",
  "text" : "RT @ChelseaClinton: Thank you President &amp; Mrs. Obama for a remarkable #MedalofFreedom ceremony honoring remarkable Americans: http:\/\/t.co\/F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 133, 144 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalofFreedom",
        "indices" : [ 54, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/F9UDM4KDDZ",
        "expanded_url" : "http:\/\/wapo.st\/17pq0cM",
        "display_url" : "wapo.st\/17pq0cM"
      } ]
    },
    "geo" : { },
    "id_str" : "403288145749237760",
    "text" : "Thank you President &amp; Mrs. Obama for a remarkable #MedalofFreedom ceremony honoring remarkable Americans: http:\/\/t.co\/F9UDM4KDDZ @WhiteHouse",
    "id" : 403288145749237760,
    "created_at" : "2013-11-20 22:26:01 +0000",
    "user" : {
      "name" : "Chelsea Clinton",
      "screen_name" : "ChelseaClinton",
      "protected" : false,
      "id_str" : "757303975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614488068905652224\/2tUcF22u_normal.jpg",
      "id" : 757303975,
      "verified" : true
    }
  },
  "id" : 403289842064179200,
  "created_at" : "2013-11-20 22:32:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GettysburgAddress",
      "indices" : [ 125, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/iepbFMnDHK",
      "expanded_url" : "http:\/\/go.wh.gov\/CTZmBF",
      "display_url" : "go.wh.gov\/CTZmBF"
    } ]
  },
  "geo" : { },
  "id_str" : "403281642355056640",
  "text" : "\u201CWhatever trials await us, this nation &amp; the freedom we cherish can, and shall, prevail.\u201D \u2014Obama: http:\/\/t.co\/iepbFMnDHK #GettysburgAddress",
  "id" : 403281642355056640,
  "created_at" : "2013-11-20 22:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 25, 40 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 84, 96 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 132, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/4BsLgYJGHM",
      "expanded_url" : "http:\/\/wapo.st\/17mFj67",
      "display_url" : "wapo.st\/17mFj67"
    } ]
  },
  "geo" : { },
  "id_str" : "403262597069156352",
  "text" : "RT if you agree with the @WashingtonPost Editorial Board: \u201CJohn Boehner must act on #immigration now.\u201D \u2014&gt; http:\/\/t.co\/4BsLgYJGHM #JustVote",
  "id" : 403262597069156352,
  "created_at" : "2013-11-20 20:44:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/403250056905510913\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/y8UIWxk0HT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZihykSCQAAjKCX.jpg",
      "id_str" : "403250056754511872",
      "id" : 403250056754511872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZihykSCQAAjKCX.jpg",
      "sizes" : [ {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/y8UIWxk0HT"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 6, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/jG9t6P437A",
      "expanded_url" : "http:\/\/go.wh.gov\/dVVxzj",
      "display_url" : "go.wh.gov\/dVVxzj"
    } ]
  },
  "geo" : { },
  "id_str" : "403250056905510913",
  "text" : "Since #Obamacare became law, health care spending has grown at the slowest rate on record: http:\/\/t.co\/jG9t6P437A, http:\/\/t.co\/y8UIWxk0HT",
  "id" : 403250056905510913,
  "created_at" : "2013-11-20 19:54:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/403223575307366400\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/66Qc77w9VE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZiJtJOCMAAgMka.jpg",
      "id_str" : "403223575311560704",
      "id" : 403223575311560704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZiJtJOCMAAgMka.jpg",
      "sizes" : [ {
        "h" : 798,
        "resize" : "fit",
        "w" : 519
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 798,
        "resize" : "fit",
        "w" : 519
      }, {
        "h" : 798,
        "resize" : "fit",
        "w" : 519
      } ],
      "display_url" : "pic.twitter.com\/66Qc77w9VE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403244962440945664",
  "text" : "RT @VP: In honor of the VP\u2019s bday, our favorite snapshot of him at 10 years old. Happy Birthday! \u2013OVP http:\/\/t.co\/66Qc77w9VE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/403223575307366400\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/66Qc77w9VE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZiJtJOCMAAgMka.jpg",
        "id_str" : "403223575311560704",
        "id" : 403223575311560704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZiJtJOCMAAgMka.jpg",
        "sizes" : [ {
          "h" : 798,
          "resize" : "fit",
          "w" : 519
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 798,
          "resize" : "fit",
          "w" : 519
        }, {
          "h" : 798,
          "resize" : "fit",
          "w" : 519
        } ],
        "display_url" : "pic.twitter.com\/66Qc77w9VE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403223575307366400",
    "text" : "In honor of the VP\u2019s bday, our favorite snapshot of him at 10 years old. Happy Birthday! \u2013OVP http:\/\/t.co\/66Qc77w9VE",
    "id" : 403223575307366400,
    "created_at" : "2013-11-20 18:09:26 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 403244962440945664,
  "created_at" : "2013-11-20 19:34:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 16, 19 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/403240034175709184\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/EEz5Ys0lr8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZiYrKhCIAApZfR.jpg",
      "id_str" : "403240033974362112",
      "id" : 403240033974362112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZiYrKhCIAApZfR.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/EEz5Ys0lr8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403240034175709184",
  "text" : "Happy birthday, @VP Biden! http:\/\/t.co\/EEz5Ys0lr8",
  "id" : 403240034175709184,
  "created_at" : "2013-11-20 19:14:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalofFreedom",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403237615669096448",
  "text" : "RT @NASA: President Obama posthumously honored Sally Ride, 1st female NASA astronaut in space, w\/ #MedalofFreedom today. http:\/\/t.co\/NlURne\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/403218774825771008\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/NlURnekxFK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZiFVuECIAAWK8u.jpg",
        "id_str" : "403218774838353920",
        "id" : 403218774838353920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZiFVuECIAAWK8u.jpg",
        "sizes" : [ {
          "h" : 418,
          "resize" : "fit",
          "w" : 673
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 673
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/NlURnekxFK"
      } ],
      "hashtags" : [ {
        "text" : "MedalofFreedom",
        "indices" : [ 88, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403218774825771008",
    "text" : "President Obama posthumously honored Sally Ride, 1st female NASA astronaut in space, w\/ #MedalofFreedom today. http:\/\/t.co\/NlURnekxFK",
    "id" : 403218774825771008,
    "created_at" : "2013-11-20 17:50:22 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 403237615669096448,
  "created_at" : "2013-11-20 19:05:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403222660529668096",
  "text" : "FACT: The Affordable Care Act will reduce our deficit by about $100 billion over 10 years according to the nonpartisan CBO. #Obamacare",
  "id" : 403222660529668096,
  "created_at" : "2013-11-20 18:05:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/7QBj5h07lW",
      "expanded_url" : "http:\/\/go.wh.gov\/qucgsZ",
      "display_url" : "go.wh.gov\/qucgsZ"
    } ]
  },
  "geo" : { },
  "id_str" : "403217821779247104",
  "text" : "RT the news: Health care spending has grown at the slowest rate on record since #Obamacare became law \u2014&gt; http:\/\/t.co\/7QBj5h07lW",
  "id" : 403217821779247104,
  "created_at" : "2013-11-20 17:46:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403201061525020672",
  "text" : "President Obama: \"These are men and women who in their extraordinary lives remind us all of the beauty of the human spirit.\" #MedalOfFreedom",
  "id" : 403201061525020672,
  "created_at" : "2013-11-20 16:39:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 9, 21 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403200893299859457",
  "text" : "Obama on @BillClinton: \"For your life-saving work around the world, which represents the very best of America, Bill, thank you so much.\"",
  "id" : 403200893299859457,
  "created_at" : "2013-11-20 16:39:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oprah Winfrey",
      "screen_name" : "Oprah",
      "indices" : [ 18, 24 ],
      "id_str" : "19397785",
      "id" : 19397785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403199118878580736",
  "text" : "President Obama: \"@Oprah\u2019s greatest strength has always been her ability to help us discover the best in ourselves.\" #MedalOfFreedom",
  "id" : 403199118878580736,
  "created_at" : "2013-11-20 16:32:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403198628061147136",
  "text" : "RT @WHLive: Obama on Gloria Steinem: \"Because of her work...more women are afforded the respect and opportunities they deserve.\" #MedalOfFr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalOfFreedom",
        "indices" : [ 117, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403198544581902336",
    "text" : "Obama on Gloria Steinem: \"Because of her work...more women are afforded the respect and opportunities they deserve.\" #MedalOfFreedom",
    "id" : 403198544581902336,
    "created_at" : "2013-11-20 16:29:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 403198628061147136,
  "created_at" : "2013-11-20 16:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403196343394390016",
  "text" : "Obama: \"As the 1st American woman in space\u2014Sally didn\u2019t just break that stratospheric glass ceiling\u2014she blasted through it.\" #MedalOfFreedom",
  "id" : 403196343394390016,
  "created_at" : "2013-11-20 16:21:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403195941684924416",
  "text" : "RT @WHLive: Obama: Ernie Banks \"came up through the Negro Leagues making $7\/day &amp; became the 1st black player to suit up for the Cubs.\" #Me\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalOfFreedom",
        "indices" : [ 128, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403195917748011009",
    "text" : "Obama: Ernie Banks \"came up through the Negro Leagues making $7\/day &amp; became the 1st black player to suit up for the Cubs.\" #MedalOfFreedom",
    "id" : 403195917748011009,
    "created_at" : "2013-11-20 16:19:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 403195941684924416,
  "created_at" : "2013-11-20 16:19:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403195786583736320",
  "text" : "RT @WHLive: Obama: \"Celebrating extraordinary individuals with our nation\u2019s highest civilian honor...is always a special occasion.\" #MedalO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalOfFreedom",
        "indices" : [ 120, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "403195670741262336",
    "text" : "Obama: \"Celebrating extraordinary individuals with our nation\u2019s highest civilian honor...is always a special occasion.\" #MedalOfFreedom",
    "id" : 403195670741262336,
    "created_at" : "2013-11-20 16:18:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 403195786583736320,
  "created_at" : "2013-11-20 16:19:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 34, 46 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    }, {
      "name" : "Oprah Winfrey",
      "screen_name" : "Oprah",
      "indices" : [ 48, 54 ],
      "id_str" : "19397785",
      "id" : 19397785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 89, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/2B2AKLQJtz",
      "expanded_url" : "http:\/\/go.wh.gov\/kBzf7a",
      "display_url" : "go.wh.gov\/kBzf7a"
    } ]
  },
  "geo" : { },
  "id_str" : "403195213255933952",
  "text" : "Right now: President Obama honors @BillClinton, @Oprah, and others with the Presidential #MedalOfFreedom. Watch \u2014&gt; http:\/\/t.co\/2B2AKLQJtz",
  "id" : 403195213255933952,
  "created_at" : "2013-11-20 16:16:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 66, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/2B2AKLQJtz",
      "expanded_url" : "http:\/\/go.wh.gov\/kBzf7a",
      "display_url" : "go.wh.gov\/kBzf7a"
    } ]
  },
  "geo" : { },
  "id_str" : "403185225879937024",
  "text" : "At 11am ET, President Obama honors recipients of the Presidential #MedalOfFreedom. Watch here \u2014&gt; http:\/\/t.co\/2B2AKLQJtz",
  "id" : 403185225879937024,
  "created_at" : "2013-11-20 15:37:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30E3\u30ED\u30E9\u30A4\u30F3\u30FB\u30B1\u30CD\u30C7\u30A3\u5927\u4F7F",
      "screen_name" : "CarolineKennedy",
      "indices" : [ 20, 36 ],
      "id_str" : "1900694785",
      "id" : 1900694785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/OWrSNjzFqm",
      "expanded_url" : "http:\/\/go.wh.gov\/Y9QNjH",
      "display_url" : "go.wh.gov\/Y9QNjH"
    } ]
  },
  "geo" : { },
  "id_str" : "402957160658649088",
  "text" : "Welcome to Twitter, @CarolineKennedy! Here's the latest from our Ambassador to Japan \u2014&gt; http:\/\/t.co\/OWrSNjzFqm",
  "id" : 402957160658649088,
  "created_at" : "2013-11-20 00:30:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GettysburgAddress",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/tVTDFJm8Gk",
      "expanded_url" : "http:\/\/go.wh.gov\/SHXFqY",
      "display_url" : "go.wh.gov\/SHXFqY"
    } ]
  },
  "geo" : { },
  "id_str" : "402950094690869248",
  "text" : "You'll want to read this: A 272-word handwritten essay from President Obama paying tribute to the #GettysburgAddress. http:\/\/t.co\/tVTDFJm8Gk",
  "id" : 402950094690869248,
  "created_at" : "2013-11-20 00:02:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/reoWTgjIPT",
      "expanded_url" : "http:\/\/go.wh.gov\/51HyBe",
      "display_url" : "go.wh.gov\/51HyBe"
    } ]
  },
  "geo" : { },
  "id_str" : "402933688561721344",
  "text" : "FACT: The Senate voted to end workplace discrimination against LGBT Americans\u2014but the House GOP refuses to #JustVote: http:\/\/t.co\/reoWTgjIPT",
  "id" : 402933688561721344,
  "created_at" : "2013-11-19 22:57:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 10, 28 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402922258651303937",
  "text" : "FACT: The #ImmigrationReform bill that passed the Senate has strong bipartisan support, but the House GOP refuses to #JustVote.",
  "id" : 402922258651303937,
  "created_at" : "2013-11-19 22:12:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 35, 53 ]
    }, {
      "text" : "ENDA",
      "indices" : [ 62, 67 ]
    }, {
      "text" : "JustVote",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/reoWTgjIPT",
      "expanded_url" : "http:\/\/go.wh.gov\/51HyBe",
      "display_url" : "go.wh.gov\/51HyBe"
    } ]
  },
  "geo" : { },
  "id_str" : "402913932794269697",
  "text" : "Right now, Congress could:\n1. Pass #ImmigrationReform\n2. Pass #ENDA\nIf House Republicans would #JustVote.\nhttp:\/\/t.co\/reoWTgjIPT",
  "id" : 402913932794269697,
  "created_at" : "2013-11-19 21:39:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 63, 67 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/Y5w9tUtNCh",
      "expanded_url" : "http:\/\/go.wh.gov\/TrMYnC",
      "display_url" : "go.wh.gov\/TrMYnC"
    } ]
  },
  "geo" : { },
  "id_str" : "402896839927545856",
  "text" : "Right now: President Obama speaks and answers questions at the @WSJ CEO Council Annual Meeting \u2014&gt; http:\/\/t.co\/Y5w9tUtNCh",
  "id" : 402896839927545856,
  "created_at" : "2013-11-19 20:31:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 110, 119 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402852622039670784",
  "text" : "RT @DrBiden: Partnership key to success for innovative community college worker training program. My op-ed w\/ @LaborSec: http:\/\/t.co\/LWK8e0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 97, 106 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CCTour",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/LWK8e0SOtC",
        "expanded_url" : "http:\/\/bit.ly\/IdlnJ8",
        "display_url" : "bit.ly\/IdlnJ8"
      } ]
    },
    "geo" : { },
    "id_str" : "402845768509190144",
    "text" : "Partnership key to success for innovative community college worker training program. My op-ed w\/ @LaborSec: http:\/\/t.co\/LWK8e0SOtC #CCTour",
    "id" : 402845768509190144,
    "created_at" : "2013-11-19 17:08:10 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 402852622039670784,
  "created_at" : "2013-11-19 17:35:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 15, 25 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/sPsd4qqHpS",
      "expanded_url" : "http:\/\/lat.ms\/17iKALT",
      "display_url" : "lat.ms\/17iKALT"
    } ]
  },
  "geo" : { },
  "id_str" : "402845491307614208",
  "text" : "Worth sharing: #Obamacare enrollment surges in many states around the country \u2014&gt; http:\/\/t.co\/sPsd4qqHpS #GetCovered",
  "id" : 402845491307614208,
  "created_at" : "2013-11-19 17:07:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 29, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402826503521845248",
  "text" : "RT @Cecilia44: Harry Reid on #immigration:\"I'm not giving up on this year.\"  The President won't either -neither should anyone else. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "immigration",
        "indices" : [ 14, 26 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/pQhc4aJGEF",
        "expanded_url" : "http:\/\/goo.gl\/SzAiK4",
        "display_url" : "goo.gl\/SzAiK4"
      } ]
    },
    "geo" : { },
    "id_str" : "402824799979728896",
    "text" : "Harry Reid on #immigration:\"I'm not giving up on this year.\"  The President won't either -neither should anyone else. http:\/\/t.co\/pQhc4aJGEF",
    "id" : 402824799979728896,
    "created_at" : "2013-11-19 15:44:51 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 402826503521845248,
  "created_at" : "2013-11-19 15:51:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 98, 109 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/sPsd4qqHpS",
      "expanded_url" : "http:\/\/lat.ms\/17iKALT",
      "display_url" : "lat.ms\/17iKALT"
    } ]
  },
  "geo" : { },
  "id_str" : "402816609732931584",
  "text" : "Health insurance enrollment surges in many states around the country \u2014&gt; http:\/\/t.co\/sPsd4qqHpS #GetCovered #Obamacare",
  "id" : 402816609732931584,
  "created_at" : "2013-11-19 15:12:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/402634869097775104\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/oCWeC35bvZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZZyR7WCUAAa72Q.jpg",
      "id_str" : "402634869009698816",
      "id" : 402634869009698816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZZyR7WCUAAa72Q.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      } ],
      "display_url" : "pic.twitter.com\/oCWeC35bvZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402634869097775104",
  "text" : "POTUS and his Chief of Staff in the Oval Office: http:\/\/t.co\/oCWeC35bvZ",
  "id" : 402634869097775104,
  "created_at" : "2013-11-19 03:10:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JustVote",
      "indices" : [ 135, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402591553538904065",
  "text" : "Obama: Senate R's \"have once again refused to do their job &amp; give well-qualified nominees to the federal bench...yes-or-no votes.\" #JustVote",
  "id" : 402591553538904065,
  "created_at" : "2013-11-19 00:18:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/LqR49nC8IZ",
      "expanded_url" : "http:\/\/go.wh.gov\/8KD6g9",
      "display_url" : "go.wh.gov\/8KD6g9"
    } ]
  },
  "geo" : { },
  "id_str" : "402589427563638784",
  "text" : "Obama: \"Senate Republicans are standing in the way of a fully-functioning judiciary that serves the American people.\" http:\/\/t.co\/LqR49nC8IZ",
  "id" : 402589427563638784,
  "created_at" : "2013-11-19 00:09:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 26, 35 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "ClevelandCommCollege",
      "screen_name" : "ClevelandCC",
      "indices" : [ 90, 102 ],
      "id_str" : "35805866",
      "id" : 35805866
    }, {
      "name" : "Broward College",
      "screen_name" : "BrowardCollege",
      "indices" : [ 109, 124 ],
      "id_str" : "15524229",
      "id" : 15524229
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CCTour",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402565338057166848",
  "text" : "RT @DrBiden: Great day w\/ @LaborSec learning more about innovative workforce partnerships @ClevelandCC &amp; @BrowardCollege! #CCTour",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 13, 22 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      }, {
        "name" : "ClevelandCommCollege",
        "screen_name" : "ClevelandCC",
        "indices" : [ 77, 89 ],
        "id_str" : "35805866",
        "id" : 35805866
      }, {
        "name" : "Broward College",
        "screen_name" : "BrowardCollege",
        "indices" : [ 96, 111 ],
        "id_str" : "15524229",
        "id" : 15524229
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CCTour",
        "indices" : [ 113, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402547910132654080",
    "text" : "Great day w\/ @LaborSec learning more about innovative workforce partnerships @ClevelandCC &amp; @BrowardCollege! #CCTour",
    "id" : 402547910132654080,
    "created_at" : "2013-11-18 21:24:35 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 402565338057166848,
  "created_at" : "2013-11-18 22:33:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "We've Moved",
      "screen_name" : "NASA_GoddardPix",
      "indices" : [ 75, 91 ],
      "id_str" : "2285685223",
      "id" : 2285685223
    }, {
      "name" : "Astro Pic Of The Day",
      "screen_name" : "apod",
      "indices" : [ 92, 97 ],
      "id_str" : "8295072",
      "id" : 8295072
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NASA_GoddardPix\/status\/402526014925856769\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/TbdkFyhvea",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZYPRx_CQAEMdhG.jpg",
      "id_str" : "402526014846156801",
      "id" : 402526014846156801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZYPRx_CQAEMdhG.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/TbdkFyhvea"
    } ],
    "hashtags" : [ {
      "text" : "Iceland",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/59D0nuOOBC",
      "expanded_url" : "http:\/\/1.usa.gov\/gc6hcU",
      "display_url" : "1.usa.gov\/gc6hcU"
    } ]
  },
  "geo" : { },
  "id_str" : "402561694339047424",
  "text" : "RT @whitehouseostp: Unreal aurora over #Iceland http:\/\/t.co\/59D0nuOOBC via @NASA_GoddardPix @apod http:\/\/t.co\/TbdkFyhvea",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We've Moved",
        "screen_name" : "NASA_GoddardPix",
        "indices" : [ 55, 71 ],
        "id_str" : "2285685223",
        "id" : 2285685223
      }, {
        "name" : "Astro Pic Of The Day",
        "screen_name" : "apod",
        "indices" : [ 72, 77 ],
        "id_str" : "8295072",
        "id" : 8295072
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA_GoddardPix\/status\/402526014925856769\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/TbdkFyhvea",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZYPRx_CQAEMdhG.jpg",
        "id_str" : "402526014846156801",
        "id" : 402526014846156801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZYPRx_CQAEMdhG.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/TbdkFyhvea"
      } ],
      "hashtags" : [ {
        "text" : "Iceland",
        "indices" : [ 19, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/59D0nuOOBC",
        "expanded_url" : "http:\/\/1.usa.gov\/gc6hcU",
        "display_url" : "1.usa.gov\/gc6hcU"
      } ]
    },
    "geo" : { },
    "id_str" : "402526510981992448",
    "text" : "Unreal aurora over #Iceland http:\/\/t.co\/59D0nuOOBC via @NASA_GoddardPix @apod http:\/\/t.co\/TbdkFyhvea",
    "id" : 402526510981992448,
    "created_at" : "2013-11-18 19:59:33 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 402561694339047424,
  "created_at" : "2013-11-18 22:19:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402556761518780416",
  "text" : "Thanks to #Obamacare, Deborah L. from NH is saving nearly $600\/month on her premium with a lower deductible and lower co-pays. #GetCovered",
  "id" : 402556761518780416,
  "created_at" : "2013-11-18 21:59:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 118, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402547867442630656",
  "text" : "Thanks to #Obamacare, Dan M. from Orlando pays $70\/month for a plan with much better benefits than he had previously. #GetCovered",
  "id" : 402547867442630656,
  "created_at" : "2013-11-18 21:24:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 134, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402526154982055936",
  "text" : "\"My new plan gives me better coverage than what I've had with the same insurer &amp; will cost $188\/month less.\" \u2014Larry M. from CA on #Obamacare",
  "id" : 402526154982055936,
  "created_at" : "2013-11-18 19:58:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/402504061481517056\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/kbAWwvMoZE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZX7T7WCAAAOEIG.png",
      "id_str" : "402504061485711360",
      "id" : 402504061485711360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZX7T7WCAAAOEIG.png",
      "sizes" : [ {
        "h" : 409,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 715,
        "resize" : "fit",
        "w" : 1049
      }, {
        "h" : 698,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kbAWwvMoZE"
    } ],
    "hashtags" : [ {
      "text" : "MAVEN",
      "indices" : [ 30, 36 ]
    }, {
      "text" : "Atlas5",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402504401153048576",
  "text" : "RT @NASA: And lift off of the #MAVEN spacecraft on a journey to Mars aboard an #Atlas5 rocket: http:\/\/t.co\/kbAWwvMoZE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/402504061481517056\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/kbAWwvMoZE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZX7T7WCAAAOEIG.png",
        "id_str" : "402504061485711360",
        "id" : 402504061485711360,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZX7T7WCAAAOEIG.png",
        "sizes" : [ {
          "h" : 409,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 715,
          "resize" : "fit",
          "w" : 1049
        }, {
          "h" : 698,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kbAWwvMoZE"
      } ],
      "hashtags" : [ {
        "text" : "MAVEN",
        "indices" : [ 20, 26 ]
      }, {
        "text" : "Atlas5",
        "indices" : [ 69, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "402504061481517056",
    "text" : "And lift off of the #MAVEN spacecraft on a journey to Mars aboard an #Atlas5 rocket: http:\/\/t.co\/kbAWwvMoZE",
    "id" : 402504061481517056,
    "created_at" : "2013-11-18 18:30:21 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 402504401153048576,
  "created_at" : "2013-11-18 18:31:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/6rD2VfsB9R",
      "expanded_url" : "http:\/\/wapo.st\/17eUXjE",
      "display_url" : "wapo.st\/17eUXjE"
    } ]
  },
  "geo" : { },
  "id_str" : "402489067486466048",
  "text" : "Thanks to #Obamacare, employees at Howard S.'s business are saving 5-40% on new insurance plans with better benefits: http:\/\/t.co\/6rD2VfsB9R",
  "id" : 402489067486466048,
  "created_at" : "2013-11-18 17:30:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/6rD2VfsB9R",
      "expanded_url" : "http:\/\/wapo.st\/17eUXjE",
      "display_url" : "wapo.st\/17eUXjE"
    } ]
  },
  "geo" : { },
  "id_str" : "402479000200544256",
  "text" : "Thanks to #Obamacare, Anne M. reduced her monthly premium by more than $600\/month for similar health coverage \u2014&gt; http:\/\/t.co\/6rD2VfsB9R",
  "id" : 402479000200544256,
  "created_at" : "2013-11-18 16:50:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcia Snyder",
      "screen_name" : "GovSteveBeshear",
      "indices" : [ 18, 34 ],
      "id_str" : "4549215252",
      "id" : 4549215252
    }, {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 36, 52 ],
      "id_str" : "234141596",
      "id" : 234141596
    }, {
      "name" : "Governor Jay Inslee",
      "screen_name" : "GovInslee",
      "indices" : [ 58, 68 ],
      "id_str" : "1077214808",
      "id" : 1077214808
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/6rD2VfsB9R",
      "expanded_url" : "http:\/\/wapo.st\/17eUXjE",
      "display_url" : "wapo.st\/17eUXjE"
    } ]
  },
  "geo" : { },
  "id_str" : "402468728907898881",
  "text" : "Worth a read: How @GovSteveBeshear, @GovMalloyOffice, and @GovInslee are making #Obamacare work in KY, CT, and WA \u2014&gt; http:\/\/t.co\/6rD2VfsB9R",
  "id" : 402468728907898881,
  "created_at" : "2013-11-18 16:09:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/OpP7m5UEFr",
      "expanded_url" : "http:\/\/wapo.st\/17eUXjF",
      "display_url" : "wapo.st\/17eUXjF"
    } ]
  },
  "geo" : { },
  "id_str" : "402454148852899840",
  "text" : "RT @jesseclee44: Powerful piece from Governors Inslee, Beshear &amp; Malloy in WaPo: \"How we got #Obamacare to work\" http:\/\/t.co\/OpP7m5UEFr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 80, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/OpP7m5UEFr",
        "expanded_url" : "http:\/\/wapo.st\/17eUXjF",
        "display_url" : "wapo.st\/17eUXjF"
      } ]
    },
    "geo" : { },
    "id_str" : "402448891997478913",
    "text" : "Powerful piece from Governors Inslee, Beshear &amp; Malloy in WaPo: \"How we got #Obamacare to work\" http:\/\/t.co\/OpP7m5UEFr",
    "id" : 402448891997478913,
    "created_at" : "2013-11-18 14:51:07 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 402454148852899840,
  "created_at" : "2013-11-18 15:12:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/402447686504153090\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/zaEqIeUBqU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZXICeNCAAAMhNe.png",
      "id_str" : "402447686512541696",
      "id" : 402447686512541696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZXICeNCAAAMhNe.png",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/zaEqIeUBqU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402447686504153090",
  "text" : "Out of many, we are one. http:\/\/t.co\/zaEqIeUBqU",
  "id" : 402447686504153090,
  "created_at" : "2013-11-18 14:46:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/DwkzbJ76Z6",
      "expanded_url" : "http:\/\/go.wh.gov\/hsD8XZ",
      "display_url" : "go.wh.gov\/hsD8XZ"
    } ]
  },
  "geo" : { },
  "id_str" : "402241176104751104",
  "text" : "Watch a recap of President Obama's week at the White House \u2014&gt; http:\/\/t.co\/DwkzbJ76Z6 #WestWingWeek",
  "id" : 402241176104751104,
  "created_at" : "2013-11-18 01:05:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/CINRk4GHsQ",
      "expanded_url" : "http:\/\/go.wh.gov\/2aMooD",
      "display_url" : "go.wh.gov\/2aMooD"
    } ]
  },
  "geo" : { },
  "id_str" : "402160392429764608",
  "text" : "Here's your backstage pass to go behind-the-scenes with President Obama. Watch \u2014&gt; http:\/\/t.co\/CINRk4GHsQ #WestWingWeek",
  "id" : 402160392429764608,
  "created_at" : "2013-11-17 19:44:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/6mkqZ5GPmm",
      "expanded_url" : "http:\/\/go.wh.gov\/NubpZP",
      "display_url" : "go.wh.gov\/NubpZP"
    } ]
  },
  "geo" : { },
  "id_str" : "401873750150246400",
  "text" : "Obama: \"We generate more renewable energy than ever\u2014with tens of thousands of good, American jobs to show for it.\" http:\/\/t.co\/6mkqZ5GPmm",
  "id" : 401873750150246400,
  "created_at" : "2013-11-17 00:45:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/OIdUDMn5EH",
      "expanded_url" : "http:\/\/go.wh.gov\/gqhpxE",
      "display_url" : "go.wh.gov\/gqhpxE"
    } ]
  },
  "geo" : { },
  "id_str" : "401808567704895488",
  "text" : "Obama: \"The United States of America now produces more of our own oil here at home than we buy from other countries.\" http:\/\/t.co\/OIdUDMn5EH",
  "id" : 401808567704895488,
  "created_at" : "2013-11-16 20:26:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Lcuv22MK9b",
      "expanded_url" : "http:\/\/go.wh.gov\/8m9vY5",
      "display_url" : "go.wh.gov\/8m9vY5"
    } ]
  },
  "geo" : { },
  "id_str" : "401737599267520512",
  "text" : "Watch President Obama's Weekly Address on leaving our kids a stronger economy and a safer planet \u2014&gt; http:\/\/t.co\/Lcuv22MK9b #ActOnClimate",
  "id" : 401737599267520512,
  "created_at" : "2013-11-16 15:44:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFBatKid",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401489800886120448",
  "text" : "RT @FLOTUS: Thanks for catching all those bad guys #SFBatKid! You're an inspiration to us all. -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SFBatKid",
        "indices" : [ 39, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401489051137499137",
    "text" : "Thanks for catching all those bad guys #SFBatKid! You're an inspiration to us all. -mo",
    "id" : 401489051137499137,
    "created_at" : "2013-11-15 23:17:03 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 401489800886120448,
  "created_at" : "2013-11-15 23:20:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SFBatKid",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/O7J4XWwYBs",
      "expanded_url" : "http:\/\/vine.co\/v\/htbdjZAPrAX",
      "display_url" : "vine.co\/v\/htbdjZAPrAX"
    } ]
  },
  "geo" : { },
  "id_str" : "401474141569572864",
  "text" : "President Obama's message to #SFBatKid \u2014&gt; http:\/\/t.co\/O7J4XWwYBs",
  "id" : 401474141569572864,
  "created_at" : "2013-11-15 22:17:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/401459238100160512\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/VVzTPVVuJg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZJFDMaCIAAPxOr.jpg",
      "id_str" : "401459237961736192",
      "id" : 401459237961736192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZJFDMaCIAAPxOr.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/VVzTPVVuJg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401459238100160512",
  "text" : "1. More jobs\n2. Higher wages\n3. Affordable health care\n4. Opportunity\nThat's what we're going to keep fighting for. http:\/\/t.co\/VVzTPVVuJg",
  "id" : 401459238100160512,
  "created_at" : "2013-11-15 21:18:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SFWish\/status\/401420300593541121\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/2PyWt49ak8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZIhouxCMAA_qgh.jpg",
      "id_str" : "401420300421574656",
      "id" : 401420300421574656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZIhouxCMAA_qgh.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/2PyWt49ak8"
    } ],
    "hashtags" : [ {
      "text" : "SFBatKid",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401435118310400000",
  "text" : "Rooting for #SFBatKid. Go get 'em! http:\/\/t.co\/2PyWt49ak8",
  "id" : 401435118310400000,
  "created_at" : "2013-11-15 19:42:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/401429985614761984\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/GehWZLA5Rv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZIqcebCUAAurOR.jpg",
      "id_str" : "401429985480560640",
      "id" : 401429985480560640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZIqcebCUAAurOR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/GehWZLA5Rv"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 45, 56 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401429985614761984",
  "text" : "It's time to focus on helping more Americans #GetCovered\u2014not repeal the progress we've made. #Obamacare, http:\/\/t.co\/GehWZLA5Rv",
  "id" : 401429985614761984,
  "created_at" : "2013-11-15 19:22:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/401428582956036097\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/Zdh9vUKe6E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZIpK1GIEAA6ozH.jpg",
      "id_str" : "401428582817599488",
      "id" : 401428582817599488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZIpK1GIEAA6ozH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Zdh9vUKe6E"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401428582956036097",
  "text" : "Under President Obama, our economy has grown even as we've reduced carbon pollution. #ActOnClimate, http:\/\/t.co\/Zdh9vUKe6E",
  "id" : 401428582956036097,
  "created_at" : "2013-11-15 19:16:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401422015816429568",
  "text" : "FACT: Last year, carbon pollution from our transportation sector was the lowest it's been in more than a decade. #ActOnClimate",
  "id" : 401422015816429568,
  "created_at" : "2013-11-15 18:50:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401416982223794176",
  "text" : "FACT: Obama's fuel efficiency standards will save the average driver $8,000 at the pump over the life of new cars in 2025. #ActOnClimate",
  "id" : 401416982223794176,
  "created_at" : "2013-11-15 18:30:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Hudy",
      "screen_name" : "Joey_Hudy",
      "indices" : [ 28, 38 ],
      "id_str" : "321466257",
      "id" : 321466257
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/401409793858232320\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DuVrkZ90rB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZIYFKLIEAAIoZ9.jpg",
      "id_str" : "401409793698828288",
      "id" : 401409793698828288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZIYFKLIEAAIoZ9.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/DuVrkZ90rB"
    } ],
    "hashtags" : [ {
      "text" : "makers",
      "indices" : [ 57, 64 ]
    }, {
      "text" : "WeTheGeeks",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/uzfthuUBwb",
      "expanded_url" : "http:\/\/go.wh.gov\/YaKSta",
      "display_url" : "go.wh.gov\/YaKSta"
    } ]
  },
  "geo" : { },
  "id_str" : "401409793858232320",
  "text" : "Starting now: Hang out with @Joey_Hudy and other awesome #makers on #WeTheGeeks. Watch \u2014&gt; http:\/\/t.co\/uzfthuUBwb, http:\/\/t.co\/DuVrkZ90rB",
  "id" : 401409793858232320,
  "created_at" : "2013-11-15 18:02:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/KXQXAoP73i",
      "expanded_url" : "http:\/\/go.wh.gov\/8ekGoz",
      "display_url" : "go.wh.gov\/8ekGoz"
    } ]
  },
  "geo" : { },
  "id_str" : "401405657892413440",
  "text" : "FACT: Under President Obama, we've cut our dependence on foreign oil to a 17-year low \u2014&gt; http:\/\/t.co\/KXQXAoP73i #ActOnClimate",
  "id" : 401405657892413440,
  "created_at" : "2013-11-15 17:45:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/401398129934598144\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/v9GdUUC2UX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZINeOtCUAAw1Z2.jpg",
      "id_str" : "401398129783623680",
      "id" : 401398129783623680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZINeOtCUAAw1Z2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/v9GdUUC2UX"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/yrT1EcWRgP",
      "expanded_url" : "http:\/\/go.wh.gov\/krYFCu",
      "display_url" : "go.wh.gov\/krYFCu"
    } ]
  },
  "geo" : { },
  "id_str" : "401398129934598144",
  "text" : "We're importing less oil than we're producing\u2014and using less oil overall \u2014&gt; http:\/\/t.co\/yrT1EcWRgP #ActOnClimate, http:\/\/t.co\/v9GdUUC2UX",
  "id" : 401398129934598144,
  "created_at" : "2013-11-15 17:15:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Lewis",
      "screen_name" : "KLewis44",
      "indices" : [ 3, 12 ],
      "id_str" : "1639207880",
      "id" : 1639207880
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 15, 18 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Abram V. Horgan",
      "screen_name" : "KingCenterATL",
      "indices" : [ 73, 87 ],
      "id_str" : "3203720542",
      "id" : 3203720542
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/401139256589959169\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/nNDoa6aYhk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZEiB07CQAElpMX.jpg",
      "id_str" : "401139256594153473",
      "id" : 401139256594153473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZEiB07CQAElpMX.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/nNDoa6aYhk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401394263780372481",
  "text" : "RT @KLewis44: .@VP  Biden honors MLK and Coretta Scott King yesterday at @KingCenterATL in Atlanta, GA. \nPhoto--&gt;http:\/\/t.co\/nNDoa6aYhk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 1, 4 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "Abram V. Horgan",
        "screen_name" : "KingCenterATL",
        "indices" : [ 59, 73 ],
        "id_str" : "3203720542",
        "id" : 3203720542
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/401139256589959169\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/nNDoa6aYhk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZEiB07CQAElpMX.jpg",
        "id_str" : "401139256594153473",
        "id" : 401139256594153473,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZEiB07CQAElpMX.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/nNDoa6aYhk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401391771780792320",
    "text" : ".@VP  Biden honors MLK and Coretta Scott King yesterday at @KingCenterATL in Atlanta, GA. \nPhoto--&gt;http:\/\/t.co\/nNDoa6aYhk",
    "id" : 401391771780792320,
    "created_at" : "2013-11-15 16:50:30 +0000",
    "user" : {
      "name" : "Kevin Lewis",
      "screen_name" : "KLewis44",
      "protected" : false,
      "id_str" : "1639207880",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711839771438354432\/NXZNoswc_normal.jpg",
      "id" : 1639207880,
      "verified" : true
    }
  },
  "id" : 401394263780372481,
  "created_at" : "2013-11-15 17:00:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Joey Hudy",
      "screen_name" : "Joey_Hudy",
      "indices" : [ 73, 83 ],
      "id_str" : "321466257",
      "id" : 321466257
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/4Uyn0DkyaA",
      "expanded_url" : "http:\/\/youtu.be\/Reimvk8D2Ho",
      "display_url" : "youtu.be\/Reimvk8D2Ho"
    } ]
  },
  "geo" : { },
  "id_str" : "401391512765747200",
  "text" : "RT @ks44: Remember when this happened? http:\/\/t.co\/4Uyn0DkyaA Don't miss @Joey_Hudy &amp; more during #WeTheGeeks today at 1ET \u2014&gt; http:\/\/t.co\/1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joey Hudy",
        "screen_name" : "Joey_Hudy",
        "indices" : [ 63, 73 ],
        "id_str" : "321466257",
        "id" : 321466257
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 92, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/4Uyn0DkyaA",
        "expanded_url" : "http:\/\/youtu.be\/Reimvk8D2Ho",
        "display_url" : "youtu.be\/Reimvk8D2Ho"
      }, {
        "indices" : [ 123, 145 ],
        "url" : "http:\/\/t.co\/1kM0iiDsbS",
        "expanded_url" : "http:\/\/wh.gov\/wethegeeks",
        "display_url" : "wh.gov\/wethegeeks"
      } ]
    },
    "geo" : { },
    "id_str" : "401389583436234752",
    "text" : "Remember when this happened? http:\/\/t.co\/4Uyn0DkyaA Don't miss @Joey_Hudy &amp; more during #WeTheGeeks today at 1ET \u2014&gt; http:\/\/t.co\/1kM0iiDsbS",
    "id" : 401389583436234752,
    "created_at" : "2013-11-15 16:41:48 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 401391512765747200,
  "created_at" : "2013-11-15 16:49:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NASAGoddard\/status\/401357059968729089\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/QQEbHE2gAF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZHoHpNIIAAvVQf.jpg",
      "id_str" : "401357059830325248",
      "id" : 401357059830325248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZHoHpNIIAAvVQf.jpg",
      "sizes" : [ {
        "h" : 1017,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1271,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QQEbHE2gAF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/AeQ7SnQAJQ",
      "expanded_url" : "http:\/\/bit.ly\/1d1Rmdv",
      "display_url" : "bit.ly\/1d1Rmdv"
    } ]
  },
  "geo" : { },
  "id_str" : "401383540186955776",
  "text" : "RT @NASA: Happy Hubble Friday! NASA Hubble Sees Sparring Antennae Galaxies: http:\/\/t.co\/AeQ7SnQAJQ http:\/\/t.co\/QQEbHE2gAF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASAGoddard\/status\/401357059968729089\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/QQEbHE2gAF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZHoHpNIIAAvVQf.jpg",
        "id_str" : "401357059830325248",
        "id" : 401357059830325248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZHoHpNIIAAvVQf.jpg",
        "sizes" : [ {
          "h" : 1017,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1271,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/QQEbHE2gAF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/AeQ7SnQAJQ",
        "expanded_url" : "http:\/\/bit.ly\/1d1Rmdv",
        "display_url" : "bit.ly\/1d1Rmdv"
      } ]
    },
    "geo" : { },
    "id_str" : "401382695193690112",
    "text" : "Happy Hubble Friday! NASA Hubble Sees Sparring Antennae Galaxies: http:\/\/t.co\/AeQ7SnQAJQ http:\/\/t.co\/QQEbHE2gAF",
    "id" : 401382695193690112,
    "created_at" : "2013-11-15 16:14:26 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 401383540186955776,
  "created_at" : "2013-11-15 16:17:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/HrwbPpJhpZ",
      "expanded_url" : "http:\/\/instagram.com\/p\/gt1GhAQivB\/",
      "display_url" : "instagram.com\/p\/gt1GhAQivB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "401377619494461440",
  "text" : "Go behind-the-scenes with President Obama for a 15-second tour of ArcelorMittal Steel Factory in Ohio \u2014&gt; http:\/\/t.co\/HrwbPpJhpZ",
  "id" : 401377619494461440,
  "created_at" : "2013-11-15 15:54:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/401137009151836160\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/OqlQw7KaXm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZEf_AlCAAA3sjE.jpg",
      "id_str" : "401137009160224768",
      "id" : 401137009160224768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZEf_AlCAAA3sjE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/OqlQw7KaXm"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 48, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/zRCCjh6ur9",
      "expanded_url" : "http:\/\/go.wh.gov\/QoPej1",
      "display_url" : "go.wh.gov\/QoPej1"
    } ]
  },
  "geo" : { },
  "id_str" : "401137009151836160",
  "text" : "RT if you agree: It's time to focus on building #ABetterBargain for the middle class \u2014&gt; http:\/\/t.co\/zRCCjh6ur9, http:\/\/t.co\/OqlQw7KaXm",
  "id" : 401137009151836160,
  "created_at" : "2013-11-14 23:58:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 128, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/upvFzfwm6g",
      "expanded_url" : "http:\/\/go.wh.gov\/bQguKb",
      "display_url" : "go.wh.gov\/bQguKb"
    } ]
  },
  "geo" : { },
  "id_str" : "401114047635943424",
  "text" : "Big news: We're now importing less oil than we're producing for the 1st time in nearly two decades \u2014&gt; http:\/\/t.co\/upvFzfwm6g #ActOnClimate",
  "id" : 401114047635943424,
  "created_at" : "2013-11-14 22:26:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 7, 17 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 33, 44 ]
    }, {
      "text" : "ThrowbackThursday",
      "indices" : [ 117, 135 ]
    }, {
      "text" : "TBT",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/mcovrQ4Qb9",
      "expanded_url" : "http:\/\/go.wh.gov\/ETR9N5",
      "display_url" : "go.wh.gov\/ETR9N5"
    } ]
  },
  "geo" : { },
  "id_str" : "401103953565208576",
  "text" : "Before #Obamacare, Gail couldn't #GetCovered because her cancer was a pre-existing condition: http:\/\/t.co\/mcovrQ4Qb9 #ThrowbackThursday #TBT",
  "id" : 401103953565208576,
  "created_at" : "2013-11-14 21:46:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401092349607960577",
  "text" : "Obama: \"If every governor followed [Ohio's] lead\u2014rather than play politics\u2014another 5.4 million Americans could get access to health care.\"",
  "id" : 401092349607960577,
  "created_at" : "2013-11-14 21:00:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401092037727883264",
  "text" : "RT @WHLive: Obama: \"We\u2019re going to fix what needs to be fixed. The Affordable Care Act is going to work.\" #Obamacare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 94, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401091911697444865",
    "text" : "Obama: \"We\u2019re going to fix what needs to be fixed. The Affordable Care Act is going to work.\" #Obamacare",
    "id" : 401091911697444865,
    "created_at" : "2013-11-14 20:58:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 401092037727883264,
  "created_at" : "2013-11-14 20:59:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401091495014318080",
  "text" : "RT @WHLive: Obama: \"We should be doing everything we can to make sure every American has access to quality, affordable health care.\" #Obama\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 121, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401091294878912512",
    "text" : "Obama: \"We should be doing everything we can to make sure every American has access to quality, affordable health care.\" #Obamacare",
    "id" : 401091294878912512,
    "created_at" : "2013-11-14 20:56:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 401091495014318080,
  "created_at" : "2013-11-14 20:57:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 116, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401089875190894592",
  "text" : "Obama: \"That\u2019s what these tough decisions are all about: Reversing the forces that have battered the middle class.\" #ABetterBargain",
  "id" : 401089875190894592,
  "created_at" : "2013-11-14 20:50:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401089134313238528",
  "text" : "Obama: \"We set new fuel standards that will double the distance our cars and trucks go on a gallon of gas.\" #ActOnClimate",
  "id" : 401089134313238528,
  "created_at" : "2013-11-14 20:47:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401088914200346624",
  "text" : "Obama: \"For the 1st time in nearly 2 decades...America produces more of our own oil here at home than we buy from other countries.\"",
  "id" : 401088914200346624,
  "created_at" : "2013-11-14 20:47:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/401088625707741184\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/SdwfX1fFpL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZDz-tjCQAAxCME.jpg",
      "id_str" : "401088625539956736",
      "id" : 401088625539956736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZDz-tjCQAAxCME.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/SdwfX1fFpL"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401088625707741184",
  "text" : "Obama: \"We invested in new American technologies to reverse our addiction to foreign oil.\" #ActOnClimate, http:\/\/t.co\/SdwfX1fFpL",
  "id" : 401088625707741184,
  "created_at" : "2013-11-14 20:45:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/401088235968819200\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/eFCTXBFwFY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZDzoBpCQAAGsRj.jpg",
      "id_str" : "401088235796840448",
      "id" : 401088235796840448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZDzoBpCQAAGsRj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/eFCTXBFwFY"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401088235968819200",
  "text" : "President Obama: \"Over the last 44 months, our businesses have created 7.8 million new jobs.\" #ABetterBargain, http:\/\/t.co\/eFCTXBFwFY",
  "id" : 401088235968819200,
  "created_at" : "2013-11-14 20:44:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401087564443959297",
  "text" : "RT @WHLive: President Obama at Arcelor Mittal: \"Folks are proud to have been making steel right here for 100 years.\" #MadeInAmerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 105, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401087507187499008",
    "text" : "President Obama at Arcelor Mittal: \"Folks are proud to have been making steel right here for 100 years.\" #MadeInAmerica",
    "id" : 401087507187499008,
    "created_at" : "2013-11-14 20:41:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 401087564443959297,
  "created_at" : "2013-11-14 20:41:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401086955837861888",
  "text" : "RT @WHLive: \"It\u2019s nice to be here when the only real battle for Ohio is the Browns-Bengals game this Sunday.\" \u2014President Obama in Cleveland",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401086928394547200",
    "text" : "\"It\u2019s nice to be here when the only real battle for Ohio is the Browns-Bengals game this Sunday.\" \u2014President Obama in Cleveland",
    "id" : 401086928394547200,
    "created_at" : "2013-11-14 20:39:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 401086955837861888,
  "created_at" : "2013-11-14 20:39:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 93, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/jeDdGDHq2C",
      "expanded_url" : "http:\/\/go.wh.gov\/CWLHdL",
      "display_url" : "go.wh.gov\/CWLHdL"
    } ]
  },
  "geo" : { },
  "id_str" : "401086633878888448",
  "text" : "Right now: President Obama speaks in Ohio on the economy. Watch \u2014&gt; http:\/\/t.co\/jeDdGDHq2C #ABetterBargain",
  "id" : 401086633878888448,
  "created_at" : "2013-11-14 20:38:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 20, 35 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401084650325819392",
  "text" : "RT @PressSec: Today @speakerboehner said he wants to \"protect\" Americans by taking away their benefits &amp; giving insurers the right to deny \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 6, 21 ],
        "id_str" : "7713202",
        "id" : 7713202
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401080490045607937",
    "text" : "Today @speakerboehner said he wants to \"protect\" Americans by taking away their benefits &amp; giving insurers the right to deny them coverage.",
    "id" : 401080490045607937,
    "created_at" : "2013-11-14 20:13:35 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 401084650325819392,
  "created_at" : "2013-11-14 20:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/2M7X7KNrqm",
      "expanded_url" : "http:\/\/go.wh.gov\/SSUaEX",
      "display_url" : "go.wh.gov\/SSUaEX"
    } ]
  },
  "geo" : { },
  "id_str" : "401076074534014976",
  "text" : "FACT: Under President Obama, we've cut our dependence on foreign oil to a 17-year low \u2014&gt; http:\/\/t.co\/2M7X7KNrqm #ActOnClimate",
  "id" : 401076074534014976,
  "created_at" : "2013-11-14 19:56:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/401065846556352514\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/M30ewhgKqi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZDfQyvIcAAplgU.jpg",
      "id_str" : "401065846426333184",
      "id" : 401065846426333184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZDfQyvIcAAplgU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/M30ewhgKqi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401065846556352514",
  "text" : "RT the good news: For the 1st time in nearly two decades, we're importing less oil than we're producing. http:\/\/t.co\/M30ewhgKqi",
  "id" : 401065846556352514,
  "created_at" : "2013-11-14 19:15:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Haiyan",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/6Ornnl5L8w",
      "expanded_url" : "http:\/\/wh.gov\/typhoon",
      "display_url" : "wh.gov\/typhoon"
    }, {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/rjxR4Bly8i",
      "expanded_url" : "http:\/\/go.wh.gov\/h72ECq",
      "display_url" : "go.wh.gov\/h72ECq"
    } ]
  },
  "geo" : { },
  "id_str" : "401059453073510400",
  "text" : "\"When our friends are in trouble, America helps.\" \u2014Obama on helping victims of #Haiyan: http:\/\/t.co\/6Ornnl5L8w, http:\/\/t.co\/rjxR4Bly8i",
  "id" : 401059453073510400,
  "created_at" : "2013-11-14 18:49:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401055492992409600",
  "text" : "RT @SenatorReid: As Janet Yellen showed today, she is eminently qualified to be Fed Chair. Her nomination deserves speedy confirmation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401051601705902081",
    "text" : "As Janet Yellen showed today, she is eminently qualified to be Fed Chair. Her nomination deserves speedy confirmation.",
    "id" : 401051601705902081,
    "created_at" : "2013-11-14 18:18:47 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 401055492992409600,
  "created_at" : "2013-11-14 18:34:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401042007113474049",
  "text" : "Today's announcement by the President will give consumers more information and choices\u2014including keeping their old plans in 2014. #Obamacare",
  "id" : 401042007113474049,
  "created_at" : "2013-11-14 17:40:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401038667503767552",
  "text" : "President Obama just announced that insurers can offer consumers the option to renew their 2013 health plans without changes. #Obamacare",
  "id" : 401038667503767552,
  "created_at" : "2013-11-14 17:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401035839561424896",
  "text" : "Obama: \"We are going to solve those problems. We are going to get this right. And the Affordable Care Act is going to work.\" #Obamacare",
  "id" : 401035839561424896,
  "created_at" : "2013-11-14 17:16:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401035587089469440",
  "text" : "Obama: \"We're in the opening weeks of the project to build a better health care system...that will offer real financial security\" #Obamacare",
  "id" : 401035587089469440,
  "created_at" : "2013-11-14 17:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401034961366441984",
  "text" : "Obama: \"I am not going to walk away from 40 million people who have the chance to get health insurance for the first time.\" #Obamacare",
  "id" : 401034961366441984,
  "created_at" : "2013-11-14 17:12:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401034623288758272",
  "text" : "President Obama: \"Insurers can extend current plans that would otherwise be cancelled into 2014.\" #Obamacare",
  "id" : 401034623288758272,
  "created_at" : "2013-11-14 17:11:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401034286783922177",
  "text" : "President Obama on #Obamacare enrollees: \"If the website were working as well as it\u2019s supposed to be, that number would be much higher.\"",
  "id" : 401034286783922177,
  "created_at" : "2013-11-14 17:09:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 9, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401033531385585664",
  "text" : "Obama on #Obamacare: \"In the 1st month, nearly 1 million Americans successfully completed an application for themselves or their families.\"",
  "id" : 401033531385585664,
  "created_at" : "2013-11-14 17:06:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Haiyan",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/6Ornnl5L8w",
      "expanded_url" : "http:\/\/wh.gov\/typhoon",
      "display_url" : "wh.gov\/typhoon"
    } ]
  },
  "geo" : { },
  "id_str" : "401033275981832192",
  "text" : "President Obama on Typhoon #Haiyan: \"I encourage everyone who wants to help to visit http:\/\/t.co\/6Ornnl5L8w.\"",
  "id" : 401033275981832192,
  "created_at" : "2013-11-14 17:05:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Haiyan",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401032973895491584",
  "text" : "Obama: \"Our prayers are with the Filipino people and with Filipino-Americans...who are anxious for their family and friends.\" #Haiyan",
  "id" : 401032973895491584,
  "created_at" : "2013-11-14 17:04:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/QbGU2ikzSb",
      "expanded_url" : "http:\/\/go.wh.gov\/wABrLi",
      "display_url" : "go.wh.gov\/wABrLi"
    } ]
  },
  "geo" : { },
  "id_str" : "401032599486754816",
  "text" : "Right now: President Obama speaks on the Affordable Care Act. Watch \u2014&gt; http:\/\/t.co\/QbGU2ikzSb #Obamacare",
  "id" : 401032599486754816,
  "created_at" : "2013-11-14 17:03:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401027497825173504",
  "text" : "RT @CEAChair: Yesterday we learned monthly domestic crude oil production exceeded crude oil imports for the first time since Feb 95 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/401025350928314369\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/3dSi8ziXT2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BZC6bpSCMAAheLe.jpg",
        "id_str" : "401025350936702976",
        "id" : 401025350936702976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZC6bpSCMAAheLe.jpg",
        "sizes" : [ {
          "h" : 291,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 258,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 383
        } ],
        "display_url" : "pic.twitter.com\/3dSi8ziXT2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "401025350928314369",
    "text" : "Yesterday we learned monthly domestic crude oil production exceeded crude oil imports for the first time since Feb 95 http:\/\/t.co\/3dSi8ziXT2",
    "id" : 401025350928314369,
    "created_at" : "2013-11-14 16:34:29 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 401027497825173504,
  "created_at" : "2013-11-14 16:43:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 3, 15 ],
      "id_str" : "110541296",
      "id" : 110541296
    }, {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 23, 35 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/tL7eQ5ursz",
      "expanded_url" : "http:\/\/1.usa.gov\/1aVxBmf",
      "display_url" : "1.usa.gov\/1aVxBmf"
    } ]
  },
  "geo" : { },
  "id_str" : "401019389811908608",
  "text" : "RT @CommerceGov: Watch @CommerceSec Pritzker unveils her new strategic vision and top priorities at 11am ET http:\/\/t.co\/tL7eQ5ursz #OpenFor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CommerceSec",
        "screen_name" : "CommerceSec",
        "indices" : [ 6, 18 ],
        "id_str" : "2319148561",
        "id" : 2319148561
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenForBusiness",
        "indices" : [ 114, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/tL7eQ5ursz",
        "expanded_url" : "http:\/\/1.usa.gov\/1aVxBmf",
        "display_url" : "1.usa.gov\/1aVxBmf"
      } ]
    },
    "geo" : { },
    "id_str" : "401011263599554560",
    "text" : "Watch @CommerceSec Pritzker unveils her new strategic vision and top priorities at 11am ET http:\/\/t.co\/tL7eQ5ursz #OpenForBusiness",
    "id" : 401011263599554560,
    "created_at" : "2013-11-14 15:38:30 +0000",
    "user" : {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "protected" : false,
      "id_str" : "110541296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/645983513712459776\/3Q0H2IVF_normal.jpg",
      "id" : 110541296,
      "verified" : true
    }
  },
  "id" : 401019389811908608,
  "created_at" : "2013-11-14 16:10:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/QbGU2ikzSb",
      "expanded_url" : "http:\/\/go.wh.gov\/wABrLi",
      "display_url" : "go.wh.gov\/wABrLi"
    } ]
  },
  "geo" : { },
  "id_str" : "400999408474390528",
  "text" : "President Obama will speak on the Affordable Care Act at 11:35am ET. Watch here \u2014&gt; http:\/\/t.co\/QbGU2ikzSb #Obamacare",
  "id" : 400999408474390528,
  "created_at" : "2013-11-14 14:51:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/400798101403107328\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/pLISriGwFk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY_rv-FIAAAgsln.jpg",
      "id_str" : "400798101210136576",
      "id" : 400798101210136576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY_rv-FIAAAgsln.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/pLISriGwFk"
    } ],
    "hashtags" : [ {
      "text" : "Haiyan",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/MFqIOhaOqg",
      "expanded_url" : "http:\/\/go.wh.gov\/PNqPeY",
      "display_url" : "go.wh.gov\/PNqPeY"
    } ]
  },
  "geo" : { },
  "id_str" : "400798101403107328",
  "text" : "Here's how you can help those affected by Typhoon #Haiyan \u2014&gt; http:\/\/t.co\/MFqIOhaOqg, http:\/\/t.co\/pLISriGwFk",
  "id" : 400798101403107328,
  "created_at" : "2013-11-14 01:31:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TribalNations",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400785838298001408",
  "text" : "RT @Inouye44: \"As a proud adopted member of the Crow Nation, let me say kahe\u00E9 - welcome.\" POTUS at the #TribalNations Conference: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Inouye44\/status\/400784165395644416\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/hO3CAvfOa0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BY_fEzJCQAAh6jR.jpg",
        "id_str" : "400784165399838720",
        "id" : 400784165399838720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY_fEzJCQAAh6jR.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1050
        } ],
        "display_url" : "pic.twitter.com\/hO3CAvfOa0"
      } ],
      "hashtags" : [ {
        "text" : "TribalNations",
        "indices" : [ 89, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400784165395644416",
    "text" : "\"As a proud adopted member of the Crow Nation, let me say kahe\u00E9 - welcome.\" POTUS at the #TribalNations Conference: http:\/\/t.co\/hO3CAvfOa0",
    "id" : 400784165395644416,
    "created_at" : "2013-11-14 00:36:06 +0000",
    "user" : {
      "name" : "Shin Inouye",
      "screen_name" : "InouyeUSCIS",
      "protected" : false,
      "id_str" : "1702571186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667848615780446208\/1LoEXwfW_normal.jpg",
      "id" : 1702571186,
      "verified" : true
    }
  },
  "id" : 400785838298001408,
  "created_at" : "2013-11-14 00:42:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 3, 16 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400775903141060608",
  "text" : "RT @DavidAgnew44: As a dad, I'm proud the President signed a bill encouraging schools to plan for EpiPen access. This will save lives!\nhttp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/7o07iCi0EJ",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/11\/13\/president-obama-signs-new-epipen-law-protect-children-asthma-and-severe-allergies-an",
        "display_url" : "whitehouse.gov\/blog\/2013\/11\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "400767763427241984",
    "text" : "As a dad, I'm proud the President signed a bill encouraging schools to plan for EpiPen access. This will save lives!\nhttp:\/\/t.co\/7o07iCi0EJ",
    "id" : 400767763427241984,
    "created_at" : "2013-11-13 23:30:55 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 400775903141060608,
  "created_at" : "2013-11-14 00:03:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400772035661398016",
  "text" : "RT @vj44: POTUS signs new law to put EpiPens in more schools keeping children w\/ asthma &amp; allergies safe in the classroom http:\/\/t.co\/8dTcy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/400754526660997121\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/8dTcyRqJpi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BY_EHmQCMAAUUAT.jpg",
        "id_str" : "400754526665191424",
        "id" : 400754526665191424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY_EHmQCMAAUUAT.jpg",
        "sizes" : [ {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8dTcyRqJpi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400754526660997121",
    "text" : "POTUS signs new law to put EpiPens in more schools keeping children w\/ asthma &amp; allergies safe in the classroom http:\/\/t.co\/8dTcyRqJpi",
    "id" : 400754526660997121,
    "created_at" : "2013-11-13 22:38:19 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 400772035661398016,
  "created_at" : "2013-11-13 23:47:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Haiyan",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/6Ornnl5L8w",
      "expanded_url" : "http:\/\/wh.gov\/typhoon",
      "display_url" : "wh.gov\/typhoon"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/WVSbNCs3px",
      "expanded_url" : "http:\/\/go.wh.gov\/zpLcSB",
      "display_url" : "go.wh.gov\/zpLcSB"
    } ]
  },
  "geo" : { },
  "id_str" : "400762295229222912",
  "text" : "President Obama encourages Americans who want to help those affected by #Haiyan to visit http:\/\/t.co\/6Ornnl5L8w \u2014&gt; http:\/\/t.co\/WVSbNCs3px",
  "id" : 400762295229222912,
  "created_at" : "2013-11-13 23:09:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Haiyan",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/6Ornnl5L8w",
      "expanded_url" : "http:\/\/wh.gov\/typhoon",
      "display_url" : "wh.gov\/typhoon"
    } ]
  },
  "geo" : { },
  "id_str" : "400756402819301376",
  "text" : "President Obama on Typhoon #Haiyan: \"I encourage Americans who want to help our Filipino friends to visit http:\/\/t.co\/6Ornnl5L8w.\"",
  "id" : 400756402819301376,
  "created_at" : "2013-11-13 22:45:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/mn6X0sPRYJ",
      "expanded_url" : "http:\/\/on.tnr.com\/1cluFwy",
      "display_url" : "on.tnr.com\/1cluFwy"
    } ]
  },
  "geo" : { },
  "id_str" : "400754707091558400",
  "text" : "RT @jesseclee44: 500K Americans on track for coverage under #Obamacare &gt; negative 20 million covered under GOP budget http:\/\/t.co\/mn6X0sPRYJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 43, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/mn6X0sPRYJ",
        "expanded_url" : "http:\/\/on.tnr.com\/1cluFwy",
        "display_url" : "on.tnr.com\/1cluFwy"
      } ]
    },
    "geo" : { },
    "id_str" : "400744383051362304",
    "text" : "500K Americans on track for coverage under #Obamacare &gt; negative 20 million covered under GOP budget http:\/\/t.co\/mn6X0sPRYJ",
    "id" : 400744383051362304,
    "created_at" : "2013-11-13 21:58:01 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 400754707091558400,
  "created_at" : "2013-11-13 22:39:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400752598136795136",
  "text" : "FACT: When MA launched its health insurance exchange\u2014more than 20% of 1st-year enrollees waited until the last month to sign up. #Obamacare",
  "id" : 400752598136795136,
  "created_at" : "2013-11-13 22:30:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400746300800368640",
  "text" : "FACT: If the remaining 24 states expanded Medicaid, another 5.4 million Americans would become eligible for coverage through #Obamacare.",
  "id" : 400746300800368640,
  "created_at" : "2013-11-13 22:05:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400745051677941760",
  "text" : "FACT: In the 26 states that have expanded Medicaid coverage, 396,261 low-income Americans have gained health coverage for 2014. #GetCovered",
  "id" : 400745051677941760,
  "created_at" : "2013-11-13 22:00:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 66, 77 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400741600449425408",
  "text" : "FACT: Nearly 1 million Americans have applied and are eligible to #GetCovered through #Obamacare\u2014but have yet to select a plan.",
  "id" : 400741600449425408,
  "created_at" : "2013-11-13 21:46:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/400739568917303297\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/CZ6g95XLOK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY-2g7yCMAEW8fA.jpg",
      "id_str" : "400739568778883073",
      "id" : 400739568778883073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY-2g7yCMAEW8fA.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/CZ6g95XLOK"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400739568917303297",
  "text" : "Thanks to #Obamacare, more than 500,000 Americans have already signed up for health coverage. #GetCovered, http:\/\/t.co\/CZ6g95XLOK",
  "id" : 400739568917303297,
  "created_at" : "2013-11-13 21:38:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/400716389150777344\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/lBojIoaQ5Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY-hbs-CYAAds39.jpg",
      "id_str" : "400716389159165952",
      "id" : 400716389159165952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY-hbs-CYAAds39.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/lBojIoaQ5Z"
    } ],
    "hashtags" : [ {
      "text" : "InvestInKids",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400716389150777344",
  "text" : "RT if you agree: It's time to give every child access to high-quality early education. #InvestInKids, http:\/\/t.co\/lBojIoaQ5Z",
  "id" : 400716389150777344,
  "created_at" : "2013-11-13 20:06:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInKids",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400711148473163776",
  "text" : "RT @arneduncan: Huge day- bipartisan legislation being introduced to dramatically expand access to Early Learning! #InvestInKids http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/arneduncan\/status\/400700118745096192\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/kUpgES25g6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BY-Soo-CIAAJzTW.jpg",
        "id_str" : "400700118749290496",
        "id" : 400700118749290496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY-Soo-CIAAJzTW.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1936,
          "resize" : "fit",
          "w" : 1936
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kUpgES25g6"
      } ],
      "hashtags" : [ {
        "text" : "InvestInKids",
        "indices" : [ 99, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400700118745096192",
    "text" : "Huge day- bipartisan legislation being introduced to dramatically expand access to Early Learning! #InvestInKids http:\/\/t.co\/kUpgES25g6",
    "id" : 400700118745096192,
    "created_at" : "2013-11-13 19:02:07 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 400711148473163776,
  "created_at" : "2013-11-13 19:45:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 71, 82 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestinKids",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Cqc9kGgjW7",
      "expanded_url" : "http:\/\/ed.gov\/early-learning",
      "display_url" : "ed.gov\/early-learning"
    } ]
  },
  "geo" : { },
  "id_str" : "400705846579310592",
  "text" : "RT @usedgov: \"Education is not just an expense, it\u2019s an investment.\" - @ArneDuncan http:\/\/t.co\/Cqc9kGgjW7 #InvestinKids",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 58, 69 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InvestinKids",
        "indices" : [ 93, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/Cqc9kGgjW7",
        "expanded_url" : "http:\/\/ed.gov\/early-learning",
        "display_url" : "ed.gov\/early-learning"
      } ]
    },
    "geo" : { },
    "id_str" : "400638873820475392",
    "text" : "\"Education is not just an expense, it\u2019s an investment.\" - @ArneDuncan http:\/\/t.co\/Cqc9kGgjW7 #InvestinKids",
    "id" : 400638873820475392,
    "created_at" : "2013-11-13 14:58:45 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 400705846579310592,
  "created_at" : "2013-11-13 19:24:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 94, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/Sfp9EKRcFe",
      "expanded_url" : "http:\/\/go.wh.gov\/FFafeu",
      "display_url" : "go.wh.gov\/FFafeu"
    } ]
  },
  "geo" : { },
  "id_str" : "400699760010473472",
  "text" : "President Obama met with faith leaders in the Oval Office this morning on passing commonsense #ImmigrationReform \u2014&gt; http:\/\/t.co\/Sfp9EKRcFe",
  "id" : 400699760010473472,
  "created_at" : "2013-11-13 19:00:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 38, 41 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/400692657057316864\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/V0ff0vsCxL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY-L2UCCQAAF1mH.jpg",
      "id_str" : "400692657065705472",
      "id" : 400692657065705472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY-L2UCCQAAF1mH.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/V0ff0vsCxL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/MphQA1pF3T",
      "expanded_url" : "http:\/\/go.wh.gov\/hC7Kpz",
      "display_url" : "go.wh.gov\/hC7Kpz"
    } ]
  },
  "geo" : { },
  "id_str" : "400692657057316864",
  "text" : "Get the latest on President Obama and @VP Biden's meeting with senior military leaders \u2014&gt; http:\/\/t.co\/MphQA1pF3T, http:\/\/t.co\/V0ff0vsCxL",
  "id" : 400692657057316864,
  "created_at" : "2013-11-13 18:32:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 31, 50 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/b5MOA9skgP",
      "expanded_url" : "http:\/\/go.wh.gov\/VYjPXq",
      "display_url" : "go.wh.gov\/VYjPXq"
    } ]
  },
  "geo" : { },
  "id_str" : "400687029576413184",
  "text" : "FACT: If the Louisiana GOP put #PeopleOverPolitics, 265,000 more people could get health coverage through #Obamacare: http:\/\/t.co\/b5MOA9skgP",
  "id" : 400687029576413184,
  "created_at" : "2013-11-13 18:10:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "PeopleOverPolitics",
      "indices" : [ 113, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400674579279904769",
  "text" : "The NC GOP is preventing nearly 400,000 people from getting health coverage through #Obamacare. It's time to put #PeopleOverPolitics.",
  "id" : 400674579279904769,
  "created_at" : "2013-11-13 17:20:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 86, 96 ]
    }, {
      "text" : "PeopleOverPolitics",
      "indices" : [ 121, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/NEBbH0VxWW",
      "expanded_url" : "http:\/\/go.wh.gov\/F4M6pN",
      "display_url" : "go.wh.gov\/F4M6pN"
    } ]
  },
  "geo" : { },
  "id_str" : "400668285756129280",
  "text" : "The FL GOP is preventing nearly 1 million people from getting health coverage through #Obamacare: http:\/\/t.co\/NEBbH0VxWW #PeopleOverPolitics",
  "id" : 400668285756129280,
  "created_at" : "2013-11-13 16:55:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 27, 46 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400661642410614784",
  "text" : "FACT: If the Texas GOP put #PeopleOverPolitics and expanded Medicaid, 1.2 million more Texans would have health insurance. #Obamacare",
  "id" : 400661642410614784,
  "created_at" : "2013-11-13 16:29:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/400652132631584768\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/LXA9e1xbuM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY9m_eyCIAArfaP.jpg",
      "id_str" : "400652132639973376",
      "id" : 400652132639973376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY9m_eyCIAArfaP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/LXA9e1xbuM"
    } ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 50, 69 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400652132631584768",
  "text" : "RT if you agree: It's time for every state to put #PeopleOverPolitics and help 5.4 million Americans #GetCovered. http:\/\/t.co\/LXA9e1xbuM",
  "id" : 400652132631584768,
  "created_at" : "2013-11-13 15:51:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ 95, 103 ],
      "id_str" : "1652541",
      "id" : 1652541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/rNZ7dMi2of",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/O14Jj6E6Ny",
      "expanded_url" : "http:\/\/reut.rs\/1gJD0PK",
      "display_url" : "reut.rs\/1gJD0PK"
    } ]
  },
  "geo" : { },
  "id_str" : "400646400012066816",
  "text" : "RT @Schultz44: White House tech chief says 'making progress' fixing http:\/\/t.co\/rNZ7dMi2of via @Reuters - http:\/\/t.co\/O14Jj6E6Ny",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reuters Top News",
        "screen_name" : "Reuters",
        "indices" : [ 80, 88 ],
        "id_str" : "1652541",
        "id" : 1652541
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/rNZ7dMi2of",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      }, {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/O14Jj6E6Ny",
        "expanded_url" : "http:\/\/reut.rs\/1gJD0PK",
        "display_url" : "reut.rs\/1gJD0PK"
      } ]
    },
    "geo" : { },
    "id_str" : "400633248042479616",
    "text" : "White House tech chief says 'making progress' fixing http:\/\/t.co\/rNZ7dMi2of via @Reuters - http:\/\/t.co\/O14Jj6E6Ny",
    "id" : 400633248042479616,
    "created_at" : "2013-11-13 14:36:24 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 400646400012066816,
  "created_at" : "2013-11-13 15:28:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/400443039405318144\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/PcUvnfwjOd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY6o0pVIMAAIfzD.jpg",
      "id_str" : "400443039283687424",
      "id" : 400443039283687424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY6o0pVIMAAIfzD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/PcUvnfwjOd"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 83, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/9K1eLFcYn4",
      "expanded_url" : "http:\/\/go.wh.gov\/w1yy6b",
      "display_url" : "go.wh.gov\/w1yy6b"
    } ]
  },
  "geo" : { },
  "id_str" : "400443039405318144",
  "text" : "Here's a quick update on the economy, in three charts \u2014&gt; http:\/\/t.co\/9K1eLFcYn4 #ABetterBargain, http:\/\/t.co\/PcUvnfwjOd",
  "id" : 400443039405318144,
  "created_at" : "2013-11-13 02:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarriageEquality",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400434309523177472",
  "text" : "\"Our gay and lesbian brothers and sisters should be treated fairly and equally under the law.\" \u2014Obama on Hawaii passing #MarriageEquality",
  "id" : 400434309523177472,
  "created_at" : "2013-11-13 01:25:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarriageEquality",
      "indices" : [ 125, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/fb616gcHw8",
      "expanded_url" : "http:\/\/go.wh.gov\/WaYd9m",
      "display_url" : "go.wh.gov\/WaYd9m"
    } ]
  },
  "geo" : { },
  "id_str" : "400409590149312514",
  "text" : "Obama: \"I\u2019ve always been proud to have been born in Hawaii &amp; today\u2019s vote makes me even prouder.\" http:\/\/t.co\/fb616gcHw8 #MarriageEquality",
  "id" : 400409590149312514,
  "created_at" : "2013-11-12 23:47:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3HhWJT2vtS",
      "expanded_url" : "http:\/\/go.wh.gov\/zAWQYi",
      "display_url" : "go.wh.gov\/zAWQYi"
    } ]
  },
  "geo" : { },
  "id_str" : "400393975451754496",
  "text" : "Obama: \"They raise their hands. They take that oath. They put on the uniform, and they put their lives on the line.\" http:\/\/t.co\/3HhWJT2vtS",
  "id" : 400393975451754496,
  "created_at" : "2013-11-12 22:45:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 3, 11 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 14, 21 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 26, 37 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/KTtneqhAHo",
      "expanded_url" : "http:\/\/nyti.ms\/17QrIXb",
      "display_url" : "nyti.ms\/17QrIXb"
    } ]
  },
  "geo" : { },
  "id_str" : "400384703250698240",
  "text" : "RT @Cabinet: .@FLOTUS and @arneduncan working together to ensure ALL kids have a shot at higher ed --&gt; http:\/\/t.co\/KTtneqhAHo , http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 1, 8 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 13, 24 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cabinet\/status\/400383754570461184\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/93uWV9Qf5k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BY5y50mCcAAi0sD.jpg",
        "id_str" : "400383754578849792",
        "id" : 400383754578849792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY5y50mCcAAi0sD.jpg",
        "sizes" : [ {
          "h" : 565,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 565,
          "resize" : "fit",
          "w" : 850
        } ],
        "display_url" : "pic.twitter.com\/93uWV9Qf5k"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/KTtneqhAHo",
        "expanded_url" : "http:\/\/nyti.ms\/17QrIXb",
        "display_url" : "nyti.ms\/17QrIXb"
      } ]
    },
    "geo" : { },
    "id_str" : "400383754570461184",
    "text" : ".@FLOTUS and @arneduncan working together to ensure ALL kids have a shot at higher ed --&gt; http:\/\/t.co\/KTtneqhAHo , http:\/\/t.co\/93uWV9Qf5k",
    "id" : 400383754570461184,
    "created_at" : "2013-11-12 22:05:00 +0000",
    "user" : {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "protected" : false,
      "id_str" : "1854981890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000444833438\/6f96900dcf05562d4e699ae28d7861c6_normal.jpeg",
      "id" : 1854981890,
      "verified" : true
    }
  },
  "id" : 400384703250698240,
  "created_at" : "2013-11-12 22:08:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Haiyan",
      "indices" : [ 137, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/uBICXq17KB",
      "expanded_url" : "http:\/\/go.wh.gov\/qTxeAV",
      "display_url" : "go.wh.gov\/qTxeAV"
    } ]
  },
  "geo" : { },
  "id_str" : "400376878042607616",
  "text" : "President Obama spoke with Filipino President Aquino to express deep condolences &amp; coordinate relief efforts: http:\/\/t.co\/uBICXq17KB #Haiyan",
  "id" : 400376878042607616,
  "created_at" : "2013-11-12 21:37:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400362656638709760",
  "text" : "RT @WHLive: President Obama: Financial reform is \"about making sure that everyone plays by the same set of clear and transparent rules.\" #A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ABetterBargain",
        "indices" : [ 125, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400362571158405122",
    "text" : "President Obama: Financial reform is \"about making sure that everyone plays by the same set of clear and transparent rules.\" #ABetterBargain",
    "id" : 400362571158405122,
    "created_at" : "2013-11-12 20:40:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 400362656638709760,
  "created_at" : "2013-11-12 20:41:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "CFTC",
      "screen_name" : "CFTC",
      "indices" : [ 106, 111 ],
      "id_str" : "234044087",
      "id" : 234044087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400360046564876289",
  "text" : "RT @WHLive: Right now: President Obama announces his intent to nominate Timothy Massad as Chairman of the @CFTC. Watch \u2014&gt; http:\/\/t.co\/BbWFY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CFTC",
        "screen_name" : "CFTC",
        "indices" : [ 94, 99 ],
        "id_str" : "234044087",
        "id" : 234044087
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/BbWFYxgdvO",
        "expanded_url" : "http:\/\/go.wh.gov\/e46b5w",
        "display_url" : "go.wh.gov\/e46b5w"
      } ]
    },
    "geo" : { },
    "id_str" : "400359936053370880",
    "text" : "Right now: President Obama announces his intent to nominate Timothy Massad as Chairman of the @CFTC. Watch \u2014&gt; http:\/\/t.co\/BbWFYxgdvO",
    "id" : 400359936053370880,
    "created_at" : "2013-11-12 20:30:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 400360046564876289,
  "created_at" : "2013-11-12 20:30:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "CFTC",
      "screen_name" : "CFTC",
      "indices" : [ 109, 114 ],
      "id_str" : "234044087",
      "id" : 234044087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400355995710259200",
  "text" : "RT @WHLive: At 3:20pm ET, President Obama announces his intent to nominate Timothy Massad as Chairman of the @CFTC. Watch \u2014&gt; http:\/\/t.co\/Bb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CFTC",
        "screen_name" : "CFTC",
        "indices" : [ 97, 102 ],
        "id_str" : "234044087",
        "id" : 234044087
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/BbWFYxgdvO",
        "expanded_url" : "http:\/\/go.wh.gov\/e46b5w",
        "display_url" : "go.wh.gov\/e46b5w"
      } ]
    },
    "geo" : { },
    "id_str" : "400355794660503553",
    "text" : "At 3:20pm ET, President Obama announces his intent to nominate Timothy Massad as Chairman of the @CFTC. Watch \u2014&gt; http:\/\/t.co\/BbWFYxgdvO",
    "id" : 400355794660503553,
    "created_at" : "2013-11-12 20:13:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 400355995710259200,
  "created_at" : "2013-11-12 20:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/kKv4yHL1H8",
      "expanded_url" : "http:\/\/go.wh.gov\/BZPnDe",
      "display_url" : "go.wh.gov\/BZPnDe"
    } ]
  },
  "geo" : { },
  "id_str" : "400352453192736768",
  "text" : "Every day should be a day we honor our veterans and serve them as well as they've served us \u2014&gt; http:\/\/t.co\/kKv4yHL1H8 #HonoringVets",
  "id" : 400352453192736768,
  "created_at" : "2013-11-12 20:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wethegeeks",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/vmmo6g2FF9",
      "expanded_url" : "http:\/\/wh.gov\/wethegeeks",
      "display_url" : "wh.gov\/wethegeeks"
    } ]
  },
  "geo" : { },
  "id_str" : "400350032299163649",
  "text" : "RT @whitehouseostp: Update: today's #wethegeeks will be rescheduled soon! For updates and past hangouts visit: http:\/\/t.co\/vmmo6g2FF9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wethegeeks",
        "indices" : [ 16, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/vmmo6g2FF9",
        "expanded_url" : "http:\/\/wh.gov\/wethegeeks",
        "display_url" : "wh.gov\/wethegeeks"
      } ]
    },
    "geo" : { },
    "id_str" : "400349844176265216",
    "text" : "Update: today's #wethegeeks will be rescheduled soon! For updates and past hangouts visit: http:\/\/t.co\/vmmo6g2FF9",
    "id" : 400349844176265216,
    "created_at" : "2013-11-12 19:50:15 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 400350032299163649,
  "created_at" : "2013-11-12 19:51:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "indices" : [ 3, 13 ],
      "id_str" : "1712989040",
      "id" : 1712989040
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 41, 44 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NY",
      "indices" : [ 99, 102 ]
    }, {
      "text" : "PR",
      "indices" : [ 104, 107 ]
    }, {
      "text" : "AR",
      "indices" : [ 109, 112 ]
    }, {
      "text" : "AL",
      "indices" : [ 114, 117 ]
    }, {
      "text" : "VA",
      "indices" : [ 124, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400325339282690048",
  "text" : "RT @Rosholm44: HAPPENING NOW: Pres &amp; @VP having lunch w\/ 5 active duty service members -- from #NY, #PR, #AR, #AL &amp; #VA -- to thank them fo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 26, 29 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NY",
        "indices" : [ 84, 87 ]
      }, {
        "text" : "PR",
        "indices" : [ 89, 92 ]
      }, {
        "text" : "AR",
        "indices" : [ 94, 97 ]
      }, {
        "text" : "AL",
        "indices" : [ 99, 102 ]
      }, {
        "text" : "VA",
        "indices" : [ 109, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400324327729410048",
    "text" : "HAPPENING NOW: Pres &amp; @VP having lunch w\/ 5 active duty service members -- from #NY, #PR, #AR, #AL &amp; #VA -- to thank them for their service.",
    "id" : 400324327729410048,
    "created_at" : "2013-11-12 18:08:52 +0000",
    "user" : {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "protected" : false,
      "id_str" : "1712989040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755544708483538944\/h-5gKL6u_normal.jpg",
      "id" : 1712989040,
      "verified" : true
    }
  },
  "id" : 400325339282690048,
  "created_at" : "2013-11-12 18:12:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 19, 30 ]
    }, {
      "text" : "DontBeBoredMakeSomething",
      "indices" : [ 111, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/8vm0uUhTFv",
      "expanded_url" : "http:\/\/go.wh.gov\/y4upfE",
      "display_url" : "go.wh.gov\/y4upfE"
    } ]
  },
  "geo" : { },
  "id_str" : "400318422715617280",
  "text" : "Don't miss today's #WeTheGeeks hangout on the next generation of makers at 2pm ET \u2014&gt; http:\/\/t.co\/8vm0uUhTFv #DontBeBoredMakeSomething",
  "id" : 400318422715617280,
  "created_at" : "2013-11-12 17:45:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Acadia National Park",
      "screen_name" : "AcadiaNPS",
      "indices" : [ 82, 92 ],
      "id_str" : "185874758",
      "id" : 185874758
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/400301874831949824\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/3sWQkstCrK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY4obyAIUAAh2cg.jpg",
      "id_str" : "400301874626449408",
      "id" : 400301874626449408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY4obyAIUAAh2cg.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3sWQkstCrK"
    } ],
    "hashtags" : [ {
      "text" : "autumn",
      "indices" : [ 22, 29 ]
    }, {
      "text" : "Maine",
      "indices" : [ 111, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400305587864731648",
  "text" : "RT @Interior: Vibrant #autumn view from Champlain Mountain on a sunny October day @AcadiaNPS by Fiana Shapiro. #Maine http:\/\/t.co\/3sWQkstCrK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Acadia National Park",
        "screen_name" : "AcadiaNPS",
        "indices" : [ 68, 78 ],
        "id_str" : "185874758",
        "id" : 185874758
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/400301874831949824\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/3sWQkstCrK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BY4obyAIUAAh2cg.jpg",
        "id_str" : "400301874626449408",
        "id" : 400301874626449408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY4obyAIUAAh2cg.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3sWQkstCrK"
      } ],
      "hashtags" : [ {
        "text" : "autumn",
        "indices" : [ 8, 15 ]
      }, {
        "text" : "Maine",
        "indices" : [ 97, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "400301874831949824",
    "text" : "Vibrant #autumn view from Champlain Mountain on a sunny October day @AcadiaNPS by Fiana Shapiro. #Maine http:\/\/t.co\/3sWQkstCrK",
    "id" : 400301874831949824,
    "created_at" : "2013-11-12 16:39:38 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 400305587864731648,
  "created_at" : "2013-11-12 16:54:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/400289246726340609\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/iyiQfMYoKD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY4c8u0IIAAfAMT.jpg",
      "id_str" : "400289246566948864",
      "id" : 400289246566948864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY4c8u0IIAAfAMT.jpg",
      "sizes" : [ {
        "h" : 715,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 697,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iyiQfMYoKD"
    } ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400289246726340609",
  "text" : "President Obama greets 107-year-old Richard Overton\u2014the oldest living World War II vet. #HonoringVets, http:\/\/t.co\/iyiQfMYoKD",
  "id" : 400289246726340609,
  "created_at" : "2013-11-12 15:49:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Haiyan",
      "indices" : [ 52, 59 ]
    }, {
      "text" : "Philippines",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/EsWld1fJZl",
      "expanded_url" : "http:\/\/ow.ly\/qJy4N",
      "display_url" : "ow.ly\/qJy4N"
    } ]
  },
  "geo" : { },
  "id_str" : "400271519890571264",
  "text" : "RT @USAID: How can you help during the aftermath of #Haiyan in the #Philippines? Learn how: http:\/\/t.co\/EsWld1fJZl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Haiyan",
        "indices" : [ 41, 48 ]
      }, {
        "text" : "Philippines",
        "indices" : [ 56, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/EsWld1fJZl",
        "expanded_url" : "http:\/\/ow.ly\/qJy4N",
        "display_url" : "ow.ly\/qJy4N"
      } ]
    },
    "geo" : { },
    "id_str" : "400249380969926656",
    "text" : "How can you help during the aftermath of #Haiyan in the #Philippines? Learn how: http:\/\/t.co\/EsWld1fJZl",
    "id" : 400249380969926656,
    "created_at" : "2013-11-12 13:11:03 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 400271519890571264,
  "created_at" : "2013-11-12 14:39:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400086992756936704",
  "text" : "RT @jesseclee44: My parents were both self-employed &amp; insurance was unrealistic for us--good NPR Q\/A on #Obamacare &amp; folks like them  \nhttp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 91, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 126, 148 ],
        "url" : "http:\/\/t.co\/KDwOKyln6g",
        "expanded_url" : "http:\/\/www.npr.org\/blogs\/health\/2013\/11\/11\/243987330\/self-employed-and-with-lots-of-questions-about-health-care",
        "display_url" : "npr.org\/blogs\/health\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "399941816038203392",
    "text" : "My parents were both self-employed &amp; insurance was unrealistic for us--good NPR Q\/A on #Obamacare &amp; folks like them  \nhttp:\/\/t.co\/KDwOKyln6g",
    "id" : 399941816038203392,
    "created_at" : "2013-11-11 16:48:54 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 400086992756936704,
  "created_at" : "2013-11-12 02:25:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "The mGive Foundation",
      "screen_name" : "mGiveFoundation",
      "indices" : [ 74, 90 ],
      "id_str" : "105166828",
      "id" : 105166828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Philippines",
      "indices" : [ 91, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399967663981875200",
  "text" : "RT @StateDept: To help from US, text AID to 80108 to give $10 donation to @mGiveFoundation #Philippines Typhoon Disaster Relief Fund http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The mGive Foundation",
        "screen_name" : "mGiveFoundation",
        "indices" : [ 59, 75 ],
        "id_str" : "105166828",
        "id" : 105166828
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Philippines",
        "indices" : [ 76, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/u4ZHYl9Obx",
        "expanded_url" : "http:\/\/go.usa.gov\/WXtB",
        "display_url" : "go.usa.gov\/WXtB"
      } ]
    },
    "geo" : { },
    "id_str" : "399963682228023296",
    "text" : "To help from US, text AID to 80108 to give $10 donation to @mGiveFoundation #Philippines Typhoon Disaster Relief Fund http:\/\/t.co\/u4ZHYl9Obx",
    "id" : 399963682228023296,
    "created_at" : "2013-11-11 18:15:47 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 399967663981875200,
  "created_at" : "2013-11-11 18:31:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399963473188491265",
  "text" : "RT @FLOTUS: \"We\u2019re not going to stop until every veteran and military spouse who wants a job has one.\" \u2014FLOTUS on #HonoringVets: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HonoringVets",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Z1lUZRN399",
        "expanded_url" : "http:\/\/go.wh.gov\/2BQogw",
        "display_url" : "go.wh.gov\/2BQogw"
      } ]
    },
    "geo" : { },
    "id_str" : "399956851652956160",
    "text" : "\"We\u2019re not going to stop until every veteran and military spouse who wants a job has one.\" \u2014FLOTUS on #HonoringVets: http:\/\/t.co\/Z1lUZRN399",
    "id" : 399956851652956160,
    "created_at" : "2013-11-11 17:48:38 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 399963473188491265,
  "created_at" : "2013-11-11 18:14:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 111, 124 ]
    }, {
      "text" : "VeteransDay",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/qdk8N0ygW3",
      "expanded_url" : "http:\/\/go.wh.gov\/7DX9zq",
      "display_url" : "go.wh.gov\/7DX9zq"
    } ]
  },
  "geo" : { },
  "id_str" : "399958029644222464",
  "text" : "RT @JoiningForces: RT to spread the word: Here are 5 ways you can thank a veteran \u2014&gt; http:\/\/t.co\/qdk8N0ygW3 #HonoringVets #VeteransDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HonoringVets",
        "indices" : [ 92, 105 ]
      }, {
        "text" : "VeteransDay",
        "indices" : [ 106, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/qdk8N0ygW3",
        "expanded_url" : "http:\/\/go.wh.gov\/7DX9zq",
        "display_url" : "go.wh.gov\/7DX9zq"
      } ]
    },
    "geo" : { },
    "id_str" : "399957803453796353",
    "text" : "RT to spread the word: Here are 5 ways you can thank a veteran \u2014&gt; http:\/\/t.co\/qdk8N0ygW3 #HonoringVets #VeteransDay",
    "id" : 399957803453796353,
    "created_at" : "2013-11-11 17:52:25 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 399958029644222464,
  "created_at" : "2013-11-11 17:53:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/DVabGxI7JJ",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/thomas-e-perez\/honoring-veterans-by-hiri_b_4243020.html",
      "display_url" : "huffingtonpost.com\/thomas-e-perez\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399955449648545792",
  "text" : "RT @LaborSec: Today, we honor veterans. And the best way to honor a veteran is to hire one.  http:\/\/t.co\/DVabGxI7JJ #HonoringVets",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HonoringVets",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/DVabGxI7JJ",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/thomas-e-perez\/honoring-veterans-by-hiri_b_4243020.html",
        "display_url" : "huffingtonpost.com\/thomas-e-perez\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "399910965598486528",
    "text" : "Today, we honor veterans. And the best way to honor a veteran is to hire one.  http:\/\/t.co\/DVabGxI7JJ #HonoringVets",
    "id" : 399910965598486528,
    "created_at" : "2013-11-11 14:46:18 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 399955449648545792,
  "created_at" : "2013-11-11 17:43:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 70, 81 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399950237092937729",
  "text" : "RT @vj44: Just had the incredible opportunity to meet Richard Overton @WhiteHouse\u2014Oldest known living WWII vet at 107yrs old! http:\/\/t.co\/l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 60, 71 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/lslO75Czkb",
        "expanded_url" : "http:\/\/ow.ly\/qHArs",
        "display_url" : "ow.ly\/qHArs"
      } ]
    },
    "geo" : { },
    "id_str" : "399942131080372224",
    "text" : "Just had the incredible opportunity to meet Richard Overton @WhiteHouse\u2014Oldest known living WWII vet at 107yrs old! http:\/\/t.co\/lslO75Czkb",
    "id" : 399942131080372224,
    "created_at" : "2013-11-11 16:50:09 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 399950237092937729,
  "created_at" : "2013-11-11 17:22:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399942080828416000",
  "text" : "President Obama: \"Our message to all those who have ever worn the uniform of this nation is this: We will stand by your side.\" #HonoringVets",
  "id" : 399942080828416000,
  "created_at" : "2013-11-11 16:49:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399940913322930176",
  "text" : "Obama: \"We\u2019re going to keep fighting to give every veteran who has fought for America the chance to pursue the American Dream\" #HonoringVets",
  "id" : 399940913322930176,
  "created_at" : "2013-11-11 16:45:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 130, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399940664516812800",
  "text" : "Obama: \"We\u2019re going to keep helping our newest veterans &amp; their families pursue their education under the Post-9\/11 GI Bill.\" #HonoringVets",
  "id" : 399940664516812800,
  "created_at" : "2013-11-11 16:44:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399940472468037632",
  "text" : "Obama: \"When we talk about fulfilling our promises to our veterans, we don\u2019t just mean for a few years. We mean now, tomorrow, and forever.\"",
  "id" : 399940472468037632,
  "created_at" : "2013-11-11 16:43:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399940188975026176",
  "text" : "President Obama: \"We are here today to pledge that we will never forget the profound sacrifices that are made in our name.\" #HonoringVets",
  "id" : 399940188975026176,
  "created_at" : "2013-11-11 16:42:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399940060654477312",
  "text" : "President Obama: \"Next year, the transition to Afghan-led security will be nearly complete. The longest war in American history will end.\"",
  "id" : 399940060654477312,
  "created_at" : "2013-11-11 16:41:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399939782702161920",
  "text" : "Obama: \"Because of their heroic service, the core of al Qaeda is on the path to defeat, our nation is more secure &amp; our homeland is safer.\"",
  "id" : 399939782702161920,
  "created_at" : "2013-11-11 16:40:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399939437846487041",
  "text" : "RT @WHLive: \"They fought on the fields of Gettysburg so that we could make whole a nation torn asunder.\" \u2014President Obama #HonoringVets",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HonoringVets",
        "indices" : [ 110, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399939376467042304",
    "text" : "\"They fought on the fields of Gettysburg so that we could make whole a nation torn asunder.\" \u2014President Obama #HonoringVets",
    "id" : 399939376467042304,
    "created_at" : "2013-11-11 16:39:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 399939437846487041,
  "created_at" : "2013-11-11 16:39:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399939403738398720",
  "text" : "RT @WHLive: President Obama: \"They fought on a green at Lexington so that we could make independent the country they imagined.\" #HonoringVe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HonoringVets",
        "indices" : [ 116, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399939276684529664",
    "text" : "President Obama: \"They fought on a green at Lexington so that we could make independent the country they imagined.\" #HonoringVets",
    "id" : 399939276684529664,
    "created_at" : "2013-11-11 16:38:48 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 399939403738398720,
  "created_at" : "2013-11-11 16:39:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399939142894632960",
  "text" : "Obama: \"They step up. They raise their hands. They take that oath. They put on the uniform and put their lives on the line.\" #HonoringVets",
  "id" : 399939142894632960,
  "created_at" : "2013-11-11 16:38:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399938944525008896",
  "text" : "\"Today, we gather once more to honor patriots who have rendered the highest service any American can offer this nation.\" \u2014President Obama",
  "id" : 399938944525008896,
  "created_at" : "2013-11-11 16:37:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/4SeMUxe8K1",
      "expanded_url" : "http:\/\/go.wh.gov\/pVedpv",
      "display_url" : "go.wh.gov\/pVedpv"
    } ]
  },
  "geo" : { },
  "id_str" : "399930645285064704",
  "text" : "Right now: President Obama participates in a wreath-laying ceremony at Arlington National Cemetery \u2014&gt; http:\/\/t.co\/4SeMUxe8K1 #VeteransDay",
  "id" : 399930645285064704,
  "created_at" : "2013-11-11 16:04:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 129, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/4SeMUxe8K1",
      "expanded_url" : "http:\/\/go.wh.gov\/pVedpv",
      "display_url" : "go.wh.gov\/pVedpv"
    } ]
  },
  "geo" : { },
  "id_str" : "399922014770581507",
  "text" : "At 11am ET, President Obama participates in a wreath-laying ceremony at Arlington National Cemetery \u2014&gt; http:\/\/t.co\/4SeMUxe8K1 #VeteransDay",
  "id" : 399922014770581507,
  "created_at" : "2013-11-11 15:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Marines",
      "screen_name" : "USMC",
      "indices" : [ 3, 8 ],
      "id_str" : "10126672",
      "id" : 10126672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/lslcsw8I1V",
      "expanded_url" : "http:\/\/ow.ly\/qAWlD",
      "display_url" : "ow.ly\/qAWlD"
    } ]
  },
  "geo" : { },
  "id_str" : "399728379282223104",
  "text" : "RT @USMC: Happy 238th birthday, Marines! http:\/\/t.co\/lslcsw8I1V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/lslcsw8I1V",
        "expanded_url" : "http:\/\/ow.ly\/qAWlD",
        "display_url" : "ow.ly\/qAWlD"
      } ]
    },
    "geo" : { },
    "id_str" : "399416532759240704",
    "text" : "Happy 238th birthday, Marines! http:\/\/t.co\/lslcsw8I1V",
    "id" : 399416532759240704,
    "created_at" : "2013-11-10 06:01:36 +0000",
    "user" : {
      "name" : "U.S. Marines",
      "screen_name" : "USMC",
      "protected" : false,
      "id_str" : "10126672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1922693175\/profile_normal.jpg",
      "id" : 10126672,
      "verified" : true
    }
  },
  "id" : 399728379282223104,
  "created_at" : "2013-11-11 02:40:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/DxXzM3vMlk",
      "expanded_url" : "http:\/\/go.wh.gov\/2d9mcP",
      "display_url" : "go.wh.gov\/2d9mcP"
    } ]
  },
  "geo" : { },
  "id_str" : "399718265913499648",
  "text" : "Watch a recap of President Obama's week at the White House \u2014&gt; http:\/\/t.co\/DxXzM3vMlk #WestWingWeek",
  "id" : 399718265913499648,
  "created_at" : "2013-11-11 02:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Yolanda",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399665418899427328",
  "text" : "\"Our thoughts and prayers go out to the millions of people affected by this devastating storm.\" \u2014President Obama on Super Typhoon #Yolanda",
  "id" : 399665418899427328,
  "created_at" : "2013-11-10 22:30:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Yolanda",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/wPbhOfxncs",
      "expanded_url" : "http:\/\/go.wh.gov\/u14iB5",
      "display_url" : "go.wh.gov\/u14iB5"
    } ]
  },
  "geo" : { },
  "id_str" : "399661227665674240",
  "text" : "Statement by President Obama on Super Typhoon #Yolanda \u2014&gt; http:\/\/t.co\/wPbhOfxncs",
  "id" : 399661227665674240,
  "created_at" : "2013-11-10 22:13:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/H5QbIFroUK",
      "expanded_url" : "http:\/\/go.wh.gov\/wdvyXM",
      "display_url" : "go.wh.gov\/wdvyXM"
    } ]
  },
  "geo" : { },
  "id_str" : "399250180400111616",
  "text" : "\"If you fight for your country overseas, you should never have to fight for a job when you come home.\" \u2014Obama: http:\/\/t.co\/H5QbIFroUK",
  "id" : 399250180400111616,
  "created_at" : "2013-11-09 19:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/399220901897854976\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/V6JFDu2I8f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYpRS4AIMAA-s_e.jpg",
      "id_str" : "399220901688127488",
      "id" : 399220901688127488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYpRS4AIMAA-s_e.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/V6JFDu2I8f"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/VCbLyWXL9C",
      "expanded_url" : "http:\/\/go.wh.gov\/wdvyXM",
      "display_url" : "go.wh.gov\/wdvyXM"
    } ]
  },
  "geo" : { },
  "id_str" : "399220901897854976",
  "text" : "To all of America's veterans: Thank you \u2014&gt; http:\/\/t.co\/VCbLyWXL9C #VeteransDay, http:\/\/t.co\/V6JFDu2I8f",
  "id" : 399220901897854976,
  "created_at" : "2013-11-09 17:04:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 1, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/H5QbIFroUK",
      "expanded_url" : "http:\/\/go.wh.gov\/wdvyXM",
      "display_url" : "go.wh.gov\/wdvyXM"
    } ]
  },
  "geo" : { },
  "id_str" : "399189789213077504",
  "text" : "\"#VeteransDay Weekend is a chance for all of us to say two simple words: 'Thank you.'\u201D \u2014President Obama: http:\/\/t.co\/H5QbIFroUK",
  "id" : 399189789213077504,
  "created_at" : "2013-11-09 15:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398961412753874944",
  "text" : "RT @AmbassadorPower: RT if you agree: 50M Americans with disabilities and 5.5M disabled vets deserve the same rights abroad as anyone else.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DisabilitiesTreaty",
        "indices" : [ 119, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398958074427232256",
    "text" : "RT if you agree: 50M Americans with disabilities and 5.5M disabled vets deserve the same rights abroad as anyone else. #DisabilitiesTreaty",
    "id" : 398958074427232256,
    "created_at" : "2013-11-08 23:39:51 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 398961412753874944,
  "created_at" : "2013-11-08 23:53:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398956673785950208",
  "text" : "RT @Interior: Did you know that access to all federal public lands is free this weekend in honor of #VeteransDay? RT to spread the word!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VeteransDay",
        "indices" : [ 86, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398891258342432770",
    "text" : "Did you know that access to all federal public lands is free this weekend in honor of #VeteransDay? RT to spread the word!",
    "id" : 398891258342432770,
    "created_at" : "2013-11-08 19:14:21 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 398956673785950208,
  "created_at" : "2013-11-08 23:34:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmithsonianPanda",
      "indices" : [ 9, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/vmJh9uKbEO",
      "expanded_url" : "http:\/\/s.si.edu\/1egGoRf",
      "display_url" : "s.si.edu\/1egGoRf"
    } ]
  },
  "geo" : { },
  "id_str" : "398948600584998912",
  "text" : "The baby #SmithsonianPanda needs a name!\n1. Bao Bao\n2. Ling Hua\n3. Long Yun\n4. Mulan\n5. Zhen Bao\nVOTE \u2014&gt; http:\/\/t.co\/vmJh9uKbEO",
  "id" : 398948600584998912,
  "created_at" : "2013-11-08 23:02:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PM of Israel",
      "screen_name" : "IsraeliPM",
      "indices" : [ 27, 37 ],
      "id_str" : "141084952",
      "id" : 141084952
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NSCPress\/status\/398943074836938752\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/MbzqydasRo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYlUnOWCAAAVrDr.jpg",
      "id_str" : "398943074841133056",
      "id" : 398943074841133056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYlUnOWCAAAVrDr.jpg",
      "sizes" : [ {
        "h" : 324,
        "resize" : "fit",
        "w" : 867
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 867
      }, {
        "h" : 127,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MbzqydasRo"
    } ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398943433064054784",
  "text" : "RT @NSCPress: POTUS called @IsraeliPM Netanyahu today to discuss #Iran. http:\/\/t.co\/MbzqydasRo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PM of Israel",
        "screen_name" : "IsraeliPM",
        "indices" : [ 13, 23 ],
        "id_str" : "141084952",
        "id" : 141084952
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NSCPress\/status\/398943074836938752\/photo\/1",
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/MbzqydasRo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYlUnOWCAAAVrDr.jpg",
        "id_str" : "398943074841133056",
        "id" : 398943074841133056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYlUnOWCAAAVrDr.jpg",
        "sizes" : [ {
          "h" : 324,
          "resize" : "fit",
          "w" : 867
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 867
        }, {
          "h" : 127,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/MbzqydasRo"
      } ],
      "hashtags" : [ {
        "text" : "Iran",
        "indices" : [ 51, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398943074836938752",
    "text" : "POTUS called @IsraeliPM Netanyahu today to discuss #Iran. http:\/\/t.co\/MbzqydasRo",
    "id" : 398943074836938752,
    "created_at" : "2013-11-08 22:40:15 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 398943433064054784,
  "created_at" : "2013-11-08 22:41:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/398613119917780993\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/Mm3b6Rfs3A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYgohUgCcAEp5mW.jpg",
      "id_str" : "398613119926169601",
      "id" : 398613119926169601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYgohUgCcAEp5mW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Mm3b6Rfs3A"
    } ],
    "hashtags" : [ {
      "text" : "ENDA",
      "indices" : [ 78, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398917181611589632",
  "text" : "No\none\nshould\nlose\ntheir\njob\nbecause\nof\nwho\nthey\nlove.\nhttp:\/\/t.co\/Mm3b6Rfs3A\n#ENDA",
  "id" : 398917181611589632,
  "created_at" : "2013-11-08 20:57:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 43, 50 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398908058136354816",
  "text" : "RT @DrBiden: Dr. Biden was honored to meet @USArmy Veteran Steven Ferraro today\u2014the 1 millionth beneficiary of Post-9\/11 GI Bill: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 30, 37 ],
        "id_str" : "8775672",
        "id" : 8775672
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/398904406646587392\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/NmwN4Le8ur",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYkxccHCAAAIIpf.jpg",
        "id_str" : "398904406650781696",
        "id" : 398904406650781696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYkxccHCAAAIIpf.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/NmwN4Le8ur"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398904406646587392",
    "text" : "Dr. Biden was honored to meet @USArmy Veteran Steven Ferraro today\u2014the 1 millionth beneficiary of Post-9\/11 GI Bill: http:\/\/t.co\/NmwN4Le8ur",
    "id" : 398904406646587392,
    "created_at" : "2013-11-08 20:06:36 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 398908058136354816,
  "created_at" : "2013-11-08 20:21:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398901311653285888",
  "text" : "RT @VP: Good news, progress on all 23 Executive Actions to reduce gun violence- Rules to require coverage for mental illness http:\/\/t.co\/Fm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/FmBDvttPCP",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/11\/08\/us\/politics\/rules-to-require-equal-coverage-for-mental-ills.html?partner=rss&emc=rss&smid=tw-nytimes&_r=0",
        "display_url" : "nytimes.com\/2013\/11\/08\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "398844238021947392",
    "text" : "Good news, progress on all 23 Executive Actions to reduce gun violence- Rules to require coverage for mental illness http:\/\/t.co\/FmBDvttPCP",
    "id" : 398844238021947392,
    "created_at" : "2013-11-08 16:07:31 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 398901311653285888,
  "created_at" : "2013-11-08 19:54:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/398889200839188480\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/qwQupb7aQT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYkjnWECYAEnaln.png",
      "id_str" : "398889200843382785",
      "id" : 398889200843382785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYkjnWECYAEnaln.png",
      "sizes" : [ {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 574
      } ],
      "display_url" : "pic.twitter.com\/qwQupb7aQT"
    } ],
    "hashtags" : [ {
      "text" : "instavideo",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/f602BLCIee",
      "expanded_url" : "http:\/\/instagram.com\/p\/gdrYBIwilC",
      "display_url" : "instagram.com\/p\/gdrYBIwilC"
    } ]
  },
  "geo" : { },
  "id_str" : "398890681193607168",
  "text" : "RT @ks44: Take a 15-second tour of the Port of New Orleans with President Obama \u2014&gt; http:\/\/t.co\/f602BLCIee #instavideo http:\/\/t.co\/qwQupb7aQT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/398889200839188480\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/qwQupb7aQT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYkjnWECYAEnaln.png",
        "id_str" : "398889200843382785",
        "id" : 398889200843382785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYkjnWECYAEnaln.png",
        "sizes" : [ {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 574
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 574
        } ],
        "display_url" : "pic.twitter.com\/qwQupb7aQT"
      } ],
      "hashtags" : [ {
        "text" : "instavideo",
        "indices" : [ 99, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/f602BLCIee",
        "expanded_url" : "http:\/\/instagram.com\/p\/gdrYBIwilC",
        "display_url" : "instagram.com\/p\/gdrYBIwilC"
      } ]
    },
    "geo" : { },
    "id_str" : "398889200839188480",
    "text" : "Take a 15-second tour of the Port of New Orleans with President Obama \u2014&gt; http:\/\/t.co\/f602BLCIee #instavideo http:\/\/t.co\/qwQupb7aQT",
    "id" : 398889200839188480,
    "created_at" : "2013-11-08 19:06:11 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 398890681193607168,
  "created_at" : "2013-11-08 19:12:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398888245523521537",
  "text" : "RT @WHLive: Obama: \"Let\u2019s make sure we\u2019ve got the best ports, and the best roads, and the best bridges, and the best schools.\" #PeopleOverP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PeopleOverPolitics",
        "indices" : [ 115, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398888083124260864",
    "text" : "Obama: \"Let\u2019s make sure we\u2019ve got the best ports, and the best roads, and the best bridges, and the best schools.\" #PeopleOverPolitics",
    "id" : 398888083124260864,
    "created_at" : "2013-11-08 19:01:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 398888245523521537,
  "created_at" : "2013-11-08 19:02:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398887048699846656",
  "text" : "RT @WHLive: Obama: \"Let\u2019s make it easier for more businesses to expand and grow and sell more goods #MadeInAmerica to the rest of the world\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 88, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398887006282850304",
    "text" : "Obama: \"Let\u2019s make it easier for more businesses to expand and grow and sell more goods #MadeInAmerica to the rest of the world.\"",
    "id" : 398887006282850304,
    "created_at" : "2013-11-08 18:57:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 398887048699846656,
  "created_at" : "2013-11-08 18:57:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 7, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398886383604875264",
  "text" : "Obama: #Obamacare \"allows states to expand Medicaid to cover more of their citizens. Here in Louisiana that would benefit...265,000 people.\"",
  "id" : 398886383604875264,
  "created_at" : "2013-11-08 18:54:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 113, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398885402217443328",
  "text" : "Obama: \"Rebuilding our infrastructure, educating our kids, funding basic research\u2014they are not partisan issues.\" #PeopleOverPolitics",
  "id" : 398885402217443328,
  "created_at" : "2013-11-08 18:51:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398884438701899777",
  "text" : "RT @WHLive: Obama: \"Educating our kids and training our workers so they\u2019re prepared for a global economy\u2014that helps us grow.\" #PeopleOverPo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PeopleOverPolitics",
        "indices" : [ 114, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398884417541648385",
    "text" : "Obama: \"Educating our kids and training our workers so they\u2019re prepared for a global economy\u2014that helps us grow.\" #PeopleOverPolitics",
    "id" : 398884417541648385,
    "created_at" : "2013-11-08 18:47:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 398884438701899777,
  "created_at" : "2013-11-08 18:47:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398884284330561536",
  "text" : "RT @WHLive: President Obama: \"Building new roads, and bridges, and schools, and ports\u2014that creates jobs.\" #MadeInAmerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 94, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398884153749278720",
    "text" : "President Obama: \"Building new roads, and bridges, and schools, and ports\u2014that creates jobs.\" #MadeInAmerica",
    "id" : 398884153749278720,
    "created_at" : "2013-11-08 18:46:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 398884284330561536,
  "created_at" : "2013-11-08 18:46:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 121, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398884031288201216",
  "text" : "Obama: \"We should close wasteful tax loopholes that don\u2019t help create jobs...and invest in the things that actually do.\" #PeopleOverPolitics",
  "id" : 398884031288201216,
  "created_at" : "2013-11-08 18:45:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 17, 35 ]
    }, {
      "text" : "PeopleOverPolitics",
      "indices" : [ 119, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398883820457324545",
  "text" : "Obama on passing #ImmigrationReform: \"There\u2019s no reason both parties can\u2019t come together and get this done this year.\" #PeopleOverPolitics",
  "id" : 398883820457324545,
  "created_at" : "2013-11-08 18:44:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 120, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398883524322672640",
  "text" : "Obama: \"First, Congress needs to pass a farm bill that helps rural communities grow and protects vulnerable Americans.\" #PeopleOverPolitics",
  "id" : 398883524322672640,
  "created_at" : "2013-11-08 18:43:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398883378503487489",
  "text" : "RT @WHLive: Obama: \"I\u2019ve put forward 3 more areas where I believe Democrats &amp; Republicans can join together to make progress.\" #PeopleOverP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PeopleOverPolitics",
        "indices" : [ 119, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398883323964968960",
    "text" : "Obama: \"I\u2019ve put forward 3 more areas where I believe Democrats &amp; Republicans can join together to make progress.\" #PeopleOverPolitics",
    "id" : 398883323964968960,
    "created_at" : "2013-11-08 18:42:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 398883378503487489,
  "created_at" : "2013-11-08 18:43:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398883225864392704",
  "text" : "Obama: \"Rather than refight the same old battles, we should fight to make sure that everyone who works hard\u2026has a chance to get ahead.\"",
  "id" : 398883225864392704,
  "created_at" : "2013-11-08 18:42:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shutdown",
      "indices" : [ 23, 32 ]
    }, {
      "text" : "PeopleOverPolitics",
      "indices" : [ 120, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398883037863092224",
  "text" : "President Obama on the #shutdown: \"These self-inflicted wounds didn\u2019t have to happen, and they shouldn\u2019t happen again.\" #PeopleOverPolitics",
  "id" : 398883037863092224,
  "created_at" : "2013-11-08 18:41:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/398882627303649281\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/szAAk4BniA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYkdotVCIAABt4f.jpg",
      "id_str" : "398882627198787584",
      "id" : 398882627198787584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYkdotVCIAABt4f.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/szAAk4BniA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398882627303649281",
  "text" : "\"Since I took office, we\u2019ve cut our deficits in half.\" \u2014President Obama, http:\/\/t.co\/szAAk4BniA",
  "id" : 398882627303649281,
  "created_at" : "2013-11-08 18:40:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/398882394763063296\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/2Yo2Z7i3ZV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYkdbLECMAAKkly.jpg",
      "id_str" : "398882394662383616",
      "id" : 398882394662383616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYkdbLECMAAKkly.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/2Yo2Z7i3ZV"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398882394763063296",
  "text" : "President Obama: \"Over the past 44 months, our businesses have created 7.8 million new jobs.\" #MadeInAmerica, http:\/\/t.co\/2Yo2Z7i3ZV",
  "id" : 398882394763063296,
  "created_at" : "2013-11-08 18:39:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/JdJudVJSB4",
      "expanded_url" : "http:\/\/go.wh.gov\/WzQsSy",
      "display_url" : "go.wh.gov\/WzQsSy"
    } ]
  },
  "geo" : { },
  "id_str" : "398881437576740865",
  "text" : "President Obama: \"Hello, Big Easy! ... It is good to be back in New Orleans.\" Watch live \u2014&gt; http:\/\/t.co\/JdJudVJSB4",
  "id" : 398881437576740865,
  "created_at" : "2013-11-08 18:35:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 83, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398879245880934401",
  "text" : "FACT: U.S. exports have growth by more than 50% since President Obama took office. #MadeInAmerica",
  "id" : 398879245880934401,
  "created_at" : "2013-11-08 18:26:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/JdJudVJSB4",
      "expanded_url" : "http:\/\/go.wh.gov\/WzQsSy",
      "display_url" : "go.wh.gov\/WzQsSy"
    } ]
  },
  "geo" : { },
  "id_str" : "398869566740111360",
  "text" : "Watch President Obama's speech on growing our economy and creating jobs by increasing our exports at 1:10pm ET \u2014&gt; http:\/\/t.co\/JdJudVJSB4",
  "id" : 398869566740111360,
  "created_at" : "2013-11-08 17:48:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 31, 50 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/78LWpXo8mB",
      "expanded_url" : "http:\/\/go.wh.gov\/r4He5n",
      "display_url" : "go.wh.gov\/r4He5n"
    } ]
  },
  "geo" : { },
  "id_str" : "398861069617082369",
  "text" : "FACT: If the Louisiana GOP put #PeopleOverPolitics, 265,000 more people could get health coverage through #Obamacare: http:\/\/t.co\/78LWpXo8mB",
  "id" : 398861069617082369,
  "created_at" : "2013-11-08 17:14:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398852549148540928",
  "text" : "FACT: Since mid-2009, U.S. automakers have added 357,000 jobs\u2014the industry's strongest growth since the 1990s. #MadeInAmerica",
  "id" : 398852549148540928,
  "created_at" : "2013-11-08 16:40:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 116, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398847514142461953",
  "text" : "FACT: Our manufacturers have added 526,000 jobs since Februrary 2010\u2014the best job growth in that sector since 1998. #MadeInAmerica",
  "id" : 398847514142461953,
  "created_at" : "2013-11-08 16:20:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskCEA",
      "indices" : [ 113, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398841669824823296",
  "text" : "RT @CEABetsey: Have questions about jobs numbers, GDP growth or the effects of the government shutdown? Ask with #AskCEA. I'll answer throu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskCEA",
        "indices" : [ 98, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398825370574536704",
    "text" : "Have questions about jobs numbers, GDP growth or the effects of the government shutdown? Ask with #AskCEA. I'll answer throughout the day.",
    "id" : 398825370574536704,
    "created_at" : "2013-11-08 14:52:32 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 398841669824823296,
  "created_at" : "2013-11-08 15:57:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/398836593621864448\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/3nEFIQMr72",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYjzxM6CEAAjMns.jpg",
      "id_str" : "398836593626058752",
      "id" : 398836593626058752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYjzxM6CEAAjMns.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/3nEFIQMr72"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/h6i39zYRRP",
      "expanded_url" : "http:\/\/go.wh.gov\/eDncT3",
      "display_url" : "go.wh.gov\/eDncT3"
    } ]
  },
  "geo" : { },
  "id_str" : "398836593621864448",
  "text" : "FACT: Our economy is now adding jobs at a pace of more than 2 million per year \u2014&gt; http:\/\/t.co\/h6i39zYRRP, http:\/\/t.co\/3nEFIQMr72",
  "id" : 398836593621864448,
  "created_at" : "2013-11-08 15:37:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/TukyThNJ3c",
      "expanded_url" : "http:\/\/go.wh.gov\/FbpvnQ",
      "display_url" : "go.wh.gov\/FbpvnQ"
    } ]
  },
  "geo" : { },
  "id_str" : "398831159993311235",
  "text" : "Good news.\nOur economy added:\n1. 212,000 private-sector jobs last month.\n2. 7.8 million jobs over 44 straight months.\nhttp:\/\/t.co\/TukyThNJ3c",
  "id" : 398831159993311235,
  "created_at" : "2013-11-08 15:15:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/398613119917780993\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Mm3b6Rfs3A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYgohUgCcAEp5mW.jpg",
      "id_str" : "398613119926169601",
      "id" : 398613119926169601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYgohUgCcAEp5mW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Mm3b6Rfs3A"
    } ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/4pHVjVlhq7",
      "expanded_url" : "http:\/\/go.wh.gov\/d9eDb6",
      "display_url" : "go.wh.gov\/d9eDb6"
    } ]
  },
  "geo" : { },
  "id_str" : "398613119917780993",
  "text" : "RT if you agree: It's long-past time to ban workplace discrimination against #LGBT Americans. http:\/\/t.co\/4pHVjVlhq7 http:\/\/t.co\/Mm3b6Rfs3A",
  "id" : 398613119917780993,
  "created_at" : "2013-11-08 00:49:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/6oEm0nMYAR",
      "expanded_url" : "http:\/\/politi.co\/17Q76fw",
      "display_url" : "politi.co\/17Q76fw"
    } ]
  },
  "geo" : { },
  "id_str" : "398583742585143296",
  "text" : "RT @PressSec: Excellent piece by Ari Fleischer, one of my predecessors, urging the House to pass ENDA: http:\/\/t.co\/6oEm0nMYAR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/6oEm0nMYAR",
        "expanded_url" : "http:\/\/politi.co\/17Q76fw",
        "display_url" : "politi.co\/17Q76fw"
      } ]
    },
    "geo" : { },
    "id_str" : "398581053251534849",
    "text" : "Excellent piece by Ari Fleischer, one of my predecessors, urging the House to pass ENDA: http:\/\/t.co\/6oEm0nMYAR",
    "id" : 398581053251534849,
    "created_at" : "2013-11-07 22:41:43 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 398583742585143296,
  "created_at" : "2013-11-07 22:52:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 87, 98 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/QZmScb2Eok",
      "expanded_url" : "http:\/\/go.wh.gov\/T9iWni",
      "display_url" : "go.wh.gov\/T9iWni"
    } ]
  },
  "geo" : { },
  "id_str" : "398574460594171906",
  "text" : "\"Nothing is going to stop us from getting this done.\" \u2014Obama on helping more Americans #GetCovered: http:\/\/t.co\/QZmScb2Eok #Obamacare",
  "id" : 398574460594171906,
  "created_at" : "2013-11-07 22:15:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ENDA",
      "indices" : [ 115, 120 ]
    }, {
      "text" : "Equality",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398560977920094208",
  "text" : "RT @LaborSec: RT if you agree: Protecting the workplace rights of LGBT workers is a moral imperative long overdue. #ENDA #Equality http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/398559800427937792\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/2p17X6ZLAb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYf4Bt7CAAAG1fO.jpg",
        "id_str" : "398559800436326400",
        "id" : 398559800436326400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYf4Bt7CAAAG1fO.jpg",
        "sizes" : [ {
          "h" : 401,
          "resize" : "fit",
          "w" : 401
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 401
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 401
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2p17X6ZLAb"
      } ],
      "hashtags" : [ {
        "text" : "ENDA",
        "indices" : [ 101, 106 ]
      }, {
        "text" : "Equality",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398559800427937792",
    "text" : "RT if you agree: Protecting the workplace rights of LGBT workers is a moral imperative long overdue. #ENDA #Equality http:\/\/t.co\/2p17X6ZLAb",
    "id" : 398559800427937792,
    "created_at" : "2013-11-07 21:17:16 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 398560977920094208,
  "created_at" : "2013-11-07 21:21:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ENDA",
      "indices" : [ 21, 26 ]
    }, {
      "text" : "equality",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398551475132973056",
  "text" : "RT @VP: In approving #ENDA, Senators on both sides of the aisle stood up for #equality. It\u2019s time for the House to vote.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ENDA",
        "indices" : [ 13, 18 ]
      }, {
        "text" : "equality",
        "indices" : [ 69, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398531205290676225",
    "text" : "In approving #ENDA, Senators on both sides of the aisle stood up for #equality. It\u2019s time for the House to vote.",
    "id" : 398531205290676225,
    "created_at" : "2013-11-07 19:23:38 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 398551475132973056,
  "created_at" : "2013-11-07 20:44:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ENDA",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/WJnqRZveyI",
      "expanded_url" : "http:\/\/go.wh.gov\/dNnxcP",
      "display_url" : "go.wh.gov\/dNnxcP"
    } ]
  },
  "geo" : { },
  "id_str" : "398548271599075328",
  "text" : "RT @Inouye44: President Obama urges the House Republican leadership to bring #ENDA to the floor for a vote --&gt; http:\/\/t.co\/WJnqRZveyI #Just\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ENDA",
        "indices" : [ 63, 68 ]
      }, {
        "text" : "JustVote",
        "indices" : [ 123, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/WJnqRZveyI",
        "expanded_url" : "http:\/\/go.wh.gov\/dNnxcP",
        "display_url" : "go.wh.gov\/dNnxcP"
      } ]
    },
    "geo" : { },
    "id_str" : "398540663773347840",
    "text" : "President Obama urges the House Republican leadership to bring #ENDA to the floor for a vote --&gt; http:\/\/t.co\/WJnqRZveyI #JustVote",
    "id" : 398540663773347840,
    "created_at" : "2013-11-07 20:01:13 +0000",
    "user" : {
      "name" : "Shin Inouye",
      "screen_name" : "InouyeUSCIS",
      "protected" : false,
      "id_str" : "1702571186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667848615780446208\/1LoEXwfW_normal.jpg",
      "id" : 1702571186,
      "verified" : true
    }
  },
  "id" : 398548271599075328,
  "created_at" : "2013-11-07 20:31:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ENDA",
      "indices" : [ 99, 104 ]
    }, {
      "text" : "Equality",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/N35cn4z2GG",
      "expanded_url" : "http:\/\/go.wh.gov\/dNnxcP",
      "display_url" : "go.wh.gov\/dNnxcP"
    } ]
  },
  "geo" : { },
  "id_str" : "398544009489944576",
  "text" : "\"Now is the time to end this kind of discrimination in the workplace.\" \u2014Obama on Senate passage of #ENDA: http:\/\/t.co\/N35cn4z2GG #Equality",
  "id" : 398544009489944576,
  "created_at" : "2013-11-07 20:14:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ENDA",
      "indices" : [ 123, 128 ]
    }, {
      "text" : "Equality",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398538242087088128",
  "text" : "\"No one should ever lose their job simply because of who they are or who they love.\" \u2014President Obama on Senate passage of #ENDA. #Equality",
  "id" : 398538242087088128,
  "created_at" : "2013-11-07 19:51:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 62, 71 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Equality",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "ENDA",
      "indices" : [ 106, 111 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/7DpXjRtHXv",
      "expanded_url" : "http:\/\/go.wh.gov\/F4y64h",
      "display_url" : "go.wh.gov\/F4y64h"
    } ]
  },
  "geo" : { },
  "id_str" : "398530420859351040",
  "text" : "\"It's time to end workplace discrimination in this country.\" \u2014@PressSec: http:\/\/t.co\/7DpXjRtHXv #Equality #ENDA #LGBT",
  "id" : 398530420859351040,
  "created_at" : "2013-11-07 19:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/398511933495586816\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/iu0b8ElQ76",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYfMffuCMAA9fEW.jpg",
      "id_str" : "398511933508169728",
      "id" : 398511933508169728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYfMffuCMAA9fEW.jpg",
      "sizes" : [ {
        "h" : 335,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 590,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 614,
        "resize" : "fit",
        "w" : 624
      }, {
        "h" : 614,
        "resize" : "fit",
        "w" : 624
      } ],
      "display_url" : "pic.twitter.com\/iu0b8ElQ76"
    } ],
    "hashtags" : [ {
      "text" : "ThrowbackThursday",
      "indices" : [ 19, 37 ]
    }, {
      "text" : "tbt",
      "indices" : [ 103, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398525786321584128",
  "text" : "RT @VP: Another VP #ThrowbackThursday \u2013 any other Marty Walshes out there? We\u2019d love to hear from you\u2026 #tbt http:\/\/t.co\/iu0b8ElQ76",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/398511933495586816\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/iu0b8ElQ76",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYfMffuCMAA9fEW.jpg",
        "id_str" : "398511933508169728",
        "id" : 398511933508169728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYfMffuCMAA9fEW.jpg",
        "sizes" : [ {
          "h" : 335,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 590,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 614,
          "resize" : "fit",
          "w" : 624
        }, {
          "h" : 614,
          "resize" : "fit",
          "w" : 624
        } ],
        "display_url" : "pic.twitter.com\/iu0b8ElQ76"
      } ],
      "hashtags" : [ {
        "text" : "ThrowbackThursday",
        "indices" : [ 11, 29 ]
      }, {
        "text" : "tbt",
        "indices" : [ 95, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398511933495586816",
    "text" : "Another VP #ThrowbackThursday \u2013 any other Marty Walshes out there? We\u2019d love to hear from you\u2026 #tbt http:\/\/t.co\/iu0b8ElQ76",
    "id" : 398511933495586816,
    "created_at" : "2013-11-07 18:07:03 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 398525786321584128,
  "created_at" : "2013-11-07 19:02:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398520354261315584",
  "text" : "FACT: Nearly 2.5 million more patients have access to care at community health centers thanks to #Obamacare and the Recovery Act.",
  "id" : 398520354261315584,
  "created_at" : "2013-11-07 18:40:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/WAcF02SMk8",
      "expanded_url" : "http:\/\/go.wh.gov\/zBgBtm",
      "display_url" : "go.wh.gov\/zBgBtm"
    } ]
  },
  "geo" : { },
  "id_str" : "398515321637572609",
  "text" : "FACT: Thanks to #Obamacare, 73,000 more Floridians will gain access to care through community health centers \u2014&gt; http:\/\/t.co\/WAcF02SMk8",
  "id" : 398515321637572609,
  "created_at" : "2013-11-07 18:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 1, 11 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Ifjm8vbKOj",
      "expanded_url" : "http:\/\/go.wh.gov\/1YWT7v",
      "display_url" : "go.wh.gov\/1YWT7v"
    } ]
  },
  "geo" : { },
  "id_str" : "398510306021736448",
  "text" : ".@Cecilia44 on how #Obamacare is \"helping more Americans get the health care they need, when they need it.\" \u2014&gt; http:\/\/t.co\/Ifjm8vbKOj",
  "id" : 398510306021736448,
  "created_at" : "2013-11-07 18:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 11, 21 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Un9mYvIYCh",
      "expanded_url" : "http:\/\/go.wh.gov\/KehXNB",
      "display_url" : "go.wh.gov\/KehXNB"
    } ]
  },
  "geo" : { },
  "id_str" : "398503488033783808",
  "text" : "Good news: #Obamacare is helping community health centers treat 1.25 million new patients \u2014&gt; http:\/\/t.co\/Un9mYvIYCh #GetCovered",
  "id" : 398503488033783808,
  "created_at" : "2013-11-07 17:33:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398500172977942529",
  "text" : "RT @CEABetsey: Today we learned how our economy was doing before the shutdown-growing at 2.8%. Tomorrow we get our first glimpse at how its\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398467066568531971",
    "text" : "Today we learned how our economy was doing before the shutdown-growing at 2.8%. Tomorrow we get our first glimpse at how its doing after.",
    "id" : 398467066568531971,
    "created_at" : "2013-11-07 15:08:46 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 398500172977942529,
  "created_at" : "2013-11-07 17:20:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/398493282386198528\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/VSpLudQg2R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYe7h2TCYAIb94x.jpg",
      "id_str" : "398493282231017474",
      "id" : 398493282231017474,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYe7h2TCYAIb94x.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/VSpLudQg2R"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398493282386198528",
  "text" : "Last quarter:\n1. GDP grew at 2.8%.\n2. Private-sector GDP grew at 3.5%.\n3. Exports grew at 4.5%.\n#ABetterBargain, http:\/\/t.co\/VSpLudQg2R",
  "id" : 398493282386198528,
  "created_at" : "2013-11-07 16:52:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 78, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/zCGrKRpYRU",
      "expanded_url" : "http:\/\/go.wh.gov\/dnnVzX",
      "display_url" : "go.wh.gov\/dnnVzX"
    } ]
  },
  "geo" : { },
  "id_str" : "398482700828278786",
  "text" : "GDP grew at a strong 2.8% clip last quarter\u2014but there's more to do to build a #ABetterBargain for the middle class: http:\/\/t.co\/zCGrKRpYRU",
  "id" : 398482700828278786,
  "created_at" : "2013-11-07 16:10:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398461648458899456",
  "text" : "RT @CEAChair: Real GDP rose at a 2.8% annual pace in Q3; fastest quarterly pace in the last year; &amp; 10th consecutive Q of growth http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/398459064805380096\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/HzVtu2ClEr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYecaIfCUAAsaqg.jpg",
        "id_str" : "398459064813768704",
        "id" : 398459064813768704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYecaIfCUAAsaqg.jpg",
        "sizes" : [ {
          "h" : 659,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 659,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/HzVtu2ClEr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "398459064805380096",
    "text" : "Real GDP rose at a 2.8% annual pace in Q3; fastest quarterly pace in the last year; &amp; 10th consecutive Q of growth http:\/\/t.co\/HzVtu2ClEr",
    "id" : 398459064805380096,
    "created_at" : "2013-11-07 14:36:58 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 398461648458899456,
  "created_at" : "2013-11-07 14:47:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/398264960050298881\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/xujaZ8bOMi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYbr3vTIMAADG-T.jpg",
      "id_str" : "398264959890894848",
      "id" : 398264959890894848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYbr3vTIMAADG-T.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xujaZ8bOMi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398264960050298881",
  "text" : "Oh, you again\u2026 http:\/\/t.co\/xujaZ8bOMi",
  "id" : 398264960050298881,
  "created_at" : "2013-11-07 01:45:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 14, 23 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "Equality",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/nzCacjJM2M",
      "expanded_url" : "http:\/\/go.wh.gov\/ARs2zp",
      "display_url" : "go.wh.gov\/ARs2zp"
    } ]
  },
  "geo" : { },
  "id_str" : "398251250992439296",
  "text" : "Watch Obama's @PressSec discuss why it's time to ban workplace discrimination against #LGBT Americans: http:\/\/t.co\/nzCacjJM2M #Equality",
  "id" : 398251250992439296,
  "created_at" : "2013-11-07 00:51:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 47, 57 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/mmRGnWMS8P",
      "expanded_url" : "http:\/\/go.wh.gov\/DjUfm2",
      "display_url" : "go.wh.gov\/DjUfm2"
    } ]
  },
  "geo" : { },
  "id_str" : "398242787973275648",
  "text" : "FACT: If every state expanded Medicaid through #Obamacare, 5.4 million more uninsured Americans could #GetCovered \u2014&gt; http:\/\/t.co\/mmRGnWMS8P",
  "id" : 398242787973275648,
  "created_at" : "2013-11-07 00:17:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 111, 122 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398232411299119104",
  "text" : "RT @FLOTUS: You don't want to miss this: President Obama, the First Lady, Bo, and Sunny surprise guests at the @WhiteHouse \u2014&gt; http:\/\/t.co\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 99, 110 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tejqnp3Rcw",
        "expanded_url" : "http:\/\/go.wh.gov\/BcngJo",
        "display_url" : "go.wh.gov\/BcngJo"
      } ]
    },
    "geo" : { },
    "id_str" : "398222191461814272",
    "text" : "You don't want to miss this: President Obama, the First Lady, Bo, and Sunny surprise guests at the @WhiteHouse \u2014&gt; http:\/\/t.co\/tejqnp3Rcw",
    "id" : 398222191461814272,
    "created_at" : "2013-11-06 22:55:43 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 398232411299119104,
  "created_at" : "2013-11-06 23:36:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "JulianCastro",
      "indices" : [ 37, 50 ],
      "id_str" : "19682187",
      "id" : 19682187
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 72, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/5WI9CsZLar",
      "expanded_url" : "http:\/\/wh.gov\/lZ5Vr",
      "display_url" : "wh.gov\/lZ5Vr"
    } ]
  },
  "geo" : { },
  "id_str" : "398223470762655744",
  "text" : "RT @vj44: Compelling case from Mayor @JulianCastro on why we should put #PeopleOverPolitics and expand Medicaid http:\/\/t.co\/5WI9CsZLar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Juli\u00E1n Castro",
        "screen_name" : "JulianCastro",
        "indices" : [ 27, 40 ],
        "id_str" : "19682187",
        "id" : 19682187
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PeopleOverPolitics",
        "indices" : [ 62, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/5WI9CsZLar",
        "expanded_url" : "http:\/\/wh.gov\/lZ5Vr",
        "display_url" : "wh.gov\/lZ5Vr"
      } ]
    },
    "geo" : { },
    "id_str" : "398217521548894208",
    "text" : "Compelling case from Mayor @JulianCastro on why we should put #PeopleOverPolitics and expand Medicaid http:\/\/t.co\/5WI9CsZLar",
    "id" : 398217521548894208,
    "created_at" : "2013-11-06 22:37:10 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 398223470762655744,
  "created_at" : "2013-11-06 23:00:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 121, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398218362230038528",
  "text" : "FACT: If the Texas GOP expanded Medicaid\u2014Texas taxpayers would save $1.7 billion in unpaid hospital bills over 10 years. #PeopleOverPolitics",
  "id" : 398218362230038528,
  "created_at" : "2013-11-06 22:40:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "JulianCastro",
      "indices" : [ 67, 80 ],
      "id_str" : "19682187",
      "id" : 19682187
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 105, 115 ]
    }, {
      "text" : "PeopleOverPolitics",
      "indices" : [ 116, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/w2Kdd3vnTG",
      "expanded_url" : "http:\/\/go.wh.gov\/fbaLPV",
      "display_url" : "go.wh.gov\/fbaLPV"
    } ]
  },
  "geo" : { },
  "id_str" : "398209309437222912",
  "text" : "\"Let's stop denying Texans health insurance because of politics.\" \u2014@JulianCastro: http:\/\/t.co\/w2Kdd3vnTG #Obamacare #PeopleOverPolitics",
  "id" : 398209309437222912,
  "created_at" : "2013-11-06 22:04:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 84, 94 ]
    }, {
      "text" : "PeopleOverPolitics",
      "indices" : [ 113, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398174321169821696",
  "text" : "The NC GOP is preventing nearly 400,000 people from getting health coverage through #Obamacare. It's time to put #PeopleOverPolitics.",
  "id" : 398174321169821696,
  "created_at" : "2013-11-06 19:45:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 79, 89 ]
    }, {
      "text" : "PeopleOverPolitics",
      "indices" : [ 121, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398168028107399168",
  "text" : "The FL GOP is preventing nearly 1 million from getting health coverage through #Obamacare. RT if you agree that's wrong. #PeopleOverPolitics",
  "id" : 398168028107399168,
  "created_at" : "2013-11-06 19:20:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "PeopleOverPolitics",
      "indices" : [ 116, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398163000894296064",
  "text" : "If the Texas GOP agreed to expand Medicaid through #Obamacare, 1.2 million more people would have health insurance. #PeopleOverPolitics",
  "id" : 398163000894296064,
  "created_at" : "2013-11-06 19:00:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 56, 75 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/T92PEuwuY0",
      "expanded_url" : "http:\/\/go.wh.gov\/1WPSnP",
      "display_url" : "go.wh.gov\/1WPSnP"
    } ]
  },
  "geo" : { },
  "id_str" : "398154110987292672",
  "text" : "It's time for states refusing to expand Medicaid to put #PeopleOverPolitics &amp; help millions of Americans #GetCovered: http:\/\/t.co\/T92PEuwuY0",
  "id" : 398154110987292672,
  "created_at" : "2013-11-06 18:25:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/398146143978135552\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/yXKxpRy1aW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYZ_zvmCIAA5wLf.jpg",
      "id_str" : "398146143994912768",
      "id" : 398146143994912768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYZ_zvmCIAA5wLf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/yXKxpRy1aW"
    } ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 19, 38 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398146143978135552",
  "text" : "If every state put #PeopleOverPolitics and expanded Medicaid, nearly 5.4 million more Americans could #GetCovered: http:\/\/t.co\/yXKxpRy1aW",
  "id" : 398146143978135552,
  "created_at" : "2013-11-06 17:53:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/398122660040671232\/photo\/1",
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/IMns5uOmI8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYZqczECAAEjyk0.png",
      "id_str" : "398122660044865537",
      "id" : 398122660044865537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYZqczECAAEjyk0.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/IMns5uOmI8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398122660040671232",
  "text" : "Morning perch. http:\/\/t.co\/IMns5uOmI8",
  "id" : 398122660040671232,
  "created_at" : "2013-11-06 16:20:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 75, 85 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/QjgCQoZX0F",
      "expanded_url" : "http:\/\/go.wh.gov\/4JD8Lf",
      "display_url" : "go.wh.gov\/4JD8Lf"
    } ]
  },
  "geo" : { },
  "id_str" : "398113469771182081",
  "text" : "NEW POLL: More Americans say they want to get health insurance through the #Obamacare marketplaces \u2014&gt; http:\/\/t.co\/QjgCQoZX0F #GetCovered",
  "id" : 398113469771182081,
  "created_at" : "2013-11-06 15:43:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/oUbLwqPemB",
      "expanded_url" : "http:\/\/go.wh.gov\/hDE4gX",
      "display_url" : "go.wh.gov\/hDE4gX"
    } ]
  },
  "geo" : { },
  "id_str" : "397879450332704768",
  "text" : "\"Michelle &amp; I are overjoyed for all the committed couples in IL whose love will now be as legal as ours\" \u2014Pres. Obama http:\/\/t.co\/oUbLwqPemB",
  "id" : 397879450332704768,
  "created_at" : "2013-11-06 00:13:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/397860420855144449\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/XExC3jvJLm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYV78d-CIAEflJV.jpg",
      "id_str" : "397860420859338753",
      "id" : 397860420859338753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYV78d-CIAEflJV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/XExC3jvJLm"
    } ],
    "hashtags" : [ {
      "text" : "MarriageEquality",
      "indices" : [ 84, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397860420855144449",
  "text" : "RT if you agree that every American should have the freedom to marry who they love. #MarriageEquality, http:\/\/t.co\/XExC3jvJLm",
  "id" : 397860420855144449,
  "created_at" : "2013-11-05 22:58:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 20, 32 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/I3JX1EQFu1",
      "expanded_url" : "http:\/\/go.wh.gov\/h9XZ81",
      "display_url" : "go.wh.gov\/h9XZ81"
    } ]
  },
  "geo" : { },
  "id_str" : "397855969067016194",
  "text" : "Secretary Kerry and @CommerceSec on why more companies all over the world are choosing to invest in America \u2014&gt; http:\/\/t.co\/I3JX1EQFu1",
  "id" : 397855969067016194,
  "created_at" : "2013-11-05 22:40:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 32, 39 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/397846407694254080\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/w54JMruklL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYVvMyPIYAE3eN6.jpg",
      "id_str" : "397846407526506497",
      "id" : 397846407526506497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYVvMyPIYAE3eN6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 809,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 830,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/w54JMruklL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397846407694254080",
  "text" : "A surprise visit with POTUS and @FLOTUS. http:\/\/t.co\/w54JMruklL",
  "id" : 397846407694254080,
  "created_at" : "2013-11-05 22:02:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Maley",
      "screen_name" : "Maley44",
      "indices" : [ 3, 11 ],
      "id_str" : "1881128166",
      "id" : 1881128166
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CONews",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397840823078768640",
  "text" : "RT @Maley44: \"It's dropping us down about $1,100 a month. We can retire. We can go fishing. We can actually see a future\" #CONews http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CONews",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Kvim7cMg4c",
        "expanded_url" : "http:\/\/n.pr\/17KNYj0",
        "display_url" : "n.pr\/17KNYj0"
      } ]
    },
    "geo" : { },
    "id_str" : "397839933202653184",
    "text" : "\"It's dropping us down about $1,100 a month. We can retire. We can go fishing. We can actually see a future\" #CONews http:\/\/t.co\/Kvim7cMg4c",
    "id" : 397839933202653184,
    "created_at" : "2013-11-05 21:36:46 +0000",
    "user" : {
      "name" : "Keith Maley",
      "screen_name" : "Maley44",
      "protected" : false,
      "id_str" : "1881128166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725086933961957376\/v5WvYCOW_normal.jpg",
      "id" : 1881128166,
      "verified" : true
    }
  },
  "id" : 397840823078768640,
  "created_at" : "2013-11-05 21:40:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/397821240477380608\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/mrVs9B53vc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYVYT3GCcAAhyfr.jpg",
      "id_str" : "397821240322191360",
      "id" : 397821240322191360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYVYT3GCcAAhyfr.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mrVs9B53vc"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 81, 92 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397821240477380608",
  "text" : "RT the good news: 17 million Americans are eligible for tax credits to help them #GetCovered next year. #Obamacare, http:\/\/t.co\/mrVs9B53vc",
  "id" : 397821240477380608,
  "created_at" : "2013-11-05 20:22:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 40, 53 ]
    }, {
      "text" : "WHChamps",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397804410539372544",
  "text" : "RT @vj44: We have a moral obligation to #ActOnClimate\u2013Check out the Iraq &amp; Afghanistan Vets advancing clean energy #WHChamps http:\/\/t.co\/RB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 30, 43 ]
      }, {
        "text" : "WHChamps",
        "indices" : [ 109, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/RBXzwH8q57",
        "expanded_url" : "http:\/\/ow.ly\/qvDbE",
        "display_url" : "ow.ly\/qvDbE"
      } ]
    },
    "geo" : { },
    "id_str" : "397801097664139264",
    "text" : "We have a moral obligation to #ActOnClimate\u2013Check out the Iraq &amp; Afghanistan Vets advancing clean energy #WHChamps http:\/\/t.co\/RBXzwH8q57",
    "id" : 397801097664139264,
    "created_at" : "2013-11-05 19:02:27 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 397804410539372544,
  "created_at" : "2013-11-05 19:15:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/397796026636976128\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/E8VvWRT0vz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYVBYO1CQAA_TYM.jpg",
      "id_str" : "397796026645364736",
      "id" : 397796026645364736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYVBYO1CQAA_TYM.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/E8VvWRT0vz"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397796026636976128",
  "text" : "RT if you agree: It's time to focus on helping millions of Americans get affordable health coverage. #Obamacare, http:\/\/t.co\/E8VvWRT0vz",
  "id" : 397796026636976128,
  "created_at" : "2013-11-05 18:42:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/f4iajvbLkd",
      "expanded_url" : "http:\/\/go.wh.gov\/RiKkXd",
      "display_url" : "go.wh.gov\/RiKkXd"
    } ]
  },
  "geo" : { },
  "id_str" : "397785513869844480",
  "text" : "Thanks to #Obamacare, nearly 2 million Californians are eligible for tax credits that make it easier to #GetCovered: http:\/\/t.co\/f4iajvbLkd",
  "id" : 397785513869844480,
  "created_at" : "2013-11-05 18:00:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/CVupTZkpb4",
      "expanded_url" : "http:\/\/go.wh.gov\/mMFezi",
      "display_url" : "go.wh.gov\/mMFezi"
    } ]
  },
  "geo" : { },
  "id_str" : "397777963124408320",
  "text" : "Need health coverage in Texas? More than 2 million are eligible for tax credits to help afford insurance: http:\/\/t.co\/CVupTZkpb4 #Obamacare",
  "id" : 397777963124408320,
  "created_at" : "2013-11-05 17:30:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 113, 124 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397770425758777345",
  "text" : "FACT: 1.5 million Floridians who are uninsured or buy coverage on their own are eligible for tax credits to help #GetCovered. #Obamacare",
  "id" : 397770425758777345,
  "created_at" : "2013-11-05 17:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 85, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/uOEiG5Qj3y",
      "expanded_url" : "http:\/\/go.wh.gov\/SyRHDo",
      "display_url" : "go.wh.gov\/SyRHDo"
    } ]
  },
  "geo" : { },
  "id_str" : "397765372448735232",
  "text" : "Thanks to #Obamacare, 17 million Americans are eligible for tax credits to help them #GetCovered next year \u2014&gt; http:\/\/t.co\/uOEiG5Qj3y",
  "id" : 397765372448735232,
  "created_at" : "2013-11-05 16:40:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/tjJfE59Ws9",
      "expanded_url" : "http:\/\/wh.gov\/surprise",
      "display_url" : "wh.gov\/surprise"
    } ]
  },
  "geo" : { },
  "id_str" : "397756520651190272",
  "text" : "White House tours are back! Watch who is surprising guests in the Blue Room \u2014&gt; http:\/\/t.co\/tjJfE59Ws9",
  "id" : 397756520651190272,
  "created_at" : "2013-11-05 16:05:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397753862062612480",
  "text" : "RT @FLOTUS: We just re-opened tours at the White House &amp; I\u2019m about to greet folks right now. Tune in\u2026this is going to be fun! \u2013mo http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/PMZscGx0kH",
        "expanded_url" : "http:\/\/WH.gov\/surprise",
        "display_url" : "WH.gov\/surprise"
      } ]
    },
    "geo" : { },
    "id_str" : "397753069951127554",
    "text" : "We just re-opened tours at the White House &amp; I\u2019m about to greet folks right now. Tune in\u2026this is going to be fun! \u2013mo http:\/\/t.co\/PMZscGx0kH",
    "id" : 397753069951127554,
    "created_at" : "2013-11-05 15:51:36 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 397753862062612480,
  "created_at" : "2013-11-05 15:54:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "indices" : [ 3, 11 ],
      "id_str" : "1603381488",
      "id" : 1603381488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 104, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ZQfGaf7MDr",
      "expanded_url" : "http:\/\/ow.ly\/qvww5",
      "display_url" : "ow.ly\/qvww5"
    } ]
  },
  "geo" : { },
  "id_str" : "397744361925910528",
  "text" : "RT @Katie44: NEW REPORT: State-by-State Estimates of # of People Eligible for Premium Tax Credits Under #ACA http:\/\/t.co\/ZQfGaf7MDr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 91, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/ZQfGaf7MDr",
        "expanded_url" : "http:\/\/ow.ly\/qvww5",
        "display_url" : "ow.ly\/qvww5"
      } ]
    },
    "geo" : { },
    "id_str" : "397741408640987137",
    "text" : "NEW REPORT: State-by-State Estimates of # of People Eligible for Premium Tax Credits Under #ACA http:\/\/t.co\/ZQfGaf7MDr",
    "id" : 397741408640987137,
    "created_at" : "2013-11-05 15:05:16 +0000",
    "user" : {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "protected" : false,
      "id_str" : "1603381488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000171840264\/4f11a05d0664eefddc3806b77bfd2b99_normal.jpeg",
      "id" : 1603381488,
      "verified" : true
    }
  },
  "id" : 397744361925910528,
  "created_at" : "2013-11-05 15:17:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/397532747822272513\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/yTBpyDLzvW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYRR7XKIIAAXQmD.png",
      "id_str" : "397532747386068992",
      "id" : 397532747386068992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYRR7XKIIAAXQmD.png",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yTBpyDLzvW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397532747822272513",
  "text" : "Pre-speech routine. http:\/\/t.co\/yTBpyDLzvW",
  "id" : 397532747822272513,
  "created_at" : "2013-11-05 01:16:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/397522580661211136\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/N4pQoqfbAV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYRIrlMCEAA-MUa.jpg",
      "id_str" : "397522580669599744",
      "id" : 397522580669599744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYRIrlMCEAA-MUa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/N4pQoqfbAV"
    } ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 94, 99 ]
    }, {
      "text" : "ENDA",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397522580661211136",
  "text" : "Thanks to today's Senate vote\u2014we're 1 step closer to banning workplace discrimination against #LGBT Americans. #ENDA http:\/\/t.co\/N4pQoqfbAV",
  "id" : 397522580661211136,
  "created_at" : "2013-11-05 00:35:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ENDA",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/tVr8sEvySs",
      "expanded_url" : "http:\/\/go.wh.gov\/eybhJR",
      "display_url" : "go.wh.gov\/eybhJR"
    } ]
  },
  "geo" : { },
  "id_str" : "397512852090544128",
  "text" : "Great news: The Senate just moved forward on banning workplace discrimination based on sexual orientation \u2014&gt; http:\/\/t.co\/tVr8sEvySs #ENDA",
  "id" : 397512852090544128,
  "created_at" : "2013-11-04 23:57:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "indices" : [ 3, 13 ],
      "id_str" : "1712989040",
      "id" : 1712989040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397507058754678784",
  "text" : "RT @Rosholm44: POTUS headed to @PortofNOLA Friday to discuss growing the economy &amp; creating jobs by increasing exports http:\/\/t.co\/0uwKmaT7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/0uwKmaT7wo",
        "expanded_url" : "http:\/\/www.nola.com\/politics\/index.ssf\/2013\/11\/president_obama_will_travel_to.html#incart_river_default",
        "display_url" : "nola.com\/politics\/index\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "397502191784566784",
    "text" : "POTUS headed to @PortofNOLA Friday to discuss growing the economy &amp; creating jobs by increasing exports http:\/\/t.co\/0uwKmaT7wo",
    "id" : 397502191784566784,
    "created_at" : "2013-11-04 23:14:42 +0000",
    "user" : {
      "name" : "Joanna Rosholm",
      "screen_name" : "Rosholm44",
      "protected" : false,
      "id_str" : "1712989040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755544708483538944\/h-5gKL6u_normal.jpg",
      "id" : 1712989040,
      "verified" : true
    }
  },
  "id" : 397507058754678784,
  "created_at" : "2013-11-04 23:34:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Blackhawks",
      "screen_name" : "NHLBlackhawks",
      "indices" : [ 48, 62 ],
      "id_str" : "14498484",
      "id" : 14498484
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/397500541401444353\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/gxajzawcus",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYQ0ouACIAAtckf.jpg",
      "id_str" : "397500541263028224",
      "id" : 397500541263028224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYQ0ouACIAAtckf.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gxajzawcus"
    } ],
    "hashtags" : [ {
      "text" : "SweetHomeChicago",
      "indices" : [ 92, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/WmyznIjNTd",
      "expanded_url" : "http:\/\/go.wh.gov\/hniw5S",
      "display_url" : "go.wh.gov\/hniw5S"
    } ]
  },
  "geo" : { },
  "id_str" : "397500541401444353",
  "text" : "President Obama honors the Stanley Cup Champion @NHLBlackhawks \u2014&gt; http:\/\/t.co\/WmyznIjNTd #SweetHomeChicago, http:\/\/t.co\/gxajzawcus",
  "id" : 397500541401444353,
  "created_at" : "2013-11-04 23:08:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viagra n tayac. Dagr",
      "screen_name" : "DagVega44",
      "indices" : [ 3, 13 ],
      "id_str" : "2785789802",
      "id" : 2785789802
    }, {
      "name" : "Marcia Snyder",
      "screen_name" : "GovSteveBeshear",
      "indices" : [ 16, 32 ],
      "id_str" : "4549215252",
      "id" : 4549215252
    }, {
      "name" : "Ed Schultz",
      "screen_name" : "edshow",
      "indices" : [ 36, 43 ],
      "id_str" : "75052666",
      "id" : 75052666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397496606389714944",
  "text" : "RT @DagVega44: .@GovSteveBeshear on @edshow: \u201CNow for the 1st time in history, every Kentuckian is going to have access to affordable healt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marcia Snyder",
        "screen_name" : "GovSteveBeshear",
        "indices" : [ 1, 17 ],
        "id_str" : "4549215252",
        "id" : 4549215252
      }, {
        "name" : "Ed Schultz",
        "screen_name" : "edshow",
        "indices" : [ 21, 28 ],
        "id_str" : "75052666",
        "id" : 75052666
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397490519330140161",
    "text" : ".@GovSteveBeshear on @edshow: \u201CNow for the 1st time in history, every Kentuckian is going to have access to affordable healthcare.\u201D #ACA",
    "id" : 397490519330140161,
    "created_at" : "2013-11-04 22:28:19 +0000",
    "user" : {
      "name" : "Rob O'Donnell",
      "screen_name" : "RODonnell44",
      "protected" : false,
      "id_str" : "1873091689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664483086738952192\/UukL2zFT_normal.jpg",
      "id" : 1873091689,
      "verified" : true
    }
  },
  "id" : 397496606389714944,
  "created_at" : "2013-11-04 22:52:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/lmN8eivRs0",
      "expanded_url" : "http:\/\/go.wh.gov\/osekWj",
      "display_url" : "go.wh.gov\/osekWj"
    } ]
  },
  "geo" : { },
  "id_str" : "397491066154139648",
  "text" : "Apply for a White House Fellowship\u2014one of America's most prestigious programs for leadership and public service \u2014&gt; http:\/\/t.co\/lmN8eivRs0",
  "id" : 397491066154139648,
  "created_at" : "2013-11-04 22:30:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 22, 33 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397483521431699457",
  "text" : "Kirk from IL couldn't #GetCovered because of a pre-existing condition (aka back surgery). Thanks to #Obamacare, he has affordable insurance.",
  "id" : 397483521431699457,
  "created_at" : "2013-11-04 22:00:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397475964612902913",
  "text" : "\"My new plan gives me better coverage than what I've had with the same insurer and will cost $188\/month less.\" \u2014Larry from CA on #Obamacare",
  "id" : 397475964612902913,
  "created_at" : "2013-11-04 21:30:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 134, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/uvXCniOFSK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/qCj9THqwJK",
      "expanded_url" : "http:\/\/go.wh.gov\/PTnk3a",
      "display_url" : "go.wh.gov\/PTnk3a"
    } ]
  },
  "geo" : { },
  "id_str" : "397470926146523136",
  "text" : "\"I signed up at http:\/\/t.co\/uvXCniOFSK &amp; I'm going to save $2,300\/year on my premium alone\" \u2014Lucy from TX: http:\/\/t.co\/qCj9THqwJK #Obamacare",
  "id" : 397470926146523136,
  "created_at" : "2013-11-04 21:10:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "Erin44",
      "indices" : [ 3, 10 ],
      "id_str" : "41044637",
      "id" : 41044637
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 48, 59 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 81, 93 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397466913070399488",
  "text" : "RT @Erin44: Oh, hey there! I'll be tweeting:\n1. @WhiteHouse social media news\n2. @WeThePeople updates\n3. GIFs\n4. All things Boston sports\n5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 36, 47 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 69, 81 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397457988035698688",
    "text" : "Oh, hey there! I'll be tweeting:\n1. @WhiteHouse social media news\n2. @WeThePeople updates\n3. GIFs\n4. All things Boston sports\n5. List tweets",
    "id" : 397457988035698688,
    "created_at" : "2013-11-04 20:19:03 +0000",
    "user" : {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "protected" : false,
      "id_str" : "2169098419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632215085256081409\/_vjZ92WM_normal.jpg",
      "id" : 2169098419,
      "verified" : true
    }
  },
  "id" : 397466913070399488,
  "created_at" : "2013-11-04 20:54:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/397449962536988673\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ARvpwc6lke",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYQGoplCcAAcOOL.jpg",
      "id_str" : "397449962541182976",
      "id" : 397449962541182976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYQGoplCcAAcOOL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/ARvpwc6lke"
    } ],
    "hashtags" : [ {
      "text" : "Equality",
      "indices" : [ 97, 106 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/Ao8OouCSvK",
      "expanded_url" : "http:\/\/huff.to\/1dGrJMm",
      "display_url" : "huff.to\/1dGrJMm"
    } ]
  },
  "geo" : { },
  "id_str" : "397449962536988673",
  "text" : "RT if you believe EVERY American should be treated equally under the law: http:\/\/t.co\/Ao8OouCSvK #Equality #LGBT, http:\/\/t.co\/ARvpwc6lke",
  "id" : 397449962536988673,
  "created_at" : "2013-11-04 19:47:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SweetHomeChicago",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397444151626575872",
  "text" : "\"To the Bulls, the Bears, the White Sox, and even the Cubs\u2014I\u2019m term-limited, so I want to see you all here soon.\" \u2014Obama #SweetHomeChicago",
  "id" : 397444151626575872,
  "created_at" : "2013-11-04 19:24:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Chicago Blackhawks",
      "screen_name" : "NHLBlackhawks",
      "indices" : [ 56, 70 ],
      "id_str" : "14498484",
      "id" : 14498484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397443924987351040",
  "text" : "RT @WHLive: \"Championships belong in Chicago. So to the @NHLBlackhawks, thank you for bringing it back home!\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chicago Blackhawks",
        "screen_name" : "NHLBlackhawks",
        "indices" : [ 44, 58 ],
        "id_str" : "14498484",
        "id" : 14498484
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397443839318695936",
    "text" : "\"Championships belong in Chicago. So to the @NHLBlackhawks, thank you for bringing it back home!\" \u2014President Obama",
    "id" : 397443839318695936,
    "created_at" : "2013-11-04 19:22:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 397443924987351040,
  "created_at" : "2013-11-04 19:23:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Blackhawks",
      "screen_name" : "NHLBlackhawks",
      "indices" : [ 64, 78 ],
      "id_str" : "14498484",
      "id" : 14498484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/9XdEildumS",
      "expanded_url" : "http:\/\/go.wh.gov\/etmckk",
      "display_url" : "go.wh.gov\/etmckk"
    } ]
  },
  "geo" : { },
  "id_str" : "397441933246611456",
  "text" : "Right now: President Obama honors the 2013 Stanley Cup Champion @NHLBlackhawks at the White House. Watch here \u2014&gt; http:\/\/t.co\/9XdEildumS",
  "id" : 397441933246611456,
  "created_at" : "2013-11-04 19:15:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397433179256008704",
  "text" : "Before: Margaret from WA paid $300\/month for limited coverage.\n\nNow: She has more extensive benefits for $150\/month thanks to #Obamacare.",
  "id" : 397433179256008704,
  "created_at" : "2013-11-04 18:40:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 73, 83 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/vG1jfxickm",
      "expanded_url" : "http:\/\/go.wh.gov\/eAdNCc",
      "display_url" : "go.wh.gov\/eAdNCc"
    } ]
  },
  "geo" : { },
  "id_str" : "397428582542086144",
  "text" : "Americans around the country are already signing up for coverage through #Obamacare. Share your #GetCovered story \u2014&gt; http:\/\/t.co\/vG1jfxickm",
  "id" : 397428582542086144,
  "created_at" : "2013-11-04 18:22:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Acadia National Park",
      "screen_name" : "AcadiaNPS",
      "indices" : [ 72, 82 ],
      "id_str" : "185874758",
      "id" : 185874758
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/397404843415203840\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/uzcBwqtj5d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYPdmW8IYAAV6IJ.jpg",
      "id_str" : "397404843201290240",
      "id" : 397404843201290240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYPdmW8IYAAV6IJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uzcBwqtj5d"
    } ],
    "hashtags" : [ {
      "text" : "Maine",
      "indices" : [ 84, 90 ]
    }, {
      "text" : "autumn",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397407038516760576",
  "text" : "RT @Interior: One of the best places to see fall colors in New England: @AcadiaNPS. #Maine #autumn http:\/\/t.co\/uzcBwqtj5d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Acadia National Park",
        "screen_name" : "AcadiaNPS",
        "indices" : [ 58, 68 ],
        "id_str" : "185874758",
        "id" : 185874758
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/397404843415203840\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/uzcBwqtj5d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BYPdmW8IYAAV6IJ.jpg",
        "id_str" : "397404843201290240",
        "id" : 397404843201290240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYPdmW8IYAAV6IJ.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/uzcBwqtj5d"
      } ],
      "hashtags" : [ {
        "text" : "Maine",
        "indices" : [ 70, 76 ]
      }, {
        "text" : "autumn",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397404843415203840",
    "text" : "One of the best places to see fall colors in New England: @AcadiaNPS. #Maine #autumn http:\/\/t.co\/uzcBwqtj5d",
    "id" : 397404843415203840,
    "created_at" : "2013-11-04 16:47:52 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 397407038516760576,
  "created_at" : "2013-11-04 16:56:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Equality",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Ao8OouCSvK",
      "expanded_url" : "http:\/\/huff.to\/1dGrJMm",
      "display_url" : "huff.to\/1dGrJMm"
    } ]
  },
  "geo" : { },
  "id_str" : "397396690618949632",
  "text" : "\"In the United States of America, who you are and who you love should never be a fireable offense.\" \u2014Obama: http:\/\/t.co\/Ao8OouCSvK #Equality",
  "id" : 397396690618949632,
  "created_at" : "2013-11-04 16:15:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ENDA",
      "indices" : [ 29, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397391544413474816",
  "text" : "RT @Cecilia44: Sen Heller on #ENDA:  \"...discrimination must not be tolerated under any circumstance.\" On to the Senate floor - historic cl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ENDA",
        "indices" : [ 14, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "397377897859534848",
    "text" : "Sen Heller on #ENDA:  \"...discrimination must not be tolerated under any circumstance.\" On to the Senate floor - historic cloture vote today",
    "id" : 397377897859534848,
    "created_at" : "2013-11-04 15:00:48 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 397391544413474816,
  "created_at" : "2013-11-04 15:55:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Equality",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Ao8OouCSvK",
      "expanded_url" : "http:\/\/huff.to\/1dGrJMm",
      "display_url" : "huff.to\/1dGrJMm"
    } ]
  },
  "geo" : { },
  "id_str" : "397387660932554754",
  "text" : "\"Every single American deserves to be treated equally in the eyes of the law.\" \u2014Obama on passing ENDA: http:\/\/t.co\/Ao8OouCSvK #Equality",
  "id" : 397387660932554754,
  "created_at" : "2013-11-04 15:39:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/397199475879329792\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/SFsoqV2lT5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYMi0ZTCEAAsx0J.jpg",
      "id_str" : "397199475677990912",
      "id" : 397199475677990912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYMi0ZTCEAAsx0J.jpg",
      "sizes" : [ {
        "h" : 459,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 783,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 841,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/SFsoqV2lT5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397199475879329792",
  "text" : "All smiles in Brooklyn. http:\/\/t.co\/SFsoqV2lT5",
  "id" : 397199475879329792,
  "created_at" : "2013-11-04 03:11:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/aED2rC7gCn",
      "expanded_url" : "http:\/\/go.wh.gov\/RJGoMz",
      "display_url" : "go.wh.gov\/RJGoMz"
    } ]
  },
  "geo" : { },
  "id_str" : "397143768140230656",
  "text" : "\"We should be doing everything we can to put college within the reach of more young people.\" \u2014Obama: http:\/\/t.co\/aED2rC7gCn #WestWingWeek",
  "id" : 397143768140230656,
  "created_at" : "2013-11-03 23:30:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 91, 104 ]
    }, {
      "text" : "HappyHalloween",
      "indices" : [ 105, 120 ]
    }, {
      "text" : "MakeCollegeAffordable",
      "indices" : [ 121, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/HaeKrnblgG",
      "expanded_url" : "http:\/\/go.wh.gov\/QDNdW9",
      "display_url" : "go.wh.gov\/QDNdW9"
    } ]
  },
  "geo" : { },
  "id_str" : "397105790244229120",
  "text" : "Your inside look at President Obama's week at the White House \u2014&gt; http:\/\/t.co\/HaeKrnblgG #WestWingWeek #HappyHalloween #MakeCollegeAffordable",
  "id" : 397105790244229120,
  "created_at" : "2013-11-03 20:59:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/j4G2CnFsWC",
      "expanded_url" : "http:\/\/go.wh.gov\/wj5Tp5",
      "display_url" : "go.wh.gov\/wj5Tp5"
    } ]
  },
  "geo" : { },
  "id_str" : "396803520067690496",
  "text" : "Watch President Obama's message to you on how we can keep growing our economy from the middle-class out \u2014&gt; http:\/\/t.co\/j4G2CnFsWC",
  "id" : 396803520067690496,
  "created_at" : "2013-11-03 00:58:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/396758176072073216\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/VCJSJNgbDB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYGRdXHCUAAuCeh.jpg",
      "id_str" : "396758175791075328",
      "id" : 396758175791075328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYGRdXHCUAAuCeh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/VCJSJNgbDB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/MZxMezXoJ6",
      "expanded_url" : "http:\/\/go.wh.gov\/y9kPSU",
      "display_url" : "go.wh.gov\/y9kPSU"
    } ]
  },
  "geo" : { },
  "id_str" : "396758176072073216",
  "text" : "\"Over the past 3.5 years, our businesses have created over 7.5 million new jobs.\" \u2014Obama: http:\/\/t.co\/MZxMezXoJ6, http:\/\/t.co\/VCJSJNgbDB",
  "id" : 396758176072073216,
  "created_at" : "2013-11-02 21:58:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/396678141009092608\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/xEFLH0dNzL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYFIqs3CAAAficP.jpg",
      "id_str" : "396678140618997760",
      "id" : 396678140618997760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYFIqs3CAAAficP.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/xEFLH0dNzL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/LQAmMLjR0y",
      "expanded_url" : "http:\/\/go.wh.gov\/QQfnyU",
      "display_url" : "go.wh.gov\/QQfnyU"
    } ]
  },
  "geo" : { },
  "id_str" : "396678141009092608",
  "text" : "\"Since I took office, we\u2019ve cut our deficits by more than half.\" \u2014President Obama: http:\/\/t.co\/LQAmMLjR0y, http:\/\/t.co\/xEFLH0dNzL",
  "id" : 396678141009092608,
  "created_at" : "2013-11-02 16:40:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/41lPAnv4LA",
      "expanded_url" : "http:\/\/go.wh.gov\/X4fyPA",
      "display_url" : "go.wh.gov\/X4fyPA"
    } ]
  },
  "geo" : { },
  "id_str" : "396639184531623936",
  "text" : "\"Our economy doesn\u2019t grow from the top-down. It grows from the middle-class out.\" \u2014Obama in his Weekly Address: http:\/\/t.co\/41lPAnv4LA",
  "id" : 396639184531623936,
  "created_at" : "2013-11-02 14:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/jQF75BzdY5",
      "expanded_url" : "http:\/\/go.wh.gov\/K3S79A",
      "display_url" : "go.wh.gov\/K3S79A"
    } ]
  },
  "geo" : { },
  "id_str" : "396400975377756161",
  "text" : "Be a fly on the wall for an inside look at President Obama's week at the White House \u2014&gt; http:\/\/t.co\/jQF75BzdY5 #WestWingWeek",
  "id" : 396400975377756161,
  "created_at" : "2013-11-01 22:18:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/BHioeGCrZp",
      "expanded_url" : "http:\/\/go.wh.gov\/BqzyhT",
      "display_url" : "go.wh.gov\/BqzyhT"
    } ]
  },
  "geo" : { },
  "id_str" : "396371369853583360",
  "text" : "#GetCovered because insurers can no longer impose lifetime limits on essential health benefits \u2014&gt; http:\/\/t.co\/BHioeGCrZp #Obamacare",
  "id" : 396371369853583360,
  "created_at" : "2013-11-01 20:21:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 117, 128 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/TlMzEOQm4m",
      "expanded_url" : "http:\/\/go.wh.gov\/L6iNXY",
      "display_url" : "go.wh.gov\/L6iNXY"
    } ]
  },
  "geo" : { },
  "id_str" : "396346242860474368",
  "text" : "RT if you agree: Everyone who needs or wants better health coverage should be able to get it. http:\/\/t.co\/TlMzEOQm4m #GetCovered #Obamacare",
  "id" : 396346242860474368,
  "created_at" : "2013-11-01 18:41:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 68, 78 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/aPWtvEgAd6",
      "expanded_url" : "http:\/\/go.wh.gov\/X5QjsL",
      "display_url" : "go.wh.gov\/X5QjsL"
    } ]
  },
  "geo" : { },
  "id_str" : "396337894505213953",
  "text" : "If you've already signed up for affordable health insurance through #Obamacare, share your #GetCovered story \u2014&gt; http:\/\/t.co\/aPWtvEgAd6",
  "id" : 396337894505213953,
  "created_at" : "2013-11-01 18:08:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396328244678365184",
  "text" : "RT @VP: VP met w\/ disabilities &amp; veterans advocacy groups at the WH today on the Admin\u2019s strong support for ratification of the Disabilitie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396316482109325312",
    "text" : "VP met w\/ disabilities &amp; veterans advocacy groups at the WH today on the Admin\u2019s strong support for ratification of the Disabilities Treaty.",
    "id" : 396316482109325312,
    "created_at" : "2013-11-01 16:43:07 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 396328244678365184,
  "created_at" : "2013-11-01 17:29:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/396320570016399360\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/76g7p82aLj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYADdV6CAAADwvP.jpg",
      "id_str" : "396320569840238592",
      "id" : 396320569840238592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYADdV6CAAADwvP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/76g7p82aLj"
    } ],
    "hashtags" : [ {
      "text" : "FactsOnly",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396320570016399360",
  "text" : "Public lands are awesome. They:\n1. Add $45 billion to the economy\n2. Support 372K jobs\n3. Are beautiful\n#FactsOnly http:\/\/t.co\/76g7p82aLj",
  "id" : 396320570016399360,
  "created_at" : "2013-11-01 16:59:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 37, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396313701135171584",
  "text" : "RT @ErnestMoniz: No excuses. We must #ActOnClimate. Read my statement on the President's executive order on climate preparedness: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 20, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/wPIPg5Kl4p",
        "expanded_url" : "http:\/\/go.usa.gov\/Wjfm",
        "display_url" : "go.usa.gov\/Wjfm"
      } ]
    },
    "geo" : { },
    "id_str" : "396289922866610176",
    "text" : "No excuses. We must #ActOnClimate. Read my statement on the President's executive order on climate preparedness: http:\/\/t.co\/wPIPg5Kl4p",
    "id" : 396289922866610176,
    "created_at" : "2013-11-01 14:57:34 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 396313701135171584,
  "created_at" : "2013-11-01 16:32:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396308698202918912",
  "text" : "RT @WhiteHouseCEQ: President Obama took new steps today to help communities build resilience &amp; prepare for climate change http:\/\/t.co\/qmLJ8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActonClimate",
        "indices" : [ 130, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/qmLJ8rmT5e",
        "expanded_url" : "http:\/\/1.usa.gov\/HySlmQ",
        "display_url" : "1.usa.gov\/HySlmQ"
      } ]
    },
    "geo" : { },
    "id_str" : "396307148952461313",
    "text" : "President Obama took new steps today to help communities build resilience &amp; prepare for climate change http:\/\/t.co\/qmLJ8rmT5e #ActonClimate",
    "id" : 396307148952461313,
    "created_at" : "2013-11-01 16:06:02 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 396308698202918912,
  "created_at" : "2013-11-01 16:12:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 72, 82 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/PYzZAMtE57",
      "expanded_url" : "http:\/\/go.wh.gov\/DQk2wx",
      "display_url" : "go.wh.gov\/DQk2wx"
    } ]
  },
  "geo" : { },
  "id_str" : "396298185678675968",
  "text" : "Americans are already signing up for affordable health coverage through #Obamacare. Share your #GetCovered story \u2014&gt; http:\/\/t.co\/PYzZAMtE57",
  "id" : 396298185678675968,
  "created_at" : "2013-11-01 15:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/MEN1lHKW1Y",
      "expanded_url" : "http:\/\/go.wh.gov\/JU7XV3",
      "display_url" : "go.wh.gov\/JU7XV3"
    } ]
  },
  "geo" : { },
  "id_str" : "396288118862532608",
  "text" : "Here's why we passed #Obamacare: To help more people like Janice, Zohre, and David afford quality health insurance \u2014&gt; http:\/\/t.co\/MEN1lHKW1Y",
  "id" : 396288118862532608,
  "created_at" : "2013-11-01 14:50:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/396279213067485184\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/t4KL1i0sds",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BX_d2C_CMAE7Ppc.jpg",
      "id_str" : "396279212815822849",
      "id" : 396279212815822849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BX_d2C_CMAE7Ppc.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/t4KL1i0sds"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 10, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396279213067485184",
  "text" : "Thanks to #Obamacare, insurers CAN'T:\n1. Deny you coverage.\n2. Drop you if you get sick.\n3. Drop you as a customer. http:\/\/t.co\/t4KL1i0sds",
  "id" : 396279213067485184,
  "created_at" : "2013-11-01 14:15:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]