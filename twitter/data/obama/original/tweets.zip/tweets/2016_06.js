Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 53, 60 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/z4GjLKvg8o",
      "expanded_url" : "http:\/\/snpy.tv\/29fanwv",
      "display_url" : "snpy.tv\/29fanwv"
    } ]
  },
  "geo" : { },
  "id_str" : "748694443922956289",
  "text" : "2016 was the last commencement season for @POTUS and @FLOTUS. Watch this year\u2019s addresses: https:\/\/t.co\/z4GjLKvg8o",
  "id" : 748694443922956289,
  "created_at" : "2016-07-01 01:47:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DataDrivenJustice",
      "indices" : [ 20, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748646614936469505",
  "text" : "RT @whitehouseostp: #DataDrivenJustice leads to better outcomes, smaller jails, and money saved for local communities. https:\/\/t.co\/sHeMKlr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/748639355510501378\/photo\/1",
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/sHeMKlr93N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmOzbL4UkAA5xWp.jpg",
        "id_str" : "748639242700492800",
        "id" : 748639242700492800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmOzbL4UkAA5xWp.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/sHeMKlr93N"
      } ],
      "hashtags" : [ {
        "text" : "DataDrivenJustice",
        "indices" : [ 0, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748639355510501378",
    "text" : "#DataDrivenJustice leads to better outcomes, smaller jails, and money saved for local communities. https:\/\/t.co\/sHeMKlr93N",
    "id" : 748639355510501378,
    "created_at" : "2016-06-30 22:08:26 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 748646614936469505,
  "created_at" : "2016-06-30 22:37:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748622425475080193",
  "text" : "RT @POTUS: The list goes on. When Members return, I hope they'll share my commitment to work together to do what must be done. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/748621673578958849\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/l8nChcXpml",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CmOjOUPWEAQIbZG.jpg",
        "id_str" : "748621429420199940",
        "id" : 748621429420199940,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CmOjOUPWEAQIbZG.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/l8nChcXpml"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "748621170015076352",
    "geo" : { },
    "id_str" : "748621673578958849",
    "in_reply_to_user_id" : 1536791610,
    "text" : "The list goes on. When Members return, I hope they'll share my commitment to work together to do what must be done. https:\/\/t.co\/l8nChcXpml",
    "id" : 748621673578958849,
    "in_reply_to_status_id" : 748621170015076352,
    "created_at" : "2016-06-30 20:58:10 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 748622425475080193,
  "created_at" : "2016-06-30 21:01:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748622375890018304",
  "text" : "RT @POTUS: Americans still need and are asking Congress to pass commonsense gun laws that strengthen background checks and keep our communi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "748620897309757440",
    "geo" : { },
    "id_str" : "748621170015076352",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Americans still need and are asking Congress to pass commonsense gun laws that strengthen background checks and keep our communities safe.",
    "id" : 748621170015076352,
    "in_reply_to_status_id" : 748620897309757440,
    "created_at" : "2016-06-30 20:56:10 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 748622375890018304,
  "created_at" : "2016-06-30 21:00:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748622327491883008",
  "text" : "RT @POTUS: After more than 100 days, the Supreme Court still needs its 9th judge, but the Senate GOP refuses to do its job and consider Jud\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "748620582216884224",
    "geo" : { },
    "id_str" : "748620897309757440",
    "in_reply_to_user_id" : 1536791610,
    "text" : "After more than 100 days, the Supreme Court still needs its 9th judge, but the Senate GOP refuses to do its job and consider Judge Garland.",
    "id" : 748620897309757440,
    "in_reply_to_status_id" : 748620582216884224,
    "created_at" : "2016-06-30 20:55:05 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 748622327491883008,
  "created_at" : "2016-06-30 21:00:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748622292960182272",
  "text" : "RT @POTUS: Congress is leaving a hefty to-do list undone. Health officials still need emergency funding to effectively protect Americans fr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "748620388175798272",
    "geo" : { },
    "id_str" : "748620582216884224",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Congress is leaving a hefty to-do list undone. Health officials still need emergency funding to effectively protect Americans from Zika.",
    "id" : 748620582216884224,
    "in_reply_to_status_id" : 748620388175798272,
    "created_at" : "2016-06-30 20:53:50 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 748622292960182272,
  "created_at" : "2016-06-30 21:00:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748622246877376512",
  "text" : "RT @POTUS: Proud to sign laws to improve transparency and avert a crisis in Puerto Rico. I'd hoped to use my pen more often before Congress\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748620388175798272",
    "text" : "Proud to sign laws to improve transparency and avert a crisis in Puerto Rico. I'd hoped to use my pen more often before Congress left town.",
    "id" : 748620388175798272,
    "created_at" : "2016-06-30 20:53:03 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 748622246877376512,
  "created_at" : "2016-06-30 21:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Econ Engage",
      "screen_name" : "EconEngage",
      "indices" : [ 3, 14 ],
      "id_str" : "211955846",
      "id" : 211955846
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 59, 70 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "refugeeswelcome",
      "indices" : [ 111, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/iIGC0L4PJS",
      "expanded_url" : "https:\/\/goo.gl\/V8rK9l",
      "display_url" : "goo.gl\/V8rK9l"
    } ]
  },
  "geo" : { },
  "id_str" : "748609053417426944",
  "text" : "RT @EconEngage: Congrats to the 15 companies answering the @WhiteHouse Call to Action: https:\/\/t.co\/iIGC0L4PJS #refugeeswelcome https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 43, 54 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EconEngage\/status\/748598318855524352\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/WDRYkxkahy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmOOM7FWYAAn4ia.jpg",
        "id_str" : "748598315743338496",
        "id" : 748598315743338496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmOOM7FWYAAn4ia.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/WDRYkxkahy"
      } ],
      "hashtags" : [ {
        "text" : "refugeeswelcome",
        "indices" : [ 95, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/iIGC0L4PJS",
        "expanded_url" : "https:\/\/goo.gl\/V8rK9l",
        "display_url" : "goo.gl\/V8rK9l"
      } ]
    },
    "geo" : { },
    "id_str" : "748598318855524352",
    "text" : "Congrats to the 15 companies answering the @WhiteHouse Call to Action: https:\/\/t.co\/iIGC0L4PJS #refugeeswelcome https:\/\/t.co\/WDRYkxkahy",
    "id" : 748598318855524352,
    "created_at" : "2016-06-30 19:25:22 +0000",
    "user" : {
      "name" : "Econ Engage",
      "screen_name" : "EconEngage",
      "protected" : false,
      "id_str" : "211955846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760547785208848384\/FaSPgzoS_normal.jpg",
      "id" : 211955846,
      "verified" : true
    }
  },
  "id" : 748609053417426944,
  "created_at" : "2016-06-30 20:08:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Diamond",
      "screen_name" : "Rob44",
      "indices" : [ 3, 9 ],
      "id_str" : "3065348142",
      "id" : 3065348142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 106, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/QbOxyKHVeb",
      "expanded_url" : "http:\/\/AidRefugees.gov",
      "display_url" : "AidRefugees.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "748601959989534720",
  "text" : "RT @Rob44: We're calling on America's business leaders to help refugees rebuild \u2192 https:\/\/t.co\/QbOxyKHVeb #RefugeesWelcome https:\/\/t.co\/JU8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Rob44\/status\/748600368787906560\/photo\/1",
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/JU8T91huOU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmOQELnUsAAJoQW.jpg",
        "id_str" : "748600364585234432",
        "id" : 748600364585234432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmOQELnUsAAJoQW.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/JU8T91huOU"
      } ],
      "hashtags" : [ {
        "text" : "RefugeesWelcome",
        "indices" : [ 95, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/QbOxyKHVeb",
        "expanded_url" : "http:\/\/AidRefugees.gov",
        "display_url" : "AidRefugees.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "748600368787906560",
    "text" : "We're calling on America's business leaders to help refugees rebuild \u2192 https:\/\/t.co\/QbOxyKHVeb #RefugeesWelcome https:\/\/t.co\/JU8T91huOU",
    "id" : 748600368787906560,
    "created_at" : "2016-06-30 19:33:30 +0000",
    "user" : {
      "name" : "Rob Diamond",
      "screen_name" : "Rob44",
      "protected" : false,
      "id_str" : "3065348142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628268968214724608\/D4RYPQmQ_normal.jpg",
      "id" : 3065348142,
      "verified" : true
    }
  },
  "id" : 748601959989534720,
  "created_at" : "2016-06-30 19:39:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IBMPolicy",
      "screen_name" : "IBMpolicy",
      "indices" : [ 3, 13 ],
      "id_str" : "608182396",
      "id" : 608182396
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IBM",
      "indices" : [ 15, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Q5CRskGLqD",
      "expanded_url" : "http:\/\/ibm.biz\/Bdrdep",
      "display_url" : "ibm.biz\/Bdrdep"
    } ]
  },
  "geo" : { },
  "id_str" : "748598354481922048",
  "text" : "RT @IBMpolicy: #IBM is proud to join @POTUS\u2019 call-to-action on the global refugee crisis. Here\u2019s how we\u2019re helping https:\/\/t.co\/Q5CRskGLqD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 22, 28 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IBM",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "RefugeesWelcome",
        "indices" : [ 124, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/Q5CRskGLqD",
        "expanded_url" : "http:\/\/ibm.biz\/Bdrdep",
        "display_url" : "ibm.biz\/Bdrdep"
      } ]
    },
    "geo" : { },
    "id_str" : "748593162201948160",
    "text" : "#IBM is proud to join @POTUS\u2019 call-to-action on the global refugee crisis. Here\u2019s how we\u2019re helping https:\/\/t.co\/Q5CRskGLqD #RefugeesWelcome",
    "id" : 748593162201948160,
    "created_at" : "2016-06-30 19:04:52 +0000",
    "user" : {
      "name" : "IBMPolicy",
      "screen_name" : "IBMpolicy",
      "protected" : false,
      "id_str" : "608182396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2307535668\/r1ap5z8zurro4pohm1zy_normal.jpeg",
      "id" : 608182396,
      "verified" : false
    }
  },
  "id" : 748598354481922048,
  "created_at" : "2016-06-30 19:25:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TripAdvisor",
      "screen_name" : "TripAdvisor",
      "indices" : [ 3, 15 ],
      "id_str" : "16365636",
      "id" : 16365636
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 43, 54 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 110, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748597572584022016",
  "text" : "RT @TripAdvisor: We are joining @POTUS and @WhiteHouse in challenging the U.S. private sector to aid refugees #RefugeesWelcome https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 26, 37 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TripAdvisor\/status\/748592192705396738\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/Q1CM0lmIoG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmOIoUbXIAA2Yia.jpg",
        "id_str" : "748592189333250048",
        "id" : 748592189333250048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmOIoUbXIAA2Yia.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Q1CM0lmIoG"
      } ],
      "hashtags" : [ {
        "text" : "RefugeesWelcome",
        "indices" : [ 93, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748592192705396738",
    "text" : "We are joining @POTUS and @WhiteHouse in challenging the U.S. private sector to aid refugees #RefugeesWelcome https:\/\/t.co\/Q1CM0lmIoG",
    "id" : 748592192705396738,
    "created_at" : "2016-06-30 19:01:01 +0000",
    "user" : {
      "name" : "TripAdvisor",
      "screen_name" : "TripAdvisor",
      "protected" : false,
      "id_str" : "16365636",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472494793616945153\/nAKMJI27_normal.jpeg",
      "id" : 16365636,
      "verified" : true
    }
  },
  "id" : 748597572584022016,
  "created_at" : "2016-06-30 19:22:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/748595078092951552\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/GTudF9rp4F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmOLQEgWYAEtbbh.jpg",
      "id_str" : "748595071277228033",
      "id" : 748595071277228033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmOLQEgWYAEtbbh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/GTudF9rp4F"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/1HwsI2MVd5",
      "expanded_url" : "http:\/\/AidRefugees.gov",
      "display_url" : "AidRefugees.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "748595078092951552",
  "text" : "More than 21 million refugees are in need of help. Learn how you can help many rebuild \u2192 https:\/\/t.co\/1HwsI2MVd5 https:\/\/t.co\/GTudF9rp4F",
  "id" : 748595078092951552,
  "created_at" : "2016-06-30 19:12:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 3, 19 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/VFqJWfElFz",
      "expanded_url" : "http:\/\/1.usa.gov\/29aTlPT",
      "display_url" : "1.usa.gov\/29aTlPT"
    } ]
  },
  "geo" : { },
  "id_str" : "748584427131932672",
  "text" : "RT @NatlParkService: New study estimates the total economic value of our parks &amp; programs to be $92 billion https:\/\/t.co\/VFqJWfElFz https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NatlParkService\/status\/748535461186924544\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/aVu18GDKGi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmNUC0XVYAE0sjS.jpg",
        "id_str" : "748534370466619393",
        "id" : 748534370466619393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmNUC0XVYAE0sjS.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/aVu18GDKGi"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/VFqJWfElFz",
        "expanded_url" : "http:\/\/1.usa.gov\/29aTlPT",
        "display_url" : "1.usa.gov\/29aTlPT"
      } ]
    },
    "geo" : { },
    "id_str" : "748535461186924544",
    "text" : "New study estimates the total economic value of our parks &amp; programs to be $92 billion https:\/\/t.co\/VFqJWfElFz https:\/\/t.co\/aVu18GDKGi",
    "id" : 748535461186924544,
    "created_at" : "2016-06-30 15:15:35 +0000",
    "user" : {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "protected" : false,
      "id_str" : "36771809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2179200522\/NPS_SocialMediaProfilePic_Blue_normal.png",
      "id" : 36771809,
      "verified" : true
    }
  },
  "id" : 748584427131932672,
  "created_at" : "2016-06-30 18:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748541507817201668",
  "text" : "RT @POTUS: Until next time, Justin. Good to know that Canada and the world will benefit from your leadership for years to come. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/T10g64niul",
        "expanded_url" : "https:\/\/twitter.com\/JustinTrudeau\/status\/748313331673501696",
        "display_url" : "twitter.com\/JustinTrudeau\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "748541124524929024",
    "text" : "Until next time, Justin. Good to know that Canada and the world will benefit from your leadership for years to come. https:\/\/t.co\/T10g64niul",
    "id" : 748541124524929024,
    "created_at" : "2016-06-30 15:38:05 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 748541507817201668,
  "created_at" : "2016-06-30 15:39:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Trudeau",
      "screen_name" : "JustinTrudeau",
      "indices" : [ 3, 17 ],
      "id_str" : "14260960",
      "id" : 14260960
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JustinTrudeau\/status\/748313331673501696\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/8Q5zCSU3CK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmKLARDXEAA67RH.jpg",
      "id_str" : "748313324790681600",
      "id" : 748313324790681600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmKLARDXEAA67RH.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/8Q5zCSU3CK"
    } ],
    "hashtags" : [ {
      "text" : "NALS2016",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748321594469027840",
  "text" : "RT @JustinTrudeau: One more for the road! \u00C0 la prochaine. #NALS2016 https:\/\/t.co\/8Q5zCSU3CK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JustinTrudeau\/status\/748313331673501696\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/8Q5zCSU3CK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmKLARDXEAA67RH.jpg",
        "id_str" : "748313324790681600",
        "id" : 748313324790681600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmKLARDXEAA67RH.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/8Q5zCSU3CK"
      } ],
      "hashtags" : [ {
        "text" : "NALS2016",
        "indices" : [ 39, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748313331673501696",
    "text" : "One more for the road! \u00C0 la prochaine. #NALS2016 https:\/\/t.co\/8Q5zCSU3CK",
    "id" : 748313331673501696,
    "created_at" : "2016-06-30 00:32:55 +0000",
    "user" : {
      "name" : "Justin Trudeau",
      "screen_name" : "JustinTrudeau",
      "protected" : false,
      "id_str" : "14260960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797443159198470144\/1AwTnliW_normal.jpg",
      "id" : 14260960,
      "verified" : true
    }
  },
  "id" : 748321594469027840,
  "created_at" : "2016-06-30 01:05:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/748304951646904320\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/zmop7XPiH6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmKDYYuUcAAYQL8.jpg",
      "id_str" : "748304943073751040",
      "id" : 748304943073751040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmKDYYuUcAAYQL8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/zmop7XPiH6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748304951646904320",
  "text" : "Puerto Ricans are American citizens. Today, the Senate did its job to restore their hope. Read @POTUS's statement: https:\/\/t.co\/zmop7XPiH6",
  "id" : 748304951646904320,
  "created_at" : "2016-06-29 23:59:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSinCanada",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/ElXHpLPZAJ",
      "expanded_url" : "http:\/\/snpy.tv\/293Aymk",
      "display_url" : "snpy.tv\/293Aymk"
    } ]
  },
  "geo" : { },
  "id_str" : "748303804827734016",
  "text" : "\"Canadians and Americans, allies and friends, now and forever.\" \u2014@POTUS #POTUSinCanada https:\/\/t.co\/ElXHpLPZAJ",
  "id" : 748303804827734016,
  "created_at" : "2016-06-29 23:55:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 88, 101 ]
    }, {
      "text" : "POTUSinCanada",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/pGOktWIuVN",
      "expanded_url" : "http:\/\/snpy.tv\/29ggzDc",
      "display_url" : "snpy.tv\/29ggzDc"
    } ]
  },
  "geo" : { },
  "id_str" : "748301304141746178",
  "text" : "Climate change is happening now.\nIt's no longer an issue we can put off for the future.\n#ActOnClimate #POTUSinCanada\nhttps:\/\/t.co\/pGOktWIuVN",
  "id" : 748301304141746178,
  "created_at" : "2016-06-29 23:45:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSinCanada",
      "indices" : [ 61, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/R1GSi6PRp6",
      "expanded_url" : "http:\/\/snpy.tv\/295en1D",
      "display_url" : "snpy.tv\/295en1D"
    } ]
  },
  "geo" : { },
  "id_str" : "748298035084533760",
  "text" : "\"We honor those who gave their lives for all of us.\" \u2014@POTUS #POTUSinCanada https:\/\/t.co\/R1GSi6PRp6",
  "id" : 748298035084533760,
  "created_at" : "2016-06-29 23:32:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSinCanada",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748295184446783488",
  "text" : "RT @NSC44: \"We must not waver in embracing our values, our best selves, our histories as nations of immigrants.\"-#POTUSinCanada\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUSinCanada",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ichcE4RZaj",
        "expanded_url" : "http:\/\/snpy.tv\/29aFnz3",
        "display_url" : "snpy.tv\/29aFnz3"
      } ]
    },
    "geo" : { },
    "id_str" : "748287493108207617",
    "text" : "\"We must not waver in embracing our values, our best selves, our histories as nations of immigrants.\"-#POTUSinCanada\nhttps:\/\/t.co\/ichcE4RZaj",
    "id" : 748287493108207617,
    "created_at" : "2016-06-29 22:50:15 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 748295184446783488,
  "created_at" : "2016-06-29 23:20:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Anderson",
      "screen_name" : "Charlie44",
      "indices" : [ 3, 13 ],
      "id_str" : "4796005523",
      "id" : 4796005523
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 46, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748292301181587456",
  "text" : "RT @Charlie44: In Canada, @POTUS explains why #TPP will let the US, not China, write the trade rules that will benefit our workers. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 31, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/wBQx6zMvgW",
        "expanded_url" : "http:\/\/snpy.tv\/29fOb4o",
        "display_url" : "snpy.tv\/29fOb4o"
      } ]
    },
    "geo" : { },
    "id_str" : "748274535267348482",
    "text" : "In Canada, @POTUS explains why #TPP will let the US, not China, write the trade rules that will benefit our workers. https:\/\/t.co\/wBQx6zMvgW",
    "id" : 748274535267348482,
    "created_at" : "2016-06-29 21:58:46 +0000",
    "user" : {
      "name" : "Charlie Anderson",
      "screen_name" : "Charlie44",
      "protected" : false,
      "id_str" : "4796005523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689598827691520000\/6gRd26qn_normal.jpg",
      "id" : 4796005523,
      "verified" : true
    }
  },
  "id" : 748292301181587456,
  "created_at" : "2016-06-29 23:09:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748287684985167878",
  "text" : "\"On that freedom road, let's stay true to the values that make us who we are\u2014Canadians and Americans, allies and friends, now and forever.\"",
  "id" : 748287684985167878,
  "created_at" : "2016-06-29 22:51:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748287350925574144",
  "text" : "RT @WHLive: \"When refugees escape barrel bombs &amp; torture, migrants cross deserts &amp; seas seeking a better life, we cannot simply look the ot\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748286362298769408",
    "text" : "\"When refugees escape barrel bombs &amp; torture, migrants cross deserts &amp; seas seeking a better life, we cannot simply look the other way.\"",
    "id" : 748286362298769408,
    "created_at" : "2016-06-29 22:45:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 748287350925574144,
  "created_at" : "2016-06-29 22:49:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748286872951087105",
  "text" : "\"We were all once strangers.\" \"The mothers, the fathers, the children we see today\u2014they\u2019re us.\"\n\"We can\u2019t forsake them.\"\n\u2014@POTUS on refugees",
  "id" : 748286872951087105,
  "created_at" : "2016-06-29 22:47:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSinCanada",
      "indices" : [ 110, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748286279524159488",
  "text" : "\"We must not waver in embracing our values, our best selves, our histories as nations of immigrants.\" \u2014@POTUS #POTUSinCanada",
  "id" : 748286279524159488,
  "created_at" : "2016-06-29 22:45:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748285634121441280",
  "text" : "\"Our work won\u2019t be finished until all women in our countries are truly equal\u2014paid equally, treated equally, given the same opportunities\"",
  "id" : 748285634121441280,
  "created_at" : "2016-06-29 22:42:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/748285163864461312\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/k8viDyy0Fr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmJxMGgWIAAbbUi.jpg",
      "id_str" : "748284940815572992",
      "id" : 748284940815572992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmJxMGgWIAAbbUi.jpg",
      "sizes" : [ {
        "h" : 1855,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1319,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/k8viDyy0Fr"
    } ],
    "hashtags" : [ {
      "text" : "POTUSinCanada",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748285163864461312",
  "text" : "\"The colors of the rainbow flag have flown on Parliament Hill. They have lit up the White House.\" \u2014#POTUSinCanada https:\/\/t.co\/k8viDyy0Fr",
  "id" : 748285163864461312,
  "created_at" : "2016-06-29 22:41:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/748284279398998017\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/hHrcVhkhmR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmJwQGhWEAECfka.jpg",
      "id_str" : "748283910027612161",
      "id" : 748283910027612161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmJwQGhWEAECfka.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/hHrcVhkhmR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748284279398998017",
  "text" : "\"If Canada can do it and the U.S. can do it, the whole world can unleash economic growth and protect our planet.\" https:\/\/t.co\/hHrcVhkhmR",
  "id" : 748284279398998017,
  "created_at" : "2016-06-29 22:37:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/748283810287095810\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/UvlzA1FQ2H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmJwGWzXEAAPjSE.jpg",
      "id_str" : "748283742599450624",
      "id" : 748283742599450624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmJwGWzXEAAPjSE.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/UvlzA1FQ2H"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748283810287095810",
  "text" : "\"When I became the first U.S. President to visit the Arctic, I could see the effects myself.\" \u2014@POTUS #ActOnClimate https:\/\/t.co\/UvlzA1FQ2H",
  "id" : 748283810287095810,
  "created_at" : "2016-06-29 22:35:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748282219416920065",
  "text" : "\"We stand united against terrorist networks &amp; ideologies that have reached to the very doorstep of this hall\" \u2014@POTUS in Canadian Parliament",
  "id" : 748282219416920065,
  "created_at" : "2016-06-29 22:29:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSinCanada",
      "indices" : [ 108, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748281433408548864",
  "text" : "\"Wealthy countries like ours cannot reach our full potential while others remain mired in poverty.\" \u2014@POTUS #POTUSinCanada",
  "id" : 748281433408548864,
  "created_at" : "2016-06-29 22:26:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 138, 144 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748279534580023296",
  "text" : "\"If the financial crisis &amp; recent recession taught us anything, it\u2019s that economies do better when everyone has a chance to succeed\" \u2014@POTUS",
  "id" : 748279534580023296,
  "created_at" : "2016-06-29 22:18:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSinCanada",
      "indices" : [ 12, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748277603082059776",
  "text" : "RT @WHLive: #POTUSinCanada: We\u2019re bound as well by the service of those who\u2019ve defended us at:\nFlanders Field\nNormandy\nThe Balkans\nAfghanis\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUSinCanada",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748277391185821696",
    "text" : "#POTUSinCanada: We\u2019re bound as well by the service of those who\u2019ve defended us at:\nFlanders Field\nNormandy\nThe Balkans\nAfghanistan\nIraq",
    "id" : 748277391185821696,
    "created_at" : "2016-06-29 22:10:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 748277603082059776,
  "created_at" : "2016-06-29 22:10:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSinCanada",
      "indices" : [ 105, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748276459186364417",
  "text" : "\"We Americans can never say it enough\u2014we could not ask for a better friend or ally than Canada.\" \u2014@POTUS #POTUSinCanada",
  "id" : 748276459186364417,
  "created_at" : "2016-06-29 22:06:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSinCanada",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Yuxirc3fFV",
      "expanded_url" : "http:\/\/go.wh.gov\/Z7qXzY",
      "display_url" : "go.wh.gov\/Z7qXzY"
    } ]
  },
  "geo" : { },
  "id_str" : "748275751468810245",
  "text" : "RT @WHLive: Happening now: Watch @POTUS deliver an address to the Canadian Parliament: https:\/\/t.co\/Yuxirc3fFV #POTUSinCanada https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 21, 27 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/748275594908078080\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/8OUQDsuYFZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmJoVEzWMAQ7BVP.jpg",
        "id_str" : "748275199372570628",
        "id" : 748275199372570628,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmJoVEzWMAQ7BVP.jpg",
        "sizes" : [ {
          "h" : 589,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 770,
          "resize" : "fit",
          "w" : 1569
        }, {
          "h" : 770,
          "resize" : "fit",
          "w" : 1569
        }, {
          "h" : 334,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/8OUQDsuYFZ"
      } ],
      "hashtags" : [ {
        "text" : "POTUSinCanada",
        "indices" : [ 99, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/Yuxirc3fFV",
        "expanded_url" : "http:\/\/go.wh.gov\/Z7qXzY",
        "display_url" : "go.wh.gov\/Z7qXzY"
      } ]
    },
    "geo" : { },
    "id_str" : "748275594908078080",
    "text" : "Happening now: Watch @POTUS deliver an address to the Canadian Parliament: https:\/\/t.co\/Yuxirc3fFV #POTUSinCanada https:\/\/t.co\/8OUQDsuYFZ",
    "id" : 748275594908078080,
    "created_at" : "2016-06-29 22:02:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 748275751468810245,
  "created_at" : "2016-06-29 22:03:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSinCanada",
      "indices" : [ 108, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/guI0IVemaJ",
      "expanded_url" : "http:\/\/go.wh.gov\/Z7qXzY",
      "display_url" : "go.wh.gov\/Z7qXzY"
    } ]
  },
  "geo" : { },
  "id_str" : "748264315749269504",
  "text" : "Tune in at 5:25pm ET to watch @POTUS deliver an address to the Canadian Parliament: https:\/\/t.co\/guI0IVemaJ #POTUSinCanada",
  "id" : 748264315749269504,
  "created_at" : "2016-06-29 21:18:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/zDsd8KaZEa",
      "expanded_url" : "http:\/\/snpy.tv\/29dbr5H",
      "display_url" : "snpy.tv\/29dbr5H"
    } ]
  },
  "geo" : { },
  "id_str" : "748242058683441153",
  "text" : "\"We\u2019re going to do what is necessary to protect our people.\" \u2014@POTUS on the attack in Istanbul: https:\/\/t.co\/zDsd8KaZEa",
  "id" : 748242058683441153,
  "created_at" : "2016-06-29 19:49:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748240010223095808",
  "text" : "\"We're going to do more to speak with one, united North American voice on the world stage.\" \u2014@POTUS with Canada and Mexico",
  "id" : 748240010223095808,
  "created_at" : "2016-06-29 19:41:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Justin Trudeau",
      "screen_name" : "JustinTrudeau",
      "indices" : [ 78, 92 ],
      "id_str" : "14260960",
      "id" : 14260960
    }, {
      "name" : "Enrique Pe\u00F1a Nieto",
      "screen_name" : "EPN",
      "indices" : [ 97, 101 ],
      "id_str" : "2897441",
      "id" : 2897441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/4Xw449EFpX",
      "expanded_url" : "http:\/\/go.wh.gov\/Zika",
      "display_url" : "go.wh.gov\/Zika"
    } ]
  },
  "geo" : { },
  "id_str" : "748239591296032768",
  "text" : "\"We\u2019re expanding our joint efforts against diseases like #Zika.\" \u2014@POTUS with @JustinTrudeau and @EPN: https:\/\/t.co\/4Xw449EFpX",
  "id" : 748239591296032768,
  "created_at" : "2016-06-29 19:39:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/748239300844654592\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/aJPgzFvetP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmJHk37WEAA7_bA.jpg",
      "id_str" : "748239186910646272",
      "id" : 748239186910646272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmJHk37WEAA7_bA.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/aJPgzFvetP"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748239300844654592",
  "text" : "\"We\u2019re announcing a new goal across our continent\" \u2014@POTUS on the U.S., Canada, and Mexico working to #ActOnClimate https:\/\/t.co\/aJPgzFvetP",
  "id" : 748239300844654592,
  "created_at" : "2016-06-29 19:38:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NALS2016",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748238493185249280",
  "text" : "\"We are bound together by family, including millions of immigrants who trace their roots to each other\u2019s countries\" \u2014@POTUS #NALS2016",
  "id" : 748238493185249280,
  "created_at" : "2016-06-29 19:35:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748238277254094848",
  "text" : "\"We can and we will defeat those who offer only death and destruction.\" \u2014@POTUS on the horrific terrorist attack in Istanbul",
  "id" : 748238277254094848,
  "created_at" : "2016-06-29 19:34:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 29, 35 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/748236767904423936\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/IGP0qHAhx7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmJFXFcVYAAnwFE.jpg",
      "id_str" : "748236750997250048",
      "id" : 748236750997250048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmJFXFcVYAAnwFE.jpg",
      "sizes" : [ {
        "h" : 1511,
        "resize" : "fit",
        "w" : 1511
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1511,
        "resize" : "fit",
        "w" : 1511
      } ],
      "display_url" : "pic.twitter.com\/IGP0qHAhx7"
    } ],
    "hashtags" : [ {
      "text" : "NALS2016",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748236921973833728",
  "text" : "RT @PressSec: Happening now: @POTUS stands with Canadian PM &amp; Mexican President at a presser in Ottawa #NALS2016 https:\/\/t.co\/IGP0qHAhx7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/748236767904423936\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/IGP0qHAhx7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmJFXFcVYAAnwFE.jpg",
        "id_str" : "748236750997250048",
        "id" : 748236750997250048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmJFXFcVYAAnwFE.jpg",
        "sizes" : [ {
          "h" : 1511,
          "resize" : "fit",
          "w" : 1511
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1511,
          "resize" : "fit",
          "w" : 1511
        } ],
        "display_url" : "pic.twitter.com\/IGP0qHAhx7"
      } ],
      "hashtags" : [ {
        "text" : "NALS2016",
        "indices" : [ 93, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748236767904423936",
    "text" : "Happening now: @POTUS stands with Canadian PM &amp; Mexican President at a presser in Ottawa #NALS2016 https:\/\/t.co\/IGP0qHAhx7",
    "id" : 748236767904423936,
    "created_at" : "2016-06-29 19:28:41 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 748236921973833728,
  "created_at" : "2016-06-29 19:29:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Justin Trudeau",
      "screen_name" : "JustinTrudeau",
      "indices" : [ 64, 78 ],
      "id_str" : "14260960",
      "id" : 14260960
    }, {
      "name" : "Enrique Pe\u00F1a Nieto",
      "screen_name" : "EPN",
      "indices" : [ 101, 105 ],
      "id_str" : "2897441",
      "id" : 2897441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/7P91jpJZUV",
      "expanded_url" : "http:\/\/go.wh.gov\/zdnw54",
      "display_url" : "go.wh.gov\/zdnw54"
    } ]
  },
  "geo" : { },
  "id_str" : "748225848105283584",
  "text" : "Watch @POTUS in a press conference with Canadian Prime Minister @JustinTrudeau and Mexican President @EPN at 3pm ET: https:\/\/t.co\/7P91jpJZUV",
  "id" : 748225848105283584,
  "created_at" : "2016-06-29 18:45:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/748214657056407552\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/DQhAZYr9wI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmIwknhXIAAbzV2.jpg",
      "id_str" : "748213893739257856",
      "id" : 748213893739257856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmIwknhXIAAbzV2.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/DQhAZYr9wI"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/748214657056407552\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/DQhAZYr9wI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmIwxYSWkAUtj-G.jpg",
      "id_str" : "748214112988073989",
      "id" : 748214112988073989,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmIwxYSWkAUtj-G.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/DQhAZYr9wI"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/gz2Uh0bgPt",
      "expanded_url" : "http:\/\/go.wh.gov\/HgV4FJ",
      "display_url" : "go.wh.gov\/HgV4FJ"
    } ]
  },
  "geo" : { },
  "id_str" : "748218991408209920",
  "text" : "RT @FLOTUS: Day 3: See what the First Lady was up to in Marrakech, Morocco \u2192 https:\/\/t.co\/gz2Uh0bgPt #LetGirlsLearn https:\/\/t.co\/DQhAZYr9wI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/748214657056407552\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/DQhAZYr9wI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmIwknhXIAAbzV2.jpg",
        "id_str" : "748213893739257856",
        "id" : 748213893739257856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmIwknhXIAAbzV2.jpg",
        "sizes" : [ {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/DQhAZYr9wI"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/748214657056407552\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/DQhAZYr9wI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmIwxYSWkAUtj-G.jpg",
        "id_str" : "748214112988073989",
        "id" : 748214112988073989,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmIwxYSWkAUtj-G.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/DQhAZYr9wI"
      } ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 89, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/gz2Uh0bgPt",
        "expanded_url" : "http:\/\/go.wh.gov\/HgV4FJ",
        "display_url" : "go.wh.gov\/HgV4FJ"
      } ]
    },
    "geo" : { },
    "id_str" : "748214657056407552",
    "text" : "Day 3: See what the First Lady was up to in Marrakech, Morocco \u2192 https:\/\/t.co\/gz2Uh0bgPt #LetGirlsLearn https:\/\/t.co\/DQhAZYr9wI",
    "id" : 748214657056407552,
    "created_at" : "2016-06-29 18:00:50 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 748218991408209920,
  "created_at" : "2016-06-29 18:18:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CanadianPM",
      "screen_name" : "CanadianPM",
      "indices" : [ 3, 14 ],
      "id_str" : "14713787",
      "id" : 14713787
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CanadianPM\/status\/748175395330068480\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/0YVM6v6h8E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmINRZ1WgAAigMG.jpg",
      "id_str" : "748175080740519936",
      "id" : 748175080740519936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmINRZ1WgAAigMG.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 999,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 999,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/0YVM6v6h8E"
    } ],
    "hashtags" : [ {
      "text" : "NALS2016",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748192464456933376",
  "text" : "RT @CanadianPM: Prime Minister Trudeau welcomes @POTUS Barack Obama and President Pe\u00F1a Nieto in Ottawa. #NALS2016 https:\/\/t.co\/0YVM6v6h8E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 32, 38 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CanadianPM\/status\/748175395330068480\/photo\/1",
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/0YVM6v6h8E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmINRZ1WgAAigMG.jpg",
        "id_str" : "748175080740519936",
        "id" : 748175080740519936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmINRZ1WgAAigMG.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 999,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 999,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/0YVM6v6h8E"
      } ],
      "hashtags" : [ {
        "text" : "NALS2016",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748175395330068480",
    "text" : "Prime Minister Trudeau welcomes @POTUS Barack Obama and President Pe\u00F1a Nieto in Ottawa. #NALS2016 https:\/\/t.co\/0YVM6v6h8E",
    "id" : 748175395330068480,
    "created_at" : "2016-06-29 15:24:49 +0000",
    "user" : {
      "name" : "CanadianPM",
      "screen_name" : "CanadianPM",
      "protected" : false,
      "id_str" : "14713787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661752246095474688\/GUa8Oxuy_normal.jpg",
      "id" : 14713787,
      "verified" : true
    }
  },
  "id" : 748192464456933376,
  "created_at" : "2016-06-29 16:32:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 103, 106 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanServe",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748160555827990529",
  "text" : "RT @SecBurwell: You #CanServe. Tell a story. Commit. Share an idea. Every American owns a stake of the @VP's cancer initiative. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 87, 90 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CanServe",
        "indices" : [ 4, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/AAK60PjRpG",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/cancermoonshot",
        "display_url" : "whitehouse.gov\/cancermoonshot"
      } ]
    },
    "geo" : { },
    "id_str" : "748154989776887811",
    "text" : "You #CanServe. Tell a story. Commit. Share an idea. Every American owns a stake of the @VP's cancer initiative. https:\/\/t.co\/AAK60PjRpG",
    "id" : 748154989776887811,
    "created_at" : "2016-06-29 14:03:44 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 748160555827990529,
  "created_at" : "2016-06-29 14:25:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 114, 117 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanServe",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748157760638943232",
  "text" : "RT @VPLive: \"The moonshot is all of you. Jumping in. Doing what you can. Helping prevent, detect, treat cancer.\" -@VP #CanServe https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 102, 105 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VPLive\/status\/748155186145820672\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/6mD3CHRfCA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmH6byjWIAA2iD6.jpg",
        "id_str" : "748154368453648384",
        "id" : 748154368453648384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmH6byjWIAA2iD6.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/6mD3CHRfCA"
      } ],
      "hashtags" : [ {
        "text" : "CanServe",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748155186145820672",
    "text" : "\"The moonshot is all of you. Jumping in. Doing what you can. Helping prevent, detect, treat cancer.\" -@VP #CanServe https:\/\/t.co\/6mD3CHRfCA",
    "id" : 748155186145820672,
    "created_at" : "2016-06-29 14:04:31 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 748157760638943232,
  "created_at" : "2016-06-29 14:14:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 123, 126 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CanServe",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748154369938423808",
  "text" : "RT @VPLive: \"Today, we're announcing a series of measures that move us toward the goal of doubling the rate of progress.\" -@VP #CanServe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 111, 114 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CanServe",
        "indices" : [ 115, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748153687114121216",
    "text" : "\"Today, we're announcing a series of measures that move us toward the goal of doubling the rate of progress.\" -@VP #CanServe",
    "id" : 748153687114121216,
    "created_at" : "2016-06-29 13:58:33 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 748154369938423808,
  "created_at" : "2016-06-29 14:01:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 95, 104 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/747930742206963712\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/lmjPOcyya9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmEu6H_UsAEpt13.jpg",
      "id_str" : "747930589232148481",
      "id" : 747930589232148481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmEu6H_UsAEpt13.jpg",
      "sizes" : [ {
        "h" : 262,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 698
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/lmjPOcyya9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747930742206963712",
  "text" : "\"The United States condemns in the strongest possible terms today\u2019s heinous terrorist attack\" \u2014@PressSec on Istanbul https:\/\/t.co\/lmjPOcyya9",
  "id" : 747930742206963712,
  "created_at" : "2016-06-28 23:12:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747926380529213440",
  "text" : "RT @vj44: Mass incarceration doesn\u2019t impact just the people behind bars. It has consequences for their families &amp; communities https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/I6RfrOQGmn",
        "expanded_url" : "https:\/\/medium.com\/@vj44\/a-personal-look-the-impact-of-mass-incarceration-on-parenthood-2ada10a884f1#.o8fmhduwj",
        "display_url" : "medium.com\/@vj44\/a-person\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747919680426250240",
    "text" : "Mass incarceration doesn\u2019t impact just the people behind bars. It has consequences for their families &amp; communities https:\/\/t.co\/I6RfrOQGmn",
    "id" : 747919680426250240,
    "created_at" : "2016-06-28 22:28:42 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 747926380529213440,
  "created_at" : "2016-06-28 22:55:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/mWDbiDq42q",
      "expanded_url" : "http:\/\/snpy.tv\/292YtE2",
      "display_url" : "snpy.tv\/292YtE2"
    } ]
  },
  "geo" : { },
  "id_str" : "747917018943340544",
  "text" : "In 1969, Stonewall was the site of historic protests for LGBT rights. Now it's our newest national monument. https:\/\/t.co\/mWDbiDq42q",
  "id" : 747917018943340544,
  "created_at" : "2016-06-28 22:18:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747877254651273217",
  "text" : "RT @NSC44: The Administration is working with state and local officials to combat Zika virus, but Congress still needs to act. \nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Ih3t0Q5RHb",
        "expanded_url" : "http:\/\/snpy.tv\/29lrN8y",
        "display_url" : "snpy.tv\/29lrN8y"
      } ]
    },
    "geo" : { },
    "id_str" : "747867484745764864",
    "text" : "The Administration is working with state and local officials to combat Zika virus, but Congress still needs to act. \nhttps:\/\/t.co\/Ih3t0Q5RHb",
    "id" : 747867484745764864,
    "created_at" : "2016-06-28 19:01:17 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 747877254651273217,
  "created_at" : "2016-06-28 19:40:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 41, 47 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Lady Vol Basketball",
      "screen_name" : "LadyVol_Hoops",
      "indices" : [ 51, 65 ],
      "id_str" : "245536839",
      "id" : 245536839
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/747821042622570496\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/mjamharF7J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmDLEgQWEAAdq96.jpg",
      "id_str" : "747820816381906944",
      "id" : 747820816381906944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmDLEgQWEAAdq96.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/mjamharF7J"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/a5awog5dpx",
      "expanded_url" : "http:\/\/go.wh.gov\/g2Z1DW",
      "display_url" : "go.wh.gov\/g2Z1DW"
    } ]
  },
  "geo" : { },
  "id_str" : "747821042622570496",
  "text" : "\"A role model to millions of Americans\" \u2014@POTUS on @LadyVol_Hoops' Pat Summitt: https:\/\/t.co\/a5awog5dpx https:\/\/t.co\/mjamharF7J",
  "id" : 747821042622570496,
  "created_at" : "2016-06-28 15:56:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayor Muriel Bowser",
      "screen_name" : "MayorBowser",
      "indices" : [ 12, 24 ],
      "id_str" : "976542720",
      "id" : 976542720
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/747563541339602949\/photo\/1",
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/Ijjdi6KBCQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl_fzJBUsAYXLHP.jpg",
      "id_str" : "747562132854583302",
      "id" : 747562132854583302,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl_fzJBUsAYXLHP.jpg",
      "sizes" : [ {
        "h" : 253,
        "resize" : "fit",
        "w" : 836
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 836
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 836
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/Ijjdi6KBCQ"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747563541339602949",
  "text" : "Congrats to @MayorBowser &amp; the District of Columbia for working to #RaiseTheWage. Now it's time for Congress to act. https:\/\/t.co\/Ijjdi6KBCQ",
  "id" : 747563541339602949,
  "created_at" : "2016-06-27 22:53:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/D6Um5hemxy",
      "expanded_url" : "https:\/\/twitter.com\/BuzzFeed\/status\/747497412147613697",
      "display_url" : "twitter.com\/BuzzFeed\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747559423493582848",
  "text" : "Things that are harder than registering to vote:\nMaking a friendship bracelet \u2713\nhttps:\/\/t.co\/D6Um5hemxy",
  "id" : 747559423493582848,
  "created_at" : "2016-06-27 22:37:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/D6Um5gWLG0",
      "expanded_url" : "https:\/\/twitter.com\/BuzzFeed\/status\/747497412147613697",
      "display_url" : "twitter.com\/BuzzFeed\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747547528254623745",
  "text" : "You get to choose the lawmakers who decide America's future. https:\/\/t.co\/D6Um5gWLG0",
  "id" : 747547528254623745,
  "created_at" : "2016-06-27 21:49:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNBA",
      "screen_name" : "WNBA",
      "indices" : [ 36, 41 ],
      "id_str" : "17159397",
      "id" : 17159397
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Minnesota Lynx",
      "screen_name" : "minnesotalynx",
      "indices" : [ 106, 120 ],
      "id_str" : "18939563",
      "id" : 18939563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/IVFX5Nk4YT",
      "expanded_url" : "http:\/\/snpy.tv\/28WADYl",
      "display_url" : "snpy.tv\/28WADYl"
    } ]
  },
  "geo" : { },
  "id_str" : "747540346540818432",
  "text" : "\"These women &amp; women across the @WNBA are setting their own outstanding example for girls\" \u2014@POTUS on @MinnesotaLynx https:\/\/t.co\/IVFX5Nk4YT",
  "id" : 747540346540818432,
  "created_at" : "2016-06-27 21:21:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "WNBA",
      "screen_name" : "WNBA",
      "indices" : [ 35, 40 ],
      "id_str" : "17159397",
      "id" : 17159397
    }, {
      "name" : "Minnesota Lynx",
      "screen_name" : "minnesotalynx",
      "indices" : [ 50, 64 ],
      "id_str" : "18939563",
      "id" : 18939563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/IVFX5Nk4YT",
      "expanded_url" : "http:\/\/snpy.tv\/28WADYl",
      "display_url" : "snpy.tv\/28WADYl"
    } ]
  },
  "geo" : { },
  "id_str" : "747538586120093696",
  "text" : "Watch @POTUS congratulate the 2015 @WNBA champion @MinnesotaLynx: https:\/\/t.co\/IVFX5Nk4YT",
  "id" : 747538586120093696,
  "created_at" : "2016-06-27 21:14:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 38, 44 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/jp7URKXWzm",
      "expanded_url" : "http:\/\/snpy.tv\/29hKWbt",
      "display_url" : "snpy.tv\/29hKWbt"
    } ]
  },
  "geo" : { },
  "id_str" : "747533335124152320",
  "text" : "\"I am for equal pay for equal work.\" \u2014@POTUS on #EqualPay and professional sports: https:\/\/t.co\/jp7URKXWzm",
  "id" : 747533335124152320,
  "created_at" : "2016-06-27 20:53:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 39, 45 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747532114749423616",
  "text" : "\"I amm for equal pay for equal work.\" \u2014@POTUS on #EqualPay and professional sports",
  "id" : 747532114749423616,
  "created_at" : "2016-06-27 20:48:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNBA",
      "screen_name" : "WNBA",
      "indices" : [ 42, 47 ],
      "id_str" : "17159397",
      "id" : 17159397
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Minnesota Lynx",
      "screen_name" : "minnesotalynx",
      "indices" : [ 117, 131 ],
      "id_str" : "18939563",
      "id" : 18939563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747532075713036288",
  "text" : "\"Today, these women, and women across the @WNBA, are setting their own outstanding example for girls\" \u2014@POTUS on the @MinnesotaLynx",
  "id" : 747532075713036288,
  "created_at" : "2016-06-27 20:48:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Minnesota Lynx",
      "screen_name" : "minnesotalynx",
      "indices" : [ 122, 136 ],
      "id_str" : "18939563",
      "id" : 18939563
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747531757801586688",
  "text" : "\"These women are not just all-star basketball players. They\u2019re also leaders in the Minneapolis community.\" \u2014@POTUS on the @MinnesotaLynx",
  "id" : 747531757801586688,
  "created_at" : "2016-06-27 20:47:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNBA",
      "screen_name" : "WNBA",
      "indices" : [ 25, 30 ],
      "id_str" : "17159397",
      "id" : 17159397
    }, {
      "name" : "Minnesota Lynx",
      "screen_name" : "minnesotalynx",
      "indices" : [ 46, 60 ],
      "id_str" : "18939563",
      "id" : 18939563
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 64, 70 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747530823809794049",
  "text" : "\"Give it up for the 2015 @WNBA champions, the @MinnesotaLynx!\" \u2014@POTUS",
  "id" : 747530823809794049,
  "created_at" : "2016-06-27 20:43:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "WNBA",
      "screen_name" : "WNBA",
      "indices" : [ 54, 59 ],
      "id_str" : "17159397",
      "id" : 17159397
    }, {
      "name" : "Minnesota Lynx",
      "screen_name" : "minnesotalynx",
      "indices" : [ 69, 83 ],
      "id_str" : "18939563",
      "id" : 18939563
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 91, 102 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/Qpft1ud2D7",
      "expanded_url" : "http:\/\/go.wh.gov\/mLvwHH",
      "display_url" : "go.wh.gov\/mLvwHH"
    } ]
  },
  "geo" : { },
  "id_str" : "747530351510167552",
  "text" : "Tune in at 4:50pm ET to watch @POTUS welcome the 2015 @WNBA Champion @MinnesotaLynx to the @WhiteHouse: https:\/\/t.co\/Qpft1ud2D7",
  "id" : 747530351510167552,
  "created_at" : "2016-06-27 20:41:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "indices" : [ 3, 9 ],
      "id_str" : "369245377",
      "id" : 369245377
    }, {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 80, 89 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "GES2016",
      "screen_name" : "ges2016",
      "indices" : [ 93, 101 ],
      "id_str" : "4787915381",
      "id" : 4787915381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/cnCH97Ug4O",
      "expanded_url" : "https:\/\/medium.com\/@rhodes44\/global-entrepreneurship-betting-on-a-future-defined-by-people-who-build-not-destroy-e18d2e84e78f#.ap3hy6mba",
      "display_url" : "medium.com\/@rhodes44\/glob\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747527725393412096",
  "text" : "RT @NSC44: Betting on a future defined by people who build, not destroy. Here's @Rhodes44 on @GES2016: https:\/\/t.co\/cnCH97Ug4O https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Rhodes",
        "screen_name" : "rhodes44",
        "indices" : [ 69, 78 ],
        "id_str" : "249722522",
        "id" : 249722522
      }, {
        "name" : "GES2016",
        "screen_name" : "ges2016",
        "indices" : [ 82, 90 ],
        "id_str" : "4787915381",
        "id" : 4787915381
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSC44\/status\/747525623141130240\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/3dYXWZQhVI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl--il2UsAA8I4E.jpg",
        "id_str" : "747525564651581440",
        "id" : 747525564651581440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl--il2UsAA8I4E.jpg",
        "sizes" : [ {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1363,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1363,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/3dYXWZQhVI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/cnCH97Ug4O",
        "expanded_url" : "https:\/\/medium.com\/@rhodes44\/global-entrepreneurship-betting-on-a-future-defined-by-people-who-build-not-destroy-e18d2e84e78f#.ap3hy6mba",
        "display_url" : "medium.com\/@rhodes44\/glob\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747525623141130240",
    "text" : "Betting on a future defined by people who build, not destroy. Here's @Rhodes44 on @GES2016: https:\/\/t.co\/cnCH97Ug4O https:\/\/t.co\/3dYXWZQhVI",
    "id" : 747525623141130240,
    "created_at" : "2016-06-27 20:22:51 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 747527725393412096,
  "created_at" : "2016-06-27 20:31:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/747490402249367556\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/VibqfCHbPn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl-eizbWAAANv_C.jpg",
      "id_str" : "747490383924428800",
      "id" : 747490383924428800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl-eizbWAAANv_C.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/VibqfCHbPn"
    } ],
    "hashtags" : [ {
      "text" : "Pride2016",
      "indices" : [ 87, 97 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747510321946984448",
  "text" : "RT @vj44: At Stonewall Inn today, honoring the many achievements of the LGBT community #Pride2016 #FindYourPark https:\/\/t.co\/VibqfCHbPn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/747490402249367556\/photo\/1",
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/VibqfCHbPn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl-eizbWAAANv_C.jpg",
        "id_str" : "747490383924428800",
        "id" : 747490383924428800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl-eizbWAAANv_C.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/VibqfCHbPn"
      } ],
      "hashtags" : [ {
        "text" : "Pride2016",
        "indices" : [ 77, 87 ]
      }, {
        "text" : "FindYourPark",
        "indices" : [ 88, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747490402249367556",
    "text" : "At Stonewall Inn today, honoring the many achievements of the LGBT community #Pride2016 #FindYourPark https:\/\/t.co\/VibqfCHbPn",
    "id" : 747490402249367556,
    "created_at" : "2016-06-27 18:02:54 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 747510321946984448,
  "created_at" : "2016-06-27 19:22:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/747486776080531460\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/txFaRtUSMN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl-YbgGWYAAFV_B.jpg",
      "id_str" : "747483661407248384",
      "id" : 747483661407248384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl-YbgGWYAAFV_B.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1866,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/txFaRtUSMN"
    } ],
    "hashtags" : [ {
      "text" : "NationalSunglassesDay",
      "indices" : [ 18, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747504909143126016",
  "text" : "RT @VPLive: Happy #NationalSunglassesDay from the White House's resident aviators enthusiast. https:\/\/t.co\/txFaRtUSMN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/747486776080531460\/photo\/1",
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/txFaRtUSMN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl-YbgGWYAAFV_B.jpg",
        "id_str" : "747483661407248384",
        "id" : 747483661407248384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl-YbgGWYAAFV_B.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1866,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/txFaRtUSMN"
      } ],
      "hashtags" : [ {
        "text" : "NationalSunglassesDay",
        "indices" : [ 6, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747486776080531460",
    "text" : "Happy #NationalSunglassesDay from the White House's resident aviators enthusiast. https:\/\/t.co\/txFaRtUSMN",
    "id" : 747486776080531460,
    "created_at" : "2016-06-27 17:48:29 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 747504909143126016,
  "created_at" : "2016-06-27 19:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 3, 12 ],
      "id_str" : "5695632",
      "id" : 5695632
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TurnUpToVote",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/vHfvNl3s5e",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/f6fc01cd-813e-43ef-9e23-8290800986a6",
      "display_url" : "amp.twimg.com\/v\/f6fc01cd-813\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "747499156827144196",
  "text" : "RT @BuzzFeed: 5 Things That Are Harder Than Registering To Vote, Featuring @POTUS #TurnUpToVote\nhttps:\/\/t.co\/vHfvNl3s5e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 61, 67 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TurnUpToVote",
        "indices" : [ 68, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/vHfvNl3s5e",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/f6fc01cd-813e-43ef-9e23-8290800986a6",
        "display_url" : "amp.twimg.com\/v\/f6fc01cd-813\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747497412147613697",
    "text" : "5 Things That Are Harder Than Registering To Vote, Featuring @POTUS #TurnUpToVote\nhttps:\/\/t.co\/vHfvNl3s5e",
    "id" : 747497412147613697,
    "created_at" : "2016-06-27 18:30:45 +0000",
    "user" : {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "protected" : false,
      "id_str" : "5695632",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687767655214891008\/n9pHVYUl_normal.png",
      "id" : 5695632,
      "verified" : true
    }
  },
  "id" : 747499156827144196,
  "created_at" : "2016-06-27 18:37:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 21, 28 ]
    }, {
      "text" : "DoYourJob",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747487425119789057",
  "text" : "RT @SCOTUSnom: FACT: #SCOTUS has been down one justice for more than 100 days. Daily reminder to the Senate GOP: #DoYourJob https:\/\/t.co\/YO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCOTUSnom\/status\/747459198401712128\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/YO4bQ3URgB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl-CEFBUsAAPIp8.jpg",
        "id_str" : "747459069745606656",
        "id" : 747459069745606656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl-CEFBUsAAPIp8.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/YO4bQ3URgB"
      } ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 6, 13 ]
      }, {
        "text" : "DoYourJob",
        "indices" : [ 98, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747459198401712128",
    "text" : "FACT: #SCOTUS has been down one justice for more than 100 days. Daily reminder to the Senate GOP: #DoYourJob https:\/\/t.co\/YO4bQ3URgB",
    "id" : 747459198401712128,
    "created_at" : "2016-06-27 15:58:54 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 747487425119789057,
  "created_at" : "2016-06-27 17:51:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/747470028635774976\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/NyvUv4ARD8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl-LcWEUoAEadMA.jpg",
      "id_str" : "747469382243098625",
      "id" : 747469382243098625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl-LcWEUoAEadMA.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/NyvUv4ARD8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747470028635774976",
  "text" : "\"I am pleased to see the Supreme Court protect women's rights and health today.\" \u2014@POTUS: https:\/\/t.co\/NyvUv4ARD8",
  "id" : 747470028635774976,
  "created_at" : "2016-06-27 16:41:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747466922841767936",
  "text" : "RT @POTUS: Women\u2019s opportunities are expanded and our nation is stronger when all of our citizens have accessible, affordable health care.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "747466445345349632",
    "geo" : { },
    "id_str" : "747466642725056512",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Women\u2019s opportunities are expanded and our nation is stronger when all of our citizens have accessible, affordable health care.",
    "id" : 747466642725056512,
    "in_reply_to_status_id" : 747466445345349632,
    "created_at" : "2016-06-27 16:28:29 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 747466922841767936,
  "created_at" : "2016-06-27 16:29:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747466686387855360",
  "text" : "RT @POTUS: Every woman has a constitutional right to make her own reproductive choices. I'm pleased to see the Supreme Court reaffirm that\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "747466445345349632",
    "text" : "Every woman has a constitutional right to make her own reproductive choices. I'm pleased to see the Supreme Court reaffirm that fact today.",
    "id" : 747466445345349632,
    "created_at" : "2016-06-27 16:27:42 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 747466686387855360,
  "created_at" : "2016-06-27 16:28:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "HelloGiggles.com",
      "screen_name" : "hellogiggles",
      "indices" : [ 101, 114 ],
      "id_str" : "219682445",
      "id" : 219682445
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 47, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/DNameJbFMZ",
      "expanded_url" : "http:\/\/go.wh.gov\/8p3Gux",
      "display_url" : "go.wh.gov\/8p3Gux"
    } ]
  },
  "geo" : { },
  "id_str" : "747170328737157122",
  "text" : "RT @FLOTUS: Follow along with the First Lady's #LetGirlsLearn trip to Liberia, Morocco, and Spain on @HelloGiggles: https:\/\/t.co\/DNameJbFMZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HelloGiggles.com",
        "screen_name" : "hellogiggles",
        "indices" : [ 89, 102 ],
        "id_str" : "219682445",
        "id" : 219682445
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 35, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/DNameJbFMZ",
        "expanded_url" : "http:\/\/go.wh.gov\/8p3Gux",
        "display_url" : "go.wh.gov\/8p3Gux"
      } ]
    },
    "geo" : { },
    "id_str" : "747157580036792320",
    "text" : "Follow along with the First Lady's #LetGirlsLearn trip to Liberia, Morocco, and Spain on @HelloGiggles: https:\/\/t.co\/DNameJbFMZ",
    "id" : 747157580036792320,
    "created_at" : "2016-06-26 20:00:23 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 747170328737157122,
  "created_at" : "2016-06-26 20:51:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 15, 18 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BidenInIreland",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/DqejxgGjkT",
      "expanded_url" : "http:\/\/go.wh.gov\/VP-In-Ireland",
      "display_url" : "go.wh.gov\/VP-In-Ireland"
    } ]
  },
  "geo" : { },
  "id_str" : "747165095638142977",
  "text" : "RT @VPLive: As @VP's Ireland trip comes to a close, here's a recap of what he's seen: https:\/\/t.co\/DqejxgGjkT #BidenInIreland\nhttps:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 3, 6 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BidenInIreland",
        "indices" : [ 98, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/DqejxgGjkT",
        "expanded_url" : "http:\/\/go.wh.gov\/VP-In-Ireland",
        "display_url" : "go.wh.gov\/VP-In-Ireland"
      }, {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/W6J5LlhOcT",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/94bd03e8-d72b-4ab2-bf60-c9ab203bf8da",
        "display_url" : "amp.twimg.com\/v\/94bd03e8-d72\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "747143391272534016",
    "text" : "As @VP's Ireland trip comes to a close, here's a recap of what he's seen: https:\/\/t.co\/DqejxgGjkT #BidenInIreland\nhttps:\/\/t.co\/W6J5LlhOcT",
    "id" : 747143391272534016,
    "created_at" : "2016-06-26 19:04:00 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 747165095638142977,
  "created_at" : "2016-06-26 20:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveIsLove",
      "indices" : [ 83, 94 ]
    }, {
      "text" : "Pride2016",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/XtTx7WGLyS",
      "expanded_url" : "http:\/\/go.wh.gov\/aq7J46",
      "display_url" : "go.wh.gov\/aq7J46"
    } ]
  },
  "geo" : { },
  "id_str" : "747157257377353728",
  "text" : "\"In every state in America, you\u2019re now free to marry the person you love.\" \u2014@POTUS #LoveIsLove #Pride2016 https:\/\/t.co\/XtTx7WGLyS",
  "id" : 747157257377353728,
  "created_at" : "2016-06-26 19:59:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveIsLove",
      "indices" : [ 86, 97 ]
    }, {
      "text" : "Pride2016",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/XtTx7WGLyS",
      "expanded_url" : "http:\/\/go.wh.gov\/aq7J46",
      "display_url" : "go.wh.gov\/aq7J46"
    } ]
  },
  "geo" : { },
  "id_str" : "747141896087035904",
  "text" : "\"Out of many, we are one. That\u2019s what makes us the greatest nation on earth.\" \u2014@POTUS #LoveIsLove #Pride2016 https:\/\/t.co\/XtTx7WGLyS",
  "id" : 747141896087035904,
  "created_at" : "2016-06-26 18:58:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveIsLove",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/TT1fgEQxiU",
      "expanded_url" : "http:\/\/go.wh.gov\/RC9e1C",
      "display_url" : "go.wh.gov\/RC9e1C"
    } ]
  },
  "geo" : { },
  "id_str" : "747126794692624385",
  "text" : "\"It was a powerful symbol here at home, where more Americans finally felt accepted and whole\" \u2014@POTUS: https:\/\/t.co\/TT1fgEQxiU #LoveIsLove",
  "id" : 747126794692624385,
  "created_at" : "2016-06-26 17:58:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/747106714005180416\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/A7FeFhS6sp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl5BjvaUYAAsQL4.jpg",
      "id_str" : "747106670468161536",
      "id" : 747106670468161536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl5BjvaUYAAsQL4.jpg",
      "sizes" : [ {
        "h" : 445,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1310,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 786,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1310,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/A7FeFhS6sp"
    } ],
    "hashtags" : [ {
      "text" : "LoveIsLove",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "747106714005180416",
  "text" : "One year ago today, the Supreme Court ruled that marriage equality would be the law of the land. #LoveIsLove https:\/\/t.co\/A7FeFhS6sp",
  "id" : 747106714005180416,
  "created_at" : "2016-06-26 16:38:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "U.S. Mayors",
      "screen_name" : "usmayors",
      "indices" : [ 38, 47 ],
      "id_str" : "15012352",
      "id" : 15012352
    }, {
      "name" : "Mayor Joe Hogsett",
      "screen_name" : "IndyMayorJoe",
      "indices" : [ 81, 94 ],
      "id_str" : "2645701736",
      "id" : 2645701736
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/746778836227002368\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/IZQaAQgIVu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl0XXvkWAAAf1-6.jpg",
      "id_str" : "746778809886703616",
      "id" : 746778809886703616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl0XXvkWAAAf1-6.jpg",
      "sizes" : [ {
        "h" : 4032,
        "resize" : "fit",
        "w" : 3024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/IZQaAQgIVu"
    } ],
    "hashtags" : [ {
      "text" : "USCM2016",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746839459094659073",
  "text" : "RT @vj44: It's great to be in Indy at @usmayors summer conference with host city @IndyMayorJoe #USCM2016 https:\/\/t.co\/IZQaAQgIVu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Mayors",
        "screen_name" : "usmayors",
        "indices" : [ 28, 37 ],
        "id_str" : "15012352",
        "id" : 15012352
      }, {
        "name" : "Mayor Joe Hogsett",
        "screen_name" : "IndyMayorJoe",
        "indices" : [ 71, 84 ],
        "id_str" : "2645701736",
        "id" : 2645701736
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/746778836227002368\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/IZQaAQgIVu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl0XXvkWAAAf1-6.jpg",
        "id_str" : "746778809886703616",
        "id" : 746778809886703616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl0XXvkWAAAf1-6.jpg",
        "sizes" : [ {
          "h" : 4032,
          "resize" : "fit",
          "w" : 3024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/IZQaAQgIVu"
      } ],
      "hashtags" : [ {
        "text" : "USCM2016",
        "indices" : [ 85, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746778836227002368",
    "text" : "It's great to be in Indy at @usmayors summer conference with host city @IndyMayorJoe #USCM2016 https:\/\/t.co\/IZQaAQgIVu",
    "id" : 746778836227002368,
    "created_at" : "2016-06-25 18:55:23 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 746839459094659073,
  "created_at" : "2016-06-25 22:56:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/XtTx7WGLyS",
      "expanded_url" : "http:\/\/go.wh.gov\/aq7J46",
      "display_url" : "go.wh.gov\/aq7J46"
    } ]
  },
  "geo" : { },
  "id_str" : "746795214317117440",
  "text" : "\"I believe our national parks should reflect the full story of our country\" \u2014@POTUS on Stonewall National Monument: https:\/\/t.co\/XtTx7WGLyS",
  "id" : 746795214317117440,
  "created_at" : "2016-06-25 20:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/XtTx7WpaHk",
      "expanded_url" : "http:\/\/go.wh.gov\/aq7J46",
      "display_url" : "go.wh.gov\/aq7J46"
    } ]
  },
  "geo" : { },
  "id_str" : "746785200303136768",
  "text" : "\"I\u2019m designating the Stonewall National Monument as the newest addition to America\u2019s National Parks System\" \u2014@POTUS: https:\/\/t.co\/XtTx7WpaHk",
  "id" : 746785200303136768,
  "created_at" : "2016-06-25 19:20:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/XtTx7WGLyS",
      "expanded_url" : "http:\/\/go.wh.gov\/aq7J46",
      "display_url" : "go.wh.gov\/aq7J46"
    } ]
  },
  "geo" : { },
  "id_str" : "746780509263409152",
  "text" : "\"The LGBT community still faces real discrimination, real violence, real hate. So we can\u2019t rest.\" \u2014@POTUS: https:\/\/t.co\/XtTx7WGLyS",
  "id" : 746780509263409152,
  "created_at" : "2016-06-25 19:02:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/XtTx7WGLyS",
      "expanded_url" : "http:\/\/go.wh.gov\/aq7J46",
      "display_url" : "go.wh.gov\/aq7J46"
    } ]
  },
  "geo" : { },
  "id_str" : "746765029265924096",
  "text" : "\"In every state in America, you\u2019re now free to marry the person you love.\" \u2014@POTUS on #LGBT progress: https:\/\/t.co\/XtTx7WGLyS",
  "id" : 746765029265924096,
  "created_at" : "2016-06-25 18:00:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/XtTx7WGLyS",
      "expanded_url" : "http:\/\/go.wh.gov\/aq7J46",
      "display_url" : "go.wh.gov\/aq7J46"
    } ]
  },
  "geo" : { },
  "id_str" : "746757125162958848",
  "text" : "\"Protests became a movement; the movement ultimately became an integral part of America.\" \u2014@POTUS on Stonewall: https:\/\/t.co\/XtTx7WGLyS",
  "id" : 746757125162958848,
  "created_at" : "2016-06-25 17:29:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/XtTx7WGLyS",
      "expanded_url" : "http:\/\/go.wh.gov\/aq7J46",
      "display_url" : "go.wh.gov\/aq7J46"
    } ]
  },
  "geo" : { },
  "id_str" : "746741271541121025",
  "text" : "\"Sometimes, we can mark that progress in special places...One of these special places is the Stonewall Inn.\"\u2014@POTUS: https:\/\/t.co\/XtTx7WGLyS",
  "id" : 746741271541121025,
  "created_at" : "2016-06-25 16:26:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/XtTx7WGLyS",
      "expanded_url" : "http:\/\/go.wh.gov\/aq7J46",
      "display_url" : "go.wh.gov\/aq7J46"
    } ]
  },
  "geo" : { },
  "id_str" : "746734857624051712",
  "text" : "\"The story of America is a story of progress.\" \u2014@POTUS on our newest national monument: Stonewall: https:\/\/t.co\/XtTx7WGLyS",
  "id" : 746734857624051712,
  "created_at" : "2016-06-25 16:00:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/XtTx7WGLyS",
      "expanded_url" : "http:\/\/go.wh.gov\/aq7J46",
      "display_url" : "go.wh.gov\/aq7J46"
    } ]
  },
  "geo" : { },
  "id_str" : "746720717257900033",
  "text" : "Watch @POTUS name our newest National Monument: Stonewall \u2192 https:\/\/t.co\/XtTx7WGLyS",
  "id" : 746720717257900033,
  "created_at" : "2016-06-25 15:04:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 76, 79 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/uI0hid0Cq1",
      "expanded_url" : "http:\/\/snpy.tv\/292XX9P",
      "display_url" : "snpy.tv\/292XX9P"
    } ]
  },
  "geo" : { },
  "id_str" : "746493218603175936",
  "text" : "From Yosemite to Ireland and beyond: catch up on the latest from @POTUS and @VP in this #WestWingWeek. https:\/\/t.co\/uI0hid0Cq1",
  "id" : 746493218603175936,
  "created_at" : "2016-06-25 00:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/aTEQijywnC",
      "expanded_url" : "http:\/\/snpy.tv\/28SmAIi",
      "display_url" : "snpy.tv\/28SmAIi"
    } ]
  },
  "geo" : { },
  "id_str" : "746478951501959168",
  "text" : "RT @rhodes44: \"I believe in you. America believes in you.\" \u2014@POTUS to young entrepreneurs at #GES2016 https:\/\/t.co\/aTEQijywnC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 46, 52 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GES2016",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/aTEQijywnC",
        "expanded_url" : "http:\/\/snpy.tv\/28SmAIi",
        "display_url" : "snpy.tv\/28SmAIi"
      } ]
    },
    "geo" : { },
    "id_str" : "746459734379798528",
    "text" : "\"I believe in you. America believes in you.\" \u2014@POTUS to young entrepreneurs at #GES2016 https:\/\/t.co\/aTEQijywnC",
    "id" : 746459734379798528,
    "created_at" : "2016-06-24 21:47:23 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 746478951501959168,
  "created_at" : "2016-06-24 23:03:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Broderick Johnson",
      "screen_name" : "Broderick44",
      "indices" : [ 3, 15 ],
      "id_str" : "3246838764",
      "id" : 3246838764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/VBfkaB6tCR",
      "expanded_url" : "http:\/\/go.wh.gov\/1gCdBy",
      "display_url" : "go.wh.gov\/1gCdBy"
    } ]
  },
  "geo" : { },
  "id_str" : "746475602601877504",
  "text" : "RT @Broderick44: Second Chance Pell Grants will help enroll 12,000 incarcerated students in educational programs \u2192  https:\/\/t.co\/VBfkaB6tCR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mybrotherskeeper",
        "indices" : [ 123, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/VBfkaB6tCR",
        "expanded_url" : "http:\/\/go.wh.gov\/1gCdBy",
        "display_url" : "go.wh.gov\/1gCdBy"
      } ]
    },
    "geo" : { },
    "id_str" : "746455407355273216",
    "text" : "Second Chance Pell Grants will help enroll 12,000 incarcerated students in educational programs \u2192  https:\/\/t.co\/VBfkaB6tCR #mybrotherskeeper",
    "id" : 746455407355273216,
    "created_at" : "2016-06-24 21:30:12 +0000",
    "user" : {
      "name" : "Broderick Johnson",
      "screen_name" : "Broderick44",
      "protected" : false,
      "id_str" : "3246838764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610850749086433280\/Y1iGefZo_normal.jpg",
      "id" : 3246838764,
      "verified" : true
    }
  },
  "id" : 746475602601877504,
  "created_at" : "2016-06-24 22:50:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "indices" : [ 3, 13 ],
      "id_str" : "1665298740",
      "id" : 1665298740
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/uFugke5UcY",
      "expanded_url" : "http:\/\/go.wh.gov\/zu5j22",
      "display_url" : "go.wh.gov\/zu5j22"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/xQmnvZaDLC",
      "expanded_url" : "http:\/\/snpy.tv\/28Q6lXd",
      "display_url" : "snpy.tv\/28Q6lXd"
    } ]
  },
  "geo" : { },
  "id_str" : "746451482661130240",
  "text" : "RT @Hoffine44: An iconic location for #LGBT rights just became our newest national monument: https:\/\/t.co\/uFugke5UcY https:\/\/t.co\/xQmnvZaDLC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBT",
        "indices" : [ 23, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/uFugke5UcY",
        "expanded_url" : "http:\/\/go.wh.gov\/zu5j22",
        "display_url" : "go.wh.gov\/zu5j22"
      }, {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/xQmnvZaDLC",
        "expanded_url" : "http:\/\/snpy.tv\/28Q6lXd",
        "display_url" : "snpy.tv\/28Q6lXd"
      } ]
    },
    "geo" : { },
    "id_str" : "746389785258823680",
    "text" : "An iconic location for #LGBT rights just became our newest national monument: https:\/\/t.co\/uFugke5UcY https:\/\/t.co\/xQmnvZaDLC",
    "id" : 746389785258823680,
    "created_at" : "2016-06-24 17:09:26 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 746451482661130240,
  "created_at" : "2016-06-24 21:14:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/n1uh1XM9nB",
      "expanded_url" : "http:\/\/snpy.tv\/28SmAIi",
      "display_url" : "snpy.tv\/28SmAIi"
    } ]
  },
  "geo" : { },
  "id_str" : "746445333018730496",
  "text" : "\"The world needs your creativity, and your energy, and your vision.\" \u2014@POTUS to young global entrepreneurs #GES2016 https:\/\/t.co\/n1uh1XM9nB",
  "id" : 746445333018730496,
  "created_at" : "2016-06-24 20:50:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/KK7L9oHGtO",
      "expanded_url" : "http:\/\/snpy.tv\/28W7Nwo",
      "display_url" : "snpy.tv\/28W7Nwo"
    } ]
  },
  "geo" : { },
  "id_str" : "746438337611862016",
  "text" : "\"This spirit of entrepreneurship also speaks to something deep within us.\" \u2014@POTUS at #GES2016 https:\/\/t.co\/KK7L9oHGtO",
  "id" : 746438337611862016,
  "created_at" : "2016-06-24 20:22:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google4Entrepreneurs",
      "screen_name" : "GoogleForEntrep",
      "indices" : [ 3, 19 ],
      "id_str" : "2281044080",
      "id" : 2281044080
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/m2UHPgV3Ev",
      "expanded_url" : "https:\/\/goo.gl\/iB4IHs",
      "display_url" : "goo.gl\/iB4IHs"
    } ]
  },
  "geo" : { },
  "id_str" : "746435274373275648",
  "text" : "RT @GoogleForEntrep: [Live Now] These four entrepreneurs are meeting with @POTUS. Watch live: https:\/\/t.co\/m2UHPgV3Ev #GES2016 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 53, 59 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GoogleForEntrep\/status\/746433643770351619\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/xvIc9hZvpL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClvTC5cVEAAhtHo.jpg",
        "id_str" : "746422209992790016",
        "id" : 746422209992790016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClvTC5cVEAAhtHo.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/xvIc9hZvpL"
      } ],
      "hashtags" : [ {
        "text" : "GES2016",
        "indices" : [ 97, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/m2UHPgV3Ev",
        "expanded_url" : "https:\/\/goo.gl\/iB4IHs",
        "display_url" : "goo.gl\/iB4IHs"
      } ]
    },
    "geo" : { },
    "id_str" : "746433643770351619",
    "text" : "[Live Now] These four entrepreneurs are meeting with @POTUS. Watch live: https:\/\/t.co\/m2UHPgV3Ev #GES2016 https:\/\/t.co\/xvIc9hZvpL",
    "id" : 746433643770351619,
    "created_at" : "2016-06-24 20:03:43 +0000",
    "user" : {
      "name" : "Google4Entrepreneurs",
      "screen_name" : "GoogleForEntrep",
      "protected" : false,
      "id_str" : "2281044080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653729177850408960\/qOXSi0g4_normal.png",
      "id" : 2281044080,
      "verified" : true
    }
  },
  "id" : 746435274373275648,
  "created_at" : "2016-06-24 20:10:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746427932734742528",
  "text" : "RT @rhodes44: .@POTUS launches the Young Transatlantic Innovation Leaders Initiative to bring 200 young Europeans to the U.S. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/aTEQijgUZ2",
        "expanded_url" : "http:\/\/snpy.tv\/28SmAIi",
        "display_url" : "snpy.tv\/28SmAIi"
      } ]
    },
    "geo" : { },
    "id_str" : "746425039637995520",
    "text" : ".@POTUS launches the Young Transatlantic Innovation Leaders Initiative to bring 200 young Europeans to the U.S. https:\/\/t.co\/aTEQijgUZ2",
    "id" : 746425039637995520,
    "created_at" : "2016-06-24 19:29:32 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 746427932734742528,
  "created_at" : "2016-06-24 19:41:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/n1uh1XM9nB",
      "expanded_url" : "http:\/\/snpy.tv\/28SmAIi",
      "display_url" : "snpy.tv\/28SmAIi"
    } ]
  },
  "geo" : { },
  "id_str" : "746424573004910592",
  "text" : "\"You're the bridge, you're the glue...who can help lead towards a more peaceful and more prosperous future.\" \u2014@POTUS https:\/\/t.co\/n1uh1XM9nB",
  "id" : 746424573004910592,
  "created_at" : "2016-06-24 19:27:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/xyJTErsQWV",
      "expanded_url" : "http:\/\/youtu.be\/iaXZQHGkUFk",
      "display_url" : "youtu.be\/iaXZQHGkUFk"
    } ]
  },
  "geo" : { },
  "id_str" : "746421659603632128",
  "text" : "Watch at 3:30pm ET: @POTUS leads a virtual meet-up with young entrepreneurs in London, Seoul, Mexico City and Erbil. https:\/\/t.co\/xyJTErsQWV",
  "id" : 746421659603632128,
  "created_at" : "2016-06-24 19:16:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746419621985554433",
  "text" : "RT @WHLive: \"It means that everybody has an immediate access to each other, not just information\"\u2014@POTUS on social media. Watch: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 86, 92 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/WY0wjgFjYm",
        "expanded_url" : "http:\/\/go.wh.gov\/jajXGd",
        "display_url" : "go.wh.gov\/jajXGd"
      } ]
    },
    "geo" : { },
    "id_str" : "746419531061440512",
    "text" : "\"It means that everybody has an immediate access to each other, not just information\"\u2014@POTUS on social media. Watch: https:\/\/t.co\/WY0wjgFjYm",
    "id" : 746419531061440512,
    "created_at" : "2016-06-24 19:07:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 746419621985554433,
  "created_at" : "2016-06-24 19:08:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 32, 41 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/PoBOod1JdA",
      "expanded_url" : "http:\/\/go.wh.gov\/jajXGd",
      "display_url" : "go.wh.gov\/jajXGd"
    } ]
  },
  "geo" : { },
  "id_str" : "746418456367529984",
  "text" : "Tune in now to catch @POTUS and @facebook CEO Mark Zuckerberg live backstage at #GES2016 \u2192 https:\/\/t.co\/PoBOod1JdA",
  "id" : 746418456367529984,
  "created_at" : "2016-06-24 19:03:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FSI Stanford",
      "screen_name" : "FSIStanford",
      "indices" : [ 3, 15 ],
      "id_str" : "221858588",
      "id" : 221858588
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746416843045253121",
  "text" : "RT @FSIStanford: In a networked world, cultures collide; entrepreneurs can lead us to a more peaceful, prosperous future. #GES2016 https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FSIStanford\/status\/746414180463325185\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/0RQ1wiPvGL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClvLvTzXIAEaGjs.jpg",
        "id_str" : "746414176889937921",
        "id" : 746414176889937921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClvLvTzXIAEaGjs.jpg",
        "sizes" : [ {
          "h" : 378,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 1348
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 1348
        } ],
        "display_url" : "pic.twitter.com\/0RQ1wiPvGL"
      } ],
      "hashtags" : [ {
        "text" : "GES2016",
        "indices" : [ 105, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746414180463325185",
    "text" : "In a networked world, cultures collide; entrepreneurs can lead us to a more peaceful, prosperous future. #GES2016 https:\/\/t.co\/0RQ1wiPvGL",
    "id" : 746414180463325185,
    "created_at" : "2016-06-24 18:46:22 +0000",
    "user" : {
      "name" : "FSI Stanford",
      "screen_name" : "FSIStanford",
      "protected" : false,
      "id_str" : "221858588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1180307823\/FSI_Sq_normal.jpg",
      "id" : 221858588,
      "verified" : false
    }
  },
  "id" : 746416843045253121,
  "created_at" : "2016-06-24 18:56:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/IdmA77dg2T",
      "expanded_url" : "http:\/\/snpy.tv\/28SoEOQ",
      "display_url" : "snpy.tv\/28SoEOQ"
    } ]
  },
  "geo" : { },
  "id_str" : "746408694036967424",
  "text" : "\"The special relationship between our two nations will endure.\" \u2014@POTUS on the UK referendum to leave the EU. https:\/\/t.co\/IdmA77dg2T",
  "id" : 746408694036967424,
  "created_at" : "2016-06-24 18:24:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 12, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/IdmA77uQUr",
      "expanded_url" : "http:\/\/snpy.tv\/28SoEOQ",
      "display_url" : "snpy.tv\/28SoEOQ"
    } ]
  },
  "geo" : { },
  "id_str" : "746406630850387969",
  "text" : "Speaking at #GES2016, @POTUS offers a statement on yesterday's UK referendum to leave the European Union. https:\/\/t.co\/IdmA77uQUr",
  "id" : 746406630850387969,
  "created_at" : "2016-06-24 18:16:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/bJZlqzWFx3",
      "expanded_url" : "http:\/\/go.wh.gov\/GES2016",
      "display_url" : "go.wh.gov\/GES2016"
    } ]
  },
  "geo" : { },
  "id_str" : "746406127106039809",
  "text" : "\"My bottom line is this: I believe in you. America believes in you.\" \u2014@POTUS to young people at #GES2016. Watch: https:\/\/t.co\/bJZlqzWFx3",
  "id" : 746406127106039809,
  "created_at" : "2016-06-24 18:14:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746406008084299776",
  "text" : "RT @WHLive: \"We are very proud to announce that next year\u2019s Global Entrepreneurship Summit will be hosted in India.\" \u2014@POTUS #GES2016",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 106, 112 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GES2016",
        "indices" : [ 113, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746405862520946688",
    "text" : "\"We are very proud to announce that next year\u2019s Global Entrepreneurship Summit will be hosted in India.\" \u2014@POTUS #GES2016",
    "id" : 746405862520946688,
    "created_at" : "2016-06-24 18:13:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 746406008084299776,
  "created_at" : "2016-06-24 18:13:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746405514825736193",
  "text" : "\"Don\u2019t be shy ... because ultimately the world needs your creativity, your energy, your vision.\" \u2014@POTUS to young people at #GES2016",
  "id" : 746405514825736193,
  "created_at" : "2016-06-24 18:11:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746405180376289280",
  "text" : "\"We\u2019re launching an initiative to connect...global investors with clean energy entrepreneurs from developing countries.\" \u2014@POTUS #GES2016",
  "id" : 746405180376289280,
  "created_at" : "2016-06-24 18:10:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746404636500889601",
  "text" : "RT @WHLive: \"We\u2019ve helped more than 17,000 entrepreneurs &amp; innovators connect with each other, access capital, find mentors &amp; start new ven\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746404490883006464",
    "text" : "\"We\u2019ve helped more than 17,000 entrepreneurs &amp; innovators connect with each other, access capital, find mentors &amp; start new ventures\" \u2014POTUS",
    "id" : 746404490883006464,
    "created_at" : "2016-06-24 18:07:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 746404636500889601,
  "created_at" : "2016-06-24 18:08:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746404354110828545",
  "text" : "\"You deserve the same chance to succeed as everyone else.\" \u2014@POTUS to women, minority, and young entrepreneurs at #GES2016",
  "id" : 746404354110828545,
  "created_at" : "2016-06-24 18:07:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746404286595112960",
  "text" : "RT @WHLive: \"You just see enormous creativity, waiting to be tapped.\" \u2014@POTUS on the entrepreneurial spirit around the world. #GES2016",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 59, 65 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GES2016",
        "indices" : [ 114, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746404214662782976",
    "text" : "\"You just see enormous creativity, waiting to be tapped.\" \u2014@POTUS on the entrepreneurial spirit around the world. #GES2016",
    "id" : 746404214662782976,
    "created_at" : "2016-06-24 18:06:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 746404286595112960,
  "created_at" : "2016-06-24 18:07:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746403726085152768",
  "text" : ".@POTUS: Entrepreneurship \"speaks to something deep within us\u2014no matter who we are, what we look like, or where we come from\" #GES2016",
  "id" : 746403726085152768,
  "created_at" : "2016-06-24 18:04:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746403427131920384",
  "text" : "\"It offers a positive path for young people seeking the chance to make something for yourselves.\" \u2014@POTUS on entrepreneurship #GES2016",
  "id" : 746403427131920384,
  "created_at" : "2016-06-24 18:03:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746402942077435904",
  "text" : "\"Our commitment to democracy, pluralism, and opportunity for all people in a globalized world will continue to unite us all\" \u2014@POTUS",
  "id" : 746402942077435904,
  "created_at" : "2016-06-24 18:01:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746402638833451008",
  "text" : "RT @WHLive: \"The special relationship between our two nations will endure. The EU will remain one of our indispensable partners\"\u2014@POTUS on\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 117, 123 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746402553827450885",
    "text" : "\"The special relationship between our two nations will endure. The EU will remain one of our indispensable partners\"\u2014@POTUS on UK referendum",
    "id" : 746402553827450885,
    "created_at" : "2016-06-24 18:00:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 746402638833451008,
  "created_at" : "2016-06-24 18:00:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746402407618224128",
  "text" : "\"Yesterday's vote speaks to the ongoing changes and challenges raised by globalization.\" \u2014@POTUS on the UK referendum to leave the EU.",
  "id" : 746402407618224128,
  "created_at" : "2016-06-24 17:59:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746402276667858944",
  "text" : "\"I'm confident that the UK is committed to an orderly transition out of the EU.\" \u2014@POTUS after a call with PM Cameron on the UK referendum",
  "id" : 746402276667858944,
  "created_at" : "2016-06-24 17:59:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/bJZlqzWFx3",
      "expanded_url" : "http:\/\/go.wh.gov\/GES2016",
      "display_url" : "go.wh.gov\/GES2016"
    } ]
  },
  "geo" : { },
  "id_str" : "746402084853948417",
  "text" : "\"You\u2019ve all travelled here from more than 170 countries...welcome to the United States of America.\" \u2014@POTUS #GES2016 https:\/\/t.co\/bJZlqzWFx3",
  "id" : 746402084853948417,
  "created_at" : "2016-06-24 17:58:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Stanford University",
      "screen_name" : "Stanford",
      "indices" : [ 66, 75 ],
      "id_str" : "18036441",
      "id" : 18036441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/pK7owIsgE1",
      "expanded_url" : "http:\/\/go.wh.gov\/GES2016",
      "display_url" : "go.wh.gov\/GES2016"
    } ]
  },
  "geo" : { },
  "id_str" : "746401981229457408",
  "text" : "RT @WHLive: \"This is the place that made 'nerd' cool.\" \u2014@POTUS at @Stanford for #GES2016 https:\/\/t.co\/pK7owIsgE1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 44, 50 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Stanford University",
        "screen_name" : "Stanford",
        "indices" : [ 54, 63 ],
        "id_str" : "18036441",
        "id" : 18036441
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GES2016",
        "indices" : [ 68, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/pK7owIsgE1",
        "expanded_url" : "http:\/\/go.wh.gov\/GES2016",
        "display_url" : "go.wh.gov\/GES2016"
      } ]
    },
    "geo" : { },
    "id_str" : "746401925730492416",
    "text" : "\"This is the place that made 'nerd' cool.\" \u2014@POTUS at @Stanford for #GES2016 https:\/\/t.co\/pK7owIsgE1",
    "id" : 746401925730492416,
    "created_at" : "2016-06-24 17:57:41 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 746401981229457408,
  "created_at" : "2016-06-24 17:57:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 83, 92 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/bJZlqzWFx3",
      "expanded_url" : "http:\/\/go.wh.gov\/GES2016",
      "display_url" : "go.wh.gov\/GES2016"
    } ]
  },
  "geo" : { },
  "id_str" : "746401421356998656",
  "text" : "Watch now: @POTUS takes the stage at #GES2016 to talk with young entrepreneurs and @facebook CEO Mark Zuckerberg. https:\/\/t.co\/bJZlqzWFx3",
  "id" : 746401421356998656,
  "created_at" : "2016-06-24 17:55:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristin Lee",
      "screen_name" : "Lee44",
      "indices" : [ 3, 9 ],
      "id_str" : "2800630026",
      "id" : 2800630026
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/G6IsTyTXRo",
      "expanded_url" : "http:\/\/go.wh.gov\/GES2016",
      "display_url" : "go.wh.gov\/GES2016"
    } ]
  },
  "geo" : { },
  "id_str" : "746399503700234240",
  "text" : "RT @Lee44: Starting soon: 700 entrepreneurs from 170 countries -- watch live as @POTUS speaks at #GES2016: https:\/\/t.co\/G6IsTyTXRo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 69, 75 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GES2016",
        "indices" : [ 86, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/G6IsTyTXRo",
        "expanded_url" : "http:\/\/go.wh.gov\/GES2016",
        "display_url" : "go.wh.gov\/GES2016"
      } ]
    },
    "geo" : { },
    "id_str" : "746398221467979776",
    "text" : "Starting soon: 700 entrepreneurs from 170 countries -- watch live as @POTUS speaks at #GES2016: https:\/\/t.co\/G6IsTyTXRo",
    "id" : 746398221467979776,
    "created_at" : "2016-06-24 17:42:58 +0000",
    "user" : {
      "name" : "Kristin Lee",
      "screen_name" : "Lee44",
      "protected" : false,
      "id_str" : "2800630026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626378024359870464\/dc8kq4yl_normal.png",
      "id" : 2800630026,
      "verified" : true
    }
  },
  "id" : 746399503700234240,
  "created_at" : "2016-06-24 17:48:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "indices" : [ 3, 19 ],
      "id_str" : "16225240",
      "id" : 16225240
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "GES2016",
      "screen_name" : "ges2016",
      "indices" : [ 95, 103 ],
      "id_str" : "4787915381",
      "id" : 4787915381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/ndFYMWAfbn",
      "expanded_url" : "http:\/\/1.usa.gov\/28Qw2ZJ",
      "display_url" : "1.usa.gov\/28Qw2ZJ"
    } ]
  },
  "geo" : { },
  "id_str" : "746392603210326016",
  "text" : "RT @TheSharkDaymond: Entrepreneurs, please join me at 1:45 pm ET in watching @POTUS remarks at @ges2016 here: https:\/\/t.co\/ndFYMWAfbn https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 56, 62 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "GES2016",
        "screen_name" : "ges2016",
        "indices" : [ 74, 82 ],
        "id_str" : "4787915381",
        "id" : 4787915381
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheSharkDaymond\/status\/746379651543601152\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/yFfuTkSob8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClusSI6WYAAT4o4.jpg",
        "id_str" : "746379590889791488",
        "id" : 746379590889791488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClusSI6WYAAT4o4.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1112,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1431,
          "resize" : "fit",
          "w" : 1544
        }, {
          "h" : 1431,
          "resize" : "fit",
          "w" : 1544
        } ],
        "display_url" : "pic.twitter.com\/yFfuTkSob8"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/ndFYMWAfbn",
        "expanded_url" : "http:\/\/1.usa.gov\/28Qw2ZJ",
        "display_url" : "1.usa.gov\/28Qw2ZJ"
      } ]
    },
    "geo" : { },
    "id_str" : "746379651543601152",
    "text" : "Entrepreneurs, please join me at 1:45 pm ET in watching @POTUS remarks at @ges2016 here: https:\/\/t.co\/ndFYMWAfbn https:\/\/t.co\/yFfuTkSob8",
    "id" : 746379651543601152,
    "created_at" : "2016-06-24 16:29:10 +0000",
    "user" : {
      "name" : "Daymond John",
      "screen_name" : "TheSharkDaymond",
      "protected" : false,
      "id_str" : "16225240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742464026781880320\/dnCGJFyT_normal.jpg",
      "id" : 16225240,
      "verified" : true
    }
  },
  "id" : 746392603210326016,
  "created_at" : "2016-06-24 17:20:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 3, 19 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 101, 114 ]
    }, {
      "text" : "Pride2016",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/w1LtqJp595",
      "expanded_url" : "http:\/\/nps.gov\/ston",
      "display_url" : "nps.gov\/ston"
    } ]
  },
  "geo" : { },
  "id_str" : "746381834854924288",
  "text" : "RT @NatlParkService: Welcome to the family #412: Stonewall National Monument https:\/\/t.co\/w1LtqJp595 #FindYourPark #Pride2016 https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NatlParkService\/status\/746379928506146816\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/tROnnPKbUT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClusdvGWAAAV2pl.jpg",
        "id_str" : "746379790119206912",
        "id" : 746379790119206912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClusdvGWAAAV2pl.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1920,
          "resize" : "fit",
          "w" : 2560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/tROnnPKbUT"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 80, 93 ]
      }, {
        "text" : "Pride2016",
        "indices" : [ 94, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/w1LtqJp595",
        "expanded_url" : "http:\/\/nps.gov\/ston",
        "display_url" : "nps.gov\/ston"
      } ]
    },
    "geo" : { },
    "id_str" : "746379928506146816",
    "text" : "Welcome to the family #412: Stonewall National Monument https:\/\/t.co\/w1LtqJp595 #FindYourPark #Pride2016 https:\/\/t.co\/tROnnPKbUT",
    "id" : 746379928506146816,
    "created_at" : "2016-06-24 16:30:16 +0000",
    "user" : {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "protected" : false,
      "id_str" : "36771809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2179200522\/NPS_SocialMediaProfilePic_Blue_normal.png",
      "id" : 36771809,
      "verified" : true
    }
  },
  "id" : 746381834854924288,
  "created_at" : "2016-06-24 16:37:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/dxUdnnY9wc",
      "expanded_url" : "http:\/\/snpy.tv\/28Q6lXd",
      "display_url" : "snpy.tv\/28Q6lXd"
    } ]
  },
  "geo" : { },
  "id_str" : "746380904520507392",
  "text" : "\"Our national parks should reflect the full story of our country.\" \u2014@POTUS announces Stonewall National Monument: https:\/\/t.co\/dxUdnnY9wc",
  "id" : 746380904520507392,
  "created_at" : "2016-06-24 16:34:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google4Entrepreneurs",
      "screen_name" : "GoogleForEntrep",
      "indices" : [ 3, 19 ],
      "id_str" : "2281044080",
      "id" : 2281044080
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GES2016",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/m2UHPgV3Ev",
      "expanded_url" : "https:\/\/goo.gl\/iB4IHs",
      "display_url" : "goo.gl\/iB4IHs"
    } ]
  },
  "geo" : { },
  "id_str" : "746380310531575808",
  "text" : "RT @GoogleForEntrep: These 4 entrepreneurs will meet with @POTUS at 12:35pm PT. Watch live: https:\/\/t.co\/m2UHPgV3Ev  #GES2016 https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 37, 43 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GoogleForEntrep\/status\/746365365614108673\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/PMplWAdUMo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClufGKcVEAAboDC.jpg",
        "id_str" : "746365091491155968",
        "id" : 746365091491155968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClufGKcVEAAboDC.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/PMplWAdUMo"
      } ],
      "hashtags" : [ {
        "text" : "GES2016",
        "indices" : [ 96, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/m2UHPgV3Ev",
        "expanded_url" : "https:\/\/goo.gl\/iB4IHs",
        "display_url" : "goo.gl\/iB4IHs"
      } ]
    },
    "geo" : { },
    "id_str" : "746365365614108673",
    "text" : "These 4 entrepreneurs will meet with @POTUS at 12:35pm PT. Watch live: https:\/\/t.co\/m2UHPgV3Ev  #GES2016 https:\/\/t.co\/PMplWAdUMo",
    "id" : 746365365614108673,
    "created_at" : "2016-06-24 15:32:24 +0000",
    "user" : {
      "name" : "Google4Entrepreneurs",
      "screen_name" : "GoogleForEntrep",
      "protected" : false,
      "id_str" : "2281044080",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653729177850408960\/qOXSi0g4_normal.png",
      "id" : 2281044080,
      "verified" : true
    }
  },
  "id" : 746380310531575808,
  "created_at" : "2016-06-24 16:31:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/dxUdnnY9wc",
      "expanded_url" : "http:\/\/snpy.tv\/28Q6lXd",
      "display_url" : "snpy.tv\/28Q6lXd"
    } ]
  },
  "geo" : { },
  "id_str" : "746372476804882432",
  "text" : ".@POTUS designates Stonewall as our first national monument to tell the story of the struggle for LGBT rights: https:\/\/t.co\/dxUdnnY9wc",
  "id" : 746372476804882432,
  "created_at" : "2016-06-24 16:00:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cleveland Cavaliers",
      "screen_name" : "cavs",
      "indices" : [ 3, 8 ],
      "id_str" : "19263978",
      "id" : 19263978
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 86, 97 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/m9xkCRCBqf",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/48090c05-e0ef-40c2-be12-ce7b5cd04103",
      "display_url" : "amp.twimg.com\/v\/48090c05-e0e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746358213537337344",
  "text" : "RT @cavs: When @POTUS calls, you answer.\n\nWatch as Coach Lue receives a ring from the @Whitehouse.\nhttps:\/\/t.co\/m9xkCRCBqf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 5, 11 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 76, 87 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/m9xkCRCBqf",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/48090c05-e0ef-40c2-be12-ce7b5cd04103",
        "display_url" : "amp.twimg.com\/v\/48090c05-e0e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746134951439958017",
    "text" : "When @POTUS calls, you answer.\n\nWatch as Coach Lue receives a ring from the @Whitehouse.\nhttps:\/\/t.co\/m9xkCRCBqf",
    "id" : 746134951439958017,
    "created_at" : "2016-06-24 00:16:49 +0000",
    "user" : {
      "name" : "Cleveland Cavaliers",
      "screen_name" : "cavs",
      "protected" : false,
      "id_str" : "19263978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785489558121091074\/vF5ijp9v_normal.jpg",
      "id" : 19263978,
      "verified" : true
    }
  },
  "id" : 746358213537337344,
  "created_at" : "2016-06-24 15:03:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecondChances",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746351688416624640",
  "text" : "RT @usedgov: 67 higher ed institutions, partnered with +100 correctional facilities, have been selected to provide #SecondChances https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/746344849637511168\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/IUzFyDFtCT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CluLQ4VWQAANoup.jpg",
        "id_str" : "746343285376040960",
        "id" : 746343285376040960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CluLQ4VWQAANoup.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 882
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 882
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 882
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/IUzFyDFtCT"
      } ],
      "hashtags" : [ {
        "text" : "SecondChances",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746344849637511168",
    "text" : "67 higher ed institutions, partnered with +100 correctional facilities, have been selected to provide #SecondChances https:\/\/t.co\/IUzFyDFtCT",
    "id" : 746344849637511168,
    "created_at" : "2016-06-24 14:10:53 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 746351688416624640,
  "created_at" : "2016-06-24 14:38:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/746334377131577348\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/gI76eRleD0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CluDH2LWYAAF5jm.jpg",
      "id_str" : "746334334085390336",
      "id" : 746334334085390336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CluDH2LWYAAF5jm.jpg",
      "sizes" : [ {
        "h" : 314,
        "resize" : "fit",
        "w" : 830
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 830
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 830
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/gI76eRleD0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746334377131577348",
  "text" : "\u201CThe United Kingdom and the European Union will remain indispensable partners of the United States\u201D \u2014@POTUS https:\/\/t.co\/gI76eRleD0",
  "id" : 746334377131577348,
  "created_at" : "2016-06-24 13:29:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/746127967529603076\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/LhT6pj03WZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClrHUGsUgAEabA9.jpg",
      "id_str" : "746127836491055105",
      "id" : 746127836491055105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClrHUGsUgAEabA9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/LhT6pj03WZ"
    } ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/eZwdRbn8YE",
      "expanded_url" : "http:\/\/wh.gov\/FilmFest",
      "display_url" : "wh.gov\/FilmFest"
    } ]
  },
  "geo" : { },
  "id_str" : "746127967529603076",
  "text" : "Calling all student film makers! Here's how you can join us for the #WHFilmFest \uD83C\uDFA5 \u2192 https:\/\/t.co\/eZwdRbn8YE https:\/\/t.co\/LhT6pj03WZ",
  "id" : 746127967529603076,
  "created_at" : "2016-06-23 23:49:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphyCT",
      "indices" : [ 3, 17 ],
      "id_str" : "150078976",
      "id" : 150078976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746100514740281344",
  "text" : "RT @ChrisMurphyCT: Cases of #Zika are on the rise &amp; those numbers will only go up. We need to stop playing games &amp; fund this urgent public\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 9, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746042215856738304",
    "text" : "Cases of #Zika are on the rise &amp; those numbers will only go up. We need to stop playing games &amp; fund this urgent public health crisis",
    "id" : 746042215856738304,
    "created_at" : "2016-06-23 18:08:19 +0000",
    "user" : {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphyCT",
      "protected" : false,
      "id_str" : "150078976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738767780246396928\/YrcsMalf_normal.jpg",
      "id" : 150078976,
      "verified" : true
    }
  },
  "id" : 746100514740281344,
  "created_at" : "2016-06-23 21:59:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746084879683575808",
  "text" : "RT @lacasablanca: \"Es angustioso para los millones de inmigrantes que han hecho sus vidas aqu\u00ED\" \u2014@POTUS sobre la decisi\u00F3n de #SCOTUS: https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 79, 85 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/3d1dTDrRkO",
        "expanded_url" : "http:\/\/snpy.tv\/28PC91Q",
        "display_url" : "snpy.tv\/28PC91Q"
      } ]
    },
    "geo" : { },
    "id_str" : "746070453723136000",
    "text" : "\"Es angustioso para los millones de inmigrantes que han hecho sus vidas aqu\u00ED\" \u2014@POTUS sobre la decisi\u00F3n de #SCOTUS: https:\/\/t.co\/3d1dTDrRkO",
    "id" : 746070453723136000,
    "created_at" : "2016-06-23 20:00:32 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 746084879683575808,
  "created_at" : "2016-06-23 20:57:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Businessweek",
      "screen_name" : "BW",
      "indices" : [ 95, 98 ],
      "id_str" : "67358777",
      "id" : 67358777
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/wk2u2W6tlg",
      "expanded_url" : "http:\/\/bloom.bg\/28XwPrt",
      "display_url" : "bloom.bg\/28XwPrt"
    } ]
  },
  "geo" : { },
  "id_str" : "746074273425432576",
  "text" : "\"We have to pay attention to the trends that push toward greater inequality\" \u2014@POTUS speaks to @BW: https:\/\/t.co\/wk2u2W6tlg",
  "id" : 746074273425432576,
  "created_at" : "2016-06-23 20:15:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Businessweek",
      "screen_name" : "BW",
      "indices" : [ 3, 6 ],
      "id_str" : "67358777",
      "id" : 67358777
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BW\/status\/745908574178713600\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/hy1i8YcOVv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cln_45NWAAAZWJJ.jpg",
      "id_str" : "745908566201073664",
      "id" : 745908566201073664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cln_45NWAAAZWJJ.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 3150,
        "resize" : "fit",
        "w" : 2363
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/hy1i8YcOVv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/RGk47ZelkN",
      "expanded_url" : "http:\/\/bloom.bg\/28XwPrt",
      "display_url" : "bloom.bg\/28XwPrt"
    } ]
  },
  "geo" : { },
  "id_str" : "746068710993993729",
  "text" : "RT @BW: NEW COVER: We talked the economy, free trade, and higher wages with President Obama https:\/\/t.co\/RGk47ZelkN https:\/\/t.co\/hy1i8YcOVv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BW\/status\/745908574178713600\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/hy1i8YcOVv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cln_45NWAAAZWJJ.jpg",
        "id_str" : "745908566201073664",
        "id" : 745908566201073664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cln_45NWAAAZWJJ.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 3150,
          "resize" : "fit",
          "w" : 2363
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/hy1i8YcOVv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/RGk47ZelkN",
        "expanded_url" : "http:\/\/bloom.bg\/28XwPrt",
        "display_url" : "bloom.bg\/28XwPrt"
      } ]
    },
    "geo" : { },
    "id_str" : "745908574178713600",
    "text" : "NEW COVER: We talked the economy, free trade, and higher wages with President Obama https:\/\/t.co\/RGk47ZelkN https:\/\/t.co\/hy1i8YcOVv",
    "id" : 745908574178713600,
    "created_at" : "2016-06-23 09:17:17 +0000",
    "user" : {
      "name" : "Businessweek",
      "screen_name" : "BW",
      "protected" : false,
      "id_str" : "67358777",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714805970556297216\/15vpk5RQ_normal.jpg",
      "id" : 67358777,
      "verified" : true
    }
  },
  "id" : 746068710993993729,
  "created_at" : "2016-06-23 19:53:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 98, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/wk2u2W6tlg",
      "expanded_url" : "http:\/\/bloom.bg\/28XwPrt",
      "display_url" : "bloom.bg\/28XwPrt"
    } ]
  },
  "geo" : { },
  "id_str" : "746060206342234112",
  "text" : "\"Our goal...should be to try to shape trade deals that raise standards everywhere.\" \u2014POTUS on the #TPP: https:\/\/t.co\/wk2u2W6tlg",
  "id" : 746060206342234112,
  "created_at" : "2016-06-23 19:19:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoBillNoBreak",
      "indices" : [ 41, 55 ]
    }, {
      "text" : "DisarmHate",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746043663952773120",
  "text" : "RT @NancyPelosi: To everyone calling for #NoBillNoBreak &amp; fighting to reduce gun violence in America: thank you. We will #DisarmHate. https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/746041633406353408\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/JTfEwcMC4p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Clp449KWEAEmeN5.jpg",
        "id_str" : "746041608169197569",
        "id" : 746041608169197569,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clp449KWEAEmeN5.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        } ],
        "display_url" : "pic.twitter.com\/JTfEwcMC4p"
      } ],
      "hashtags" : [ {
        "text" : "NoBillNoBreak",
        "indices" : [ 24, 38 ]
      }, {
        "text" : "DisarmHate",
        "indices" : [ 108, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746041633406353408",
    "text" : "To everyone calling for #NoBillNoBreak &amp; fighting to reduce gun violence in America: thank you. We will #DisarmHate. https:\/\/t.co\/JTfEwcMC4p",
    "id" : 746041633406353408,
    "created_at" : "2016-06-23 18:06:00 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 746043663952773120,
  "created_at" : "2016-06-23 18:14:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Schiff",
      "screen_name" : "RepAdamSchiff",
      "indices" : [ 3, 17 ],
      "id_str" : "29501253",
      "id" : 29501253
    }, {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 20, 33 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746041424618086400",
  "text" : "RT @RepAdamSchiff: .@repjohnlewis ends sit-in for now, harkening back to the civil rights movement \"when I was in jail, I felt free.\" https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Lewis",
        "screen_name" : "repjohnlewis",
        "indices" : [ 1, 14 ],
        "id_str" : "29450962",
        "id" : 29450962
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RepAdamSchiff\/status\/746031092570931201\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/HliCDWYOBL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Clpua1nWQAE7XaI.jpg",
        "id_str" : "746030095631007745",
        "id" : 746030095631007745,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clpua1nWQAE7XaI.jpg",
        "sizes" : [ {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1419,
          "resize" : "fit",
          "w" : 1893
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1419,
          "resize" : "fit",
          "w" : 1893
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/HliCDWYOBL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746031092570931201",
    "text" : ".@repjohnlewis ends sit-in for now, harkening back to the civil rights movement \"when I was in jail, I felt free.\" https:\/\/t.co\/HliCDWYOBL",
    "id" : 746031092570931201,
    "created_at" : "2016-06-23 17:24:07 +0000",
    "user" : {
      "name" : "Adam Schiff",
      "screen_name" : "RepAdamSchiff",
      "protected" : false,
      "id_str" : "29501253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553289858924285952\/asUU5hh9_normal.png",
      "id" : 29501253,
      "verified" : true
    }
  },
  "id" : 746041424618086400,
  "created_at" : "2016-06-23 18:05:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746039012901650432",
  "text" : "RT @FLOTUS: It is time to come together and do something worthy of the memory of those we have lost and the future we want for our children\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Enough",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "746037587782041600",
    "geo" : { },
    "id_str" : "746038342878269440",
    "in_reply_to_user_id" : 1093090866,
    "text" : "It is time to come together and do something worthy of the memory of those we have lost and the future we want for our children. #Enough -mo",
    "id" : 746038342878269440,
    "in_reply_to_status_id" : 746037587782041600,
    "created_at" : "2016-06-23 17:52:56 +0000",
    "in_reply_to_screen_name" : "FLOTUS",
    "in_reply_to_user_id_str" : "1093090866",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 746039012901650432,
  "created_at" : "2016-06-23 17:55:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Enough",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746038812569133056",
  "text" : "RT @FLOTUS: If there is even one step we can take to save just one life from gun violence, then we have a moral obligation to try. #Enough",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Enough",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "746036844198977537",
    "geo" : { },
    "id_str" : "746037587782041600",
    "in_reply_to_user_id" : 1093090866,
    "text" : "If there is even one step we can take to save just one life from gun violence, then we have a moral obligation to try. #Enough",
    "id" : 746037587782041600,
    "in_reply_to_status_id" : 746036844198977537,
    "created_at" : "2016-06-23 17:49:56 +0000",
    "in_reply_to_screen_name" : "FLOTUS",
    "in_reply_to_user_id_str" : "1093090866",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 746038812569133056,
  "created_at" : "2016-06-23 17:54:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746038663964925952",
  "text" : "RT @FLOTUS: We have grieved for too many children and wept for too many families after shootings. Chicago. Tucson. Newtown. Charleston. Orl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Enough",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "746036617563930624",
    "geo" : { },
    "id_str" : "746036844198977537",
    "in_reply_to_user_id" : 1093090866,
    "text" : "We have grieved for too many children and wept for too many families after shootings. Chicago. Tucson. Newtown. Charleston. Orlando. #Enough",
    "id" : 746036844198977537,
    "in_reply_to_status_id" : 746036617563930624,
    "created_at" : "2016-06-23 17:46:59 +0000",
    "in_reply_to_screen_name" : "FLOTUS",
    "in_reply_to_user_id_str" : "1093090866",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 746038663964925952,
  "created_at" : "2016-06-23 17:54:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoodTrouble",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/TFblz1HQcM",
      "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/746026115467218944",
      "display_url" : "twitter.com\/repjohnlewis\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "746038259063656448",
  "text" : "RT @FLOTUS: So proud of everyone who stood up by sitting down. #GoodTrouble https:\/\/t.co\/TFblz1HQcM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoodTrouble",
        "indices" : [ 51, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/TFblz1HQcM",
        "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/746026115467218944",
        "display_url" : "twitter.com\/repjohnlewis\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "746036617563930624",
    "text" : "So proud of everyone who stood up by sitting down. #GoodTrouble https:\/\/t.co\/TFblz1HQcM",
    "id" : 746036617563930624,
    "created_at" : "2016-06-23 17:46:04 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 746038259063656448,
  "created_at" : "2016-06-23 17:52:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "indices" : [ 3, 17 ],
      "id_str" : "43920155",
      "id" : 43920155
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DOTSmartCity",
      "indices" : [ 49, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/TPBzZ82bAQ",
      "expanded_url" : "https:\/\/vine.co\/v\/5BQlJtBTvrK",
      "display_url" : "vine.co\/v\/5BQlJtBTvrK"
    } ]
  },
  "geo" : { },
  "id_str" : "746032945085964288",
  "text" : "RT @SecretaryFoxx: And the winner is...Columbus! #DOTSmartCity https:\/\/t.co\/TPBzZ82bAQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DOTSmartCity",
        "indices" : [ 30, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/TPBzZ82bAQ",
        "expanded_url" : "https:\/\/vine.co\/v\/5BQlJtBTvrK",
        "display_url" : "vine.co\/v\/5BQlJtBTvrK"
      } ]
    },
    "geo" : { },
    "id_str" : "746016528294887424",
    "text" : "And the winner is...Columbus! #DOTSmartCity https:\/\/t.co\/TPBzZ82bAQ",
    "id" : 746016528294887424,
    "created_at" : "2016-06-23 16:26:15 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 746032945085964288,
  "created_at" : "2016-06-23 17:31:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/9P7ZJ312W0",
      "expanded_url" : "http:\/\/snpy.tv\/28SFgIl",
      "display_url" : "snpy.tv\/28SFgIl"
    } ]
  },
  "geo" : { },
  "id_str" : "746025227168014336",
  "text" : "\u201CImmigration is not something to fear\u2026What makes us American is our shared commitment to an ideal\u201D \u2014@POTUS: https:\/\/t.co\/9P7ZJ312W0",
  "id" : 746025227168014336,
  "created_at" : "2016-06-23 17:00:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 48, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746022683989647360",
  "text" : "RT @SCOTUSnom: Watch @POTUS explain why today's #SCOTUS 4-4 ruling on immigration reflects the Senate Rs' failure on Judge Garland. https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 33, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/2E37E2ghKq",
        "expanded_url" : "http:\/\/snpy.tv\/28PC91Q",
        "display_url" : "snpy.tv\/28PC91Q"
      } ]
    },
    "geo" : { },
    "id_str" : "746019643278516224",
    "text" : "Watch @POTUS explain why today's #SCOTUS 4-4 ruling on immigration reflects the Senate Rs' failure on Judge Garland. https:\/\/t.co\/2E37E2ghKq",
    "id" : 746019643278516224,
    "created_at" : "2016-06-23 16:38:37 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 746022683989647360,
  "created_at" : "2016-06-23 16:50:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/egpB1r3FEN",
      "expanded_url" : "http:\/\/snpy.tv\/28PC91Q",
      "display_url" : "snpy.tv\/28PC91Q"
    } ]
  },
  "geo" : { },
  "id_str" : "746020255378485248",
  "text" : "\"It is heartbreaking for the millions of immigrants who\u2019ve made their lives here\" \u2014@POTUS on #SCOTUS\u2019s ruling: https:\/\/t.co\/egpB1r3FEN",
  "id" : 746020255378485248,
  "created_at" : "2016-06-23 16:41:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746018045026459648",
  "text" : "RT @SCOTUSnom: \"If you keep on blocking judges from getting on the bench, then courts can't issue decisions.\" \u2014@POTUS #SCOTUS  https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 96, 102 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 103, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/bmWwvrvPkV",
        "expanded_url" : "http:\/\/snpy.tv\/28STEk9",
        "display_url" : "snpy.tv\/28STEk9"
      } ]
    },
    "geo" : { },
    "id_str" : "746017651042856960",
    "text" : "\"If you keep on blocking judges from getting on the bench, then courts can't issue decisions.\" \u2014@POTUS #SCOTUS  https:\/\/t.co\/bmWwvrvPkV",
    "id" : 746017651042856960,
    "created_at" : "2016-06-23 16:30:43 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 746018045026459648,
  "created_at" : "2016-06-23 16:32:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 8, 14 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 30, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/kdrhQQbPiS",
      "expanded_url" : "http:\/\/snpy.tv\/28PhlVp",
      "display_url" : "snpy.tv\/28PhlVp"
    } ]
  },
  "geo" : { },
  "id_str" : "746016909913526272",
  "text" : "Watch \u2192 @POTUS on why today's #SCOTUS decision sets us back even further\non immigration reform: https:\/\/t.co\/kdrhQQbPiS",
  "id" : 746016909913526272,
  "created_at" : "2016-06-23 16:27:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 19, 26 ]
    }, {
      "text" : "immigration",
      "indices" : [ 37, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/zcBWEIT8Ai",
      "expanded_url" : "http:\/\/go.wh.gov\/6ahJPi",
      "display_url" : "go.wh.gov\/6ahJPi"
    }, {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/egpB1r3FEN",
      "expanded_url" : "http:\/\/snpy.tv\/28PC91Q",
      "display_url" : "snpy.tv\/28PC91Q"
    } ]
  },
  "geo" : { },
  "id_str" : "746014015596310528",
  "text" : ".@POTUS on today's #SCOTUS ruling on #immigration: https:\/\/t.co\/zcBWEIT8Ai https:\/\/t.co\/egpB1r3FEN",
  "id" : 746014015596310528,
  "created_at" : "2016-06-23 16:16:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746011257904345089",
  "text" : "\u201CI promise you this though: sooner or later, immigration reform will get done.\u201D \u2014@POTUS",
  "id" : 746011257904345089,
  "created_at" : "2016-06-23 16:05:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746009765591941120",
  "text" : "\"It\u2019s heartbreaking for the millions of immigrants who\u2019ve made their lives here; who\u2019ve raised families here\" \u2014@POTUS on #SCOTUS ruling",
  "id" : 746009765591941120,
  "created_at" : "2016-06-23 15:59:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746008641145208832",
  "text" : "\u201CThe fact that the Supreme Court wasn\u2019t able to issue a decision in this case sets it back even further.\u201D \u2014@POTUS on #immigration ruling",
  "id" : 746008641145208832,
  "created_at" : "2016-06-23 15:54:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746008417144233988",
  "text" : "\u201COne of the reasons why America is such a diverse and inclusive nation is because we\u2019re a nation of immigrants\u201D \u2014@POTUS",
  "id" : 746008417144233988,
  "created_at" : "2016-06-23 15:54:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FishervUT",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746008302576771072",
  "text" : "\u201CI\u2019m pleased that the Supreme Court upheld the basic notion that diversity is an important value in our society\u201D \u2014@POTUS on #FishervUT",
  "id" : 746008302576771072,
  "created_at" : "2016-06-23 15:53:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/zcBWEIT8Ai",
      "expanded_url" : "http:\/\/go.wh.gov\/6ahJPi",
      "display_url" : "go.wh.gov\/6ahJPi"
    } ]
  },
  "geo" : { },
  "id_str" : "746008178001739776",
  "text" : "Happening now: @POTUS speaks on immigration after today\u2019s #SCOTUS ruling \u2192 https:\/\/t.co\/zcBWEIT8Ai",
  "id" : 746008178001739776,
  "created_at" : "2016-06-23 15:53:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746005941766651904",
  "text" : "RT @lacasablanca: Somos un pa\u00EDs de inmigrantes. @POTUS hablara sobre la decisi\u00F3n de la Corte Suprema. En vivo 11:45am ET:  https:\/\/t.co\/YAf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 30, 36 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/YAfTXsLhQh",
        "expanded_url" : "http:\/\/go.wh.gov\/6ahJPi",
        "display_url" : "go.wh.gov\/6ahJPi"
      } ]
    },
    "geo" : { },
    "id_str" : "746005772266438656",
    "text" : "Somos un pa\u00EDs de inmigrantes. @POTUS hablara sobre la decisi\u00F3n de la Corte Suprema. En vivo 11:45am ET:  https:\/\/t.co\/YAfTXsLhQh",
    "id" : 746005772266438656,
    "created_at" : "2016-06-23 15:43:30 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 746005941766651904,
  "created_at" : "2016-06-23 15:44:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/zcBWEIT8Ai",
      "expanded_url" : "http:\/\/go.wh.gov\/6ahJPi",
      "display_url" : "go.wh.gov\/6ahJPi"
    } ]
  },
  "geo" : { },
  "id_str" : "746004195132616706",
  "text" : "Watch live at 11:45am ET: @POTUS delivers a statement after today\u2019s Supreme Court decision on immigration reform \u2192 https:\/\/t.co\/zcBWEIT8Ai",
  "id" : 746004195132616706,
  "created_at" : "2016-06-23 15:37:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 49, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/UI3Jh1wGtk",
      "expanded_url" : "http:\/\/playerstribu.ne\/POTUSJeterConvo",
      "display_url" : "playerstribu.ne\/POTUSJeterConvo"
    }, {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/FbKOSa0uOY",
      "expanded_url" : "http:\/\/snpy.tv\/28UNYSt",
      "display_url" : "snpy.tv\/28UNYSt"
    } ]
  },
  "geo" : { },
  "id_str" : "745977940123463680",
  "text" : ".@POTUS sits down with Derek Jeter to talk about #MyBrothersKeeper: https:\/\/t.co\/UI3Jh1wGtk https:\/\/t.co\/FbKOSa0uOY",
  "id" : 745977940123463680,
  "created_at" : "2016-06-23 13:52:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Barbara Lee",
      "screen_name" : "RepBarbaraLee",
      "indices" : [ 3, 17 ],
      "id_str" : "248735463",
      "id" : 248735463
    }, {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 65, 78 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoBillNoBreak",
      "indices" : [ 109, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745814061992939520",
  "text" : "RT @RepBarbaraLee: History being made on the House floor. Led by @RepJohnLewis, we sang \"We Shall Overcome.\" #NoBillNoBreak\nhttps:\/\/t.co\/Br\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Lewis",
        "screen_name" : "repjohnlewis",
        "indices" : [ 46, 59 ],
        "id_str" : "29450962",
        "id" : 29450962
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NoBillNoBreak",
        "indices" : [ 90, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/BrV2N5kl6n",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/896fe53d-1d85-43b2-b479-abd15b3fb742",
        "display_url" : "amp.twimg.com\/v\/896fe53d-1d8\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745810277896073216",
    "text" : "History being made on the House floor. Led by @RepJohnLewis, we sang \"We Shall Overcome.\" #NoBillNoBreak\nhttps:\/\/t.co\/BrV2N5kl6n",
    "id" : 745810277896073216,
    "created_at" : "2016-06-23 02:46:41 +0000",
    "user" : {
      "name" : "Rep. Barbara Lee",
      "screen_name" : "RepBarbaraLee",
      "protected" : false,
      "id_str" : "248735463",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430378206353317888\/3QKYak-Z_normal.jpeg",
      "id" : 248735463,
      "verified" : true
    }
  },
  "id" : 745814061992939520,
  "created_at" : "2016-06-23 03:01:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745803391100555264",
  "text" : "RT @Simas44: Vote to protect Wall Street conflicts of interest proceeds while House Dems demand vote to protect people from gun violence. #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Enough",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745801472059793408",
    "text" : "Vote to protect Wall Street conflicts of interest proceeds while House Dems demand vote to protect people from gun violence. #Enough",
    "id" : 745801472059793408,
    "created_at" : "2016-06-23 02:11:41 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 745803391100555264,
  "created_at" : "2016-06-23 02:19:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/745772146207555585\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/Npi2BuKclF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cll7sNcUYAQut-G.jpg",
      "id_str" : "745763212759425028",
      "id" : 745763212759425028,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cll7sNcUYAQut-G.jpg",
      "sizes" : [ {
        "h" : 1429,
        "resize" : "fit",
        "w" : 1247
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1047
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1429,
        "resize" : "fit",
        "w" : 1247
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 593
      } ],
      "display_url" : "pic.twitter.com\/Npi2BuKclF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/X3aS9PuUgt",
      "expanded_url" : "http:\/\/go.wh.gov\/PimE37",
      "display_url" : "go.wh.gov\/PimE37"
    } ]
  },
  "geo" : { },
  "id_str" : "745772146207555585",
  "text" : "One mom of a son on the road to recovery wrote to @POTUS about opioids. Read his response: https:\/\/t.co\/X3aS9PuUgt https:\/\/t.co\/Npi2BuKclF",
  "id" : 745772146207555585,
  "created_at" : "2016-06-23 00:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoBillNoBreak",
      "indices" : [ 93, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/GSw4TkZxKB",
      "expanded_url" : "http:\/\/snpy.tv\/28N7ErM",
      "display_url" : "snpy.tv\/28N7ErM"
    } ]
  },
  "geo" : { },
  "id_str" : "745760847486541825",
  "text" : "\"We need our kids to hear us speak up about the risks guns pose to our communities.\" \u2014@POTUS #NoBillNoBreak https:\/\/t.co\/GSw4TkZxKB",
  "id" : 745760847486541825,
  "created_at" : "2016-06-22 23:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Ancestry",
      "screen_name" : "ancestry",
      "indices" : [ 13, 22 ],
      "id_str" : "16754078",
      "id" : 16754078
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 42, 45 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BidenInIreland",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/APw6JPUQW7",
      "expanded_url" : "http:\/\/www.ancestry.com\/cs\/biden-in-ireland",
      "display_url" : "ancestry.com\/cs\/biden-in-ir\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745750045014761472",
  "text" : "RT @VPLive: .@ancestry is chronicling the @VP's trip through Ireland, too! Follow along: https:\/\/t.co\/APw6JPUQW7 #BidenInIreland https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ancestry",
        "screen_name" : "ancestry",
        "indices" : [ 1, 10 ],
        "id_str" : "16754078",
        "id" : 16754078
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 30, 33 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/745748255204573188\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/cVXnFkbzy4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClltmeaWEAApgVu.jpg",
        "id_str" : "745747721072545792",
        "id" : 745747721072545792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClltmeaWEAApgVu.jpg",
        "sizes" : [ {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/cVXnFkbzy4"
      } ],
      "hashtags" : [ {
        "text" : "BidenInIreland",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/APw6JPUQW7",
        "expanded_url" : "http:\/\/www.ancestry.com\/cs\/biden-in-ireland",
        "display_url" : "ancestry.com\/cs\/biden-in-ir\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745748255204573188",
    "text" : ".@ancestry is chronicling the @VP's trip through Ireland, too! Follow along: https:\/\/t.co\/APw6JPUQW7 #BidenInIreland https:\/\/t.co\/cVXnFkbzy4",
    "id" : 745748255204573188,
    "created_at" : "2016-06-22 22:40:14 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 745750045014761472,
  "created_at" : "2016-06-22 22:47:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoBillNoBreak",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745741284866920448",
  "text" : "RT @PressSec: .@POTUS called on Congress to take action on commonsense gun reforms. That's what our kids deserve. #NoBillNoBreak https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NoBillNoBreak",
        "indices" : [ 100, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/Jo7zfbHjuf",
        "expanded_url" : "http:\/\/snpy.tv\/28N7ErM",
        "display_url" : "snpy.tv\/28N7ErM"
      } ]
    },
    "geo" : { },
    "id_str" : "745741080029601792",
    "text" : ".@POTUS called on Congress to take action on commonsense gun reforms. That's what our kids deserve. #NoBillNoBreak https:\/\/t.co\/Jo7zfbHjuf",
    "id" : 745741080029601792,
    "created_at" : "2016-06-22 22:11:43 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 745741284866920448,
  "created_at" : "2016-06-22 22:12:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoBillNoBreak",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/GSw4TkZxKB",
      "expanded_url" : "http:\/\/snpy.tv\/28N7ErM",
      "display_url" : "snpy.tv\/28N7ErM"
    } ]
  },
  "geo" : { },
  "id_str" : "745723479824097280",
  "text" : "\"If we\u2019re going to raise our kids in a safer, more loving world, we need to speak up for it.\" \u2014@POTUS #NoBillNoBreak https:\/\/t.co\/GSw4TkZxKB",
  "id" : 745723479824097280,
  "created_at" : "2016-06-22 21:01:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 11, 24 ],
      "id_str" : "29450962",
      "id" : 29450962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NoBillNoBreak",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745714402075222016",
  "text" : "RT @vj44: .@RepJohnLewis just said, \"It is always right to do right.\" Right on! #NoBillNoBreak",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Lewis",
        "screen_name" : "repjohnlewis",
        "indices" : [ 1, 14 ],
        "id_str" : "29450962",
        "id" : 29450962
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NoBillNoBreak",
        "indices" : [ 70, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745689223232094216",
    "text" : ".@RepJohnLewis just said, \"It is always right to do right.\" Right on! #NoBillNoBreak",
    "id" : 745689223232094216,
    "created_at" : "2016-06-22 18:45:39 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 745714402075222016,
  "created_at" : "2016-06-22 20:25:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/D9CW2A3a2B",
      "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/745644565433028608",
      "display_url" : "twitter.com\/repjohnlewis\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745696865681838080",
  "text" : "RT @VP: Always the keeper of the nation's conscience at times of challenge and controversy. Thank you, John Lewis. https:\/\/t.co\/D9CW2A3a2B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/D9CW2A3a2B",
        "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/745644565433028608",
        "display_url" : "twitter.com\/repjohnlewis\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745678222994464770",
    "text" : "Always the keeper of the nation's conscience at times of challenge and controversy. Thank you, John Lewis. https:\/\/t.co\/D9CW2A3a2B",
    "id" : 745678222994464770,
    "created_at" : "2016-06-22 18:01:57 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 745696865681838080,
  "created_at" : "2016-06-22 19:16:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "indices" : [ 3, 16 ],
      "id_str" : "29450962",
      "id" : 29450962
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745691891820339201",
  "text" : "RT @repjohnlewis: @POTUS Thank you, Mr. President. I'm just trying to help out and make a contribution.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "745674203286773761",
    "geo" : { },
    "id_str" : "745674739344097280",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS Thank you, Mr. President. I'm just trying to help out and make a contribution.",
    "id" : 745674739344097280,
    "in_reply_to_status_id" : 745674203286773761,
    "created_at" : "2016-06-22 17:48:06 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "John Lewis",
      "screen_name" : "repjohnlewis",
      "protected" : false,
      "id_str" : "29450962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751446634429575169\/KWfWsq0W_normal.jpg",
      "id" : 29450962,
      "verified" : true
    }
  },
  "id" : 745691891820339201,
  "created_at" : "2016-06-22 18:56:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/vctfqAH5Wt",
      "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/745631702186336256",
      "display_url" : "twitter.com\/repjohnlewis\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745674256596480000",
  "text" : "RT @POTUS: Thank you John Lewis for leading on gun violence where we need it most. https:\/\/t.co\/vctfqAH5Wt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/vctfqAH5Wt",
        "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/745631702186336256",
        "display_url" : "twitter.com\/repjohnlewis\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745674203286773761",
    "text" : "Thank you John Lewis for leading on gun violence where we need it most. https:\/\/t.co\/vctfqAH5Wt",
    "id" : 745674203286773761,
    "created_at" : "2016-06-22 17:45:58 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 745674256596480000,
  "created_at" : "2016-06-22 17:46:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WednesdayWisdom",
      "indices" : [ 14, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/qB9d2QIpN4",
      "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/745631702186336256",
      "display_url" : "twitter.com\/repjohnlewis\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745649582953070592",
  "text" : "RT @PressSec: #WednesdayWisdom  https:\/\/t.co\/qB9d2QIpN4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WednesdayWisdom",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/qB9d2QIpN4",
        "expanded_url" : "https:\/\/twitter.com\/repjohnlewis\/status\/745631702186336256",
        "display_url" : "twitter.com\/repjohnlewis\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745649380036775936",
    "text" : "#WednesdayWisdom  https:\/\/t.co\/qB9d2QIpN4",
    "id" : 745649380036775936,
    "created_at" : "2016-06-22 16:07:20 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 745649582953070592,
  "created_at" : "2016-06-22 16:08:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 84, 88 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TSCA",
      "indices" : [ 44, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745647615694471168",
  "text" : "RT @GinaEPA: Today @POTUS signed bipartisan #TSCA reform, huge step forward to help @EPA protect Americans from toxic chemicals. https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 71, 75 ],
        "id_str" : "14615871",
        "id" : 14615871
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TSCA",
        "indices" : [ 31, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/EUQbInRMHD",
        "expanded_url" : "https:\/\/blog.epa.gov\/blog\/2016\/06\/tsca-reform-a-bipartisan-milestone-to-protect-our-health-from-dangerous-chemicals\/",
        "display_url" : "blog.epa.gov\/blog\/2016\/06\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "745646146756935684",
    "text" : "Today @POTUS signed bipartisan #TSCA reform, huge step forward to help @EPA protect Americans from toxic chemicals. https:\/\/t.co\/EUQbInRMHD",
    "id" : 745646146756935684,
    "created_at" : "2016-06-22 15:54:29 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 745647615694471168,
  "created_at" : "2016-06-22 16:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChemicalSafety",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/3YoAKwoq9G",
      "expanded_url" : "http:\/\/snpy.tv\/28RefDU",
      "display_url" : "snpy.tv\/28RefDU"
    } ]
  },
  "geo" : { },
  "id_str" : "745646174141616128",
  "text" : "\u201CFor the first time...we\u2019ll actually be able to regulate chemicals effectively.\u201D \u2014@POTUS on #ChemicalSafety Act: https:\/\/t.co\/3YoAKwoq9G",
  "id" : 745646174141616128,
  "created_at" : "2016-06-22 15:54:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChemicalSafety",
      "indices" : [ 106, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745642332381384704",
  "text" : "\u201CFor the first time in our history, we\u2019ll actually be able to regulate chemicals effectively.\u201D \u2014@POTUS on #ChemicalSafety reform",
  "id" : 745642332381384704,
  "created_at" : "2016-06-22 15:39:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChemicalSafety",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745642144812179456",
  "text" : "\u201CFor the first time in 20 years, we\u2019re updating a national environmental statute.\" \u2014@POTUS on #ChemicalSafety reform",
  "id" : 745642144812179456,
  "created_at" : "2016-06-22 15:38:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/ZoK5A4UhgL",
      "expanded_url" : "http:\/\/go.wh.gov\/Zc31fR",
      "display_url" : "go.wh.gov\/Zc31fR"
    } ]
  },
  "geo" : { },
  "id_str" : "745640642555056128",
  "text" : "Happening now: @POTUS signs the Frank R. Lautenberg Chemical Safety for the 21st Century Act \u2192 https:\/\/t.co\/ZoK5A4UhgL",
  "id" : 745640642555056128,
  "created_at" : "2016-06-22 15:32:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/745394184253636608\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/2MjkLY7HjK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Clgr3toUYAQA2z4.jpg",
      "id_str" : "745393974471319556",
      "id" : 745393974471319556,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clgr3toUYAQA2z4.jpg",
      "sizes" : [ {
        "h" : 731,
        "resize" : "fit",
        "w" : 1290
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1290
      } ],
      "display_url" : "pic.twitter.com\/2MjkLY7HjK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/0J9a6CXCnb",
      "expanded_url" : "http:\/\/go.wh.gov\/STEM100",
      "display_url" : "go.wh.gov\/STEM100"
    } ]
  },
  "geo" : { },
  "id_str" : "745394184253636608",
  "text" : "Since 2008, wind power has tripled.\nSolar power has grown by more than 30-fold.\nhttps:\/\/t.co\/0J9a6CXCnb https:\/\/t.co\/2MjkLY7HjK",
  "id" : 745394184253636608,
  "created_at" : "2016-06-21 23:13:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745368606402191361",
  "text" : "RT @whitehouseostp: Big news: Dr. Holdren's going live tomorrow at 12:30pm ET on @POTUS's 100 science achievements with Dr. Jim Gates: http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 61, 67 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/MqU0nwk5VM",
        "expanded_url" : "http:\/\/facebook.com\/WhiteHouse",
        "display_url" : "facebook.com\/WhiteHouse"
      } ]
    },
    "geo" : { },
    "id_str" : "745363413866536960",
    "text" : "Big news: Dr. Holdren's going live tomorrow at 12:30pm ET on @POTUS's 100 science achievements with Dr. Jim Gates: https:\/\/t.co\/MqU0nwk5VM",
    "id" : 745363413866536960,
    "created_at" : "2016-06-21 21:11:00 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 745368606402191361,
  "created_at" : "2016-06-21 21:31:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745358521139503105",
  "text" : "RT @PressSec: Said this in today's briefing but it bears repeating: The Senate's failure on gun violence last night is a textbook definitio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745356683552030720",
    "text" : "Said this in today's briefing but it bears repeating: The Senate's failure on gun violence last night is a textbook definition of cowardice.",
    "id" : 745356683552030720,
    "created_at" : "2016-06-21 20:44:16 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 745358521139503105,
  "created_at" : "2016-06-21 20:51:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 3, 16 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745347957839568896",
  "text" : "RT @LorettaLynch: We must examine how to make our country a place of safety for all\u2014no matter who we are, what we look like, &amp; whom we love\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OrlandoUnited",
        "indices" : [ 127, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742882204951273472",
    "text" : "We must examine how to make our country a place of safety for all\u2014no matter who we are, what we look like, &amp; whom we love. #OrlandoUnited",
    "id" : 742882204951273472,
    "created_at" : "2016-06-15 00:51:34 +0000",
    "user" : {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "protected" : false,
      "id_str" : "3290070855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657296962052468736\/BBNYJ8rH_normal.jpg",
      "id" : 3290070855,
      "verified" : true
    }
  },
  "id" : 745347957839568896,
  "created_at" : "2016-06-21 20:09:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R. David Edelman",
      "screen_name" : "rD44",
      "indices" : [ 3, 8 ],
      "id_str" : "4073671214",
      "id" : 4073671214
    }, {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "indices" : [ 37, 51 ],
      "id_str" : "43920155",
      "id" : 43920155
    }, {
      "name" : "TransportationGov",
      "screen_name" : "USDOT",
      "indices" : [ 56, 62 ],
      "id_str" : "393562221",
      "id" : 393562221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UAS",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/TNewbbTY8t",
      "expanded_url" : "http:\/\/1.usa.gov\/28KGgJm",
      "display_url" : "1.usa.gov\/28KGgJm"
    } ]
  },
  "geo" : { },
  "id_str" : "745345053850275842",
  "text" : "RT @rD44: Huge day for small drones: @SecretaryFoxx and @USDOT finalize rules for commercial #UAS use: https:\/\/t.co\/TNewbbTY8t https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anthony Foxx",
        "screen_name" : "SecretaryFoxx",
        "indices" : [ 27, 41 ],
        "id_str" : "43920155",
        "id" : 43920155
      }, {
        "name" : "TransportationGov",
        "screen_name" : "USDOT",
        "indices" : [ 46, 52 ],
        "id_str" : "393562221",
        "id" : 393562221
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rD44\/status\/745316081103867905\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/rccFbjQ1ah",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Clfk_wIUsAAxXrw.jpg",
        "id_str" : "745316047255810048",
        "id" : 745316047255810048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clfk_wIUsAAxXrw.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 485,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 485,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 485,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 485,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/rccFbjQ1ah"
      } ],
      "hashtags" : [ {
        "text" : "UAS",
        "indices" : [ 83, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/TNewbbTY8t",
        "expanded_url" : "http:\/\/1.usa.gov\/28KGgJm",
        "display_url" : "1.usa.gov\/28KGgJm"
      } ]
    },
    "geo" : { },
    "id_str" : "745316081103867905",
    "text" : "Huge day for small drones: @SecretaryFoxx and @USDOT finalize rules for commercial #UAS use: https:\/\/t.co\/TNewbbTY8t https:\/\/t.co\/rccFbjQ1ah",
    "id" : 745316081103867905,
    "created_at" : "2016-06-21 18:02:55 +0000",
    "user" : {
      "name" : "R. David Edelman",
      "screen_name" : "rD44",
      "protected" : false,
      "id_str" : "4073671214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664566060801216513\/-QEofkKM_normal.jpg",
      "id" : 4073671214,
      "verified" : true
    }
  },
  "id" : 745345053850275842,
  "created_at" : "2016-06-21 19:58:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745327427803561984",
  "text" : "RT @POTUS: By giving him its highest rating, the American Bar Association confirms what we all know: Judge Garland should serve on the Supr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745327295544569856",
    "text" : "By giving him its highest rating, the American Bar Association confirms what we all know: Judge Garland should serve on the Supreme Court.",
    "id" : 745327295544569856,
    "created_at" : "2016-06-21 18:47:29 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 745327427803561984,
  "created_at" : "2016-06-21 18:48:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 41, 50 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/745306140502822912\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/G8GgOOGPJ0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Clfb97BWQAAQ1wb.jpg",
      "id_str" : "745306120214953984",
      "id" : 745306120214953984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clfb97BWQAAQ1wb.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/G8GgOOGPJ0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745306839525396484",
  "text" : "RT @FLOTUS: Oh hey! Look who just joined @Snapchat.\n\uD83D\uDC7B Add: MichelleObama \uD83D\uDC81\uD83C\uDFFD https:\/\/t.co\/G8GgOOGPJ0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Snapchat",
        "screen_name" : "Snapchat",
        "indices" : [ 29, 38 ],
        "id_str" : "376502929",
        "id" : 376502929
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/745306140502822912\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/G8GgOOGPJ0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Clfb97BWQAAQ1wb.jpg",
        "id_str" : "745306120214953984",
        "id" : 745306120214953984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clfb97BWQAAQ1wb.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 576
        } ],
        "display_url" : "pic.twitter.com\/G8GgOOGPJ0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745306140502822912",
    "text" : "Oh hey! Look who just joined @Snapchat.\n\uD83D\uDC7B Add: MichelleObama \uD83D\uDC81\uD83C\uDFFD https:\/\/t.co\/G8GgOOGPJ0",
    "id" : 745306140502822912,
    "created_at" : "2016-06-21 17:23:25 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 745306839525396484,
  "created_at" : "2016-06-21 17:26:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/G6REVXnaD0",
      "expanded_url" : "http:\/\/go.wh.gov\/E9YfYw",
      "display_url" : "go.wh.gov\/E9YfYw"
    } ]
  },
  "geo" : { },
  "id_str" : "745288209052008448",
  "text" : "RT @SCOTUSnom: Read why the American Bar Association unanimously gave Judge Garland its highest rating:  https:\/\/t.co\/G6REVXnaD0 https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCOTUSnom\/status\/745286393576951808\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/M6DA4Z5CRa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClfJ28CUYAEXkkT.jpg",
        "id_str" : "745286209019076609",
        "id" : 745286209019076609,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClfJ28CUYAEXkkT.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/M6DA4Z5CRa"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/G6REVXnaD0",
        "expanded_url" : "http:\/\/go.wh.gov\/E9YfYw",
        "display_url" : "go.wh.gov\/E9YfYw"
      } ]
    },
    "geo" : { },
    "id_str" : "745286393576951808",
    "text" : "Read why the American Bar Association unanimously gave Judge Garland its highest rating:  https:\/\/t.co\/G6REVXnaD0 https:\/\/t.co\/M6DA4Z5CRa",
    "id" : 745286393576951808,
    "created_at" : "2016-06-21 16:04:57 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 745288209052008448,
  "created_at" : "2016-06-21 16:12:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745273087629922304",
  "text" : "RT @POTUS: Gun violence requires more than moments of silence. It requires action. In failing that test, the Senate failed the American peo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745272915780743168",
    "text" : "Gun violence requires more than moments of silence. It requires action. In failing that test, the Senate failed the American people.",
    "id" : 745272915780743168,
    "created_at" : "2016-06-21 15:11:24 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 745273087629922304,
  "created_at" : "2016-06-21 15:12:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 27, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/pfjPQiUPQi",
      "expanded_url" : "http:\/\/go.wh.gov\/SvnSmM",
      "display_url" : "go.wh.gov\/SvnSmM"
    } ]
  },
  "in_reply_to_status_id_str" : "745078106822574080",
  "geo" : { },
  "id_str" : "745080944718053377",
  "in_reply_to_user_id" : 30313925,
  "text" : ".@POTUS has taken steps to #StopGunViolence. Now is time for the Senate to do its part. Inaction is inexcusable. https:\/\/t.co\/pfjPQiUPQi",
  "id" : 745080944718053377,
  "in_reply_to_status_id" : 745078106822574080,
  "created_at" : "2016-06-21 02:28:34 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/745078106822574080\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/0qjaNFeBHV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClcMlbCUgAAJh7p.jpg",
      "id_str" : "745078100405288960",
      "id" : 745078100405288960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClcMlbCUgAAJh7p.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      } ],
      "display_url" : "pic.twitter.com\/0qjaNFeBHV"
    } ],
    "hashtags" : [ {
      "text" : "DisarmHate",
      "indices" : [ 45, 56 ]
    }, {
      "text" : "StopGunViolence",
      "indices" : [ 93, 109 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745077389089116161",
  "geo" : { },
  "id_str" : "745078106822574080",
  "in_reply_to_user_id" : 30313925,
  "text" : "Tonight, the Senate failed to do its part to #DisarmHate. Here are steps @POTUS has taken to #StopGunViolence. https:\/\/t.co\/0qjaNFeBHV",
  "id" : 745078106822574080,
  "in_reply_to_status_id" : 745077389089116161,
  "created_at" : "2016-06-21 02:17:18 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DisarmHate",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745074703300104192",
  "geo" : { },
  "id_str" : "745077389089116161",
  "in_reply_to_user_id" : 30313925,
  "text" : "Most gun owners agree: Strengthening the background check system is a commonsense step to #DisarmHate.",
  "id" : 745077389089116161,
  "in_reply_to_status_id" : 745074703300104192,
  "created_at" : "2016-06-21 02:14:27 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 53, 59 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/745074703300104192\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/CSSYIM45YT",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/ClcJajaUoAQjXQC.jpg",
      "id_str" : "745074615139999748",
      "id" : 745074615139999748,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/ClcJajaUoAQjXQC.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CSSYIM45YT"
    } ],
    "hashtags" : [ {
      "text" : "DisarmHate",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745074703300104192",
  "text" : "More than 30,000 Americans die from guns every year. @POTUS is doing what he can to stop gun violence. #DisarmHate https:\/\/t.co\/CSSYIM45YT",
  "id" : 745074703300104192,
  "created_at" : "2016-06-21 02:03:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meb keflezighi",
      "screen_name" : "runmeb",
      "indices" : [ 3, 10 ],
      "id_str" : "69002830",
      "id" : 69002830
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745028747082891265",
  "text" : "RT @runmeb: Today is World Refugee Day. I was a refugee. Thanks to welcoming people, families and nations, I can chase my dreams\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ssENaemPpw",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/99408ef7-fceb-46f5-bb34-f3179db37065",
        "display_url" : "amp.twimg.com\/v\/99408ef7-fce\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744977284445044738",
    "text" : "Today is World Refugee Day. I was a refugee. Thanks to welcoming people, families and nations, I can chase my dreams\nhttps:\/\/t.co\/ssENaemPpw",
    "id" : 744977284445044738,
    "created_at" : "2016-06-20 19:36:40 +0000",
    "user" : {
      "name" : "meb keflezighi",
      "screen_name" : "runmeb",
      "protected" : false,
      "id_str" : "69002830",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582919770229493760\/PVq527xA_normal.jpg",
      "id" : 69002830,
      "verified" : true
    }
  },
  "id" : 745028747082891265,
  "created_at" : "2016-06-20 23:01:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/745009619097923584\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/o3hbkxySVf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClbLOd9VAAAtG_Y.jpg",
      "id_str" : "745006237796859904",
      "id" : 745006237796859904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClbLOd9VAAAtG_Y.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/o3hbkxySVf"
    } ],
    "hashtags" : [ {
      "text" : "WorldRefugeeDay",
      "indices" : [ 84, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745009619097923584",
  "text" : "\"Protecting and assisting refugees is a part of our history as a nation\" \u2014@POTUS on #WorldRefugeeDay https:\/\/t.co\/o3hbkxySVf",
  "id" : 745009619097923584,
  "created_at" : "2016-06-20 21:45:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meb keflezighi",
      "screen_name" : "runmeb",
      "indices" : [ 26, 33 ],
      "id_str" : "69002830",
      "id" : 69002830
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldRefugeeDay",
      "indices" : [ 96, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/1HwsI34w4D",
      "expanded_url" : "http:\/\/AidRefugees.gov",
      "display_url" : "AidRefugees.gov"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/vnlULMzMcK",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/bbbf44ca-d37f-411f-9853-d8a8234b7145",
      "display_url" : "amp.twimg.com\/v\/bbbf44ca-d37\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745005062997442560",
  "text" : "Watch U.S. Olympic runner @runmeb share what America means to refugees: https:\/\/t.co\/1HwsI34w4D #WorldRefugeeDay\nhttps:\/\/t.co\/vnlULMzMcK",
  "id" : 745005062997442560,
  "created_at" : "2016-06-20 21:27:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745004222018527233",
  "text" : "RT @FLOTUS: The beauty of the national park system is it belongs to everybody. See the First Family's visit to Yosemite: https:\/\/t.co\/2uRYn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/2uRYnmHe2n",
        "expanded_url" : "http:\/\/snpy.tv\/28JxWz9",
        "display_url" : "snpy.tv\/28JxWz9"
      } ]
    },
    "geo" : { },
    "id_str" : "745003825614880768",
    "text" : "The beauty of the national park system is it belongs to everybody. See the First Family's visit to Yosemite: https:\/\/t.co\/2uRYnmHe2n",
    "id" : 745003825614880768,
    "created_at" : "2016-06-20 21:22:08 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 745004222018527233,
  "created_at" : "2016-06-20 21:23:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/744997536872595457\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/NCVX7lsnjh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClbCr3EVEAA9Pp7.jpg",
      "id_str" : "744996847148666880",
      "id" : 744996847148666880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClbCr3EVEAA9Pp7.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/NCVX7lsnjh"
    } ],
    "hashtags" : [ {
      "text" : "WorldRefugeeDay",
      "indices" : [ 92, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/1HwsI34w4D",
      "expanded_url" : "http:\/\/AidRefugees.gov",
      "display_url" : "AidRefugees.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "744997536872595457",
  "text" : "Protecting refugees is part of our history as a nation. Learn more: https:\/\/t.co\/1HwsI34w4D #WorldRefugeeDay https:\/\/t.co\/NCVX7lsnjh",
  "id" : 744997536872595457,
  "created_at" : "2016-06-20 20:57:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "NNMI",
      "screen_name" : "nnmigov",
      "indices" : [ 21, 29 ],
      "id_str" : "769150232294748160",
      "id" : 769150232294748160
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manufacturing",
      "indices" : [ 69, 83 ]
    }, {
      "text" : "WeekofMaking",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744970102089654273",
  "text" : "RT @ENERGY: This new @NNMIGov institute on smart tech will make U.S. #manufacturing more efficient &amp; productive. #WeekofMaking\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NNMI",
        "screen_name" : "nnmigov",
        "indices" : [ 9, 17 ],
        "id_str" : "769150232294748160",
        "id" : 769150232294748160
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "manufacturing",
        "indices" : [ 57, 71 ]
      }, {
        "text" : "WeekofMaking",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/w7V7K8QKVf",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/a0b02b98-2c7c-4b0f-9eae-806909b7f5f5",
        "display_url" : "amp.twimg.com\/v\/a0b02b98-2c7\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744943046115004417",
    "text" : "This new @NNMIGov institute on smart tech will make U.S. #manufacturing more efficient &amp; productive. #WeekofMaking\nhttps:\/\/t.co\/w7V7K8QKVf",
    "id" : 744943046115004417,
    "created_at" : "2016-06-20 17:20:37 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 744970102089654273,
  "created_at" : "2016-06-20 19:08:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FirstDayOfSummer",
      "indices" : [ 23, 40 ]
    }, {
      "text" : "Zika",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744968778862075904",
  "text" : "RT @PressSec: It's the #FirstDayOfSummer! Make sure your summer plans include protecting yourself from #Zika. Here's how. https:\/\/t.co\/iKSI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/744968254829928450\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/iKSIcY4WFL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClaombCUsAAqIWU.jpg",
        "id_str" : "744968166422392832",
        "id" : 744968166422392832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClaombCUsAAqIWU.jpg",
        "sizes" : [ {
          "h" : 730,
          "resize" : "fit",
          "w" : 1290
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 1290
        } ],
        "display_url" : "pic.twitter.com\/iKSIcY4WFL"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/744968254829928450\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/iKSIcY4WFL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Claoml5UgAAta-5.jpg",
        "id_str" : "744968169337421824",
        "id" : 744968169337421824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Claoml5UgAAta-5.jpg",
        "sizes" : [ {
          "h" : 385,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 1291
        }, {
          "h" : 679,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 1291
        } ],
        "display_url" : "pic.twitter.com\/iKSIcY4WFL"
      } ],
      "hashtags" : [ {
        "text" : "FirstDayOfSummer",
        "indices" : [ 9, 26 ]
      }, {
        "text" : "Zika",
        "indices" : [ 89, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744968254829928450",
    "text" : "It's the #FirstDayOfSummer! Make sure your summer plans include protecting yourself from #Zika. Here's how. https:\/\/t.co\/iKSIcY4WFL",
    "id" : 744968254829928450,
    "created_at" : "2016-06-20 19:00:47 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 744968778862075904,
  "created_at" : "2016-06-20 19:02:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connie Britton",
      "screen_name" : "conniebritton",
      "indices" : [ 3, 17 ],
      "id_str" : "1905230346",
      "id" : 1905230346
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldRefugeeDay",
      "indices" : [ 31, 47 ]
    }, {
      "text" : "RefugeesWelcome",
      "indices" : [ 118, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744961831375011842",
  "text" : "RT @conniebritton: In honor of #WorldRefugeeDay I spoke with Sandrine about her journey from DRC to US. Please watch. #RefugeesWelcome\nhttp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldRefugeeDay",
        "indices" : [ 12, 28 ]
      }, {
        "text" : "RefugeesWelcome",
        "indices" : [ 99, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/h17OPJ5eBD",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/36274e0d-514b-4a45-9366-eb3b8f4e0d15",
        "display_url" : "amp.twimg.com\/v\/36274e0d-514\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744959071959158784",
    "text" : "In honor of #WorldRefugeeDay I spoke with Sandrine about her journey from DRC to US. Please watch. #RefugeesWelcome\nhttps:\/\/t.co\/h17OPJ5eBD",
    "id" : 744959071959158784,
    "created_at" : "2016-06-20 18:24:18 +0000",
    "user" : {
      "name" : "Connie Britton",
      "screen_name" : "conniebritton",
      "protected" : false,
      "id_str" : "1905230346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795623148842524672\/CqwRofAF_normal.jpg",
      "id" : 1905230346,
      "verified" : true
    }
  },
  "id" : 744961831375011842,
  "created_at" : "2016-06-20 18:35:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/744950823306805248\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/cAO4r3hZet",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClaYAwuVYAEvAVV.jpg",
      "id_str" : "744949927223058433",
      "id" : 744949927223058433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClaYAwuVYAEvAVV.jpg",
      "sizes" : [ {
        "h" : 730,
        "resize" : "fit",
        "w" : 1290
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 1290
      } ],
      "display_url" : "pic.twitter.com\/cAO4r3hZet"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/744950823306805248\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/cAO4r3hZet",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClaYB0ZUsAAgZeJ.jpg",
      "id_str" : "744949945388544000",
      "id" : 744949945388544000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClaYB0ZUsAAgZeJ.jpg",
      "sizes" : [ {
        "h" : 385,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 1291
      }, {
        "h" : 679,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 1291
      } ],
      "display_url" : "pic.twitter.com\/cAO4r3hZet"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 67, 72 ]
    }, {
      "text" : "FirstDayOfSummer",
      "indices" : [ 98, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/ALl4TTKKbL",
      "expanded_url" : "http:\/\/hhs.gov\/zika",
      "display_url" : "hhs.gov\/zika"
    } ]
  },
  "geo" : { },
  "id_str" : "744950823306805248",
  "text" : "Now that summer's heating up, learn steps to protect yourself from #Zika: https:\/\/t.co\/ALl4TTKKbL #FirstDayOfSummer https:\/\/t.co\/cAO4r3hZet",
  "id" : 744950823306805248,
  "created_at" : "2016-06-20 17:51:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "indices" : [ 109, 119 ],
      "id_str" : "1099296103",
      "id" : 1099296103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/QAdFfTwk2I",
      "expanded_url" : "http:\/\/snpy.tv\/28IUzmG",
      "display_url" : "snpy.tv\/28IUzmG"
    } ]
  },
  "geo" : { },
  "id_str" : "744947755278209025",
  "text" : "\u201CParticipating companies have invested more than $10 billion in 35 U.S. states &amp; territories\u201D \u2014@POTUS on @SelectUSA https:\/\/t.co\/QAdFfTwk2I",
  "id" : 744947755278209025,
  "created_at" : "2016-06-20 17:39:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/lYRnmNkGAd",
      "expanded_url" : "http:\/\/snpy.tv\/28IU4ck",
      "display_url" : "snpy.tv\/28IU4ck"
    } ]
  },
  "geo" : { },
  "id_str" : "744944997368160256",
  "text" : "\"Nowhere in the world and never in history has there ever been a better place to grow your business.\" \u2014@POTUS https:\/\/t.co\/lYRnmNkGAd",
  "id" : 744944997368160256,
  "created_at" : "2016-06-20 17:28:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 33, 36 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 40, 52 ],
      "id_str" : "369507958",
      "id" : 369507958
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 89, 94 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/4Hpx1bUnUz",
      "expanded_url" : "http:\/\/go.wh.gov\/WTP-Call",
      "display_url" : "go.wh.gov\/WTP-Call"
    } ]
  },
  "geo" : { },
  "id_str" : "744942098365939712",
  "text" : "RT @VPLive: \"Enough is enough.\" -@VP to @WeThePeople petition signers ahead of a call w\/ @VJ44. Listen: https:\/\/t.co\/4Hpx1bUnUz\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 21, 24 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 28, 40 ],
        "id_str" : "369507958",
        "id" : 369507958
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 77, 82 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/4Hpx1bUnUz",
        "expanded_url" : "http:\/\/go.wh.gov\/WTP-Call",
        "display_url" : "go.wh.gov\/WTP-Call"
      }, {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/wHSnDBR67c",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/3ae18141-f62d-4939-b933-43c29555b76c",
        "display_url" : "amp.twimg.com\/v\/3ae18141-f62\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744940824442507264",
    "text" : "\"Enough is enough.\" -@VP to @WeThePeople petition signers ahead of a call w\/ @VJ44. Listen: https:\/\/t.co\/4Hpx1bUnUz\nhttps:\/\/t.co\/wHSnDBR67c",
    "id" : 744940824442507264,
    "created_at" : "2016-06-20 17:11:47 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 744942098365939712,
  "created_at" : "2016-06-20 17:16:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744934757897732096",
  "text" : "\"Good luck. I'm rooting for you. Make a deal. Make that smart choice to invest in USA. We are open for business.\" \u2014@POTUS",
  "id" : 744934757897732096,
  "created_at" : "2016-06-20 16:47:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "indices" : [ 112, 122 ],
      "id_str" : "1099296103",
      "id" : 1099296103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744933762572615680",
  "text" : "RT @WHLive: \"When your companies come together, you can help bring countries and cultures together.\" \u2014@POTUS at @SelectUSA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 90, 96 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "SelectUSA",
        "screen_name" : "SelectUSA",
        "indices" : [ 100, 110 ],
        "id_str" : "1099296103",
        "id" : 1099296103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744933695782551553",
    "text" : "\"When your companies come together, you can help bring countries and cultures together.\" \u2014@POTUS at @SelectUSA",
    "id" : 744933695782551553,
    "created_at" : "2016-06-20 16:43:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 744933762572615680,
  "created_at" : "2016-06-20 16:43:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744933559291482112",
  "text" : "\"In the Oval Office I keep models of great American patents like the Morse telegraph, the propeller blade, and the gear-cutting machine.\"",
  "id" : 744933559291482112,
  "created_at" : "2016-06-20 16:42:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/n0wSPPq6wc",
      "expanded_url" : "http:\/\/go.wh.gov\/VnidaC",
      "display_url" : "go.wh.gov\/VnidaC"
    } ]
  },
  "geo" : { },
  "id_str" : "744933512407560192",
  "text" : "\"Since 2014, we\u2019ve opened eight cutting-edge manufacturing hubs.\"\n\"Today I\u2019m proud to announce a ninth hub.\" \u2014@POTUS\nhttps:\/\/t.co\/n0wSPPq6wc",
  "id" : 744933512407560192,
  "created_at" : "2016-06-20 16:42:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744933235906457600",
  "text" : "\"Investing in the United States is the best business decision you can make.\" \u2014@POTUS",
  "id" : 744933235906457600,
  "created_at" : "2016-06-20 16:41:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "indices" : [ 3, 13 ],
      "id_str" : "1099296103",
      "id" : 1099296103
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SelectUSASummit",
      "indices" : [ 119, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744932366565638147",
  "text" : "RT @SelectUSA: .@POTUS: Nowhere else in the world is there a better place to invest &amp; do biz in the United States. #SelectUSASummit https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SelectUSA\/status\/744932226224128001\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/pVMXcTPT37",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClaHYP6WgAEOgFl.jpg",
        "id_str" : "744931639034281985",
        "id" : 744931639034281985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClaHYP6WgAEOgFl.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pVMXcTPT37"
      } ],
      "hashtags" : [ {
        "text" : "SelectUSASummit",
        "indices" : [ 104, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744932226224128001",
    "text" : ".@POTUS: Nowhere else in the world is there a better place to invest &amp; do biz in the United States. #SelectUSASummit https:\/\/t.co\/pVMXcTPT37",
    "id" : 744932226224128001,
    "created_at" : "2016-06-20 16:37:37 +0000",
    "user" : {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "protected" : false,
      "id_str" : "1099296103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/581470913503191041\/fP7b5mZT_normal.jpg",
      "id" : 1099296103,
      "verified" : true
    }
  },
  "id" : 744932366565638147,
  "created_at" : "2016-06-20 16:38:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeekOfMaking",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744932005918441472",
  "text" : "\"No country has done more to build a culture of making and tinkering, of entrepreneurship and risk-taking\" \u2014@POTUS on the U.S. #WeekOfMaking",
  "id" : 744932005918441472,
  "created_at" : "2016-06-20 16:36:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 128, 134 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744931577428312064",
  "text" : "\"Never before has our high school graduation rate been higher, preparing students for college and careers in your industries.\" \u2014@POTUS",
  "id" : 744931577428312064,
  "created_at" : "2016-06-20 16:35:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "indices" : [ 106, 116 ],
      "id_str" : "1099296103",
      "id" : 1099296103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744931523330252800",
  "text" : "\"Never before has the United States recorded 75 straight months of private-sector job growth.\" \u2014@POTUS at @SelectUSA",
  "id" : 744931523330252800,
  "created_at" : "2016-06-20 16:34:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 43, 49 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "SelectUSA",
      "screen_name" : "SelectUSA",
      "indices" : [ 107, 117 ],
      "id_str" : "1099296103",
      "id" : 1099296103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744930517070516224",
  "text" : "RT @WHLive: Tune in at 12:30pm ET to watch @POTUS speak on bringing job-creating investment to the U.S. at @SelectUSA: https:\/\/t.co\/2EWf0c8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 31, 37 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "SelectUSA",
        "screen_name" : "SelectUSA",
        "indices" : [ 95, 105 ],
        "id_str" : "1099296103",
        "id" : 1099296103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/2EWf0c8kYT",
        "expanded_url" : "http:\/\/go.wh.gov\/3y2XbG",
        "display_url" : "go.wh.gov\/3y2XbG"
      } ]
    },
    "geo" : { },
    "id_str" : "744930227344805888",
    "text" : "Tune in at 12:30pm ET to watch @POTUS speak on bringing job-creating investment to the U.S. at @SelectUSA: https:\/\/t.co\/2EWf0c8kYT",
    "id" : 744930227344805888,
    "created_at" : "2016-06-20 16:29:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 744930517070516224,
  "created_at" : "2016-06-20 16:30:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "indices" : [ 3, 17 ],
      "id_str" : "308573576",
      "id" : 308573576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SelectUSASummit",
      "indices" : [ 83, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/7LRED1FTZm",
      "expanded_url" : "https:\/\/live.hosted.events\/SelectUSA\/",
      "display_url" : "live.hosted.events\/SelectUSA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "744927226802675713",
  "text" : "RT @PennyPritzker: At 12:30pm EST, President Obama will deliver his keynote at the #SelectUSASummit. Tune in: https:\/\/t.co\/7LRED1FTZm https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PennyPritzker\/status\/744924551771881473\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/EbiJ2VbfVm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClaA7LJWkAAlNTQ.jpg",
        "id_str" : "744924542469050368",
        "id" : 744924542469050368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClaA7LJWkAAlNTQ.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/EbiJ2VbfVm"
      } ],
      "hashtags" : [ {
        "text" : "SelectUSASummit",
        "indices" : [ 64, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/7LRED1FTZm",
        "expanded_url" : "https:\/\/live.hosted.events\/SelectUSA\/",
        "display_url" : "live.hosted.events\/SelectUSA\/"
      } ]
    },
    "geo" : { },
    "id_str" : "744924551771881473",
    "text" : "At 12:30pm EST, President Obama will deliver his keynote at the #SelectUSASummit. Tune in: https:\/\/t.co\/7LRED1FTZm https:\/\/t.co\/EbiJ2VbfVm",
    "id" : 744924551771881473,
    "created_at" : "2016-06-20 16:07:07 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 744927226802675713,
  "created_at" : "2016-06-20 16:17:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/aP5WJ0Zols",
      "expanded_url" : "http:\/\/snpy.tv\/28JxWz9",
      "display_url" : "snpy.tv\/28JxWz9"
    } ]
  },
  "geo" : { },
  "id_str" : "744924446813749248",
  "text" : "Get a behind-the-scenes look at @POTUS's historic trip to Yosemite National Park this weekend: https:\/\/t.co\/aP5WJ0Zols",
  "id" : 744924446813749248,
  "created_at" : "2016-06-20 16:06:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/744917658848497664\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/IvtpZb4msK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClZ6M-3XEAAz2kO.jpg",
      "id_str" : "744917151828611072",
      "id" : 744917151828611072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClZ6M-3XEAAz2kO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/IvtpZb4msK"
    } ],
    "hashtags" : [ {
      "text" : "WorldRefugeeDay",
      "indices" : [ 96, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/1HwsI34w4D",
      "expanded_url" : "http:\/\/AidRefugees.gov",
      "display_url" : "AidRefugees.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "744917658848497664",
  "text" : "Protecting and assisting refugees is a part of our history as a nation. https:\/\/t.co\/1HwsI34w4D #WorldRefugeeDay https:\/\/t.co\/IvtpZb4msK",
  "id" : 744917658848497664,
  "created_at" : "2016-06-20 15:39:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Mission to the UN",
      "screen_name" : "USUN",
      "indices" : [ 3, 8 ],
      "id_str" : "249677516",
      "id" : 249677516
    }, {
      "name" : "meb keflezighi",
      "screen_name" : "runmeb",
      "indices" : [ 41, 48 ],
      "id_str" : "69002830",
      "id" : 69002830
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 109, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744914956722675715",
  "text" : "RT @USUN: US has welcomed refugees, like @runmeb, for generations. Today we highlight some of their stories. #RefugeesWelcome https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "meb keflezighi",
        "screen_name" : "runmeb",
        "indices" : [ 31, 38 ],
        "id_str" : "69002830",
        "id" : 69002830
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USUN\/status\/744908755939139584\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/4BNZ7Xwdtq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClZykNtVEAArsHY.jpg",
        "id_str" : "744908754857037824",
        "id" : 744908754857037824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClZykNtVEAArsHY.jpg",
        "sizes" : [ {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/4BNZ7Xwdtq"
      } ],
      "hashtags" : [ {
        "text" : "RefugeesWelcome",
        "indices" : [ 99, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744908755939139584",
    "text" : "US has welcomed refugees, like @runmeb, for generations. Today we highlight some of their stories. #RefugeesWelcome https:\/\/t.co\/4BNZ7Xwdtq",
    "id" : 744908755939139584,
    "created_at" : "2016-06-20 15:04:21 +0000",
    "user" : {
      "name" : "US Mission to the UN",
      "screen_name" : "USUN",
      "protected" : false,
      "id_str" : "249677516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616236749149241345\/Dm-anuiC_normal.jpg",
      "id" : 249677516,
      "verified" : true
    }
  },
  "id" : 744914956722675715,
  "created_at" : "2016-06-20 15:29:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldRefugeeDay",
      "indices" : [ 70, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744912947525230597",
  "text" : "RT @AmbassadorRice: World is esp focused on plight of refugees today, #WorldRefugeeDay, but mustn\u2019t forget their struggle will endure unles\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorldRefugeeDay",
        "indices" : [ 50, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744885545076035584",
    "text" : "World is esp focused on plight of refugees today, #WorldRefugeeDay, but mustn\u2019t forget their struggle will endure unless we all do more.",
    "id" : 744885545076035584,
    "created_at" : "2016-06-20 13:32:07 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 744912947525230597,
  "created_at" : "2016-06-20 15:21:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RefugeesWelcome",
      "indices" : [ 95, 111 ]
    }, {
      "text" : "WorldRefugeeDay",
      "indices" : [ 112, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744910058362933248",
  "text" : "RT @SecBurwell: Refugees are making a positive difference in communities across their country. #RefugeesWelcome #WorldRefugeeDay\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RefugeesWelcome",
        "indices" : [ 79, 95 ]
      }, {
        "text" : "WorldRefugeeDay",
        "indices" : [ 96, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/hxNmpoSmD3",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/0f1157e9-4ae8-4378-a92c-aea89dee309d",
        "display_url" : "amp.twimg.com\/v\/0f1157e9-4ae\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744879580691849217",
    "text" : "Refugees are making a positive difference in communities across their country. #RefugeesWelcome #WorldRefugeeDay\nhttps:\/\/t.co\/hxNmpoSmD3",
    "id" : 744879580691849217,
    "created_at" : "2016-06-20 13:08:25 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 744910058362933248,
  "created_at" : "2016-06-20 15:09:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Cleveland Cavaliers",
      "screen_name" : "cavs",
      "indices" : [ 49, 54 ],
      "id_str" : "19263978",
      "id" : 19263978
    }, {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 69, 79 ],
      "id_str" : "23083404",
      "id" : 23083404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744735061501575169",
  "text" : "RT @POTUS: What a game and what a series for the @Cavs. Happy to see @KingJames bring it home for Cleveland!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cleveland Cavaliers",
        "screen_name" : "cavs",
        "indices" : [ 38, 43 ],
        "id_str" : "19263978",
        "id" : 19263978
      }, {
        "name" : "LeBron James",
        "screen_name" : "KingJames",
        "indices" : [ 58, 68 ],
        "id_str" : "23083404",
        "id" : 23083404
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744734234179477504",
    "text" : "What a game and what a series for the @Cavs. Happy to see @KingJames bring it home for Cleveland!",
    "id" : 744734234179477504,
    "created_at" : "2016-06-20 03:30:52 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 744735061501575169,
  "created_at" : "2016-06-20 03:34:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "indices" : [ 3, 15 ],
      "id_str" : "18726942",
      "id" : 18726942
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 104, 117 ]
    }, {
      "text" : "NPS100",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744712323701440512",
  "text" : "RT @YosemiteNPS: .@POTUS and family have left after enjoying some hiking. We were honored to host them! #FindYourPark #NPS100 https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YosemiteNPS\/status\/744667925970313216\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/JCIiRgUj9Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClWXcZoWIAAA0Uq.jpg",
        "id_str" : "744667827571924992",
        "id" : 744667827571924992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClWXcZoWIAAA0Uq.jpg",
        "sizes" : [ {
          "h" : 541,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 2293,
          "resize" : "fit",
          "w" : 2880
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1631,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 955,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/JCIiRgUj9Z"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/YosemiteNPS\/status\/744667925970313216\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/JCIiRgUj9Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClWXfSWWQAE46ri.jpg",
        "id_str" : "744667877156995073",
        "id" : 744667877156995073,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClWXfSWWQAE46ri.jpg",
        "sizes" : [ {
          "h" : 2160,
          "resize" : "fit",
          "w" : 2880
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/JCIiRgUj9Z"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 87, 100 ]
      }, {
        "text" : "NPS100",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744667925970313216",
    "text" : ".@POTUS and family have left after enjoying some hiking. We were honored to host them! #FindYourPark #NPS100 https:\/\/t.co\/JCIiRgUj9Z",
    "id" : 744667925970313216,
    "created_at" : "2016-06-19 23:07:23 +0000",
    "user" : {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "protected" : false,
      "id_str" : "18726942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2729953592\/5afe7b5385c9388e33684f8083294beb_normal.png",
      "id" : 18726942,
      "verified" : true
    }
  },
  "id" : 744712323701440512,
  "created_at" : "2016-06-20 02:03:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/SaNJgmoIK1",
      "expanded_url" : "https:\/\/twitter.com\/flotus\/status\/744547424757223425",
      "display_url" : "twitter.com\/flotus\/status\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744657031785816065",
  "text" : "RT @POTUS: Happy Father's Day to all the dads out there. Glad to be spending this one with my family in Yosemite. https:\/\/t.co\/SaNJgmoIK1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/SaNJgmoIK1",
        "expanded_url" : "https:\/\/twitter.com\/flotus\/status\/744547424757223425",
        "display_url" : "twitter.com\/flotus\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744656711596773380",
    "text" : "Happy Father's Day to all the dads out there. Glad to be spending this one with my family in Yosemite. https:\/\/t.co\/SaNJgmoIK1",
    "id" : 744656711596773380,
    "created_at" : "2016-06-19 22:22:49 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 744657031785816065,
  "created_at" : "2016-06-19 22:24:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 49, 55 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/QPZ9vzxsHo",
      "expanded_url" : "http:\/\/go.wh.gov\/t91WCW",
      "display_url" : "go.wh.gov\/t91WCW"
    } ]
  },
  "geo" : { },
  "id_str" : "744635937976528896",
  "text" : "\"Happy Father\u2019s Day to all the dads out there.\" \u2014@POTUS in his weekly address: https:\/\/t.co\/QPZ9vzxsHo",
  "id" : 744635937976528896,
  "created_at" : "2016-06-19 21:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/QPZ9vzxsHo",
      "expanded_url" : "http:\/\/go.wh.gov\/t91WCW",
      "display_url" : "go.wh.gov\/t91WCW"
    } ]
  },
  "geo" : { },
  "id_str" : "744609484346032129",
  "text" : "\"Let\u2019s never forget how much good we can achieve simply by loving one another.\" \u2014@POTUS: https:\/\/t.co\/QPZ9vzxsHo",
  "id" : 744609484346032129,
  "created_at" : "2016-06-19 19:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/744601610085621761\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/teKZ7TZyx7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClVZHnKWAAA_hws.jpg",
      "id_str" : "744599300706009088",
      "id" : 744599300706009088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClVZHnKWAAA_hws.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 732
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 732
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 732
      } ],
      "display_url" : "pic.twitter.com\/teKZ7TZyx7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744601610085621761",
  "text" : "\"Even in the darkest hours, there is cause to hope for tomorrow\u2019s light.\" \u2014@POTUS marking this Juneteenth: https:\/\/t.co\/teKZ7TZyx7",
  "id" : 744601610085621761,
  "created_at" : "2016-06-19 18:43:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/QPZ9vzxsHo",
      "expanded_url" : "http:\/\/go.wh.gov\/t91WCW",
      "display_url" : "go.wh.gov\/t91WCW"
    } ]
  },
  "geo" : { },
  "id_str" : "744575623566229504",
  "text" : "\"To me, fatherhood means being there. So in the days ahead, let\u2019s be there for each other.\" \u2014@POTUS: https:\/\/t.co\/QPZ9vzxsHo",
  "id" : 744575623566229504,
  "created_at" : "2016-06-19 17:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/QPZ9vzxsHo",
      "expanded_url" : "http:\/\/go.wh.gov\/t91WCW",
      "display_url" : "go.wh.gov\/t91WCW"
    } ]
  },
  "geo" : { },
  "id_str" : "744556625189429248",
  "text" : "\"We need our kids to hear us speak up about the risks guns pose to our communities\" \u2014@POTUS in his weekly address: https:\/\/t.co\/QPZ9vzxsHo",
  "id" : 744556625189429248,
  "created_at" : "2016-06-19 15:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/744547424757223425\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/peU8VZASRm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClUp7CQWIAAcHFj.jpg",
      "id_str" : "744547407594135552",
      "id" : 744547407594135552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClUp7CQWIAAcHFj.jpg",
      "sizes" : [ {
        "h" : 517,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1556,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1556,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 912,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/peU8VZASRm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744548603671150593",
  "text" : "RT @FLOTUS: Happy Father's Day \u2764\uFE0F https:\/\/t.co\/peU8VZASRm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/744547424757223425\/photo\/1",
        "indices" : [ 22, 45 ],
        "url" : "https:\/\/t.co\/peU8VZASRm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClUp7CQWIAAcHFj.jpg",
        "id_str" : "744547407594135552",
        "id" : 744547407594135552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClUp7CQWIAAcHFj.jpg",
        "sizes" : [ {
          "h" : 517,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1556,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1556,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 912,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/peU8VZASRm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744547424757223425",
    "text" : "Happy Father's Day \u2764\uFE0F https:\/\/t.co\/peU8VZASRm",
    "id" : 744547424757223425,
    "created_at" : "2016-06-19 15:08:33 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 744548603671150593,
  "created_at" : "2016-06-19 15:13:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/QPZ9vzxsHo",
      "expanded_url" : "http:\/\/go.wh.gov\/t91WCW",
      "display_url" : "go.wh.gov\/t91WCW"
    } ]
  },
  "geo" : { },
  "id_str" : "744541532674367488",
  "text" : "\"If we\u2019re going to raise our kids in a safer, more loving world, we need to speak up for it.\" \u2014@POTUS: https:\/\/t.co\/QPZ9vzxsHo",
  "id" : 744541532674367488,
  "created_at" : "2016-06-19 14:45:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "indices" : [ 3, 10 ],
      "id_str" : "17471979",
      "id" : 17471979
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744532547758067712",
  "text" : "RT @NatGeo: Exclusive: We spoke with @POTUS\u00A0about embracing national parks as symbols of the planet\u2019s beauty and history https:\/\/t.co\/XPvMj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 25, 31 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/XPvMjcMqTl",
        "expanded_url" : "http:\/\/on.natgeo.com\/1WUMxJa",
        "display_url" : "on.natgeo.com\/1WUMxJa"
      } ]
    },
    "geo" : { },
    "id_str" : "744303801046278144",
    "text" : "Exclusive: We spoke with @POTUS\u00A0about embracing national parks as symbols of the planet\u2019s beauty and history https:\/\/t.co\/XPvMjcMqTl",
    "id" : 744303801046278144,
    "created_at" : "2016-06-18 23:00:29 +0000",
    "user" : {
      "name" : "National Geographic",
      "screen_name" : "NatGeo",
      "protected" : false,
      "id_str" : "17471979",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798181194202566656\/U8QbCBdH_normal.jpg",
      "id" : 17471979,
      "verified" : true
    }
  },
  "id" : 744532547758067712,
  "created_at" : "2016-06-19 14:09:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/744524465334292480\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/u3QyP0eutD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClUVABRWAAEPy3-.jpg",
      "id_str" : "744524403485048833",
      "id" : 744524403485048833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClUVABRWAAEPy3-.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 490
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2773,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 865
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1477
      } ],
      "display_url" : "pic.twitter.com\/u3QyP0eutD"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744524465334292480",
  "text" : "RT if you agree with @POTUS: It's time to #ActOnClimate so future generations can enjoy America\u2019s greatest treasures https:\/\/t.co\/u3QyP0eutD",
  "id" : 744524465334292480,
  "created_at" : "2016-06-19 13:37:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/Fdr3yEXfn4",
      "expanded_url" : "https:\/\/www.facebook.com\/potus\/posts\/500976740092171",
      "display_url" : "facebook.com\/potus\/posts\/50\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "744355898999508992",
  "text" : "RT @ks44: Want to see the photos President Obama took in Yosemite? He just shared some on Facebook: https:\/\/t.co\/Fdr3yEXfn4 https:\/\/t.co\/D9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/744341323738550272\/photo\/1",
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/D9L25oYfns",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClRtHNHVAAAbN_m.jpg",
        "id_str" : "744339808969883648",
        "id" : 744339808969883648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClRtHNHVAAAbN_m.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1364,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/D9L25oYfns"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/Fdr3yEXfn4",
        "expanded_url" : "https:\/\/www.facebook.com\/potus\/posts\/500976740092171",
        "display_url" : "facebook.com\/potus\/posts\/50\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744341323738550272",
    "text" : "Want to see the photos President Obama took in Yosemite? He just shared some on Facebook: https:\/\/t.co\/Fdr3yEXfn4 https:\/\/t.co\/D9L25oYfns",
    "id" : 744341323738550272,
    "created_at" : "2016-06-19 01:29:35 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 744355898999508992,
  "created_at" : "2016-06-19 02:27:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/HdciLzfKqM",
      "expanded_url" : "http:\/\/on.natgeo.com\/1WUMxJa",
      "display_url" : "on.natgeo.com\/1WUMxJa"
    } ]
  },
  "geo" : { },
  "id_str" : "744341488973164544",
  "text" : "\"These spaces are sacred. They are for everyone and not just for the few.\" \u2014@POTUS on America's National Parks: https:\/\/t.co\/HdciLzfKqM",
  "id" : 744341488973164544,
  "created_at" : "2016-06-19 01:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 67, 73 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/QPZ9vzxsHo",
      "expanded_url" : "http:\/\/go.wh.gov\/t91WCW",
      "display_url" : "go.wh.gov\/t91WCW"
    } ]
  },
  "geo" : { },
  "id_str" : "744326374077325318",
  "text" : "\"It\u2019s unconscionable that we allow easy access to weapons of war\" \u2014@POTUS on the need for common-sense gun reforms: https:\/\/t.co\/QPZ9vzxsHo",
  "id" : 744326374077325318,
  "created_at" : "2016-06-19 00:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/QPZ9vzxsHo",
      "expanded_url" : "http:\/\/go.wh.gov\/t91WCW",
      "display_url" : "go.wh.gov\/t91WCW"
    } ]
  },
  "geo" : { },
  "id_str" : "744315040983965696",
  "text" : "\"We\u2019ve also seen a renewed focus on reducing gun violence.\" \u2014@POTUS on the response to the attack in Orlando: https:\/\/t.co\/QPZ9vzxsHo",
  "id" : 744315040983965696,
  "created_at" : "2016-06-18 23:45:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/QPZ9vzxsHo",
      "expanded_url" : "http:\/\/go.wh.gov\/t91WCW",
      "display_url" : "go.wh.gov\/t91WCW"
    } ]
  },
  "geo" : { },
  "id_str" : "744296182118154240",
  "text" : "\"We will keep doing everything in our power to stop these kinds of attacks, and to ultimately destroy ISIL.\"\u2014@POTUS: https:\/\/t.co\/QPZ9vzxsHo",
  "id" : 744296182118154240,
  "created_at" : "2016-06-18 22:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/QPZ9vzxsHo",
      "expanded_url" : "http:\/\/go.wh.gov\/t91WCW",
      "display_url" : "go.wh.gov\/t91WCW"
    } ]
  },
  "geo" : { },
  "id_str" : "744277283830042625",
  "text" : "\"The American people, and people all over the world, are standing with them.\" \u2014@POTUS on his visit to Orlando: https:\/\/t.co\/QPZ9vzxsHo",
  "id" : 744277283830042625,
  "created_at" : "2016-06-18 21:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "indices" : [ 78, 90 ],
      "id_str" : "18726942",
      "id" : 18726942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/GEKhf4Pc9V",
      "expanded_url" : "http:\/\/snpy.tv\/1Yzjlqw",
      "display_url" : "snpy.tv\/1Yzjlqw"
    } ]
  },
  "geo" : { },
  "id_str" : "744264702411169792",
  "text" : "\"We can't treat these things as something that we deal with later\" \u2014@POTUS in @YosemiteNPS #ActOnClimate https:\/\/t.co\/GEKhf4Pc9V",
  "id" : 744264702411169792,
  "created_at" : "2016-06-18 20:25:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/GEKhf4Pc9V",
      "expanded_url" : "http:\/\/snpy.tv\/1Yzjlqw",
      "display_url" : "snpy.tv\/1Yzjlqw"
    } ]
  },
  "geo" : { },
  "id_str" : "744255883786412032",
  "text" : "\u201CWhat a precious thing we have to pass on to the next generation.\" \u2014@POTUS on protecting America's natural heritage https:\/\/t.co\/GEKhf4Pc9V",
  "id" : 744255883786412032,
  "created_at" : "2016-06-18 19:50:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "indices" : [ 101, 113 ],
      "id_str" : "18726942",
      "id" : 18726942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/GEKhf4Pc9V",
      "expanded_url" : "http:\/\/snpy.tv\/1Yzjlqw",
      "display_url" : "snpy.tv\/1Yzjlqw"
    } ]
  },
  "geo" : { },
  "id_str" : "744248632510033920",
  "text" : "\u201CEvery dollar we invest in our national parks generates ten dollars for local economies.\u201D \u2014@POTUS at @YosemiteNPS https:\/\/t.co\/GEKhf4Pc9V",
  "id" : 744248632510033920,
  "created_at" : "2016-06-18 19:21:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/GEKhf4Pc9V",
      "expanded_url" : "http:\/\/snpy.tv\/1Yzjlqw",
      "display_url" : "snpy.tv\/1Yzjlqw"
    } ]
  },
  "geo" : { },
  "id_str" : "744242052448169984",
  "text" : "These parks belong to all of us.\nThis planet belongs to all of us.\nIt\u2019s the only one we\u2019ve got. #ActOnClimate https:\/\/t.co\/GEKhf4Pc9V",
  "id" : 744242052448169984,
  "created_at" : "2016-06-18 18:55:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744237519580073985",
  "text" : "RT @WHLive: \"We\u2019ve made good strides, jumpstarting a clean energy revolution...rallying the world to tackle climate change\" \u2014@POTUS #ActOnC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 113, 119 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 120, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744237446276198401",
    "text" : "\"We\u2019ve made good strides, jumpstarting a clean energy revolution...rallying the world to tackle climate change\" \u2014@POTUS #ActOnClimate",
    "id" : 744237446276198401,
    "created_at" : "2016-06-18 18:36:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 744237519580073985,
  "created_at" : "2016-06-18 18:37:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/744236623295057920\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/12XgitxkEB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClQPQK5VEAAJspc.jpg",
      "id_str" : "744236608900108288",
      "id" : 744236608900108288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClQPQK5VEAAJspc.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/12XgitxkEB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744236623295057920",
  "text" : "\"These parks belong to all of us. This planet belongs to all of us. It\u2019s the only one we\u2019ve got\" \u2014@POTUS in Yosemite https:\/\/t.co\/12XgitxkEB",
  "id" : 744236623295057920,
  "created_at" : "2016-06-18 18:33:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/e8KPyzF2zh",
      "expanded_url" : "http:\/\/wh.gov\/Climate-Change",
      "display_url" : "wh.gov\/Climate-Change"
    } ]
  },
  "geo" : { },
  "id_str" : "744235980924796928",
  "text" : "\"Climate change is no longer just a threat \u2013 it\u2019s already a reality.\" \u2014@POTUS: https:\/\/t.co\/e8KPyzF2zh \n#ActOnClimate",
  "id" : 744235980924796928,
  "created_at" : "2016-06-18 18:30:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 31, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/tE9JdkFapK",
      "expanded_url" : "http:\/\/wwww.FindYourPark.com",
      "display_url" : "wwww.FindYourPark.com"
    } ]
  },
  "geo" : { },
  "id_str" : "744235354341937152",
  "text" : "\"We\u2019re asking all Americans to #FindYourPark so that everyone...can experience these wonders.\" \u2014@POTUS: https:\/\/t.co\/tE9JdkFapK",
  "id" : 744235354341937152,
  "created_at" : "2016-06-18 18:28:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/744234861205065728\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/rr7GQiBHSK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClQNm1wUoAA1F2d.jpg",
      "id_str" : "744234799338921984",
      "id" : 744234799338921984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClQNm1wUoAA1F2d.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/rr7GQiBHSK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744234861205065728",
  "text" : "\u201CWe\u2019ve protected more than 265 million acres of public lands and waters\u201D \u2014@POTUS in Yosemite National Park https:\/\/t.co\/rr7GQiBHSK",
  "id" : 744234861205065728,
  "created_at" : "2016-06-18 18:26:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/LZvuEP77fb",
      "expanded_url" : "http:\/\/go.wh.gov\/5gck3Y",
      "display_url" : "go.wh.gov\/5gck3Y"
    } ]
  },
  "geo" : { },
  "id_str" : "744234690773651457",
  "text" : "\u201CIn August, we\u2019ll celebrate the 100th anniversary of the National Park Service.\u201D \u2014@POTUS #FindYourPark: https:\/\/t.co\/LZvuEP77fb",
  "id" : 744234690773651457,
  "created_at" : "2016-06-18 18:25:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 128, 134 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744234634209275904",
  "text" : "\u201CIt\u2019s no wonder Teddy Roosevelt called the great trees here a \u2018temple grander than any human architect could possibly build.\u2019\u201D \u2014@POTUS",
  "id" : 744234634209275904,
  "created_at" : "2016-06-18 18:25:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "indices" : [ 112, 124 ],
      "id_str" : "18726942",
      "id" : 18726942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744234559668125696",
  "text" : "\u201CIt\u2019s no wonder that 152 years ago, President Lincoln first protected the ground on which we stand.\u201D \u2014@POTUS at @YosemiteNPS",
  "id" : 744234559668125696,
  "created_at" : "2016-06-18 18:25:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "indices" : [ 64, 76 ],
      "id_str" : "18726942",
      "id" : 18726942
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/744234477136805888\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/cRx4jfwq6N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClQNTg9VEAAvlR_.jpg",
      "id_str" : "744234467338817536",
      "id" : 744234467338817536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClQNTg9VEAAvlR_.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/cRx4jfwq6N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744234477136805888",
  "text" : "\u201CYou\u2019ve got to come here to breathe it in yourself.\u201D \u2014@POTUS at @YosemiteNPS https:\/\/t.co\/cRx4jfwq6N",
  "id" : 744234477136805888,
  "created_at" : "2016-06-18 18:25:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/744234307095519232\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/oHydI2RLo7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClQNJ6gUsAEpXOj.jpg",
      "id_str" : "744234302397788161",
      "id" : 744234302397788161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClQNJ6gUsAEpXOj.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 908
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1550
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 515
      }, {
        "h" : 2980,
        "resize" : "fit",
        "w" : 2256
      } ],
      "display_url" : "pic.twitter.com\/oHydI2RLo7"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744234307095519232",
  "text" : "\u201CIn the West Wing Lobby, I\u2019ve got a painting of Vernal Fall and Half-Dome.\u201D \u2014@POTUS in Yosemite #FindYourPark https:\/\/t.co\/oHydI2RLo7",
  "id" : 744234307095519232,
  "created_at" : "2016-06-18 18:24:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/744234064291323904\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/kbSIzYy0qM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClQM7pYUsAAWeLb.jpg",
      "id_str" : "744234057282662400",
      "id" : 744234057282662400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClQM7pYUsAAWeLb.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      } ],
      "display_url" : "pic.twitter.com\/kbSIzYy0qM"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744234064291323904",
  "text" : "\u201CYesterday, our family checked out Carlsbad Caverns down in New Mexico.\u201D \u2014@POTUS #FindYourPark https:\/\/t.co\/kbSIzYy0qM",
  "id" : 744234064291323904,
  "created_at" : "2016-06-18 18:23:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/hNtbTR0Nb1",
      "expanded_url" : "http:\/\/go.wh.gov\/5gck3Y",
      "display_url" : "go.wh.gov\/5gck3Y"
    } ]
  },
  "geo" : { },
  "id_str" : "744233909764919296",
  "text" : "RT @WHLive: Happening now: @POTUS gives remarks live from Yosemite National Park \u2192 https:\/\/t.co\/hNtbTR0Nb1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/hNtbTR0Nb1",
        "expanded_url" : "http:\/\/go.wh.gov\/5gck3Y",
        "display_url" : "go.wh.gov\/5gck3Y"
      } ]
    },
    "geo" : { },
    "id_str" : "744233841032847361",
    "text" : "Happening now: @POTUS gives remarks live from Yosemite National Park \u2192 https:\/\/t.co\/hNtbTR0Nb1",
    "id" : 744233841032847361,
    "created_at" : "2016-06-18 18:22:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 744233909764919296,
  "created_at" : "2016-06-18 18:22:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 96, 107 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EveryKidinaPark",
      "indices" : [ 64, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744225580934127616",
  "text" : "RT @WhiteHouseCEQ: .@POTUS surprised 4th graders &amp; gave out #EveryKidinaPark passes! Follow @WhiteHouse on Snapchat for the full story. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 77, 88 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WhiteHouseCEQ\/status\/744221915934396417\/video\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/jFauxOTUQJ",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/744221568339869696\/pu\/img\/g6prCQ8f6bj9jPz4.jpg",
        "id_str" : "744221568339869696",
        "id" : 744221568339869696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/744221568339869696\/pu\/img\/g6prCQ8f6bj9jPz4.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 360
        } ],
        "display_url" : "pic.twitter.com\/jFauxOTUQJ"
      } ],
      "hashtags" : [ {
        "text" : "EveryKidinaPark",
        "indices" : [ 45, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744221915934396417",
    "text" : ".@POTUS surprised 4th graders &amp; gave out #EveryKidinaPark passes! Follow @WhiteHouse on Snapchat for the full story. https:\/\/t.co\/jFauxOTUQJ",
    "id" : 744221915934396417,
    "created_at" : "2016-06-18 17:35:06 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 744225580934127616,
  "created_at" : "2016-06-18 17:49:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 67, 83 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/744224439210901504\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/neA85jHiqE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClP-3jKWIAEP-qD.jpg",
      "id_str" : "744218593731158017",
      "id" : 744218593731158017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClP-3jKWIAEP-qD.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2016,
        "resize" : "fit",
        "w" : 1512
      }, {
        "h" : 2016,
        "resize" : "fit",
        "w" : 1512
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/neA85jHiqE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/LZvuEPoI6J",
      "expanded_url" : "http:\/\/go.wh.gov\/5gck3Y",
      "display_url" : "go.wh.gov\/5gck3Y"
    } ]
  },
  "geo" : { },
  "id_str" : "744224439210901504",
  "text" : "Watch live at 2pm ET from Yosemite: @POTUS celebrates 100 years of @NatlParkService \u2192 https:\/\/t.co\/LZvuEPoI6J https:\/\/t.co\/neA85jHiqE",
  "id" : 744224439210901504,
  "created_at" : "2016-06-18 17:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "indices" : [ 3, 14 ],
      "id_str" : "562456722",
      "id" : 562456722
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 38, 44 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 49, 56 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "indices" : [ 114, 126 ],
      "id_str" : "18726942",
      "id" : 18726942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744220582447710209",
  "text" : "RT @LizAllen44: Beautiful morning for @POTUS and @FLOTUS to give out Every Kid in a Park passes to 4th graders at @YosemiteNPS https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 22, 28 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 33, 40 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Yosemite National Pk",
        "screen_name" : "YosemiteNPS",
        "indices" : [ 98, 110 ],
        "id_str" : "18726942",
        "id" : 18726942
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LizAllen44\/status\/744216029362954241\/photo\/1",
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/uvzhfaxyyf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClP8geTVYAALQbk.jpg",
        "id_str" : "744215998266433536",
        "id" : 744215998266433536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClP8geTVYAALQbk.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/uvzhfaxyyf"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "744216029362954241",
    "text" : "Beautiful morning for @POTUS and @FLOTUS to give out Every Kid in a Park passes to 4th graders at @YosemiteNPS https:\/\/t.co\/uvzhfaxyyf",
    "id" : 744216029362954241,
    "created_at" : "2016-06-18 17:11:42 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 744220582447710209,
  "created_at" : "2016-06-18 17:29:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/pJ6p8AUZpC",
      "expanded_url" : "http:\/\/on.doi.gov\/1YxiiXW",
      "display_url" : "on.doi.gov\/1YxiiXW"
    } ]
  },
  "geo" : { },
  "id_str" : "744196984454602752",
  "text" : "RT @Interior: Public lands are economic powerhouses, generating $106B to US economy last year https:\/\/t.co\/pJ6p8AUZpC https:\/\/t.co\/ugAPQZ2g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/743884343664320512\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/ugAPQZ2gRX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClLO3V9WEAAbEwE.jpg",
        "id_str" : "743884338652123136",
        "id" : 743884338652123136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClLO3V9WEAAbEwE.jpg",
        "sizes" : [ {
          "h" : 750,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2560,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/ugAPQZ2gRX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/pJ6p8AUZpC",
        "expanded_url" : "http:\/\/on.doi.gov\/1YxiiXW",
        "display_url" : "on.doi.gov\/1YxiiXW"
      } ]
    },
    "geo" : { },
    "id_str" : "743884343664320512",
    "text" : "Public lands are economic powerhouses, generating $106B to US economy last year https:\/\/t.co\/pJ6p8AUZpC https:\/\/t.co\/ugAPQZ2gRX",
    "id" : 743884343664320512,
    "created_at" : "2016-06-17 19:13:42 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 744196984454602752,
  "created_at" : "2016-06-18 15:56:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/ErxKWmNKUh",
      "expanded_url" : "http:\/\/go.wh.gov\/8Mavvp",
      "display_url" : "go.wh.gov\/8Mavvp"
    } ]
  },
  "geo" : { },
  "id_str" : "744188451273093121",
  "text" : "RT @WHLive: The First Family is exploring our National Parks this weekend. Follow along: https:\/\/t.co\/ErxKWmNKUh #FindYourPark https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/744188235438391296\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/Is6TmRSM7f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClPigK8UsAA9K-9.jpg",
        "id_str" : "744187405767323648",
        "id" : 744187405767323648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClPigK8UsAA9K-9.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1366,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1921,
          "resize" : "fit",
          "w" : 2880
        } ],
        "display_url" : "pic.twitter.com\/Is6TmRSM7f"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/ErxKWmNKUh",
        "expanded_url" : "http:\/\/go.wh.gov\/8Mavvp",
        "display_url" : "go.wh.gov\/8Mavvp"
      } ]
    },
    "geo" : { },
    "id_str" : "744188235438391296",
    "text" : "The First Family is exploring our National Parks this weekend. Follow along: https:\/\/t.co\/ErxKWmNKUh #FindYourPark https:\/\/t.co\/Is6TmRSM7f",
    "id" : 744188235438391296,
    "created_at" : "2016-06-18 15:21:16 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 744188451273093121,
  "created_at" : "2016-06-18 15:22:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/QPZ9vzxsHo",
      "expanded_url" : "http:\/\/go.wh.gov\/t91WCW",
      "display_url" : "go.wh.gov\/t91WCW"
    } ]
  },
  "geo" : { },
  "id_str" : "744174312286883840",
  "text" : "\"Foremost in all of our minds has been the loss and the grief felt by the people of Orlando\" \u2014@POTUS: https:\/\/t.co\/QPZ9vzxsHo",
  "id" : 744174312286883840,
  "created_at" : "2016-06-18 14:25:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/QPZ9vzxsHo",
      "expanded_url" : "http:\/\/go.wh.gov\/t91WCW",
      "display_url" : "go.wh.gov\/t91WCW"
    } ]
  },
  "geo" : { },
  "id_str" : "744155040386973701",
  "text" : "After visiting Orlando, watch @POTUS reflect on meeting with the families of the victims: https:\/\/t.co\/QPZ9vzxsHo",
  "id" : 744155040386973701,
  "created_at" : "2016-06-18 13:09:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OrlandoUnited",
      "indices" : [ 28, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/HDRG07xkcG",
      "expanded_url" : "http:\/\/snpy.tv\/1UESG65",
      "display_url" : "snpy.tv\/1UESG65"
    } ]
  },
  "geo" : { },
  "id_str" : "743948914106130433",
  "text" : "We Will Stand with Orlando. #OrlandoUnited https:\/\/t.co\/HDRG07xkcG",
  "id" : 743948914106130433,
  "created_at" : "2016-06-17 23:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/743933830193520641\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/rnCqd1EEFV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClL2hFPXEAAijf1.jpg",
      "id_str" : "743927936672272384",
      "id" : 743927936672272384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClL2hFPXEAAijf1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/rnCqd1EEFV"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/RxPSPdGsxs",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "743933830193520641",
  "text" : "Under @POTUS\u2019s leadership, we've done more than ever before to #ActOnClimate: https:\/\/t.co\/RxPSPdGsxs https:\/\/t.co\/rnCqd1EEFV",
  "id" : 743933830193520641,
  "created_at" : "2016-06-17 22:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 51, 57 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/743927580307369984\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/OmlBNThqHb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClL2JYoWYAQRcBe.jpg",
      "id_str" : "743927529560498180",
      "id" : 743927529560498180,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClL2JYoWYAQRcBe.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/OmlBNThqHb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/ZGC7HpWsTy",
      "expanded_url" : "http:\/\/go.wh.gov\/ParksTrip",
      "display_url" : "go.wh.gov\/ParksTrip"
    } ]
  },
  "geo" : { },
  "id_str" : "743927580307369984",
  "text" : "America\u2019s natural heritage is a national treasure. @POTUS has made protecting it a priority: https:\/\/t.co\/ZGC7HpWsTy https:\/\/t.co\/OmlBNThqHb",
  "id" : 743927580307369984,
  "created_at" : "2016-06-17 22:05:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/GbJrKgPftu",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2016\/06\/17\/never-forget-we-are-charleston",
      "display_url" : "whitehouse.gov\/blog\/2016\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743916671333769216",
  "text" : "RT @vj44: We as a nation must find that amazing grace @POTUS spoke about 1 year ago in Charleston. https:\/\/t.co\/GbJrKgPftu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 44, 50 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/GbJrKgPftu",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2016\/06\/17\/never-forget-we-are-charleston",
        "display_url" : "whitehouse.gov\/blog\/2016\/06\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743883400851816448",
    "text" : "We as a nation must find that amazing grace @POTUS spoke about 1 year ago in Charleston. https:\/\/t.co\/GbJrKgPftu",
    "id" : 743883400851816448,
    "created_at" : "2016-06-17 19:09:58 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 743916671333769216,
  "created_at" : "2016-06-17 21:22:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 9, 15 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/rLDSSZGXOj",
      "expanded_url" : "http:\/\/go.wh.gov\/9RFgdx",
      "display_url" : "go.wh.gov\/9RFgdx"
    } ]
  },
  "geo" : { },
  "id_str" : "743908689308975104",
  "text" : ".@VP and @POTUS agree: Assault weapons and high-capacity magazines should be banned from civilian ownership \u2192 https:\/\/t.co\/rLDSSZGXOj",
  "id" : 743908689308975104,
  "created_at" : "2016-06-17 20:50:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 126, 133 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743903835610025985",
  "text" : "RT @DrBiden: Follow along! Dr. Biden will be sharing stories &amp; behind-the-scenes photos from the road in Latin America on @Medium https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 113, 120 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/MS76No6gEJ",
        "expanded_url" : "https:\/\/medium.com\/@DrBiden\/why-im-returning-to-latin-america-75987ba4b882#.tyh6ko2e9",
        "display_url" : "medium.com\/@DrBiden\/why-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743902483844567046",
    "text" : "Follow along! Dr. Biden will be sharing stories &amp; behind-the-scenes photos from the road in Latin America on @Medium https:\/\/t.co\/MS76No6gEJ",
    "id" : 743902483844567046,
    "created_at" : "2016-06-17 20:25:47 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 743903835610025985,
  "created_at" : "2016-06-17 20:31:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Jorgeson",
      "screen_name" : "kjorgeson",
      "indices" : [ 10, 20 ],
      "id_str" : "20655960",
      "id" : 20655960
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 77, 87 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/L8mcQRIwit",
      "expanded_url" : "https:\/\/www.instagram.com\/whitehouse\/",
      "display_url" : "instagram.com\/whitehouse\/"
    }, {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/jS3XjbhAYL",
      "expanded_url" : "https:\/\/twitter.com\/kjorgeson\/status\/743200854426058752",
      "display_url" : "twitter.com\/kjorgeson\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743897952683458561",
  "text" : "On belay, @KJorgeson? Excited to have you &amp; other climbers take over our @Instagram today: https:\/\/t.co\/L8mcQRIwit https:\/\/t.co\/jS3XjbhAYL",
  "id" : 743897952683458561,
  "created_at" : "2016-06-17 20:07:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Heinrich",
      "screen_name" : "MartinHeinrich",
      "indices" : [ 3, 18 ],
      "id_str" : "1099199839",
      "id" : 1099199839
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Carlsbad Caverns NPS",
      "screen_name" : "CavernsNPS",
      "indices" : [ 78, 89 ],
      "id_str" : "2216141035",
      "id" : 2216141035
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPSCentennial",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743873046927282176",
  "text" : "RT @MartinHeinrich: Honored to have @POTUS &amp; family in NM today. Visiting @CavernsNPS is a great way to celebrate the #NPSCentennial! https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 16, 22 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Carlsbad Caverns NPS",
        "screen_name" : "CavernsNPS",
        "indices" : [ 58, 69 ],
        "id_str" : "2216141035",
        "id" : 2216141035
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MartinHeinrich\/status\/743849260219768832\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/ApMFv37VVh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClKu9WcWQAAq5LR.jpg",
        "id_str" : "743849257489285120",
        "id" : 743849257489285120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClKu9WcWQAAq5LR.jpg",
        "sizes" : [ {
          "h" : 465,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 760
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 760
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 760
        } ],
        "display_url" : "pic.twitter.com\/ApMFv37VVh"
      } ],
      "hashtags" : [ {
        "text" : "NPSCentennial",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743849260219768832",
    "text" : "Honored to have @POTUS &amp; family in NM today. Visiting @CavernsNPS is a great way to celebrate the #NPSCentennial! https:\/\/t.co\/ApMFv37VVh",
    "id" : 743849260219768832,
    "created_at" : "2016-06-17 16:54:18 +0000",
    "user" : {
      "name" : "Martin Heinrich",
      "screen_name" : "MartinHeinrich",
      "protected" : false,
      "id_str" : "1099199839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472115942248308737\/BjSCAw32_normal.jpeg",
      "id" : 1099199839,
      "verified" : true
    }
  },
  "id" : 743873046927282176,
  "created_at" : "2016-06-17 18:28:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743848456112857088",
  "text" : "RT @VP: Taking steps to reduce gun violence worth doing if it could save one life. But it could save far more. Finish this. https:\/\/t.co\/P7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/P7LuMWrQ6B",
        "expanded_url" : "http:\/\/go.wh.gov\/9RFgdx",
        "display_url" : "go.wh.gov\/9RFgdx"
      } ]
    },
    "geo" : { },
    "id_str" : "743848155993735169",
    "text" : "Taking steps to reduce gun violence worth doing if it could save one life. But it could save far more. Finish this. https:\/\/t.co\/P7LuMWrQ6B",
    "id" : 743848155993735169,
    "created_at" : "2016-06-17 16:49:55 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 743848456112857088,
  "created_at" : "2016-06-17 16:51:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/19DFPNHTmU",
      "expanded_url" : "https:\/\/twitter.com\/thehill\/status\/743513757108867072",
      "display_url" : "twitter.com\/thehill\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "743812611477733376",
  "text" : "RT @rhodes44: Common sense step by bipartisan majority - Americans should be free to travel to Cuba. \n#CubaPolicy  https:\/\/t.co\/19DFPNHTmU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CubaPolicy",
        "indices" : [ 88, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/19DFPNHTmU",
        "expanded_url" : "https:\/\/twitter.com\/thehill\/status\/743513757108867072",
        "display_url" : "twitter.com\/thehill\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743564305992388610",
    "text" : "Common sense step by bipartisan majority - Americans should be free to travel to Cuba. \n#CubaPolicy  https:\/\/t.co\/19DFPNHTmU",
    "id" : 743564305992388610,
    "created_at" : "2016-06-16 22:01:59 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 743812611477733376,
  "created_at" : "2016-06-17 14:28:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 19, 22 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/NXNem8FBNN",
      "expanded_url" : "http:\/\/snpy.tv\/28IEAuD",
      "display_url" : "snpy.tv\/28IEAuD"
    } ]
  },
  "geo" : { },
  "id_str" : "743590903248363520",
  "text" : "Today @POTUS &amp; @VP visited Orlando. Watch the President give remarks after meeting with the families of the victims: https:\/\/t.co\/NXNem8FBNN",
  "id" : 743590903248363520,
  "created_at" : "2016-06-16 23:47:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayor Buddy Dyer",
      "screen_name" : "orlandomayor",
      "indices" : [ 3, 16 ],
      "id_str" : "30924790",
      "id" : 30924790
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 101, 112 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/orlandomayor\/status\/743534505059835905\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/WbGaV2VoJF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClGQsByUgAAO-Jm.jpg",
      "id_str" : "743534499560980480",
      "id" : 743534499560980480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClGQsByUgAAO-Jm.jpg",
      "sizes" : [ {
        "h" : 408,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/WbGaV2VoJF"
    } ],
    "hashtags" : [ {
      "text" : "OrlandoUnited",
      "indices" : [ 86, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743570218795016193",
  "text" : "RT @orlandomayor: Thank you @POTUS for showing your support to the Orlando community. #OrlandoUnited @WhiteHouse https:\/\/t.co\/WbGaV2VoJF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 83, 94 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/orlandomayor\/status\/743534505059835905\/photo\/1",
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/WbGaV2VoJF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClGQsByUgAAO-Jm.jpg",
        "id_str" : "743534499560980480",
        "id" : 743534499560980480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClGQsByUgAAO-Jm.jpg",
        "sizes" : [ {
          "h" : 408,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/WbGaV2VoJF"
      } ],
      "hashtags" : [ {
        "text" : "OrlandoUnited",
        "indices" : [ 68, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743534505059835905",
    "text" : "Thank you @POTUS for showing your support to the Orlando community. #OrlandoUnited @WhiteHouse https:\/\/t.co\/WbGaV2VoJF",
    "id" : 743534505059835905,
    "created_at" : "2016-06-16 20:03:34 +0000",
    "user" : {
      "name" : "Mayor Buddy Dyer",
      "screen_name" : "orlandomayor",
      "protected" : false,
      "id_str" : "30924790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798620932210393088\/stUeOfiu_normal.jpg",
      "id" : 30924790,
      "verified" : true
    }
  },
  "id" : 743570218795016193,
  "created_at" : "2016-06-16 22:25:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/743562545013760001\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/4ZclMbYy3Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClGpXGaUgAA46Sx.jpg",
      "id_str" : "743561627815936000",
      "id" : 743561627815936000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClGpXGaUgAA46Sx.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/4ZclMbYy3Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743562545013760001",
  "text" : "\"These families could be our families...They are our family\u2014they\u2019re part of the American family.\" \u2014@POTUS in Orlando https:\/\/t.co\/4ZclMbYy3Q",
  "id" : 743562545013760001,
  "created_at" : "2016-06-16 21:55:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743228209521532929",
  "text" : "RT @Cecilia44: Celebrating the anniversary of DACA: read the inspiring stories of what the DACAmented are doing four years later:  \nhttps:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/olsb1DemTk",
        "expanded_url" : "https:\/\/goo.gl\/YCsivl",
        "display_url" : "goo.gl\/YCsivl"
      } ]
    },
    "geo" : { },
    "id_str" : "743223490069684225",
    "text" : "Celebrating the anniversary of DACA: read the inspiring stories of what the DACAmented are doing four years later:  \nhttps:\/\/t.co\/olsb1DemTk",
    "id" : 743223490069684225,
    "created_at" : "2016-06-15 23:27:43 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 743228209521532929,
  "created_at" : "2016-06-15 23:46:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743220794520666112",
  "text" : "RT @Denis44: POTUS has proposed $1.1BN to help address the opioid epidemic in all 50 states. Now it is Congress\u2019s turn to vote. https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/743214816282583040\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/7de4ICTiFM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClBt7z9WAAAm-VU.jpg",
        "id_str" : "743214812843343872",
        "id" : 743214812843343872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClBt7z9WAAAm-VU.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/7de4ICTiFM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743214816282583040",
    "text" : "POTUS has proposed $1.1BN to help address the opioid epidemic in all 50 states. Now it is Congress\u2019s turn to vote. https:\/\/t.co\/7de4ICTiFM",
    "id" : 743214816282583040,
    "created_at" : "2016-06-15 22:53:15 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 743220794520666112,
  "created_at" : "2016-06-15 23:17:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 40, 46 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/ydogCEbuiL",
      "expanded_url" : "http:\/\/snpy.tv\/1XV224t",
      "display_url" : "snpy.tv\/1XV224t"
    } ]
  },
  "geo" : { },
  "id_str" : "743216376979005440",
  "text" : "\u201CThat\u2019s America\u2014one team, one nation.\u201D \u2014@POTUS on unity in the wake of the attack in Orlando: https:\/\/t.co\/ydogCEbuiL",
  "id" : 743216376979005440,
  "created_at" : "2016-06-15 22:59:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/aVldf5pIJZ",
      "expanded_url" : "http:\/\/snpy.tv\/1VXI7A9",
      "display_url" : "snpy.tv\/1VXI7A9"
    } ]
  },
  "geo" : { },
  "id_str" : "743193820058181632",
  "text" : "\"We have to make it harder for people who want to kill Americans to get their hands on weapons of war\" \u2014@POTUS: https:\/\/t.co\/aVldf5pIJZ",
  "id" : 743193820058181632,
  "created_at" : "2016-06-15 21:29:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743180454464004096",
  "text" : "RT @VP: Seth, you know it better than anyone. Couldn't agree more. Thanks for your service--then &amp; now. Let's get this done. https:\/\/t.co\/4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/4Q6h1iNklv",
        "expanded_url" : "https:\/\/twitter.com\/sethmoulton\/status\/742742213701074945",
        "display_url" : "twitter.com\/sethmoulton\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "743177477489573889",
    "text" : "Seth, you know it better than anyone. Couldn't agree more. Thanks for your service--then &amp; now. Let's get this done. https:\/\/t.co\/4Q6h1iNklv",
    "id" : 743177477489573889,
    "created_at" : "2016-06-15 20:24:52 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 743180454464004096,
  "created_at" : "2016-06-15 20:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/Bo9M1IXzu4",
      "expanded_url" : "http:\/\/snpy.tv\/1VXUUSZ",
      "display_url" : "snpy.tv\/1VXUUSZ"
    } ]
  },
  "geo" : { },
  "id_str" : "743174501072932865",
  "text" : "\"Our country isn\u2019t just all about the Benjamins \u2013 it\u2019s about the Tubmans, too.\" \u2014@POTUS at the #StateOfWomen Summit https:\/\/t.co\/Bo9M1IXzu4",
  "id" : 743174501072932865,
  "created_at" : "2016-06-15 20:13:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 39, 45 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/VKhkqUSCTO",
      "expanded_url" : "http:\/\/go.wh.gov\/Women",
      "display_url" : "go.wh.gov\/Women"
    }, {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/n6oq0r4fHU",
      "expanded_url" : "http:\/\/snpy.tv\/1US0ktG",
      "display_url" : "snpy.tv\/1US0ktG"
    } ]
  },
  "geo" : { },
  "id_str" : "743169414548230144",
  "text" : "\"This is what a feminist looks like.\" \u2014@POTUS: https:\/\/t.co\/VKhkqUSCTO #StateOfWomen https:\/\/t.co\/n6oq0r4fHU",
  "id" : 743169414548230144,
  "created_at" : "2016-06-15 19:52:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 59, 70 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743159047071883264",
  "text" : "RT @vj44: Honored to host members of the Newtown community @WhiteHouse today to screen \"Newtown\".  We are deeply moved by your courage and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 49, 60 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743136249817358336",
    "text" : "Honored to host members of the Newtown community @WhiteHouse today to screen \"Newtown\".  We are deeply moved by your courage and strength.",
    "id" : 743136249817358336,
    "created_at" : "2016-06-15 17:41:03 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 743159047071883264,
  "created_at" : "2016-06-15 19:11:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Lansky",
      "screen_name" : "Amy44",
      "indices" : [ 3, 9 ],
      "id_str" : "3440125814",
      "id" : 3440125814
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NHAS2020",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743137991082840064",
  "text" : "RT @Amy44: ONAP is back on Twitter! I'm Dr. Amy Lansky, and I'm happy to now serve as ONAP Director to implement #NHAS2020.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NHAS2020",
        "indices" : [ 102, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743121069062643713",
    "text" : "ONAP is back on Twitter! I'm Dr. Amy Lansky, and I'm happy to now serve as ONAP Director to implement #NHAS2020.",
    "id" : 743121069062643713,
    "created_at" : "2016-06-15 16:40:44 +0000",
    "user" : {
      "name" : "Amy Lansky",
      "screen_name" : "Amy44",
      "protected" : false,
      "id_str" : "3440125814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743106758684647424\/47aKPHuB_normal.jpg",
      "id" : 3440125814,
      "verified" : true
    }
  },
  "id" : 743137991082840064,
  "created_at" : "2016-06-15 17:47:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743118197524697088",
  "text" : "RT @SCOTUSnom: \"Dreams don't come true by magic, even if you're Harry Potter.\" \u2014Judge Garland to graduating 5th graders https:\/\/t.co\/NNIEcC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SCOTUSnom\/status\/743092465784229888\/photo\/1",
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/NNIEcCDnYy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck_-p3VUUAE-z4I.jpg",
        "id_str" : "743092458720874497",
        "id" : 743092458720874497,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck_-p3VUUAE-z4I.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/NNIEcCDnYy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "743092465784229888",
    "text" : "\"Dreams don't come true by magic, even if you're Harry Potter.\" \u2014Judge Garland to graduating 5th graders https:\/\/t.co\/NNIEcCDnYy",
    "id" : 743092465784229888,
    "created_at" : "2016-06-15 14:47:04 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 743118197524697088,
  "created_at" : "2016-06-15 16:29:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 8, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/vFkrwENTPL",
      "expanded_url" : "http:\/\/go.wh.gov\/T1kyi9",
      "display_url" : "go.wh.gov\/T1kyi9"
    } ]
  },
  "geo" : { },
  "id_str" : "742875721916416001",
  "text" : "Today's #NetNeutrality ruling is a victory for a free and fair internet: https:\/\/t.co\/vFkrwENTPL",
  "id" : 742875721916416001,
  "created_at" : "2016-06-15 00:25:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Oprah Winfrey",
      "screen_name" : "Oprah",
      "indices" : [ 62, 68 ],
      "id_str" : "19397785",
      "id" : 19397785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742861913231495168",
  "text" : "RT @FLOTUS: \"You make me proud to spell my name W-O-M-A-N.\" \u2014 @Oprah quoting Maya Angelou at the #StateOfWomen Summit.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oprah Winfrey",
        "screen_name" : "Oprah",
        "indices" : [ 50, 56 ],
        "id_str" : "19397785",
        "id" : 19397785
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StateOfWomen",
        "indices" : [ 85, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742861764333731840",
    "text" : "\"You make me proud to spell my name W-O-M-A-N.\" \u2014 @Oprah quoting Maya Angelou at the #StateOfWomen Summit.",
    "id" : 742861764333731840,
    "created_at" : "2016-06-14 23:30:20 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 742861913231495168,
  "created_at" : "2016-06-14 23:30:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UnitedStateofWomen",
      "screen_name" : "USWomen2016",
      "indices" : [ 3, 15 ],
      "id_str" : "4795344505",
      "id" : 4795344505
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 91, 98 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateofWomen",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742859421605187584",
  "text" : "RT @USWomen2016: \"My hope is that people leave here inspired and ready to do something.\" \u2013 @FLOTUS on The United #StateofWomen Summit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 74, 81 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StateofWomen",
        "indices" : [ 96, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742859248435007488",
    "text" : "\"My hope is that people leave here inspired and ready to do something.\" \u2013 @FLOTUS on The United #StateofWomen Summit",
    "id" : 742859248435007488,
    "created_at" : "2016-06-14 23:20:21 +0000",
    "user" : {
      "name" : "UnitedStateofWomen",
      "screen_name" : "USWomen2016",
      "protected" : false,
      "id_str" : "4795344505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692985821901754368\/5UoBC1W1_normal.png",
      "id" : 4795344505,
      "verified" : true
    }
  },
  "id" : 742859421605187584,
  "created_at" : "2016-06-14 23:21:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742856299776376832",
  "text" : "RT @FLOTUS: \"I wanted to wake up inspired - to do something greater than myself.\" \u2014The First Lady on her passion for public service. #State\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StateOfWomen",
        "indices" : [ 121, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742856159573344256",
    "text" : "\"I wanted to wake up inspired - to do something greater than myself.\" \u2014The First Lady on her passion for public service. #StateOfWomen",
    "id" : 742856159573344256,
    "created_at" : "2016-06-14 23:08:04 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 742856299776376832,
  "created_at" : "2016-06-14 23:08:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmyPoehlerSmartGirls",
      "screen_name" : "smrtgrls",
      "indices" : [ 3, 12 ],
      "id_str" : "113439399",
      "id" : 113439399
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 65, 72 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742855630696783873",
  "text" : "RT @smrtgrls: \"Surround yourself with people that uplift you.\" - @FLOTUS #StateOfWomen \uD83D\uDCAA\uD83D\uDC99",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 51, 58 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StateOfWomen",
        "indices" : [ 59, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742853621285584896",
    "text" : "\"Surround yourself with people that uplift you.\" - @FLOTUS #StateOfWomen \uD83D\uDCAA\uD83D\uDC99",
    "id" : 742853621285584896,
    "created_at" : "2016-06-14 22:57:59 +0000",
    "user" : {
      "name" : "AmyPoehlerSmartGirls",
      "screen_name" : "smrtgrls",
      "protected" : false,
      "id_str" : "113439399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700467562413297664\/0qESscTd_normal.png",
      "id" : 113439399,
      "verified" : true
    }
  },
  "id" : 742855630696783873,
  "created_at" : "2016-06-14 23:05:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Oprah Winfrey",
      "screen_name" : "Oprah",
      "indices" : [ 94, 100 ],
      "id_str" : "19397785",
      "id" : 19397785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742852261232054273",
  "text" : "RT @FLOTUS: \"Our first job in life as women is to get to know ourselves.\"  \u2014The First Lady to @Oprah at the #StateOfWomen Summit https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oprah Winfrey",
        "screen_name" : "Oprah",
        "indices" : [ 82, 88 ],
        "id_str" : "19397785",
        "id" : 19397785
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/742851652319862784\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/doavJCxvIU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck8jf6HVAAURzDY.jpg",
        "id_str" : "742851494622330885",
        "id" : 742851494622330885,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck8jf6HVAAURzDY.jpg",
        "sizes" : [ {
          "h" : 389,
          "resize" : "fit",
          "w" : 689
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 689
        }, {
          "h" : 389,
          "resize" : "fit",
          "w" : 689
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/doavJCxvIU"
      } ],
      "hashtags" : [ {
        "text" : "StateOfWomen",
        "indices" : [ 96, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742851652319862784",
    "text" : "\"Our first job in life as women is to get to know ourselves.\"  \u2014The First Lady to @Oprah at the #StateOfWomen Summit https:\/\/t.co\/doavJCxvIU",
    "id" : 742851652319862784,
    "created_at" : "2016-06-14 22:50:10 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 742852261232054273,
  "created_at" : "2016-06-14 22:52:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Oprah Winfrey",
      "screen_name" : "Oprah",
      "indices" : [ 29, 35 ],
      "id_str" : "19397785",
      "id" : 19397785
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/742849340863971328\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/ErIEI0r4fg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck8hXzMUkAEpcGk.jpg",
      "id_str" : "742849156302016513",
      "id" : 742849156302016513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck8hXzMUkAEpcGk.jpg",
      "sizes" : [ {
        "h" : 610,
        "resize" : "fit",
        "w" : 1210
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 1210
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/ErIEI0r4fg"
    } ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 60, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/U9Apn5c80e",
      "expanded_url" : "http:\/\/go.wh.gov\/Women",
      "display_url" : "go.wh.gov\/Women"
    } ]
  },
  "geo" : { },
  "id_str" : "742850910116663296",
  "text" : "RT @FLOTUS: The First Lady \u2713\n@Oprah \u2713\nJoin us live from the #StateOfWomen Summit: https:\/\/t.co\/U9Apn5c80e https:\/\/t.co\/ErIEI0r4fg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oprah Winfrey",
        "screen_name" : "Oprah",
        "indices" : [ 17, 23 ],
        "id_str" : "19397785",
        "id" : 19397785
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/742849340863971328\/photo\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/ErIEI0r4fg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck8hXzMUkAEpcGk.jpg",
        "id_str" : "742849156302016513",
        "id" : 742849156302016513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck8hXzMUkAEpcGk.jpg",
        "sizes" : [ {
          "h" : 610,
          "resize" : "fit",
          "w" : 1210
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 1210
        }, {
          "h" : 343,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/ErIEI0r4fg"
      } ],
      "hashtags" : [ {
        "text" : "StateOfWomen",
        "indices" : [ 48, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/U9Apn5c80e",
        "expanded_url" : "http:\/\/go.wh.gov\/Women",
        "display_url" : "go.wh.gov\/Women"
      } ]
    },
    "geo" : { },
    "id_str" : "742849340863971328",
    "text" : "The First Lady \u2713\n@Oprah \u2713\nJoin us live from the #StateOfWomen Summit: https:\/\/t.co\/U9Apn5c80e https:\/\/t.co\/ErIEI0r4fg",
    "id" : 742849340863971328,
    "created_at" : "2016-06-14 22:40:58 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 742850910116663296,
  "created_at" : "2016-06-14 22:47:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristen Bell",
      "screen_name" : "IMKristenBell",
      "indices" : [ 4, 18 ],
      "id_str" : "53297035",
      "id" : 53297035
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742840752363868160\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/IAnsuaswBi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck8ZaddVAAAWbxV.jpg",
      "id_str" : "742840405914353664",
      "id" : 742840405914353664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck8ZaddVAAAWbxV.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 4167,
        "resize" : "fit",
        "w" : 4167
      } ],
      "display_url" : "pic.twitter.com\/IAnsuaswBi"
    } ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/D17enE6HaS",
      "expanded_url" : "http:\/\/go.wh.gov\/MAkDDm",
      "display_url" : "go.wh.gov\/MAkDDm"
    } ]
  },
  "geo" : { },
  "id_str" : "742840752363868160",
  "text" : "Why @IMKristenBell thinks that being \"girly\" is great: https:\/\/t.co\/D17enE6HaS #StateOfWomen https:\/\/t.co\/IAnsuaswBi",
  "id" : 742840752363868160,
  "created_at" : "2016-06-14 22:06:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christy Turlington",
      "screen_name" : "CTurlington",
      "indices" : [ 4, 16 ],
      "id_str" : "122258041",
      "id" : 122258041
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742829976748097536\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/QvoUXpDNwZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck8P7BpXIAIAqWj.jpg",
      "id_str" : "742829970268037122",
      "id" : 742829970268037122,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck8P7BpXIAIAqWj.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 4167,
        "resize" : "fit",
        "w" : 4167
      } ],
      "display_url" : "pic.twitter.com\/QvoUXpDNwZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/5QnVXTKRFP",
      "expanded_url" : "http:\/\/go.wh.gov\/zQBaeW",
      "display_url" : "go.wh.gov\/zQBaeW"
    } ]
  },
  "geo" : { },
  "id_str" : "742829976748097536",
  "text" : "For @CTurlington, a difficult birth was a wake up call about maternal healthcare: https:\/\/t.co\/5QnVXTKRFP https:\/\/t.co\/QvoUXpDNwZ",
  "id" : 742829976748097536,
  "created_at" : "2016-06-14 21:24:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melinda Gates",
      "screen_name" : "melindagates",
      "indices" : [ 57, 70 ],
      "id_str" : "161801527",
      "id" : 161801527
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742814304982827010\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/kXwwQWAAB7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck8Bi-vWkAAz2cK.jpg",
      "id_str" : "742814164008210432",
      "id" : 742814164008210432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck8Bi-vWkAAz2cK.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 4167,
        "resize" : "fit",
        "w" : 4167
      } ],
      "display_url" : "pic.twitter.com\/kXwwQWAAB7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/EAMrh8LSwx",
      "expanded_url" : "http:\/\/go.wh.gov\/gycudp",
      "display_url" : "go.wh.gov\/gycudp"
    } ]
  },
  "geo" : { },
  "id_str" : "742814304982827010",
  "text" : "Women have boundless potential but are short on time\u2014and @MelindaGates\nwants to change that: https:\/\/t.co\/EAMrh8LSwx https:\/\/t.co\/kXwwQWAAB7",
  "id" : 742814304982827010,
  "created_at" : "2016-06-14 20:21:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742797935927283712",
  "text" : "\"That\u2019s the story we\u2019re going to keep on telling, so our girls see that they, too, are America.\" \u2014@POTUS #StateOfWomen",
  "id" : 742797935927283712,
  "created_at" : "2016-06-14 19:16:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742796638549331968",
  "text" : "\"Our country isn\u2019t just about the Benjamins\u2014it\u2019s about the Tubmans, too.\" \u2014@POTUS",
  "id" : 742796638549331968,
  "created_at" : "2016-06-14 19:11:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742795794655367173",
  "text" : "\"This is the future we\u2019re building. One where all of us, here at home and around the world, are free to live out our dreams.\" \u2014@POTUS",
  "id" : 742795794655367173,
  "created_at" : "2016-06-14 19:08:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/742795088649191424\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/YAuBasv71W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck7wKzwWkAEMKYy.jpg",
      "id_str" : "742795057045082113",
      "id" : 742795057045082113,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck7wKzwWkAEMKYy.jpg",
      "sizes" : [ {
        "h" : 611,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 1211
      } ],
      "display_url" : "pic.twitter.com\/YAuBasv71W"
    } ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/alnchk8D6D",
      "expanded_url" : "http:\/\/itsonus.org",
      "display_url" : "itsonus.org"
    } ]
  },
  "geo" : { },
  "id_str" : "742795088649191424",
  "text" : "\"We launched a movement of women and men to fight campus sexual assault\" \u2014@POTUS: https:\/\/t.co\/alnchk8D6D #ItsOnUs https:\/\/t.co\/YAuBasv71W",
  "id" : 742795088649191424,
  "created_at" : "2016-06-14 19:05:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742794987612610560\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/zrnBdKdCio",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck7wFdEWYAEU50c.jpg",
      "id_str" : "742794965055594497",
      "id" : 742794965055594497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck7wFdEWYAEU50c.jpg",
      "sizes" : [ {
        "h" : 611,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/zrnBdKdCio"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742794987612610560",
  "text" : "\"We\u2019re encouraging more girls to pursue their love of science, technology, engineering, and math.\" \u2014@POTUS https:\/\/t.co\/zrnBdKdCio",
  "id" : 742794987612610560,
  "created_at" : "2016-06-14 19:05:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742793667354742784\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/ez2ef0DXG8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck7u2JUWsAA75if.jpg",
      "id_str" : "742793602544349184",
      "id" : 742793602544349184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck7u2JUWsAA75if.jpg",
      "sizes" : [ {
        "h" : 611,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 1211
      } ],
      "display_url" : "pic.twitter.com\/ez2ef0DXG8"
    } ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742793667354742784",
  "text" : "\"We passed the ACA to give more Americans the security of health care coverage.\" \u2014@POTUS #StateOfWomen https:\/\/t.co\/ez2ef0DXG8",
  "id" : 742793667354742784,
  "created_at" : "2016-06-14 18:59:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742793242475925512\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/NCeE5gHNHi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck7udr2W0AAXMZi.jpg",
      "id_str" : "742793182317039616",
      "id" : 742793182317039616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck7udr2W0AAXMZi.jpg",
      "sizes" : [ {
        "h" : 605,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/NCeE5gHNHi"
    } ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742793242475925512",
  "text" : "\"We need to retool our system so that modern families and businesses can thrive.\" \u2014@POTUS #StateOfWomen https:\/\/t.co\/NCeE5gHNHi",
  "id" : 742793242475925512,
  "created_at" : "2016-06-14 18:58:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742793094735790085",
  "text" : "\"We should guarantee paid maternity leave and paid paternity leave, too.\" \u2014@POTUS #StateOfWomen",
  "id" : 742793094735790085,
  "created_at" : "2016-06-14 18:57:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742792951340879872",
  "text" : "\"We need equal pay for equal work. We need paid family and sick leave. We need affordable child care. We've got to raise the minimum wage.\"",
  "id" : 742792951340879872,
  "created_at" : "2016-06-14 18:56:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742792708536799237\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/zgwvO8OlIV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck7tvisWYAAFw8-.jpg",
      "id_str" : "742792389585166336",
      "id" : 742792389585166336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck7tvisWYAAFw8-.jpg",
      "sizes" : [ {
        "h" : 605,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 1211
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 1211
      } ],
      "display_url" : "pic.twitter.com\/zgwvO8OlIV"
    } ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742792708536799237",
  "text" : "\"Our workplace policies still look like they\u2019re straight out of Mad Men. \" \u2014@POTUS #StateOfWomen https:\/\/t.co\/zgwvO8OlIV",
  "id" : 742792708536799237,
  "created_at" : "2016-06-14 18:55:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742791748133498880",
  "text" : "RT @WHLive: \"54 ago, Katherine Johnson did the behind-the-scenes math to put a man in orbit. Today, almost 60 women have blasted into space\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742791705624207360",
    "text" : "\"54 ago, Katherine Johnson did the behind-the-scenes math to put a man in orbit. Today, almost 60 women have blasted into space themselves.\"",
    "id" : 742791705624207360,
    "created_at" : "2016-06-14 18:51:57 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 742791748133498880,
  "created_at" : "2016-06-14 18:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742791181650780160\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/kwZQ4dXO5S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck7sod7XEAE1Ry7.jpg",
      "id_str" : "742791168535236609",
      "id" : 742791168535236609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck7sod7XEAE1Ry7.jpg",
      "sizes" : [ {
        "h" : 447,
        "resize" : "fit",
        "w" : 935
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 935
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 935
      } ],
      "display_url" : "pic.twitter.com\/kwZQ4dXO5S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742791181650780160",
  "text" : "\"I may be a little grayer than I was eight years ago, but this is what a feminist looks like.\" \u2014@POTUS https:\/\/t.co\/kwZQ4dXO5S",
  "id" : 742791181650780160,
  "created_at" : "2016-06-14 18:49:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742781399502073857\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/htG0eNnHYm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck7jhd_XEAA_cO-.jpg",
      "id_str" : "742781152688279552",
      "id" : 742781152688279552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck7jhd_XEAA_cO-.jpg",
      "sizes" : [ {
        "h" : 610,
        "resize" : "fit",
        "w" : 1210
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 1210
      }, {
        "h" : 343,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/htG0eNnHYm"
    } ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 56, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/VKhkqUB22g",
      "expanded_url" : "http:\/\/go.wh.gov\/Women",
      "display_url" : "go.wh.gov\/Women"
    } ]
  },
  "geo" : { },
  "id_str" : "742781399502073857",
  "text" : "Today, we\u2019ll change tomorrow.\nWatch @POTUS speak at the #StateOfWomen Summit at 2:20pm ET: https:\/\/t.co\/VKhkqUB22g https:\/\/t.co\/htG0eNnHYm",
  "id" : 742781399502073857,
  "created_at" : "2016-06-14 18:11:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742759351908204544",
  "text" : "\"That\u2019s the spirit we see in Orlando. That\u2019s the unity and resolve that will allow us to defeat ISIL.\"  \u2014@POTUS",
  "id" : 742759351908204544,
  "created_at" : "2016-06-14 16:43:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742759119187251200",
  "text" : "\"That's the American military. That's America\u2014one team, one nation. Those are the values that ISIL's trying to destroy.\" \u2014@POTUS",
  "id" : 742759119187251200,
  "created_at" : "2016-06-14 16:42:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742758578252046336",
  "text" : "RT @WHLive: \"This is a country founded on basic freedoms, including freedom of religion.\" \u2014@POTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 79, 85 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742758535239479296",
    "text" : "\"This is a country founded on basic freedoms, including freedom of religion.\" \u2014@POTUS",
    "id" : 742758535239479296,
    "created_at" : "2016-06-14 16:40:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 742758578252046336,
  "created_at" : "2016-06-14 16:40:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742756115155406849",
  "text" : "\"Be tough on terrorism. Stop making it easy as possible for terrorists to buy assault weapons. Reinstate the assault weapons ban.\" \u2014@POTUS",
  "id" : 742756115155406849,
  "created_at" : "2016-06-14 16:30:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742755866126999557",
  "text" : "\"We have to make it harder for people who want to kill Americans to get their hands on weapons of war that let them kill dozens\" \u2014@POTUS",
  "id" : 742755866126999557,
  "created_at" : "2016-06-14 16:29:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742754597056487424",
  "text" : "\"ISIL has now lost nearly half of the populated territory it once controlled in Iraq\u2014and it will lose more.\" \u2014@POTUS",
  "id" : 742754597056487424,
  "created_at" : "2016-06-14 16:24:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742754486276530176",
  "text" : "\"We\u2019ve taken out more than 120 top ISIL leaders &amp; commanders\nOur message is clear: If you target America &amp; our allies, you will not be safe\"",
  "id" : 742754486276530176,
  "created_at" : "2016-06-14 16:24:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742753541320769536",
  "text" : "\"They are not alone. The American people, our allies, friends, people all over the world stand with them\" \u2014@POTUS on the people of Orlando",
  "id" : 742753541320769536,
  "created_at" : "2016-06-14 16:20:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/oDIQ2UMleK",
      "expanded_url" : "http:\/\/go.wh.gov\/ISIL",
      "display_url" : "go.wh.gov\/ISIL"
    } ]
  },
  "geo" : { },
  "id_str" : "742745782718238720",
  "text" : "Tune in at 11:55am ET: @POTUS will deliver a statement after meeting with his National Security Council on ISIL: https:\/\/t.co\/oDIQ2UMleK",
  "id" : 742745782718238720,
  "created_at" : "2016-06-14 15:49:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 31, 34 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 101, 110 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/feb37FmYzM",
      "expanded_url" : "https:\/\/www.facebook.com\/VicePresidentBiden\/",
      "display_url" : "facebook.com\/VicePresidentB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742717492297109504",
  "text" : "RT @VPLive: Happening Now: The @VP is speaking live from the United #StateOfWomen Summit. Tune in on @Facebook: https:\/\/t.co\/feb37FmYzM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 19, 22 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "Facebook",
        "screen_name" : "facebook",
        "indices" : [ 89, 98 ],
        "id_str" : "2425151",
        "id" : 2425151
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StateOfWomen",
        "indices" : [ 56, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/feb37FmYzM",
        "expanded_url" : "https:\/\/www.facebook.com\/VicePresidentBiden\/",
        "display_url" : "facebook.com\/VicePresidentB\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742711013536092160",
    "text" : "Happening Now: The @VP is speaking live from the United #StateOfWomen Summit. Tune in on @Facebook: https:\/\/t.co\/feb37FmYzM",
    "id" : 742711013536092160,
    "created_at" : "2016-06-14 13:31:19 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 742717492297109504,
  "created_at" : "2016-06-14 13:57:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "UnitedStateofWomen",
      "screen_name" : "USWomen2016",
      "indices" : [ 55, 67 ],
      "id_str" : "4795344505",
      "id" : 4795344505
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateofWomen",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/elAlMYbTHd",
      "expanded_url" : "http:\/\/www.theunitedstateofwomen.org\/",
      "display_url" : "theunitedstateofwomen.org"
    } ]
  },
  "geo" : { },
  "id_str" : "742706975482384386",
  "text" : "RT @vj44: Good Morning! Very excited to be here at the @USWomen2016 Summit! Tune in at https:\/\/t.co\/elAlMYbTHd #StateofWomen https:\/\/t.co\/3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UnitedStateofWomen",
        "screen_name" : "USWomen2016",
        "indices" : [ 45, 57 ],
        "id_str" : "4795344505",
        "id" : 4795344505
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/742703733319053313\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/3SfUCvUXuX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck6c35DUgAA99CV.jpg",
        "id_str" : "742703472584196096",
        "id" : 742703472584196096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck6c35DUgAA99CV.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/3SfUCvUXuX"
      } ],
      "hashtags" : [ {
        "text" : "StateofWomen",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/elAlMYbTHd",
        "expanded_url" : "http:\/\/www.theunitedstateofwomen.org\/",
        "display_url" : "theunitedstateofwomen.org"
      } ]
    },
    "geo" : { },
    "id_str" : "742703733319053313",
    "text" : "Good Morning! Very excited to be here at the @USWomen2016 Summit! Tune in at https:\/\/t.co\/elAlMYbTHd #StateofWomen https:\/\/t.co\/3SfUCvUXuX",
    "id" : 742703733319053313,
    "created_at" : "2016-06-14 13:02:23 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 742706975482384386,
  "created_at" : "2016-06-14 13:15:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 27, 33 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Orlando",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742534984326623234",
  "text" : "RT @PressSec: On Thursday, @POTUS will travel to #Orlando to pay his respects to victims' families and stand in solidarity with the communi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 13, 19 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Orlando",
        "indices" : [ 35, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742534940512948224",
    "text" : "On Thursday, @POTUS will travel to #Orlando to pay his respects to victims' families and stand in solidarity with the community.",
    "id" : 742534940512948224,
    "created_at" : "2016-06-14 01:51:40 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 742534984326623234,
  "created_at" : "2016-06-14 01:51:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/i4OGrD2fBA",
      "expanded_url" : "http:\/\/go.wh.gov\/o45VQN",
      "display_url" : "go.wh.gov\/o45VQN"
    }, {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/Xjb8vre3eK",
      "expanded_url" : "http:\/\/snpy.tv\/1UOqldp",
      "display_url" : "snpy.tv\/1UOqldp"
    } ]
  },
  "geo" : { },
  "id_str" : "742425523142430720",
  "text" : "Watch @POTUS speak after his briefing on the attack in Orlando, Florida: https:\/\/t.co\/i4OGrD2fBA https:\/\/t.co\/Xjb8vre3eK",
  "id" : 742425523142430720,
  "created_at" : "2016-06-13 18:36:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/i7fOS3qhYh",
      "expanded_url" : "http:\/\/snpy.tv\/1VTwev2",
      "display_url" : "snpy.tv\/1VTwev2"
    } ]
  },
  "geo" : { },
  "id_str" : "742106752972402688",
  "text" : "This is an especially heartbreaking day for all our friends\u2014our fellow Americans\u2014who are LGBT: https:\/\/t.co\/i7fOS3qhYh",
  "id" : 742106752972402688,
  "created_at" : "2016-06-12 21:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/i7fOS38GzH",
      "expanded_url" : "http:\/\/snpy.tv\/1VTwev2",
      "display_url" : "snpy.tv\/1VTwev2"
    } ]
  },
  "geo" : { },
  "id_str" : "742074006526820353",
  "text" : "Attacks on any American\u2014regardless of race, ethnicity, religion, or sexual orientation\u2014is an attack on all of us.  https:\/\/t.co\/i7fOS38GzH",
  "id" : 742074006526820353,
  "created_at" : "2016-06-12 19:20:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742071444193050624\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/uivIQQQC9j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkxdtUFWYAA80rc.jpg",
      "id_str" : "742071071675932672",
      "id" : 742071071675932672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkxdtUFWYAA80rc.jpg",
      "sizes" : [ {
        "h" : 587,
        "resize" : "fit",
        "w" : 697
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 697
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 573,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 587,
        "resize" : "fit",
        "w" : 697
      } ],
      "display_url" : "pic.twitter.com\/uivIQQQC9j"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/k6QWAbrHAh",
      "expanded_url" : "http:\/\/go.wh.gov\/ab6dbt",
      "display_url" : "go.wh.gov\/ab6dbt"
    } ]
  },
  "geo" : { },
  "id_str" : "742071444193050624",
  "text" : ".@POTUS orders U.S. flags flown at half-staff to honor the victims of the attack in Orlando: https:\/\/t.co\/k6QWAbrHAh https:\/\/t.co\/uivIQQQC9j",
  "id" : 742071444193050624,
  "created_at" : "2016-06-12 19:09:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742064336550662144\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/ceFk3QSkko",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkxXfDPUYAAVKqc.jpg",
      "id_str" : "742064229566406656",
      "id" : 742064229566406656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkxXfDPUYAAVKqc.jpg",
      "sizes" : [ {
        "h" : 1407,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1979,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 825,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ceFk3QSkko"
    } ],
    "hashtags" : [ {
      "text" : "Orlando",
      "indices" : [ 100, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742064336550662144",
  "text" : "\"As Americans, we are united in grief, in outrage, and in resolve to defend our people.\" \u2014@POTUS on #Orlando https:\/\/t.co\/ceFk3QSkko",
  "id" : 742064336550662144,
  "created_at" : "2016-06-12 18:41:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Orlando",
      "indices" : [ 29, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/i7fOS3qhYh",
      "expanded_url" : "http:\/\/snpy.tv\/1VTwev2",
      "display_url" : "snpy.tv\/1VTwev2"
    } ]
  },
  "geo" : { },
  "id_str" : "742060786072354817",
  "text" : "\u201CWe stand with the people of #Orlando who have endured a terrible attack on their city.\" \u2014@POTUS https:\/\/t.co\/i7fOS3qhYh",
  "id" : 742060786072354817,
  "created_at" : "2016-06-12 18:27:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/i7fOS38GzH",
      "expanded_url" : "http:\/\/snpy.tv\/1VTwev2",
      "display_url" : "snpy.tv\/1VTwev2"
    } ]
  },
  "geo" : { },
  "id_str" : "742058774412681221",
  "text" : "\"In the face of hate and violence, we will love one another. We will not give into fear.\" \u2014@POTUS https:\/\/t.co\/i7fOS38GzH",
  "id" : 742058774412681221,
  "created_at" : "2016-06-12 18:19:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Orlando",
      "indices" : [ 79, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/i7fOS38GzH",
      "expanded_url" : "http:\/\/snpy.tv\/1VTwev2",
      "display_url" : "snpy.tv\/1VTwev2"
    } ]
  },
  "geo" : { },
  "id_str" : "742057172532482048",
  "text" : "\"This was an act of terror and act of hate.\" \u2014@POTUS on the tragic shooting in #Orlando https:\/\/t.co\/i7fOS38GzH",
  "id" : 742057172532482048,
  "created_at" : "2016-06-12 18:13:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742053625858543616\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/7RTFgaAlDc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkxNytAUYAAmldR.jpg",
      "id_str" : "742053572079017984",
      "id" : 742053572079017984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkxNytAUYAAmldR.jpg",
      "sizes" : [ {
        "h" : 517,
        "resize" : "fit",
        "w" : 934
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 934
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 517,
        "resize" : "fit",
        "w" : 934
      } ],
      "display_url" : "pic.twitter.com\/7RTFgaAlDc"
    } ],
    "hashtags" : [ {
      "text" : "Orlando",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/k6QWAbrHAh",
      "expanded_url" : "http:\/\/go.wh.gov\/ab6dbt",
      "display_url" : "go.wh.gov\/ab6dbt"
    } ]
  },
  "geo" : { },
  "id_str" : "742053625858543616",
  "text" : "Happening now: @POTUS speaks on the tragic shooting in #Orlando \u2192 https:\/\/t.co\/k6QWAbrHAh https:\/\/t.co\/7RTFgaAlDc",
  "id" : 742053625858543616,
  "created_at" : "2016-06-12 17:59:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Orlando",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/k6QWAbrHAh",
      "expanded_url" : "http:\/\/go.wh.gov\/ab6dbt",
      "display_url" : "go.wh.gov\/ab6dbt"
    } ]
  },
  "geo" : { },
  "id_str" : "742028842785755136",
  "text" : "At 1:30pm ET, @POTUS will deliver a statement on the tragic shooting in #Orlando. Watch live: https:\/\/t.co\/k6QWAbrHAh",
  "id" : 742028842785755136,
  "created_at" : "2016-06-12 16:20:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 27, 30 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/AI3z2J3Cp5",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/06\/12\/statement-vice-president-bidens-spokesperson",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "742024796893028352",
  "text" : "RT @VPLive: Statement from @VP spokesperson on last night's heinous attack in Orlando: https:\/\/t.co\/AI3z2J3Cp5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 15, 18 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/AI3z2J3Cp5",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2016\/06\/12\/statement-vice-president-bidens-spokesperson",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "742020423555125250",
    "text" : "Statement from @VP spokesperson on last night's heinous attack in Orlando: https:\/\/t.co\/AI3z2J3Cp5",
    "id" : 742020423555125250,
    "created_at" : "2016-06-12 15:47:09 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 742024796893028352,
  "created_at" : "2016-06-12 16:04:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 13, 22 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/742002464203776001\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/GUCmIWNctn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkwZGmXWgAAx3ne.jpg",
      "id_str" : "741995639777689600",
      "id" : 741995639777689600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkwZGmXWgAAx3ne.jpg",
      "sizes" : [ {
        "h" : 391,
        "resize" : "fit",
        "w" : 844
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 844
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 844
      } ],
      "display_url" : "pic.twitter.com\/GUCmIWNctn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/61AlHODnJ7",
      "expanded_url" : "http:\/\/go.wh.gov\/s9DbKt",
      "display_url" : "go.wh.gov\/s9DbKt"
    } ]
  },
  "geo" : { },
  "id_str" : "742002464203776001",
  "text" : "Statement by @PressSec on the tragic shooting in Orlando: https:\/\/t.co\/61AlHODnJ7 https:\/\/t.co\/GUCmIWNctn",
  "id" : 742002464203776001,
  "created_at" : "2016-06-12 14:35:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PuertoRico",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/9bYXm2vX85",
      "expanded_url" : "http:\/\/go.wh.gov\/brKa1M",
      "display_url" : "go.wh.gov\/brKa1M"
    } ]
  },
  "geo" : { },
  "id_str" : "741744380092895232",
  "text" : "\"Teachers have to choose between turning on the lights or turning on the computers.\" \u2014@POTUS on #PuertoRico: https:\/\/t.co\/9bYXm2vX85",
  "id" : 741744380092895232,
  "created_at" : "2016-06-11 21:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pride2016",
      "indices" : [ 70, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/6b7pNQXiHW",
      "expanded_url" : "http:\/\/snpy.tv\/1TYjApV",
      "display_url" : "snpy.tv\/1TYjApV"
    } ]
  },
  "geo" : { },
  "id_str" : "741730247188484096",
  "text" : "\"When all Americans are treated equal, we are all more free.\" \u2014@POTUS #Pride2016 https:\/\/t.co\/6b7pNQXiHW",
  "id" : 741730247188484096,
  "created_at" : "2016-06-11 20:34:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741727687291478016",
  "text" : "RT @lacasablanca: \"Los puertorrique\u00F1os son ciudadanos estadounidenses, igual que los de Maine o los de Oklahoma.\" \u2014@POTUS: https:\/\/t.co\/UW5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 97, 103 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/UW5Xpfsudm",
        "expanded_url" : "http:\/\/go.wh.gov\/brKa1M",
        "display_url" : "go.wh.gov\/brKa1M"
      } ]
    },
    "geo" : { },
    "id_str" : "741699088152858624",
    "text" : "\"Los puertorrique\u00F1os son ciudadanos estadounidenses, igual que los de Maine o los de Oklahoma.\" \u2014@POTUS: https:\/\/t.co\/UW5Xpfsudm",
    "id" : 741699088152858624,
    "created_at" : "2016-06-11 18:30:17 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 741727687291478016,
  "created_at" : "2016-06-11 20:23:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 51, 57 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/9bYXm2vX85",
      "expanded_url" : "http:\/\/go.wh.gov\/brKa1M",
      "display_url" : "go.wh.gov\/brKa1M"
    } ]
  },
  "geo" : { },
  "id_str" : "741684003942465537",
  "text" : "\"We don\u2019t turn our backs on our fellow Americans\" \u2014@POTUS on addressing Puerto Rico's economic crisis: https:\/\/t.co\/9bYXm2vX85",
  "id" : 741684003942465537,
  "created_at" : "2016-06-11 17:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/9bYXm2vX85",
      "expanded_url" : "http:\/\/go.wh.gov\/brKa1M",
      "display_url" : "go.wh.gov\/brKa1M"
    } ]
  },
  "geo" : { },
  "id_str" : "741672646211866625",
  "text" : "\"Puerto Ricans are American citizens, just like folks in Maine or Oklahoma or New Mexico\"\u2014@POTUS: https:\/\/t.co\/9bYXm2vX85",
  "id" : 741672646211866625,
  "created_at" : "2016-06-11 16:45:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/9bYXm2vX85",
      "expanded_url" : "http:\/\/go.wh.gov\/brKa1M",
      "display_url" : "go.wh.gov\/brKa1M"
    } ]
  },
  "geo" : { },
  "id_str" : "741665098586984448",
  "text" : "\"Today, I want to talk with you about the crisis in Puerto Rico\u2014and why it matters to all of us.\"  \u2014@POTUS: https:\/\/t.co\/9bYXm2vX85",
  "id" : 741665098586984448,
  "created_at" : "2016-06-11 16:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741407640669016065",
  "text" : "RT @vj44: \"Muhammad Ali was America. He will always be America.\" An honor to read @POTUS statement at the Champ's funeral. https:\/\/t.co\/wOf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 72, 78 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/741397311906033664\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/wOfi2Aohtw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckn46YWVEAAF8yA.jpg",
        "id_str" : "741397295531364352",
        "id" : 741397295531364352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckn46YWVEAAF8yA.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/wOfi2Aohtw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741397311906033664",
    "text" : "\"Muhammad Ali was America. He will always be America.\" An honor to read @POTUS statement at the Champ's funeral. https:\/\/t.co\/wOfi2Aohtw",
    "id" : 741397311906033664,
    "created_at" : "2016-06-10 22:31:08 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 741407640669016065,
  "created_at" : "2016-06-10 23:12:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 3, 16 ],
      "id_str" : "426909329",
      "id" : 426909329
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741367767501266944",
  "text" : "RT @DrFriedenCDC: Prevent #Zika by taking steps to prevent mosquito bites this summer. Use an EPA-registered insect repellent. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrFriedenCDC\/status\/741363148628889601\/photo\/1",
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/6q1dkFDHia",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CknZ2pJXAAAov-t.jpg",
        "id_str" : "741363146460430336",
        "id" : 741363146460430336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CknZ2pJXAAAov-t.jpg",
        "sizes" : [ {
          "h" : 531,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 846,
          "resize" : "fit",
          "w" : 1084
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 846,
          "resize" : "fit",
          "w" : 1084
        }, {
          "h" : 846,
          "resize" : "fit",
          "w" : 1084
        } ],
        "display_url" : "pic.twitter.com\/6q1dkFDHia"
      } ],
      "hashtags" : [ {
        "text" : "Zika",
        "indices" : [ 8, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741363148628889601",
    "text" : "Prevent #Zika by taking steps to prevent mosquito bites this summer. Use an EPA-registered insect repellent. https:\/\/t.co\/6q1dkFDHia",
    "id" : 741363148628889601,
    "created_at" : "2016-06-10 20:15:23 +0000",
    "user" : {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "protected" : false,
      "id_str" : "426909329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1677474099\/Frieden-88_-_1200x1200_normal.jpg",
      "id" : 426909329,
      "verified" : true
    }
  },
  "id" : 741367767501266944,
  "created_at" : "2016-06-10 20:33:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 64, 70 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/741360117506007040\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/K1MwwxT3P5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CknW57FUYAEfrNH.jpg",
      "id_str" : "741359904280043521",
      "id" : 741359904280043521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CknW57FUYAEfrNH.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1001,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1001,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/K1MwwxT3P5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/ekO7NZEv75",
      "expanded_url" : "http:\/\/go.wh.gov\/t5zEJS",
      "display_url" : "go.wh.gov\/t5zEJS"
    } ]
  },
  "geo" : { },
  "id_str" : "741360117506007040",
  "text" : "\"I grew up having my identify shaped by what he accomplished.\" \u2014@POTUS on Muhammad Ali: https:\/\/t.co\/ekO7NZEv75 https:\/\/t.co\/K1MwwxT3P5",
  "id" : 741360117506007040,
  "created_at" : "2016-06-10 20:03:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/medium.com\" rel=\"nofollow\"\u003EMedium\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "beverly bond",
      "screen_name" : "BEVERLYBOND",
      "indices" : [ 38, 50 ],
      "id_str" : "34111781",
      "id" : 34111781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/OMqXeukMJK",
      "expanded_url" : "https:\/\/medium.com\/p\/empower-a-girl-change-the-world-f41a201ecd14",
      "display_url" : "medium.com\/p\/empower-a-gi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741331531390668800",
  "text" : "\u201CEmpower a Girl, Change the World\u201D by @BEVERLYBOND https:\/\/t.co\/OMqXeukMJK",
  "id" : 741331531390668800,
  "created_at" : "2016-06-10 18:09:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Carlsbad Caverns NPS",
      "screen_name" : "CavernsNPS",
      "indices" : [ 28, 39 ],
      "id_str" : "2216141035",
      "id" : 2216141035
    }, {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "indices" : [ 42, 54 ],
      "id_str" : "18726942",
      "id" : 18726942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 58, 71 ]
    }, {
      "text" : "NPS100",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/MfXGu9iVyc",
      "expanded_url" : "http:\/\/FindYourPark.com",
      "display_url" : "FindYourPark.com"
    }, {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/obdzA6RQHT",
      "expanded_url" : "http:\/\/snpy.tv\/1OffFIb",
      "display_url" : "snpy.tv\/1OffFIb"
    } ]
  },
  "geo" : { },
  "id_str" : "741322474193883136",
  "text" : "The First Family \u2713\n@POTUS \u2713\n@CavernsNPS \u2713\n@YosemiteNPS \u2713\n\n#FindYourPark \u2192 https:\/\/t.co\/MfXGu9iVyc #NPS100 https:\/\/t.co\/obdzA6RQHT",
  "id" : 741322474193883136,
  "created_at" : "2016-06-10 17:33:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brittany Packnett",
      "screen_name" : "MsPackyetti",
      "indices" : [ 45, 57 ],
      "id_str" : "239509917",
      "id" : 239509917
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/741311655540232192\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/skMlt8tVJJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckmq_h6XAAELfIm.jpg",
      "id_str" : "741311622090784769",
      "id" : 741311622090784769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckmq_h6XAAELfIm.jpg",
      "sizes" : [ {
        "h" : 2083,
        "resize" : "fit",
        "w" : 2075
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 677
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2040
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1195
      } ],
      "display_url" : "pic.twitter.com\/skMlt8tVJJ"
    } ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/4eGznYLJHf",
      "expanded_url" : "http:\/\/go.wh.gov\/7QAcvT",
      "display_url" : "go.wh.gov\/7QAcvT"
    } ]
  },
  "geo" : { },
  "id_str" : "741311655540232192",
  "text" : "Who is the most powerful woman you know? For @MsPackyetti, it's her mother: https:\/\/t.co\/4eGznYLJHf #StateOfWomen https:\/\/t.co\/skMlt8tVJJ",
  "id" : 741311655540232192,
  "created_at" : "2016-06-10 16:50:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    }, {
      "name" : "TransportationGov",
      "screen_name" : "USDOT",
      "indices" : [ 24, 30 ],
      "id_str" : "393562221",
      "id" : 393562221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/UuVfPeGqx1",
      "expanded_url" : "https:\/\/www.transportation.gov\/briefing-room\/us-transportation-secretary-foxx-approves-us-airlines-begin-scheduled-service-cuba",
      "display_url" : "transportation.gov\/briefing-room\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "741297078203232256",
  "text" : "RT @rhodes44: BREAKING: @USDOT announced authorization of direct flights from 6 US airlines to #Cuba \u2192 https:\/\/t.co\/UuVfPeGqx1 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TransportationGov",
        "screen_name" : "USDOT",
        "indices" : [ 10, 16 ],
        "id_str" : "393562221",
        "id" : 393562221
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/rhodes44\/status\/741296701290516480\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/pg4o1RaB81",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CkmdYkAUkAE6foX.jpg",
        "id_str" : "741296658986602497",
        "id" : 741296658986602497,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CkmdYkAUkAE6foX.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/pg4o1RaB81"
      } ],
      "hashtags" : [ {
        "text" : "Cuba",
        "indices" : [ 81, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/UuVfPeGqx1",
        "expanded_url" : "https:\/\/www.transportation.gov\/briefing-room\/us-transportation-secretary-foxx-approves-us-airlines-begin-scheduled-service-cuba",
        "display_url" : "transportation.gov\/briefing-room\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "741296701290516480",
    "text" : "BREAKING: @USDOT announced authorization of direct flights from 6 US airlines to #Cuba \u2192 https:\/\/t.co\/UuVfPeGqx1 https:\/\/t.co\/pg4o1RaB81",
    "id" : 741296701290516480,
    "created_at" : "2016-06-10 15:51:20 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 741297078203232256,
  "created_at" : "2016-06-10 15:52:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "indices" : [ 1, 13 ],
      "id_str" : "15485441",
      "id" : 15485441
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/zMvtnNfYLo",
      "expanded_url" : "http:\/\/snpy.tv\/1TZuFqE",
      "display_url" : "snpy.tv\/1TZuFqE"
    } ]
  },
  "geo" : { },
  "id_str" : "741288931027652608",
  "text" : ".@JimmyFallon: \"This trade deal will help put everyday Americans back to...\"\n@POTUS: \"Work, work, work, work\" #TPP\nhttps:\/\/t.co\/zMvtnNfYLo",
  "id" : 741288931027652608,
  "created_at" : "2016-06-10 15:20:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/741262865722691585\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/GdjunwkujC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckl-nXzWsAApPux.jpg",
      "id_str" : "741262828548567040",
      "id" : 741262828548567040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckl-nXzWsAApPux.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/GdjunwkujC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741268481669275648",
  "text" : "RT @vj44: .@POTUS with Gilbert Baker, designer of the original Rainbow Pride Flag! https:\/\/t.co\/GdjunwkujC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/741262865722691585\/photo\/1",
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/GdjunwkujC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckl-nXzWsAApPux.jpg",
        "id_str" : "741262828548567040",
        "id" : 741262828548567040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckl-nXzWsAApPux.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/GdjunwkujC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741262865722691585",
    "text" : ".@POTUS with Gilbert Baker, designer of the original Rainbow Pride Flag! https:\/\/t.co\/GdjunwkujC",
    "id" : 741262865722691585,
    "created_at" : "2016-06-10 13:36:53 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 741268481669275648,
  "created_at" : "2016-06-10 13:59:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/tQXVlJa1pq",
      "expanded_url" : "http:\/\/go.wh.gov\/ToDoList",
      "display_url" : "go.wh.gov\/ToDoList"
    } ]
  },
  "geo" : { },
  "id_str" : "741261713106821121",
  "text" : "RT @PressSec: If GOPers in Congress want to act in ways that'll actually help people, here's a to-do list https:\/\/t.co\/tQXVlJa1pq https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PressSec\/status\/741257393003057156\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/DNK5F1ZxuS",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Cki7Ju_VAAAwbju.jpg",
        "id_str" : "741047914609311744",
        "id" : 741047914609311744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Cki7Ju_VAAAwbju.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DNK5F1ZxuS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/tQXVlJa1pq",
        "expanded_url" : "http:\/\/go.wh.gov\/ToDoList",
        "display_url" : "go.wh.gov\/ToDoList"
      } ]
    },
    "geo" : { },
    "id_str" : "741257393003057156",
    "text" : "If GOPers in Congress want to act in ways that'll actually help people, here's a to-do list https:\/\/t.co\/tQXVlJa1pq https:\/\/t.co\/DNK5F1ZxuS",
    "id" : 741257393003057156,
    "created_at" : "2016-06-10 13:15:09 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 741261713106821121,
  "created_at" : "2016-06-10 13:32:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Fallon Tonight",
      "screen_name" : "FallonTonight",
      "indices" : [ 81, 95 ],
      "id_str" : "19777398",
      "id" : 19777398
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/741080031397445632\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/1uyuHVevfZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkjKCEdUkAEFbhI.jpg",
      "id_str" : "741064275607719937",
      "id" : 741064275607719937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkjKCEdUkAEFbhI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 466,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1028,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 822,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1028,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/1uyuHVevfZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741080031397445632",
  "text" : ".@POTUS \u2713\nSerious dance moves \u2713\n\nTune in at 11:35pm ET to watch the President on @FallonTonight! https:\/\/t.co\/1uyuHVevfZ",
  "id" : 741080031397445632,
  "created_at" : "2016-06-10 01:30:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 23, 32 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/741063841400782848\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/2tQAOznZNS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkjJojXVEAAU782.jpg",
      "id_str" : "741063837227487232",
      "id" : 741063837227487232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkjJojXVEAAU782.jpg",
      "sizes" : [ {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1334,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 382
      } ],
      "display_url" : "pic.twitter.com\/2tQAOznZNS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741069654265876481",
  "text" : "RT @vj44: Watch now on @Snapchat story to learn more about National Gun Violence Awareness day https:\/\/t.co\/2tQAOznZNS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Snapchat",
        "screen_name" : "Snapchat",
        "indices" : [ 13, 22 ],
        "id_str" : "376502929",
        "id" : 376502929
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/741063841400782848\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/2tQAOznZNS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkjJojXVEAAU782.jpg",
        "id_str" : "741063837227487232",
        "id" : 741063837227487232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkjJojXVEAAU782.jpg",
        "sizes" : [ {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 675
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1334,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 382
        } ],
        "display_url" : "pic.twitter.com\/2tQAOznZNS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741063841400782848",
    "text" : "Watch now on @Snapchat story to learn more about National Gun Violence Awareness day https:\/\/t.co\/2tQAOznZNS",
    "id" : 741063841400782848,
    "created_at" : "2016-06-10 00:26:02 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 741069654265876481,
  "created_at" : "2016-06-10 00:49:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SCOTUSnom\/status\/741066807709048834\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/HlavsW89IY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkjMTq9UoAA-u5T.jpg",
      "id_str" : "741066777023520768",
      "id" : 741066777023520768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkjMTq9UoAA-u5T.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/HlavsW89IY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741068557300158470",
  "text" : "RT @SCOTUSnom: FACT: Every single nominee got an up-or-down vote under Sen. Joe Biden. Every single time. https:\/\/t.co\/HlavsW89IY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SCOTUSnom\/status\/741066807709048834\/photo\/1",
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/HlavsW89IY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkjMTq9UoAA-u5T.jpg",
        "id_str" : "741066777023520768",
        "id" : 741066777023520768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkjMTq9UoAA-u5T.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/HlavsW89IY"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741066807709048834",
    "text" : "FACT: Every single nominee got an up-or-down vote under Sen. Joe Biden. Every single time. https:\/\/t.co\/HlavsW89IY",
    "id" : 741066807709048834,
    "created_at" : "2016-06-10 00:37:49 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 741068557300158470,
  "created_at" : "2016-06-10 00:44:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 1, 17 ],
      "id_str" : "36771809",
      "id" : 36771809
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/obdzA6RQHT",
      "expanded_url" : "http:\/\/snpy.tv\/1OffFIb",
      "display_url" : "snpy.tv\/1OffFIb"
    } ]
  },
  "geo" : { },
  "id_str" : "741054702859739137",
  "text" : ".@NatlParkService turns 100 this summer. Here's how @POTUS plans to celebrate: https:\/\/t.co\/obdzA6RQHT",
  "id" : 741054702859739137,
  "created_at" : "2016-06-09 23:49:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "indices" : [ 3, 10 ],
      "id_str" : "703302487827058688",
      "id" : 703302487827058688
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 68, 71 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/dQbwayTt84",
      "expanded_url" : "http:\/\/WH.gov\/Live",
      "display_url" : "WH.gov\/Live"
    } ]
  },
  "geo" : { },
  "id_str" : "741050637991981056",
  "text" : "RT @VPLive: This was 85 days ago. It's time to end the dysfunction. @VP talks #SCOTUS at 7:30 ET: https:\/\/t.co\/dQbwayTt84 https:\/\/t.co\/SRrC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 56, 59 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VPLive\/status\/741046182298980356\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/SRrC8HOpLy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cki5kvAWYAAfw2p.jpg",
        "id_str" : "741046179446808576",
        "id" : 741046179446808576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cki5kvAWYAAfw2p.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/SRrC8HOpLy"
      } ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 66, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/dQbwayTt84",
        "expanded_url" : "http:\/\/WH.gov\/Live",
        "display_url" : "WH.gov\/Live"
      } ]
    },
    "geo" : { },
    "id_str" : "741046182298980356",
    "text" : "This was 85 days ago. It's time to end the dysfunction. @VP talks #SCOTUS at 7:30 ET: https:\/\/t.co\/dQbwayTt84 https:\/\/t.co\/SRrC8HOpLy",
    "id" : 741046182298980356,
    "created_at" : "2016-06-09 23:15:52 +0000",
    "user" : {
      "name" : "VP Biden Live",
      "screen_name" : "VPLive",
      "protected" : false,
      "id_str" : "703302487827058688",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703967894741225474\/uRy3_xIt_normal.jpg",
      "id" : 703302487827058688,
      "verified" : true
    }
  },
  "id" : 741050637991981056,
  "created_at" : "2016-06-09 23:33:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741048904750370817",
  "text" : "RT @PressSec: Today, the House took necessary action to address Puerto Rico's fiscal crisis. Now, it's the Senate's turn. https:\/\/t.co\/L12f\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/741045443484749824\/photo\/1",
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/L12fjJokS8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cki4xxSVEAAMLIY.jpg",
        "id_str" : "741045303885762560",
        "id" : 741045303885762560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cki4xxSVEAAMLIY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 662
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 662
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 662
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 662
        } ],
        "display_url" : "pic.twitter.com\/L12fjJokS8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "741045443484749824",
    "text" : "Today, the House took necessary action to address Puerto Rico's fiscal crisis. Now, it's the Senate's turn. https:\/\/t.co\/L12fjJokS8",
    "id" : 741045443484749824,
    "created_at" : "2016-06-09 23:12:56 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 741048904750370817,
  "created_at" : "2016-06-09 23:26:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/741047501562617857\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/HA0M2QKSAY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cki3dqzUkAA3G2P.jpg",
      "id_str" : "741043859036082176",
      "id" : 741043859036082176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cki3dqzUkAA3G2P.jpg",
      "sizes" : [ {
        "h" : 372,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/HA0M2QKSAY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/CtQcTpFdkQ",
      "expanded_url" : "http:\/\/go.wh.gov\/rT1jS7",
      "display_url" : "go.wh.gov\/rT1jS7"
    } ]
  },
  "geo" : { },
  "id_str" : "741047501562617857",
  "text" : "\"I wanted to take a few minutes to show you some special things from The Champ.\" \u2014@POTUS: https:\/\/t.co\/CtQcTpFdkQ https:\/\/t.co\/HA0M2QKSAY",
  "id" : 741047501562617857,
  "created_at" : "2016-06-09 23:21:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 39, 45 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pride2016",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/6b7pNQFHQo",
      "expanded_url" : "http:\/\/snpy.tv\/1TYjApV",
      "display_url" : "snpy.tv\/1TYjApV"
    } ]
  },
  "geo" : { },
  "id_str" : "741043636591308800",
  "text" : "\"There\u2019s a lot to be proud of today.\" \u2014@POTUS celebrating our progress over the last seven years #Pride2016 https:\/\/t.co\/6b7pNQFHQo",
  "id" : 741043636591308800,
  "created_at" : "2016-06-09 23:05:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/741017365681311744\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/eszexqybSU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiewN3WgAAZOSH.jpg",
      "id_str" : "741016689895178240",
      "id" : 741016689895178240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiewN3WgAAZOSH.jpg",
      "sizes" : [ {
        "h" : 1855,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1319,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/eszexqybSU"
    } ],
    "hashtags" : [ {
      "text" : "Pride2016",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741017365681311744",
  "text" : "\"It was a powerful symbol here at home, where more Americans finally felt accepted and whole.\" \u2014@POTUS #Pride2016 https:\/\/t.co\/eszexqybSU",
  "id" : 741017365681311744,
  "created_at" : "2016-06-09 21:21:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pride2016",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741016595611279360",
  "text" : "\"If the past few years have taught us anything, it\u2019s that people who love their country can change it.\" \u2014@POTUS #Pride2016",
  "id" : 741016595611279360,
  "created_at" : "2016-06-09 21:18:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/741016543199272960\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/LWkysr8yER",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiemFtW0AA-uOu.jpg",
      "id_str" : "741016515907080192",
      "id" : 741016515907080192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiemFtW0AA-uOu.jpg",
      "sizes" : [ {
        "h" : 1342,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 786,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1835,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/LWkysr8yER"
    } ],
    "hashtags" : [ {
      "text" : "Pride2016",
      "indices" : [ 70, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741016543199272960",
  "text" : "\"When all Americans are treated equal, we are all more free.\" \u2014@POTUS #Pride2016 https:\/\/t.co\/LWkysr8yER",
  "id" : 741016543199272960,
  "created_at" : "2016-06-09 21:18:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Pride2016",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741015396191342593",
  "text" : "\"Lesbian, gay, bisexual, and transgender Americans have helped to make our union just a little more perfect.\" \u2014@POTUS #Pride2016",
  "id" : 741015396191342593,
  "created_at" : "2016-06-09 21:13:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/741011540300705792\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/rg6M0IjdNB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiZRSgUYAAR46u.jpg",
      "id_str" : "741010661006663680",
      "id" : 741010661006663680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiZRSgUYAAR46u.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/rg6M0IjdNB"
    } ],
    "hashtags" : [ {
      "text" : "Pride2016",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/vD3NIuJrGp",
      "expanded_url" : "http:\/\/go.wh.gov\/tH5oet",
      "display_url" : "go.wh.gov\/tH5oet"
    } ]
  },
  "geo" : { },
  "id_str" : "741011540300705792",
  "text" : "\"We are all more free when we are treated as equals.\" Watch @POTUS celebrate #Pride2016 \u2192 https:\/\/t.co\/vD3NIuJrGp https:\/\/t.co\/rg6M0IjdNB",
  "id" : 741011540300705792,
  "created_at" : "2016-06-09 20:58:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/741009985237221376\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/jVAiIwSlhV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkiYdwyUkAAx9ze.png",
      "id_str" : "741009775782039552",
      "id" : 741009775782039552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkiYdwyUkAAx9ze.png",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2040
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 677
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1195
      }, {
        "h" : 4167,
        "resize" : "fit",
        "w" : 4150
      } ],
      "display_url" : "pic.twitter.com\/jVAiIwSlhV"
    } ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/TzEkD5GE1w",
      "expanded_url" : "http:\/\/go.wh.gov\/wrjtC9",
      "display_url" : "go.wh.gov\/wrjtC9"
    } ]
  },
  "geo" : { },
  "id_str" : "741009985237221376",
  "text" : "How working women are behind the most dynamic labor movement of our lifetimes: https:\/\/t.co\/TzEkD5GE1w #StateOfWomen https:\/\/t.co\/jVAiIwSlhV",
  "id" : 741009985237221376,
  "created_at" : "2016-06-09 20:52:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "UnitedStateofWomen",
      "screen_name" : "USWomen2016",
      "indices" : [ 81, 93 ],
      "id_str" : "4795344505",
      "id" : 4795344505
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740960218352226304",
  "text" : "RT @vj44: Hi everyone! Welcome to my office hours. I'm ready to answer Qs on the @USWomen2016 Summit. Ask using #StateOfWomen. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UnitedStateofWomen",
        "screen_name" : "USWomen2016",
        "indices" : [ 71, 83 ],
        "id_str" : "4795344505",
        "id" : 4795344505
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/740953964955369472\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/XPt9Zj5kAz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkhlUyEVEAACScF.jpg",
        "id_str" : "740953546414166016",
        "id" : 740953546414166016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkhlUyEVEAACScF.jpg",
        "sizes" : [ {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/XPt9Zj5kAz"
      } ],
      "hashtags" : [ {
        "text" : "StateOfWomen",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740953964955369472",
    "text" : "Hi everyone! Welcome to my office hours. I'm ready to answer Qs on the @USWomen2016 Summit. Ask using #StateOfWomen. https:\/\/t.co\/XPt9Zj5kAz",
    "id" : 740953964955369472,
    "created_at" : "2016-06-09 17:09:26 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 740960218352226304,
  "created_at" : "2016-06-09 17:34:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrideMonth",
      "indices" : [ 14, 25 ]
    }, {
      "text" : "ImOUTdoors",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740938668811026433",
  "text" : "RT @Interior: #PrideMonth: we recognize LGBT history &amp; continued work for equality. Get outside &amp; show your pride w\/ #ImOUTdoors\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PrideMonth",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "ImOUTdoors",
        "indices" : [ 111, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 123, 146 ],
        "url" : "https:\/\/t.co\/7qHstjULOk",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/a7e505d4-12cb-4d98-9c9d-481f8437fe5d",
        "display_url" : "amp.twimg.com\/v\/a7e505d4-12c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740607653726982144",
    "text" : "#PrideMonth: we recognize LGBT history &amp; continued work for equality. Get outside &amp; show your pride w\/ #ImOUTdoors\nhttps:\/\/t.co\/7qHstjULOk",
    "id" : 740607653726982144,
    "created_at" : "2016-06-08 18:13:19 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 740938668811026433,
  "created_at" : "2016-06-09 16:08:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "It's On Us",
      "screen_name" : "ItsOnUs",
      "indices" : [ 42, 50 ],
      "id_str" : "2840712124",
      "id" : 2840712124
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/740934486116995072\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/gBVHi0E8iX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkhT-wQWYAEZ05T.jpg",
      "id_str" : "740934476272918529",
      "id" : 740934476272918529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkhT-wQWYAEZ05T.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 4167,
        "resize" : "fit",
        "w" : 4167
      } ],
      "display_url" : "pic.twitter.com\/gBVHi0E8iX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/4vkjsjtcIT",
      "expanded_url" : "http:\/\/go.wh.gov\/JBMEoq",
      "display_url" : "go.wh.gov\/JBMEoq"
    } ]
  },
  "geo" : { },
  "id_str" : "740934486116995072",
  "text" : "\"Sexual violence is not inevitable.\" This @ItsOnUs activist has a powerful message to share: https:\/\/t.co\/4vkjsjtcIT https:\/\/t.co\/gBVHi0E8iX",
  "id" : 740934486116995072,
  "created_at" : "2016-06-09 15:52:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 73, 81 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SCOTUSnom\/status\/740887568183525376\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/tKzF0sFNzz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkgpQ5NUUAAI7tF.jpg",
      "id_str" : "740887508913770496",
      "id" : 740887508913770496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkgpQ5NUUAAI7tF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/tKzF0sFNzz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ATGXjSYC1h",
      "expanded_url" : "http:\/\/nyti.ms\/1TXtg3N",
      "display_url" : "nyti.ms\/1TXtg3N"
    } ]
  },
  "geo" : { },
  "id_str" : "740896680661291008",
  "text" : "RT @SCOTUSnom: \"The Republicans' blockade of Judge Garland is shameful\" \u2014@nytimes. https:\/\/t.co\/ATGXjSYC1h https:\/\/t.co\/tKzF0sFNzz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 58, 66 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SCOTUSnom\/status\/740887568183525376\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/tKzF0sFNzz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkgpQ5NUUAAI7tF.jpg",
        "id_str" : "740887508913770496",
        "id" : 740887508913770496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkgpQ5NUUAAI7tF.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/tKzF0sFNzz"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/ATGXjSYC1h",
        "expanded_url" : "http:\/\/nyti.ms\/1TXtg3N",
        "display_url" : "nyti.ms\/1TXtg3N"
      } ]
    },
    "geo" : { },
    "id_str" : "740887568183525376",
    "text" : "\"The Republicans' blockade of Judge Garland is shameful\" \u2014@nytimes. https:\/\/t.co\/ATGXjSYC1h https:\/\/t.co\/tKzF0sFNzz",
    "id" : 740887568183525376,
    "created_at" : "2016-06-09 12:45:35 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 740896680661291008,
  "created_at" : "2016-06-09 13:21:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "UnitedStateofWomen",
      "screen_name" : "USWomen2016",
      "indices" : [ 44, 56 ],
      "id_str" : "4795344505",
      "id" : 4795344505
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740731700418871296",
  "text" : "RT @vj44: We're getting ready for Tuesday's @USWomen2016 Summit. Questions? Ask by tomorrow at 1pm ET with #StateOfWomen. https:\/\/t.co\/w0Wh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UnitedStateofWomen",
        "screen_name" : "USWomen2016",
        "indices" : [ 34, 46 ],
        "id_str" : "4795344505",
        "id" : 4795344505
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StateOfWomen",
        "indices" : [ 97, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/w0Wh3K9z9S",
        "expanded_url" : "http:\/\/www.theunitedstateofwomen.org",
        "display_url" : "theunitedstateofwomen.org"
      } ]
    },
    "geo" : { },
    "id_str" : "740712650447851521",
    "text" : "We're getting ready for Tuesday's @USWomen2016 Summit. Questions? Ask by tomorrow at 1pm ET with #StateOfWomen. https:\/\/t.co\/w0Wh3K9z9S",
    "id" : 740712650447851521,
    "created_at" : "2016-06-09 01:10:32 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 740731700418871296,
  "created_at" : "2016-06-09 02:26:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/740677344269066240\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/0K64f9LvO2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkdpI6tUoAEBq-9.jpg",
      "id_str" : "740676265644957697",
      "id" : 740676265644957697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkdpI6tUoAEBq-9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/0K64f9LvO2"
    } ],
    "hashtags" : [ {
      "text" : "WorldOceansDay",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/xQDERBymp3",
      "expanded_url" : "http:\/\/wh.gov\/climate",
      "display_url" : "wh.gov\/climate"
    } ]
  },
  "geo" : { },
  "id_str" : "740677344269066240",
  "text" : "Let the record show: @POTUS is protecting our oceans for future\ngenerations\u2192 https:\/\/t.co\/xQDERBymp3 #WorldOceansDay https:\/\/t.co\/0K64f9LvO2",
  "id" : 740677344269066240,
  "created_at" : "2016-06-08 22:50:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 1, 8 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Oprah Winfrey",
      "screen_name" : "Oprah",
      "indices" : [ 11, 17 ],
      "id_str" : "19397785",
      "id" : 19397785
    }, {
      "name" : "UnitedStateofWomen",
      "screen_name" : "USWomen2016",
      "indices" : [ 20, 32 ],
      "id_str" : "4795344505",
      "id" : 4795344505
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/Wb3qj3VMXG",
      "expanded_url" : "http:\/\/go.wh.gov\/K2dya4",
      "display_url" : "go.wh.gov\/K2dya4"
    } ]
  },
  "geo" : { },
  "id_str" : "740673142763466752",
  "text" : ".@FLOTUS \u2713\n@Oprah \u2713\n@USWomen2016 \u2713\nAsk your question about the next generation of trailblazers using #StateOfWomen:  https:\/\/t.co\/Wb3qj3VMXG",
  "id" : 740673142763466752,
  "created_at" : "2016-06-08 22:33:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "indices" : [ 3, 8 ],
      "id_str" : "3030922321",
      "id" : 3030922321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/9T2qwU1isA",
      "expanded_url" : "https:\/\/twitter.com\/ProductHunt\/status\/738749111877439490",
      "display_url" : "twitter.com\/ProductHunt\/st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740661229627277312",
  "text" : "RT @DJ44: Hope you'll join us tomorrow! 10am Pacific\/ 1pm Eastern https:\/\/t.co\/9T2qwU1isA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/9T2qwU1isA",
        "expanded_url" : "https:\/\/twitter.com\/ProductHunt\/status\/738749111877439490",
        "display_url" : "twitter.com\/ProductHunt\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740629215817539585",
    "text" : "Hope you'll join us tomorrow! 10am Pacific\/ 1pm Eastern https:\/\/t.co\/9T2qwU1isA",
    "id" : 740629215817539585,
    "created_at" : "2016-06-08 19:38:59 +0000",
    "user" : {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "protected" : false,
      "id_str" : "3030922321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570697565977313280\/aoCw1bC5_normal.jpeg",
      "id" : 3030922321,
      "verified" : true
    }
  },
  "id" : 740661229627277312,
  "created_at" : "2016-06-08 21:46:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/740625174777716736\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/TjzZJpKbj6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ckc6B-5XIAAr0Tu.jpg",
      "id_str" : "740624469463605248",
      "id" : 740624469463605248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ckc6B-5XIAAr0Tu.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/TjzZJpKbj6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/uigYcraydQ",
      "expanded_url" : "http:\/\/go.wh.gov\/TxYmQW",
      "display_url" : "go.wh.gov\/TxYmQW"
    } ]
  },
  "geo" : { },
  "id_str" : "740625174777716736",
  "text" : "Today @POTUS took action to ensure Americans' financial futures are protected: https:\/\/t.co\/uigYcraydQ https:\/\/t.co\/TjzZJpKbj6",
  "id" : 740625174777716736,
  "created_at" : "2016-06-08 19:22:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740616691890192384",
  "text" : "RT @LaborSec: With today's veto, @POTUS affirms that \u201Cputting customers\u2019 best interests first\u201D is more than a Wall Street marketing gimmick\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 19, 25 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "740614273307574272",
    "text" : "With today's veto, @POTUS affirms that \u201Cputting customers\u2019 best interests first\u201D is more than a Wall Street marketing gimmick, it\u2019s the law.",
    "id" : 740614273307574272,
    "created_at" : "2016-06-08 18:39:37 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 740616691890192384,
  "created_at" : "2016-06-08 18:49:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/740544683143618560\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/wk78GSPWG9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkbxZubUUAAq41X.jpg",
      "id_str" : "740544613010657280",
      "id" : 740544613010657280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkbxZubUUAAq41X.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1124,
        "resize" : "fit",
        "w" : 1124
      }, {
        "h" : 1124,
        "resize" : "fit",
        "w" : 1124
      }, {
        "h" : 1124,
        "resize" : "fit",
        "w" : 1124
      } ],
      "display_url" : "pic.twitter.com\/wk78GSPWG9"
    } ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/7V6RG6FG12",
      "expanded_url" : "http:\/\/go.wh.gov\/QvKZnb",
      "display_url" : "go.wh.gov\/QvKZnb"
    } ]
  },
  "geo" : { },
  "id_str" : "740544683143618560",
  "text" : "Reshma Saujani is on a mission to get more girls coding\u2014what it means for the #StateOfWomen: https:\/\/t.co\/7V6RG6FG12 https:\/\/t.co\/wk78GSPWG9",
  "id" : 740544683143618560,
  "created_at" : "2016-06-08 14:03:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/740330453987659777\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/bK5V1zC44W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkYufcpXAAAr1L0.jpg",
      "id_str" : "740330306549514240",
      "id" : 740330306549514240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkYufcpXAAAr1L0.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/bK5V1zC44W"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/cocE42J7TU",
      "expanded_url" : "http:\/\/go.wh.gov\/vTZR5r",
      "display_url" : "go.wh.gov\/vTZR5r"
    } ]
  },
  "geo" : { },
  "id_str" : "740330453987659777",
  "text" : "Here's how we're working with India on issues from climate change to economic growth: https:\/\/t.co\/cocE42J7TU https:\/\/t.co\/bK5V1zC44W",
  "id" : 740330453987659777,
  "created_at" : "2016-06-07 23:51:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/740312134417022976\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/qOgnmO8yGT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkYd1GUWgAAEyzM.jpg",
      "id_str" : "740311986815270912",
      "id" : 740311986815270912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkYd1GUWgAAEyzM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/qOgnmO8yGT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740312134417022976",
  "text" : "\"A life that proves those who love their country can change it. S\u00ED se puede.\" \u2014@POTUS on Helen Chavez: https:\/\/t.co\/qOgnmO8yGT",
  "id" : 740312134417022976,
  "created_at" : "2016-06-07 22:39:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eva Roca",
      "screen_name" : "EvaRoca",
      "indices" : [ 3, 11 ],
      "id_str" : "25330036",
      "id" : 25330036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/emAn92n1FX",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/06\/03\/private-sector-stepping-combat-zika-virus-congress-should-too",
      "display_url" : "whitehouse.gov\/blog\/2016\/06\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740295213239787520",
  "text" : "RT @EvaRoca: Glad at least someone is doing something about Zika. Now how about Congress steps up? https:\/\/t.co\/emAn92n1FX https:\/\/t.co\/I6K\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EvaRoca\/status\/740272833201344512\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/I6KBsPoSfk",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CkX6Dk6WkAABNcN.jpg",
        "id_str" : "740272653127290880",
        "id" : 740272653127290880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CkX6Dk6WkAABNcN.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/I6KBsPoSfk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/emAn92n1FX",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/06\/03\/private-sector-stepping-combat-zika-virus-congress-should-too",
        "display_url" : "whitehouse.gov\/blog\/2016\/06\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740272833201344512",
    "text" : "Glad at least someone is doing something about Zika. Now how about Congress steps up? https:\/\/t.co\/emAn92n1FX https:\/\/t.co\/I6KBsPoSfk",
    "id" : 740272833201344512,
    "created_at" : "2016-06-07 20:02:51 +0000",
    "user" : {
      "name" : "Eva Roca",
      "screen_name" : "EvaRoca",
      "protected" : false,
      "id_str" : "25330036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791378184663105536\/9tMUeDWm_normal.jpg",
      "id" : 25330036,
      "verified" : false
    }
  },
  "id" : 740295213239787520,
  "created_at" : "2016-06-07 21:31:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Andr\u00E9s",
      "screen_name" : "chefjoseandres",
      "indices" : [ 3, 18 ],
      "id_str" : "73206956",
      "id" : 73206956
    }, {
      "name" : "Clean Cookstoves",
      "screen_name" : "cookstoves",
      "indices" : [ 101, 112 ],
      "id_str" : "39516682",
      "id" : 39516682
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 115, 126 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740291090176036864",
  "text" : "RT @chefjoseandres: Cooking unites us all, and together we can accomplish so much by providing clean @cookstoves.  @WhiteHouse https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Clean Cookstoves",
        "screen_name" : "cookstoves",
        "indices" : [ 81, 92 ],
        "id_str" : "39516682",
        "id" : 39516682
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 95, 106 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/p4UHPQNYC0",
        "expanded_url" : "http:\/\/bit.ly\/25KAkIz",
        "display_url" : "bit.ly\/25KAkIz"
      } ]
    },
    "geo" : { },
    "id_str" : "740274684172722176",
    "text" : "Cooking unites us all, and together we can accomplish so much by providing clean @cookstoves.  @WhiteHouse https:\/\/t.co\/p4UHPQNYC0",
    "id" : 740274684172722176,
    "created_at" : "2016-06-07 20:10:13 +0000",
    "user" : {
      "name" : "Jos\u00E9 Andr\u00E9s",
      "screen_name" : "chefjoseandres",
      "protected" : false,
      "id_str" : "73206956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468467014772600832\/vauGQ8wb_normal.jpeg",
      "id" : 73206956,
      "verified" : true
    }
  },
  "id" : 740291090176036864,
  "created_at" : "2016-06-07 21:15:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "indices" : [ 13, 24 ],
      "id_str" : "9109712",
      "id" : 9109712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/jEOCgttXx2",
      "expanded_url" : "http:\/\/wh.gov\/filmfest",
      "display_url" : "wh.gov\/filmfest"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/YsTyYqCODK",
      "expanded_url" : "http:\/\/snpy.tv\/1VKDw4b",
      "display_url" : "snpy.tv\/1VKDw4b"
    } ]
  },
  "in_reply_to_status_id_str" : "740262513808449536",
  "geo" : { },
  "id_str" : "740276225462112256",
  "in_reply_to_user_id" : 30313925,
  "text" : "Students and @PeaceCorps volunteers: Your film could screen at the White House. Apply today: https:\/\/t.co\/jEOCgttXx2 https:\/\/t.co\/YsTyYqCODK",
  "id" : 740276225462112256,
  "in_reply_to_status_id" : 740262513808449536,
  "created_at" : "2016-06-07 20:16:20 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 84, 91 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/YsTyYqCODK",
      "expanded_url" : "http:\/\/snpy.tv\/1VKDw4b",
      "display_url" : "snpy.tv\/1VKDw4b"
    } ]
  },
  "geo" : { },
  "id_str" : "740262513808449536",
  "text" : "\"This is your chance to make a difference in the lives of girls around the world.\" \u2014@FLOTUS on the #WHFilmFest: https:\/\/t.co\/YsTyYqCODK",
  "id" : 740262513808449536,
  "created_at" : "2016-06-07 19:21:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 89, 102 ],
      "id_str" : "426909329",
      "id" : 426909329
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/MfAEUq3s7d",
      "expanded_url" : "http:\/\/go.wh.gov\/PoqDoL",
      "display_url" : "go.wh.gov\/PoqDoL"
    } ]
  },
  "geo" : { },
  "id_str" : "740221661606076416",
  "text" : "You're by a lake. Someone's drowning. You can save that person, but your hands are tied. @DrFriedenCDC on #Zika: https:\/\/t.co\/MfAEUq3s7d",
  "id" : 740221661606076416,
  "created_at" : "2016-06-07 16:39:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diane Guerrero",
      "screen_name" : "dianeguerrero__",
      "indices" : [ 3, 19 ],
      "id_str" : "1635077976",
      "id" : 1635077976
    }, {
      "name" : "StandStrongerUS",
      "screen_name" : "StandStrongerUS",
      "indices" : [ 81, 97 ],
      "id_str" : "3547131737",
      "id" : 3547131737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/LxAM2htelv",
      "expanded_url" : "http:\/\/CommittoCitizenship.org",
      "display_url" : "CommittoCitizenship.org"
    }, {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/i6hL5cQDbU",
      "expanded_url" : "https:\/\/youtu.be\/uEP66aEY_VU",
      "display_url" : "youtu.be\/uEP66aEY_VU"
    } ]
  },
  "geo" : { },
  "id_str" : "740207253853110273",
  "text" : "RT @dianeguerrero__: Please make the commitment today at https:\/\/t.co\/LxAM2htelv @StandStrongerUS \nhttps:\/\/t.co\/i6hL5cQDbU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "StandStrongerUS",
        "screen_name" : "StandStrongerUS",
        "indices" : [ 60, 76 ],
        "id_str" : "3547131737",
        "id" : 3547131737
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/LxAM2htelv",
        "expanded_url" : "http:\/\/CommittoCitizenship.org",
        "display_url" : "CommittoCitizenship.org"
      }, {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/i6hL5cQDbU",
        "expanded_url" : "https:\/\/youtu.be\/uEP66aEY_VU",
        "display_url" : "youtu.be\/uEP66aEY_VU"
      } ]
    },
    "geo" : { },
    "id_str" : "740202903101538304",
    "text" : "Please make the commitment today at https:\/\/t.co\/LxAM2htelv @StandStrongerUS \nhttps:\/\/t.co\/i6hL5cQDbU",
    "id" : 740202903101538304,
    "created_at" : "2016-06-07 15:24:59 +0000",
    "user" : {
      "name" : "Diane Guerrero",
      "screen_name" : "dianeguerrero__",
      "protected" : false,
      "id_str" : "1635077976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768796654048841728\/do9LsylK_normal.jpg",
      "id" : 1635077976,
      "verified" : true
    }
  },
  "id" : 740207253853110273,
  "created_at" : "2016-06-07 15:42:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/EcjNufDGmf",
      "expanded_url" : "http:\/\/www.vox.com\/2016\/6\/5\/11861202\/toy-like-me-prosthetic-leg-girl-cries",
      "display_url" : "vox.com\/2016\/6\/5\/11861\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "740200600877424641",
  "text" : "RT @vj44: Emma's joy when seeing a doll w\/legs like hers is exactly why we need diverse toys! https:\/\/t.co\/EcjNufDGmf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/EcjNufDGmf",
        "expanded_url" : "http:\/\/www.vox.com\/2016\/6\/5\/11861202\/toy-like-me-prosthetic-leg-girl-cries",
        "display_url" : "vox.com\/2016\/6\/5\/11861\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "740172158475730945",
    "text" : "Emma's joy when seeing a doll w\/legs like hers is exactly why we need diverse toys! https:\/\/t.co\/EcjNufDGmf",
    "id" : 740172158475730945,
    "created_at" : "2016-06-07 13:22:48 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 740200600877424641,
  "created_at" : "2016-06-07 15:15:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 53, 59 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/2Hwmz3M1uC",
      "expanded_url" : "http:\/\/snpy.tv\/1VGAQ7G",
      "display_url" : "snpy.tv\/1VGAQ7G"
    } ]
  },
  "geo" : { },
  "id_str" : "739985995081252864",
  "text" : "\u201CSo how come you look so good? What\u2019s your secret?\u201D \u2014@POTUS meeting 108-year-old Lester Townsend. Watch: https:\/\/t.co\/2Hwmz3M1uC",
  "id" : 739985995081252864,
  "created_at" : "2016-06-07 01:03:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/739967654656540672\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/5ngEgEcq7H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkTZkvGVAAEreQC.jpg",
      "id_str" : "739955463937130497",
      "id" : 739955463937130497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkTZkvGVAAEreQC.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5ngEgEcq7H"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/pUjd4akszO",
      "expanded_url" : "http:\/\/go.wh.gov\/YogaNX",
      "display_url" : "go.wh.gov\/YogaNX"
    } ]
  },
  "geo" : { },
  "id_str" : "739967654656540672",
  "text" : "See how we're partnering with local communities across the U.S. to help Americans succeed \u2192 https:\/\/t.co\/pUjd4akszO https:\/\/t.co\/5ngEgEcq7H",
  "id" : 739967654656540672,
  "created_at" : "2016-06-06 23:50:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/739955263638253569\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/jNDP6FXHeh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkTZWdZVAAASz1z.jpg",
      "id_str" : "739955218666815488",
      "id" : 739955218666815488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkTZWdZVAAASz1z.jpg",
      "sizes" : [ {
        "h" : 1338,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1338,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/jNDP6FXHeh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/pUjd4a2RIg",
      "expanded_url" : "http:\/\/go.wh.gov\/YogaNX",
      "display_url" : "go.wh.gov\/YogaNX"
    } ]
  },
  "geo" : { },
  "id_str" : "739955263638253569",
  "text" : "RT if you agree: Real change starts from the ground up. @POTUS on working with communities: https:\/\/t.co\/pUjd4a2RIg https:\/\/t.co\/jNDP6FXHeh",
  "id" : 739955263638253569,
  "created_at" : "2016-06-06 23:00:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/739950808368881669\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/uiSF1PE9nu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkTVN0LWUAAaaFK.jpg",
      "id_str" : "739950672116862976",
      "id" : 739950672116862976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkTVN0LWUAAaaFK.jpg",
      "sizes" : [ {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/uiSF1PE9nu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/GIuE47taVq",
      "expanded_url" : "https:\/\/www.snapchat.com\/add\/whitehouse",
      "display_url" : "snapchat.com\/add\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "739950808368881669",
  "text" : "\"The only quarterback to lead two different teams to Super Bowl wins.\" \u2014@POTUS on Peyton: https:\/\/t.co\/GIuE47taVq https:\/\/t.co\/uiSF1PE9nu",
  "id" : 739950808368881669,
  "created_at" : "2016-06-06 22:43:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "indices" : [ 103, 111 ],
      "id_str" : "18734310",
      "id" : 18734310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/oiaNPzvupJ",
      "expanded_url" : "http:\/\/snpy.tv\/22KgpaU",
      "display_url" : "snpy.tv\/22KgpaU"
    } ]
  },
  "geo" : { },
  "id_str" : "739938884369457152",
  "text" : "\"On and off the field, these guys are champs.\" \u2014@POTUS celebrating the 2016 Super Bowl Champion Denver @Broncos: https:\/\/t.co\/oiaNPzvupJ",
  "id" : 739938884369457152,
  "created_at" : "2016-06-06 21:55:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "indices" : [ 3, 11 ],
      "id_str" : "18734310",
      "id" : 18734310
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Broncos\/status\/739920424482557958\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/RNl5o9zKBq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkS5pTNUoAAm4s8.jpg",
      "id_str" : "739920357977530368",
      "id" : 739920357977530368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkS5pTNUoAAm4s8.jpg",
      "sizes" : [ {
        "h" : 989,
        "resize" : "fit",
        "w" : 1759
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 989,
        "resize" : "fit",
        "w" : 1759
      } ],
      "display_url" : "pic.twitter.com\/RNl5o9zKBq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739920611988910080",
  "text" : "RT @Broncos: \"This is a well-deserved celebration of an extraordinary season.\" - @POTUS https:\/\/t.co\/RNl5o9zKBq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 68, 74 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Broncos\/status\/739920424482557958\/photo\/1",
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/RNl5o9zKBq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkS5pTNUoAAm4s8.jpg",
        "id_str" : "739920357977530368",
        "id" : 739920357977530368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkS5pTNUoAAm4s8.jpg",
        "sizes" : [ {
          "h" : 989,
          "resize" : "fit",
          "w" : 1759
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 989,
          "resize" : "fit",
          "w" : 1759
        } ],
        "display_url" : "pic.twitter.com\/RNl5o9zKBq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739920424482557958",
    "text" : "\"This is a well-deserved celebration of an extraordinary season.\" - @POTUS https:\/\/t.co\/RNl5o9zKBq",
    "id" : 739920424482557958,
    "created_at" : "2016-06-06 20:42:30 +0000",
    "user" : {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "protected" : false,
      "id_str" : "18734310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554750999852642304\/fpZDS_N__normal.png",
      "id" : 18734310,
      "verified" : true
    }
  },
  "id" : 739920611988910080,
  "created_at" : "2016-06-06 20:43:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "indices" : [ 95, 103 ],
      "id_str" : "18734310",
      "id" : 18734310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739917873276194816",
  "text" : "\"Holding fitness clinics.\"\n\"Mentoring young people.\"\n\"Honoring our troops.\"\n\u2014@POTUS on how the @Broncos give back to their community",
  "id" : 739917873276194816,
  "created_at" : "2016-06-06 20:32:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "indices" : [ 69, 77 ],
      "id_str" : "18734310",
      "id" : 18734310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739917718380503040",
  "text" : "RT @WHLive: \"This team is far more than a collection of players. The @Broncos are a way of life not just in Colorado but throughout the Mou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Denver Broncos",
        "screen_name" : "Broncos",
        "indices" : [ 57, 65 ],
        "id_str" : "18734310",
        "id" : 18734310
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739917676114509824",
    "text" : "\"This team is far more than a collection of players. The @Broncos are a way of life not just in Colorado but throughout the Mountain West.\"",
    "id" : 739917676114509824,
    "created_at" : "2016-06-06 20:31:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 739917718380503040,
  "created_at" : "2016-06-06 20:31:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "indices" : [ 53, 61 ],
      "id_str" : "18734310",
      "id" : 18734310
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/739916187472125953\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/1yHHV0Xap2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkS11qCUoAAI1_t.jpg",
      "id_str" : "739916172217327616",
      "id" : 739916172217327616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkS11qCUoAAI1_t.jpg",
      "sizes" : [ {
        "h" : 526,
        "resize" : "fit",
        "w" : 937
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 937
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 937
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/1yHHV0Xap2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739916187472125953",
  "text" : "\"Let\u2019s give it up for the Super Bowl Champion Denver @Broncos!\" \u2014@POTUS welcoming the Broncos to the White House https:\/\/t.co\/1yHHV0Xap2",
  "id" : 739916187472125953,
  "created_at" : "2016-06-06 20:25:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "indices" : [ 79, 87 ],
      "id_str" : "18734310",
      "id" : 18734310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/xrm2cwRkWJ",
      "expanded_url" : "http:\/\/go.wh.gov\/ah3HRc",
      "display_url" : "go.wh.gov\/ah3HRc"
    } ]
  },
  "geo" : { },
  "id_str" : "739914120628211713",
  "text" : "Watch at 4:25pm ET as @POTUS congratulates the 2016 Super Bowl Champion Denver @Broncos at the White House: https:\/\/t.co\/xrm2cwRkWJ",
  "id" : 739914120628211713,
  "created_at" : "2016-06-06 20:17:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/739837814892691459\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/abFbfKHZOT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkRukd9UYAA4lCh.jpg",
      "id_str" : "739837811591766016",
      "id" : 739837811591766016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkRukd9UYAA4lCh.jpg",
      "sizes" : [ {
        "h" : 1435,
        "resize" : "fit",
        "w" : 1484
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1435,
        "resize" : "fit",
        "w" : 1484
      }, {
        "h" : 1160,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/abFbfKHZOT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739912115922862080",
  "text" : "RT @Denis44: \"Justice delayed is justice denied.\" https:\/\/t.co\/abFbfKHZOT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Denis44\/status\/739837814892691459\/photo\/1",
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/abFbfKHZOT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkRukd9UYAA4lCh.jpg",
        "id_str" : "739837811591766016",
        "id" : 739837811591766016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkRukd9UYAA4lCh.jpg",
        "sizes" : [ {
          "h" : 1435,
          "resize" : "fit",
          "w" : 1484
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1435,
          "resize" : "fit",
          "w" : 1484
        }, {
          "h" : 1160,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 658,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/abFbfKHZOT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739837814892691459",
    "text" : "\"Justice delayed is justice denied.\" https:\/\/t.co\/abFbfKHZOT",
    "id" : 739837814892691459,
    "created_at" : "2016-06-06 15:14:15 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 739912115922862080,
  "created_at" : "2016-06-06 20:09:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 60, 73 ],
      "id_str" : "426909329",
      "id" : 426909329
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/739882679898910720\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/PwboluvDAY",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CkSXS5_UkAAdEIS.jpg",
      "id_str" : "739882589855453184",
      "id" : 739882589855453184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CkSXS5_UkAAdEIS.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PwboluvDAY"
    } ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 77, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/o6BBXImaHR",
      "expanded_url" : "http:\/\/go.wh.gov\/vgd68N",
      "display_url" : "go.wh.gov\/vgd68N"
    } ]
  },
  "geo" : { },
  "id_str" : "739882679898910720",
  "text" : "\"When it comes to fighting an epidemic, every day counts.\" \u2014@DrFriedenCDC on #Zika: https:\/\/t.co\/o6BBXImaHR https:\/\/t.co\/PwboluvDAY",
  "id" : 739882679898910720,
  "created_at" : "2016-06-06 18:12:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 84, 97 ],
      "id_str" : "426909329",
      "id" : 426909329
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Zika",
      "indices" : [ 49, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/o6BBXImaHR",
      "expanded_url" : "http:\/\/go.wh.gov\/vgd68N",
      "display_url" : "go.wh.gov\/vgd68N"
    } ]
  },
  "geo" : { },
  "id_str" : "739873934439514112",
  "text" : "\"The private sector is stepping up to combat the #Zika virus\u2014Congress should too.\" \u2014@DrFriedenCDC: https:\/\/t.co\/o6BBXImaHR",
  "id" : 739873934439514112,
  "created_at" : "2016-06-06 17:37:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CORY REMSBURG",
      "screen_name" : "RangerRemsburg",
      "indices" : [ 3, 18 ],
      "id_str" : "2587948046",
      "id" : 2587948046
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/P4Km70TGyu",
      "expanded_url" : "https:\/\/www.facebook.com\/potus\/?fref=nf",
      "display_url" : "facebook.com\/potus\/?fref=nf"
    } ]
  },
  "geo" : { },
  "id_str" : "739856732424417280",
  "text" : "RT @RangerRemsburg: Thank you @POTUS  for the honor of meeting with you in the Oval Office. \nhttps:\/\/t.co\/P4Km70TGyu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/P4Km70TGyu",
        "expanded_url" : "https:\/\/www.facebook.com\/potus\/?fref=nf",
        "display_url" : "facebook.com\/potus\/?fref=nf"
      } ]
    },
    "geo" : { },
    "id_str" : "739832542220558337",
    "text" : "Thank you @POTUS  for the honor of meeting with you in the Oval Office. \nhttps:\/\/t.co\/P4Km70TGyu",
    "id" : 739832542220558337,
    "created_at" : "2016-06-06 14:53:18 +0000",
    "user" : {
      "name" : "CORY REMSBURG",
      "screen_name" : "RangerRemsburg",
      "protected" : false,
      "id_str" : "2587948046",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481870663137775616\/7QXeMrL3_normal.jpeg",
      "id" : 2587948046,
      "verified" : false
    }
  },
  "id" : 739856732424417280,
  "created_at" : "2016-06-06 16:29:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/739853115697037314\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/lV0TyhxxPJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkR8TNBWYAEcBwf.jpg",
      "id_str" : "739852908150284289",
      "id" : 739852908150284289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkR8TNBWYAEcBwf.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 486
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 486
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 486
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 486
      } ],
      "display_url" : "pic.twitter.com\/lV0TyhxxPJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/eUoMlVHLHL",
      "expanded_url" : "http:\/\/go.wh.gov\/HGA84c",
      "display_url" : "go.wh.gov\/HGA84c"
    } ]
  },
  "geo" : { },
  "id_str" : "739853115697037314",
  "text" : "\"Of all the people I've met as President, no one has inspired me more than Cory.\" \u2014@POTUS: https:\/\/t.co\/eUoMlVHLHL https:\/\/t.co\/lV0TyhxxPJ",
  "id" : 739853115697037314,
  "created_at" : "2016-06-06 16:15:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfWomen",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/kMuWTuXTdb",
      "expanded_url" : "http:\/\/www.theunitedstateofwomen.org",
      "display_url" : "theunitedstateofwomen.org"
    } ]
  },
  "geo" : { },
  "id_str" : "739796163088506880",
  "text" : "RT @FLOTUS: Together, we are stronger. Together we can change tomorrow. Stand with us: https:\/\/t.co\/kMuWTuXTdb #StateOfWomen\nhttps:\/\/t.co\/m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StateOfWomen",
        "indices" : [ 99, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/kMuWTuXTdb",
        "expanded_url" : "http:\/\/www.theunitedstateofwomen.org",
        "display_url" : "theunitedstateofwomen.org"
      }, {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/maBuf4nT0E",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/144d35e7-9e4c-4f5e-a0f6-6e352e434d17",
        "display_url" : "amp.twimg.com\/v\/144d35e7-9e4\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739790326454312960",
    "text" : "Together, we are stronger. Together we can change tomorrow. Stand with us: https:\/\/t.co\/kMuWTuXTdb #StateOfWomen\nhttps:\/\/t.co\/maBuf4nT0E",
    "id" : 739790326454312960,
    "created_at" : "2016-06-06 12:05:33 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 739796163088506880,
  "created_at" : "2016-06-06 12:28:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/2Hwmz43CTc",
      "expanded_url" : "http:\/\/snpy.tv\/1VGAQ7G",
      "display_url" : "snpy.tv\/1VGAQ7G"
    } ]
  },
  "geo" : { },
  "id_str" : "739624621658476544",
  "text" : "\"I never thought I\u2019d live to see this.\u201D \u2014108-year-old Lester Townsend on meeting @POTUS. https:\/\/t.co\/2Hwmz43CTc",
  "id" : 739624621658476544,
  "created_at" : "2016-06-06 01:07:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/ctdVLJCons",
      "expanded_url" : "http:\/\/go.wh.gov\/LewC6U",
      "display_url" : "go.wh.gov\/LewC6U"
    } ]
  },
  "geo" : { },
  "id_str" : "739611782596206593",
  "text" : "\"Over the past seven years, we\u2019ve proven that progress is possible.\" \u2014@POTUS: https:\/\/t.co\/ctdVLJCons",
  "id" : 739611782596206593,
  "created_at" : "2016-06-06 00:16:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/739597708827234304\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/CPTEzR2INz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkOUHiPUkAAsns5.jpg",
      "id_str" : "739597620989956096",
      "id" : 739597620989956096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkOUHiPUkAAsns5.jpg",
      "sizes" : [ {
        "h" : 200,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 1334
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 1334
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/CPTEzR2INz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739597708827234304",
  "text" : "\"As Muslim Americans celebrate the holy month, I am reminded that we are one American family\" \u2014@POTUS on Ramadan https:\/\/t.co\/CPTEzR2INz",
  "id" : 739597708827234304,
  "created_at" : "2016-06-05 23:20:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ctdVLJkMYS",
      "expanded_url" : "http:\/\/go.wh.gov\/LewC6U",
      "display_url" : "go.wh.gov\/LewC6U"
    } ]
  },
  "geo" : { },
  "id_str" : "739581348424212480",
  "text" : "\u201CIf we\u2019re going to fix what needs fixing, we can\u2019t divide ourselves.\u201D \u2014@POTUS: https:\/\/t.co\/ctdVLJkMYS",
  "id" : 739581348424212480,
  "created_at" : "2016-06-05 22:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 9, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/jEOCgtcm8s",
      "expanded_url" : "http:\/\/wh.gov\/filmfest",
      "display_url" : "wh.gov\/filmfest"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/HD7xdMUEXG",
      "expanded_url" : "http:\/\/snpy.tv\/1U7gmDQ",
      "display_url" : "snpy.tv\/1U7gmDQ"
    } ]
  },
  "geo" : { },
  "id_str" : "739563995422588928",
  "text" : "The 2016 #WHFilmFest is now open for entries from students K-12. Find out how to enter \u2192 https:\/\/t.co\/jEOCgtcm8s \uD83C\uDFA5 https:\/\/t.co\/HD7xdMUEXG",
  "id" : 739563995422588928,
  "created_at" : "2016-06-05 21:06:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 3, 14 ],
      "id_str" : "44615672",
      "id" : 44615672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldEnvironmentDay",
      "indices" : [ 25, 45 ]
    }, {
      "text" : "TPP",
      "indices" : [ 56, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/86fG3PTlOl",
      "expanded_url" : "http:\/\/go.usa.gov\/czJWQ",
      "display_url" : "go.usa.gov\/czJWQ"
    } ]
  },
  "geo" : { },
  "id_str" : "739557473296744449",
  "text" : "RT @USTradeRep: Today is #WorldEnvironmentDay! Read how #TPP can help protect endangered wetlands &amp; species: https:\/\/t.co\/86fG3PTlOl https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USTradeRep\/status\/739526221642366976\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/IAbyKyEHAE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkNTD1eUkAA9rrP.jpg",
        "id_str" : "739526089177862144",
        "id" : 739526089177862144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkNTD1eUkAA9rrP.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/IAbyKyEHAE"
      } ],
      "hashtags" : [ {
        "text" : "WorldEnvironmentDay",
        "indices" : [ 9, 29 ]
      }, {
        "text" : "TPP",
        "indices" : [ 40, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/86fG3PTlOl",
        "expanded_url" : "http:\/\/go.usa.gov\/czJWQ",
        "display_url" : "go.usa.gov\/czJWQ"
      } ]
    },
    "geo" : { },
    "id_str" : "739526221642366976",
    "text" : "Today is #WorldEnvironmentDay! Read how #TPP can help protect endangered wetlands &amp; species: https:\/\/t.co\/86fG3PTlOl https:\/\/t.co\/IAbyKyEHAE",
    "id" : 739526221642366976,
    "created_at" : "2016-06-05 18:36:05 +0000",
    "user" : {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "protected" : false,
      "id_str" : "44615672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662636758509596672\/O-ShXHZB_normal.png",
      "id" : 44615672,
      "verified" : true
    }
  },
  "id" : 739557473296744449,
  "created_at" : "2016-06-05 20:40:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/ctdVLJCons",
      "expanded_url" : "http:\/\/go.wh.gov\/LewC6U",
      "display_url" : "go.wh.gov\/LewC6U"
    } ]
  },
  "geo" : { },
  "id_str" : "739549533961650176",
  "text" : "\u201CWe haven\u2019t fixed everything. Wages, while growing again, need to grow faster.\u201D \u2014@POTUS on our economy: https:\/\/t.co\/ctdVLJCons",
  "id" : 739549533961650176,
  "created_at" : "2016-06-05 20:08:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ctdVLJkMYS",
      "expanded_url" : "http:\/\/go.wh.gov\/LewC6U",
      "display_url" : "go.wh.gov\/LewC6U"
    } ]
  },
  "geo" : { },
  "id_str" : "739523982618071040",
  "text" : "\u201CWe\u2019ve cut our deficits by nearly 75 percent.\u201D \u2014@POTUS on our economic progress: https:\/\/t.co\/ctdVLJkMYS",
  "id" : 739523982618071040,
  "created_at" : "2016-06-05 18:27:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/ctdVLJkMYS",
      "expanded_url" : "http:\/\/go.wh.gov\/LewC6U",
      "display_url" : "go.wh.gov\/LewC6U"
    } ]
  },
  "geo" : { },
  "id_str" : "739510503651704832",
  "text" : "\u201CWe\u2019ve cut unemployment by more than half. Another 20 million Americans have health insurance.\u201D \u2014@POTUS: https:\/\/t.co\/ctdVLJkMYS",
  "id" : 739510503651704832,
  "created_at" : "2016-06-05 17:33:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 42, 51 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Yosemite National Pk",
      "screen_name" : "YosemiteNPS",
      "indices" : [ 108, 120 ],
      "id_str" : "18726942",
      "id" : 18726942
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldEnvironmentDay",
      "indices" : [ 20, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739502995612667906",
  "text" : "RT @Interior: Happy #WorldEnvironmentDay! @Interior works all year to protect America's special places like @YosemiteNPS https:\/\/t.co\/jCu4N\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 28, 37 ],
        "id_str" : "76348185",
        "id" : 76348185
      }, {
        "name" : "Yosemite National Pk",
        "screen_name" : "YosemiteNPS",
        "indices" : [ 94, 106 ],
        "id_str" : "18726942",
        "id" : 18726942
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/739479660795400194\/photo\/1",
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/jCu4Nhy8vB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkMo0dzXEAA7IFn.jpg",
        "id_str" : "739479645637251072",
        "id" : 739479645637251072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkMo0dzXEAA7IFn.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/jCu4Nhy8vB"
      } ],
      "hashtags" : [ {
        "text" : "WorldEnvironmentDay",
        "indices" : [ 6, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739479660795400194",
    "text" : "Happy #WorldEnvironmentDay! @Interior works all year to protect America's special places like @YosemiteNPS https:\/\/t.co\/jCu4Nhy8vB",
    "id" : 739479660795400194,
    "created_at" : "2016-06-05 15:31:04 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 739502995612667906,
  "created_at" : "2016-06-05 17:03:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/ctdVLJkMYS",
      "expanded_url" : "http:\/\/go.wh.gov\/LewC6U",
      "display_url" : "go.wh.gov\/LewC6U"
    } ]
  },
  "geo" : { },
  "id_str" : "739495607404892160",
  "text" : "\"We\u2019ve seen the first sustained manufacturing growth since the nineties.\" \u2014@POTUS on our economic progress: https:\/\/t.co\/ctdVLJkMYS",
  "id" : 739495607404892160,
  "created_at" : "2016-06-05 16:34:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/739483636827709440\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/2Ava3xdT15",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkMr-dpUUAI-0QM.jpg",
      "id_str" : "739483115928702978",
      "id" : 739483115928702978,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkMr-dpUUAI-0QM.jpg",
      "sizes" : [ {
        "h" : 368,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 881
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 881
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 881
      } ],
      "display_url" : "pic.twitter.com\/2Ava3xdT15"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739483636827709440",
  "text" : "\"Let's rededicate ourselves to ending this epidemic\" \u2014@POTUS on the 35th anniversary of HIV\/AIDS in America https:\/\/t.co\/2Ava3xdT15",
  "id" : 739483636827709440,
  "created_at" : "2016-06-05 15:46:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AIDS",
      "indices" : [ 65, 70 ]
    }, {
      "text" : "35YearsofAIDS",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/5TiSQgVkwU",
      "expanded_url" : "http:\/\/1.usa.gov\/1UkkdcU",
      "display_url" : "1.usa.gov\/1UkkdcU"
    } ]
  },
  "geo" : { },
  "id_str" : "739476063294619648",
  "text" : "RT @HHSGov: Today marks the 35th anniversary of the discovery of #AIDS. Fed leaders reflect. https:\/\/t.co\/5TiSQgVkwU #35YearsofAIDS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AIDS",
        "indices" : [ 53, 58 ]
      }, {
        "text" : "35YearsofAIDS",
        "indices" : [ 105, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/5TiSQgVkwU",
        "expanded_url" : "http:\/\/1.usa.gov\/1UkkdcU",
        "display_url" : "1.usa.gov\/1UkkdcU"
      } ]
    },
    "geo" : { },
    "id_str" : "739449198928482305",
    "text" : "Today marks the 35th anniversary of the discovery of #AIDS. Fed leaders reflect. https:\/\/t.co\/5TiSQgVkwU #35YearsofAIDS",
    "id" : 739449198928482305,
    "created_at" : "2016-06-05 13:30:01 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 739476063294619648,
  "created_at" : "2016-06-05 15:16:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SXSW",
      "screen_name" : "sxsw",
      "indices" : [ 3, 8 ],
      "id_str" : "784304",
      "id" : 784304
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HackforChange",
      "indices" : [ 85, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/iRQakGmO4I",
      "expanded_url" : "http:\/\/snpy.tv\/1RcRXH6",
      "display_url" : "snpy.tv\/1RcRXH6"
    } ]
  },
  "geo" : { },
  "id_str" : "739465734460346370",
  "text" : "At @SXSW this year, @POTUS invited the American people to put their skills to use to #HackforChange. https:\/\/t.co\/iRQakGmO4I",
  "id" : 739465734460346370,
  "created_at" : "2016-06-05 14:35:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/8ZdwCHgQkQ",
      "expanded_url" : "http:\/\/snpy.tv\/1UpluPG",
      "display_url" : "snpy.tv\/1UpluPG"
    } ]
  },
  "geo" : { },
  "id_str" : "739246783419850752",
  "text" : "Japan, Indiana, Colorado and Arlington: this week\u2019s episode of #WestWingWeek covers a lot of ground. https:\/\/t.co\/8ZdwCHgQkQ",
  "id" : 739246783419850752,
  "created_at" : "2016-06-05 00:05:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HackForChange",
      "indices" : [ 108, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739237855197696000",
  "text" : "\u201CThe most important office in a democracy is the office of citizen.\u201D \u2014@POTUS. Thanks to all volunteering to #HackForChange this weekend!",
  "id" : 739237855197696000,
  "created_at" : "2016-06-04 23:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ctdVLJkMYS",
      "expanded_url" : "http:\/\/go.wh.gov\/LewC6U",
      "display_url" : "go.wh.gov\/LewC6U"
    } ]
  },
  "geo" : { },
  "id_str" : "739225303822671872",
  "text" : "\u201CThe results are clear. America\u2019s businesses have created 14.5 million new jobs over 75 straight months.\u201D \u2014@POTUS: https:\/\/t.co\/ctdVLJkMYS",
  "id" : 739225303822671872,
  "created_at" : "2016-06-04 22:40:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/739206508139974656\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/MUchdbEuiS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkIwY_3UYAArPZN.jpg",
      "id_str" : "739206494860632064",
      "id" : 739206494860632064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkIwY_3UYAArPZN.jpg",
      "sizes" : [ {
        "h" : 586,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 931,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 931,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 931,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/MUchdbEuiS"
    } ],
    "hashtags" : [ {
      "text" : "NationalTrailsDay",
      "indices" : [ 70, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/wpVEGP2SF2",
      "expanded_url" : "http:\/\/on.doi.gov\/1sTBanR",
      "display_url" : "on.doi.gov\/1sTBanR"
    } ]
  },
  "geo" : { },
  "id_str" : "739217877455097856",
  "text" : "RT @Interior: Celebrating 9 new national trails! How are you spending #NationalTrailsDay? https:\/\/t.co\/wpVEGP2SF2 https:\/\/t.co\/MUchdbEuiS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/739206508139974656\/photo\/1",
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/MUchdbEuiS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkIwY_3UYAArPZN.jpg",
        "id_str" : "739206494860632064",
        "id" : 739206494860632064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkIwY_3UYAArPZN.jpg",
        "sizes" : [ {
          "h" : 586,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 931,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 931,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 931,
          "resize" : "fit",
          "w" : 1080
        } ],
        "display_url" : "pic.twitter.com\/MUchdbEuiS"
      } ],
      "hashtags" : [ {
        "text" : "NationalTrailsDay",
        "indices" : [ 56, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/wpVEGP2SF2",
        "expanded_url" : "http:\/\/on.doi.gov\/1sTBanR",
        "display_url" : "on.doi.gov\/1sTBanR"
      } ]
    },
    "geo" : { },
    "id_str" : "739206508139974656",
    "text" : "Celebrating 9 new national trails! How are you spending #NationalTrailsDay? https:\/\/t.co\/wpVEGP2SF2 https:\/\/t.co\/MUchdbEuiS",
    "id" : 739206508139974656,
    "created_at" : "2016-06-04 21:25:39 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 739217877455097856,
  "created_at" : "2016-06-04 22:10:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ctdVLJkMYS",
      "expanded_url" : "http:\/\/go.wh.gov\/LewC6U",
      "display_url" : "go.wh.gov\/LewC6U"
    } ]
  },
  "geo" : { },
  "id_str" : "739203841892044802",
  "text" : "\u201CIt\u2019s also because we made a series of smart decisions early in my presidency.\u201D \u2014@POTUS on our economic progress: https:\/\/t.co\/ctdVLJkMYS",
  "id" : 739203841892044802,
  "created_at" : "2016-06-04 21:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "indices" : [ 3, 9 ],
      "id_str" : "2888895350",
      "id" : 2888895350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HackforChange",
      "indices" : [ 30, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/Du10CYfmSo",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/06\/03\/open-data-and-innovation-national-day-civic-hacking-2016",
      "display_url" : "whitehouse.gov\/blog\/2016\/06\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "739202050169282560",
  "text" : "RT @USCTO: Everyone Welcome!  #HackforChange w\/ over 100 events today National-Civic-Day-of-Hacking https:\/\/t.co\/Du10CYfmSo https:\/\/t.co\/i8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USCTO\/status\/739134470482059265\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/i8vwTZRMyu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkHuwzmUoAUYTT4.jpg",
        "id_str" : "739134336117547013",
        "id" : 739134336117547013,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkHuwzmUoAUYTT4.jpg",
        "sizes" : [ {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1153
        }, {
          "h" : 2160,
          "resize" : "fit",
          "w" : 1216
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 676
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 383
        } ],
        "display_url" : "pic.twitter.com\/i8vwTZRMyu"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/USCTO\/status\/739134470482059265\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/i8vwTZRMyu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkHuyTGUgAAtT4l.jpg",
        "id_str" : "739134361753124864",
        "id" : 739134361753124864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkHuyTGUgAAtT4l.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1216,
          "resize" : "fit",
          "w" : 2160
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1153,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/i8vwTZRMyu"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/USCTO\/status\/739134470482059265\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/i8vwTZRMyu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkHuz--UUAAALH0.jpg",
        "id_str" : "739134390710587392",
        "id" : 739134390710587392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkHuz--UUAAALH0.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1153,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1216,
          "resize" : "fit",
          "w" : 2160
        } ],
        "display_url" : "pic.twitter.com\/i8vwTZRMyu"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/USCTO\/status\/739134470482059265\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/i8vwTZRMyu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkHu107UYAQoSg5.jpg",
        "id_str" : "739134422373392388",
        "id" : 739134422373392388,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkHu107UYAQoSg5.jpg",
        "sizes" : [ {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 676,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1216,
          "resize" : "fit",
          "w" : 2160
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1153,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/i8vwTZRMyu"
      } ],
      "hashtags" : [ {
        "text" : "HackforChange",
        "indices" : [ 19, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/Du10CYfmSo",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2016\/06\/03\/open-data-and-innovation-national-day-civic-hacking-2016",
        "display_url" : "whitehouse.gov\/blog\/2016\/06\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "739134470482059265",
    "text" : "Everyone Welcome!  #HackforChange w\/ over 100 events today National-Civic-Day-of-Hacking https:\/\/t.co\/Du10CYfmSo https:\/\/t.co\/i8vwTZRMyu",
    "id" : 739134470482059265,
    "created_at" : "2016-06-04 16:39:24 +0000",
    "user" : {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "protected" : false,
      "id_str" : "2888895350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/534373591228219392\/Ewzw--q6_normal.jpeg",
      "id" : 2888895350,
      "verified" : true
    }
  },
  "id" : 739202050169282560,
  "created_at" : "2016-06-04 21:07:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ctdVLJkMYS",
      "expanded_url" : "http:\/\/go.wh.gov\/LewC6U",
      "display_url" : "go.wh.gov\/LewC6U"
    } ]
  },
  "geo" : { },
  "id_str" : "739177477801529344",
  "text" : "\u201CIt\u2019s no accident. It\u2019s because people there worked hard, and sacrificed.\u201D \u2014@POTUS on Elkhart\u2019s economic recovery: https:\/\/t.co\/ctdVLJkMYS",
  "id" : 739177477801529344,
  "created_at" : "2016-06-04 19:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/xMzmv8QLdV",
      "expanded_url" : "http:\/\/go.wh.gov\/5rWToz",
      "display_url" : "go.wh.gov\/5rWToz"
    } ]
  },
  "geo" : { },
  "id_str" : "739173745256865792",
  "text" : "RT @VP: Muhammad Ali fought for the basic belief that everyone is entitled to be treated with dignity. https:\/\/t.co\/xMzmv8QLdV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/xMzmv8QLdV",
        "expanded_url" : "http:\/\/go.wh.gov\/5rWToz",
        "display_url" : "go.wh.gov\/5rWToz"
      } ]
    },
    "geo" : { },
    "id_str" : "739171357154410496",
    "text" : "Muhammad Ali fought for the basic belief that everyone is entitled to be treated with dignity. https:\/\/t.co\/xMzmv8QLdV",
    "id" : 739171357154410496,
    "created_at" : "2016-06-04 19:05:59 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 739173745256865792,
  "created_at" : "2016-06-04 19:15:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIPMuhammadAli",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/vToZqGdGLj",
      "expanded_url" : "http:\/\/go.wh.gov\/MuhammadAli",
      "display_url" : "go.wh.gov\/MuhammadAli"
    } ]
  },
  "geo" : { },
  "id_str" : "739108792802119680",
  "text" : "\"Muhammad Ali shook up the world. And the world is better for it.\" \u2014@POTUS: https:\/\/t.co\/vToZqGdGLj #RIPMuhammadAli",
  "id" : 739108792802119680,
  "created_at" : "2016-06-04 14:57:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/739095745584844800\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/z1yM3sSLH3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkHLn5EXIAA4y_2.jpg",
      "id_str" : "739095700059922432",
      "id" : 739095700059922432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkHLn5EXIAA4y_2.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 453
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      } ],
      "display_url" : "pic.twitter.com\/z1yM3sSLH3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739096978617999361",
  "text" : "RT @POTUS: He shook up the world, and the world's better for it. Rest in peace, Champ. https:\/\/t.co\/z1yM3sSLH3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/739095745584844800\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/z1yM3sSLH3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CkHLn5EXIAA4y_2.jpg",
        "id_str" : "739095700059922432",
        "id" : 739095700059922432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkHLn5EXIAA4y_2.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 453
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        } ],
        "display_url" : "pic.twitter.com\/z1yM3sSLH3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "739095745584844800",
    "text" : "He shook up the world, and the world's better for it. Rest in peace, Champ. https:\/\/t.co\/z1yM3sSLH3",
    "id" : 739095745584844800,
    "created_at" : "2016-06-04 14:05:32 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 739096978617999361,
  "created_at" : "2016-06-04 14:10:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/ctdVLJCons",
      "expanded_url" : "http:\/\/go.wh.gov\/LewC6U",
      "display_url" : "go.wh.gov\/LewC6U"
    } ]
  },
  "geo" : { },
  "id_str" : "739095830125260800",
  "text" : "\u201CThis week, I returned to Elkhart. Unemployment there has now fallen to around four percent.\u201D \u2014@POTUS: https:\/\/t.co\/ctdVLJCons",
  "id" : 739095830125260800,
  "created_at" : "2016-06-04 14:05:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ctdVLJCons",
      "expanded_url" : "http:\/\/go.wh.gov\/LewC6U",
      "display_url" : "go.wh.gov\/LewC6U"
    } ]
  },
  "geo" : { },
  "id_str" : "739079584998686721",
  "text" : "\"Elkhart, Indiana was the first town I visited as President.\" \u2014@POTUS. Watch his address on returning to Elkhart: https:\/\/t.co\/ctdVLJCons",
  "id" : 739079584998686721,
  "created_at" : "2016-06-04 13:01:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "USAFA (Official)",
      "screen_name" : "AF_Academy",
      "indices" : [ 91, 102 ],
      "id_str" : "69073724",
      "id" : 69073724
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738875498051162112\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/ZkZPWV75o0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkDsYajWYAAyR4r.jpg",
      "id_str" : "738850243077365760",
      "id" : 738850243077365760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkDsYajWYAAyR4r.jpg",
      "sizes" : [ {
        "h" : 724,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 456,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 724,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/ZkZPWV75o0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738875498051162112",
  "text" : "\"Keep strong that Long Blue Line. Stay true to the values you\u2019ve learned here.\" \u2014@POTUS to @AF_Academy 2016 grads https:\/\/t.co\/ZkZPWV75o0",
  "id" : 738875498051162112,
  "created_at" : "2016-06-03 23:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738860388373004291\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/baIax8BPuM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkDs23lXAAAW7zp.jpg",
      "id_str" : "738850766266499072",
      "id" : 738850766266499072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkDs23lXAAAW7zp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/baIax8BPuM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/eNv6u2mETH",
      "expanded_url" : "http:\/\/go.wh.gov\/clemency",
      "display_url" : "go.wh.gov\/clemency"
    } ]
  },
  "geo" : { },
  "id_str" : "738860388373004291",
  "text" : ".@POTUS has now granted clemency to 348 people\u2014more than the past 7 presidents combined. https:\/\/t.co\/eNv6u2mETH https:\/\/t.co\/baIax8BPuM",
  "id" : 738860388373004291,
  "created_at" : "2016-06-03 22:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/738850665745813504\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/P59hBHS2wM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CkDsv6UWUAAuMOh.jpg",
      "id_str" : "738850646741372928",
      "id" : 738850646741372928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CkDsv6UWUAAuMOh.jpg",
      "sizes" : [ {
        "h" : 564,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 479,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/P59hBHS2wM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/eNv6u25429",
      "expanded_url" : "http:\/\/go.wh.gov\/clemency",
      "display_url" : "go.wh.gov\/clemency"
    } ]
  },
  "geo" : { },
  "id_str" : "738850665745813504",
  "text" : "Today, @POTUS commuted the sentences of 42 people whose punishments didn't fit their crimes: https:\/\/t.co\/eNv6u25429 https:\/\/t.co\/P59hBHS2wM",
  "id" : 738850665745813504,
  "created_at" : "2016-06-03 21:51:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/am6lbJnKEO",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/c4a4d230-a7cb-4d33-967b-155e96c683ed",
      "display_url" : "amp.twimg.com\/v\/c4a4d230-a7c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "738849539671633920",
  "text" : "RT @VP: Happy birthday, Jilly. You're the love of my life, and the life of my love.\nhttps:\/\/t.co\/am6lbJnKEO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/am6lbJnKEO",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/c4a4d230-a7cb-4d33-967b-155e96c683ed",
        "display_url" : "amp.twimg.com\/v\/c4a4d230-a7c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738773870635671552",
    "text" : "Happy birthday, Jilly. You're the love of my life, and the life of my love.\nhttps:\/\/t.co\/am6lbJnKEO",
    "id" : 738773870635671552,
    "created_at" : "2016-06-03 16:46:31 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 738849539671633920,
  "created_at" : "2016-06-03 21:47:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738794998963916800",
  "text" : "RT @Denis44: POTUS asked journalists to fact check his economic record, so they did. See the results for yourself here: https:\/\/t.co\/JfJ1B9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/JfJ1B9SKpJ",
        "expanded_url" : "http:\/\/www.southbendtribune.com\/news\/local\/do-some-fact-checking-obama-said-so-we-did\/article_915e3aec-291d-5473-9b26-fd04a45bfb7a.html?mode=jqm",
        "display_url" : "southbendtribune.com\/news\/local\/do-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738722169971179520",
    "text" : "POTUS asked journalists to fact check his economic record, so they did. See the results for yourself here: https:\/\/t.co\/JfJ1B9SKpJ",
    "id" : 738722169971179520,
    "created_at" : "2016-06-03 13:21:04 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 738794998963916800,
  "created_at" : "2016-06-03 18:10:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "indices" : [ 3, 13 ],
      "id_str" : "708072909114318848",
      "id" : 708072909114318848
    }, {
      "name" : "Senate Republicans",
      "screen_name" : "SenateGOP",
      "indices" : [ 48, 58 ],
      "id_str" : "14344823",
      "id" : 14344823
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738765758465855488",
  "text" : "RT @SCOTUSnom: Ohio history teacher schools the @SenateGOP on #SCOTUS: \"I\u2019m not sure they\u2019d pass my class at this point.\" https:\/\/t.co\/BodO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senate Republicans",
        "screen_name" : "SenateGOP",
        "indices" : [ 33, 43 ],
        "id_str" : "14344823",
        "id" : 14344823
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 47, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/BodOgetBYN",
        "expanded_url" : "http:\/\/go.wh.gov\/ZdHfB2",
        "display_url" : "go.wh.gov\/ZdHfB2"
      } ]
    },
    "geo" : { },
    "id_str" : "738765455008006144",
    "text" : "Ohio history teacher schools the @SenateGOP on #SCOTUS: \"I\u2019m not sure they\u2019d pass my class at this point.\" https:\/\/t.co\/BodOgetBYN",
    "id" : 738765455008006144,
    "created_at" : "2016-06-03 16:13:04 +0000",
    "user" : {
      "name" : "SCOTUS Nomination",
      "screen_name" : "SCOTUSnom",
      "protected" : false,
      "id_str" : "708072909114318848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710053451216998400\/aFZCGgVp_normal.jpg",
      "id" : 708072909114318848,
      "verified" : true
    }
  },
  "id" : 738765758465855488,
  "created_at" : "2016-06-03 16:14:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738547246099107841\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/V6YC7v1GFR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj_SuenVAAEew2f.jpg",
      "id_str" : "738540559845883905",
      "id" : 738540559845883905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj_SuenVAAEew2f.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      } ],
      "display_url" : "pic.twitter.com\/V6YC7v1GFR"
    } ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 80, 96 ]
    }, {
      "text" : "WearOrange",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738547246099107841",
  "text" : "More than 30,000 Americans die from guns every year. Here\u2019s what we're doing to #StopGunViolence. #WearOrange https:\/\/t.co\/V6YC7v1GFR",
  "id" : 738547246099107841,
  "created_at" : "2016-06-03 01:45:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738540426651656192\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/opjTPzRk0k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj_Sl6ZUgAEclcN.jpg",
      "id_str" : "738540412684500993",
      "id" : 738540412684500993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj_Sl6ZUgAEclcN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      } ],
      "display_url" : "pic.twitter.com\/opjTPzRk0k"
    } ],
    "hashtags" : [ {
      "text" : "WearOrange",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/pfjPQiDeYK",
      "expanded_url" : "http:\/\/go.wh.gov\/SvnSmM",
      "display_url" : "go.wh.gov\/SvnSmM"
    } ]
  },
  "geo" : { },
  "id_str" : "738540426651656192",
  "text" : ".@POTUS is taking action to shape the future of gun safety technology \u2192 https:\/\/t.co\/pfjPQiDeYK #WearOrange https:\/\/t.co\/opjTPzRk0k",
  "id" : 738540426651656192,
  "created_at" : "2016-06-03 01:18:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738537320824066048\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/G8k8dQYcu5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj_PxNgVAAEG9Zt.jpg",
      "id_str" : "738537308257845249",
      "id" : 738537308257845249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj_PxNgVAAEG9Zt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/G8k8dQYcu5"
    } ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 93, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/pfjPQiDeYK",
      "expanded_url" : "http:\/\/go.wh.gov\/SvnSmM",
      "display_url" : "go.wh.gov\/SvnSmM"
    } ]
  },
  "geo" : { },
  "id_str" : "738537320824066048",
  "text" : "FACT: @POTUS is taking action to increase mental health treatment \u2192 https:\/\/t.co\/pfjPQiDeYK  #StopGunViolence https:\/\/t.co\/G8k8dQYcu5",
  "id" : 738537320824066048,
  "created_at" : "2016-06-03 01:06:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738523309713817600\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/2VSJTv4j92",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj_CzALWUAAfIhm.jpg",
      "id_str" : "738523045388767232",
      "id" : 738523045388767232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj_CzALWUAAfIhm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      } ],
      "display_url" : "pic.twitter.com\/2VSJTv4j92"
    } ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 85, 101 ]
    }, {
      "text" : "WearOrange",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738523309713817600",
  "text" : "FACT: Each year, more than 30,000 American lives are cut short by guns. It's time to #StopGunViolence. #WearOrange https:\/\/t.co\/2VSJTv4j92",
  "id" : 738523309713817600,
  "created_at" : "2016-06-03 00:10:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "USAFA (Official)",
      "screen_name" : "AF_Academy",
      "indices" : [ 95, 106 ],
      "id_str" : "69073724",
      "id" : 69073724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/MLM0DqUd2R",
      "expanded_url" : "http:\/\/snpy.tv\/1Xl6hGp",
      "display_url" : "snpy.tv\/1Xl6hGp"
    } ]
  },
  "geo" : { },
  "id_str" : "738462728755388416",
  "text" : "\"As we navigate this complex world, America cannot shirk the mantle of leadership.\" \u2014@POTUS to @AF_Academy  https:\/\/t.co\/MLM0DqUd2R",
  "id" : 738462728755388416,
  "created_at" : "2016-06-02 20:10:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/m5oH8FOv3P",
      "expanded_url" : "http:\/\/snpy.tv\/1Xl8p0K",
      "display_url" : "snpy.tv\/1Xl8p0K"
    } ]
  },
  "geo" : { },
  "id_str" : "738456629692096512",
  "text" : "\"We\u2019re stronger when our gay and lesbian cadets and troops can serve their country...without hiding who they love.\" https:\/\/t.co\/m5oH8FOv3P",
  "id" : 738456629692096512,
  "created_at" : "2016-06-02 19:45:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/GaaofsONv5",
      "expanded_url" : "http:\/\/snpy.tv\/1Vzvg6S",
      "display_url" : "snpy.tv\/1Vzvg6S"
    } ]
  },
  "geo" : { },
  "id_str" : "738451283905019904",
  "text" : ".@POTUS on why leading America\u2019s military has been the highest honor of his life: https:\/\/t.co\/GaaofsONv5",
  "id" : 738451283905019904,
  "created_at" : "2016-06-02 19:24:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "classof2016",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738438801102503936",
  "text" : "RT @PressSec: POTUS delivers an inspiring commencement address to the soon-to-be 2nd lieutenants that inspire us. #classof2016 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/738433435748814850\/photo\/1",
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/8CUhgncjNb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj9xSA9VAAIRmyA.jpg",
        "id_str" : "738433418220863490",
        "id" : 738433418220863490,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj9xSA9VAAIRmyA.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/8CUhgncjNb"
      } ],
      "hashtags" : [ {
        "text" : "classof2016",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738433435748814850",
    "text" : "POTUS delivers an inspiring commencement address to the soon-to-be 2nd lieutenants that inspire us. #classof2016 https:\/\/t.co\/8CUhgncjNb",
    "id" : 738433435748814850,
    "created_at" : "2016-06-02 18:13:45 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 738438801102503936,
  "created_at" : "2016-06-02 18:35:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "USAFA (Official)",
      "screen_name" : "AF_Academy",
      "indices" : [ 100, 111 ],
      "id_str" : "69073724",
      "id" : 69073724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738413703180214272",
  "text" : "\"We\u2019re stronger because of it.\" \u2014@POTUS on the 40th anniversary of the first female cadets arriving @AF_Academy",
  "id" : 738413703180214272,
  "created_at" : "2016-06-02 16:55:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738413307124719617",
  "text" : "\"We\u2019re stronger when our gay and lesbian cadets and troops can serve the country they love without hiding who they love.\" \u2014@POTUS",
  "id" : 738413307124719617,
  "created_at" : "2016-06-02 16:53:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "USAFA (Official)",
      "screen_name" : "AF_Academy",
      "indices" : [ 111, 122 ],
      "id_str" : "69073724",
      "id" : 69073724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738411327253843968",
  "text" : "\"If you target Americans, we will find you and justice will be done and we will defend our nation.\" \u2014@POTUS at @AF_Academy",
  "id" : 738411327253843968,
  "created_at" : "2016-06-02 16:45:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "USAFA (Official)",
      "screen_name" : "AF_Academy",
      "indices" : [ 119, 130 ],
      "id_str" : "69073724",
      "id" : 69073724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738409525464731648",
  "text" : "\u201CIt\u2019s time for the Senate to do its job and help us advance American leadership, rather than undermine it.\u201D \u2014@POTUS at @AF_Academy",
  "id" : 738409525464731648,
  "created_at" : "2016-06-02 16:38:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "USAFA (Official)",
      "screen_name" : "AF_Academy",
      "indices" : [ 97, 108 ],
      "id_str" : "69073724",
      "id" : 69073724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/sdslZZ2M74",
      "expanded_url" : "http:\/\/go.wh.gov\/gMDN1z",
      "display_url" : "go.wh.gov\/gMDN1z"
    } ]
  },
  "geo" : { },
  "id_str" : "738407860464406529",
  "text" : "\u201CIt is undeniable\u2014our military is the most capable fighting force on the planet\u201D\u2014@POTUS speaking @AF_Academy: https:\/\/t.co\/sdslZZ2M74",
  "id" : 738407860464406529,
  "created_at" : "2016-06-02 16:32:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "USAFA (Official)",
      "screen_name" : "AF_Academy",
      "indices" : [ 107, 118 ],
      "id_str" : "69073724",
      "id" : 69073724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738407408083537920",
  "text" : "RT @WHLive: \u201CRemember what you learned at this Academy\u2014the importance of evidence and facts.\u201D   \u2014@POTUS to @AF_Academy Class of 2016",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 85, 91 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "USAFA (Official)",
        "screen_name" : "AF_Academy",
        "indices" : [ 95, 106 ],
        "id_str" : "69073724",
        "id" : 69073724
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738407298259943424",
    "text" : "\u201CRemember what you learned at this Academy\u2014the importance of evidence and facts.\u201D   \u2014@POTUS to @AF_Academy Class of 2016",
    "id" : 738407298259943424,
    "created_at" : "2016-06-02 16:29:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 738407408083537920,
  "created_at" : "2016-06-02 16:30:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738406969132908545",
  "text" : "\u201CIt has been the highest honor of my life to lead the greatest military in the history of the world. It inspires me every day.\" \u2014@POTUS",
  "id" : 738406969132908545,
  "created_at" : "2016-06-02 16:28:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 128, 134 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738406673484779521",
  "text" : "\u201CWe congratulate our newest Air Force officers. On behalf of the American people, I thank you for choosing a life of service.\u201D \u2014@POTUS",
  "id" : 738406673484779521,
  "created_at" : "2016-06-02 16:27:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "USAFA (Official)",
      "screen_name" : "AF_Academy",
      "indices" : [ 36, 47 ],
      "id_str" : "69073724",
      "id" : 69073724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/sdslZZ2M74",
      "expanded_url" : "http:\/\/go.wh.gov\/gMDN1z",
      "display_url" : "go.wh.gov\/gMDN1z"
    } ]
  },
  "geo" : { },
  "id_str" : "738398373246607360",
  "text" : "Happening now: @POTUS addresses the @AF_Academy Class of 2016. Watch his last commencement address as President \u2192 https:\/\/t.co\/sdslZZ2M74",
  "id" : 738398373246607360,
  "created_at" : "2016-06-02 15:54:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738388940726636544",
  "text" : "RT @POTUS: We cannot accept our level of gun violence as the new normal. We must take action to prevent this from happening again &amp; again.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WearOrange",
        "indices" : [ 132, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738388734207512578",
    "text" : "We cannot accept our level of gun violence as the new normal. We must take action to prevent this from happening again &amp; again. #WearOrange",
    "id" : 738388734207512578,
    "created_at" : "2016-06-02 15:16:07 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 738388940726636544,
  "created_at" : "2016-06-02 15:16:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 78, 84 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738383973718458369\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/M3Wuzt6wrV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj9DBymUYAA_OAH.jpg",
      "id_str" : "738382561953472512",
      "id" : 738382561953472512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj9DBymUYAA_OAH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/M3Wuzt6wrV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738383973718458369",
  "text" : "Solicitor General Don Verrilli won landmark cases that moved America forward. @POTUS on his service: https:\/\/t.co\/M3Wuzt6wrV",
  "id" : 738383973718458369,
  "created_at" : "2016-06-02 14:57:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Shambaugh",
      "screen_name" : "CEAJay",
      "indices" : [ 3, 10 ],
      "id_str" : "727888567280779264",
      "id" : 727888567280779264
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "indices" : [ 102, 111 ],
      "id_str" : "1979039203",
      "id" : 1979039203
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 112, 117 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Elkhart",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738373648348647424",
  "text" : "RT @CEAJay: Yesterday @POTUS traveled to #Elkhart to discuss US econ. Questions about his speech? Ask @CEASandy @VJ44 &amp; I at 1pm https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Sandy Black",
        "screen_name" : "CEASandy",
        "indices" : [ 90, 99 ],
        "id_str" : "1979039203",
        "id" : 1979039203
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 100, 105 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Elkhart",
        "indices" : [ 29, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/SH2IzjfXWi",
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/738168002705645569",
        "display_url" : "twitter.com\/vj44\/status\/73\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738371220362559488",
    "text" : "Yesterday @POTUS traveled to #Elkhart to discuss US econ. Questions about his speech? Ask @CEASandy @VJ44 &amp; I at 1pm https:\/\/t.co\/SH2IzjfXWi",
    "id" : 738371220362559488,
    "created_at" : "2016-06-02 14:06:31 +0000",
    "user" : {
      "name" : "Jay Shambaugh",
      "screen_name" : "CEAJay",
      "protected" : false,
      "id_str" : "727888567280779264",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730062181920743424\/Cfoqp3cQ_normal.jpg",
      "id" : 727888567280779264,
      "verified" : false
    }
  },
  "id" : 738373648348647424,
  "created_at" : "2016-06-02 14:16:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Welcome.us",
      "screen_name" : "Welcome_us",
      "indices" : [ 3, 14 ],
      "id_str" : "2484632473",
      "id" : 2484632473
    }, {
      "name" : "Lupita Nyong'o",
      "screen_name" : "Lupita_Nyongo",
      "indices" : [ 76, 90 ],
      "id_str" : "2155649270",
      "id" : 2155649270
    }, {
      "name" : "Miguel",
      "screen_name" : "Miguel",
      "indices" : [ 92, 99 ],
      "id_str" : "63677189",
      "id" : 63677189
    }, {
      "name" : "Rosario Dawson",
      "screen_name" : "rosariodawson",
      "indices" : [ 101, 115 ],
      "id_str" : "82939583",
      "id" : 82939583
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IAmAnImmigrant",
      "indices" : [ 23, 38 ]
    }, {
      "text" : "ImmigrantHeritageMonth",
      "indices" : [ 49, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738189444273065985",
  "text" : "RT @Welcome_us: Watch: #IAmAnImmigrant kicks off #ImmigrantHeritageMonth w\/ @Lupita_Nyongo, @Miguel, @RosarioDawson &amp; many more\nhttps:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lupita Nyong'o",
        "screen_name" : "Lupita_Nyongo",
        "indices" : [ 60, 74 ],
        "id_str" : "2155649270",
        "id" : 2155649270
      }, {
        "name" : "Miguel",
        "screen_name" : "Miguel",
        "indices" : [ 76, 83 ],
        "id_str" : "63677189",
        "id" : 63677189
      }, {
        "name" : "Rosario Dawson",
        "screen_name" : "rosariodawson",
        "indices" : [ 85, 99 ],
        "id_str" : "82939583",
        "id" : 82939583
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IAmAnImmigrant",
        "indices" : [ 7, 22 ]
      }, {
        "text" : "ImmigrantHeritageMonth",
        "indices" : [ 33, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/z8CvNOO8tj",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/ab969db2-83f5-463e-b92b-178295a21bfc",
        "display_url" : "amp.twimg.com\/v\/ab969db2-83f\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "738007183908995072",
    "text" : "Watch: #IAmAnImmigrant kicks off #ImmigrantHeritageMonth w\/ @Lupita_Nyongo, @Miguel, @RosarioDawson &amp; many more\nhttps:\/\/t.co\/z8CvNOO8tj",
    "id" : 738007183908995072,
    "created_at" : "2016-06-01 13:59:58 +0000",
    "user" : {
      "name" : "Welcome.us",
      "screen_name" : "Welcome_us",
      "protected" : false,
      "id_str" : "2484632473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776166827143692289\/UwHNo41j_normal.jpg",
      "id" : 2484632473,
      "verified" : false
    }
  },
  "id" : 738189444273065985,
  "created_at" : "2016-06-02 02:04:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Jay Shambaugh",
      "screen_name" : "CEAJay",
      "indices" : [ 93, 100 ],
      "id_str" : "727888567280779264",
      "id" : 727888567280779264
    }, {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "indices" : [ 102, 111 ],
      "id_str" : "1979039203",
      "id" : 1979039203
    }, {
      "name" : "Pete Buttigieg",
      "screen_name" : "PeteButtigieg",
      "indices" : [ 119, 133 ],
      "id_str" : "226222147",
      "id" : 226222147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738171228402290688",
  "text" : "RT @vj44: Questions about @POTUS's trip back to Elkhart? I'll answer tomorrow at 1pm ET with @CEAJay, @CEASandy, &amp; @PeteButtigieg. Ask usin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 16, 22 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Jay Shambaugh",
        "screen_name" : "CEAJay",
        "indices" : [ 83, 90 ],
        "id_str" : "727888567280779264",
        "id" : 727888567280779264
      }, {
        "name" : "Sandy Black",
        "screen_name" : "CEASandy",
        "indices" : [ 92, 101 ],
        "id_str" : "1979039203",
        "id" : 1979039203
      }, {
        "name" : "Pete Buttigieg",
        "screen_name" : "PeteButtigieg",
        "indices" : [ 109, 123 ],
        "id_str" : "226222147",
        "id" : 226222147
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Elkhart",
        "indices" : [ 135, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738168002705645569",
    "text" : "Questions about @POTUS's trip back to Elkhart? I'll answer tomorrow at 1pm ET with @CEAJay, @CEASandy, &amp; @PeteButtigieg. Ask using #Elkhart",
    "id" : 738168002705645569,
    "created_at" : "2016-06-02 00:39:01 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 738171228402290688,
  "created_at" : "2016-06-02 00:51:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "PBS NewsHour",
      "screen_name" : "NewsHour",
      "indices" : [ 33, 42 ],
      "id_str" : "14437914",
      "id" : 14437914
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "gwen ifill",
      "screen_name" : "gwenifill",
      "indices" : [ 93, 103 ],
      "id_str" : "164412502",
      "id" : 164412502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738160771423571968",
  "text" : "RT @WHLive: Happening now on PBS @NewsHour: @POTUS sits down for a town hall discussion with @GwenIfill in Elkhart, Indiana. #POTUSonNewsHo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PBS NewsHour",
        "screen_name" : "NewsHour",
        "indices" : [ 21, 30 ],
        "id_str" : "14437914",
        "id" : 14437914
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 32, 38 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "gwen ifill",
        "screen_name" : "gwenifill",
        "indices" : [ 81, 91 ],
        "id_str" : "164412502",
        "id" : 164412502
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUSonNewsHour",
        "indices" : [ 113, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738160645686710276",
    "text" : "Happening now on PBS @NewsHour: @POTUS sits down for a town hall discussion with @GwenIfill in Elkhart, Indiana. #POTUSonNewsHour",
    "id" : 738160645686710276,
    "created_at" : "2016-06-02 00:09:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 738160771423571968,
  "created_at" : "2016-06-02 00:10:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PBS NewsHour",
      "screen_name" : "NewsHour",
      "indices" : [ 3, 12 ],
      "id_str" : "14437914",
      "id" : 14437914
    }, {
      "name" : "gwen ifill",
      "screen_name" : "gwenifill",
      "indices" : [ 26, 36 ],
      "id_str" : "164412502",
      "id" : 164412502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSonNewsHour",
      "indices" : [ 108, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738152607005315073",
  "text" : "RT @NewsHour: Join us for @gwenifill's exclusive interview of Pres. Obama and town hall in Elkhart, Indiana #POTUSonNewsHour https:\/\/t.co\/V\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "gwen ifill",
        "screen_name" : "gwenifill",
        "indices" : [ 12, 22 ],
        "id_str" : "164412502",
        "id" : 164412502
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUSonNewsHour",
        "indices" : [ 94, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/VgCmeWF5aL",
        "expanded_url" : "http:\/\/snpy.tv\/1VxB54Q",
        "display_url" : "snpy.tv\/1VxB54Q"
      } ]
    },
    "geo" : { },
    "id_str" : "738143093493403650",
    "text" : "Join us for @gwenifill's exclusive interview of Pres. Obama and town hall in Elkhart, Indiana #POTUSonNewsHour https:\/\/t.co\/VgCmeWF5aL",
    "id" : 738143093493403650,
    "created_at" : "2016-06-01 23:00:02 +0000",
    "user" : {
      "name" : "PBS NewsHour",
      "screen_name" : "NewsHour",
      "protected" : false,
      "id_str" : "14437914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793805679786090496\/gqA4z5BM_normal.jpg",
      "id" : 14437914,
      "verified" : true
    }
  },
  "id" : 738152607005315073,
  "created_at" : "2016-06-01 23:37:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/lyGJ286F7P",
      "expanded_url" : "http:\/\/snpy.tv\/1TKjTV9",
      "display_url" : "snpy.tv\/1TKjTV9"
    } ]
  },
  "geo" : { },
  "id_str" : "738150675612241922",
  "text" : "\"We all love this country. We all care about our children's futures. That's what makes us great.\" \u2014@POTUS in Elkhart https:\/\/t.co\/lyGJ286F7P",
  "id" : 738150675612241922,
  "created_at" : "2016-06-01 23:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "indices" : [ 3, 11 ],
      "id_str" : "3093573484",
      "id" : 3093573484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738138574797688832",
  "text" : "RT @Denis44: From POTUS\u2019s speech in Elkhart today. He\u2019s 100% right: we need Congress\u2019s help to fight Zika &amp; opioid epidemic: https:\/\/t.co\/s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/svyIG83BAU",
        "expanded_url" : "http:\/\/snpy.tv\/1TYmHlc",
        "display_url" : "snpy.tv\/1TYmHlc"
      } ]
    },
    "geo" : { },
    "id_str" : "738137292078878720",
    "text" : "From POTUS\u2019s speech in Elkhart today. He\u2019s 100% right: we need Congress\u2019s help to fight Zika &amp; opioid epidemic: https:\/\/t.co\/svyIG83BAU",
    "id" : 738137292078878720,
    "created_at" : "2016-06-01 22:36:59 +0000",
    "user" : {
      "name" : "Denis McDonough",
      "screen_name" : "Denis44",
      "protected" : false,
      "id_str" : "3093573484",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684853824180232192\/4P802YCN_normal.jpg",
      "id" : 3093573484,
      "verified" : true
    }
  },
  "id" : 738138574797688832,
  "created_at" : "2016-06-01 22:42:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/IryDjICFDM",
      "expanded_url" : "http:\/\/snpy.tv\/1TYjpye",
      "display_url" : "snpy.tv\/1TYjpye"
    } ]
  },
  "geo" : { },
  "id_str" : "738128087074775040",
  "text" : "4 myths Republicans in Congress continue to spread about the economy\u2014busted by @POTUS: https:\/\/t.co\/IryDjICFDM",
  "id" : 738128087074775040,
  "created_at" : "2016-06-01 22:00:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/unuRhiHTSU",
      "expanded_url" : "http:\/\/snpy.tv\/1ZdW23V",
      "display_url" : "snpy.tv\/1ZdW23V"
    } ]
  },
  "geo" : { },
  "id_str" : "738125493371691008",
  "text" : "\"The truth is trade has helped our country a lot more than it\u2019s hurt us.\" \u2014@POTUS in Elkhart, IN. https:\/\/t.co\/unuRhiHTSU",
  "id" : 738125493371691008,
  "created_at" : "2016-06-01 21:50:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/8oQETqIXhJ",
      "expanded_url" : "http:\/\/snpy.tv\/1XhwkhI",
      "display_url" : "snpy.tv\/1XhwkhI"
    } ]
  },
  "geo" : { },
  "id_str" : "738122926273110017",
  "text" : "\"Our deficits haven\u2019t grown these past seven and a half years\u2014we\u2019ve cut them by almost 75 percent.\" \u2014@POTUS https:\/\/t.co\/8oQETqIXhJ",
  "id" : 738122926273110017,
  "created_at" : "2016-06-01 21:39:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 34, 40 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/FqBJVWoDBU",
      "expanded_url" : "http:\/\/snpy.tv\/1VxeJ3o",
      "display_url" : "snpy.tv\/1VxeJ3o"
    } ]
  },
  "geo" : { },
  "id_str" : "738117953426579456",
  "text" : "\"Let's get wages rising faster.\" \u2014@POTUS in Elkhart on how we can help working families see bigger paychecks: https:\/\/t.co\/FqBJVWoDBU",
  "id" : 738117953426579456,
  "created_at" : "2016-06-01 21:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/jvGZdAKGzQ",
      "expanded_url" : "http:\/\/snpy.tv\/22yojEn",
      "display_url" : "snpy.tv\/22yojEn"
    } ]
  },
  "geo" : { },
  "id_str" : "738113008807841792",
  "text" : "\"By almost every economic measure, we're better off\" \u2014@POTUS outlines America's economic progress in Elkhart, IN https:\/\/t.co\/jvGZdAKGzQ",
  "id" : 738113008807841792,
  "created_at" : "2016-06-01 21:00:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/IryDjIUh2m",
      "expanded_url" : "http:\/\/snpy.tv\/1TYjpye",
      "display_url" : "snpy.tv\/1TYjpye"
    } ]
  },
  "geo" : { },
  "id_str" : "738109601376243713",
  "text" : ".@POTUS busts the 4 myths Republicans in Congress spread about the economy.\nHere's the facts: https:\/\/t.co\/IryDjIUh2m",
  "id" : 738109601376243713,
  "created_at" : "2016-06-01 20:46:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738103122803970054\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/WEwRWAn7Qn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj5E3r0UgAEV6fu.jpg",
      "id_str" : "738103112381005825",
      "id" : 738103112381005825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj5E3r0UgAEV6fu.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/WEwRWAn7Qn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738103122803970054",
  "text" : "\"Middle class families have paid a lower federal income tax rate during my presidency\" \u2014@POTUS in Elkhart https:\/\/t.co\/WEwRWAn7Qn",
  "id" : 738103122803970054,
  "created_at" : "2016-06-01 20:21:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738100017374867457",
  "text" : "RT @WHLive: \"America shouldn\u2019t be changing our laws to make it harder for workers to organize\" \u2014@POTUS in Elkhart",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 84, 90 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738099918628392960",
    "text" : "\"America shouldn\u2019t be changing our laws to make it harder for workers to organize\" \u2014@POTUS in Elkhart",
    "id" : 738099918628392960,
    "created_at" : "2016-06-01 20:08:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 738100017374867457,
  "created_at" : "2016-06-01 20:08:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738099760293380096",
  "text" : "\"It\u2019s not a coincidence that as union membership shrank, inequality grew and wages stagnated.\"  \u2014@POTUS in Elkhart",
  "id" : 738099760293380096,
  "created_at" : "2016-06-01 20:07:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayNow",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738099623760388097",
  "text" : "\"It shouldn\u2019t be a partisan issue, Republicans have daughters, too.\u201D \u2014@POTUS on why it's time for #EqualPayNow",
  "id" : 738099623760388097,
  "created_at" : "2016-06-01 20:07:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738099292850786308",
  "text" : "RT if you agree with @POTUS: \"We should raise the minimum wage high enough to keep working families from living in poverty\" #RaiseTheWage",
  "id" : 738099292850786308,
  "created_at" : "2016-06-01 20:05:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738098817929740292\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/TE0HzMF5AQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj5A85SVAAEXgmX.jpg",
      "id_str" : "738098803849363457",
      "id" : 738098803849363457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj5A85SVAAEXgmX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TE0HzMF5AQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738098817929740292",
  "text" : "\u201CTook new action to help millions of workers finally collect the overtime pay they\u2019ve earned.\u201D \u2014@POTUS in Elkhart https:\/\/t.co\/TE0HzMF5AQ",
  "id" : 738098817929740292,
  "created_at" : "2016-06-01 20:04:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738098416299843588",
  "text" : "\"Every child in this country deserves an education that lets them dream bigger than their circumstance. \" \u2014@POTUS in Elkhart",
  "id" : 738098416299843588,
  "created_at" : "2016-06-01 20:02:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/IlwRRs4e2G",
      "expanded_url" : "http:\/\/go.wh.gov\/Elkhart",
      "display_url" : "go.wh.gov\/Elkhart"
    } ]
  },
  "geo" : { },
  "id_str" : "738098165094580228",
  "text" : "\"Working families of all races, and all backgrounds, deserve higher wages.\" \u2014@POTUS on the economy in Elkhart: https:\/\/t.co\/IlwRRs4e2G",
  "id" : 738098165094580228,
  "created_at" : "2016-06-01 20:01:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738097415287250946\/photo\/1",
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/OCeVja0F3o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj4_pNsUYAAqhNE.jpg",
      "id_str" : "738097366218072064",
      "id" : 738097366218072064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj4_pNsUYAAqhNE.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/OCeVja0F3o"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738097415287250946",
  "text" : "\u201CWe just need a Congress who\u2019s willing to make it happen.\u201D \u2014@POTUS on immigration reform https:\/\/t.co\/OCeVja0F3o",
  "id" : 738097415287250946,
  "created_at" : "2016-06-01 19:58:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738096274033901569\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/wKGbFheQpl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj4-kQOUgAA6xEM.jpg",
      "id_str" : "738096181486583808",
      "id" : 738096181486583808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj4-kQOUgAA6xEM.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/wKGbFheQpl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738096274033901569",
  "text" : "\"We\u2019ve brought more trade cases against other countries than anyone else\" \u2014@POTUS in Elkhart https:\/\/t.co\/wKGbFheQpl",
  "id" : 738096274033901569,
  "created_at" : "2016-06-01 19:53:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738095782453121024\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/l6Z3R0JWyQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj4-LydUkAEaXwk.jpg",
      "id_str" : "738095761179578369",
      "id" : 738095761179578369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj4-LydUkAEaXwk.jpg",
      "sizes" : [ {
        "h" : 721,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/l6Z3R0JWyQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738095782453121024",
  "text" : "\"I\u2019ve issued fewer executive orders than any two-term President since Ulysses S. Grant.\" \u2014@POTUS in Elkhart https:\/\/t.co\/l6Z3R0JWyQ",
  "id" : 738095782453121024,
  "created_at" : "2016-06-01 19:52:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738095351601631232\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/7VpWC5VzH9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj49yidVAAADocn.jpg",
      "id_str" : "738095327387910144",
      "id" : 738095327387910144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj49yidVAAADocn.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/7VpWC5VzH9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738095351601631232",
  "text" : "\"I signed the ACA into law over 6 years ago. Since then our businesses have created jobs every single month\" \u2014@POTUS https:\/\/t.co\/7VpWC5VzH9",
  "id" : 738095351601631232,
  "created_at" : "2016-06-01 19:50:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738094782832992258\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/k24EI0FGQ6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj49O3HVAAAuAZe.jpg",
      "id_str" : "738094714457489408",
      "id" : 738094714457489408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj49O3HVAAAuAZe.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/k24EI0FGQ6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738094782832992258",
  "text" : "\u201COur deficits haven\u2019t grown these past seven and a half years; we\u2019ve cut them by almost 75%.\u201D \u2014@POTUS https:\/\/t.co\/k24EI0FGQ6",
  "id" : 738094782832992258,
  "created_at" : "2016-06-01 19:48:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 138, 144 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738094642822946817",
  "text" : "\u201CWe spend less on domestic priorities outside of Social Security, Medicare, &amp; Medicaid\u2026than we did when Ronald Reagan was president\u201D \u2014@POTUS",
  "id" : 738094642822946817,
  "created_at" : "2016-06-01 19:47:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738094172687630336",
  "text" : "\u201CInstead of telling you what they\u2019re for, they\u2019ve defined their economic agenda by what they\u2019re against.\u201D \u2014@POTUS on Republicans in Congress",
  "id" : 738094172687630336,
  "created_at" : "2016-06-01 19:45:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738093459282747392",
  "text" : "\"All these trends make it easy to feel like the system is rigged, and that the American Dream is increasingly hard to reach.\u201D \u2014@POTUS",
  "id" : 738093459282747392,
  "created_at" : "2016-06-01 19:42:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738092920012722176",
  "text" : "\u201CWe\u2019ve been stuck with a Republican Congress that\u2019s opposed pretty much everything we\u2019ve tried to do.\u201D \u2014@POTUS on the economy in Elkhart",
  "id" : 738092920012722176,
  "created_at" : "2016-06-01 19:40:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738092717356486657\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/MsHaN1fnHh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj47YF7W0AEUFQM.jpg",
      "id_str" : "738092674029375489",
      "id" : 738092674029375489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj47YF7W0AEUFQM.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/MsHaN1fnHh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738092717356486657",
  "text" : "\u201CFor the first time ever, more than ninety percent of the country has health insurance.\u201D \u2014@POTUS on Elkhart https:\/\/t.co\/MsHaN1fnHh",
  "id" : 738092717356486657,
  "created_at" : "2016-06-01 19:39:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738092556999921664\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/BYknKBnaa0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj47QpTWkAAaojR.jpg",
      "id_str" : "738092546086309888",
      "id" : 738092546086309888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj47QpTWkAAaojR.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/BYknKBnaa0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738092556999921664",
  "text" : "\u201COver the past six years, our businesses have created more than 14 million new jobs.\"  \u2014@POTUS in Elkhart https:\/\/t.co\/BYknKBnaa0",
  "id" : 738092556999921664,
  "created_at" : "2016-06-01 19:39:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738092145345695744\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/gF5scu2xL0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj463haWEAIP-nx.jpg",
      "id_str" : "738092114471424002",
      "id" : 738092114471424002,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj463haWEAIP-nx.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/gF5scu2xL0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738092145345695744",
  "text" : "\u201CBack then, only 75% of your kids graduated from high school. Tomorrow, almost 90% of them will\u201D \u2014@POTUS on Elkhart https:\/\/t.co\/gF5scu2xL0",
  "id" : 738092145345695744,
  "created_at" : "2016-06-01 19:37:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738092061480652801",
  "text" : "\"Nearly 1 in 10 homeowners in Indiana were either way behind on their mortgages, or in foreclosure. Today, it\u2019s more like 1 in 30.\" \u2014@POTUS",
  "id" : 738092061480652801,
  "created_at" : "2016-06-01 19:37:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738091950839058432\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/OZT94boB8C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj46oDVW0AAVyzI.jpg",
      "id_str" : "738091848699400192",
      "id" : 738091848699400192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj46oDVW0AAVyzI.jpg",
      "sizes" : [ {
        "h" : 721,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OZT94boB8C"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/IlwRRslPrg",
      "expanded_url" : "http:\/\/go.wh.gov\/Elkhart",
      "display_url" : "go.wh.gov\/Elkhart"
    } ]
  },
  "geo" : { },
  "id_str" : "738091950839058432",
  "text" : "\u201CElkhart was hit harder than most. Unemployment would peak here at 19.6 percent.\u201D \u2014@POTUS: https:\/\/t.co\/IlwRRslPrg https:\/\/t.co\/OZT94boB8C",
  "id" : 738091950839058432,
  "created_at" : "2016-06-01 19:36:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738091460575297536",
  "text" : "\"We can make it even stronger...But to do that, we have to be honest about what our real challenges are.\" \u2014@POTUS in Elkhart",
  "id" : 738091460575297536,
  "created_at" : "2016-06-01 19:34:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738091277149982721",
  "text" : "\u201CAmerica\u2019s economy isn\u2019t just better than it was eight years ago\u2014it\u2019s the strongest, most durable economy in the world\u201D \u2014@POTUS in Elkhart",
  "id" : 738091277149982721,
  "created_at" : "2016-06-01 19:34:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/IlwRRslPrg",
      "expanded_url" : "http:\/\/go.wh.gov\/Elkhart",
      "display_url" : "go.wh.gov\/Elkhart"
    } ]
  },
  "geo" : { },
  "id_str" : "738090687502110720",
  "text" : "Happening now: @POTUS highlights the economic progress we've made &amp; the challenges that remain \u2192 https:\/\/t.co\/IlwRRslPrg",
  "id" : 738090687502110720,
  "created_at" : "2016-06-01 19:31:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/738088669354045440\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/HQMtU1rfkU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj43a9jWgAAuEiS.jpg",
      "id_str" : "738088325274304512",
      "id" : 738088325274304512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj43a9jWgAAuEiS.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HQMtU1rfkU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/IlwRRslPrg",
      "expanded_url" : "http:\/\/go.wh.gov\/Elkhart",
      "display_url" : "go.wh.gov\/Elkhart"
    } ]
  },
  "geo" : { },
  "id_str" : "738088669354045440",
  "text" : "One of @POTUS's first trips in 2009 was to Elkhart, IN. Today, he\u2019s going back. Tune in \u2192 https:\/\/t.co\/IlwRRslPrg https:\/\/t.co\/HQMtU1rfkU",
  "id" : 738088669354045440,
  "created_at" : "2016-06-01 19:23:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/738042186198028288\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/wIL0QjbBfz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj4NYhoWkAEuBwb.jpg",
      "id_str" : "738042103930982401",
      "id" : 738042103930982401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj4NYhoWkAEuBwb.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/wIL0QjbBfz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/IlwRRslPrg",
      "expanded_url" : "http:\/\/go.wh.gov\/Elkhart",
      "display_url" : "go.wh.gov\/Elkhart"
    } ]
  },
  "geo" : { },
  "id_str" : "738042186198028288",
  "text" : "Here's what you need to know about our economic progress ahead of @POTUS's visit to Elkhart: https:\/\/t.co\/IlwRRslPrg https:\/\/t.co\/wIL0QjbBfz",
  "id" : 738042186198028288,
  "created_at" : "2016-06-01 16:19:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738026173482053632",
  "text" : "RT @Cecilia44: Yesterday, the guy who plays a Treasury Secretary, now the actual Secretary:Time for Congress to Act on Puerto Rico.\nhttps:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/6UE4Xqq33w",
        "expanded_url" : "http:\/\/www.nydailynews.com\/opinion\/jacob-lew-puerto-rico-rescue-article-1.2656285",
        "display_url" : "nydailynews.com\/opinion\/jacob-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "737998750178627586",
    "text" : "Yesterday, the guy who plays a Treasury Secretary, now the actual Secretary:Time for Congress to Act on Puerto Rico.\nhttps:\/\/t.co\/6UE4Xqq33w",
    "id" : 737998750178627586,
    "created_at" : "2016-06-01 13:26:28 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 738026173482053632,
  "created_at" : "2016-06-01 15:15:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "738012177680977920",
  "text" : "RT @vj44: First time @POTUS visited Elkhart in 2009, the unemployment rate was on its way to 19.6%. Today it is 4.1%. THAT'S progress.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 11, 17 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "738011250743877632",
    "text" : "First time @POTUS visited Elkhart in 2009, the unemployment rate was on its way to 19.6%. Today it is 4.1%. THAT'S progress.",
    "id" : 738011250743877632,
    "created_at" : "2016-06-01 14:16:08 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 738012177680977920,
  "created_at" : "2016-06-01 14:19:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]