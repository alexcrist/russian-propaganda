Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/263844603629817856\/photo\/1",
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/QVHydYAn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6ldROPCUAA7o7q.jpg",
      "id_str" : "263844603638206464",
      "id" : 263844603638206464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6ldROPCUAA7o7q.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QVHydYAn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/yfwdAQzc",
      "expanded_url" : "http:\/\/on.wh.gov\/vZilNV",
      "display_url" : "on.wh.gov\/vZilNV"
    } ]
  },
  "geo" : { },
  "id_str" : "263844603629817856",
  "text" : "Today, President Obama toured storm damage in NJ. View the gallery: http:\/\/t.co\/yfwdAQzc Photo: http:\/\/t.co\/QVHydYAn",
  "id" : 263844603629817856,
  "created_at" : "2012-11-01 03:27:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/92evmG6a",
      "expanded_url" : "http:\/\/on.wh.gov\/NulepT",
      "display_url" : "on.wh.gov\/NulepT"
    } ]
  },
  "geo" : { },
  "id_str" : "263835261878796288",
  "text" : "President Obama to those effected by #Sandy: \"We are here for you. We will not forget.\" Watch: http:\/\/t.co\/92evmG6a",
  "id" : 263835261878796288,
  "created_at" : "2012-11-01 02:50:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Christie",
      "screen_name" : "GovChristie",
      "indices" : [ 44, 56 ],
      "id_str" : "90484508",
      "id" : 90484508
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/263773895247675393\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/l3nIu7ht",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6kc9c_CQAEtRB_.jpg",
      "id_str" : "263773895256064001",
      "id" : 263773895256064001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6kc9c_CQAEtRB_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/l3nIu7ht"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263773895247675393",
  "text" : "Photo: On Marine One, President Obama &amp; @GovChristie survey the damage done by Hurricane #Sandy along New Jersey coast: http:\/\/t.co\/l3nIu7ht",
  "id" : 263773895247675393,
  "created_at" : "2012-10-31 22:46:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 40, 45 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 32, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/qmwZvJM8",
      "expanded_url" : "http:\/\/on.wh.gov\/I3flJ3",
      "display_url" : "on.wh.gov\/I3flJ3"
    } ]
  },
  "geo" : { },
  "id_str" : "263744452848394241",
  "text" : "Help the survivors of Hurricane #Sandy: @fema suggests a financial contribution &amp; giving blood. More ways to help: http:\/\/t.co\/qmwZvJM8",
  "id" : 263744452848394241,
  "created_at" : "2012-10-31 20:49:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 39, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/V04GleYA",
      "expanded_url" : "http:\/\/on.wh.gov\/n2GUNT",
      "display_url" : "on.wh.gov\/n2GUNT"
    } ]
  },
  "geo" : { },
  "id_str" : "263677713116696576",
  "text" : "How to Help the Survivors of Hurricane #Sandy: http:\/\/t.co\/V04GleYA",
  "id" : 263677713116696576,
  "created_at" : "2012-10-31 16:24:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263640496306540544",
  "text" : "Today, President Obama travels to New Jersey to view #Sandy damage, talk to citizens recovering from the storm &amp; thank first responders.",
  "id" : 263640496306540544,
  "created_at" : "2012-10-31 13:56:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/FUy4aFac",
      "expanded_url" : "http:\/\/on.wh.gov\/6Sn31z",
      "display_url" : "on.wh.gov\/6Sn31z"
    } ]
  },
  "geo" : { },
  "id_str" : "263412093183733760",
  "text" : "\"During the darkness of the storm, I think we also saw what's brightest in America\" -President Obama on #Sandy. Watch: http:\/\/t.co\/FUy4aFac",
  "id" : 263412093183733760,
  "created_at" : "2012-10-30 22:48:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "American Red Cross",
      "screen_name" : "RedCross",
      "indices" : [ 73, 82 ],
      "id_str" : "6519522",
      "id" : 6519522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/263395805828878336\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/beJPaIs6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6fFFwICEAEzdNy.jpg",
      "id_str" : "263395805833072641",
      "id" : 263395805833072641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6fFFwICEAEzdNy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2607,
        "resize" : "fit",
        "w" : 3910
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/beJPaIs6"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 59, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/03E7ArQ0",
      "expanded_url" : "http:\/\/on.wh.gov\/WNSStK",
      "display_url" : "on.wh.gov\/WNSStK"
    } ]
  },
  "geo" : { },
  "id_str" : "263395805828878336",
  "text" : "\"This storm is not yet over\" -President Obama on Hurricane #Sandy at the @RedCross today: http:\/\/t.co\/03E7ArQ0 Photo: http:\/\/t.co\/beJPaIs6",
  "id" : 263395805828878336,
  "created_at" : "2012-10-30 21:43:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 3, 15 ],
      "id_str" : "59204932",
      "id" : 59204932
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 109, 114 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 27, 33 ]
    }, {
      "text" : "volunteer",
      "indices" : [ 86, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/u7rlW6sz",
      "expanded_url" : "http:\/\/go.usa.gov\/YwJY",
      "display_url" : "go.usa.gov\/YwJY"
    } ]
  },
  "geo" : { },
  "id_str" : "263374588988235776",
  "text" : "RT @ServeDotGov: Important #Sandy safety information &amp; where to go if you want to #volunteer or help via @FEMA http:\/\/t.co\/u7rlW6sz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FEMA",
        "screen_name" : "fema",
        "indices" : [ 92, 97 ],
        "id_str" : "16669075",
        "id" : 16669075
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 10, 16 ]
      }, {
        "text" : "volunteer",
        "indices" : [ 69, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/u7rlW6sz",
        "expanded_url" : "http:\/\/go.usa.gov\/YwJY",
        "display_url" : "go.usa.gov\/YwJY"
      } ]
    },
    "geo" : { },
    "id_str" : "263371806176600064",
    "text" : "Important #Sandy safety information &amp; where to go if you want to #volunteer or help via @FEMA http:\/\/t.co\/u7rlW6sz",
    "id" : 263371806176600064,
    "created_at" : "2012-10-30 20:08:26 +0000",
    "user" : {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "protected" : false,
      "id_str" : "59204932",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1119135330\/serve_normal.JPG",
      "id" : 59204932,
      "verified" : true
    }
  },
  "id" : 263374588988235776,
  "created_at" : "2012-10-30 20:19:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/263362172690784256\/photo\/1",
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/Xnqr2r3s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6emgC8CYAA5HK6.jpg",
      "id_str" : "263362172699172864",
      "id" : 263362172699172864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6emgC8CYAA5HK6.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Xnqr2r3s"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 49, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/Fb1is0e6",
      "expanded_url" : "http:\/\/on.wh.gov\/i8nnGg",
      "display_url" : "on.wh.gov\/i8nnGg"
    } ]
  },
  "geo" : { },
  "id_str" : "263362172690784256",
  "text" : "Readout of the President's Briefing on Hurricane #Sandy: http:\/\/t.co\/Fb1is0e6 Pic: http:\/\/t.co\/Xnqr2r3s",
  "id" : 263362172690784256,
  "created_at" : "2012-10-30 19:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263358017075036161",
  "text" : "RT @VP: PHOTO: VP joins the President's video-teleconference call from Columbus, OH to get the latest on #Sandy. (WH Photo) http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/263311109740703744\/photo\/1",
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/DmmoyQjJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A6d4DyoCMAANRC0.jpg",
        "id_str" : "263311109749092352",
        "id" : 263311109749092352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6d4DyoCMAANRC0.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/DmmoyQjJ"
      } ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 97, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263311109740703744",
    "text" : "PHOTO: VP joins the President's video-teleconference call from Columbus, OH to get the latest on #Sandy. (WH Photo) http:\/\/t.co\/DmmoyQjJ",
    "id" : 263311109740703744,
    "created_at" : "2012-10-30 16:07:16 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 263358017075036161,
  "created_at" : "2012-10-30 19:13:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263313894825660417",
  "text" : "RT @jearnest44: NEW PHOTO: this am, POTUS convenes a videoconference on Sandy with his homeland security team in the Situation Room.  ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/sazMIvTY",
        "expanded_url" : "http:\/\/bitly.com\/SuK5pW",
        "display_url" : "bitly.com\/SuK5pW"
      } ]
    },
    "geo" : { },
    "id_str" : "263303593908654080",
    "text" : "NEW PHOTO: this am, POTUS convenes a videoconference on Sandy with his homeland security team in the Situation Room.  http:\/\/t.co\/sazMIvTY",
    "id" : 263303593908654080,
    "created_at" : "2012-10-30 15:37:23 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 263313894825660417,
  "created_at" : "2012-10-30 16:18:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "biz",
      "indices" : [ 75, 79 ]
    }, {
      "text" : "Sandy",
      "indices" : [ 112, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263287088122830848",
  "text" : "RT @SBAgov: SBA is on hand to answer your Qs about disaster assistance for #biz &amp; homeowners in the wake of #Sandy- Call 1-800-659-2955",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "biz",
        "indices" : [ 63, 67 ]
      }, {
        "text" : "Sandy",
        "indices" : [ 100, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263271787998113792",
    "text" : "SBA is on hand to answer your Qs about disaster assistance for #biz &amp; homeowners in the wake of #Sandy- Call 1-800-659-2955",
    "id" : 263271787998113792,
    "created_at" : "2012-10-30 13:31:00 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 263287088122830848,
  "created_at" : "2012-10-30 14:31:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/9svv3C4O",
      "expanded_url" : "http:\/\/on.wh.gov\/lfmIj3",
      "display_url" : "on.wh.gov\/lfmIj3"
    } ]
  },
  "geo" : { },
  "id_str" : "263250749792849921",
  "text" : "Watch: President Obama delivers a statement on Hurricane #Sandy in the Press Briefing Room: http:\/\/t.co\/9svv3C4O",
  "id" : 263250749792849921,
  "created_at" : "2012-10-30 12:07:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hurricane",
      "indices" : [ 49, 59 ]
    }, {
      "text" : "Sandy",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/sPshqlkH",
      "expanded_url" : "http:\/\/Ready.gov\/hurricanes",
      "display_url" : "Ready.gov\/hurricanes"
    }, {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/xz5hNhXR",
      "expanded_url" : "http:\/\/m.fema.gov\/hurricanes.htm",
      "display_url" : "m.fema.gov\/hurricanes.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "263125107776557057",
  "text" : "RT @fema: What to do before, during, and after a #hurricane. On the web: http:\/\/t.co\/sPshqlkH On your phone: http:\/\/t.co\/xz5hNhXR #Sandy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hurricane",
        "indices" : [ 39, 49 ]
      }, {
        "text" : "Sandy",
        "indices" : [ 120, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/sPshqlkH",
        "expanded_url" : "http:\/\/Ready.gov\/hurricanes",
        "display_url" : "Ready.gov\/hurricanes"
      }, {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/xz5hNhXR",
        "expanded_url" : "http:\/\/m.fema.gov\/hurricanes.htm",
        "display_url" : "m.fema.gov\/hurricanes.htm"
      } ]
    },
    "geo" : { },
    "id_str" : "263100040233492480",
    "text" : "What to do before, during, and after a #hurricane. On the web: http:\/\/t.co\/sPshqlkH On your phone: http:\/\/t.co\/xz5hNhXR #Sandy",
    "id" : 263100040233492480,
    "created_at" : "2012-10-30 02:08:32 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 263125107776557057,
  "created_at" : "2012-10-30 03:48:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 16, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263087371816431619",
  "text" : "RT @fema: 10\/29 #Sandy safety tip: Stay off the roads to let emergency crews do their work. Check on your neighbors to make sure they're OK.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 6, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "263070236578816000",
    "text" : "10\/29 #Sandy safety tip: Stay off the roads to let emergency crews do their work. Check on your neighbors to make sure they're OK.",
    "id" : 263070236578816000,
    "created_at" : "2012-10-30 00:10:06 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 263087371816431619,
  "created_at" : "2012-10-30 01:18:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/263012747111985152\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/JEYyEwSJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6ZoszQCcAAzYwa.jpg",
      "id_str" : "263012747128762368",
      "id" : 263012747128762368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6ZoszQCcAAzYwa.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JEYyEwSJ"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 79, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263012747111985152",
  "text" : "Photo: President Obama receives an update on the ongoing response to Hurricane #Sandy in the Situation Room: http:\/\/t.co\/JEYyEwSJ",
  "id" : 263012747111985152,
  "created_at" : "2012-10-29 20:21:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 29, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/BMOyjGXy",
      "expanded_url" : "http:\/\/on.wh.gov\/F3aa0R",
      "display_url" : "on.wh.gov\/F3aa0R"
    } ]
  },
  "geo" : { },
  "id_str" : "262993227311878144",
  "text" : "President Obama on Hurricane #Sandy: \"Please listen to what your state and local officials are saying.\" Watch: http:\/\/t.co\/BMOyjGXy",
  "id" : 262993227311878144,
  "created_at" : "2012-10-29 19:04:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/Yu8VAQB0",
      "expanded_url" : "http:\/\/on.wh.gov\/MnYfbK",
      "display_url" : "on.wh.gov\/MnYfbK"
    } ]
  },
  "geo" : { },
  "id_str" : "262959162693152768",
  "text" : "Happening Now: President Obama delivers a statement on Hurricane #Sandy. Watch it live: http:\/\/t.co\/Yu8VAQB0",
  "id" : 262959162693152768,
  "created_at" : "2012-10-29 16:48:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 79, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/PqT8QRRI",
      "expanded_url" : "http:\/\/on.wh.gov\/ezvJ0p",
      "display_url" : "on.wh.gov\/ezvJ0p"
    } ]
  },
  "geo" : { },
  "id_str" : "262946360456785920",
  "text" : "Happening at 12:45 p.m. EDT: President Obama delivers a statement on Hurricane #Sandy. Watch live: http:\/\/t.co\/PqT8QRRI",
  "id" : 262946360456785920,
  "created_at" : "2012-10-29 15:57:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 20, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262931145614823424",
  "text" : "RT @fema: 10\/29: As #Sandy makes landfall: stay off the roads, charge your cell phone, listen to local officials &amp; follow your forecast.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 10, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262928486820360193",
    "text" : "10\/29: As #Sandy makes landfall: stay off the roads, charge your cell phone, listen to local officials &amp; follow your forecast.",
    "id" : 262928486820360193,
    "created_at" : "2012-10-29 14:46:50 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 262931145614823424,
  "created_at" : "2012-10-29 14:57:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 10, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262751417993945088",
  "text" : "RT @fema: #Sandy East coast, search for open shelters by texting: SHELTER + a zip code to 43362 (4FEMA). Ex: Shelter 01234 (std rates apply)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262715813444845568",
    "text" : "#Sandy East coast, search for open shelters by texting: SHELTER + a zip code to 43362 (4FEMA). Ex: Shelter 01234 (std rates apply)",
    "id" : 262715813444845568,
    "created_at" : "2012-10-29 00:41:45 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 262751417993945088,
  "created_at" : "2012-10-29 03:03:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 92, 97 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/262656977887453185\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/byviJKh6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6UlITlCYAAQEZH.jpg",
      "id_str" : "262656977895841792",
      "id" : 262656977895841792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6UlITlCYAAQEZH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/byviJKh6"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 29, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/joUrWYJd",
      "expanded_url" : "http:\/\/on.wh.gov\/kPMeMP",
      "display_url" : "on.wh.gov\/kPMeMP"
    } ]
  },
  "geo" : { },
  "id_str" : "262656977887453185",
  "text" : "President Obama on Hurricane #Sandy: \"Take this very seriously\": http:\/\/t.co\/joUrWYJd Photo @FEMA today: http:\/\/t.co\/byviJKh6",
  "id" : 262656977887453185,
  "created_at" : "2012-10-28 20:47:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 34, 40 ]
    }, {
      "text" : "frankenstorm",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/ohMVYd6c",
      "expanded_url" : "http:\/\/www.weather.gov",
      "display_url" : "weather.gov"
    }, {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/iulfUz8k",
      "expanded_url" : "http:\/\/mobile.weather.gov",
      "display_url" : "mobile.weather.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "262592015118774272",
  "text" : "RT @fema: Stay up-to-date on your #Sandy forecast. On the web: http:\/\/t.co\/ohMVYd6c Mobile: http:\/\/t.co\/iulfUz8k #frankenstorm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 24, 30 ]
      }, {
        "text" : "frankenstorm",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/ohMVYd6c",
        "expanded_url" : "http:\/\/www.weather.gov",
        "display_url" : "weather.gov"
      }, {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/iulfUz8k",
        "expanded_url" : "http:\/\/mobile.weather.gov",
        "display_url" : "mobile.weather.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "262583698770255872",
    "text" : "Stay up-to-date on your #Sandy forecast. On the web: http:\/\/t.co\/ohMVYd6c Mobile: http:\/\/t.co\/iulfUz8k #frankenstorm",
    "id" : 262583698770255872,
    "created_at" : "2012-10-28 15:56:47 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 262592015118774272,
  "created_at" : "2012-10-28 16:29:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/GJeHAbgX",
      "expanded_url" : "http:\/\/on.wh.gov\/OzW4Wt",
      "display_url" : "on.wh.gov\/OzW4Wt"
    } ]
  },
  "geo" : { },
  "id_str" : "262208600901050369",
  "text" : "Weekly Address: Protecting the American People with New Wall Street Reforms: http:\/\/t.co\/GJeHAbgX",
  "id" : 262208600901050369,
  "created_at" : "2012-10-27 15:06:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 19, 24 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/y6ql4vr0",
      "expanded_url" : "http:\/\/on.wh.gov\/ilBvWz",
      "display_url" : "on.wh.gov\/ilBvWz"
    } ]
  },
  "geo" : { },
  "id_str" : "262192919908347905",
  "text" : "President Obama on @CFPB: \"Their mission is to fight for you. And when needed, they'll take action.\" Weekly Address: http:\/\/t.co\/y6ql4vr0",
  "id" : 262192919908347905,
  "created_at" : "2012-10-27 14:03:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreastCancerAwarenessMonth",
      "indices" : [ 52, 79 ]
    }, {
      "text" : "WHGarden",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/ne2lATbE",
      "expanded_url" : "http:\/\/on.wh.gov\/ToI8Qi",
      "display_url" : "on.wh.gov\/ToI8Qi"
    } ]
  },
  "geo" : { },
  "id_str" : "262017609887789056",
  "text" : "A behind-the-scenes look at this week at 1600 Penn: #BreastCancerAwarenessMonth, Fall #WHGarden Tours &amp; more. Watch: http:\/\/t.co\/ne2lATbE",
  "id" : 262017609887789056,
  "created_at" : "2012-10-27 02:27:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/261976117056000000\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/d82tfmNg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6K54_VCUAAh8oo.jpg",
      "id_str" : "261976117064388608",
      "id" : 261976117064388608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6K54_VCUAAh8oo.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/d82tfmNg"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 55, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/OYTDHXgB",
      "expanded_url" : "http:\/\/on.wh.gov\/C4hL08",
      "display_url" : "on.wh.gov\/C4hL08"
    } ]
  },
  "geo" : { },
  "id_str" : "261976117056000000",
  "text" : "Photo: President Obama receives an update on Hurricane #Sandy. Get safety tips &amp; be prepared: http:\/\/t.co\/OYTDHXgB http:\/\/t.co\/d82tfmNg",
  "id" : 261976117056000000,
  "created_at" : "2012-10-26 23:42:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Indiana Fever",
      "screen_name" : "IndianaFever",
      "indices" : [ 73, 86 ],
      "id_str" : "28672101",
      "id" : 28672101
    }, {
      "name" : "Tamika Catchings",
      "screen_name" : "Catchin24",
      "indices" : [ 97, 107 ],
      "id_str" : "370435297",
      "id" : 370435297
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WNBA",
      "indices" : [ 60, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261955626878517248",
  "text" : "RT @vj44: Today President Obama called to congratulate 2012 #WNBA Champs @IndianaFever &amp; MVP @Catchin24 on an excellent season! http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Indiana Fever",
        "screen_name" : "IndianaFever",
        "indices" : [ 63, 76 ],
        "id_str" : "28672101",
        "id" : 28672101
      }, {
        "name" : "Tamika Catchings",
        "screen_name" : "Catchin24",
        "indices" : [ 87, 97 ],
        "id_str" : "370435297",
        "id" : 370435297
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WNBA",
        "indices" : [ 50, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/tQfd4yAF",
        "expanded_url" : "http:\/\/wh.gov\/0g5z",
        "display_url" : "wh.gov\/0g5z"
      } ]
    },
    "geo" : { },
    "id_str" : "261952939562786817",
    "text" : "Today President Obama called to congratulate 2012 #WNBA Champs @IndianaFever &amp; MVP @Catchin24 on an excellent season! http:\/\/t.co\/tQfd4yAF",
    "id" : 261952939562786817,
    "created_at" : "2012-10-26 22:10:22 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 261955626878517248,
  "created_at" : "2012-10-26 22:21:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/PofCOQ2q",
      "expanded_url" : "http:\/\/on.wh.gov\/FIAGwM",
      "display_url" : "on.wh.gov\/FIAGwM"
    } ]
  },
  "geo" : { },
  "id_str" : "261952553519042560",
  "text" : "\"Best wishes for a joyful Eid al-Adha to Muslims in the United States &amp; around the world.\"-President Obama http:\/\/t.co\/PofCOQ2q",
  "id" : 261952553519042560,
  "created_at" : "2012-10-26 22:08:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/261913992736436224\/photo\/1",
      "indices" : [ 128, 148 ],
      "url" : "http:\/\/t.co\/8CG3b9Yo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6KBY4NCcAAf8Xh.jpg",
      "id_str" : "261913992744824832",
      "id" : 261913992744824832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6KBY4NCcAAf8Xh.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8CG3b9Yo"
    } ],
    "hashtags" : [ {
      "text" : "BreastCancerAwarenessMonth",
      "indices" : [ 32, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/D7aHn4nr",
      "expanded_url" : "http:\/\/on.wh.gov\/CTmoVr",
      "display_url" : "on.wh.gov\/CTmoVr"
    } ]
  },
  "geo" : { },
  "id_str" : "261913992736436224",
  "text" : ".@VP &amp; Dr Biden commemorate #BreastCancerAwarenessMonth w\/ a reception: http:\/\/t.co\/D7aHn4nr &amp; a pink Naval Observatory http:\/\/t.co\/8CG3b9Yo",
  "id" : 261913992736436224,
  "created_at" : "2012-10-26 19:35:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 10, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/QQKE0mEO",
      "expanded_url" : "http:\/\/www.hurricanes.gov",
      "display_url" : "hurricanes.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "261888837104570368",
  "text" : "RT @fema: #Sandy\u2019s future path is uncertain; those along the East Coast should follow http:\/\/t.co\/QQKE0mEO &amp; get prepared http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/QQKE0mEO",
        "expanded_url" : "http:\/\/www.hurricanes.gov",
        "display_url" : "hurricanes.gov"
      }, {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/XurOvjjR",
        "expanded_url" : "http:\/\/www.Ready.gov\/hurricanes",
        "display_url" : "Ready.gov\/hurricanes"
      } ]
    },
    "geo" : { },
    "id_str" : "261601586525118464",
    "text" : "#Sandy\u2019s future path is uncertain; those along the East Coast should follow http:\/\/t.co\/QQKE0mEO &amp; get prepared http:\/\/t.co\/XurOvjjR",
    "id" : 261601586525118464,
    "created_at" : "2012-10-25 22:54:13 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 261888837104570368,
  "created_at" : "2012-10-26 17:55:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/W9winhzu",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/10\/26\/advance-estimate-gdp-third-quarter-2012\/",
      "display_url" : "whitehouse.gov\/blog\/2012\/10\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261845059656380418",
  "text" : "RT @Brundage44: CEA Chairman Alan Krueger's statement on the advance estimate for 3rd Quarter GDP here: http:\/\/t.co\/W9winhzu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/W9winhzu",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/10\/26\/advance-estimate-gdp-third-quarter-2012\/",
        "display_url" : "whitehouse.gov\/blog\/2012\/10\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "261839714271776768",
    "text" : "CEA Chairman Alan Krueger's statement on the advance estimate for 3rd Quarter GDP here: http:\/\/t.co\/W9winhzu",
    "id" : 261839714271776768,
    "created_at" : "2012-10-26 14:40:27 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 261845059656380418,
  "created_at" : "2012-10-26 15:01:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Washington",
      "indices" : [ 45, 56 ]
    }, {
      "text" : "Monument",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/5ZMW6CQX",
      "expanded_url" : "http:\/\/instagr.am\/p\/ROGVA7gu0E\/",
      "display_url" : "instagr.am\/p\/ROGVA7gu0E\/"
    } ]
  },
  "geo" : { },
  "id_str" : "261634565519601665",
  "text" : "RT @Interior: It's not every day you see the #Washington #Monument from this angle. http:\/\/t.co\/5ZMW6CQX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Washington",
        "indices" : [ 31, 42 ]
      }, {
        "text" : "Monument",
        "indices" : [ 43, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/5ZMW6CQX",
        "expanded_url" : "http:\/\/instagr.am\/p\/ROGVA7gu0E\/",
        "display_url" : "instagr.am\/p\/ROGVA7gu0E\/"
      } ]
    },
    "geo" : { },
    "id_str" : "261593128673370112",
    "text" : "It's not every day you see the #Washington #Monument from this angle. http:\/\/t.co\/5ZMW6CQX",
    "id" : 261593128673370112,
    "created_at" : "2012-10-25 22:20:36 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 261634565519601665,
  "created_at" : "2012-10-26 01:05:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/261559889833381888\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/Q1MNfRTx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6E_VYGCUAAO7KM.jpg",
      "id_str" : "261559889841770496",
      "id" : 261559889841770496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6E_VYGCUAAO7KM.jpg",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/Q1MNfRTx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/nDrguq5F",
      "expanded_url" : "http:\/\/on.wh.gov\/acwejI",
      "display_url" : "on.wh.gov\/acwejI"
    } ]
  },
  "geo" : { },
  "id_str" : "261559889833381888",
  "text" : "Don't miss your chance to attend the 90th National Christmas Tree Lighting on 12\/6. Sign up: http:\/\/t.co\/nDrguq5F Pic: http:\/\/t.co\/Q1MNfRTx",
  "id" : 261559889833381888,
  "created_at" : "2012-10-25 20:08:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 3, 15 ],
      "id_str" : "67378554",
      "id" : 67378554
    }, {
      "name" : "NHC Atlantic Ops",
      "screen_name" : "NHC_Atlantic",
      "indices" : [ 81, 94 ],
      "id_str" : "299798272",
      "id" : 299798272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 27, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/9BnFL4V7",
      "expanded_url" : "http:\/\/www.Ready.gov\/hurricanes",
      "display_url" : "Ready.gov\/hurricanes"
    } ]
  },
  "geo" : { },
  "id_str" : "261555231190560768",
  "text" : "RT @CraigatFEMA: Hurricane #Sandy 5day forecast track, http;\/\/www.hurricanes.gov @NHC_Atlantic   R U Ready? http:\/\/t.co\/9BnFL4V7 http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NHC Atlantic Ops",
        "screen_name" : "NHC_Atlantic",
        "indices" : [ 64, 77 ],
        "id_str" : "299798272",
        "id" : 299798272
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CraigatFEMA\/status\/261500883504873472\/photo\/1",
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/frbOBvyV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A6EJqwZCQAA8Pzd.jpg",
        "id_str" : "261500883513262080",
        "id" : 261500883513262080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6EJqwZCQAA8Pzd.jpg",
        "sizes" : [ {
          "h" : 716,
          "resize" : "fit",
          "w" : 895
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 895
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/frbOBvyV"
      } ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 10, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/9BnFL4V7",
        "expanded_url" : "http:\/\/www.Ready.gov\/hurricanes",
        "display_url" : "Ready.gov\/hurricanes"
      } ]
    },
    "geo" : { },
    "id_str" : "261500883504873472",
    "text" : "Hurricane #Sandy 5day forecast track, http;\/\/www.hurricanes.gov @NHC_Atlantic   R U Ready? http:\/\/t.co\/9BnFL4V7 http:\/\/t.co\/frbOBvyV",
    "id" : 261500883504873472,
    "created_at" : "2012-10-25 16:14:04 +0000",
    "user" : {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "protected" : false,
      "id_str" : "67378554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522052690138763264\/isW58OSG_normal.jpeg",
      "id" : 67378554,
      "verified" : true
    }
  },
  "id" : 261555231190560768,
  "created_at" : "2012-10-25 19:50:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreastCancerAwarenessMonth",
      "indices" : [ 75, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261535154831511552",
  "text" : "RT @VP: PHOTO: The Naval Observatory lit with pink lights last night for a #BreastCancerAwarenessMonth reception. (WH Photo) http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/261522759283269634\/photo\/1",
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/056cPQlz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A6EdkGCCYAAqWnu.jpg",
        "id_str" : "261522759295852544",
        "id" : 261522759295852544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6EdkGCCYAAqWnu.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/056cPQlz"
      } ],
      "hashtags" : [ {
        "text" : "BreastCancerAwarenessMonth",
        "indices" : [ 67, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261522759283269634",
    "text" : "PHOTO: The Naval Observatory lit with pink lights last night for a #BreastCancerAwarenessMonth reception. (WH Photo) http:\/\/t.co\/056cPQlz",
    "id" : 261522759283269634,
    "created_at" : "2012-10-25 17:41:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 261535154831511552,
  "created_at" : "2012-10-25 18:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Leno",
      "screen_name" : "jayleno",
      "indices" : [ 50, 58 ],
      "id_str" : "35859588",
      "id" : 35859588
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/261488979680051200\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/cvCarGx5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6D-13LCQAEDZx5.jpg",
      "id_str" : "261488979684245505",
      "id" : 261488979684245505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6D-13LCQAEDZx5.jpg",
      "sizes" : [ {
        "h" : 651,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 651,
        "resize" : "fit",
        "w" : 976
      } ],
      "display_url" : "pic.twitter.com\/cvCarGx5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261488979680051200",
  "text" : "Photo of the Day: President Obama jokes with host @JayLeno during \"The Tonight Show with Jay Leno\" in Burbank, Calif: http:\/\/t.co\/cvCarGx5",
  "id" : 261488979680051200,
  "created_at" : "2012-10-25 15:26:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 78, 81 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNDay",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/rmxfsoR3",
      "expanded_url" : "http:\/\/on.wh.gov\/QII6fM",
      "display_url" : "on.wh.gov\/QII6fM"
    } ]
  },
  "geo" : { },
  "id_str" : "261194447130341376",
  "text" : "\"All people deserve the chance to seek their own destiny\" -President Obama on @UN Day: http:\/\/t.co\/rmxfsoR3 #UNDay",
  "id" : 261194447130341376,
  "created_at" : "2012-10-24 19:56:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/261135652958117889\/photo\/1",
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/Fmekcidp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5-9filCIAA4Pg6.jpg",
      "id_str" : "261135652966506496",
      "id" : 261135652966506496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5-9filCIAA4Pg6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Fmekcidp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261135652958117889",
  "text" : "Photo of the Day: President Obama waves as he boards Air Force One in Dayton, Ohio: http:\/\/t.co\/Fmekcidp",
  "id" : 261135652958117889,
  "created_at" : "2012-10-24 16:02:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 49, 60 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/260916313952768000\/photo\/1",
      "indices" : [ 127, 147 ],
      "url" : "http:\/\/t.co\/wAmNL6un",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A572AVHCUAAm6s7.jpg",
      "id_str" : "260916313961156608",
      "id" : 260916313961156608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A572AVHCUAAm6s7.jpg",
      "sizes" : [ {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      } ],
      "display_url" : "pic.twitter.com\/wAmNL6un"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/SZjplxZd",
      "expanded_url" : "http:\/\/on.wh.gov\/0kqG0o",
      "display_url" : "on.wh.gov\/0kqG0o"
    } ]
  },
  "geo" : { },
  "id_str" : "260916313952768000",
  "text" : "Get the latest news, pics, &amp; videos from the @whitehouse with our app for iPhone, iPad &amp; Android: http:\/\/t.co\/SZjplxZd http:\/\/t.co\/wAmNL6un",
  "id" : 260916313952768000,
  "created_at" : "2012-10-24 01:31:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/9Hi0WNer",
      "expanded_url" : "http:\/\/on.wh.gov\/9Je0LP",
      "display_url" : "on.wh.gov\/9Je0LP"
    } ]
  },
  "geo" : { },
  "id_str" : "260828168942940160",
  "text" : "Watch \"Inside the White House: Letters to the President\" to see how your letter could end up on the President's desk: http:\/\/t.co\/9Hi0WNer",
  "id" : 260828168942940160,
  "created_at" : "2012-10-23 19:40:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/260786574466375680\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/dMBdWs67",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A56AAf3CYAA8wNI.jpg",
      "id_str" : "260786574474764288",
      "id" : 260786574474764288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A56AAf3CYAA8wNI.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dMBdWs67"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260786574466375680",
  "text" : "Photo of the Day: President Obama with Sen. John Kerry talks with advisor Karen Dunn aboard Marine One, Oct. 22, 2012. http:\/\/t.co\/dMBdWs67",
  "id" : 260786574466375680,
  "created_at" : "2012-10-23 16:55:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/pTO3oh1h",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/whitehouse\/8114833684\/in\/photostream",
      "display_url" : "flickr.com\/photos\/whiteho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260572150505828355",
  "text" : "RT @VP: PHOTO: VP and daughter Ashley watch President Obama during tonight's debate. http:\/\/t.co\/pTO3oh1h  #debates",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debates",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/pTO3oh1h",
        "expanded_url" : "http:\/\/www.flickr.com\/photos\/whitehouse\/8114833684\/in\/photostream",
        "display_url" : "flickr.com\/photos\/whiteho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "260570704183951361",
    "text" : "PHOTO: VP and daughter Ashley watch President Obama during tonight's debate. http:\/\/t.co\/pTO3oh1h  #debates",
    "id" : 260570704183951361,
    "created_at" : "2012-10-23 02:37:51 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 260572150505828355,
  "created_at" : "2012-10-23 02:43:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 45, 54 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/260494324888903681\/photo\/1",
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/JiwaqJLT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A512NVWCIAAdiwf.jpg",
      "id_str" : "260494324897292288",
      "id" : 260494324897292288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A512NVWCIAAdiwf.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/JiwaqJLT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/aEvS6h7h",
      "expanded_url" : "http:\/\/on.wh.gov\/93M41d",
      "display_url" : "on.wh.gov\/93M41d"
    } ]
  },
  "geo" : { },
  "id_str" : "260494324888903681",
  "text" : "Love following @whitehouse?  Go \"like\" us on @Facebook: http:\/\/t.co\/aEvS6h7h http:\/\/t.co\/JiwaqJLT",
  "id" : 260494324888903681,
  "created_at" : "2012-10-22 21:34:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 3, 8 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/QwroNOvN",
      "expanded_url" : "http:\/\/on.wh.gov\/LQggp3",
      "display_url" : "on.wh.gov\/LQggp3"
    } ]
  },
  "geo" : { },
  "id_str" : "260478795717414913",
  "text" : "RT @CFPB: We are now accepting complaints about credit reports: http:\/\/t.co\/QwroNOvN",
  "id" : 260478795717414913,
  "created_at" : "2012-10-22 20:32:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/260451818084134912\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/EfEnmYpd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A51PjHLCcAA-feY.jpg",
      "id_str" : "260451818096717824",
      "id" : 260451818096717824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A51PjHLCcAA-feY.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EfEnmYpd"
    } ],
    "hashtags" : [ {
      "text" : "WHGarden",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260451818084134912",
  "text" : "Photo of the day: President Obama waves to visitors as they tour the White House grounds, Oct. 19, 2012. #WHGarden http:\/\/t.co\/EfEnmYpd",
  "id" : 260451818084134912,
  "created_at" : "2012-10-22 18:45:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/TNRI0LDu",
      "expanded_url" : "http:\/\/bit.ly\/Pk9eFr",
      "display_url" : "bit.ly\/Pk9eFr"
    } ]
  },
  "geo" : { },
  "id_str" : "260187168029421569",
  "text" : "RT @petesouza: New photo of President Obama at Camp David: http:\/\/t.co\/TNRI0LDu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/TNRI0LDu",
        "expanded_url" : "http:\/\/bit.ly\/Pk9eFr",
        "display_url" : "bit.ly\/Pk9eFr"
      } ]
    },
    "geo" : { },
    "id_str" : "260131145675595776",
    "text" : "New photo of President Obama at Camp David: http:\/\/t.co\/TNRI0LDu",
    "id" : 260131145675595776,
    "created_at" : "2012-10-21 21:31:12 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 260187168029421569,
  "created_at" : "2012-10-22 01:13:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/2a7O1HsE",
      "expanded_url" : "http:\/\/on.wh.gov\/kWZpKN",
      "display_url" : "on.wh.gov\/kWZpKN"
    } ]
  },
  "geo" : { },
  "id_str" : "259756959568375810",
  "text" : "\"I never believed that the best way to deal with the housing market was to just sit back &amp; do nothing.\"-President Obama http:\/\/t.co\/2a7O1HsE",
  "id" : 259756959568375810,
  "created_at" : "2012-10-20 20:44:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/rQtitU5w",
      "expanded_url" : "http:\/\/on.wh.gov\/Y9xaXW",
      "display_url" : "on.wh.gov\/Y9xaXW"
    } ]
  },
  "geo" : { },
  "id_str" : "259707532128444417",
  "text" : "Weekly Address: Congress Should Join the President to Help Responsible Homeowners http:\/\/t.co\/rQtitU5w",
  "id" : 259707532128444417,
  "created_at" : "2012-10-20 17:27:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Show",
      "screen_name" : "TheDailyShow",
      "indices" : [ 52, 65 ],
      "id_str" : "158414847",
      "id" : 158414847
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/259420991996981248\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/kNQUhxJo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5mmBIuCcAABg_g.jpg",
      "id_str" : "259420992001175552",
      "id" : 259420992001175552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5mmBIuCcAABg_g.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kNQUhxJo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259420991996981248",
  "text" : "Photo of the day: President Obama is interviewed by @TheDailyShow's Jon Stewart at the Comedy Central Studios in N.Y. http:\/\/t.co\/kNQUhxJo",
  "id" : 259420991996981248,
  "created_at" : "2012-10-19 22:29:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pamela O'Leary",
      "screen_name" : "olearypd",
      "indices" : [ 3, 12 ],
      "id_str" : "33935084",
      "id" : 33935084
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHGarden",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259368368300249089",
  "text" : "RT @olearypd: #WHGarden My life is complete.  If you pose for enough pics w\/ your friend, you can end up in the West Wing Week video! ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHGarden",
        "indices" : [ 0, 9 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/6x4r1pTE",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/10\/19\/west-wing-week-101912-or-power-we",
        "display_url" : "whitehouse.gov\/blog\/2012\/10\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "259362880317685761",
    "text" : "#WHGarden My life is complete.  If you pose for enough pics w\/ your friend, you can end up in the West Wing Week video! http:\/\/t.co\/6x4r1pTE",
    "id" : 259362880317685761,
    "created_at" : "2012-10-19 18:38:24 +0000",
    "user" : {
      "name" : "Pamela O'Leary",
      "screen_name" : "olearypd",
      "protected" : false,
      "id_str" : "33935084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796804593854349312\/g59U4yXr_normal.jpg",
      "id" : 33935084,
      "verified" : false
    }
  },
  "id" : 259368368300249089,
  "created_at" : "2012-10-19 19:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 45, 50 ]
    }, {
      "text" : "SpiritDay",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259354418674290690",
  "text" : "RT @arneduncan: Purple tie on to support our #LGBT youth. Bullying is not a rite of passage &amp; we've got to take a stand. #SpiritDay  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/arneduncan\/status\/259344661385187328\/photo\/1",
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/JFJ7WwzY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A5lgmHDCEAEEDnz.jpg",
        "id_str" : "259344661393575937",
        "id" : 259344661393575937,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5lgmHDCEAEEDnz.jpg",
        "sizes" : [ {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/JFJ7WwzY"
      } ],
      "hashtags" : [ {
        "text" : "LGBT",
        "indices" : [ 29, 34 ]
      }, {
        "text" : "SpiritDay",
        "indices" : [ 109, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259344661385187328",
    "text" : "Purple tie on to support our #LGBT youth. Bullying is not a rite of passage &amp; we've got to take a stand. #SpiritDay http:\/\/t.co\/JFJ7WwzY",
    "id" : 259344661385187328,
    "created_at" : "2012-10-19 17:26:00 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 259354418674290690,
  "created_at" : "2012-10-19 18:04:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 6, 17 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "purple",
      "indices" : [ 27, 34 ]
    }, {
      "text" : "SpiritDay",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/JVftplyZ",
      "expanded_url" : "http:\/\/at.wh.gov\/eC0sL",
      "display_url" : "at.wh.gov\/eC0sL"
    } ]
  },
  "geo" : { },
  "id_str" : "259322911637266432",
  "text" : "Today @WhiteHouse has gone #purple for #SpiritDay: http:\/\/t.co\/JVftplyZ",
  "id" : 259322911637266432,
  "created_at" : "2012-10-19 15:59:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHGarden",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/g5icuVZL",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "259286283191476225",
  "text" : "RT @WHLive: Happening now on http:\/\/t.co\/g5icuVZL : The 2012 White House Fall Garden Tours live from the South Lawn. #WHGarden",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHGarden",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 17, 37 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "259286186751832064",
    "text" : "Happening now on http:\/\/t.co\/g5icuVZL : The 2012 White House Fall Garden Tours live from the South Lawn. #WHGarden",
    "id" : 259286186751832064,
    "created_at" : "2012-10-19 13:33:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 259286283191476225,
  "created_at" : "2012-10-19 13:34:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/5IeJ84KY",
      "expanded_url" : "http:\/\/on.wh.gov\/GhABO6",
      "display_url" : "on.wh.gov\/GhABO6"
    } ]
  },
  "geo" : { },
  "id_str" : "259281685886144512",
  "text" : "West Wing Week 10\/19\/12: Your guide to everything that happened this week at 1600 Penn. Watch: http:\/\/t.co\/5IeJ84KY",
  "id" : 259281685886144512,
  "created_at" : "2012-10-19 13:15:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHGarden",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/Rs2TappN",
      "expanded_url" : "http:\/\/on.wh.gov\/9Uu1Qg",
      "display_url" : "on.wh.gov\/9Uu1Qg"
    } ]
  },
  "geo" : { },
  "id_str" : "259265905371017216",
  "text" : "Starting at 9ET on http:\/\/t.co\/Rs2TappN The 2012 White House Fall Garden Tours live from the South Lawn. #WHGarden",
  "id" : 259265905371017216,
  "created_at" : "2012-10-19 12:13:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/VqEpvqxE",
      "expanded_url" : "http:\/\/on.wh.gov\/5vurvq",
      "display_url" : "on.wh.gov\/5vurvq"
    } ]
  },
  "geo" : { },
  "id_str" : "259095508633653248",
  "text" : "Go inside the White House with WH Curator Bill Allman as he talks about the history of the Presidential Seal: http:\/\/t.co\/VqEpvqxE",
  "id" : 259095508633653248,
  "created_at" : "2012-10-19 00:55:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259044286836916225",
  "text" : "RT @letsmove: In DC? Take a White House Garden Tour: get free tix at the Ellipse Visitor Pavillion on 15&amp;E St NW @ 8am 10\/19 &amp; 1 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 127, 147 ],
        "url" : "http:\/\/t.co\/niqEGLLE",
        "expanded_url" : "http:\/\/wh.gov\/KdLy",
        "display_url" : "wh.gov\/KdLy"
      } ]
    },
    "geo" : { },
    "id_str" : "259037828858642433",
    "text" : "In DC? Take a White House Garden Tour: get free tix at the Ellipse Visitor Pavillion on 15&amp;E St NW @ 8am 10\/19 &amp; 10\/20 http:\/\/t.co\/niqEGLLE",
    "id" : 259037828858642433,
    "created_at" : "2012-10-18 21:06:45 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 259044286836916225,
  "created_at" : "2012-10-18 21:32:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA Water",
      "screen_name" : "EPAwater",
      "indices" : [ 3, 12 ],
      "id_str" : "17451742",
      "id" : 17451742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cleanwater",
      "indices" : [ 93, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/RXHXwGC6",
      "expanded_url" : "http:\/\/on.wh.gov\/Teuplt",
      "display_url" : "on.wh.gov\/Teuplt"
    } ]
  },
  "geo" : { },
  "id_str" : "259028778506919936",
  "text" : "MT @EPAWater: We're celebrating the 40th Anniversary of the Clean Water Act today. What does #cleanwater mean to you? http:\/\/t.co\/RXHXwGC6",
  "id" : 259028778506919936,
  "created_at" : "2012-10-18 20:30:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/MVMoWX4k",
      "expanded_url" : "http:\/\/on.wh.gov\/cGBied",
      "display_url" : "on.wh.gov\/cGBied"
    } ]
  },
  "geo" : { },
  "id_str" : "258990924066091009",
  "text" : "In 1945, President Harry Truman made a significant change to the Presidential Seal. Want to know what it was? Watch: http:\/\/t.co\/MVMoWX4k",
  "id" : 258990924066091009,
  "created_at" : "2012-10-18 18:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 133, 140 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBiz",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258970516654800898",
  "text" : "RT @vj44: October is Nat'l Women's Small Business Month. Did you know about 30%\n#SmallBiz are owned by women, up from 5% in 1970? cc @SBAgov",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SBA",
        "screen_name" : "SBAgov",
        "indices" : [ 123, 130 ],
        "id_str" : "153149305",
        "id" : 153149305
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBiz",
        "indices" : [ 70, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258955278299578368",
    "text" : "October is Nat'l Women's Small Business Month. Did you know about 30%\n#SmallBiz are owned by women, up from 5% in 1970? cc @SBAgov",
    "id" : 258955278299578368,
    "created_at" : "2012-10-18 15:38:44 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 258970516654800898,
  "created_at" : "2012-10-18 16:39:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/258699013518393346\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/gjlyssIA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5cVYdVCAAA1tpr.jpg",
      "id_str" : "258699013530976256",
      "id" : 258699013530976256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5cVYdVCAAA1tpr.jpg",
      "sizes" : [ {
        "h" : 419,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 419,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/gjlyssIA"
    } ],
    "hashtags" : [ {
      "text" : "RefugeWeek",
      "indices" : [ 23, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/7UEi6eeD",
      "expanded_url" : "http:\/\/on.wh.gov\/G1sRRT",
      "display_url" : "on.wh.gov\/G1sRRT"
    } ]
  },
  "geo" : { },
  "id_str" : "258699013518393346",
  "text" : "It's National Wildlife #RefugeWeek: http:\/\/t.co\/7UEi6eeD Visit 1 of the 560 sites nationwide to see wildlife like this: http:\/\/t.co\/gjlyssIA",
  "id" : 258699013518393346,
  "created_at" : "2012-10-17 22:40:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/FkG4xPmW",
      "expanded_url" : "http:\/\/on.wh.gov\/TVs0zX",
      "display_url" : "on.wh.gov\/TVs0zX"
    } ]
  },
  "geo" : { },
  "id_str" : "258683497521233920",
  "text" : "Want a peek inside one of the most secure spaces in the country? Watch: Inside the White House: The Situation Room: http:\/\/t.co\/FkG4xPmW",
  "id" : 258683497521233920,
  "created_at" : "2012-10-17 21:38:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NCSAM",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/jkyp7L90",
      "expanded_url" : "http:\/\/on.wh.gov\/9u8Rwk",
      "display_url" : "on.wh.gov\/9u8Rwk"
    } ]
  },
  "geo" : { },
  "id_str" : "258607472728739841",
  "text" : "It's National Cyber Security Awareness Month. Make sure you check out these tips to help you stay safe online: http:\/\/t.co\/jkyp7L90 #NCSAM",
  "id" : 258607472728739841,
  "created_at" : "2012-10-17 16:36:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Brooklyn Brewery",
      "screen_name" : "BrooklynBrewery",
      "indices" : [ 3, 19 ],
      "id_str" : "24126361",
      "id" : 24126361
    }, {
      "name" : "Garrett Oliver",
      "screen_name" : "GarrettOliver",
      "indices" : [ 29, 43 ],
      "id_str" : "214083142",
      "id" : 214083142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhiteHouse",
      "indices" : [ 55, 66 ]
    }, {
      "text" : "homebrew",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258573233765367808",
  "text" : "RT @BrooklynBrewery: Our man @GarrettOliver tastes the #WhiteHouse #homebrew. The verdict? It's a beer we can all believe in. http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Garrett Oliver",
        "screen_name" : "GarrettOliver",
        "indices" : [ 8, 22 ],
        "id_str" : "214083142",
        "id" : 214083142
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhiteHouse",
        "indices" : [ 34, 45 ]
      }, {
        "text" : "homebrew",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/EwIO4XJP",
        "expanded_url" : "http:\/\/nyti.ms\/V6SEW1",
        "display_url" : "nyti.ms\/V6SEW1"
      } ]
    },
    "geo" : { },
    "id_str" : "258566749979557890",
    "text" : "Our man @GarrettOliver tastes the #WhiteHouse #homebrew. The verdict? It's a beer we can all believe in. http:\/\/t.co\/EwIO4XJP",
    "id" : 258566749979557890,
    "created_at" : "2012-10-17 13:54:51 +0000",
    "user" : {
      "name" : "The Brooklyn Brewery",
      "screen_name" : "BrooklynBrewery",
      "protected" : false,
      "id_str" : "24126361",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656862574873595905\/GTXwgkYG_normal.png",
      "id" : 24126361,
      "verified" : true
    }
  },
  "id" : 258573233765367808,
  "created_at" : "2012-10-17 14:20:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "Feed the Future",
      "screen_name" : "FeedtheFuture",
      "indices" : [ 44, 58 ],
      "id_str" : "441938188",
      "id" : 441938188
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hunger",
      "indices" : [ 97, 104 ]
    }, {
      "text" : "WFD2012",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/riEOzJX0",
      "expanded_url" : "http:\/\/youtu.be\/8yQExUeIWN0",
      "display_url" : "youtu.be\/8yQExUeIWN0"
    } ]
  },
  "geo" : { },
  "id_str" : "258280342916562945",
  "text" : "RT @StateDept: On World Food Day, learn how @FeedtheFuture is working to turn the tide on global #hunger: http:\/\/t.co\/riEOzJX0. #WFD2012",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Feed the Future",
        "screen_name" : "FeedtheFuture",
        "indices" : [ 29, 43 ],
        "id_str" : "441938188",
        "id" : 441938188
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hunger",
        "indices" : [ 82, 89 ]
      }, {
        "text" : "WFD2012",
        "indices" : [ 113, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/riEOzJX0",
        "expanded_url" : "http:\/\/youtu.be\/8yQExUeIWN0",
        "display_url" : "youtu.be\/8yQExUeIWN0"
      } ]
    },
    "geo" : { },
    "id_str" : "258242017052721152",
    "text" : "On World Food Day, learn how @FeedtheFuture is working to turn the tide on global #hunger: http:\/\/t.co\/riEOzJX0. #WFD2012",
    "id" : 258242017052721152,
    "created_at" : "2012-10-16 16:24:29 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 258280342916562945,
  "created_at" : "2012-10-16 18:56:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258233242216443904",
  "text" : "RT @VP: PHOTO: Remembering Sen. Arlen Specter today. VP &amp; Sen. Specter talk as they ride the train to Philadelphia, 2\/27\/09. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/258230978974216192\/photo\/1",
        "indices" : [ 121, 141 ],
        "url" : "http:\/\/t.co\/2BKaahTb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A5VrtQ0CYAAix2N.jpg",
        "id_str" : "258230978995183616",
        "id" : 258230978995183616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5VrtQ0CYAAix2N.jpg",
        "sizes" : [ {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2BKaahTb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258230978974216192",
    "text" : "PHOTO: Remembering Sen. Arlen Specter today. VP &amp; Sen. Specter talk as they ride the train to Philadelphia, 2\/27\/09. http:\/\/t.co\/2BKaahTb",
    "id" : 258230978974216192,
    "created_at" : "2012-10-16 15:40:38 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 258233242216443904,
  "created_at" : "2012-10-16 15:49:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/258197710740541440\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/og62PC99",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5VNcy8CUAAKeyp.jpg",
      "id_str" : "258197710748930048",
      "id" : 258197710748930048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5VNcy8CUAAKeyp.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/og62PC99"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258197710740541440",
  "text" : "Photo of the day: President Obama walks w\/ Chief of Staff Jack Lew during a break from debate prep in Williamsburg, Va. http:\/\/t.co\/og62PC99",
  "id" : 258197710740541440,
  "created_at" : "2012-10-16 13:28:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PowerofWe",
      "indices" : [ 56, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/VY2G4MdM",
      "expanded_url" : "http:\/\/on.wh.gov\/4DcPTl",
      "display_url" : "on.wh.gov\/4DcPTl"
    } ]
  },
  "geo" : { },
  "id_str" : "258004429368877056",
  "text" : "For Blog Action Day 2012 the White House celebrates the #PowerofWe: http:\/\/t.co\/VY2G4MdM",
  "id" : 258004429368877056,
  "created_at" : "2012-10-16 00:40:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everyday Health",
      "screen_name" : "EverydayHealth",
      "indices" : [ 3, 18 ],
      "id_str" : "17393790",
      "id" : 17393790
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 58, 65 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreastCancer",
      "indices" : [ 40, 53 ]
    }, {
      "text" : "AskSebelius",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/2c7AP0B1",
      "expanded_url" : "http:\/\/on.wh.gov\/eBqEnk",
      "display_url" : "on.wh.gov\/eBqEnk"
    } ]
  },
  "geo" : { },
  "id_str" : "257988431693635584",
  "text" : "MT @EverydayHealth: Send us your Q's on #BreastCancer for @HHSGov Secretary Kathleen Sebelius. Use #AskSebelius http:\/\/t.co\/2c7AP0B1",
  "id" : 257988431693635584,
  "created_at" : "2012-10-15 23:36:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/257952163043631105\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/ivedlmOG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5RuICfCYAAWAC-.jpg",
      "id_str" : "257952163052019712",
      "id" : 257952163052019712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5RuICfCYAAWAC-.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ivedlmOG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257952163043631105",
  "text" : "Photo of the day: President Obama watches the Vice Presidential debate aboard Air Force One with staff, Oct. 11, 2012. http:\/\/t.co\/ivedlmOG",
  "id" : 257952163043631105,
  "created_at" : "2012-10-15 21:12:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blog Action Day",
      "screen_name" : "blogactionday12",
      "indices" : [ 3, 19 ],
      "id_str" : "387690334",
      "id" : 387690334
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 96, 107 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BAD12",
      "indices" : [ 108, 114 ]
    }, {
      "text" : "PowerofWe",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/efRv33Hw",
      "expanded_url" : "http:\/\/wh.gov\/KHUa",
      "display_url" : "wh.gov\/KHUa"
    } ]
  },
  "geo" : { },
  "id_str" : "257941232653848577",
  "text" : "RT @blogactionday12: Blog Action Day: \u201CThe Power of We\u201D | The White House: http:\/\/t.co\/efRv33Hw @whitehouse #BAD12 #PowerofWe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 75, 86 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BAD12",
        "indices" : [ 87, 93 ]
      }, {
        "text" : "PowerofWe",
        "indices" : [ 94, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/efRv33Hw",
        "expanded_url" : "http:\/\/wh.gov\/KHUa",
        "display_url" : "wh.gov\/KHUa"
      } ]
    },
    "geo" : { },
    "id_str" : "257939347746222080",
    "text" : "Blog Action Day: \u201CThe Power of We\u201D | The White House: http:\/\/t.co\/efRv33Hw @whitehouse #BAD12 #PowerofWe",
    "id" : 257939347746222080,
    "created_at" : "2012-10-15 20:21:47 +0000",
    "user" : {
      "name" : "Blog Action Day",
      "screen_name" : "blogactionday12",
      "protected" : false,
      "id_str" : "387690334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648995650751856640\/yDof4lWr_normal.png",
      "id" : 387690334,
      "verified" : false
    }
  },
  "id" : 257941232653848577,
  "created_at" : "2012-10-15 20:29:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/hnZtY5sU",
      "expanded_url" : "http:\/\/on.wh.gov\/FrIsjd",
      "display_url" : "on.wh.gov\/FrIsjd"
    } ]
  },
  "geo" : { },
  "id_str" : "257936220011786240",
  "text" : "President Obama orders US flags to be flown at half-staff in honor of Arlen Specter. Presidential Proclamation: http:\/\/t.co\/hnZtY5sU",
  "id" : 257936220011786240,
  "created_at" : "2012-10-15 20:09:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/257920001762279424\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/WoDagSbB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5RQ4AYCQAAj1MK.jpg",
      "id_str" : "257920001770668032",
      "id" : 257920001770668032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5RQ4AYCQAAj1MK.jpg",
      "sizes" : [ {
        "h" : 245,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 208,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WoDagSbB"
    } ],
    "hashtags" : [ {
      "text" : "WHGarden",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/7lQpRdrc",
      "expanded_url" : "http:\/\/on.wh.gov\/ryLKdy",
      "display_url" : "on.wh.gov\/ryLKdy"
    } ]
  },
  "geo" : { },
  "id_str" : "257920001762279424",
  "text" : "Check out pics from the #WHGarden tours this weekend: http:\/\/t.co\/7lQpRdrc Including this one of the Kitchen Garden: http:\/\/t.co\/WoDagSbB",
  "id" : 257920001762279424,
  "created_at" : "2012-10-15 19:04:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wildlife",
      "indices" : [ 29, 38 ]
    }, {
      "text" : "refugeweek",
      "indices" : [ 39, 50 ]
    }, {
      "text" : "Becharof",
      "indices" : [ 76, 85 ]
    }, {
      "text" : "Alaska",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/ZR6LMGgK",
      "expanded_url" : "http:\/\/instagr.am\/p\/Qzx7Brgu8i\/",
      "display_url" : "instagr.am\/p\/Qzx7Brgu8i\/"
    } ]
  },
  "geo" : { },
  "id_str" : "257893627777400833",
  "text" : "RT @Interior: Happy National #Wildlife #refugeweek! Here's a cool shot from #Becharof NWR in #Alaska. http:\/\/t.co\/ZR6LMGgK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Wildlife",
        "indices" : [ 15, 24 ]
      }, {
        "text" : "refugeweek",
        "indices" : [ 25, 36 ]
      }, {
        "text" : "Becharof",
        "indices" : [ 62, 71 ]
      }, {
        "text" : "Alaska",
        "indices" : [ 79, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/ZR6LMGgK",
        "expanded_url" : "http:\/\/instagr.am\/p\/Qzx7Brgu8i\/",
        "display_url" : "instagr.am\/p\/Qzx7Brgu8i\/"
      } ]
    },
    "geo" : { },
    "id_str" : "257877658715688961",
    "text" : "Happy National #Wildlife #refugeweek! Here's a cool shot from #Becharof NWR in #Alaska. http:\/\/t.co\/ZR6LMGgK",
    "id" : 257877658715688961,
    "created_at" : "2012-10-15 16:16:39 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 257893627777400833,
  "created_at" : "2012-10-15 17:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/T4txz0sc",
      "expanded_url" : "http:\/\/on.wh.gov\/Aur6tJ",
      "display_url" : "on.wh.gov\/Aur6tJ"
    } ]
  },
  "geo" : { },
  "id_str" : "257643013700980736",
  "text" : "\"Arlen Specter was always a fighter.\"-President Obama Full statement on the passing of Arlen Specter: http:\/\/t.co\/T4txz0sc",
  "id" : 257643013700980736,
  "created_at" : "2012-10-15 00:44:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257636654511190016",
  "text" : "RT @VP: Our Nation has lost a dedicated public servant who served his country with strength, grit and determination. \u2013VP on Sen. Arlen S ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257612753152405504",
    "text" : "Our Nation has lost a dedicated public servant who served his country with strength, grit and determination. \u2013VP on Sen. Arlen Specter",
    "id" : 257612753152405504,
    "created_at" : "2012-10-14 22:44:01 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 257636654511190016,
  "created_at" : "2012-10-15 00:18:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eden Joyner",
      "screen_name" : "edenjoyner",
      "indices" : [ 0, 11 ],
      "id_str" : "52187422",
      "id" : 52187422
    }, {
      "name" : "Stefanie L.J. Vestal",
      "screen_name" : "SLJV13",
      "indices" : [ 12, 19 ],
      "id_str" : "361679341",
      "id" : 361679341
    }, {
      "name" : "Jason Walker",
      "screen_name" : "stumpy_jason",
      "indices" : [ 20, 33 ],
      "id_str" : "864821748",
      "id" : 864821748
    }, {
      "name" : "Naomi Amaha",
      "screen_name" : "njamaha",
      "indices" : [ 34, 42 ],
      "id_str" : "21172109",
      "id" : 21172109
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Storify",
      "indices" : [ 68, 76 ]
    }, {
      "text" : "WHGarden",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/r3xOv28v",
      "expanded_url" : "http:\/\/sfy.co\/jATS",
      "display_url" : "sfy.co\/jATS"
    } ]
  },
  "geo" : { },
  "id_str" : "257480182867300352",
  "in_reply_to_user_id" : 52187422,
  "text" : "@edenjoyner @SLJV13 @stumpy_jason @njamaha You've been quoted in my #Storify story \"Fall #WHGarden Tour: Your Photos\" http:\/\/t.co\/r3xOv28v\u00A0",
  "id" : 257480182867300352,
  "created_at" : "2012-10-14 13:57:14 +0000",
  "in_reply_to_screen_name" : "edenjoyner",
  "in_reply_to_user_id_str" : "52187422",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Jallifier",
      "screen_name" : "maxjallifier",
      "indices" : [ 0, 13 ],
      "id_str" : "144824839",
      "id" : 144824839
    }, {
      "name" : "Meghan Winch",
      "screen_name" : "WinchMD",
      "indices" : [ 14, 22 ],
      "id_str" : "860203962",
      "id" : 860203962
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Storify",
      "indices" : [ 48, 56 ]
    }, {
      "text" : "WHGarden",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/r3xOv28v",
      "expanded_url" : "http:\/\/sfy.co\/jATS",
      "display_url" : "sfy.co\/jATS"
    } ]
  },
  "geo" : { },
  "id_str" : "257232884224651264",
  "in_reply_to_user_id" : 144824839,
  "text" : "@maxjallifier @WinchMD You've been quoted in my #Storify story \"Fall #WHGarden Tour: Your Photos\" http:\/\/t.co\/r3xOv28v",
  "id" : 257232884224651264,
  "created_at" : "2012-10-13 21:34:33 +0000",
  "in_reply_to_screen_name" : "maxjallifier",
  "in_reply_to_user_id_str" : "144824839",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 49, 56 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257156289883430914",
  "text" : "RT @DeptofDefense: Please join us in wishing the @USNavy a very Happy 237th Birthday today!",
  "id" : 257156289883430914,
  "created_at" : "2012-10-13 16:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lanaly Sy Cabalo",
      "screen_name" : "cabalo02",
      "indices" : [ 0, 9 ],
      "id_str" : "55097422",
      "id" : 55097422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Storify",
      "indices" : [ 35, 43 ]
    }, {
      "text" : "WHGarden",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/r3xOv28v",
      "expanded_url" : "http:\/\/sfy.co\/jATS",
      "display_url" : "sfy.co\/jATS"
    } ]
  },
  "geo" : { },
  "id_str" : "257144080121856000",
  "in_reply_to_user_id" : 55097422,
  "text" : "@cabalo02 You've been quoted in my #Storify story \"Fall #WHGarden Tour: Your Photos\" http:\/\/t.co\/r3xOv28v",
  "id" : 257144080121856000,
  "created_at" : "2012-10-13 15:41:40 +0000",
  "in_reply_to_screen_name" : "cabalo02",
  "in_reply_to_user_id_str" : "55097422",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/6angF027",
      "expanded_url" : "http:\/\/on.wh.gov\/NYfDBk",
      "display_url" : "on.wh.gov\/NYfDBk"
    } ]
  },
  "geo" : { },
  "id_str" : "257138948231540736",
  "text" : "'We refused to let Detroit go bankrupt. We bet on American workers...and that bet is paying of.\" -President Obama http:\/\/t.co\/6angF027",
  "id" : 257138948231540736,
  "created_at" : "2012-10-13 15:21:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Reho",
      "screen_name" : "SamanthaReho",
      "indices" : [ 0, 13 ],
      "id_str" : "15004436",
      "id" : 15004436
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Storify",
      "indices" : [ 39, 47 ]
    }, {
      "text" : "WHGarden",
      "indices" : [ 60, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/r3xOv28v",
      "expanded_url" : "http:\/\/sfy.co\/jATS",
      "display_url" : "sfy.co\/jATS"
    } ]
  },
  "geo" : { },
  "id_str" : "257136228439293954",
  "in_reply_to_user_id" : 15004436,
  "text" : "@SamanthaReho You've been quoted in my #Storify story \"Fall #WHGarden Tour: Your Photos\" http:\/\/t.co\/r3xOv28v",
  "id" : 257136228439293954,
  "created_at" : "2012-10-13 15:10:28 +0000",
  "in_reply_to_screen_name" : "SamanthaReho",
  "in_reply_to_user_id_str" : "15004436",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amanda Althoff",
      "screen_name" : "aasmiley89",
      "indices" : [ 0, 11 ],
      "id_str" : "466154636",
      "id" : 466154636
    }, {
      "name" : "FEKD",
      "screen_name" : "packersri",
      "indices" : [ 12, 22 ],
      "id_str" : "245975971",
      "id" : 245975971
    }, {
      "name" : "Thomas Skaff",
      "screen_name" : "skaffmania",
      "indices" : [ 23, 34 ],
      "id_str" : "299402946",
      "id" : 299402946
    }, {
      "name" : "Amy Rose Sisk",
      "screen_name" : "amyrsisk",
      "indices" : [ 35, 44 ],
      "id_str" : "24483933",
      "id" : 24483933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Storify",
      "indices" : [ 70, 78 ]
    }, {
      "text" : "WHGarden",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/r3xOv28v",
      "expanded_url" : "http:\/\/sfy.co\/jATS",
      "display_url" : "sfy.co\/jATS"
    } ]
  },
  "geo" : { },
  "id_str" : "257136228506423296",
  "in_reply_to_user_id" : 466154636,
  "text" : "@aasmiley89 @packersri @skaffmania @amyrsisk You've been quoted in my #Storify story \"Fall #WHGarden Tour: Your Photos\" http:\/\/t.co\/r3xOv28v",
  "id" : 257136228506423296,
  "created_at" : "2012-10-13 15:10:28 +0000",
  "in_reply_to_screen_name" : "aasmiley89",
  "in_reply_to_user_id_str" : "466154636",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/257114111652028417\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/1DG68SVo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5Fz7BxCYAEEw3z.jpg",
      "id_str" : "257114111660417025",
      "id" : 257114111660417025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5Fz7BxCYAEEw3z.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1DG68SVo"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/5ebpMYcF",
      "expanded_url" : "http:\/\/on.wh.gov\/cOiKdo",
      "display_url" : "on.wh.gov\/cOiKdo"
    } ]
  },
  "geo" : { },
  "id_str" : "257114111652028417",
  "text" : "Photo gallery: Behind the scenes in Sept. 2012: http:\/\/t.co\/5ebpMYcF Including First Dog Bo hanging out on the WH lawn http:\/\/t.co\/1DG68SVo",
  "id" : 257114111652028417,
  "created_at" : "2012-10-13 13:42:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/NKLIyGGH",
      "expanded_url" : "http:\/\/on.wh.gov\/fSjrQi",
      "display_url" : "on.wh.gov\/fSjrQi"
    } ]
  },
  "geo" : { },
  "id_str" : "256933642306195456",
  "text" : "Go behind the scenes w\/ WH Curator Bill Allman &amp; see fire damage left over from the White House Fire of 1814. Watch: http:\/\/t.co\/NKLIyGGH",
  "id" : 256933642306195456,
  "created_at" : "2012-10-13 01:45:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/8yNciR1S",
      "expanded_url" : "http:\/\/on.wh.gov\/3lJzqI",
      "display_url" : "on.wh.gov\/3lJzqI"
    } ]
  },
  "geo" : { },
  "id_str" : "256837535051964416",
  "text" : "Visiting D.C. this weekend? Get tickets for the 2012 Fall Garden Tours at the White House this Sat &amp; Sun. More info: http:\/\/t.co\/8yNciR1S",
  "id" : 256837535051964416,
  "created_at" : "2012-10-12 19:23:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/256783958027669504\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/RCiu1Vmr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5BHpjrCEAALMUO.jpg",
      "id_str" : "256783958036058112",
      "id" : 256783958036058112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5BHpjrCEAALMUO.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RCiu1Vmr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256783958027669504",
  "text" : "Photo of the day: President Obama walks with Senior Advisor David Plouffe along the Colonnade of the White House. http:\/\/t.co\/RCiu1Vmr",
  "id" : 256783958027669504,
  "created_at" : "2012-10-12 15:50:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/2oBzWX7Y",
      "expanded_url" : "http:\/\/on.wh.gov\/NXT2sx",
      "display_url" : "on.wh.gov\/NXT2sx"
    } ]
  },
  "geo" : { },
  "id_str" : "256768558518894593",
  "text" : "West Wing Week 10\/12\/12: Your guide to everything that happened this week at 1600 Penn. Watch: http:\/\/t.co\/2oBzWX7Y",
  "id" : 256768558518894593,
  "created_at" : "2012-10-12 14:49:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/si1hL74p",
      "expanded_url" : "http:\/\/bit.ly\/SQ0jup",
      "display_url" : "bit.ly\/SQ0jup"
    } ]
  },
  "geo" : { },
  "id_str" : "256768140808163328",
  "text" : "RT @petesouza: New White House photos from Sept: http:\/\/t.co\/si1hL74p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/si1hL74p",
        "expanded_url" : "http:\/\/bit.ly\/SQ0jup",
        "display_url" : "bit.ly\/SQ0jup"
      } ]
    },
    "geo" : { },
    "id_str" : "256758264941928449",
    "text" : "New White House photos from Sept: http:\/\/t.co\/si1hL74p",
    "id" : 256758264941928449,
    "created_at" : "2012-10-12 14:08:35 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 256768140808163328,
  "created_at" : "2012-10-12 14:47:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayOfTheGirl",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/wnNJ7PMw",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/10\/11\/celebrating-girl-power",
      "display_url" : "whitehouse.gov\/blog\/2012\/10\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256510998591205376",
  "text" : "On International #DayOfTheGirl, celebrating girl power at the White House: http:\/\/t.co\/wnNJ7PMw",
  "id" : 256510998591205376,
  "created_at" : "2012-10-11 21:46:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/XEgfUuGu",
      "expanded_url" : "http:\/\/on.wh.gov\/yDukMb",
      "display_url" : "on.wh.gov\/yDukMb"
    } ]
  },
  "geo" : { },
  "id_str" : "256507071133007873",
  "text" : "Want to stay connected? Sign up for email updates from President Obama and other senior White House officials: http:\/\/t.co\/XEgfUuGu",
  "id" : 256507071133007873,
  "created_at" : "2012-10-11 21:30:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 43, 49 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayoftheGirl",
      "indices" : [ 18, 31 ]
    }, {
      "text" : "women",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/nZEPnQ5L",
      "expanded_url" : "http:\/\/on.wh.gov\/5YUE4z",
      "display_url" : "on.wh.gov\/5YUE4z"
    } ]
  },
  "geo" : { },
  "id_str" : "256479455835484161",
  "text" : "RT @StateDept: On #DayoftheGirl, learn how @USAID works to advance gender equality and promote #women's empowerment: http:\/\/t.co\/nZEPnQ5L",
  "id" : 256479455835484161,
  "created_at" : "2012-10-11 19:40:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 13, 22 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayOfTheGirl",
      "indices" : [ 57, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/gfIhhVXH",
      "expanded_url" : "http:\/\/at.wh.gov\/eplOl",
      "display_url" : "at.wh.gov\/eplOl"
    } ]
  },
  "geo" : { },
  "id_str" : "256477521422450688",
  "text" : "Statement by @PressSec on the first annual International #DayOfTheGirl: http:\/\/t.co\/gfIhhVXH",
  "id" : 256477521422450688,
  "created_at" : "2012-10-11 19:33:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "women",
      "indices" : [ 45, 51 ]
    }, {
      "text" : "girls",
      "indices" : [ 58, 64 ]
    }, {
      "text" : "DayOftheGirl",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/18Vnf0Fd",
      "expanded_url" : "http:\/\/ow.ly\/eoHvF",
      "display_url" : "ow.ly\/eoHvF"
    } ]
  },
  "geo" : { },
  "id_str" : "256445105194532864",
  "text" : "RT @USAID: Photo Gallery: Catch a glimpse of #women &amp; #girls around the world http:\/\/t.co\/18Vnf0Fd #DayOftheGirl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "women",
        "indices" : [ 34, 40 ]
      }, {
        "text" : "girls",
        "indices" : [ 47, 53 ]
      }, {
        "text" : "DayOftheGirl",
        "indices" : [ 92, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/18Vnf0Fd",
        "expanded_url" : "http:\/\/ow.ly\/eoHvF",
        "display_url" : "ow.ly\/eoHvF"
      } ]
    },
    "geo" : { },
    "id_str" : "256443304663719937",
    "text" : "Photo Gallery: Catch a glimpse of #women &amp; #girls around the world http:\/\/t.co\/18Vnf0Fd #DayOftheGirl",
    "id" : 256443304663719937,
    "created_at" : "2012-10-11 17:17:02 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 256445105194532864,
  "created_at" : "2012-10-11 17:24:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 10, 16 ],
      "id_str" : "36683668",
      "id" : 36683668
    }, {
      "name" : "Raj Shah",
      "screen_name" : "rajshah",
      "indices" : [ 23, 31 ],
      "id_str" : "232193350",
      "id" : 232193350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GenPrevTech",
      "indices" : [ 43, 55 ]
    }, {
      "text" : "technology",
      "indices" : [ 77, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/YeW90UzP",
      "expanded_url" : "http:\/\/on.wh.gov\/UTdU82",
      "display_url" : "on.wh.gov\/UTdU82"
    } ]
  },
  "geo" : { },
  "id_str" : "256422170966769664",
  "text" : "Yesterday @USAID Chief @RajShah launched a #GenPrevTech Challenge to harness #technology to prevent mass atrocities: http:\/\/t.co\/YeW90UzP",
  "id" : 256422170966769664,
  "created_at" : "2012-10-11 15:53:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/256406773936820226\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/e6MC26ka",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A47wmjcCEAA1iJ5.jpg",
      "id_str" : "256406773945208832",
      "id" : 256406773945208832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A47wmjcCEAA1iJ5.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/e6MC26ka"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256406773936820226",
  "text" : "Photo: President Obama talks w\/ Alan Krueger, CEA Chair &amp; Chief of Staff Jack Lew in the Oval Office: http:\/\/t.co\/e6MC26ka",
  "id" : 256406773936820226,
  "created_at" : "2012-10-11 14:51:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Mission to the UN",
      "screen_name" : "USUN",
      "indices" : [ 3, 8 ],
      "id_str" : "249677516",
      "id" : 249677516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayoftheGirl",
      "indices" : [ 43, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256399590553690113",
  "text" : "RT @USUN: TODAY we celebrate International #DayoftheGirl. Read about U.S. initiatives to fight for the status of girls worldwide: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DayoftheGirl",
        "indices" : [ 33, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/GCaZ322D",
        "expanded_url" : "http:\/\/go.usa.gov\/YkBT",
        "display_url" : "go.usa.gov\/YkBT"
      } ]
    },
    "geo" : { },
    "id_str" : "256397855705673728",
    "text" : "TODAY we celebrate International #DayoftheGirl. Read about U.S. initiatives to fight for the status of girls worldwide: http:\/\/t.co\/GCaZ322D",
    "id" : 256397855705673728,
    "created_at" : "2012-10-11 14:16:27 +0000",
    "user" : {
      "name" : "US Mission to the UN",
      "screen_name" : "USUN",
      "protected" : false,
      "id_str" : "249677516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616236749149241345\/Dm-anuiC_normal.jpg",
      "id" : 249677516,
      "verified" : true
    }
  },
  "id" : 256399590553690113,
  "created_at" : "2012-10-11 14:23:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecClinton",
      "indices" : [ 22, 33 ]
    }, {
      "text" : "DayOfTheGirl",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/7tw4YgUr",
      "expanded_url" : "http:\/\/flic.kr\/p\/dizbKC",
      "display_url" : "flic.kr\/p\/dizbKC"
    } ]
  },
  "geo" : { },
  "id_str" : "256151314915012608",
  "text" : "RT @StateDept: Photo: #SecClinton meets with Archbishop Desmond Tutu http:\/\/t.co\/7tw4YgUr #DayOfTheGirl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecClinton",
        "indices" : [ 7, 18 ]
      }, {
        "text" : "DayOfTheGirl",
        "indices" : [ 75, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/7tw4YgUr",
        "expanded_url" : "http:\/\/flic.kr\/p\/dizbKC",
        "display_url" : "flic.kr\/p\/dizbKC"
      } ]
    },
    "geo" : { },
    "id_str" : "256149987413606400",
    "text" : "Photo: #SecClinton meets with Archbishop Desmond Tutu http:\/\/t.co\/7tw4YgUr #DayOfTheGirl",
    "id" : 256149987413606400,
    "created_at" : "2012-10-10 21:51:30 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 256151314915012608,
  "created_at" : "2012-10-10 21:56:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Rachael Ray",
      "screen_name" : "rachael_ray",
      "indices" : [ 101, 113 ],
      "id_str" : "2214904466",
      "id" : 2214904466
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "recipe",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256132642053963777",
  "text" : "RT @VP: Our family loves to get together for Sunday dinners. Our favorite chicken parm #recipe is in @rachael_ray mag: http:\/\/t.co\/1ZYO7 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachael Ray",
        "screen_name" : "rachael_ray",
        "indices" : [ 93, 105 ],
        "id_str" : "2214904466",
        "id" : 2214904466
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "recipe",
        "indices" : [ 79, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/1ZYO7G6W",
        "expanded_url" : "http:\/\/www.rachaelraymag.com\/recipe\/jill-bidens-chicken-parm\/",
        "display_url" : "rachaelraymag.com\/recipe\/jill-bi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "256103860274356224",
    "text" : "Our family loves to get together for Sunday dinners. Our favorite chicken parm #recipe is in @rachael_ray mag: http:\/\/t.co\/1ZYO7G6W \u2013Dr. B",
    "id" : 256103860274356224,
    "created_at" : "2012-10-10 18:48:13 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 256132642053963777,
  "created_at" : "2012-10-10 20:42:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/55PralpO",
      "expanded_url" : "http:\/\/on.wh.gov\/JKiJIy",
      "display_url" : "on.wh.gov\/JKiJIy"
    } ]
  },
  "geo" : { },
  "id_str" : "256103875898130432",
  "text" : "Always wanted to visit the White House?  Check out our online interactive tour: http:\/\/t.co\/55PralpO",
  "id" : 256103875898130432,
  "created_at" : "2012-10-10 18:48:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/256083314685915136\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/KurX2VgF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A43Kav0CMAA5OqI.jpg",
      "id_str" : "256083314690109440",
      "id" : 256083314690109440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A43Kav0CMAA5OqI.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KurX2VgF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256083314685915136",
  "text" : "Photo: President Obama views the office of C\u00E9sar Ch\u00E1vez before the dedication of the C\u00E9sar E. Ch\u00E1vez National Monument http:\/\/t.co\/KurX2VgF",
  "id" : 256083314685915136,
  "created_at" : "2012-10-10 17:26:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 33, 43 ],
      "id_str" : "200176600",
      "id" : 200176600
    }, {
      "name" : "iTriage",
      "screen_name" : "iTriage",
      "indices" : [ 50, 58 ],
      "id_str" : "23453611",
      "id" : 23453611
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "innovategov",
      "indices" : [ 110, 122 ]
    }, {
      "text" : "opendata",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256083306251173888",
  "text" : "RT @macon44: Full service USCTO: @todd_park codes @itriage , integrating a CDC symptoms data set into the app #innovategov #opendata htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Todd Park",
        "screen_name" : "todd_park",
        "indices" : [ 20, 30 ],
        "id_str" : "200176600",
        "id" : 200176600
      }, {
        "name" : "iTriage",
        "screen_name" : "iTriage",
        "indices" : [ 37, 45 ],
        "id_str" : "23453611",
        "id" : 23453611
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/256076454595526656\/photo\/1",
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/1xvu2EBl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A43ELcACAAAJxbs.jpg",
        "id_str" : "256076454603915264",
        "id" : 256076454603915264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A43ELcACAAAJxbs.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/1xvu2EBl"
      } ],
      "hashtags" : [ {
        "text" : "innovategov",
        "indices" : [ 97, 109 ]
      }, {
        "text" : "opendata",
        "indices" : [ 110, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 39.750867, -105.001959 ]
    },
    "id_str" : "256076454595526656",
    "text" : "Full service USCTO: @todd_park codes @itriage , integrating a CDC symptoms data set into the app #innovategov #opendata http:\/\/t.co\/1xvu2EBl",
    "id" : 256076454595526656,
    "created_at" : "2012-10-10 16:59:19 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 256083306251173888,
  "created_at" : "2012-10-10 17:26:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "dukeresearch",
      "screen_name" : "dukeresearch",
      "indices" : [ 121, 134 ],
      "id_str" : "18222462",
      "id" : 18222462
    }, {
      "name" : "Stanford University",
      "screen_name" : "Stanford",
      "indices" : [ 135, 144 ],
      "id_str" : "18036441",
      "id" : 18036441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nobel",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256064853347803136",
  "text" : "MT @whitehouseostp: Congrats to Americans Robert Lefkowitz &amp; Brian Kobilka for their #Nobel Prize wins in Chemistry! @dukeresearch @Stanford",
  "id" : 256064853347803136,
  "created_at" : "2012-10-10 16:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/255815686725705728\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/4FptKcyU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4zXAv_CIAAvxTo.jpg",
      "id_str" : "255815686734094336",
      "id" : 255815686734094336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4zXAv_CIAAvxTo.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4FptKcyU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/PHJqyXaC",
      "expanded_url" : "http:\/\/on.wh.gov\/dMsIlB",
      "display_url" : "on.wh.gov\/dMsIlB"
    } ]
  },
  "geo" : { },
  "id_str" : "255815686725705728",
  "text" : "Happy 4th Birthday, Bo! Check out some highlights from his busy year at 1600 Penn: http:\/\/t.co\/PHJqyXaC Pic: http:\/\/t.co\/4FptKcyU",
  "id" : 255815686725705728,
  "created_at" : "2012-10-09 23:43:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 28, 38 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/5bUm8SQK",
      "expanded_url" : "http:\/\/on.wh.gov\/7L1GeQ",
      "display_url" : "on.wh.gov\/7L1GeQ"
    } ]
  },
  "geo" : { },
  "id_str" : "255797109327011840",
  "text" : "RT White House photographer @PeteSouza: My slide show of the President's first term: http:\/\/t.co\/5bUm8SQK",
  "id" : 255797109327011840,
  "created_at" : "2012-10-09 22:29:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/255736188747538432\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/3ewJ6U7h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4yOtW7CYAAdOTv.jpg",
      "id_str" : "255736188751732736",
      "id" : 255736188751732736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4yOtW7CYAAdOTv.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/3ewJ6U7h"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/EHggQD8i",
      "expanded_url" : "http:\/\/on.wh.gov\/hCq9jY",
      "display_url" : "on.wh.gov\/hCq9jY"
    } ]
  },
  "geo" : { },
  "id_str" : "255736188747538432",
  "text" : "President Obama announces the establishment of the Cesar E. Chavez National Monument: http:\/\/t.co\/EHggQD8i Pic: http:\/\/t.co\/3ewJ6U7h",
  "id" : 255736188747538432,
  "created_at" : "2012-10-09 18:27:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/effRkjSD",
      "expanded_url" : "http:\/\/on.wh.gov\/wCn7ns",
      "display_url" : "on.wh.gov\/wCn7ns"
    } ]
  },
  "geo" : { },
  "id_str" : "255705322247839746",
  "text" : "WH staffer Julie Rodriguez on what the new national monument honoring her grandfather, Cesar E. Chavez means to her: http:\/\/t.co\/effRkjSD",
  "id" : 255705322247839746,
  "created_at" : "2012-10-09 16:24:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "NIST",
      "screen_name" : "usnistgov",
      "indices" : [ 32, 42 ],
      "id_str" : "46648807",
      "id" : 46648807
    }, {
      "name" : "Nobel Media",
      "screen_name" : "Nobelprize_org",
      "indices" : [ 76, 91 ],
      "id_str" : "2817719635",
      "id" : 2817719635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/tEP29JTu",
      "expanded_url" : "http:\/\/www.nobelprize.org\/nobel_prizes\/physics\/laureates\/2012\/wineland.html",
      "display_url" : "nobelprize.org\/nobel_prizes\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255683947701366784",
  "text" : "RT @whitehouseostp: Congrats to @usnistgov scientist David Wineland for his @Nobelprize_org win in Physics! http:\/\/t.co\/tEP29JTu",
  "id" : 255683947701366784,
  "created_at" : "2012-10-09 14:59:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/HNeTHUsB",
      "expanded_url" : "http:\/\/on.wh.gov\/ziwcHh",
      "display_url" : "on.wh.gov\/ziwcHh"
    } ]
  },
  "geo" : { },
  "id_str" : "255369859486081024",
  "text" : "Starting at 2:15ET on http:\/\/t.co\/HNeTHUsB President Obama announces the establishment of the Cesar E. Chavez National Monument.",
  "id" : 255369859486081024,
  "created_at" : "2012-10-08 18:11:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/7noMidrz",
      "expanded_url" : "http:\/\/on.wh.gov\/1AMC5Y",
      "display_url" : "on.wh.gov\/1AMC5Y"
    } ]
  },
  "geo" : { },
  "id_str" : "255328626831147009",
  "text" : "Today at 2:15ET: President Obama Announces the Establishment of the Cesar E. Chavez National Monument. Watch live: http:\/\/t.co\/7noMidrz",
  "id" : 255328626831147009,
  "created_at" : "2012-10-08 15:27:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iotd",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/bKcliOwX",
      "expanded_url" : "http:\/\/go.nasa.gov\/R8Hu1Z",
      "display_url" : "go.nasa.gov\/R8Hu1Z"
    } ]
  },
  "geo" : { },
  "id_str" : "255137996230250496",
  "text" : "RT @NASA: [Image of the Day] SpaceX Launches for the International Space Station http:\/\/t.co\/bKcliOwX #iotd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iotd",
        "indices" : [ 92, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/bKcliOwX",
        "expanded_url" : "http:\/\/go.nasa.gov\/R8Hu1Z",
        "display_url" : "go.nasa.gov\/R8Hu1Z"
      } ]
    },
    "geo" : { },
    "id_str" : "255137483929563136",
    "text" : "[Image of the Day] SpaceX Launches for the International Space Station http:\/\/t.co\/bKcliOwX #iotd",
    "id" : 255137483929563136,
    "created_at" : "2012-10-08 02:48:11 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 255137996230250496,
  "created_at" : "2012-10-08 02:50:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/Vst7mhyt",
      "expanded_url" : "http:\/\/on.wh.gov\/YjsKzm",
      "display_url" : "on.wh.gov\/YjsKzm"
    } ]
  },
  "geo" : { },
  "id_str" : "254615732418125824",
  "text" : "\"We've made too much progress to return to the policies that got us into this mess in the first place.\"-President Obama http:\/\/t.co\/Vst7mhyt",
  "id" : 254615732418125824,
  "created_at" : "2012-10-06 16:14:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/XY9QSSWZ",
      "expanded_url" : "http:\/\/on.wh.gov\/b0NGpW",
      "display_url" : "on.wh.gov\/b0NGpW"
    } ]
  },
  "geo" : { },
  "id_str" : "254600108191133697",
  "text" : "Weekly Address: Congress Should Keep America Moving Forward http:\/\/t.co\/XY9QSSWZ",
  "id" : 254600108191133697,
  "created_at" : "2012-10-06 15:12:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/Y3QdM5sM",
      "expanded_url" : "http:\/\/on.wh.gov\/ug5UMv",
      "display_url" : "on.wh.gov\/ug5UMv"
    } ]
  },
  "geo" : { },
  "id_str" : "254344487634104321",
  "text" : "West Wing Week 10\/05\/2012: Your behind the scenes guide to everything that happened this week at 1600 Penn. Video: http:\/\/t.co\/Y3QdM5sM",
  "id" : 254344487634104321,
  "created_at" : "2012-10-05 22:17:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/1jM8PsZh",
      "expanded_url" : "http:\/\/on.wh.gov\/UcPexC",
      "display_url" : "on.wh.gov\/UcPexC"
    } ]
  },
  "geo" : { },
  "id_str" : "254328717789241344",
  "text" : "\"He changed the way each of us sees the world.\" -President Obama on the passing of Steve Jobs, Oct. 5, 2011: http:\/\/t.co\/1jM8PsZh",
  "id" : 254328717789241344,
  "created_at" : "2012-10-05 21:14:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Girl Scouts",
      "screen_name" : "girlscouts",
      "indices" : [ 11, 22 ],
      "id_str" : "103018203",
      "id" : 103018203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254296324093116416",
  "text" : "RT @vj44: .@girlscouts Let's begin with fathers whose daughters adore them-they can play key role in inspiring their girls' interest in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Girl Scouts",
        "screen_name" : "girlscouts",
        "indices" : [ 1, 12 ],
        "id_str" : "103018203",
        "id" : 103018203
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 126, 131 ]
      }, {
        "text" : "whchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "254293419227238400",
    "text" : ".@girlscouts Let's begin with fathers whose daughters adore them-they can play key role in inspiring their girls' interest in #STEM. #whchat",
    "id" : 254293419227238400,
    "created_at" : "2012-10-05 18:54:10 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 254296324093116416,
  "created_at" : "2012-10-05 19:05:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Girl Scouts",
      "screen_name" : "girlscouts",
      "indices" : [ 3, 14 ],
      "id_str" : "103018203",
      "id" : 103018203
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 16, 23 ]
    }, {
      "text" : "STEM",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254296260243251200",
  "text" : "RT @girlscouts: #WHChat a question we often hear is \"How do we inspire male mentors to support girl #STEM initiatives?\" What's your take?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "STEM",
        "indices" : [ 84, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "254291810275430401",
    "text" : "#WHChat a question we often hear is \"How do we inspire male mentors to support girl #STEM initiatives?\" What's your take?",
    "id" : 254291810275430401,
    "created_at" : "2012-10-05 18:47:46 +0000",
    "user" : {
      "name" : "Girl Scouts",
      "screen_name" : "girlscouts",
      "protected" : false,
      "id_str" : "103018203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3414110648\/af49e35a3cd3963d75f47e5ab305d421_normal.png",
      "id" : 103018203,
      "verified" : true
    }
  },
  "id" : 254296260243251200,
  "created_at" : "2012-10-05 19:05:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "GirlForward",
      "screen_name" : "GirlForward",
      "indices" : [ 11, 23 ],
      "id_str" : "322983626",
      "id" : 322983626
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 66, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254293500999380992",
  "text" : "RT @vj44: .@GirlForward Our top priorities are domestic violence, #STEM, entrepreneurship, civic &amp; political leadership: http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GirlForward",
        "screen_name" : "GirlForward",
        "indices" : [ 1, 13 ],
        "id_str" : "322983626",
        "id" : 322983626
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 56, 61 ]
      }, {
        "text" : "whchat",
        "indices" : [ 136, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/UY0bbkiz",
        "expanded_url" : "http:\/\/wh.gov\/Ba1Q",
        "display_url" : "wh.gov\/Ba1Q"
      } ]
    },
    "geo" : { },
    "id_str" : "254290749766639616",
    "text" : ".@GirlForward Our top priorities are domestic violence, #STEM, entrepreneurship, civic &amp; political leadership: http:\/\/t.co\/UY0bbkiz #whchat",
    "id" : 254290749766639616,
    "created_at" : "2012-10-05 18:43:33 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 254293500999380992,
  "created_at" : "2012-10-05 18:54:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GirlForward",
      "screen_name" : "GirlForward",
      "indices" : [ 3, 15 ],
      "id_str" : "322983626",
      "id" : 322983626
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 17, 24 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 25, 30 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualFutures",
      "indices" : [ 96, 109 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254293440471371780",
  "text" : "RT @GirlForward: @WHLive @vj44 Are there specific domestic issues facing women &amp; girls that #EqualFutures will focus on? #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 0, 7 ],
        "id_str" : "369505837",
        "id" : 369505837
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 8, 13 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualFutures",
        "indices" : [ 79, 92 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 108, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "254290125478039553",
    "in_reply_to_user_id" : 369505837,
    "text" : "@WHLive @vj44 Are there specific domestic issues facing women &amp; girls that #EqualFutures will focus on? #WHchat",
    "id" : 254290125478039553,
    "created_at" : "2012-10-05 18:41:05 +0000",
    "in_reply_to_screen_name" : "WHLive",
    "in_reply_to_user_id_str" : "369505837",
    "user" : {
      "name" : "GirlForward",
      "screen_name" : "GirlForward",
      "protected" : false,
      "id_str" : "322983626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717439507184766976\/-9AGIwuo_normal.jpg",
      "id" : 322983626,
      "verified" : false
    }
  },
  "id" : 254293440471371780,
  "created_at" : "2012-10-05 18:54:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 15, 20 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 139, 146 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254286996002988032",
  "text" : "Happening now: @vj44 &amp; Samantha Power answer your questions about empowering women at home &amp; abroad. Ask with #WHChat &amp; follow @WHLive.",
  "id" : 254286996002988032,
  "created_at" : "2012-10-05 18:28:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 105, 110 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 138, 145 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254260647867588609",
  "text" : "Starting at 2:30ET: Q&amp;A on empowering women &amp; girls at home &amp; abroad w\/ Samantha Power &amp; @vj44. Ask Qs w\/ #WHChat Follow: @WHLive",
  "id" : 254260647867588609,
  "created_at" : "2012-10-05 16:43:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/254244873509691392\/photo\/1",
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/rFeIDy86",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4dCXYwCYAAFO2Y.jpg",
      "id_str" : "254244873518080000",
      "id" : 254244873518080000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4dCXYwCYAAFO2Y.jpg",
      "sizes" : [ {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      } ],
      "display_url" : "pic.twitter.com\/rFeIDy86"
    } ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 9, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/tUXlycip",
      "expanded_url" : "http:\/\/on.wh.gov\/XHbrnS",
      "display_url" : "on.wh.gov\/XHbrnS"
    } ]
  },
  "geo" : { },
  "id_str" : "254244873509691392",
  "text" : "New jobs #s: 5.2M new jobs over 31 months &amp; unemployment falls to 7.8%. More work to do. http:\/\/t.co\/tUXlycip Chart: http:\/\/t.co\/rFeIDy86",
  "id" : 254244873509691392,
  "created_at" : "2012-10-05 15:41:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 61, 66 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 136, 156 ],
      "url" : "http:\/\/t.co\/GwmXelaM",
      "expanded_url" : "http:\/\/on.wh.gov\/mvco1M",
      "display_url" : "on.wh.gov\/mvco1M"
    } ]
  },
  "geo" : { },
  "id_str" : "254218085844783104",
  "text" : "Have Q's on ways to empower women at home &amp; abroad?  Ask @vj44 &amp; Samantha Power now w\/ #WHChat &amp; join the Q&amp;A @ 2:30ET: http:\/\/t.co\/GwmXelaM",
  "id" : 254218085844783104,
  "created_at" : "2012-10-05 13:54:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/254006859072172032\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/yReoBwtH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4Zp5H4CcAElJag.jpg",
      "id_str" : "254006859080560641",
      "id" : 254006859080560641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4Zp5H4CcAElJag.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yReoBwtH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/Ekckx3Ui",
      "expanded_url" : "http:\/\/on.wh.gov\/cuz5N3",
      "display_url" : "on.wh.gov\/cuz5N3"
    } ]
  },
  "geo" : { },
  "id_str" : "254006859072172032",
  "text" : "Dr. Biden launches \"Operation Educate the Educators\" to help teachers teach military kids: \nhttp:\/\/t.co\/Ekckx3Ui Pic: http:\/\/t.co\/yReoBwtH",
  "id" : 254006859072172032,
  "created_at" : "2012-10-04 23:55:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/95TCNjIM",
      "expanded_url" : "http:\/\/on.wh.gov\/KyixO6",
      "display_url" : "on.wh.gov\/KyixO6"
    } ]
  },
  "geo" : { },
  "id_str" : "253990504927203328",
  "text" : "It's National Energy Action Month. Watch &amp; learn about the President's all-of-the-above plan for energy independence: http:\/\/t.co\/95TCNjIM",
  "id" : 253990504927203328,
  "created_at" : "2012-10-04 22:50:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 72, 77 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualFutures",
      "indices" : [ 43, 56 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 136, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/UW4cjzNc",
      "expanded_url" : "http:\/\/on.wh.gov\/mhONHu",
      "display_url" : "on.wh.gov\/mhONHu"
    } ]
  },
  "geo" : { },
  "id_str" : "253919974832345088",
  "text" : "On 10\/5 at 2:30ET: Join WH Office Hours on #EqualFutures for women with @vj44 &amp; Samantha Power: http:\/\/t.co\/UW4cjzNc Ask Q's now w\/ #WHChat",
  "id" : 253919974832345088,
  "created_at" : "2012-10-04 18:10:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/253559774287900673\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/oNgRlj4O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4TTRXRCMAAoHqT.jpg",
      "id_str" : "253559774296289280",
      "id" : 253559774296289280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4TTRXRCMAAoHqT.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oNgRlj4O"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/Ne2VFLH6",
      "expanded_url" : "http:\/\/on.wh.gov\/UveJRt",
      "display_url" : "on.wh.gov\/UveJRt"
    } ]
  },
  "geo" : { },
  "id_str" : "253559774287900673",
  "text" : "Photo of the day: President Obama views the Hoover Dam during a visit, Oct. 2, 2012. More pics: http:\/\/t.co\/Ne2VFLH6 http:\/\/t.co\/oNgRlj4O",
  "id" : 253559774287900673,
  "created_at" : "2012-10-03 18:18:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/qb4YuRSB",
      "expanded_url" : "http:\/\/1.usa.gov\/Qyn3Lv",
      "display_url" : "1.usa.gov\/Qyn3Lv"
    } ]
  },
  "geo" : { },
  "id_str" : "253325555791982592",
  "text" : "RT @petesouza: New photo of President Obama at the Hoover Dam: http:\/\/t.co\/qb4YuRSB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/qb4YuRSB",
        "expanded_url" : "http:\/\/1.usa.gov\/Qyn3Lv",
        "display_url" : "1.usa.gov\/Qyn3Lv"
      } ]
    },
    "geo" : { },
    "id_str" : "253321888091213824",
    "text" : "New photo of President Obama at the Hoover Dam: http:\/\/t.co\/qb4YuRSB",
    "id" : 253321888091213824,
    "created_at" : "2012-10-03 02:33:39 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 253325555791982592,
  "created_at" : "2012-10-03 02:48:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/253204410031812608\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/VjiX9qnL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4OQEcQCMAA_JK3.jpg",
      "id_str" : "253204410040201216",
      "id" : 253204410040201216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4OQEcQCMAA_JK3.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VjiX9qnL"
    } ],
    "hashtags" : [ {
      "text" : "BreastCancerAwarenessMonth",
      "indices" : [ 91, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253204410031812608",
  "text" : "Photo of the day: Tourists take a pic in front of the White House, lit pink last night for #BreastCancerAwarenessMonth http:\/\/t.co\/VjiX9qnL",
  "id" : 253204410031812608,
  "created_at" : "2012-10-02 18:46:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/252938241412591616\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ExlWrGzh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A4Kd_Y3CcAA6Lni.jpg",
      "id_str" : "252938241416785920",
      "id" : 252938241416785920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A4Kd_Y3CcAA6Lni.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ExlWrGzh"
    } ],
    "hashtags" : [ {
      "text" : "BreastCancerAwarenessMonth",
      "indices" : [ 57, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/TlMCu5Rf",
      "expanded_url" : "http:\/\/on.wh.gov\/HA2W20",
      "display_url" : "on.wh.gov\/HA2W20"
    } ]
  },
  "geo" : { },
  "id_str" : "252938241412591616",
  "text" : "Tonight, the White House is illuminated pink in honor of #BreastCancerAwarenessMonth: http:\/\/t.co\/TlMCu5Rf\n Photo: http:\/\/t.co\/ExlWrGzh",
  "id" : 252938241412591616,
  "created_at" : "2012-10-02 01:09:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ryJbjk3H",
      "expanded_url" : "http:\/\/on.wh.gov\/WqYbqg",
      "display_url" : "on.wh.gov\/WqYbqg"
    } ]
  },
  "geo" : { },
  "id_str" : "252909434211274752",
  "text" : "\"All Americans can play a role in ending domestic violence.\"-President Obama on Natl Domestic Violence Awareness Month: http:\/\/t.co\/ryJbjk3H",
  "id" : 252909434211274752,
  "created_at" : "2012-10-01 23:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreastCancerAwarenessMonth",
      "indices" : [ 56, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252871723651837953",
  "text" : "RT @VP: Tonight, the Naval Observatory will go pink for #BreastCancerAwarenessMonth. Help raise awareness of early detection. \u2013Dr. B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BreastCancerAwarenessMonth",
        "indices" : [ 48, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252869377144287233",
    "text" : "Tonight, the Naval Observatory will go pink for #BreastCancerAwarenessMonth. Help raise awareness of early detection. \u2013Dr. B",
    "id" : 252869377144287233,
    "created_at" : "2012-10-01 20:35:32 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 252871723651837953,
  "created_at" : "2012-10-01 20:44:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Smith",
      "screen_name" : "JSmith44",
      "indices" : [ 3, 12 ],
      "id_str" : "2821610174",
      "id" : 2821610174
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 23, 34 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreastCancerAwarenessMonth",
      "indices" : [ 60, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252855507696640002",
  "text" : "RT @JSmith44: Tonight, @WhiteHouse will go pink in honor of #BreastCancerAwarenessMonth. We stand with all those who have been affected.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 9, 20 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BreastCancerAwarenessMonth",
        "indices" : [ 46, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252854503789981697",
    "text" : "Tonight, @WhiteHouse will go pink in honor of #BreastCancerAwarenessMonth. We stand with all those who have been affected.",
    "id" : 252854503789981697,
    "created_at" : "2012-10-01 19:36:26 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 252855507696640002,
  "created_at" : "2012-10-01 19:40:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreastCancerAwarenessMonth",
      "indices" : [ 36, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/CGrTDs2H",
      "expanded_url" : "http:\/\/on.wh.gov\/27Z31D",
      "display_url" : "on.wh.gov\/27Z31D"
    } ]
  },
  "geo" : { },
  "id_str" : "252825187416952833",
  "text" : "Presidential Proclamation: National #BreastCancerAwarenessMonth: http:\/\/t.co\/CGrTDs2H",
  "id" : 252825187416952833,
  "created_at" : "2012-10-01 17:39:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]