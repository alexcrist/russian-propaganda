Grailbird.data.tweets_2009_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2419955395",
  "text" : "Today's the day: the President's health reform online town hall at 1:15 Eastern.  Watch, discuss, engage. http:\/\/bit.ly\/72G0a",
  "id" : 2419955395,
  "created_at" : "2009-07-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHCQ",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2420546622",
  "text" : "Twittering on location in VA, video questions being queued up, big monitors set up.  Watching discussion on #WHHCQ",
  "id" : 2420546622,
  "created_at" : "2009-07-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHCQ",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2422765317",
  "text" : "President\u2019s online health reform town hall in 15 min. Shout out from Valerie Jarrett. Watch: http:\/\/bit.ly\/72G0a  #WHHCQ",
  "id" : 2422765317,
  "created_at" : "2009-07-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2403205266",
  "text" : "On Tap: 2:00 President on innovation & nonprofits; 5:00 CIO Vivek Kundra live-stream chat on amazing new transparency project",
  "id" : 2403205266,
  "created_at" : "2009-06-30 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2407160859",
  "text" : "President Obama on innovative nonprofits, community solutions.  Watch live: http:\/\/www.whitehouse.gov\/live\/",
  "id" : 2407160859,
  "created_at" : "2009-06-30 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2409500827",
  "text" : "5:00 CIO Vivek Kundra on Facebook Live-Stream chat re: transparency breakthrough, moderator Macon Phillips http:\/\/bit.ly\/tCHXt",
  "id" : 2409500827,
  "created_at" : "2009-06-30 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Government",
      "screen_name" : "OpenGov",
      "indices" : [ 3, 11 ],
      "id_str" : "24752484",
      "id" : 24752484
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pdf09",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2394414262",
  "text" : "RT @OpenGov Noveck & Kundra (& Phillips) speak on \"Innovation in Gov't\" tomorrow at 8:45am at PDF #pdf09 http:\/\/bit.ly\/oV2Zd",
  "id" : 2394414262,
  "created_at" : "2009-06-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2388554654",
  "text" : "On Tap: 2:15 President of Colombia; 4:25 President & First Lady LGBT Pride Event;  5:00  Live-stream chat w\/ Health Reform Director DeParle",
  "id" : 2388554654,
  "created_at" : "2009-06-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2389563947",
  "text" : "Brian Bond of OPE : from being \"a gay kid growing up in rural Missouri\" to hosting WH LGBT Pride reception http:\/\/bit.ly\/YUpmM",
  "id" : 2389563947,
  "created_at" : "2009-06-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2392989278",
  "text" : "Watch, engage, discuss: Health Reform Office Director Nancy-Ann DeParle Facebook live-stream chat at 5:00 http:\/\/bit.ly\/tCHXt",
  "id" : 2392989278,
  "created_at" : "2009-06-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NHTD09",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2358982248",
  "text" : "1 in 5 Americans with HIV doesn't know. Share this Nat'l HIV Testing Day vid of Pres Obama's test: http:\/\/bit.ly\/7LZaH #NHTD09",
  "id" : 2358982248,
  "created_at" : "2009-06-27 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHCQ",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2362947255",
  "text" : "President Obama wants to hear your health reform questions: http:\/\/bit.ly\/Zm1RD #WHHCQ",
  "id" : 2362947255,
  "created_at" : "2009-06-27 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2345788450",
  "text" : "House vote on historic energy bill this afternoon, watch the President\u2019s endorsement yesterday: http:\/\/bit.ly\/pr5fH",
  "id" : 2345788450,
  "created_at" : "2009-06-26 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2350596305",
  "text" : "Dunked! President Obama dunks Robert Gibbs, Rahm Emanuel and Peter Orszag. Watch:  http:\/\/bit.ly\/RWckv",
  "id" : 2350596305,
  "created_at" : "2009-06-26 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2326678977",
  "text" : "On tap: President and First Lady at major Service event now, 2:00 meeting with Congress on immigration, 6:30 Luau with Congress",
  "id" : 2326678977,
  "created_at" : "2009-06-25 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2329408126",
  "text" : "Streaming momentarily: President speaks in the Rose Garden on need to pass historic energy bill http:\/\/bit.ly\/GOZOt",
  "id" : 2329408126,
  "created_at" : "2009-06-25 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2311880208",
  "text" : "Green Jobs pioneer Van Jones of CEQ: Watch the new video now, join the live-streamed chat at 3:00: http:\/\/bit.ly\/3Uv9m",
  "id" : 2311880208,
  "created_at" : "2009-06-24 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2314428207",
  "text" : "Starting at 3:00: Watch, discuss, and engage with Van Jones of CEQ on Green Jobs through Facebook:  http:\/\/bit.ly\/tCHXt",
  "id" : 2314428207,
  "created_at" : "2009-06-24 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2316064659",
  "text" : "New WH Slideshare account to share docs and presentations http:\/\/bit.ly\/wh5hT  Open Gov Directive Phase III: Drafting http:\/\/bit.ly\/12UFoW",
  "id" : 2316064659,
  "created_at" : "2009-06-24 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2294558918",
  "text" : "On tap: 12:30 Press Conf., meetings with Pres. of Chile. Title IX event w\/ BJK and Facebook chat at 2:30 http:\/\/bit.ly\/YWIaw",
  "id" : 2294558918,
  "created_at" : "2009-06-23 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2296717285",
  "text" : "President\u2019s press conference streaming momentarily: http:\/\/bit.ly\/GOZOt Watch & discuss through Facebook: http:\/\/bit.ly\/tCHXt",
  "id" : 2296717285,
  "created_at" : "2009-06-23 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2298232054",
  "text" : "2:30 - Watch, discuss, engage w\/ Facebook, WH.gov:  Valerie Jarrett, Billie Jean King in Title IX Roundtable http:\/\/bit.ly\/dwuup",
  "id" : 2298232054,
  "created_at" : "2009-06-23 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iranelection",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2299818678",
  "text" : "President Obama's Remarks on Iran at his Press Conference, with Persian Translation: http:\/\/bit.ly\/p9A4K  #iranelection",
  "id" : 2299818678,
  "created_at" : "2009-06-23 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iranelection",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2300344424",
  "text" : "\u0633\u062E\u0646\u0627\u0646 \u067E\u0631\u0632\u06CC\u062F\u0646\u062A \u0627\u0648\u0628\u0627\u0645\u0627 \u062F\u0631 \u06A9\u0646\u0641\u0631\u0627\u0646\u0633 \u0645\u0637\u0628\u0648\u0639\u0627\u062A\u06CC \u062E\u0648\u062F \u062F\u0631\u0628\u0627\u0631\u06C0 \u0627\u06CC\u0631\u0627\u0646\u060C \u0647\u0645\u0631\u0627\u0647 \u0628\u0627 \u062A\u0631\u062C\u0645\u06C0 \u0641\u0627\u0631\u0633\u06CC http:\/\/bit.ly\/p9A4K  #iranelection",
  "id" : 2300344424,
  "created_at" : "2009-06-23 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2281442663",
  "text" : "New video from the First Lady on \"United We Serve\": http:\/\/bit.ly\/2M0Bf  Also, fresh photos on Flickr: http:\/\/bit.ly\/D00KK",
  "id" : 2281442663,
  "created_at" : "2009-06-22 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2282233616",
  "text" : "President signing long overdue kids tobacco bill.  Watch live: http:\/\/bit.ly\/GOZOt",
  "id" : 2282233616,
  "created_at" : "2009-06-22 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2282852781",
  "text" : "Not too late! Women athletes submit your photos, help us celebrate Title IX\u2019s Anniversary tomorrow: http:\/\/bit.ly\/F07T6",
  "id" : 2282852781,
  "created_at" : "2009-06-22 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2246043117",
  "text" : "President Obama on Iran \u201Cwe stand behind those who are seeking justice in a peaceful way\u201D http:\/\/bit.ly\/SNwuX",
  "id" : 2246043117,
  "created_at" : "2009-06-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2254966751",
  "text" : "UN Amb. Rice reflects on Title IX 37th anniversary, photo of her in action - women athletes share your own http:\/\/bit.ly\/F07T6",
  "id" : 2254966751,
  "created_at" : "2009-06-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2256032125",
  "text" : "President Obama: \"We call on the Iranian government to stop all violent and unjust actions against its own people.\" http:\/\/bit.ly\/EAlZP",
  "id" : 2256032125,
  "created_at" : "2009-06-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2237694693",
  "text" : "Bo: The Portrait, the Baseball Card.   All your Bo-wishes are fulfilled: http:\/\/bit.ly\/11ZMbM",
  "id" : 2237694693,
  "created_at" : "2009-06-19 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2242358234",
  "text" : "For Father\u2019s Day:  President holds conversation on family & responsible fatherhood. Streaming any minute  http:\/\/bit.ly\/2A62mE",
  "id" : 2242358234,
  "created_at" : "2009-06-19 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2223628728",
  "text" : "WH Facebook page exclusive: President Obama backstage before ordering Colbert\u2019s head-shave  http:\/\/bit.ly\/8tSfq",
  "id" : 2223628728,
  "created_at" : "2009-06-18 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2226204677",
  "text" : "Join experimental live-stream discussion through Facebook or our site on a WH meeting with physicians: http:\/\/bit.ly\/10zBK2",
  "id" : 2226204677,
  "created_at" : "2009-06-18 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2207581269",
  "text" : "On tap: President\u2019s video on \u201CUnited We Serve\u201D http:\/\/www.serve.gov Financial reg reform 12:50; Benefits for gay federal employees 5:45",
  "id" : 2207581269,
  "created_at" : "2009-06-17 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2208890698",
  "text" : "Fact Sheet: Presidential Memorandum on Federal Benefits and Non-Discrimination http:\/\/bit.ly\/4Rvvw",
  "id" : 2208890698,
  "created_at" : "2009-06-17 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2212149518",
  "text" : "President\u2019s remarks and all you could want to know about his proposed overhaul of financial regulations: http:\/\/bit.ly\/1X6mba",
  "id" : 2212149518,
  "created_at" : "2009-06-17 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2185448039",
  "text" : "President meets Italian PM, answers on Iran:\u201Cup to Iranians to make decisions\u201D \u201Cwrong for me to be silent\u201D http:\/\/bit.ly\/AbB1d",
  "id" : 2185448039,
  "created_at" : "2009-06-16 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2192281385",
  "text" : "On tap: The President meets with President Lee, the Republic of Korea.  Interagency report on climate change released at 1:30",
  "id" : 2192281385,
  "created_at" : "2009-06-16 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHclimate",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2195322709",
  "text" : "WH releases consensus interagency report on climate change impacts in US.  Watch live, learn more: http:\/\/bit.ly\/Yd6Ca Questions? #WHclimate",
  "id" : 2195322709,
  "created_at" : "2009-06-16 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2196772352",
  "text" : "First Lady at WH Jazz Studio, jazz like democracy:\u201Cindividual freedom, but with responsibility to the group.\" http:\/\/bit.ly\/qw96C",
  "id" : 2196772352,
  "created_at" : "2009-06-16 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2177614723",
  "text" : "On tap: President\u2019s major health care speech to AMA in Chicago, 11:15 CDT.  Geithner\/ Summers on new financial regs: http:\/\/bit.ly\/QR54X",
  "id" : 2177614723,
  "created_at" : "2009-06-15 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2181405795",
  "text" : "Something special.  First Lady launches WH music series with Jazz Studio with greats and students. Watch:  http:\/\/bit.ly\/GOZOt",
  "id" : 2181405795,
  "created_at" : "2009-06-15 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2182836384",
  "text" : "The President\u2019s full vision on health reform in his pivotal speech to the AMA. Read highlights or in full: http:\/\/bit.ly\/JCXrG",
  "id" : 2182836384,
  "created_at" : "2009-06-15 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2130855276",
  "text" : "DTV! \u201CThe Transition is in progress\u2026\u201D If you have an analog TV, get a converter or new TV.  Converter coupons: http:\/\/dtv.gov",
  "id" : 2130855276,
  "created_at" : "2009-06-12 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2133074480",
  "text" : "Streaming momentarily - The President talks about the kids\/ tobacco legislation, a long time coming: http:\/\/bit.ly\/GOZOt",
  "id" : 2133074480,
  "created_at" : "2009-06-12 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2110595746",
  "text" : "Transparency: Access to Information: Michael Fitzpatrick, Associate Administrator of the Office of Information a.. http:\/\/tinyurl.com\/n4epn9",
  "id" : 2110595746,
  "created_at" : "2009-06-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2110596470",
  "text" : "Welcoming the Steelers: Behind the Scenes: A follow-up video to the Pittsburgh Steelers' visit last month, get a.. http:\/\/tinyurl.com\/m8hkdz",
  "id" : 2110596470,
  "created_at" : "2009-06-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2110596852",
  "text" : "On the Holocaust Museum Shooting: The President and Secretary Salazar offer condolences. http:\/\/tinyurl.com\/l3y9dj",
  "id" : 2110596852,
  "created_at" : "2009-06-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2120515487",
  "text" : "President\u2019s health care town hall, context and opening remarks: \u201Cfix what\u2019s broken, build on what works\u201D http:\/\/bit.ly\/YDfay",
  "id" : 2120515487,
  "created_at" : "2009-06-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2123958844",
  "text" : "State Dept. Q of the Week: What Will Promote Understanding Between U.S. and Muslim Communities Worldwide? http:\/\/bit.ly\/5oJ4u",
  "id" : 2123958844,
  "created_at" : "2009-06-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2096947380",
  "text" : "Race for the Cure: The Vice President and Dr. Biden serve as Honorary Co-Chairs of the 2009 Susan G. Komen Globa.. http:\/\/tinyurl.com\/mlhrdu",
  "id" : 2096947380,
  "created_at" : "2009-06-10 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2096947661",
  "text" : "Photostream: The Middle East and Europe: The White House Photo Office drops sixty photos from the President's tr.. http:\/\/tinyurl.com\/lvepng",
  "id" : 2096947661,
  "created_at" : "2009-06-10 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2098215793",
  "text" : "Wrap-Up of the Open Government Brainstorming: Participation: Beth Noveck, Deputy Chief Technology Officer for Op.. http:\/\/tinyurl.com\/npzjrz",
  "id" : 2098215793,
  "created_at" : "2009-06-10 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2109377810",
  "text" : "Accountability on Executive Compensation: Treasury Secretary Geithner announced that the Administration is calli.. http:\/\/tinyurl.com\/lxm2vm",
  "id" : 2109377810,
  "created_at" : "2009-06-10 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2109378055",
  "text" : "Rubber Hitting the Road on Health Care: The President invites key Senators on health reform to the White House t.. http:\/\/tinyurl.com\/nb6pbm",
  "id" : 2109378055,
  "created_at" : "2009-06-10 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2095058210",
  "text" : "See the new, behind the scenes photos from the President's trip last week: http:\/\/bit.ly\/3qv8Tf",
  "id" : 2095058210,
  "created_at" : "2009-06-09 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2085872610",
  "text" : "Data Transparency via Data.gov: Chief Information Officer Vivek Kundra asks for your input on the future of Data.. http:\/\/tinyurl.com\/m3esh8",
  "id" : 2085872610,
  "created_at" : "2009-06-09 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2091359659",
  "text" : "Streaming at Noon: Health Care Stakeholder Discussion on Health Disparities and Health Reform: The Health and Hu.. http:\/\/tinyurl.com\/m5ld6v",
  "id" : 2091359659,
  "created_at" : "2009-06-09 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2094155289",
  "text" : "TARP Funds Returned, Spending Reined In: The President comes bearing good news for the taxpayer. http:\/\/tinyurl.com\/m8c7a7",
  "id" : 2094155289,
  "created_at" : "2009-06-09 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2076804448",
  "text" : "Recovery in Action: TN, CO, TX, LA, MS: Not too long after President Obama signed the Recovery Act into law, the.. http:\/\/tinyurl.com\/m5q7jd",
  "id" : 2076804448,
  "created_at" : "2009-06-08 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2077858555",
  "text" : "600,000 Jobs on the Road to Recovery: The President and Vice President announce the Roadmap to Recovery -- a sum.. http:\/\/tinyurl.com\/mtxuzp",
  "id" : 2077858555,
  "created_at" : "2009-06-08 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2080817071",
  "text" : "Accelerating Our Efforts: The Next 100 Days: The President and Vice President meet with Cabinet officials to dis.. http:\/\/tinyurl.com\/mrmt2m",
  "id" : 2080817071,
  "created_at" : "2009-06-08 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2082176401",
  "text" : "Transparency: Open Government Operations: Robynn Sturm, Assistant Deputy CTO for Open Government, asks what you .. http:\/\/tinyurl.com\/lsypmr",
  "id" : 2082176401,
  "created_at" : "2009-06-08 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2051578527",
  "text" : "Weekly Address: President Obama Calls for Real Health Care Reform: The President makes clear that as Congress wo.. http:\/\/tinyurl.com\/kpbowc",
  "id" : 2051578527,
  "created_at" : "2009-06-06 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2056849407",
  "text" : "D-Day: In Normandy, the President speaks at the D-Day 65th Anniversary Ceremony. http:\/\/tinyurl.com\/o7nabh",
  "id" : 2056849407,
  "created_at" : "2009-06-06 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2044903762",
  "text" : "In Alaska: Jodi A. Gillette is Associate Director, White House Office of Public Engagement & Deputy Associate Di.. http:\/\/tinyurl.com\/q45lr9",
  "id" : 2044903762,
  "created_at" : "2009-06-05 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2044903982",
  "text" : "Streaming at 11:00: Health Care Stakeholder Discussion with Women\u2019s Groups: Today the White House holds another .. http:\/\/tinyurl.com\/r4lv27",
  "id" : 2044903982,
  "created_at" : "2009-06-05 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2044904179",
  "text" : "Napolitano, Holder, and Kerlikowske Announcing Southwest Border Counternarcotics Strategy: Watch the live-stream.. http:\/\/tinyurl.com\/qo38r4",
  "id" : 2044904179,
  "created_at" : "2009-06-05 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2045891031",
  "text" : "Buchenwald: The President and Chancellor Merkel tour Buchenwald Concentration Camp, joined by survivors Elie Wie.. http:\/\/tinyurl.com\/lgy796",
  "id" : 2045891031,
  "created_at" : "2009-06-05 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2047894423",
  "text" : "Ryan Howard Talks Healthy Diet With the White House Chef: Ryan Howard of the World Series Champion Philadelphia .. http:\/\/tinyurl.com\/ogrnq8",
  "id" : 2047894423,
  "created_at" : "2009-06-05 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2023698509",
  "text" : "In advance of the speech tomorrow, here are some stories of Muslim Americans proudly serving in the federal gov't: http:\/\/bit.ly\/hmn9z",
  "id" : 2023698509,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2023768152",
  "text" : "The First Lady: \"Today is Just the Beginning\": In her address to the graduating seniors of Washington Math and S.. http:\/\/tinyurl.com\/o9dj29",
  "id" : 2023768152,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2024091085",
  "text" : "Watch and discuss the President's speech in Cairo tomorrow: http:\/\/bit.ly\/rxDvH",
  "id" : 2024091085,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2027846429",
  "text" : "Don't forget to tune in live to the President's speech in Cairo at 6:10am ET today: http:\/\/www.whitehouse.gov\/live\/",
  "id" : 2027846429,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2027890692",
  "text" : "Obama: I have come here to seek a new beginning between the US & the Muslim world based upon mutual interest and mutual respect",
  "id" : 2027890692,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2027914596",
  "text" : "Obama: throughout history, Islam has demonstrated through words and deeds the possibilities of religious tolerance and racial equality.",
  "id" : 2027914596,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2027948984",
  "text" : "Obama:  Our problems must be dealt with through partnership; progress must be shared.",
  "id" : 2027948984,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2027954193",
  "text" : "Obama: The first issue that we have to confront is violent extremism in all of its forms.",
  "id" : 2027954193,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2027955202",
  "text" : "Obama: In Ankara, I made clear that America is not \u2013 and never will be \u2013 at war with Islam.",
  "id" : 2027955202,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2027985761",
  "text" : "Obama: America has a dual responsibility: to help Iraq forge a better future \u2013 and to leave Iraq to Iraqis.",
  "id" : 2027985761,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028005930",
  "text" : "Obama: America\u2019s strong bonds with Israel are well known. This bond is unbreakable.",
  "id" : 2028005930,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028009971",
  "text" : "Obama: America will not turn our backs on the legitimate Palestinian aspiration for dignity, opportunity, and a state of their own.",
  "id" : 2028009971,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028020243",
  "text" : "Obama: the only resolution is for the aspirations of both sides to be met through two states .. in peace and security",
  "id" : 2028020243,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028049633",
  "text" : "Obama:The third source of tension is our shared interest in the rights and responsibilities of nations on nuclear weapons.",
  "id" : 2028049633,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028063021",
  "text" : "Obama: I strongly reaffirmed America\u2019s commitment to seek a world in which no nations hold nuclear weapons.",
  "id" : 2028063021,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028065719",
  "text" : "Obama: The fourth issue that I will address is democracy.",
  "id" : 2028065719,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028077047",
  "text" : "Obama: America respects the right of all peaceful and law-abiding voices to be heard around the world, even if we disagree with them..",
  "id" : 2028077047,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028078836",
  "text" : "Obama.. And we will welcome all elected, peaceful governments \u2013 provided they govern with respect for all their people.",
  "id" : 2028078836,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028085141",
  "text" : "Obama: The fifth issue that we must address together is religious freedom. Islam has a proud tradition of tolerance.",
  "id" : 2028085141,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028095169",
  "text" : "Obama: Freedom of religion is central to the ability of peoples to live together.",
  "id" : 2028095169,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028102497",
  "text" : "Obama: The sixth issue that I want to address is women\u2019s rights.",
  "id" : 2028102497,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028115391",
  "text" : "Obama: Our daughters can contribute just as much to society as our sons ..",
  "id" : 2028115391,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028116112",
  "text" : "Obama .. and our common prosperity will be advanced by allowing all humanity \u2013 men and women \u2013 to reach their full potential",
  "id" : 2028116112,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028120157",
  "text" : "Obama: Finally, I want to discuss economic development and opportunity.",
  "id" : 2028120157,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028167383",
  "text" : "We have the power to make the world we seek, but only if we have the courage to make a new beginning, keeping in mind what has been written.",
  "id" : 2028167383,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028172963",
  "text" : "Obama: The people of the world can live together in peace. We know that is God\u2019s vision. Now, that must be our work here on Earth.",
  "id" : 2028172963,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2028297752",
  "text" : "We'll have the full transcript and recorded video of the President's speech on http:\/\/www.whitehouse.gov shortly. Stay tuned!",
  "id" : 2028297752,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2031044028",
  "text" : "The President\u2019s Speech in Cairo: A New Beginning: Watch or read the President\u2019s speech in Cairo on America\u2019s rel.. http:\/\/tinyurl.com\/r5xfvu",
  "id" : 2031044028,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2033181860",
  "text" : "Judge Sotomayor\u2019s Questionnaire - A New Modern Record: White House Counsel Greg Craig discusses Judge Sotomayor .. http:\/\/tinyurl.com\/pv6fr4",
  "id" : 2033181860,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2034338214",
  "text" : "Nashala's Story: Read the backstory of a symbolic case the President referenced in his Cairo speech. http:\/\/tinyurl.com\/qhfx2g",
  "id" : 2034338214,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2036315209",
  "text" : "Dr. Biden: \"We Support One Another\" : During her visit to the Today Show, Dr. Biden called on Americans to do wh.. http:\/\/tinyurl.com\/ocefsf",
  "id" : 2036315209,
  "created_at" : "2009-06-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2019204680",
  "text" : "Tomorrow, the President will give a speech in Cairo, Egypt. Watch it live:http:\/\/bit.ly\/12nxRn and\/or RSVP here: http:\/\/bit.ly\/g9L2k",
  "id" : 2019204680,
  "created_at" : "2009-06-03 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2021966445",
  "text" : "The first government sponsored TED Talks: Rob Lalka, the Partnerships Liaison at the U.S. Department of State, d.. http:\/\/tinyurl.com\/r45yrc",
  "id" : 2021966445,
  "created_at" : "2009-06-03 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2021966812",
  "text" : "The President Spells Out His Vision on Health Care Reform: The President writes to Senators Ted Kennedy and Max .. http:\/\/tinyurl.com\/qh2foo",
  "id" : 2021966812,
  "created_at" : "2009-06-03 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2021967216",
  "text" : "The President in the Middle East: The history of the relationship between America and the Muslim World is deeper.. http:\/\/tinyurl.com\/rdaxqx",
  "id" : 2021967216,
  "created_at" : "2009-06-03 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2022993315",
  "text" : "Open Government Initiative Discussion Phase: Transparency Principles: Beth Noveck, Deputy Chief Technology Offic.. http:\/\/tinyurl.com\/p8sfr5",
  "id" : 2022993315,
  "created_at" : "2009-06-03 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2010709479",
  "text" : "The Vice President on Business and Recovery: Vice President Biden hosts a roundtable with business leaders, rang.. http:\/\/tinyurl.com\/qecpr4",
  "id" : 2010709479,
  "created_at" : "2009-06-03 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2012561529",
  "text" : "Wrap-Up of the Open Government Brainstorming: Transparency: Beth Noveck is Deputy Chief Technology Officer for O.. http:\/\/tinyurl.com\/o3ut3j",
  "id" : 2012561529,
  "created_at" : "2009-06-03 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2003823939",
  "text" : "\"When I Was in the 6th Grade...\": Dr. Jill Biden talks about attending the Scripps National Spelling Bee last week. http:\/\/tinyurl.com\/n ...",
  "id" : 2003823939,
  "created_at" : "2009-06-02 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2005914703",
  "text" : "The Economic Case for Health Care Reform: The White House Council of Economic Advisers issues a pivotal report e.. http:\/\/tinyurl.com\/ktdp6f",
  "id" : 2005914703,
  "created_at" : "2009-06-02 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2008901888",
  "text" : "Transparency at the FDA: HHS Secretary Kathleen Sebelius discusses the new Food and Drug Administration Transpar.. http:\/\/tinyurl.com\/ol6mpa",
  "id" : 2008901888,
  "created_at" : "2009-06-02 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2008902124",
  "text" : "Judge Sotomayor, In Practice: As Judge Sonia Sotomayor has been visiting Capitol Hill, her former co-prosecutor .. http:\/\/tinyurl.com\/qkx9g5",
  "id" : 2008902124,
  "created_at" : "2009-06-02 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2008902512",
  "text" : "Photostream: The White House Photo Office has just posted 94 new photos on the White House photostream. Have a l.. http:\/\/tinyurl.com\/ovfze6",
  "id" : 2008902512,
  "created_at" : "2009-06-02 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]