Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Heritage Foundation",
      "screen_name" : "Heritage",
      "indices" : [ 106, 115 ],
      "id_str" : "10168082",
      "id" : 10168082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/uyFQWCoV",
      "expanded_url" : "http:\/\/is.gd\/jUs1UN",
      "display_url" : "is.gd\/jUs1UN"
    } ]
  },
  "geo" : { },
  "id_str" : "119913731265265664",
  "text" : "RT @PressSec: Me quoting fmr Mass gov on conservative origin of individual mandate: http:\/\/t.co\/uyFQWCoV. @Heritage reax: http:\/\/t.co\/KE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Heritage Foundation",
        "screen_name" : "Heritage",
        "indices" : [ 92, 101 ],
        "id_str" : "10168082",
        "id" : 10168082
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/uyFQWCoV",
        "expanded_url" : "http:\/\/is.gd\/jUs1UN",
        "display_url" : "is.gd\/jUs1UN"
      }, {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/KEcF1j31",
        "expanded_url" : "http:\/\/is.gd\/4Kedmf",
        "display_url" : "is.gd\/4Kedmf"
      } ]
    },
    "geo" : { },
    "id_str" : "119911729001017345",
    "text" : "Me quoting fmr Mass gov on conservative origin of individual mandate: http:\/\/t.co\/uyFQWCoV. @Heritage reax: http:\/\/t.co\/KEcF1j31.",
    "id" : 119911729001017345,
    "created_at" : "2011-09-30 23:09:18 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 119913731265265664,
  "created_at" : "2011-09-30 23:17:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Autism",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119895919255756800",
  "text" : "RT @macon44: Great post from an incredible guy: A Father Celebrates Today's Reauthorization of the Combating #Autism Act http:\/\/t.co\/2Nu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 129, 140 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Autism",
        "indices" : [ 96, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/2NuBURNo",
        "expanded_url" : "http:\/\/1.usa.gov\/o0YI4e",
        "display_url" : "1.usa.gov\/o0YI4e"
      } ]
    },
    "geo" : { },
    "id_str" : "119888068869234688",
    "text" : "Great post from an incredible guy: A Father Celebrates Today's Reauthorization of the Combating #Autism Act http:\/\/t.co\/2NuBURNo @whitehouse",
    "id" : 119888068869234688,
    "created_at" : "2011-09-30 21:35:17 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 119895919255756800,
  "created_at" : "2011-09-30 22:06:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "indices" : [ 3, 17 ],
      "id_str" : "28576135",
      "id" : 28576135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119863558912749568",
  "text" : "RT @thejointstaff: To the troops & families of the armed forces, Deborah & I our deeply honored to have served with you. Full msg @ http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/smJMgZGe",
        "expanded_url" : "http:\/\/tinyurl.com\/2bvqucw",
        "display_url" : "tinyurl.com\/2bvqucw"
      } ]
    },
    "geo" : { },
    "id_str" : "119752823851335680",
    "text" : "To the troops & families of the armed forces, Deborah & I our deeply honored to have served with you. Full msg @ http:\/\/t.co\/smJMgZGe",
    "id" : 119752823851335680,
    "created_at" : "2011-09-30 12:37:52 +0000",
    "user" : {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "protected" : false,
      "id_str" : "28576135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459045440063672320\/SOEE5LHU_normal.png",
      "id" : 28576135,
      "verified" : true
    }
  },
  "id" : 119863558912749568,
  "created_at" : "2011-09-30 19:57:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericanJobsAct",
      "indices" : [ 12, 28 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/QapDxuFC",
      "expanded_url" : "http:\/\/wh.gov\/4H9",
      "display_url" : "wh.gov\/4H9"
    } ]
  },
  "geo" : { },
  "id_str" : "119822605028036608",
  "text" : ".@VP Biden: #AmericanJobsAct will keep first responders on the beat & improve emergency communication: http:\/\/t.co\/QapDxuFC #JobsNow",
  "id" : 119822605028036608,
  "created_at" : "2011-09-30 17:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "indices" : [ 3, 17 ],
      "id_str" : "28576135",
      "id" : 28576135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/5Z5dSzr6",
      "expanded_url" : "http:\/\/tinyurl.com\/5yynj",
      "display_url" : "tinyurl.com\/5yynj"
    } ]
  },
  "geo" : { },
  "id_str" : "119801195958247424",
  "text" : "RT @thejointstaff: Watch Admiral Mullen's farewell address. Streaming live now @ http:\/\/t.co\/5Z5dSzr6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/5Z5dSzr6",
        "expanded_url" : "http:\/\/tinyurl.com\/5yynj",
        "display_url" : "tinyurl.com\/5yynj"
      } ]
    },
    "geo" : { },
    "id_str" : "119800109226659840",
    "text" : "Watch Admiral Mullen's farewell address. Streaming live now @ http:\/\/t.co\/5Z5dSzr6",
    "id" : 119800109226659840,
    "created_at" : "2011-09-30 15:45:46 +0000",
    "user" : {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "protected" : false,
      "id_str" : "28576135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459045440063672320\/SOEE5LHU_normal.png",
      "id" : 28576135,
      "verified" : true
    }
  },
  "id" : 119801195958247424,
  "created_at" : "2011-09-30 15:50:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "indices" : [ 68, 82 ],
      "id_str" : "28576135",
      "id" : 28576135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/tOVqQ5CT",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "119790147029057536",
  "text" : "RT @WHLive: Happening now: President Obama speaks @ the Chairman of @thejointstaff change of office ceremony: http:\/\/t.co\/tOVqQ5CT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Joint Staff",
        "screen_name" : "thejointstaff",
        "indices" : [ 56, 70 ],
        "id_str" : "28576135",
        "id" : 28576135
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/tOVqQ5CT",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "119790031438229504",
    "text" : "Happening now: President Obama speaks @ the Chairman of @thejointstaff change of office ceremony: http:\/\/t.co\/tOVqQ5CT",
    "id" : 119790031438229504,
    "created_at" : "2011-09-30 15:05:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 119790147029057536,
  "created_at" : "2011-09-30 15:06:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 74, 83 ],
      "id_str" : "13058772",
      "id" : 13058772
    }, {
      "name" : "Sharpie",
      "screen_name" : "Sharpie",
      "indices" : [ 84, 92 ],
      "id_str" : "17498440",
      "id" : 17498440
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "fixNCLB",
      "indices" : [ 93, 101 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 102, 110 ]
    }, {
      "text" : "BacktoSchool",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/Nb5YQrHN",
      "expanded_url" : "http:\/\/youtu.be\/-aUn2ARjBtw",
      "display_url" : "youtu.be\/-aUn2ARjBtw"
    } ]
  },
  "geo" : { },
  "id_str" : "119787610800537600",
  "text" : "#WestWingWeek 9\/30\/11 or \"Set Your Sights High\": http:\/\/t.co\/Nb5YQrHN cc: @LinkedIn @Sharpie #fixNCLB #JobsNow #BacktoSchool",
  "id" : 119787610800537600,
  "created_at" : "2011-09-30 14:56:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 3, 7 ],
      "id_str" : "66369206",
      "id" : 66369206
    }, {
      "name" : "Apps for Communities",
      "screen_name" : "communityapps",
      "indices" : [ 78, 92 ],
      "id_str" : "245440314",
      "id" : 245440314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/D4ANBVNL",
      "expanded_url" : "http:\/\/appsforcommunities.challenge.gov\/",
      "display_url" : "appsforcommunities.challenge.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "119531335290335232",
  "text" : "RT @FCC: Only 4 days left to double your chances & enter an additional app in @communityapps challenge http:\/\/t.co\/D4ANBVNL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Apps for Communities",
        "screen_name" : "communityapps",
        "indices" : [ 69, 83 ],
        "id_str" : "245440314",
        "id" : 245440314
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/D4ANBVNL",
        "expanded_url" : "http:\/\/appsforcommunities.challenge.gov\/",
        "display_url" : "appsforcommunities.challenge.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "119530854115573760",
    "text" : "Only 4 days left to double your chances & enter an additional app in @communityapps challenge http:\/\/t.co\/D4ANBVNL",
    "id" : 119530854115573760,
    "created_at" : "2011-09-29 21:55:51 +0000",
    "user" : {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "protected" : false,
      "id_str" : "66369206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303190571\/twitter_fcc_icon_normal.png",
      "id" : 66369206,
      "verified" : true
    }
  },
  "id" : 119531335290335232,
  "created_at" : "2011-09-29 21:57:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeThePeople",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/tKx2b6vw",
      "expanded_url" : "https:\/\/wwws.whitehouse.gov\/petitions",
      "display_url" : "wwws.whitehouse.gov\/petitions"
    } ]
  },
  "geo" : { },
  "id_str" : "119526097481240576",
  "text" : "#WeThePeople is a new way to create & sign petitions calling on the Obama Admin to take action. Check it out: http:\/\/t.co\/tKx2b6vw",
  "id" : 119526097481240576,
  "created_at" : "2011-09-29 21:36:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeThePeople",
      "indices" : [ 16, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119516667503063040",
  "text" : "RT @macon44: In #WeThePeople's 1st week, 500k signatures from 300k ppl on 6500 petitions. Mtg w\/policy folks tmrw to review 1st batch to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeThePeople",
        "indices" : [ 3, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "119515925518098432",
    "text" : "In #WeThePeople's 1st week, 500k signatures from 300k ppl on 6500 petitions. Mtg w\/policy folks tmrw to review 1st batch to cross threshold.",
    "id" : 119515925518098432,
    "created_at" : "2011-09-29 20:56:31 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 119516667503063040,
  "created_at" : "2011-09-29 20:59:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/xgCZv53g",
      "expanded_url" : "http:\/\/youtu.be\/fPaLab42z1s",
      "display_url" : "youtu.be\/fPaLab42z1s"
    } ]
  },
  "geo" : { },
  "id_str" : "119502858738610177",
  "text" : "\"Set your sights high\" -President Obama to students. Watch his back-to-school speech: http:\/\/t.co\/xgCZv53g",
  "id" : 119502858738610177,
  "created_at" : "2011-09-29 20:04:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Kenyon",
      "screen_name" : "giddywithglee",
      "indices" : [ 3, 17 ],
      "id_str" : "256613166",
      "id" : 256613166
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "priceless",
      "indices" : [ 59, 69 ]
    }, {
      "text" : "WHTweetup",
      "indices" : [ 70, 80 ]
    }, {
      "text" : "giddywithglee",
      "indices" : [ 81, 95 ]
    }, {
      "text" : "dreams",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119498132722692096",
  "text" : "RT @giddywithglee: Meeting 2 presidents on the same day ...#priceless #WHTweetup #giddywithglee #dreams Sign up BEFORE 5 PM EDT TODAY! h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "priceless",
        "indices" : [ 40, 50 ]
      }, {
        "text" : "WHTweetup",
        "indices" : [ 51, 61 ]
      }, {
        "text" : "giddywithglee",
        "indices" : [ 62, 76 ]
      }, {
        "text" : "dreams",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/SaTjXdBz",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/tweetup",
        "display_url" : "whitehouse.gov\/tweetup"
      } ]
    },
    "geo" : { },
    "id_str" : "119494465122603008",
    "text" : "Meeting 2 presidents on the same day ...#priceless #WHTweetup #giddywithglee #dreams Sign up BEFORE 5 PM EDT TODAY! http:\/\/t.co\/SaTjXdBz",
    "id" : 119494465122603008,
    "created_at" : "2011-09-29 19:31:15 +0000",
    "user" : {
      "name" : "Allen Kenyon",
      "screen_name" : "giddywithglee",
      "protected" : false,
      "id_str" : "256613166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672805704172900353\/HM7Je8N8_normal.jpg",
      "id" : 256613166,
      "verified" : false
    }
  },
  "id" : 119498132722692096,
  "created_at" : "2011-09-29 19:45:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "The Denver Post",
      "screen_name" : "denverpost",
      "indices" : [ 87, 98 ],
      "id_str" : "8216772",
      "id" : 8216772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/kuB6B2gv",
      "expanded_url" : "http:\/\/bit.ly\/nie44c",
      "display_url" : "bit.ly\/nie44c"
    } ]
  },
  "geo" : { },
  "id_str" : "119484772450971650",
  "text" : "RT @arneduncan: The President's Plan for the Economy & Education. Read my op-ed in the @DenverPost http:\/\/t.co\/kuB6B2gv #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Denver Post",
        "screen_name" : "denverpost",
        "indices" : [ 71, 82 ],
        "id_str" : "8216772",
        "id" : 8216772
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/kuB6B2gv",
        "expanded_url" : "http:\/\/bit.ly\/nie44c",
        "display_url" : "bit.ly\/nie44c"
      } ]
    },
    "geo" : { },
    "id_str" : "119057928916443136",
    "text" : "The President's Plan for the Economy & Education. Read my op-ed in the @DenverPost http:\/\/t.co\/kuB6B2gv #JobsNow",
    "id" : 119057928916443136,
    "created_at" : "2011-09-28 14:36:36 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 119484772450971650,
  "created_at" : "2011-09-29 18:52:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Goode",
      "screen_name" : "scottgoode",
      "indices" : [ 29, 40 ],
      "id_str" : "25916730",
      "id" : 25916730
    }, {
      "name" : "Melodie Woerman",
      "screen_name" : "Melodie_Woerman",
      "indices" : [ 41, 57 ],
      "id_str" : "17344897",
      "id" : 17344897
    }, {
      "name" : "Jonathan E Smith",
      "screen_name" : "JonathanESmith",
      "indices" : [ 58, 73 ],
      "id_str" : "44524722",
      "id" : 44524722
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/yzzfeOR0",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/tweetup",
      "display_url" : "whitehouse.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "119482189812473856",
  "text" : "Arrival Ceremony #WHTweetup: @scottgoode @Melodie_Woerman @JonathanESmith & more signed up. Have you? Apply by 5ET: http:\/\/t.co\/yzzfeOR0",
  "id" : 119482189812473856,
  "created_at" : "2011-09-29 18:42:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kansas City, MO",
      "screen_name" : "KCMO",
      "indices" : [ 120, 125 ],
      "id_str" : "41657673",
      "id" : 41657673
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KansasCity",
      "indices" : [ 47, 58 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/YVdemlZV",
      "expanded_url" : "http:\/\/youtu.be\/XFlAFSt5yJU",
      "display_url" : "youtu.be\/XFlAFSt5yJU"
    } ]
  },
  "geo" : { },
  "id_str" : "119437846267432960",
  "text" : "\"Jobs are at the forefront of people\u2019s minds\" -#KansasCity Mayor Sly James on #JobsNow. Watch: http:\/\/t.co\/YVdemlZV cc: @KCMO",
  "id" : 119437846267432960,
  "created_at" : "2011-09-29 15:46:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HornofAfrica",
      "indices" : [ 80, 93 ]
    }, {
      "text" : "FWD",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119417883234275328",
  "text" : "RT @USAID: Worst drought in 60 years. Worst famine in 20. Ongoing violence. The #HornofAfrica needs your help. #FWD the facts http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HornofAfrica",
        "indices" : [ 69, 82 ]
      }, {
        "text" : "FWD",
        "indices" : [ 100, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/KGOKpCQI",
        "expanded_url" : "http:\/\/www.usaid.gov\/fwd\/",
        "display_url" : "usaid.gov\/fwd\/"
      } ]
    },
    "geo" : { },
    "id_str" : "119417207787749376",
    "text" : "Worst drought in 60 years. Worst famine in 20. Ongoing violence. The #HornofAfrica needs your help. #FWD the facts http:\/\/t.co\/KGOKpCQI",
    "id" : 119417207787749376,
    "created_at" : "2011-09-29 14:24:15 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 119417883234275328,
  "created_at" : "2011-09-29 14:26:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119415304932687873",
  "text" : "RT @StateDept: The @WhiteHouse invites you to join a #WHTweetup for arrival of President Lee Myung-bak. Apply by 11:00 AM EDT today! htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 38, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/qT0qTJt4",
        "expanded_url" : "http:\/\/go.usa.gov\/8vs",
        "display_url" : "go.usa.gov\/8vs"
      } ]
    },
    "geo" : { },
    "id_str" : "119414790560022529",
    "text" : "The @WhiteHouse invites you to join a #WHTweetup for arrival of President Lee Myung-bak. Apply by 11:00 AM EDT today! http:\/\/t.co\/qT0qTJt4",
    "id" : 119414790560022529,
    "created_at" : "2011-09-29 14:14:39 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 119415304932687873,
  "created_at" : "2011-09-29 14:16:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/CyNeVWUN",
      "expanded_url" : "http:\/\/youtu.be\/CgQLmrAxJiM",
      "display_url" : "youtu.be\/CgQLmrAxJiM"
    } ]
  },
  "geo" : { },
  "id_str" : "119181810193268736",
  "text" : "\"I wish you, your families & all who celebrate Rosh Hashanah a sweet yr full of health, happiness & peace\" -Pres Obama: http:\/\/t.co\/CyNeVWUN",
  "id" : 119181810193268736,
  "created_at" : "2011-09-28 22:48:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luru\u2122",
      "screen_name" : "lurizzle",
      "indices" : [ 70, 79 ],
      "id_str" : "14673548",
      "id" : 14673548
    }, {
      "name" : "AllisonMY",
      "screen_name" : "AllisonMY",
      "indices" : [ 80, 90 ],
      "id_str" : "7765802",
      "id" : 7765802
    }, {
      "name" : "Joshua Dumais",
      "screen_name" : "JRGGLASS",
      "indices" : [ 91, 100 ],
      "id_str" : "2249550353",
      "id" : 2249550353
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/yzzfeOR0",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/tweetup",
      "display_url" : "whitehouse.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "119175870907817984",
  "text" : "Lots of tweeps signing up for the ROK State Arrival #WHTweetup, incl. @lurizzle @AllisonMY @JRGGlass Have you? http:\/\/t.co\/yzzfeOR0",
  "id" : 119175870907817984,
  "created_at" : "2011-09-28 22:25:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/119169690533761025\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/mBIw8j5s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AadgM8CCEAAR7zm.jpg",
      "id_str" : "119169690537955328",
      "id" : 119169690537955328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AadgM8CCEAAR7zm.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mBIw8j5s"
    } ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/otB0048y",
      "expanded_url" : "http:\/\/www.wh.gov\/tweetup",
      "display_url" : "wh.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "119169690533761025",
  "text" : "#WHTweetup: Come to @whitehouse for Republic of Korea arrival ceremony. Apply: http:\/\/t.co\/otB0048y You could be here: http:\/\/t.co\/mBIw8j5s",
  "id" : 119169690533761025,
  "created_at" : "2011-09-28 22:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 20, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/yzzfeOR0",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/tweetup",
      "display_url" : "whitehouse.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "119137648181919746",
  "text" : "Announcing our next #WHTweetup: Arrival Ceremony for Republic of Korea @ the White House on 10\/13. Apply now: http:\/\/t.co\/yzzfeOR0",
  "id" : 119137648181919746,
  "created_at" : "2011-09-28 19:53:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 58, 62 ]
    }, {
      "text" : "hcr",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "119136786969673728",
  "text" : "RT @jesseclee44: \"Obama Admin. Asks Supreme Court to Hear #HCR Lawsuit...We know #hcr is constitutional...confident SCOTUS will agree\" h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HCR",
        "indices" : [ 41, 45 ]
      }, {
        "text" : "hcr",
        "indices" : [ 64, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/b94pNgP9",
        "expanded_url" : "http:\/\/wh.gov\/4VN",
        "display_url" : "wh.gov\/4VN"
      } ]
    },
    "geo" : { },
    "id_str" : "119134319620009985",
    "text" : "\"Obama Admin. Asks Supreme Court to Hear #HCR Lawsuit...We know #hcr is constitutional...confident SCOTUS will agree\" http:\/\/t.co\/b94pNgP9",
    "id" : 119134319620009985,
    "created_at" : "2011-09-28 19:40:09 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 119136786969673728,
  "created_at" : "2011-09-28 19:49:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 125, 132 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/tOVqQ5CT",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "119100981064634368",
  "text" : "RT @WHLive: Happening @ 1:30ET: President Obama\u2019s 3rd Annual Back-to-School Speech. Watch live: http:\/\/t.co\/tOVqQ5CT Follow: @WHLive",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 113, 120 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/tOVqQ5CT",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "119100836407287808",
    "text" : "Happening @ 1:30ET: President Obama\u2019s 3rd Annual Back-to-School Speech. Watch live: http:\/\/t.co\/tOVqQ5CT Follow: @WHLive",
    "id" : 119100836407287808,
    "created_at" : "2011-09-28 17:27:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 119100981064634368,
  "created_at" : "2011-09-28 17:27:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 49, 55 ],
      "id_str" : "19380829",
      "id" : 19380829
    }, {
      "name" : "MSN Latino",
      "screen_name" : "msnlatino",
      "indices" : [ 56, 66 ],
      "id_str" : "126741060",
      "id" : 126741060
    }, {
      "name" : "aollatino",
      "screen_name" : "aollatino",
      "indices" : [ 67, 77 ],
      "id_str" : "1353019076",
      "id" : 1353019076
    }, {
      "name" : "HP LatinoVoices",
      "screen_name" : "LatinoVoices",
      "indices" : [ 78, 91 ],
      "id_str" : "351065668",
      "id" : 351065668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "119067528881385472",
  "text" : "Watch @ 11:25ET: President Obama\u2019s Roundtable w\/ @Yahoo @msnlatino @AOLLatino @LatinoVoices. Live in English & Spanish: http:\/\/t.co\/hhNoX4fh",
  "id" : 119067528881385472,
  "created_at" : "2011-09-28 15:14:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/hQeoy67v",
      "expanded_url" : "http:\/\/wh.gov\/4QR",
      "display_url" : "wh.gov\/4QR"
    } ]
  },
  "geo" : { },
  "id_str" : "118856174077616129",
  "text" : "RT @jesseclee44: Fact Check: Bang for the Buck in the American Jobs Act http:\/\/t.co\/hQeoy67v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/hQeoy67v",
        "expanded_url" : "http:\/\/wh.gov\/4QR",
        "display_url" : "wh.gov\/4QR"
      } ]
    },
    "geo" : { },
    "id_str" : "118856027046281217",
    "text" : "Fact Check: Bang for the Buck in the American Jobs Act http:\/\/t.co\/hQeoy67v",
    "id" : 118856027046281217,
    "created_at" : "2011-09-28 01:14:19 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 118856174077616129,
  "created_at" : "2011-09-28 01:14:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 81, 90 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/E2tOZUjB",
      "expanded_url" : "http:\/\/wh.gov\/4KC",
      "display_url" : "wh.gov\/4KC"
    } ]
  },
  "geo" : { },
  "id_str" : "118790795179458560",
  "text" : "In case you missed it: Yesterday, President Obama answered Q's at a Town Hall w\/ @LinkedIn. Watch video & learn more: http:\/\/t.co\/E2tOZUjB",
  "id" : 118790795179458560,
  "created_at" : "2011-09-27 20:55:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Follow us: @TheView",
      "screen_name" : "TheViewTV",
      "indices" : [ 21, 31 ],
      "id_str" : "2863349735",
      "id" : 2863349735
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/118786257890451457\/photo\/1",
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/wzg2fTyi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AaYDeQ-CIAApsex.jpg",
      "id_str" : "118786258658009088",
      "id" : 118786258658009088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AaYDeQ-CIAApsex.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/wzg2fTyi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/go08S2k4",
      "expanded_url" : "http:\/\/theview.abc.go.com\/blog\/joe-biden-talks-politics-and-stopping-domestic-violence",
      "display_url" : "theview.abc.go.com\/blog\/joe-biden\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "118787896214953984",
  "text" : "RT @VP: PHOTO: VP on @theviewtv set talking about Violence Against Women http:\/\/t.co\/go08S2k4 http:\/\/t.co\/wzg2fTyi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Follow us: @TheView",
        "screen_name" : "TheViewTV",
        "indices" : [ 13, 23 ],
        "id_str" : "2863349735",
        "id" : 2863349735
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/118786257890451457\/photo\/1",
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/wzg2fTyi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AaYDeQ-CIAApsex.jpg",
        "id_str" : "118786258658009088",
        "id" : 118786258658009088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AaYDeQ-CIAApsex.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/wzg2fTyi"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/go08S2k4",
        "expanded_url" : "http:\/\/theview.abc.go.com\/blog\/joe-biden-talks-politics-and-stopping-domestic-violence",
        "display_url" : "theview.abc.go.com\/blog\/joe-biden\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "118786257890451457",
    "text" : "PHOTO: VP on @theviewtv set talking about Violence Against Women http:\/\/t.co\/go08S2k4 http:\/\/t.co\/wzg2fTyi",
    "id" : 118786257890451457,
    "created_at" : "2011-09-27 20:37:06 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 118787896214953984,
  "created_at" : "2011-09-27 20:43:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "National Science Fdn",
      "screen_name" : "NSF",
      "indices" : [ 29, 33 ],
      "id_str" : "16245822",
      "id" : 16245822
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/118694689862975488\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/jZbmzQt5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AaWwMQpCAAAy_Oe.jpg",
      "id_str" : "118694689867169792",
      "id" : 118694689867169792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AaWwMQpCAAAy_Oe.jpg",
      "sizes" : [ {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 691,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1296,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/jZbmzQt5"
    } ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 78, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/VzBSdkrD",
      "expanded_url" : "http:\/\/1.usa.gov\/nstlfw",
      "display_url" : "1.usa.gov\/nstlfw"
    } ]
  },
  "geo" : { },
  "id_str" : "118694689862975488",
  "text" : "Video: Michelle Obama on new @NSF family-friendly policies & impt of women in #STEM: http:\/\/t.co\/VzBSdkrD Pic: http:\/\/t.co\/jZbmzQt5",
  "id" : 118694689862975488,
  "created_at" : "2011-09-27 14:33:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 35, 44 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/BIUUxpn6",
      "expanded_url" : "http:\/\/1.usa.gov\/o0d0Vp",
      "display_url" : "1.usa.gov\/o0d0Vp"
    } ]
  },
  "geo" : { },
  "id_str" : "118476603985633282",
  "text" : "Missed President Obama's Town Hall @LinkedIn? Check out the video here: http:\/\/t.co\/BIUUxpn6",
  "id" : 118476603985633282,
  "created_at" : "2011-09-27 00:06:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 3, 12 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118391908195237888",
  "text" : "RT @LinkedIn: LIVE VIDEO: Next audience question from Wayne (Arizona) on government's role in helping veterans find jobs http:\/\/t.co\/eXc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/eXc0Mcdy",
        "expanded_url" : "http:\/\/today.linkedin.com\/obama",
        "display_url" : "today.linkedin.com\/obama"
      } ]
    },
    "geo" : { },
    "id_str" : "118391562517479424",
    "text" : "LIVE VIDEO: Next audience question from Wayne (Arizona) on government's role in helping veterans find jobs http:\/\/t.co\/eXc0Mcdy",
    "id" : 118391562517479424,
    "created_at" : "2011-09-26 18:28:42 +0000",
    "user" : {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "protected" : false,
      "id_str" : "13058772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614583061448036352\/CBpFkPaz_normal.png",
      "id" : 13058772,
      "verified" : true
    }
  },
  "id" : 118391908195237888,
  "created_at" : "2011-09-26 18:30:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 70, 79 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "118383872588267520",
  "text" : "Happening now on http:\/\/t.co\/u95y7hhB : Putting America Back to Work: @LinkedIn Presents a Town Hall with President Obama",
  "id" : 118383872588267520,
  "created_at" : "2011-09-26 17:58:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 36, 45 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "118378641464893441",
  "text" : "Starting @ 2pm EDT: President Obama @LinkedIn Town Hall answering Q's on the economy & jobs. Watch live: http:\/\/t.co\/u95y7hhB.",
  "id" : 118378641464893441,
  "created_at" : "2011-09-26 17:37:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 3, 12 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "in",
      "indices" : [ 110, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/hBOToRfx",
      "expanded_url" : "http:\/\/bit.ly\/qhkRsJ",
      "display_url" : "bit.ly\/qhkRsJ"
    } ]
  },
  "geo" : { },
  "id_str" : "118377611738099712",
  "text" : "RT @LinkedIn: new post: Live from Mountain View: LinkedIn Town Hall with President Obama http:\/\/t.co\/hBOToRfx #in",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "in",
        "indices" : [ 96, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/hBOToRfx",
        "expanded_url" : "http:\/\/bit.ly\/qhkRsJ",
        "display_url" : "bit.ly\/qhkRsJ"
      } ]
    },
    "geo" : { },
    "id_str" : "118376687749693440",
    "text" : "new post: Live from Mountain View: LinkedIn Town Hall with President Obama http:\/\/t.co\/hBOToRfx #in",
    "id" : 118376687749693440,
    "created_at" : "2011-09-26 17:29:36 +0000",
    "user" : {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "protected" : false,
      "id_str" : "13058772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614583061448036352\/CBpFkPaz_normal.png",
      "id" : 13058772,
      "verified" : true
    }
  },
  "id" : 118377611738099712,
  "created_at" : "2011-09-26 17:33:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/1hsaXRdR",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/09\/26\/american-jobs-act-your-questions-answered#.ToCmESFR9So.twitter",
      "display_url" : "whitehouse.gov\/blog\/2011\/09\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "118373781961060354",
  "text" : "RT @JonCarson44: The American Jobs Act: Your Questions Answered - new Q&A based on questions we have been getting\nhttp:\/\/t.co\/1hsaXRdR \n ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 119, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/1hsaXRdR",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/09\/26\/american-jobs-act-your-questions-answered#.ToCmESFR9So.twitter",
        "display_url" : "whitehouse.gov\/blog\/2011\/09\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "118368813866692609",
    "text" : "The American Jobs Act: Your Questions Answered - new Q&A based on questions we have been getting\nhttp:\/\/t.co\/1hsaXRdR \n#JobsNow -",
    "id" : 118368813866692609,
    "created_at" : "2011-09-26 16:58:19 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 118373781961060354,
  "created_at" : "2011-09-26 17:18:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Weiner",
      "screen_name" : "jeffweiner",
      "indices" : [ 3, 14 ],
      "id_str" : "20348377",
      "id" : 20348377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118358542720827392",
  "text" : "RT @jeffweiner: Looking forward to today's town hall with President Obama re: putting America back to work.  Watch live at 11am PST. htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/8SWph0gN",
        "expanded_url" : "http:\/\/lnkd.in\/JsbV5m",
        "display_url" : "lnkd.in\/JsbV5m"
      } ]
    },
    "geo" : { },
    "id_str" : "118339438685331456",
    "text" : "Looking forward to today's town hall with President Obama re: putting America back to work.  Watch live at 11am PST. http:\/\/t.co\/8SWph0gN",
    "id" : 118339438685331456,
    "created_at" : "2011-09-26 15:01:35 +0000",
    "user" : {
      "name" : "Jeff Weiner",
      "screen_name" : "jeffweiner",
      "protected" : false,
      "id_str" : "20348377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500480798886084611\/P5XUPlTJ_normal.jpeg",
      "id" : 20348377,
      "verified" : true
    }
  },
  "id" : 118358542720827392,
  "created_at" : "2011-09-26 16:17:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 24, 35 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "National Science Fdn",
      "screen_name" : "NSF",
      "indices" : [ 38, 42 ],
      "id_str" : "16245822",
      "id" : 16245822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118357815432724480",
  "text" : "RT @whitehouseostp: The @whitehouse & @NSF Announce New Workplace Flexibility Policies to Support America\u2019s Scientists and Their Familie ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "National Science Fdn",
        "screen_name" : "NSF",
        "indices" : [ 18, 22 ],
        "id_str" : "16245822",
        "id" : 16245822
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/P6kthiUv",
        "expanded_url" : "http:\/\/go.ostp.gov\/qiTdr4",
        "display_url" : "go.ostp.gov\/qiTdr4"
      } ]
    },
    "geo" : { },
    "id_str" : "118355252725551105",
    "text" : "The @whitehouse & @NSF Announce New Workplace Flexibility Policies to Support America\u2019s Scientists and Their Families http:\/\/t.co\/P6kthiUv",
    "id" : 118355252725551105,
    "created_at" : "2011-09-26 16:04:25 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 118357815432724480,
  "created_at" : "2011-09-26 16:14:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 30, 39 ],
      "id_str" : "13058772",
      "id" : 13058772
    }, {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 60, 69 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/mrASZn2u",
      "expanded_url" : "http:\/\/1.usa.gov\/nC4GzU",
      "display_url" : "1.usa.gov\/nC4GzU"
    } ]
  },
  "geo" : { },
  "id_str" : "118301226050920448",
  "text" : "Happening today: Town Hall w\/ @LinkedIn: Pres Obama answers @LinkedIn members Qs on the economy & jobs. Watch live: http:\/\/t.co\/mrASZn2u",
  "id" : 118301226050920448,
  "created_at" : "2011-09-26 12:29:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "troops",
      "indices" : [ 60, 67 ]
    }, {
      "text" : "JoiningForces",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "118138807915778048",
  "text" : "RT @JoiningForces: We need 100% of Americans supporting our #troops & their families. Are you #JoiningForces? Get involved: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "troops",
        "indices" : [ 41, 48 ]
      }, {
        "text" : "JoiningForces",
        "indices" : [ 75, 89 ]
      }, {
        "text" : "emhe",
        "indices" : [ 126, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/e2SERM0m",
        "expanded_url" : "http:\/\/www.joiningforces.gov",
        "display_url" : "joiningforces.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "118138225880608770",
    "text" : "We need 100% of Americans supporting our #troops & their families. Are you #JoiningForces? Get involved: http:\/\/t.co\/e2SERM0m #emhe",
    "id" : 118138225880608770,
    "created_at" : "2011-09-26 01:42:02 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 118138807915778048,
  "created_at" : "2011-09-26 01:44:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/lDkl2wlD",
      "expanded_url" : "http:\/\/youtu.be\/N5JORMMTbNM",
      "display_url" : "youtu.be\/N5JORMMTbNM"
    } ]
  },
  "geo" : { },
  "id_str" : "117738155884548097",
  "text" : "#WestWingWeek or \"It's Math\": Don't miss your guide to everything that's happening @ 1600 Penn: http:\/\/t.co\/lDkl2wlD #JobsNow",
  "id" : 117738155884548097,
  "created_at" : "2011-09-24 23:12:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "extreme home",
      "screen_name" : "extremehome",
      "indices" : [ 39, 51 ],
      "id_str" : "142827079",
      "id" : 142827079
    }, {
      "name" : "Ty Pennington",
      "screen_name" : "typennington",
      "indices" : [ 76, 89 ],
      "id_str" : "50121225",
      "id" : 50121225
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 19, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117679243130974208",
  "text" : "RT @JoiningForces: #JoiningForces with @extremehome: First Lady Obama joins @typennington & team to support homeless female vets: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "extreme home",
        "screen_name" : "extremehome",
        "indices" : [ 20, 32 ],
        "id_str" : "142827079",
        "id" : 142827079
      }, {
        "name" : "Ty Pennington",
        "screen_name" : "typennington",
        "indices" : [ 57, 70 ],
        "id_str" : "50121225",
        "id" : 50121225
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JoiningForces",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/WQOBDS3s",
        "expanded_url" : "http:\/\/youtu.be\/sIf6c8emc1U",
        "display_url" : "youtu.be\/sIf6c8emc1U"
      } ]
    },
    "geo" : { },
    "id_str" : "117679003380363264",
    "text" : "#JoiningForces with @extremehome: First Lady Obama joins @typennington & team to support homeless female vets: http:\/\/t.co\/WQOBDS3s",
    "id" : 117679003380363264,
    "created_at" : "2011-09-24 19:17:15 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 117679243130974208,
  "created_at" : "2011-09-24 19:18:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fixNCLB",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/38nQbqVW",
      "expanded_url" : "http:\/\/youtu.be\/pAdWbOtJYX4",
      "display_url" : "youtu.be\/pAdWbOtJYX4"
    } ]
  },
  "geo" : { },
  "id_str" : "117631902608928768",
  "text" : "\"Now is the time to once again make our education system the envy of the world.\" -President Obama: http:\/\/t.co\/38nQbqVW #fixNCLB",
  "id" : 117631902608928768,
  "created_at" : "2011-09-24 16:10:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fixNCLB",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/KBCn7yb1",
      "expanded_url" : "http:\/\/wh.gov\/gAC",
      "display_url" : "wh.gov\/gAC"
    } ]
  },
  "geo" : { },
  "id_str" : "117372462286639104",
  "text" : "\"Our kids only get one shot at a decent education. They cannot afford to wait any longer\" -President Obama http:\/\/t.co\/KBCn7yb1 #fixNCLB",
  "id" : 117372462286639104,
  "created_at" : "2011-09-23 22:59:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/HKNVkkYH",
      "expanded_url" : "http:\/\/www.letsmove.gov\/tweetup",
      "display_url" : "letsmove.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "117315590447833089",
  "text" : "RT @letsmove: Don't miss your chance to come to the White House for our 1st #LetsMove Tweetup! Apply by 5ET today: http:\/\/t.co\/HKNVkkYH  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 62, 71 ]
      }, {
        "text" : "WHTweetup",
        "indices" : [ 122, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/HKNVkkYH",
        "expanded_url" : "http:\/\/www.letsmove.gov\/tweetup",
        "display_url" : "letsmove.gov\/tweetup"
      } ]
    },
    "geo" : { },
    "id_str" : "117315449456304129",
    "text" : "Don't miss your chance to come to the White House for our 1st #LetsMove Tweetup! Apply by 5ET today: http:\/\/t.co\/HKNVkkYH #WHTweetup",
    "id" : 117315449456304129,
    "created_at" : "2011-09-23 19:12:37 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 117315590447833089,
  "created_at" : "2011-09-23 19:13:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NCLB",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/cQ21Bjcd",
      "expanded_url" : "http:\/\/go.usa.gov\/881",
      "display_url" : "go.usa.gov\/881"
    } ]
  },
  "geo" : { },
  "id_str" : "117301713630797825",
  "text" : "RT @usedgov: What #NCLB Flexibility Means for You http:\/\/t.co\/cQ21Bjcd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NCLB",
        "indices" : [ 5, 10 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/cQ21Bjcd",
        "expanded_url" : "http:\/\/go.usa.gov\/881",
        "display_url" : "go.usa.gov\/881"
      } ]
    },
    "geo" : { },
    "id_str" : "117249285690621957",
    "text" : "What #NCLB Flexibility Means for You http:\/\/t.co\/cQ21Bjcd",
    "id" : 117249285690621957,
    "created_at" : "2011-09-23 14:49:42 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 117301713630797825,
  "created_at" : "2011-09-23 18:18:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 38, 47 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/w1ALzPup",
      "expanded_url" : "http:\/\/www.linkedin.com\/groups\/Putting-America-Back-Work-2011-4094334?trk=specialedition",
      "display_url" : "linkedin.com\/groups\/Putting\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "117289973320925184",
  "text" : "President Obama will join a Town Hall @LinkedIn on Monday. Have a question on #jobsnow & the economy? Ask here: http:\/\/t.co\/w1ALzPup",
  "id" : 117289973320925184,
  "created_at" : "2011-09-23 17:31:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2many",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117274219624140802",
  "text" : "RT @VP: \"I'm asking students to share ideas with me on how we can make things safer for you\"-VP talks #1is2many in NEW VIDEO http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1is2many",
        "indices" : [ 94, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/BwsPfdrF",
        "expanded_url" : "http:\/\/bit.ly\/rjTPtZ",
        "display_url" : "bit.ly\/rjTPtZ"
      } ]
    },
    "geo" : { },
    "id_str" : "117273876290998272",
    "text" : "\"I'm asking students to share ideas with me on how we can make things safer for you\"-VP talks #1is2many in NEW VIDEO http:\/\/t.co\/BwsPfdrF",
    "id" : 117273876290998272,
    "created_at" : "2011-09-23 16:27:25 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 117274219624140802,
  "created_at" : "2011-09-23 16:28:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "117266878061219840",
  "text" : "Happening @ 12ET: Live Q&A on Obama\u2019s trip to the UN General Assembly. Ask w\/ #WHChat & watch: http:\/\/t.co\/QDIpMRKE",
  "id" : 117266878061219840,
  "created_at" : "2011-09-23 15:59:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "117247750847987714",
  "text" : "RT @WHLive: Obama: We need to act now. We need to harness the good ideas coming out of our states and our schools & hold them to higher  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117246633556709378",
    "text" : "Obama: We need to act now. We need to harness the good ideas coming out of our states and our schools & hold them to higher standards.",
    "id" : 117246633556709378,
    "created_at" : "2011-09-23 14:39:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 117247750847987714,
  "created_at" : "2011-09-23 14:43:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 27, 30 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/Ri7HiQ1R",
      "expanded_url" : "http:\/\/wh.gov\/g1q",
      "display_url" : "wh.gov\/g1q"
    } ]
  },
  "geo" : { },
  "id_str" : "117234093271420928",
  "text" : "Have Qs on Obama\u2019s trip to @UN General Assembly? Ask Natl Security Advisor Ben Rhodes today. Ask: #WHChat Watch live: http:\/\/t.co\/Ri7HiQ1R",
  "id" : 117234093271420928,
  "created_at" : "2011-09-23 13:49:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 118, 125 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NCLB",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "117229795053539329",
  "text" : "Happening @ 10:15 ET: President Obama speaks on No Child Left Behind Reform #NCLB Watch: http:\/\/t.co\/hhNoX4fh Follow: @WHLive",
  "id" : 117229795053539329,
  "created_at" : "2011-09-23 13:32:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaInvents",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ibiEc2eU",
      "expanded_url" : "http:\/\/youtu.be\/mOErv8UQb7I",
      "display_url" : "youtu.be\/mOErv8UQb7I"
    } ]
  },
  "geo" : { },
  "id_str" : "116986830477475842",
  "text" : "\"We have to do everything we can to encourage the entrepreneurial spirit\" -President Obama on #AmericaInvents Act: http:\/\/t.co\/ibiEc2eU",
  "id" : 116986830477475842,
  "created_at" : "2011-09-22 21:26:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116980591286685696",
  "text" : "RT @GovernorOMalley: America wins when America creates jobs. Let's pass the President's jobs plan & let's pass it now. America can't wai ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 127, 138 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 118, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116965822102126592",
    "text" : "America wins when America creates jobs. Let's pass the President's jobs plan & let's pass it now. America can't wait. #JobsNow @WhiteHouse",
    "id" : 116965822102126592,
    "created_at" : "2011-09-22 20:03:19 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 116980591286685696,
  "created_at" : "2011-09-22 21:02:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Baker",
      "screen_name" : "MassGovernor",
      "indices" : [ 3, 16 ],
      "id_str" : "18023868",
      "id" : 18023868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116980505068584960",
  "text" : "RT @MassGovernor: Calling on Congress to pass the American Jobs Act \u2013 it\u2019ll make a difference for our people & economy. http:\/\/t.co\/6iKX ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 123, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/6iKXIfH8",
        "expanded_url" : "http:\/\/cot.ag\/o8u6gS",
        "display_url" : "cot.ag\/o8u6gS"
      } ]
    },
    "geo" : { },
    "id_str" : "116959661869109250",
    "text" : "Calling on Congress to pass the American Jobs Act \u2013 it\u2019ll make a difference for our people & economy. http:\/\/t.co\/6iKXIfH8 #JobsNow",
    "id" : 116959661869109250,
    "created_at" : "2011-09-22 19:38:51 +0000",
    "user" : {
      "name" : "Charlie Baker",
      "screen_name" : "MassGovernor",
      "protected" : false,
      "id_str" : "18023868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588540751430033408\/5rOCtVsL_normal.jpg",
      "id" : 18023868,
      "verified" : true
    }
  },
  "id" : 116980505068584960,
  "created_at" : "2011-09-22 21:01:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116965171108384768",
  "text" : "RT @PressSec: POTUS' msg at \"functionally obsolete\" bridge linking OH & KY: Mr Boehner, Mr McConnell, help pass this bill! Put Americans ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116963023951900672",
    "text" : "POTUS' msg at \"functionally obsolete\" bridge linking OH & KY: Mr Boehner, Mr McConnell, help pass this bill! Put Americans back to work!",
    "id" : 116963023951900672,
    "created_at" : "2011-09-22 19:52:12 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 116965171108384768,
  "created_at" : "2011-09-22 20:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 122, 129 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cincinnati",
      "indices" : [ 96, 107 ]
    }, {
      "text" : "Ohio",
      "indices" : [ 108, 113 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116941544208076800",
  "text" : "RT @WHLive: Today, President Obama speaks on the American Jobs Act @ the Brent Spence Bridge in #Cincinnati #Ohio. Follow @WHLive #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 110, 117 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cincinnati",
        "indices" : [ 84, 95 ]
      }, {
        "text" : "Ohio",
        "indices" : [ 96, 101 ]
      }, {
        "text" : "JobsNow",
        "indices" : [ 118, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116941440264839168",
    "text" : "Today, President Obama speaks on the American Jobs Act @ the Brent Spence Bridge in #Cincinnati #Ohio. Follow @WHLive #JobsNow",
    "id" : 116941440264839168,
    "created_at" : "2011-09-22 18:26:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 116941544208076800,
  "created_at" : "2011-09-22 18:26:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116931664470474752",
  "text" : "RT @letsmove: Announcing our first #LetsMove Tweetup @ the White House! Tour the garden, meet the chefs, talk healthy kids. Apply: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 21, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/HKNVkkYH",
        "expanded_url" : "http:\/\/www.letsmove.gov\/tweetup",
        "display_url" : "letsmove.gov\/tweetup"
      } ]
    },
    "geo" : { },
    "id_str" : "116927747028295681",
    "text" : "Announcing our first #LetsMove Tweetup @ the White House! Tour the garden, meet the chefs, talk healthy kids. Apply: http:\/\/t.co\/HKNVkkYH",
    "id" : 116927747028295681,
    "created_at" : "2011-09-22 17:32:01 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 116931664470474752,
  "created_at" : "2011-09-22 17:47:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 3, 12 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/dHvIwU7D",
      "expanded_url" : "http:\/\/lnkd.in\/ask-obama",
      "display_url" : "lnkd.in\/ask-obama"
    } ]
  },
  "geo" : { },
  "id_str" : "116908104242839554",
  "text" : "RT @LinkedIn: We\u2019d love to hear your questions for the President\u2019s Monday LinkedIn Town Hall. Ask here http:\/\/t.co\/dHvIwU7D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/dHvIwU7D",
        "expanded_url" : "http:\/\/lnkd.in\/ask-obama",
        "display_url" : "lnkd.in\/ask-obama"
      } ]
    },
    "geo" : { },
    "id_str" : "116890248264425473",
    "text" : "We\u2019d love to hear your questions for the President\u2019s Monday LinkedIn Town Hall. Ask here http:\/\/t.co\/dHvIwU7D",
    "id" : 116890248264425473,
    "created_at" : "2011-09-22 15:03:01 +0000",
    "user" : {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "protected" : false,
      "id_str" : "13058772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614583061448036352\/CBpFkPaz_normal.png",
      "id" : 13058772,
      "verified" : true
    }
  },
  "id" : 116908104242839554,
  "created_at" : "2011-09-22 16:13:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeThePeople",
      "indices" : [ 27, 39 ]
    }, {
      "text" : "whoops",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/3peTz2aB",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/petitions",
      "display_url" : "whitehouse.gov\/petitions"
    } ]
  },
  "geo" : { },
  "id_str" : "116896640207556608",
  "text" : "Tweeted the wrong link for #WeThePeople earlier, here's the right one: http:\/\/t.co\/3peTz2aB #whoops",
  "id" : 116896640207556608,
  "created_at" : "2011-09-22 15:28:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeThePeople",
      "indices" : [ 32, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/TB0dTXds",
      "expanded_url" : "http:\/\/bit.ly\/p2odZj",
      "display_url" : "bit.ly\/p2odZj"
    } ]
  },
  "geo" : { },
  "id_str" : "116887153820180481",
  "text" : "RT @macon44: Thrilled to launch #WeThePeople today. It's your voice in our government, so what are you waiting for? http:\/\/t.co\/TB0dTXds ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeThePeople",
        "indices" : [ 19, 31 ]
      }, {
        "text" : "gov20",
        "indices" : [ 124, 130 ]
      }, {
        "text" : "opengov",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/TB0dTXds",
        "expanded_url" : "http:\/\/bit.ly\/p2odZj",
        "display_url" : "bit.ly\/p2odZj"
      } ]
    },
    "geo" : { },
    "id_str" : "116864000494551041",
    "text" : "Thrilled to launch #WeThePeople today. It's your voice in our government, so what are you waiting for? http:\/\/t.co\/TB0dTXds #gov20 #opengov",
    "id" : 116864000494551041,
    "created_at" : "2011-09-22 13:18:43 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 116887153820180481,
  "created_at" : "2011-09-22 14:50:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116662188550262785",
  "text" : "RT @pfeiffer44: We are pleased that the House of Representatives today rejected efforts to put politics above the needs of communities i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116655922478202880",
    "text" : "We are pleased that the House of Representatives today rejected efforts to put politics above the needs of communities impacted by disasters",
    "id" : 116655922478202880,
    "created_at" : "2011-09-21 23:31:53 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 116662188550262785,
  "created_at" : "2011-09-21 23:56:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcworks",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "hcr",
      "indices" : [ 114, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/f6lMy0zq",
      "expanded_url" : "http:\/\/1.usa.gov\/qnGcZA",
      "display_url" : "1.usa.gov\/qnGcZA"
    } ]
  },
  "geo" : { },
  "id_str" : "116651474561400832",
  "text" : "RT @HealthCareGov: One Million More Young Adults Have Coverage Thanks to Health Law http:\/\/t.co\/f6lMy0zq #hcworks #hcr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcworks",
        "indices" : [ 86, 94 ]
      }, {
        "text" : "hcr",
        "indices" : [ 95, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/f6lMy0zq",
        "expanded_url" : "http:\/\/1.usa.gov\/qnGcZA",
        "display_url" : "1.usa.gov\/qnGcZA"
      } ]
    },
    "geo" : { },
    "id_str" : "116545266122895360",
    "text" : "One Million More Young Adults Have Coverage Thanks to Health Law http:\/\/t.co\/f6lMy0zq #hcworks #hcr",
    "id" : 116545266122895360,
    "created_at" : "2011-09-21 16:12:11 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 116651474561400832,
  "created_at" : "2011-09-21 23:14:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/2nIFgkMF",
      "expanded_url" : "http:\/\/wh.gov\/g4R",
      "display_url" : "wh.gov\/g4R"
    } ]
  },
  "geo" : { },
  "id_str" : "116630580816388098",
  "text" : "Buffett Rule Facts & Fictions: This is a rule of simple fairness. Look at what this rule is and is not: http:\/\/t.co\/2nIFgkMF",
  "id" : 116630580816388098,
  "created_at" : "2011-09-21 21:51:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CGI",
      "screen_name" : "ClintonGlobal",
      "indices" : [ 43, 57 ],
      "id_str" : "68999404",
      "id" : 68999404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CGI2011",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "116580919493664769",
  "text" : "Happening @ 2:45ET: President Obama speaks @ClintonGlobal Initiative in NYC. Watch live: http:\/\/t.co\/hhNoX4fh #CGI2011",
  "id" : 116580919493664769,
  "created_at" : "2011-09-21 18:33:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 72, 78 ],
      "id_str" : "19380829",
      "id" : 19380829
    }, {
      "name" : "MSN Latino",
      "screen_name" : "msnlatino",
      "indices" : [ 79, 89 ],
      "id_str" : "126741060",
      "id" : 126741060
    }, {
      "name" : "aollatino",
      "screen_name" : "aollatino",
      "indices" : [ 90, 100 ],
      "id_str" : "1353019076",
      "id" : 1353019076
    }, {
      "name" : "HP LatinoVoices",
      "screen_name" : "LatinoVoices",
      "indices" : [ 101, 114 ],
      "id_str" : "351065668",
      "id" : 351065668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116569898989264896",
  "text" : "RT @lacasablanca: Presidente Obama te responde en foro por Internet con @Yahoo @MSNLatino @AOLLatino @LatinoVoices. Somete tus preguntas ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yahoo",
        "screen_name" : "Yahoo",
        "indices" : [ 54, 60 ],
        "id_str" : "19380829",
        "id" : 19380829
      }, {
        "name" : "MSN Latino",
        "screen_name" : "msnlatino",
        "indices" : [ 61, 71 ],
        "id_str" : "126741060",
        "id" : 126741060
      }, {
        "name" : "aollatino",
        "screen_name" : "aollatino",
        "indices" : [ 72, 82 ],
        "id_str" : "1353019076",
        "id" : 1353019076
      }, {
        "name" : "HP LatinoVoices",
        "screen_name" : "LatinoVoices",
        "indices" : [ 83, 96 ],
        "id_str" : "351065668",
        "id" : 351065668
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/U2V2pjda",
        "expanded_url" : "http:\/\/wh.gov\/gYU",
        "display_url" : "wh.gov\/gYU"
      } ]
    },
    "geo" : { },
    "id_str" : "116569551281471488",
    "text" : "Presidente Obama te responde en foro por Internet con @Yahoo @MSNLatino @AOLLatino @LatinoVoices. Somete tus preguntas: http:\/\/t.co\/U2V2pjda",
    "id" : 116569551281471488,
    "created_at" : "2011-09-21 17:48:41 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 116569898989264896,
  "created_at" : "2011-09-21 17:50:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 51, 57 ],
      "id_str" : "19380829",
      "id" : 19380829
    }, {
      "name" : "MSN Latino",
      "screen_name" : "msnlatino",
      "indices" : [ 58, 68 ],
      "id_str" : "126741060",
      "id" : 126741060
    }, {
      "name" : "aollatino",
      "screen_name" : "aollatino",
      "indices" : [ 69, 79 ],
      "id_str" : "1353019076",
      "id" : 1353019076
    }, {
      "name" : "HP LatinoVoices",
      "screen_name" : "LatinoVoices",
      "indices" : [ 80, 93 ],
      "id_str" : "351065668",
      "id" : 351065668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/483DicQw",
      "expanded_url" : "http:\/\/wh.gov\/gg3",
      "display_url" : "wh.gov\/gg3"
    } ]
  },
  "geo" : { },
  "id_str" : "116562922771197953",
  "text" : "Open for Questions Roundtable w\/ President Obama & @Yahoo @msnlatino @AOLLatino @LatinoVoices. Send your questions: http:\/\/t.co\/483DicQw",
  "id" : 116562922771197953,
  "created_at" : "2011-09-21 17:22:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UN",
      "indices" : [ 26, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116525689146064898",
  "text" : "RT @jesseclee44: Obama at #UN: \"No country should deny people their rights because of who they love\u2026stand up for the rights of gays & le ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UN",
        "indices" : [ 9, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116523520258871296",
    "text" : "Obama at #UN: \"No country should deny people their rights because of who they love\u2026stand up for the rights of gays & lesbians everywhere\"",
    "id" : 116523520258871296,
    "created_at" : "2011-09-21 14:45:46 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 116525689146064898,
  "created_at" : "2011-09-21 14:54:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUS",
      "indices" : [ 11, 17 ]
    }, {
      "text" : "UNGA",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116525223490228224",
  "text" : "RT @USAID: #POTUS on women's rights at #UNGA \"No country can reach its full potential, when half of its population cannot reach theirs.\" ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUS",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "UNGA",
        "indices" : [ 28, 33 ]
      }, {
        "text" : "women",
        "indices" : [ 126, 132 ]
      }, {
        "text" : "girls",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116525078224707586",
    "text" : "#POTUS on women's rights at #UNGA \"No country can reach its full potential, when half of its population cannot reach theirs.\" #women #girls",
    "id" : 116525078224707586,
    "created_at" : "2011-09-21 14:51:58 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 116525223490228224,
  "created_at" : "2011-09-21 14:52:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 109, 112 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116525015721189376",
  "text" : "RT @WHLive: \"Together, let us work to make, not merely a peace, but a peace that will last\" -President Obama @UN General Assembly #UNGA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "United Nations",
        "screen_name" : "UN",
        "indices" : [ 97, 100 ],
        "id_str" : "14159148",
        "id" : 14159148
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 118, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116524328052465665",
    "text" : "\"Together, let us work to make, not merely a peace, but a peace that will last\" -President Obama @UN General Assembly #UNGA",
    "id" : 116524328052465665,
    "created_at" : "2011-09-21 14:48:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 116525015721189376,
  "created_at" : "2011-09-21 14:51:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 56, 59 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/xrOHuqTm",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "116510431568347136",
  "text" : "RT @WHLive: Happening @ 10ET: President Obama addresses @UN General Assembly. Watch live: http:\/\/t.co\/xrOHuqTm #UNGA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "United Nations",
        "screen_name" : "UN",
        "indices" : [ 44, 47 ],
        "id_str" : "14159148",
        "id" : 14159148
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 99, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/xrOHuqTm",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "116510294506868736",
    "text" : "Happening @ 10ET: President Obama addresses @UN General Assembly. Watch live: http:\/\/t.co\/xrOHuqTm #UNGA",
    "id" : 116510294506868736,
    "created_at" : "2011-09-21 13:53:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 116510431568347136,
  "created_at" : "2011-09-21 13:53:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 52, 55 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/116340553263759360\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/dPxXwRmz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AZ1THeaCQAAHhbL.jpg",
      "id_str" : "116340553267953664",
      "id" : 116340553267953664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZ1THeaCQAAHhbL.jpg",
      "sizes" : [ {
        "h" : 1258,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dPxXwRmz"
    } ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 45, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/1fIUJcv3",
      "expanded_url" : "http:\/\/wh.gov\/grv",
      "display_url" : "wh.gov\/grv"
    } ]
  },
  "geo" : { },
  "id_str" : "116340553263759360",
  "text" : "\"We will stand with you\" -President Obama on #Libya @UN General Assembly in NY. Video: http:\/\/t.co\/1fIUJcv3 Pic: http:\/\/t.co\/dPxXwRmz",
  "id" : 116340553263759360,
  "created_at" : "2011-09-21 02:38:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0644\u062E\u0627\u0631\u062C\u064A\u0629 \u0627\u0644\u0623\u0645\u0631\u064A\u0643\u064A\u0629",
      "screen_name" : "USAbilAraby",
      "indices" : [ 3, 15 ],
      "id_str" : "249409411",
      "id" : 249409411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116338407344578560",
  "text" : "RT @USAbilAraby: \u0627\u0644\u0631\u0626\u064A\u0633 \u0623\u0648\u0628\u0627\u0645\u0627: \u0633\u0648\u0641 \u0646\u0642\u0641 \u0645\u0639\u0643\u0645 \u0648\u0627\u0646\u062A\u0645 \u062A\u063A\u062A\u0646\u0645\u0648\u0646 \u0647\u0630\u0647 \u0627\u0644\u0644\u062D\u0638\u0629 \u0627\u0644\u0648\u0627\u0639\u062F\u0629  \u0628\u064A\u0646\u0645\u0627 \u062A\u062D\u0635\u0644\u0648\u0646 \u0639\u0644\u0649 \u0627\u0644\u062D\u0631\u064A\u0629 \u0648\u0627\u0644\u0643\u0631\u0627\u0645\u0629  \u0648\u0627\u0644\u0641\u0631\u0635\u0629 \u0627\u0644\u062A\u064A \u062A\u0633\u062A\u062D\u0642\u0648\u0646\u0647\u0627  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 119, 125 ]
      }, {
        "text" : "Libya",
        "indices" : [ 126, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116197822461771776",
    "text" : "\u0627\u0644\u0631\u0626\u064A\u0633 \u0623\u0648\u0628\u0627\u0645\u0627: \u0633\u0648\u0641 \u0646\u0642\u0641 \u0645\u0639\u0643\u0645 \u0648\u0627\u0646\u062A\u0645 \u062A\u063A\u062A\u0646\u0645\u0648\u0646 \u0647\u0630\u0647 \u0627\u0644\u0644\u062D\u0638\u0629 \u0627\u0644\u0648\u0627\u0639\u062F\u0629  \u0628\u064A\u0646\u0645\u0627 \u062A\u062D\u0635\u0644\u0648\u0646 \u0639\u0644\u0649 \u0627\u0644\u062D\u0631\u064A\u0629 \u0648\u0627\u0644\u0643\u0631\u0627\u0645\u0629  \u0648\u0627\u0644\u0641\u0631\u0635\u0629 \u0627\u0644\u062A\u064A \u062A\u0633\u062A\u062D\u0642\u0648\u0646\u0647\u0627 #Obama #Libya",
    "id" : 116197822461771776,
    "created_at" : "2011-09-20 17:11:34 +0000",
    "user" : {
      "name" : "\u0627\u0644\u062E\u0627\u0631\u062C\u064A\u0629 \u0627\u0644\u0623\u0645\u0631\u064A\u0643\u064A\u0629",
      "screen_name" : "USAbilAraby",
      "protected" : false,
      "id_str" : "249409411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551745952730451968\/hpIBWtgZ_normal.png",
      "id" : 249409411,
      "verified" : true
    }
  },
  "id" : 116338407344578560,
  "created_at" : "2011-09-21 02:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/ed8VIwRD",
      "expanded_url" : "http:\/\/wh.gov\/gr9",
      "display_url" : "wh.gov\/gr9"
    } ]
  },
  "geo" : { },
  "id_str" : "116312482653540352",
  "text" : "A promise made is now a promise kept. As of 12:01am today, \"Don\u2019t Ask, Don\u2019t Tell\" is over: http:\/\/t.co\/ed8VIwRD #DADT",
  "id" : 116312482653540352,
  "created_at" : "2011-09-21 00:47:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 3, 12 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "in",
      "indices" : [ 115, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/rTY3aFSE",
      "expanded_url" : "http:\/\/bit.ly\/orK5lU",
      "display_url" : "bit.ly\/orK5lU"
    } ]
  },
  "geo" : { },
  "id_str" : "116285093001166848",
  "text" : "RT @LinkedIn: new post: LinkedIn Town Hall with President Obama: Putting America Back to Work http:\/\/t.co\/rTY3aFSE #in",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "in",
        "indices" : [ 101, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/rTY3aFSE",
        "expanded_url" : "http:\/\/bit.ly\/orK5lU",
        "display_url" : "bit.ly\/orK5lU"
      } ]
    },
    "geo" : { },
    "id_str" : "116279334465060864",
    "text" : "new post: LinkedIn Town Hall with President Obama: Putting America Back to Work http:\/\/t.co\/rTY3aFSE #in",
    "id" : 116279334465060864,
    "created_at" : "2011-09-20 22:35:28 +0000",
    "user" : {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "protected" : false,
      "id_str" : "13058772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614583061448036352\/CBpFkPaz_normal.png",
      "id" : 13058772,
      "verified" : true
    }
  },
  "id" : 116285093001166848,
  "created_at" : "2011-09-20 22:58:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 11, 20 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/lO9gmrUk",
      "expanded_url" : "http:\/\/www.linkedin.com\/groups\/Putting-America-Back-Work-2011-4094334?gid=4094334",
      "display_url" : "linkedin.com\/groups\/Putting\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "116283373789515776",
  "text" : "Announcing @LinkedIn Town Hall w\/ President Obama. Ask the President your ?s on #jobsnow & the economy: http:\/\/t.co\/lO9gmrUk",
  "id" : 116283373789515776,
  "created_at" : "2011-09-20 22:51:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1is2many",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116278347360772096",
  "text" : "RT @VP: \"No means no, no matter what\"-watch VP's #1is2many message & share your ideas to prevent dating violence & assault http:\/\/t.co\/A ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1is2many",
        "indices" : [ 41, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/A91FkweH",
        "expanded_url" : "http:\/\/1.usa.gov\/oKSKJU",
        "display_url" : "1.usa.gov\/oKSKJU"
      } ]
    },
    "geo" : { },
    "id_str" : "116274884941840385",
    "text" : "\"No means no, no matter what\"-watch VP's #1is2many message & share your ideas to prevent dating violence & assault http:\/\/t.co\/A91FkweH",
    "id" : 116274884941840385,
    "created_at" : "2011-09-20 22:17:47 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 116278347360772096,
  "created_at" : "2011-09-20 22:31:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/NmiqLl3E",
      "expanded_url" : "http:\/\/wh.gov\/gCZ",
      "display_url" : "wh.gov\/gCZ"
    } ]
  },
  "geo" : { },
  "id_str" : "116234422457597952",
  "text" : "The United States releases its Open Government National Action Plan. Highlights here: http:\/\/t.co\/NmiqLl3E",
  "id" : 116234422457597952,
  "created_at" : "2011-09-20 19:37:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116234045423230976",
  "text" : "RT @aneeshchopra: President Obama: \"...information is power\u2014helping people make informed decisions and entrepreneurs turn data into...ne ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "116233120306561026",
    "text" : "President Obama: \"...information is power\u2014helping people make informed decisions and entrepreneurs turn data into...new jobs \"",
    "id" : 116233120306561026,
    "created_at" : "2011-09-20 19:31:50 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 116234045423230976,
  "created_at" : "2011-09-20 19:35:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116233073301004289",
  "text" : "RT @aneeshchopra: Join us live as President Obama and other Heads of State launch their Open Govt National Action Plans. http:\/\/t.co\/WTb ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/WTbypp12",
        "expanded_url" : "http:\/\/1.usa.gov\/UT2FE",
        "display_url" : "1.usa.gov\/UT2FE"
      } ]
    },
    "geo" : { },
    "id_str" : "116215524207239168",
    "text" : "Join us live as President Obama and other Heads of State launch their Open Govt National Action Plans. http:\/\/t.co\/WTbypp12",
    "id" : 116215524207239168,
    "created_at" : "2011-09-20 18:21:54 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 116233073301004289,
  "created_at" : "2011-09-20 19:31:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 69, 75 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/116176453573410819\/photo\/1",
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/PhRy2Aqd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AZy93ncCAAAVomf.jpg",
      "id_str" : "116176453581799424",
      "id" : 116176453581799424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZy93ncCAAAVomf.jpg",
      "sizes" : [ {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 610
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 467,
        "resize" : "fit",
        "w" : 610
      } ],
      "display_url" : "pic.twitter.com\/PhRy2Aqd"
    } ],
    "hashtags" : [ {
      "text" : "FWD",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "HornofAfrica",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/IPUmv4mW",
      "expanded_url" : "http:\/\/www.usaid.gov\/fwd\/",
      "display_url" : "usaid.gov\/fwd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "116176453573410819",
  "text" : "#FWD the facts about famine, war & drought in the #HornofAfrica. New @USAID campaign: http:\/\/t.co\/IPUmv4mW http:\/\/t.co\/PhRy2Aqd",
  "id" : 116176453573410819,
  "created_at" : "2011-09-20 15:46:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116148562349391872",
  "text" : "RT @jesseclee44: Obama: \"patriotic Americans...will no longer have to lie about who they are in order to serve the country they love\" ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/LfWc3gV1",
        "expanded_url" : "http:\/\/wh.gov\/gCN",
        "display_url" : "wh.gov\/gCN"
      } ]
    },
    "geo" : { },
    "id_str" : "116140131257294849",
    "text" : "Obama: \"patriotic Americans...will no longer have to lie about who they are in order to serve the country they love\" http:\/\/t.co\/LfWc3gV1",
    "id" : 116140131257294849,
    "created_at" : "2011-09-20 13:22:19 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 116148562349391872,
  "created_at" : "2011-09-20 13:55:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "116147861661556736",
  "text" : "RT @JonCarson44: Lots of groups supporting President's balanced approach to deficit reduction - here's Alliance for Retired Americans: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/ZqeXgJIh",
        "expanded_url" : "http:\/\/www.retiredamericans.org\/newsroom\/press-releases\/view\/2011-09-retiree-leader-praises-obama-economic-proposal",
        "display_url" : "retiredamericans.org\/newsroom\/press\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "116134789379137536",
    "text" : "Lots of groups supporting President's balanced approach to deficit reduction - here's Alliance for Retired Americans: http:\/\/t.co\/ZqeXgJIh",
    "id" : 116134789379137536,
    "created_at" : "2011-09-20 13:01:06 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 116147861661556736,
  "created_at" : "2011-09-20 13:53:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115998909721092096",
  "text" : "As of 12:01 am, the\u00A0repeal of the\u00A0discriminatory law known as \u2018Don\u2019t Ask, Don\u2019t Tell\u2019\u00A0finally & formally\u00A0takes effect. #DADT",
  "id" : 115998909721092096,
  "created_at" : "2011-09-20 04:01:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/I8VA7qAa",
      "expanded_url" : "http:\/\/youtu.be\/gdqxBrKZmUw",
      "display_url" : "youtu.be\/gdqxBrKZmUw"
    } ]
  },
  "geo" : { },
  "id_str" : "115957425038823425",
  "text" : "\"This is not class warfare. It\u2019s math.\" -President Obama announces his plan for economic growth & deficit reduction: http:\/\/t.co\/I8VA7qAa",
  "id" : 115957425038823425,
  "created_at" : "2011-09-20 01:16:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/JXxfbNbE",
      "expanded_url" : "http:\/\/1.usa.gov\/pIVjcQ",
      "display_url" : "1.usa.gov\/pIVjcQ"
    } ]
  },
  "geo" : { },
  "id_str" : "115878909274370048",
  "text" : "\"This is not class warfare. It\u2019s math.\" -President Obama on his plan for economic growth & deficit reduction. Video: http:\/\/t.co\/JXxfbNbE",
  "id" : 115878909274370048,
  "created_at" : "2011-09-19 20:04:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/dA9BYM7K",
      "expanded_url" : "http:\/\/1.usa.gov\/pcTy1c",
      "display_url" : "1.usa.gov\/pcTy1c"
    } ]
  },
  "geo" : { },
  "id_str" : "115846207846359040",
  "text" : "As a Nation, we can live within our means while still making the investments we need to prosper. Pres Obama's plan: http:\/\/t.co\/dA9BYM7K",
  "id" : 115846207846359040,
  "created_at" : "2011-09-19 17:54:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/xrOHuqTm",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "115808713004171265",
  "text" : "RT @WHLive: The President's remarks on deficit reduction just concluded. Video will be posted soon: http:\/\/t.co\/xrOHuqTm (thanks for fol ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 131, 138 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/xrOHuqTm",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "115807383183310848",
    "text" : "The President's remarks on deficit reduction just concluded. Video will be posted soon: http:\/\/t.co\/xrOHuqTm (thanks for following @WHLive)",
    "id" : 115807383183310848,
    "created_at" : "2011-09-19 15:20:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115808713004171265,
  "created_at" : "2011-09-19 15:25:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "countrybeforeparty",
      "indices" : [ 51, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115806509522366465",
  "text" : "RT @WHLive: Obama:  It\u2019s our responsibility to put #countrybeforeparty. It\u2019s our responsibility to do what\u2019s right for our future.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "countrybeforeparty",
        "indices" : [ 39, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115806297387053058",
    "text" : "Obama:  It\u2019s our responsibility to put #countrybeforeparty. It\u2019s our responsibility to do what\u2019s right for our future.",
    "id" : 115806297387053058,
    "created_at" : "2011-09-19 15:15:47 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115806509522366465,
  "created_at" : "2011-09-19 15:16:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115806494456426496",
  "text" : "RT @WHLive: Obama: I will not support any plan that puts all the burden for closing our deficit on ordinary Americans.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115805859895980035",
    "text" : "Obama: I will not support any plan that puts all the burden for closing our deficit on ordinary Americans.",
    "id" : 115805859895980035,
    "created_at" : "2011-09-19 15:14:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115806494456426496,
  "created_at" : "2011-09-19 15:16:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115805961653989377",
  "text" : "RT @WHLive: Obama: We can\u2019t afford both. This isn\u2019t class warfare. It\u2019s math.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115805611295387648",
    "text" : "Obama: We can\u2019t afford both. This isn\u2019t class warfare. It\u2019s math.",
    "id" : 115805611295387648,
    "created_at" : "2011-09-19 15:13:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115805961653989377,
  "created_at" : "2011-09-19 15:14:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115805951713480704",
  "text" : "RT @WHLive: Obama: Either we ask seniors to pay more for Medicare, or we ask the wealthiest Americans to pay their fair share in taxes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115805529678422017",
    "text" : "Obama: Either we ask seniors to pay more for Medicare, or we ask the wealthiest Americans to pay their fair share in taxes.",
    "id" : 115805529678422017,
    "created_at" : "2011-09-19 15:12:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115805951713480704,
  "created_at" : "2011-09-19 15:14:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115805244973268993",
  "text" : "RT @WHLive: Obama: the last time I checked, the only pledge that really matters is the pledge we take to uphold the Constitution.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115805023841173505",
    "text" : "Obama: the last time I checked, the only pledge that really matters is the pledge we take to uphold the Constitution.",
    "id" : 115805023841173505,
    "created_at" : "2011-09-19 15:10:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115805244973268993,
  "created_at" : "2011-09-19 15:11:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115805231018803201",
  "text" : "RT @WHLive: Obama: Any reform should follow a simple principle: middle-class families shouldn\u2019t pay higher taxes than millionaires & bil ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115804790130348032",
    "text" : "Obama: Any reform should follow a simple principle: middle-class families shouldn\u2019t pay higher taxes than millionaires & billionaires.",
    "id" : 115804790130348032,
    "created_at" : "2011-09-19 15:09:48 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115805231018803201,
  "created_at" : "2011-09-19 15:11:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115805214107385856",
  "text" : "RT @WHLive: Obama: Warren Buffett\u2019s secretary shouldn\u2019t pay a higher tax rate than Warren Buffett.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115804718936240128",
    "text" : "Obama: Warren Buffett\u2019s secretary shouldn\u2019t pay a higher tax rate than Warren Buffett.",
    "id" : 115804718936240128,
    "created_at" : "2011-09-19 15:09:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115805214107385856,
  "created_at" : "2011-09-19 15:11:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115804589940408320",
  "text" : "RT @WHLive: Obama: This plan asks the wealthiest Americans to go back to paying the same tax rates they paid during the nineties, before ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115804114662858752",
    "text" : "Obama: This plan asks the wealthiest Americans to go back to paying the same tax rates they paid during the nineties, before Bush tax cuts.",
    "id" : 115804114662858752,
    "created_at" : "2011-09-19 15:07:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115804589940408320,
  "created_at" : "2011-09-19 15:09:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115804124389457920",
  "text" : "RT @WHLive: Obama: If we\u2019re going to meet our responsibilities, we\u2019re going to have to do it together.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115803872315973632",
    "text" : "Obama: If we\u2019re going to meet our responsibilities, we\u2019re going to have to do it together.",
    "id" : 115803872315973632,
    "created_at" : "2011-09-19 15:06:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115804124389457920,
  "created_at" : "2011-09-19 15:07:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115802731654033411",
  "text" : "RT @WHLive: Obama: For us to solve this problem, everyone \u2013 including the wealthiest Americans & biggest corporations \u2013 has to pay their ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115802301511372801",
    "text" : "Obama: For us to solve this problem, everyone \u2013 including the wealthiest Americans & biggest corporations \u2013 has to pay their fair share.",
    "id" : 115802301511372801,
    "created_at" : "2011-09-19 14:59:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115802731654033411,
  "created_at" : "2011-09-19 15:01:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115802647130423297",
  "text" : "RT @WHLive: Obama: Govt has to do what families across this country have been doing: we have to cut what we can\u2019t afford to pay for what ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115802028948729857",
    "text" : "Obama: Govt has to do what families across this country have been doing: we have to cut what we can\u2019t afford to pay for what really matters",
    "id" : 115802028948729857,
    "created_at" : "2011-09-19 14:58:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115802647130423297,
  "created_at" : "2011-09-19 15:01:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "115802558001451008",
  "text" : "RT @WHLive: Obama: Today, I\u2019m releasing a plan that details how to pay for this bill while also paying down our debt over time #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 115, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "115801681219952642",
    "text" : "Obama: Today, I\u2019m releasing a plan that details how to pay for this bill while also paying down our debt over time #JobsNow",
    "id" : 115801681219952642,
    "created_at" : "2011-09-19 14:57:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115802558001451008,
  "created_at" : "2011-09-19 15:00:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/xrOHuqTm",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "115795146259435521",
  "text" : "RT @WHLive: Starting soon: Obama speaks on his vision for a balanced approach to reducing our deficit. Watch: http:\/\/t.co\/xrOHuqTm & fol ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 129, 136 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/xrOHuqTm",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "115795046560841728",
    "text" : "Starting soon: Obama speaks on his vision for a balanced approach to reducing our deficit. Watch: http:\/\/t.co\/xrOHuqTm & follow: @WHLive",
    "id" : 115795046560841728,
    "created_at" : "2011-09-19 14:31:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 115795146259435521,
  "created_at" : "2011-09-19 14:31:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "115785842705960960",
  "text" : "10:30ET: Obama speaks on a balanced approach to reducing our deficit & living within our means. Watch live: http:\/\/t.co\/hhNoX4fh #JobsNow",
  "id" : 115785842705960960,
  "created_at" : "2011-09-19 13:54:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/7Sih4INA",
      "expanded_url" : "http:\/\/youtu.be\/NTdqip5TC-s",
      "display_url" : "youtu.be\/NTdqip5TC-s"
    } ]
  },
  "geo" : { },
  "id_str" : "115592718842986496",
  "text" : "\"The time for action is now\" -President Obama on passing the American Jobs Act: http:\/\/t.co\/7Sih4INA #JobsNow",
  "id" : 115592718842986496,
  "created_at" : "2011-09-19 01:07:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/7Sih4INA",
      "expanded_url" : "http:\/\/youtu.be\/NTdqip5TC-s",
      "display_url" : "youtu.be\/NTdqip5TC-s"
    } ]
  },
  "geo" : { },
  "id_str" : "115025927146184704",
  "text" : "\"You can help make it happen by telling your congressperson to pass this jobs bill right away\" -Pres Obama: http:\/\/t.co\/7Sih4INA #JobsNow",
  "id" : 115025927146184704,
  "created_at" : "2011-09-17 11:34:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 38, 46 ]
    }, {
      "text" : "MedalofHonor",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/1wTSUBTK",
      "expanded_url" : "http:\/\/youtu.be\/9e75vObBzXA",
      "display_url" : "youtu.be\/9e75vObBzXA"
    } ]
  },
  "geo" : { },
  "id_str" : "114853861629509632",
  "text" : "Fresh West Wing Week: Obama takes his #jobsnow plan to VA, OH & NC, commemorates 9\/11 & presents the #MedalofHonor: http:\/\/t.co\/1wTSUBTK",
  "id" : 114853861629509632,
  "created_at" : "2011-09-17 00:11:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 26, 37 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114832992890925056",
  "text" : "RT @macon44: Video Gamers @whitehouse event are \"surprised & delighted to hear from teachers. \"We were like, 'Aren't we enemies?'\" http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 13, 24 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/hfVuRFnV",
        "expanded_url" : "http:\/\/usat.ly\/qcXOKk",
        "display_url" : "usat.ly\/qcXOKk"
      } ]
    },
    "geo" : { },
    "id_str" : "114807121555632128",
    "text" : "Video Gamers @whitehouse event are \"surprised & delighted to hear from teachers. \"We were like, 'Aren't we enemies?'\" http:\/\/t.co\/hfVuRFnV",
    "id" : 114807121555632128,
    "created_at" : "2011-09-16 21:05:25 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 114832992890925056,
  "created_at" : "2011-09-16 22:48:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 15, 28 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "USPTO",
      "screen_name" : "uspto",
      "indices" : [ 31, 37 ],
      "id_str" : "16057477",
      "id" : 16057477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaInvests",
      "indices" : [ 71, 86 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "114814842984087552",
  "text" : "Happening now: @aneeshchopra & @USPTO Dir. Kappos answering your Qs on #AmericaInvests Act. Ask w\/ #WHChat watch live http:\/\/t.co\/u95y7hhB",
  "id" : 114814842984087552,
  "created_at" : "2011-09-16 21:36:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 69, 82 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "USPTO",
      "screen_name" : "uspto",
      "indices" : [ 85, 91 ],
      "id_str" : "16057477",
      "id" : 16057477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaInvents",
      "indices" : [ 24, 39 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 54, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "114809836520210433",
  "text" : "Now @ 5:30ET: Got Qs on #AmericaInvents Act? Ask with #WHChat & join @aneeshchopra & @USPTO Dir Kappos live: http:\/\/t.co\/QDIpMRKE",
  "id" : 114809836520210433,
  "created_at" : "2011-09-16 21:16:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 30, 37 ]
    }, {
      "text" : "AmericaInvents",
      "indices" : [ 60, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "114798178087346176",
  "text" : "Open for Questions @ 5ET: Use #WHChat to ask your ?s on the #AmericaInvents Act & tune in live: http:\/\/t.co\/hhNoX4fh",
  "id" : 114798178087346176,
  "created_at" : "2011-09-16 20:29:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 11, 15 ],
      "id_str" : "3108351",
      "id" : 3108351
    }, {
      "name" : "U.S. Chamber",
      "screen_name" : "USChamber",
      "indices" : [ 17, 27 ],
      "id_str" : "85606078",
      "id" : 85606078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/xsnzUPkl",
      "expanded_url" : "http:\/\/1.usa.gov\/oGws5x",
      "display_url" : "1.usa.gov\/oGws5x"
    } ]
  },
  "geo" : { },
  "id_str" : "114792461825617920",
  "text" : "In today's @WSJ, @uschamber president & CEO Tom Donahue raised concerns on the American Jobs Act. WH response here: http:\/\/t.co\/xsnzUPkl",
  "id" : 114792461825617920,
  "created_at" : "2011-09-16 20:07:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 73, 86 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "USPTO",
      "screen_name" : "uspto",
      "indices" : [ 89, 95 ],
      "id_str" : "16057477",
      "id" : 16057477
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaInvents",
      "indices" : [ 22, 37 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/6Z6u7BNz",
      "expanded_url" : "http:\/\/1.usa.gov\/qsA6Jn",
      "display_url" : "1.usa.gov\/qsA6Jn"
    } ]
  },
  "geo" : { },
  "id_str" : "114751601541005312",
  "text" : "Obama just signed the #AmericaInvents Act. Got Qs? Ask now: #WHChat Join @aneeshchopra & @USPTO Dir Kappos live @ 5ET: http:\/\/t.co\/6Z6u7BNz",
  "id" : 114751601541005312,
  "created_at" : "2011-09-16 17:24:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 132, 139 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericaInvents",
      "indices" : [ 36, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "114719316485734400",
  "text" : "Happening now: Pres Obama signs the #AmericaInvents Act @ Thomas Jefferson High School in VA - Listen: http:\/\/t.co\/hhNoX4fh Follow: @WHLive",
  "id" : 114719316485734400,
  "created_at" : "2011-09-16 15:16:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 5, 16 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "digitalpromise",
      "indices" : [ 26, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/x0C9Z5l9",
      "expanded_url" : "http:\/\/1.usa.gov\/r86geZ",
      "display_url" : "1.usa.gov\/r86geZ"
    } ]
  },
  "geo" : { },
  "id_str" : "114696411458703360",
  "text" : "WH & @arneduncan announce #digitalpromise initiative to spur learning technologies that transform teaching & learning: http:\/\/t.co\/x0C9Z5l9",
  "id" : 114696411458703360,
  "created_at" : "2011-09-16 13:45:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/114478563943657472\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/yY6O4zIP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AZa1pbtCMAAwwok.jpg",
      "id_str" : "114478563960434688",
      "id" : 114478563960434688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZa1pbtCMAAwwok.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yY6O4zIP"
    } ],
    "hashtags" : [ {
      "text" : "MedalofHonor",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/fwsMLDW0",
      "expanded_url" : "http:\/\/1.usa.gov\/o1Ikqu",
      "display_url" : "1.usa.gov\/o1Ikqu"
    } ]
  },
  "geo" : { },
  "id_str" : "114478563943657472",
  "text" : "\u201CIn Sgt @Dakota_Meyer, we see the best of a generation\" -President Obama awards #MedalofHonor: http:\/\/t.co\/fwsMLDW0 http:\/\/t.co\/yY6O4zIP",
  "id" : 114478563943657472,
  "created_at" : "2011-09-15 23:19:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 59, 67 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/rJquyE4x",
      "expanded_url" : "http:\/\/1.usa.gov\/q793Xq",
      "display_url" : "1.usa.gov\/q793Xq"
    } ]
  },
  "geo" : { },
  "id_str" : "114465287885176832",
  "text" : "What the people want to know about We the People: Q&A with @Macon44 on our new WH petition tool: http:\/\/t.co\/rJquyE4x",
  "id" : 114465287885176832,
  "created_at" : "2011-09-15 22:27:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/Midi3RBo",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/jobsact",
      "display_url" : "whitehouse.gov\/jobsact"
    } ]
  },
  "geo" : { },
  "id_str" : "114441374899781632",
  "text" : "RT @WHLive: Been great answering your Qs, Look forward to coming back. For more on American Jobs Act: http:\/\/t.co\/Midi3RBo #WHchat Bye f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/Midi3RBo",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/jobsact",
        "display_url" : "whitehouse.gov\/jobsact"
      } ]
    },
    "geo" : { },
    "id_str" : "114440614539567104",
    "text" : "Been great answering your Qs, Look forward to coming back. For more on American Jobs Act: http:\/\/t.co\/Midi3RBo #WHchat Bye from Jason Furman",
    "id" : 114440614539567104,
    "created_at" : "2011-09-15 20:49:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 114441374899781632,
  "created_at" : "2011-09-15 20:52:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Peter Korman",
      "screen_name" : "pjkorman",
      "indices" : [ 13, 22 ],
      "id_str" : "150841541",
      "id" : 150841541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/Midi3RBo",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/jobsact",
      "display_url" : "whitehouse.gov\/jobsact"
    } ]
  },
  "geo" : { },
  "id_str" : "114436704693260288",
  "text" : "RT @WHLive: .@pjkorman: $35b for teachers and first responders. $30b for school modernize. Full facts at http:\/\/t.co\/Midi3RBo #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Peter Korman",
        "screen_name" : "pjkorman",
        "indices" : [ 1, 10 ],
        "id_str" : "150841541",
        "id" : 150841541
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 114, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/Midi3RBo",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/jobsact",
        "display_url" : "whitehouse.gov\/jobsact"
      } ]
    },
    "geo" : { },
    "id_str" : "114436257651769344",
    "text" : ".@pjkorman: $35b for teachers and first responders. $30b for school modernize. Full facts at http:\/\/t.co\/Midi3RBo #WHchat",
    "id" : 114436257651769344,
    "created_at" : "2011-09-15 20:31:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 114436704693260288,
  "created_at" : "2011-09-15 20:33:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Korman",
      "screen_name" : "pjkorman",
      "indices" : [ 3, 12 ],
      "id_str" : "150841541",
      "id" : 150841541
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 15, 22 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Lindsey",
      "screen_name" : "xcrunrchic4",
      "indices" : [ 25, 37 ],
      "id_str" : "255032273",
      "id" : 255032273
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114436663278710784",
  "text" : "RT @pjkorman: \u201C@WHLive: .@xcrunrchic4: Fund to save 280,000 teacher jobs. Funds to modernize 35,000 schools. Education a priority. #WHch ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 1, 8 ],
        "id_str" : "369505837",
        "id" : 369505837
      }, {
        "name" : "Lindsey",
        "screen_name" : "xcrunrchic4",
        "indices" : [ 11, 23 ],
        "id_str" : "255032273",
        "id" : 255032273
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 117, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114435378743750656",
    "text" : "\u201C@WHLive: .@xcrunrchic4: Fund to save 280,000 teacher jobs. Funds to modernize 35,000 schools. Education a priority. #WHchat\u201D How many $?",
    "id" : 114435378743750656,
    "created_at" : "2011-09-15 20:28:15 +0000",
    "user" : {
      "name" : "Peter Korman",
      "screen_name" : "pjkorman",
      "protected" : false,
      "id_str" : "150841541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703796170292789249\/F9i42kUI_normal.jpg",
      "id" : 150841541,
      "verified" : false
    }
  },
  "id" : 114436663278710784,
  "created_at" : "2011-09-15 20:33:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Lindsey",
      "screen_name" : "xcrunrchic4",
      "indices" : [ 13, 25 ],
      "id_str" : "255032273",
      "id" : 255032273
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114434674331365378",
  "text" : "RT @WHLive: .@xcrunrchic4: Fund to save 280,000 teacher jobs. Funds to modernize 35,000 schools. Education a priority. #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lindsey",
        "screen_name" : "xcrunrchic4",
        "indices" : [ 1, 13 ],
        "id_str" : "255032273",
        "id" : 255032273
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114433729778298880",
    "text" : ".@xcrunrchic4: Fund to save 280,000 teacher jobs. Funds to modernize 35,000 schools. Education a priority. #WHchat",
    "id" : 114433729778298880,
    "created_at" : "2011-09-15 20:21:41 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 114434674331365378,
  "created_at" : "2011-09-15 20:25:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey",
      "screen_name" : "xcrunrchic4",
      "indices" : [ 3, 15 ],
      "id_str" : "255032273",
      "id" : 255032273
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 17, 24 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114434616550637568",
  "text" : "RT @xcrunrchic4: @WHLive how is the jobs act going to help education? Education doesn't seem to be a priority anymore #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 0, 7 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 101, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114431229868244992",
    "in_reply_to_user_id" : 369505837,
    "text" : "@WHLive how is the jobs act going to help education? Education doesn't seem to be a priority anymore #WHChat",
    "id" : 114431229868244992,
    "created_at" : "2011-09-15 20:11:45 +0000",
    "in_reply_to_screen_name" : "WHLive",
    "in_reply_to_user_id_str" : "369505837",
    "user" : {
      "name" : "Lindsey",
      "screen_name" : "xcrunrchic4",
      "protected" : false,
      "id_str" : "255032273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633019747672702977\/H4anQuLO_normal.jpg",
      "id" : 255032273,
      "verified" : false
    }
  },
  "id" : 114434616550637568,
  "created_at" : "2011-09-15 20:25:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114432016702910464",
  "text" : "RT @WHLive: I got off to such a fast start, forgot to say hi it is Jason Furman from the National Economic Council here to answer your q ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114431039144861696",
    "text" : "I got off to such a fast start, forgot to say hi it is Jason Furman from the National Economic Council here to answer your questions #WHchat",
    "id" : 114431039144861696,
    "created_at" : "2011-09-15 20:11:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 114432016702910464,
  "created_at" : "2011-09-15 20:14:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 110, 117 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114423186183036929",
  "text" : "RT @WHLive: Got Qs on the American Jobs Act? WH economist Jason Furman has As. Join us for Office Hours @ 4ET @WHLive. Ask ?s now: #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 98, 105 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114423039889903616",
    "text" : "Got Qs on the American Jobs Act? WH economist Jason Furman has As. Join us for Office Hours @ 4ET @WHLive. Ask ?s now: #WHChat",
    "id" : 114423039889903616,
    "created_at" : "2011-09-15 19:39:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 114423186183036929,
  "created_at" : "2011-09-15 19:39:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Marines",
      "screen_name" : "USMC",
      "indices" : [ 3, 8 ],
      "id_str" : "10126672",
      "id" : 10126672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114414933990576128",
  "text" : "RT @USMC: \"In Sgt. @Dakota_Meyer we see the best of a generation\" - President Obama #Marines Medal of Honor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Marines",
        "indices" : [ 74, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114412202387189760",
    "text" : "\"In Sgt. @Dakota_Meyer we see the best of a generation\" - President Obama #Marines Medal of Honor",
    "id" : 114412202387189760,
    "created_at" : "2011-09-15 18:56:09 +0000",
    "user" : {
      "name" : "U.S. Marines",
      "screen_name" : "USMC",
      "protected" : false,
      "id_str" : "10126672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1922693175\/profile_normal.jpg",
      "id" : 10126672,
      "verified" : true
    }
  },
  "id" : 114414933990576128,
  "created_at" : "2011-09-15 19:07:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "114414180420943873",
  "text" : "Happening now: President Obama awards @Dakota_Meyer the Medal of Honor. Watch: http:\/\/t.co\/QDIpMRKE",
  "id" : 114414180420943873,
  "created_at" : "2011-09-15 19:04:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 53, 65 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "114402436042600448",
  "text" : "Happening now: Live chat on the American Jobs Act w\/ @JonCarson44 & WH economist Brian Deese: http:\/\/t.co\/hhNoX4fh Ask Qs w\/ #WHChat",
  "id" : 114402436042600448,
  "created_at" : "2011-09-15 18:17:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 55, 67 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114383722920419328",
  "text" : "Happening @ 2ET: Live chat on the American Jobs Act w\/ @JonCarson44 & WH economist Jason Furman. Use #WHChat to ask Qs now.",
  "id" : 114383722920419328,
  "created_at" : "2011-09-15 17:02:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 77, 92 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114380069325127680",
  "text" : "RT @pfeiffer44: The Dept of Energy has a blog post up explaining why today's @washingtonpost article on green jobs is innacurate http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 61, 76 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/uKZ0VWZS",
        "expanded_url" : "http:\/\/1.usa.gov\/p4OGRa",
        "display_url" : "1.usa.gov\/p4OGRa"
      } ]
    },
    "geo" : { },
    "id_str" : "114377279857111040",
    "text" : "The Dept of Energy has a blog post up explaining why today's @washingtonpost article on green jobs is innacurate http:\/\/t.co\/uKZ0VWZS",
    "id" : 114377279857111040,
    "created_at" : "2011-09-15 16:37:23 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 114380069325127680,
  "created_at" : "2011-09-15 16:48:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114367450254028801",
  "text" : "RT @ENERGY: How our loan program's projects will support 60,000 American jobs & save 300 million gallons of gasoline a year.  http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/6w0gSv5Y",
        "expanded_url" : "http:\/\/go.usa.gov\/0La",
        "display_url" : "go.usa.gov\/0La"
      } ]
    },
    "geo" : { },
    "id_str" : "114366110954045440",
    "text" : "How our loan program's projects will support 60,000 American jobs & save 300 million gallons of gasoline a year.  http:\/\/t.co\/6w0gSv5Y",
    "id" : 114366110954045440,
    "created_at" : "2011-09-15 15:53:00 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 114367450254028801,
  "created_at" : "2011-09-15 15:58:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericanJobsAct",
      "indices" : [ 13, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/N5YgN5fG",
      "expanded_url" : "http:\/\/youtu.be\/WZdKxuIx0sI",
      "display_url" : "youtu.be\/WZdKxuIx0sI"
    } ]
  },
  "geo" : { },
  "id_str" : "114158843675676673",
  "text" : "Obama on the #AmericanJobsAct: I need you to lift your voice. Make it heard. Call, email, tweet, fax, Facebook: http:\/\/t.co\/N5YgN5fG",
  "id" : 114158843675676673,
  "created_at" : "2011-09-15 02:09:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/Hxe6Ikr7",
      "expanded_url" : "http:\/\/bit.ly\/r23Ack",
      "display_url" : "bit.ly\/r23Ack"
    } ]
  },
  "geo" : { },
  "id_str" : "114120242426425344",
  "text" : "RT @petesouza: Photo of the President having a beer with Dakota Meyer, who will be awarded the Medal of Honor tomorrow: http:\/\/t.co\/Hxe6Ikr7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/Hxe6Ikr7",
        "expanded_url" : "http:\/\/bit.ly\/r23Ack",
        "display_url" : "bit.ly\/r23Ack"
      } ]
    },
    "geo" : { },
    "id_str" : "114109158122471425",
    "text" : "Photo of the President having a beer with Dakota Meyer, who will be awarded the Medal of Honor tomorrow: http:\/\/t.co\/Hxe6Ikr7",
    "id" : 114109158122471425,
    "created_at" : "2011-09-14 22:51:58 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 114120242426425344,
  "created_at" : "2011-09-14 23:36:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 110, 117 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/114112851299401728\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/lJE4srgT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AZVpCJ5CAAAdr3G.jpg",
      "id_str" : "114112851303596032",
      "id" : 114112851303596032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZVpCJ5CAAAdr3G.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lJE4srgT"
    } ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 74, 82 ]
    }, {
      "text" : "whchat",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114112851299401728",
  "text" : "Stephanie Cutter, Assistant to the Pres, is here answering your Qs on the #JobsNow plan. Ask: #whchat Follow: @WHLive http:\/\/t.co\/lJE4srgT",
  "id" : 114112851299401728,
  "created_at" : "2011-09-14 23:06:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "scott glennon",
      "screen_name" : "scott4567",
      "indices" : [ 13, 23 ],
      "id_str" : "24036660",
      "id" : 24036660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114110346410725377",
  "text" : "RT @WHLive: .@scott4567 Lots for vets.Tax credit for biz to hire unemployed vets & extra benefit for hiring wounded vets. http:\/\/t.co\/zB ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "scott glennon",
        "screen_name" : "scott4567",
        "indices" : [ 1, 11 ],
        "id_str" : "24036660",
        "id" : 24036660
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/zBggJh8t",
        "expanded_url" : "http:\/\/1.usa.gov\/nzFcq3",
        "display_url" : "1.usa.gov\/nzFcq3"
      } ]
    },
    "geo" : { },
    "id_str" : "114109634943516672",
    "text" : ".@scott4567 Lots for vets.Tax credit for biz to hire unemployed vets & extra benefit for hiring wounded vets. http:\/\/t.co\/zBggJh8t #whchat",
    "id" : 114109634943516672,
    "created_at" : "2011-09-14 22:53:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 114110346410725377,
  "created_at" : "2011-09-14 22:56:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "scott glennon",
      "screen_name" : "scott4567",
      "indices" : [ 3, 13 ],
      "id_str" : "24036660",
      "id" : 24036660
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 15, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114110327553146880",
  "text" : "RT @scott4567: #whchat I am Veteran and a 99'er. Is there anything in this plan for me? I heard talk of programs for Veterans, and I hop ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114106851980873728",
    "text" : "#whchat I am Veteran and a 99'er. Is there anything in this plan for me? I heard talk of programs for Veterans, and I hope for Tier V.",
    "id" : 114106851980873728,
    "created_at" : "2011-09-14 22:42:48 +0000",
    "user" : {
      "name" : "scott glennon",
      "screen_name" : "scott4567",
      "protected" : false,
      "id_str" : "24036660",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789575820947910656\/uqf9dopv_normal.jpg",
      "id" : 24036660,
      "verified" : false
    }
  },
  "id" : 114110327553146880,
  "created_at" : "2011-09-14 22:56:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114108609532669952",
  "text" : "RT @WHLive: Hi.  It's Stephanie and I'm here ready to take your questions on the President's American Jobs Act.  Ask with #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "114106553522601984",
    "text" : "Hi.  It's Stephanie and I'm here ready to take your questions on the President's American Jobs Act.  Ask with #whchat",
    "id" : 114106553522601984,
    "created_at" : "2011-09-14 22:41:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 114108609532669952,
  "created_at" : "2011-09-14 22:49:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 128, 135 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114102232106016768",
  "text" : "Office Hrs @ 6:30ET: Stephanie Cutter, Obama's Deputy Sr Advisor, answers Qs on the American Jobs Act. Ask now: #WHChat Follow: @WHLive",
  "id" : 114102232106016768,
  "created_at" : "2011-09-14 22:24:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/pghgzrcq",
      "expanded_url" : "http:\/\/www.wh.gov\/jobsact",
      "display_url" : "wh.gov\/jobsact"
    } ]
  },
  "geo" : { },
  "id_str" : "114084174725513216",
  "text" : "RT @WHLive: Have Qs on the American Jobs Act? Read it: http:\/\/t.co\/pghgzrcq Ask now: #WHChat Join us: Office Hours @ 6:30ET right here @ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 123, 130 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 73, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/pghgzrcq",
        "expanded_url" : "http:\/\/www.wh.gov\/jobsact",
        "display_url" : "wh.gov\/jobsact"
      } ]
    },
    "geo" : { },
    "id_str" : "114083621719117824",
    "text" : "Have Qs on the American Jobs Act? Read it: http:\/\/t.co\/pghgzrcq Ask now: #WHChat Join us: Office Hours @ 6:30ET right here @WHLive",
    "id" : 114083621719117824,
    "created_at" : "2011-09-14 21:10:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 114084174725513216,
  "created_at" : "2011-09-14 21:12:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 71, 78 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "114067958787092480",
  "text" : "Happening now: Open for Questions: Youth & the American Jobs Act. Ask: #WHChat & watch live: http:\/\/t.co\/QDIpMRKE #JobsNow",
  "id" : 114067958787092480,
  "created_at" : "2011-09-14 20:08:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Raleigh",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 39 ],
      "url" : "http:\/\/t.co\/YsbLKUm",
      "expanded_url" : "http:\/\/www.whitehouse.gov",
      "display_url" : "whitehouse.gov"
    }, {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/QQwhiW9",
      "expanded_url" : "http:\/\/www.wh.gov\/jobsact",
      "display_url" : "wh.gov\/jobsact"
    } ]
  },
  "geo" : { },
  "id_str" : "114052501673738241",
  "text" : "\"You can read it on http:\/\/t.co\/YsbLKUm\" -President Obama on the American Jobs Act in #Raleigh today. Here it is: http:\/\/t.co\/QQwhiW9",
  "id" : 114052501673738241,
  "created_at" : "2011-09-14 19:06:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/47y9gSTN",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/09\/14\/american-jobs-act-and-your-community",
      "display_url" : "whitehouse.gov\/blog\/2011\/09\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "114046258049585152",
  "text" : "RT @JonCarson44: Find out what the American Jobs Act will do for your community: http:\/\/t.co\/47y9gSTN  #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 86, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/47y9gSTN",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/09\/14\/american-jobs-act-and-your-community",
        "display_url" : "whitehouse.gov\/blog\/2011\/09\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "114044552301649920",
    "text" : "Find out what the American Jobs Act will do for your community: http:\/\/t.co\/47y9gSTN  #JobsNow",
    "id" : 114044552301649920,
    "created_at" : "2011-09-14 18:35:14 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 114046258049585152,
  "created_at" : "2011-09-14 18:42:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/nRt6vER",
      "expanded_url" : "http:\/\/1.usa.gov\/oPsHlO",
      "display_url" : "1.usa.gov\/oPsHlO"
    } ]
  },
  "geo" : { },
  "id_str" : "114030416087883776",
  "text" : "Open for Questions @ 4ET: Join us for a live video chat on youth & the American Jobs Act. Use #WHChat to ask ?s now: http:\/\/t.co\/nRt6vER",
  "id" : 114030416087883776,
  "created_at" : "2011-09-14 17:39:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/IGc2afS",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "114017589709123584",
  "text" : "Just started: President Obama speaks on the American Jobs Act\n@ North Carolina State University. Watch: http:\/\/t.co\/IGc2afS #JobsNow",
  "id" : 114017589709123584,
  "created_at" : "2011-09-14 16:48:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/113979554669928448\/photo\/1",
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/ZUJlIyT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AZTvzRQCIAAY6ND.jpg",
      "id_str" : "113979554674122752",
      "id" : 113979554674122752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZTvzRQCIAAY6ND.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZUJlIyT"
    } ],
    "hashtags" : [ {
      "text" : "Columbus",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "Ohio",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 57 ],
      "url" : "http:\/\/t.co\/h9FD39J",
      "expanded_url" : "http:\/\/1.usa.gov\/oeKpV5",
      "display_url" : "1.usa.gov\/oeKpV5"
    } ]
  },
  "geo" : { },
  "id_str" : "113979554669928448",
  "text" : "\"Every child deserves a great school\" http:\/\/t.co\/h9FD39J President Obama visits a classroom in #Columbus #Ohio: http:\/\/t.co\/ZUJlIyT",
  "id" : 113979554669928448,
  "created_at" : "2011-09-14 14:16:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 45, 53 ],
      "id_str" : "17814938",
      "id" : 17814938
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 83, 90 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 100, 107 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http:\/\/t.co\/zmkjFck",
      "expanded_url" : "http:\/\/sfy.co\/GwV",
      "display_url" : "sfy.co\/GwV"
    } ]
  },
  "geo" : { },
  "id_str" : "113751614556344321",
  "text" : "Missed Office Hrs w\/ David Plouffe? Full Q&A @Storify: http:\/\/t.co\/zmkjFck  Follow @WHLive for more #WHChat on Obama's #JobsNow plan.",
  "id" : 113751614556344321,
  "created_at" : "2011-09-13 23:11:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 74, 81 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/113737128793477120\/photo\/1",
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/Pfbu204",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AZQTUOfCEAIn-Ob.jpg",
      "id_str" : "113737128797671426",
      "id" : 113737128797671426,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZQTUOfCEAIn-Ob.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Pfbu204"
    } ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113737128793477120",
  "text" : "Happening now: Sr Advisor David Plouffe answers your questions on Twitter @WHLive -- Ask now w\/ #WHChat http:\/\/t.co\/Pfbu204",
  "id" : 113737128793477120,
  "created_at" : "2011-09-13 22:13:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "John Cody Smith",
      "screen_name" : "johncodysmith",
      "indices" : [ 13, 27 ],
      "id_str" : "262835943",
      "id" : 262835943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113735487910445056",
  "text" : "RT @WHLive: .@johncodysmith. it all should. in this econ, who can be against mid class tax cuts, hiring vets, long term unemp &teachers? ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Cody Smith",
        "screen_name" : "johncodysmith",
        "indices" : [ 1, 15 ],
        "id_str" : "262835943",
        "id" : 262835943
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113735130056622080",
    "text" : ".@johncodysmith. it all should. in this econ, who can be against mid class tax cuts, hiring vets, long term unemp &teachers? we need action.",
    "id" : 113735130056622080,
    "created_at" : "2011-09-13 22:05:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 113735487910445056,
  "created_at" : "2011-09-13 22:07:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cody Smith",
      "screen_name" : "johncodysmith",
      "indices" : [ 3, 17 ],
      "id_str" : "262835943",
      "id" : 262835943
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113735165704015873",
  "text" : "RT @johncodysmith: #WHchat What pieces of POTUS job plan will satisfy D's and R's respectively?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113733159845249024",
    "text" : "#WHchat What pieces of POTUS job plan will satisfy D's and R's respectively?",
    "id" : 113733159845249024,
    "created_at" : "2011-09-13 21:57:53 +0000",
    "user" : {
      "name" : "John Cody Smith",
      "screen_name" : "johncodysmith",
      "protected" : false,
      "id_str" : "262835943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/416437912616452096\/A3q5_q3t_normal.png",
      "id" : 262835943,
      "verified" : false
    }
  },
  "id" : 113735165704015873,
  "created_at" : "2011-09-13 22:05:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Sue Hornik",
      "screen_name" : "Hornik10",
      "indices" : [ 13, 22 ],
      "id_str" : "108334613",
      "id" : 108334613
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113733512997249024",
  "text" : "RT @WHLive: .@Hornik10  Tax cuts for small biz that hire new workers, vets hiring tax cut  for all & apprenticeship & youth summer job p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sue Hornik",
        "screen_name" : "Hornik10",
        "indices" : [ 1, 10 ],
        "id_str" : "108334613",
        "id" : 108334613
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113733073165762560",
    "text" : ".@Hornik10  Tax cuts for small biz that hire new workers, vets hiring tax cut  for all & apprenticeship & youth summer job programs #whchat",
    "id" : 113733073165762560,
    "created_at" : "2011-09-13 21:57:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 113733512997249024,
  "created_at" : "2011-09-13 21:59:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Hornik",
      "screen_name" : "Hornik10",
      "indices" : [ 3, 12 ],
      "id_str" : "108334613",
      "id" : 108334613
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113733494722658304",
  "text" : "RT @Hornik10: #WHChat How will AJA help unemployed young people?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113731402004041728",
    "text" : "#WHChat How will AJA help unemployed young people?",
    "id" : 113731402004041728,
    "created_at" : "2011-09-13 21:50:53 +0000",
    "user" : {
      "name" : "Sue Hornik",
      "screen_name" : "Hornik10",
      "protected" : false,
      "id_str" : "108334613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769495441\/SueHawaii.aspx_normal.jpeg",
      "id" : 108334613,
      "verified" : false
    }
  },
  "id" : 113733494722658304,
  "created_at" : "2011-09-13 21:59:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113730499729571840",
  "text" : "RT @WHLive: Hey everybody. David Plouffe here to take your questions. Use #WHChat. let's get started.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 62, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113729942314950656",
    "text" : "Hey everybody. David Plouffe here to take your questions. Use #WHChat. let's get started.",
    "id" : 113729942314950656,
    "created_at" : "2011-09-13 21:45:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 113730499729571840,
  "created_at" : "2011-09-13 21:47:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 85, 92 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 104, 115 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113720626937741313",
  "text" : "Join us @ 5:30ET for Office Hrs w\/ Obama's Sr Advisor David Plouffe. Follow full Q&A @WHLive Highlights @WhiteHouse Ask Qs now: #WHChat",
  "id" : 113720626937741313,
  "created_at" : "2011-09-13 21:08:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113719518907478017",
  "text" : "RT @PressSec: As part of the American Jobs Act, POTUS is calling for a $25 billion investment to modernize & rebuild at least 35,000 pub ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113636976091078656",
    "text" : "As part of the American Jobs Act, POTUS is calling for a $25 billion investment to modernize & rebuild at least 35,000 public schools.",
    "id" : 113636976091078656,
    "created_at" : "2011-09-13 15:35:41 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 113719518907478017,
  "created_at" : "2011-09-13 21:03:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericanJobsAct",
      "indices" : [ 69, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113710437035540480",
  "text" : "RT @arneduncan: Just finished a visit to Columbus, OH w\/ Pres Obama. #AmericanJobsAct wld provide Columbus District w\/ $111mil to help f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AmericanJobsAct",
        "indices" : [ 53, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113700930402271233",
    "text" : "Just finished a visit to Columbus, OH w\/ Pres Obama. #AmericanJobsAct wld provide Columbus District w\/ $111mil to help fund teacher jobs.",
    "id" : 113700930402271233,
    "created_at" : "2011-09-13 19:49:48 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 113710437035540480,
  "created_at" : "2011-09-13 20:27:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113687080932081664",
  "text" : "RT @WHLive: Obama: This isn\u2019t about giving me a win. This isn\u2019t about giving Rs or Ds a win. This is about giving the American people a  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 129, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113685335778664448",
    "text" : "Obama: This isn\u2019t about giving me a win. This isn\u2019t about giving Rs or Ds a win. This is about giving the American people a win. #JobsNow",
    "id" : 113685335778664448,
    "created_at" : "2011-09-13 18:47:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 113687080932081664,
  "created_at" : "2011-09-13 18:54:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Coleman",
      "screen_name" : "MichaelBColeman",
      "indices" : [ 3, 19 ],
      "id_str" : "151943134",
      "id" : 151943134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Columbus",
      "indices" : [ 39, 48 ]
    }, {
      "text" : "AmericanJobsAct",
      "indices" : [ 62, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113680291947753472",
  "text" : "RT @MichaelBColeman: POTUS speaks at a #Columbus HS about how #AmericanJobsAct will get teachers back in classrooms & improve our school ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Columbus",
        "indices" : [ 18, 27 ]
      }, {
        "text" : "AmericanJobsAct",
        "indices" : [ 41, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 136 ],
        "url" : "http:\/\/t.co\/IPncNG5",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "113679289219678208",
    "text" : "POTUS speaks at a #Columbus HS about how #AmericanJobsAct will get teachers back in classrooms & improve our schools http:\/\/t.co\/IPncNG5.",
    "id" : 113679289219678208,
    "created_at" : "2011-09-13 18:23:49 +0000",
    "user" : {
      "name" : "Mike Coleman",
      "screen_name" : "MichaelBColeman",
      "protected" : false,
      "id_str" : "151943134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618036641702260736\/DkC3Y_n4_normal.jpg",
      "id" : 151943134,
      "verified" : true
    }
  },
  "id" : 113680291947753472,
  "created_at" : "2011-09-13 18:27:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Columbus",
      "indices" : [ 85, 94 ]
    }, {
      "text" : "Ohio",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/9d2iD5e",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "113676228237606912",
  "text" : "RT @WHLive: Happening @ 2:15ET: President Obama speaks on the American Jobs Act\nfrom #Columbus #Ohio. Watch live: http:\/\/t.co\/9d2iD5e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Columbus",
        "indices" : [ 73, 82 ]
      }, {
        "text" : "Ohio",
        "indices" : [ 83, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 121 ],
        "url" : "http:\/\/t.co\/9d2iD5e",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "113676116857864192",
    "text" : "Happening @ 2:15ET: President Obama speaks on the American Jobs Act\nfrom #Columbus #Ohio. Watch live: http:\/\/t.co\/9d2iD5e",
    "id" : 113676116857864192,
    "created_at" : "2011-09-13 18:11:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 113676228237606912,
  "created_at" : "2011-09-13 18:11:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http:\/\/t.co\/L55iZci",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/1is2many",
      "display_url" : "whitehouse.gov\/1is2many"
    } ]
  },
  "geo" : { },
  "id_str" : "113644786161950720",
  "text" : "RT @VP: BREAKING-Visit http:\/\/t.co\/L55iZci for video message from VP on an important issue facing teens & young adults across the U.S. # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1is2many",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 15, 34 ],
        "url" : "http:\/\/t.co\/L55iZci",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/1is2many",
        "display_url" : "whitehouse.gov\/1is2many"
      } ]
    },
    "geo" : { },
    "id_str" : "113623456096075776",
    "text" : "BREAKING-Visit http:\/\/t.co\/L55iZci for video message from VP on an important issue facing teens & young adults across the U.S. #1is2many",
    "id" : 113623456096075776,
    "created_at" : "2011-09-13 14:41:57 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 113644786161950720,
  "created_at" : "2011-09-13 16:06:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 26, 34 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113628487792865280",
  "text" : "Got Qs on the President's #JobsNow plan? Obama's senior advisor David Plouffe will be here for Office Hrs @ 5:30ET today. Ask now: #WHChat",
  "id" : 113628487792865280,
  "created_at" : "2011-09-13 15:01:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/113620405771698176\/photo\/1",
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/zPIQRQZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AZOpKDXCAAAoAnN.jpg",
      "id_str" : "113620405780086784",
      "id" : 113620405780086784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZOpKDXCAAAoAnN.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/zPIQRQZ"
    } ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http:\/\/t.co\/ET9oPlY",
      "expanded_url" : "http:\/\/1.usa.gov\/pStuS6",
      "display_url" : "1.usa.gov\/pStuS6"
    } ]
  },
  "geo" : { },
  "id_str" : "113620405771698176",
  "text" : "The American Jobs Act: See President Obama's plan to create #jobsnow: http:\/\/t.co\/ET9oPlY Obama sends Act to Congress: http:\/\/t.co\/zPIQRQZ",
  "id" : 113620405771698176,
  "created_at" : "2011-09-13 14:29:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113612328024539136",
  "text" : "RT @JonCarson44: Find out how the American Jobs Act will create jobs for young people - join our webchat Wednesday at 4pm EST - http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 130 ],
        "url" : "http:\/\/t.co\/kjN36pe",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/09\/12\/open-questions-live-chat-american-jobs-act",
        "display_url" : "whitehouse.gov\/blog\/2011\/09\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "113607383518937088",
    "text" : "Find out how the American Jobs Act will create jobs for young people - join our webchat Wednesday at 4pm EST - http:\/\/t.co\/kjN36pe #JobsNow",
    "id" : 113607383518937088,
    "created_at" : "2011-09-13 13:38:05 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 113612328024539136,
  "created_at" : "2011-09-13 13:57:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113394564529799168",
  "text" : "RT @PressSec: The American Jobs Act has been sent to Congress. Congress should pass it now. As POTUS said, \"No games. No politics. No de ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113381397112160256",
    "text" : "The American Jobs Act has been sent to Congress. Congress should pass it now. As POTUS said, \"No games. No politics. No delays.\"",
    "id" : 113381397112160256,
    "created_at" : "2011-09-12 22:40:06 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 113394564529799168,
  "created_at" : "2011-09-12 23:32:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/IGc2afS",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "113354816754941952",
  "text" : "President Obama just surprised the Open for Questions event! Watch live now: http:\/\/t.co\/IGc2afS\u00A0#JobsNow",
  "id" : 113354816754941952,
  "created_at" : "2011-09-12 20:54:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 79, 87 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 120 ],
      "url" : "http:\/\/t.co\/Wql9hJp",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "113341560413896704",
  "text" : "Happening now: Administration officials answer YOUR questions on the economy & #JobsNow. Watch live: http:\/\/t.co\/Wql9hJp Ask Qs: #WHChat",
  "id" : 113341560413896704,
  "created_at" : "2011-09-12 20:01:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amadeu Souza",
      "screen_name" : "newsoneofficial",
      "indices" : [ 27, 43 ],
      "id_str" : "4625034513",
      "id" : 4625034513
    }, {
      "name" : "Hello Beautiful",
      "screen_name" : "HelloBeautiful",
      "indices" : [ 44, 59 ],
      "id_str" : "19026288",
      "id" : 19026288
    }, {
      "name" : "blackplanet",
      "screen_name" : "blackplanet",
      "indices" : [ 60, 72 ],
      "id_str" : "18216025",
      "id" : 18216025
    }, {
      "name" : "TUD",
      "screen_name" : "TheUrbanDaily",
      "indices" : [ 73, 87 ],
      "id_str" : "18691124",
      "id" : 18691124
    }, {
      "name" : "theGrio.com",
      "screen_name" : "theGrio",
      "indices" : [ 88, 96 ],
      "id_str" : "38228095",
      "id" : 38228095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 103, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/Wql9hJp",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "113335934262587392",
  "text" : "Live @ 4ET: Open for Qs w\/ @NewsOneOfficial @HelloBeautiful @blackplanet @Theurbandaily @theGrio. Ask: #WHChat Watch: http:\/\/t.co\/Wql9hJp",
  "id" : 113335934262587392,
  "created_at" : "2011-09-12 19:39:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "theGrio.com",
      "screen_name" : "theGrio",
      "indices" : [ 3, 11 ],
      "id_str" : "38228095",
      "id" : 38228095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/NTJhKRU",
      "expanded_url" : "http:\/\/on.thegrio.com\/rgTVXb",
      "display_url" : "on.thegrio.com\/rgTVXb"
    } ]
  },
  "geo" : { },
  "id_str" : "113314765971005440",
  "text" : "RT @theGrio: Ask questions to the White House! Live @ 4pm watch WH officials answer them. http:\/\/ow.ly\/6s8u6 #WHChat http:\/\/t.co\/NTJhKRU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 96, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 123 ],
        "url" : "http:\/\/t.co\/NTJhKRU",
        "expanded_url" : "http:\/\/on.thegrio.com\/rgTVXb",
        "display_url" : "on.thegrio.com\/rgTVXb"
      } ]
    },
    "geo" : { },
    "id_str" : "113302164092362752",
    "text" : "Ask questions to the White House! Live @ 4pm watch WH officials answer them. http:\/\/ow.ly\/6s8u6 #WHChat http:\/\/t.co\/NTJhKRU",
    "id" : 113302164092362752,
    "created_at" : "2011-09-12 17:25:15 +0000",
    "user" : {
      "name" : "theGrio.com",
      "screen_name" : "theGrio",
      "protected" : false,
      "id_str" : "38228095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2627095049\/ydblgtyalyq0zsexwp6t_normal.jpeg",
      "id" : 38228095,
      "verified" : true
    }
  },
  "id" : 113314765971005440,
  "created_at" : "2011-09-12 18:15:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ONC",
      "indices" : [ 27, 31 ]
    }, {
      "text" : "HealthIT",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113313103269208064",
  "text" : "RT @HHSGov: Happening now: #ONC's Consumer eHealth Summit to educate consumers & health providers about value of #HealthIT. Watch live:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ONC",
        "indices" : [ 15, 19 ]
      }, {
        "text" : "HealthIT",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "113307991889027072",
    "text" : "Happening now: #ONC's Consumer eHealth Summit to educate consumers & health providers about value of #HealthIT. Watch live: www.hhs.gov\/live",
    "id" : 113307991889027072,
    "created_at" : "2011-09-12 17:48:25 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 113313103269208064,
  "created_at" : "2011-09-12 18:08:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/QUKf18H",
      "expanded_url" : "http:\/\/wh.gov\/Y6s",
      "display_url" : "wh.gov\/Y6s"
    } ]
  },
  "geo" : { },
  "id_str" : "113295763743842305",
  "text" : "RT @jesseclee44: Impact of the American Jobs Act, state by state: http:\/\/t.co\/QUKf18H #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 69, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 68 ],
        "url" : "http:\/\/t.co\/QUKf18H",
        "expanded_url" : "http:\/\/wh.gov\/Y6s",
        "display_url" : "wh.gov\/Y6s"
      } ]
    },
    "geo" : { },
    "id_str" : "113293147391537152",
    "text" : "Impact of the American Jobs Act, state by state: http:\/\/t.co\/QUKf18H #JobsNow",
    "id" : 113293147391537152,
    "created_at" : "2011-09-12 16:49:25 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 113295763743842305,
  "created_at" : "2011-09-12 16:59:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amadeu Souza",
      "screen_name" : "newsoneofficial",
      "indices" : [ 1, 17 ],
      "id_str" : "4625034513",
      "id" : 4625034513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/C6fO9p9",
      "expanded_url" : "http:\/\/1.usa.gov\/q72ulk",
      "display_url" : "1.usa.gov\/q72ulk"
    } ]
  },
  "geo" : { },
  "id_str" : "113292014228996096",
  "text" : ".@NewsOneOfficial, HelloBeautiful, Black Planet, UrbanDaily & Grio bring your Qs to the WH. Join live today @ 4ET: http:\/\/t.co\/C6fO9p9",
  "id" : 113292014228996096,
  "created_at" : "2011-09-12 16:44:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 116, 121 ]
    }, {
      "text" : "p2",
      "indices" : [ 122, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/kysgqqS",
      "expanded_url" : "http:\/\/fxn.ws\/qAzHHt",
      "display_url" : "fxn.ws\/qAzHHt"
    } ]
  },
  "geo" : { },
  "id_str" : "113268450431991808",
  "text" : "RT @jesseclee44: Fox News: \u201CMost of Obama\u2019s Jobs Proposals Have Drawn GOP Support in the Past\u201D http:\/\/t.co\/kysgqqS  #tcot #p2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 99, 104 ]
      }, {
        "text" : "p2",
        "indices" : [ 105, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 97 ],
        "url" : "http:\/\/t.co\/kysgqqS",
        "expanded_url" : "http:\/\/fxn.ws\/qAzHHt",
        "display_url" : "fxn.ws\/qAzHHt"
      } ]
    },
    "geo" : { },
    "id_str" : "113267163745366016",
    "text" : "Fox News: \u201CMost of Obama\u2019s Jobs Proposals Have Drawn GOP Support in the Past\u201D http:\/\/t.co\/kysgqqS  #tcot #p2",
    "id" : 113267163745366016,
    "created_at" : "2011-09-12 15:06:10 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 113268450431991808,
  "created_at" : "2011-09-12 15:11:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113259403884503040",
  "text" : "RT @PressSec: In a few mins, POTUS goes to Rose Garden to announce he's sending Congress the American Jobs Act. Watch it here: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 132 ],
        "url" : "http:\/\/t.co\/Zn3e9GC",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "113259264679751681",
    "text" : "In a few mins, POTUS goes to Rose Garden to announce he's sending Congress the American Jobs Act. Watch it here: http:\/\/t.co\/Zn3e9GC.",
    "id" : 113259264679751681,
    "created_at" : "2011-09-12 14:34:47 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 113259403884503040,
  "created_at" : "2011-09-12 14:35:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/Wql9hJp",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "113256386464456704",
  "text" : "Happening @ 10:40ET: President Obama speaks on the American Jobs Act from the Rose Garden. Watch live: http:\/\/t.co\/Wql9hJp #JobsNow",
  "id" : 113256386464456704,
  "created_at" : "2011-09-12 14:23:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/VTHEuyf",
      "expanded_url" : "http:\/\/1.usa.gov\/pfMQE2",
      "display_url" : "1.usa.gov\/pfMQE2"
    } ]
  },
  "geo" : { },
  "id_str" : "113245832958058497",
  "text" : "RT @petesouza: Photos of the Pres and First Lady, VP and Dr Biden, from 10th anniversary of 9\/11: http:\/\/t.co\/VTHEuyf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 102 ],
        "url" : "http:\/\/t.co\/VTHEuyf",
        "expanded_url" : "http:\/\/1.usa.gov\/pfMQE2",
        "display_url" : "1.usa.gov\/pfMQE2"
      } ]
    },
    "geo" : { },
    "id_str" : "113209744113668096",
    "text" : "Photos of the Pres and First Lady, VP and Dr Biden, from 10th anniversary of 9\/11: http:\/\/t.co\/VTHEuyf",
    "id" : 113209744113668096,
    "created_at" : "2011-09-12 11:18:00 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 113245832958058497,
  "created_at" : "2011-09-12 13:41:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sept11",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/aVwIcX8",
      "expanded_url" : "http:\/\/youtu.be\/eS8i-vH3uGg",
      "display_url" : "youtu.be\/eS8i-vH3uGg"
    } ]
  },
  "geo" : { },
  "id_str" : "113087050483384320",
  "text" : "\"Your loved ones live on in you & in the life of our nation, which will never forget them\" -Obama to #Sept11 families: http:\/\/t.co\/aVwIcX8",
  "id" : 113087050483384320,
  "created_at" : "2011-09-12 03:10:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sept11",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 109 ],
      "url" : "http:\/\/t.co\/9Y66KQ1",
      "expanded_url" : "http:\/\/goo.gl\/fb\/4o2JS",
      "display_url" : "goo.gl\/fb\/4o2JS"
    } ]
  },
  "geo" : { },
  "id_str" : "112980459398512640",
  "text" : "President Obama and First Lady Join Services to Commemorate Tenth Anniversary of #Sept11: http:\/\/t.co\/9Y66KQ1",
  "id" : 112980459398512640,
  "created_at" : "2011-09-11 20:06:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHSJournal",
      "screen_name" : "DHSJournal",
      "indices" : [ 3, 14 ],
      "id_str" : "376234273",
      "id" : 376234273
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "911remembered",
      "indices" : [ 55, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/v8tiFKV",
      "expanded_url" : "http:\/\/www.dhs.gov\/files\/9-11-share-your-story.shtm",
      "display_url" : "dhs.gov\/files\/9-11-sha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "112979195600175104",
  "text" : "RT @DHSJournal: Share your September 11 memories using #911remembered and see what others are saying on http:\/\/t.co\/v8tiFKV .",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "911remembered",
        "indices" : [ 39, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 107 ],
        "url" : "http:\/\/t.co\/v8tiFKV",
        "expanded_url" : "http:\/\/www.dhs.gov\/files\/9-11-share-your-story.shtm",
        "display_url" : "dhs.gov\/files\/9-11-sha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "112969641332195328",
    "text" : "Share your September 11 memories using #911remembered and see what others are saying on http:\/\/t.co\/v8tiFKV .",
    "id" : 112969641332195328,
    "created_at" : "2011-09-11 19:23:56 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 112979195600175104,
  "created_at" : "2011-09-11 20:01:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/112958226483519488\/photo\/1",
      "indices" : [ 112, 131 ],
      "url" : "http:\/\/t.co\/EIBgQVc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AZFO6JSCIAA_TVs.jpg",
      "id_str" : "112958226491908096",
      "id" : 112958226491908096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZFO6JSCIAA_TVs.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EIBgQVc"
    } ],
    "hashtags" : [ {
      "text" : "Sept11",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112958226483519488",
  "text" : "The President & First Lady commemorate #Sept11 in NYC, PA & DC today. Visited Section 60 @ Arlington yesterday: http:\/\/t.co\/EIBgQVc",
  "id" : 112958226483519488,
  "created_at" : "2011-09-11 18:38:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112920572240994305",
  "text" : "RT @DeptVetAffairs: On this 10th anniversary of 9\/11,we remember those lost that day\u2014and all who have served since.More from Sec. Shinse ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 139 ],
        "url" : "http:\/\/t.co\/UQ6AyRH",
        "expanded_url" : "http:\/\/www.va.gov\/opa\/speeches\/2011\/09_09_2011.asp",
        "display_url" : "va.gov\/opa\/speeches\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "112881035674533888",
    "text" : "On this 10th anniversary of 9\/11,we remember those lost that day\u2014and all who have served since.More from Sec. Shinseki: http:\/\/t.co\/UQ6AyRH",
    "id" : 112881035674533888,
    "created_at" : "2011-09-11 13:31:50 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 112920572240994305,
  "created_at" : "2011-09-11 16:08:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/112897640219410432\/photo\/1",
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/dccz35b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AZEXzj2CAAAuyhE.jpg",
      "id_str" : "112897640223604736",
      "id" : 112897640223604736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZEXzj2CAAAuyhE.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dccz35b"
    } ],
    "hashtags" : [ {
      "text" : "911day",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112897640219410432",
  "text" : "Photo: President Obama & family prepare food for those in need @ DC Central Kitchen. How are you serving on #911day? http:\/\/t.co\/dccz35b",
  "id" : 112897640219410432,
  "created_at" : "2011-09-11 14:37:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "911day",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112895292629712896",
  "text" : "Even the smallest act of service is a way to honor those we lost & reclaim that spirit of unity that followed 9\/11. #911day",
  "id" : 112895292629712896,
  "created_at" : "2011-09-11 14:28:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/112615329154342912\/photo\/1",
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/tHyoWXf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AZAXC5MCIAAvd0a.jpg",
      "id_str" : "112615329162731520",
      "id" : 112615329162731520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZAXC5MCIAAvd0a.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1529,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tHyoWXf"
    } ],
    "hashtags" : [ {
      "text" : "Flt93",
      "indices" : [ 52, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112651153786933248",
  "text" : "RT @VP: VP, Pres Bush, Laura Bush greet families of #Flt93 passengers & crew following memorial dedication PHOTO http:\/\/t.co\/tHyoWXf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/112615329154342912\/photo\/1",
        "indices" : [ 105, 124 ],
        "url" : "http:\/\/t.co\/tHyoWXf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AZAXC5MCIAAvd0a.jpg",
        "id_str" : "112615329162731520",
        "id" : 112615329162731520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AZAXC5MCIAAvd0a.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1529,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tHyoWXf"
      } ],
      "hashtags" : [ {
        "text" : "Flt93",
        "indices" : [ 44, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112615329154342912",
    "text" : "VP, Pres Bush, Laura Bush greet families of #Flt93 passengers & crew following memorial dedication PHOTO http:\/\/t.co\/tHyoWXf",
    "id" : 112615329154342912,
    "created_at" : "2011-09-10 19:56:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 112651153786933248,
  "created_at" : "2011-09-10 22:18:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/FSacfpV",
      "expanded_url" : "http:\/\/youtu.be\/CtSHDC-bsu4",
      "display_url" : "youtu.be\/CtSHDC-bsu4"
    } ]
  },
  "geo" : { },
  "id_str" : "112533929298374656",
  "text" : "\"This weekend, we\u2019re coming together, as one nation, to mark the 10th anniv of the Sept 11th attacks\" -President Obama: http:\/\/t.co\/FSacfpV",
  "id" : 112533929298374656,
  "created_at" : "2011-09-10 14:32:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 51, 56 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http:\/\/t.co\/9FmKxOI",
      "expanded_url" : "http:\/\/1.usa.gov\/mPlRGm",
      "display_url" : "1.usa.gov\/mPlRGm"
    } ]
  },
  "geo" : { },
  "id_str" : "112343187997196289",
  "text" : "Experts confirm: The American Jobs Act will create #jobs: http:\/\/t.co\/9FmKxOI #JobsNow",
  "id" : 112343187997196289,
  "created_at" : "2011-09-10 01:54:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 37, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112307504893001728",
  "text" : "RT @PressSec: Enjoyed the first ever #WHTweetup briefing. Good people, good questions. Thanks to all who came. Am newly committed to twe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 23, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112304802591014912",
    "text" : "Enjoyed the first ever #WHTweetup briefing. Good people, good questions. Thanks to all who came. Am newly committed to tweeting. swear!",
    "id" : 112304802591014912,
    "created_at" : "2011-09-09 23:22:06 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 112307504893001728,
  "created_at" : "2011-09-09 23:32:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isabel Lara",
      "screen_name" : "isalara",
      "indices" : [ 3, 11 ],
      "id_str" : "18364847",
      "id" : 18364847
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHtweeps",
      "indices" : [ 67, 76 ]
    }, {
      "text" : "HappyFriday",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112297382582034433",
  "text" : "RT @isalara: Awesome day at the @whitehouse - met some really cool #WHtweeps today :-) #HappyFriday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 19, 30 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHtweeps",
        "indices" : [ 54, 63 ]
      }, {
        "text" : "HappyFriday",
        "indices" : [ 74, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112296176782548992",
    "text" : "Awesome day at the @whitehouse - met some really cool #WHtweeps today :-) #HappyFriday",
    "id" : 112296176782548992,
    "created_at" : "2011-09-09 22:47:49 +0000",
    "user" : {
      "name" : "Isabel Lara",
      "screen_name" : "isalara",
      "protected" : false,
      "id_str" : "18364847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795257855091896320\/7yyou7I6_normal.jpg",
      "id" : 18364847,
      "verified" : false
    }
  },
  "id" : 112297382582034433,
  "created_at" : "2011-09-09 22:52:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Kinnari",
      "screen_name" : "aaronkinnari",
      "indices" : [ 3, 16 ],
      "id_str" : "47839461",
      "id" : 47839461
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 43, 52 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Jobs",
      "indices" : [ 76, 81 ]
    }, {
      "text" : "economy",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112283832778108928",
  "text" : "RT @aaronkinnari: Some great insights from @PressSec Carney on the American #Jobs Act & other WH initiatives to grow the #economy at the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 25, 34 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Jobs",
        "indices" : [ 58, 63 ]
      }, {
        "text" : "economy",
        "indices" : [ 103, 111 ]
      }, {
        "text" : "WHTweetup",
        "indices" : [ 119, 129 ]
      }, {
        "text" : "jobsnow",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112282853546536961",
    "text" : "Some great insights from @PressSec Carney on the American #Jobs Act & other WH initiatives to grow the #economy at the #WHTweetup #jobsnow",
    "id" : 112282853546536961,
    "created_at" : "2011-09-09 21:54:53 +0000",
    "user" : {
      "name" : "Aaron Kinnari",
      "screen_name" : "aaronkinnari",
      "protected" : false,
      "id_str" : "47839461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781502435965669376\/qZVnznWB_normal.jpg",
      "id" : 47839461,
      "verified" : false
    }
  },
  "id" : 112283832778108928,
  "created_at" : "2011-09-09 21:58:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justin Doc Herman",
      "screen_name" : "JustinHerman",
      "indices" : [ 3, 16 ],
      "id_str" : "15378805",
      "id" : 15378805
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 87, 96 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/bD91xPQ",
      "expanded_url" : "http:\/\/instagr.am\/p\/MnRu6\/",
      "display_url" : "instagr.am\/p\/MnRu6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "112280908580667392",
  "text" : "RT @JustinHerman: More from the White House Press Secretary's Office in the West Wing (@presssec) #WHTweetup http:\/\/t.co\/bD91xPQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 69, 78 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 80, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 110 ],
        "url" : "http:\/\/t.co\/bD91xPQ",
        "expanded_url" : "http:\/\/instagr.am\/p\/MnRu6\/",
        "display_url" : "instagr.am\/p\/MnRu6\/"
      } ]
    },
    "geo" : { },
    "id_str" : "112279946969354241",
    "text" : "More from the White House Press Secretary's Office in the West Wing (@presssec) #WHTweetup http:\/\/t.co\/bD91xPQ",
    "id" : 112279946969354241,
    "created_at" : "2011-09-09 21:43:20 +0000",
    "user" : {
      "name" : "Justin Doc Herman",
      "screen_name" : "JustinHerman",
      "protected" : false,
      "id_str" : "15378805",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791626944634839040\/o1DRNJVi_normal.jpg",
      "id" : 15378805,
      "verified" : false
    }
  },
  "id" : 112280908580667392,
  "created_at" : "2011-09-09 21:47:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 52, 61 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http:\/\/t.co\/YtVPlDv",
      "expanded_url" : "http:\/\/yfrog.com\/keoz1bfj",
      "display_url" : "yfrog.com\/keoz1bfj"
    } ]
  },
  "geo" : { },
  "id_str" : "112280495756296193",
  "text" : "Happening now: #WHTweetup Briefing w\/ Jay Carney in @PressSec's office in the West Wing. Pic: http:\/\/t.co\/YtVPlDv",
  "id" : 112280495756296193,
  "created_at" : "2011-09-09 21:45:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 92, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112272976744955905",
  "text" : "RT @PressSec: I know - it's been too long! BUT- looking forward to answering q's in the 1st #WHTweetup Briefing. Follow it here: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 78, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 134 ],
        "url" : "http:\/\/t.co\/hPkVmbP",
        "expanded_url" : "https:\/\/twitter.com\/#!\/whitehouse\/tweetup-briefing",
        "display_url" : "twitter.com\/#!\/whitehouse\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "112271193486266368",
    "text" : "I know - it's been too long! BUT- looking forward to answering q's in the 1st #WHTweetup Briefing. Follow it here: http:\/\/t.co\/hPkVmbP",
    "id" : 112271193486266368,
    "created_at" : "2011-09-09 21:08:33 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 112272976744955905,
  "created_at" : "2011-09-09 21:15:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Ann ",
      "screen_name" : "kellyanncollins",
      "indices" : [ 3, 19 ],
      "id_str" : "3528714136",
      "id" : 3528714136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112267642521403392",
  "text" : "RT @kellyanncollins: Sneak peek at new \"We The People\" tools that haven't gone live yet - creating a petition looks super-easy! #whtweet ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whtweetup",
        "indices" : [ 107, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 139 ],
        "url" : "http:\/\/t.co\/wWjZu1k",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/wethepeople",
        "display_url" : "whitehouse.gov\/wethepeople"
      } ]
    },
    "geo" : { },
    "id_str" : "112267099858153472",
    "text" : "Sneak peek at new \"We The People\" tools that haven't gone live yet - creating a petition looks super-easy! #whtweetup | http:\/\/t.co\/wWjZu1k",
    "id" : 112267099858153472,
    "created_at" : "2011-09-09 20:52:17 +0000",
    "user" : {
      "name" : "Kelly Ann Collins",
      "screen_name" : "itskac",
      "protected" : false,
      "id_str" : "14114324",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797680838460796928\/tnAMaUGe_normal.jpg",
      "id" : 14114324,
      "verified" : false
    }
  },
  "id" : 112267642521403392,
  "created_at" : "2011-09-09 20:54:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112264250298339328",
  "text" : "RT @WHLive: .@dolupduk no, American Jobs Act will make the tax break for new hires effective now. What we need is Congress to pass the b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112263820407349248",
    "text" : ".@dolupduk no, American Jobs Act will make the tax break for new hires effective now. What we need is Congress to pass the bill #WHChat",
    "id" : 112263820407349248,
    "created_at" : "2011-09-09 20:39:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 112264250298339328,
  "created_at" : "2011-09-09 20:40:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Susan Reaney",
      "screen_name" : "SSReaney",
      "indices" : [ 13, 22 ],
      "id_str" : "82901787",
      "id" : 82901787
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112258698713378816",
  "text" : "RT @WHLive: .@SSReaney Stay tuned, we will be submitting full text of the American Jobs Act to Congress early next week #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Reaney",
        "screen_name" : "SSReaney",
        "indices" : [ 1, 10 ],
        "id_str" : "82901787",
        "id" : 82901787
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 108, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112258378562158593",
    "text" : ".@SSReaney Stay tuned, we will be submitting full text of the American Jobs Act to Congress early next week #WHChat",
    "id" : 112258378562158593,
    "created_at" : "2011-09-09 20:17:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 112258698713378816,
  "created_at" : "2011-09-09 20:18:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Reaney",
      "screen_name" : "SSReaney",
      "indices" : [ 3, 12 ],
      "id_str" : "82901787",
      "id" : 82901787
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Webhosting Chat",
      "screen_name" : "WHChat",
      "indices" : [ 26, 33 ],
      "id_str" : "153947010",
      "id" : 153947010
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 34, 41 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 42, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112258641255612417",
  "text" : "RT @SSReaney: @whitehouse @whchat @WHLive #whchat if you all have a copy of the propose bill how about supplying a copy to Congress so t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Webhosting Chat",
        "screen_name" : "WHChat",
        "indices" : [ 12, 19 ],
        "id_str" : "153947010",
        "id" : 153947010
      }, {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 20, 27 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 28, 35 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "112256754691223553",
    "geo" : { },
    "id_str" : "112257661453606912",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse @whchat @WHLive #whchat if you all have a copy of the propose bill how about supplying a copy to Congress so they can act on it!",
    "id" : 112257661453606912,
    "in_reply_to_status_id" : 112256754691223553,
    "created_at" : "2011-09-09 20:14:46 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Susan Reaney",
      "screen_name" : "SSReaney",
      "protected" : false,
      "id_str" : "82901787",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797509088930365440\/zL7SAYa5_normal.jpg",
      "id" : 82901787,
      "verified" : false
    }
  },
  "id" : 112258641255612417,
  "created_at" : "2011-09-09 20:18:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 70, 78 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 54, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 113 ],
      "url" : "http:\/\/t.co\/pBL1FW3",
      "expanded_url" : "http:\/\/bit.ly\/oCqDRe",
      "display_url" : "bit.ly\/oCqDRe"
    } ]
  },
  "geo" : { },
  "id_str" : "112257926609113088",
  "text" : "RT @aneeshchopra: Excited to meet the tweeps here for #WHTweetup with @macon44!Follow it here http:\/\/t.co\/pBL1FW3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "former Macon44",
        "screen_name" : "macon44",
        "indices" : [ 52, 60 ],
        "id_str" : "776593497122082820",
        "id" : 776593497122082820
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 36, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 95 ],
        "url" : "http:\/\/t.co\/pBL1FW3",
        "expanded_url" : "http:\/\/bit.ly\/oCqDRe",
        "display_url" : "bit.ly\/oCqDRe"
      } ]
    },
    "geo" : { },
    "id_str" : "112257512266407937",
    "text" : "Excited to meet the tweeps here for #WHTweetup with @macon44!Follow it here http:\/\/t.co\/pBL1FW3",
    "id" : 112257512266407937,
    "created_at" : "2011-09-09 20:14:11 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 112257926609113088,
  "created_at" : "2011-09-09 20:15:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Webhosting Chat",
      "screen_name" : "WHChat",
      "indices" : [ 108, 115 ],
      "id_str" : "153947010",
      "id" : 153947010
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 125, 132 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112256754691223553",
  "text" : "Starting now: Brian Deese from the NEC holding Office Hours to answer Q\u2019s on the American Jobs Act \u2013 ask w\/ @whchat & follow @WHLive",
  "id" : 112256754691223553,
  "created_at" : "2011-09-09 20:11:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    }, {
      "name" : "AFL-CIO",
      "screen_name" : "AFLCIO",
      "indices" : [ 58, 65 ],
      "id_str" : "10069612",
      "id" : 10069612
    }, {
      "name" : "AFSCME",
      "screen_name" : "AFSCME",
      "indices" : [ 66, 73 ],
      "id_str" : "14240875",
      "id" : 14240875
    }, {
      "name" : "Civil Rights",
      "screen_name" : "civilrightsorg",
      "indices" : [ 74, 89 ],
      "id_str" : "58503762",
      "id" : 58503762
    }, {
      "name" : "NEA",
      "screen_name" : "NEAToday",
      "indices" : [ 90, 99 ],
      "id_str" : "22789766",
      "id" : 22789766
    }, {
      "name" : "Small Biz Majority",
      "screen_name" : "SmlBizMajority",
      "indices" : [ 100, 115 ],
      "id_str" : "198959733",
      "id" : 198959733
    }, {
      "name" : "United Steelworkers",
      "screen_name" : "steelworkers",
      "indices" : [ 116, 129 ],
      "id_str" : "108993692",
      "id" : 108993692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 53, 56 ]
    }, {
      "text" : "JobsNow",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112251641322946561",
  "text" : "RT @NancyPelosi: Supporters of the American Jobs Act #FF: @AFLCIO @AFSCME @civilrightsorg @NEAToday @SmlBizMajority @steelworkers #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AFL-CIO",
        "screen_name" : "AFLCIO",
        "indices" : [ 41, 48 ],
        "id_str" : "10069612",
        "id" : 10069612
      }, {
        "name" : "AFSCME",
        "screen_name" : "AFSCME",
        "indices" : [ 49, 56 ],
        "id_str" : "14240875",
        "id" : 14240875
      }, {
        "name" : "Civil Rights",
        "screen_name" : "civilrightsorg",
        "indices" : [ 57, 72 ],
        "id_str" : "58503762",
        "id" : 58503762
      }, {
        "name" : "NEA",
        "screen_name" : "NEAToday",
        "indices" : [ 73, 82 ],
        "id_str" : "22789766",
        "id" : 22789766
      }, {
        "name" : "Small Biz Majority",
        "screen_name" : "SmlBizMajority",
        "indices" : [ 83, 98 ],
        "id_str" : "198959733",
        "id" : 198959733
      }, {
        "name" : "United Steelworkers",
        "screen_name" : "steelworkers",
        "indices" : [ 99, 112 ],
        "id_str" : "108993692",
        "id" : 108993692
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FF",
        "indices" : [ 36, 39 ]
      }, {
        "text" : "JobsNow",
        "indices" : [ 113, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112245273706774529",
    "text" : "Supporters of the American Jobs Act #FF: @AFLCIO @AFSCME @civilrightsorg @NEAToday @SmlBizMajority @steelworkers #JobsNow",
    "id" : 112245273706774529,
    "created_at" : "2011-09-09 19:25:33 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 112251641322946561,
  "created_at" : "2011-09-09 19:50:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 102, 110 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112251569579372544",
  "text" : "RT @WHLive: Office Hours @ 4ET: Brian Deese of NEC will be here to answer your Qs on Obama's plan for #JobsNow. Ask: #WHChat Follow Q&A: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 125, 132 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 90, 98 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112248230670114816",
    "text" : "Office Hours @ 4ET: Brian Deese of NEC will be here to answer your Qs on Obama's plan for #JobsNow. Ask: #WHChat Follow Q&A: @WHLive",
    "id" : 112248230670114816,
    "created_at" : "2011-09-09 19:37:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 112251569579372544,
  "created_at" : "2011-09-09 19:50:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 82, 89 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 43, 51 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112246286958329856",
  "text" : "Have Qs on the American Jobs Act & Obama's #JobsNow speech? WH econ staff will be @WHLive for Office Hours @ 4ET. Ask now w\/ #WHChat",
  "id" : 112246286958329856,
  "created_at" : "2011-09-09 19:29:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/AWoHfQI",
      "expanded_url" : "http:\/\/bit.ly\/qIzkMq",
      "display_url" : "bit.ly\/qIzkMq"
    } ]
  },
  "geo" : { },
  "id_str" : "112215098348675072",
  "text" : "RT @RayLaHood: American Jobs Act will get workers back where they belong\u2014on the job, rebuilding America. http:\/\/t.co\/AWoHfQI #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 109 ],
        "url" : "http:\/\/t.co\/AWoHfQI",
        "expanded_url" : "http:\/\/bit.ly\/qIzkMq",
        "display_url" : "bit.ly\/qIzkMq"
      } ]
    },
    "geo" : { },
    "id_str" : "112210573709684736",
    "text" : "American Jobs Act will get workers back where they belong\u2014on the job, rebuilding America. http:\/\/t.co\/AWoHfQI #JobsNow",
    "id" : 112210573709684736,
    "created_at" : "2011-09-09 17:07:40 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 112215098348675072,
  "created_at" : "2011-09-09 17:25:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 28, 37 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "911Day",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 93 ],
      "url" : "http:\/\/t.co\/AOQvBJn",
      "expanded_url" : "http:\/\/usat.ly\/r9JgiE",
      "display_url" : "usat.ly\/r9JgiE"
    } ]
  },
  "geo" : { },
  "id_str" : "112210878803349504",
  "text" : "Op-ed by President Obama in @USAToday: Let's Reclaim the Post-9\/11 Unity: http:\/\/t.co\/AOQvBJn #911Day",
  "id" : 112210878803349504,
  "created_at" : "2011-09-09 17:08:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 22, 31 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 82, 90 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 91, 104 ],
      "id_str" : "121539516",
      "id" : 121539516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/eTvbAlt",
      "expanded_url" : "https:\/\/twitter.com\/#!\/whitehouse\/tweetup-briefing",
      "display_url" : "twitter.com\/#!\/whitehouse\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "112194554039508993",
  "text" : "#WHTweetup Briefing w @PressSec is today! Tweeps just arrived for a tour & mtgs w @Macon44 @AneeshChopra. Follow here: http:\/\/t.co\/eTvbAlt",
  "id" : 112194554039508993,
  "created_at" : "2011-09-09 16:04:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/v8SVzMj",
      "expanded_url" : "http:\/\/youtu.be\/N5f-FwN2ZJs",
      "display_url" : "youtu.be\/N5f-FwN2ZJs"
    } ]
  },
  "geo" : { },
  "id_str" : "111996277448912897",
  "text" : "American Jobs Act: Watch the web-only enhanced version of the President's address to Congress: http:\/\/t.co\/v8SVzMj #JobsNow",
  "id" : 111996277448912897,
  "created_at" : "2011-09-09 02:56:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 3, 19 ],
      "id_str" : "234141596",
      "id" : 234141596
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 123, 134 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 31, 37 ]
    }, {
      "text" : "CT",
      "indices" : [ 78, 81 ]
    }, {
      "text" : "AmericanJobsAct",
      "indices" : [ 106, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111978144201838594",
  "text" : "RT @GovMalloyOffice: President #Obama\u2019s proposals will be a direct benefit to #CT residents & businesses. #AmericanJobsAct @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 102, 113 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 10, 16 ]
      }, {
        "text" : "CT",
        "indices" : [ 57, 60 ]
      }, {
        "text" : "AmericanJobsAct",
        "indices" : [ 85, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111954736651051008",
    "text" : "President #Obama\u2019s proposals will be a direct benefit to #CT residents & businesses. #AmericanJobsAct @whitehouse",
    "id" : 111954736651051008,
    "created_at" : "2011-09-09 00:11:03 +0000",
    "user" : {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "protected" : false,
      "id_str" : "234141596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738519424223858688\/_0xQvvKS_normal.jpg",
      "id" : 234141596,
      "verified" : true
    }
  },
  "id" : 111978144201838594,
  "created_at" : "2011-09-09 01:44:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steny Hoyer",
      "screen_name" : "WhipHoyer",
      "indices" : [ 3, 13 ],
      "id_str" : "22012091",
      "id" : 22012091
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 59, 67 ]
    }, {
      "text" : "GOP",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111977056937582592",
  "text" : "RT @WhipHoyer: Tonight President Obama unveiled a plan for #jobsnow that can and should pass. #GOP should work with us to help more peop ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobsnow",
        "indices" : [ 44, 52 ]
      }, {
        "text" : "GOP",
        "indices" : [ 79, 83 ]
      }, {
        "text" : "MakeItInAmerica",
        "indices" : [ 124, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111962079908470784",
    "text" : "Tonight President Obama unveiled a plan for #jobsnow that can and should pass. #GOP should work with us to help more people #MakeItInAmerica",
    "id" : 111962079908470784,
    "created_at" : "2011-09-09 00:40:14 +0000",
    "user" : {
      "name" : "Steny Hoyer",
      "screen_name" : "WhipHoyer",
      "protected" : false,
      "id_str" : "22012091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742490369347203072\/WLvGn-ia_normal.jpg",
      "id" : 22012091,
      "verified" : true
    }
  },
  "id" : 111977056937582592,
  "created_at" : "2011-09-09 01:39:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MayorSlay.com",
      "screen_name" : "MayorSlay",
      "indices" : [ 3, 13 ],
      "id_str" : "16332522",
      "id" : 16332522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111976774107283456",
  "text" : "RT @MayorSlay: We are tougher than the times we live in, bigger than our politics ...  The American Jobs Act was framed in a great speech.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111947632846454785",
    "text" : "We are tougher than the times we live in, bigger than our politics ...  The American Jobs Act was framed in a great speech.",
    "id" : 111947632846454785,
    "created_at" : "2011-09-08 23:42:50 +0000",
    "user" : {
      "name" : "MayorSlay.com",
      "screen_name" : "MayorSlay",
      "protected" : false,
      "id_str" : "16332522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2756545289\/05bd2ce1e341434544143eb7ce41b2ac_normal.png",
      "id" : 16332522,
      "verified" : true
    }
  },
  "id" : 111976774107283456,
  "created_at" : "2011-09-09 01:38:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 35, 43 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111974097591861248",
  "text" : "RT @macon44: In top 10 trending on @twitter for US during Obama speech: Presidential Address, American Jobs Act, Fair Share, Simple Math ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 22, 30 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsSpeech",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111972349456289792",
    "text" : "In top 10 trending on @twitter for US during Obama speech: Presidential Address, American Jobs Act, Fair Share, Simple Math, #JobsSpeech",
    "id" : 111972349456289792,
    "created_at" : "2011-09-09 01:21:03 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 111974097591861248,
  "created_at" : "2011-09-09 01:27:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Nutter",
      "screen_name" : "Michael_Nutter",
      "indices" : [ 3, 18 ],
      "id_str" : "202790178",
      "id" : 202790178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111967457408847872",
  "text" : "RT @Michael_Nutter: The President has laid out a plan, now it's time for Congress to act. Put the politics aside & get to work creating  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111947744461066241",
    "text" : "The President has laid out a plan, now it's time for Congress to act. Put the politics aside & get to work creating jobs for Americans now.",
    "id" : 111947744461066241,
    "created_at" : "2011-09-08 23:43:16 +0000",
    "user" : {
      "name" : "Michael A. Nutter",
      "screen_name" : "Michael_Nutter",
      "protected" : false,
      "id_str" : "202790178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753094044654395392\/Rt-pdJuc_normal.jpg",
      "id" : 202790178,
      "verified" : true
    }
  },
  "id" : 111967457408847872,
  "created_at" : "2011-09-09 01:01:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111966454261366784",
  "text" : "RT @SenatorReid: Americans are looking at us for leadership, and I hope Rs join Ds in passing the President\u2019s bi-partisan #jobs plan asap",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 105, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111956810293981185",
    "text" : "Americans are looking at us for leadership, and I hope Rs join Ds in passing the President\u2019s bi-partisan #jobs plan asap",
    "id" : 111956810293981185,
    "created_at" : "2011-09-09 00:19:18 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 111966454261366784,
  "created_at" : "2011-09-09 00:57:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111966275349127169",
  "text" : "RT @NancyPelosi: GOP has a choice to either work with Dems on creating #JobsNow or waste more time--POTUS has put forward a plan & Dems  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 54, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111955541181464576",
    "text" : "GOP has a choice to either work with Dems on creating #JobsNow or waste more time--POTUS has put forward a plan & Dems are prepared to act.",
    "id" : 111955541181464576,
    "created_at" : "2011-09-09 00:14:15 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 111966275349127169,
  "created_at" : "2011-09-09 00:56:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Udall",
      "screen_name" : "SenatorTomUdall",
      "indices" : [ 3, 19 ],
      "id_str" : "60828944",
      "id" : 60828944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111966094641733632",
  "text" : "RT @SenatorTomUdall: Great speech. It's time for Congress to stop bickering & unite w\/ a balanced\/effective jobs bill to inspire confide ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111948682466824192",
    "text" : "Great speech. It's time for Congress to stop bickering & unite w\/ a balanced\/effective jobs bill to inspire confidence in the economy.",
    "id" : 111948682466824192,
    "created_at" : "2011-09-08 23:47:00 +0000",
    "user" : {
      "name" : "Tom Udall",
      "screen_name" : "SenatorTomUdall",
      "protected" : false,
      "id_str" : "60828944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796471076687671297\/IubNkFTl_normal.jpg",
      "id" : 60828944,
      "verified" : true
    }
  },
  "id" : 111966094641733632,
  "created_at" : "2011-09-09 00:56:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 128 ],
      "url" : "http:\/\/t.co\/zXgmLm5",
      "expanded_url" : "http:\/\/1.usa.gov\/pPEeo4",
      "display_url" : "1.usa.gov\/pPEeo4"
    } ]
  },
  "geo" : { },
  "id_str" : "111960537297985536",
  "text" : "FACT SHEET: American Jobs Act helps families, small biz hire & puts teachers & construction workers to work: http:\/\/t.co\/zXgmLm5 #JobsNow",
  "id" : 111960537297985536,
  "created_at" : "2011-09-09 00:34:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "b.e-l.l-e a.-",
      "screen_name" : "bellicious206",
      "indices" : [ 3, 17 ],
      "id_str" : "52579496",
      "id" : 52579496
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 34, 46 ],
      "id_str" : "813286",
      "id" : 813286
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 102, 109 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 50, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111955994879328256",
  "text" : "RT @bellicious206: I just took in @BarackObama 's #JobsNow speech in &lt;10mins via twitter feed. Thx @WHLive...and just about every oth ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 15, 27 ],
        "id_str" : "813286",
        "id" : 813286
      }, {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 83, 90 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 31, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111955582851887104",
    "text" : "I just took in @BarackObama 's #JobsNow speech in &lt;10mins via twitter feed. Thx @WHLive...and just about every other person i follow on here",
    "id" : 111955582851887104,
    "created_at" : "2011-09-09 00:14:25 +0000",
    "user" : {
      "name" : "b.e-l.l-e a.-",
      "screen_name" : "bellicious206",
      "protected" : false,
      "id_str" : "52579496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/293001922\/me_normal.jpg",
      "id" : 52579496,
      "verified" : false
    }
  },
  "id" : 111955994879328256,
  "created_at" : "2011-09-09 00:16:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Adams",
      "screen_name" : "evan_adams",
      "indices" : [ 0, 11 ],
      "id_str" : "32180339",
      "id" : 32180339
    }, {
      "name" : "Immediate Capital",
      "screen_name" : "aialobbyist",
      "indices" : [ 12, 24 ],
      "id_str" : "2162848507",
      "id" : 2162848507
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/l93MN40",
      "expanded_url" : "https:\/\/twitter.com\/#!\/WHLive\/status\/111941126574968832",
      "display_url" : "twitter.com\/#!\/WHLive\/stat\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "111949180540432384",
  "geo" : { },
  "id_str" : "111951425013161984",
  "in_reply_to_user_id" : 32180339,
  "text" : "@evan_adams @aialobbyist schools a central part of #jobsnow - from tonight's speech: http:\/\/t.co\/l93MN40",
  "id" : 111951425013161984,
  "in_reply_to_status_id" : 111949180540432384,
  "created_at" : "2011-09-08 23:57:54 +0000",
  "in_reply_to_screen_name" : "evan_adams",
  "in_reply_to_user_id_str" : "32180339",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam VanHo",
      "screen_name" : "adamvanho",
      "indices" : [ 1, 11 ],
      "id_str" : "50807638",
      "id" : 50807638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 139 ],
      "url" : "http:\/\/t.co\/pQF41T9",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "in_reply_to_status_id_str" : "111949093336649728",
  "geo" : { },
  "id_str" : "111950250478010368",
  "in_reply_to_user_id" : 50807638,
  "text" : ".@adamvanho no worries! we'll post #jobsnow speech to wh.gov video asap, incl enhanced version & there's live Q&A now @ http:\/\/t.co\/pQF41T9",
  "id" : 111950250478010368,
  "in_reply_to_status_id" : 111949093336649728,
  "created_at" : "2011-09-08 23:53:14 +0000",
  "in_reply_to_screen_name" : "adamvanho",
  "in_reply_to_user_id_str" : "50807638",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 32, 39 ]
    }, {
      "text" : "jobsnow",
      "indices" : [ 86, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/IGc2afS",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "111950044835491840",
  "text" : "We're Open for Questions -- Use #WHChat to ask our policy panel Qs on the President's #jobsnow plan. Happening now: http:\/\/t.co\/IGc2afS",
  "id" : 111950044835491840,
  "created_at" : "2011-09-08 23:52:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie DeVito",
      "screen_name" : "kdevito",
      "indices" : [ 3, 11 ],
      "id_str" : "18231339",
      "id" : 18231339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "americanjobsact",
      "indices" : [ 28, 44 ]
    }, {
      "text" : "jobsnow",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "Nj",
      "indices" : [ 54, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111948701127290881",
  "text" : "RT @kdevito: Let's do this! #americanjobsact #jobsnow #Nj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "americanjobsact",
        "indices" : [ 15, 31 ]
      }, {
        "text" : "jobsnow",
        "indices" : [ 32, 40 ]
      }, {
        "text" : "Nj",
        "indices" : [ 41, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111948522458324992",
    "text" : "Let's do this! #americanjobsact #jobsnow #Nj",
    "id" : 111948522458324992,
    "created_at" : "2011-09-08 23:46:22 +0000",
    "user" : {
      "name" : "Katie DeVito",
      "screen_name" : "kdevito",
      "protected" : false,
      "id_str" : "18231339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2555713779\/uuf38xbodjt71lkbl52o_normal.jpeg",
      "id" : 18231339,
      "verified" : false
    }
  },
  "id" : 111948701127290881,
  "created_at" : "2011-09-08 23:47:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 32, 40 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/pQF41T9",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "111948258431090688",
  "text" : "Do you have questions about the #JobsNow speech? You can ask the using #WHChat. Live event happening now http:\/\/t.co\/pQF41T9",
  "id" : 111948258431090688,
  "created_at" : "2011-09-08 23:45:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111947651959881728",
  "text" : "RT @WHLive: Obama: Let\u2019s get to work, and show the world once again why the United States of America remains the greatest nation on Eart ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111947425303887873",
    "text" : "Obama: Let\u2019s get to work, and show the world once again why the United States of America remains the greatest nation on Earth. #JobsNow",
    "id" : 111947425303887873,
    "created_at" : "2011-09-08 23:42:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111947651959881728,
  "created_at" : "2011-09-08 23:42:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111947583206862848",
  "text" : "RT @WHLive: Obama: Kennedy once said, \u201COur problems are man-made \u2013 therefore they can be solved by man.  And man can be as big as he wan ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 129, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111947331858997248",
    "text" : "Obama: Kennedy once said, \u201COur problems are man-made \u2013 therefore they can be solved by man.  And man can be as big as he wants.\u201D #JobsNow",
    "id" : 111947331858997248,
    "created_at" : "2011-09-08 23:41:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111947583206862848,
  "created_at" : "2011-09-08 23:42:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111947474553417728",
  "text" : "RT @WHLive: Obama: ...Tell Washington that doing nothing is not an option. #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 63, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111947291690147841",
    "text" : "Obama: ...Tell Washington that doing nothing is not an option. #JobsNow",
    "id" : 111947291690147841,
    "created_at" : "2011-09-08 23:41:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111947474553417728,
  "created_at" : "2011-09-08 23:42:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111947378881331201",
  "text" : "RT @WHLive: Obama: Regardless of the arguments we\u2019ve had in the past ... this plan is the right thing to do right now. #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111947123041382401",
    "text" : "Obama: Regardless of the arguments we\u2019ve had in the past ... this plan is the right thing to do right now. #JobsNow",
    "id" : 111947123041382401,
    "created_at" : "2011-09-08 23:40:48 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111947378881331201,
  "created_at" : "2011-09-08 23:41:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111946779599192064",
  "text" : "RT @WHLive: Obama: I know there\u2019s been a lot of skepticism...we\u2019re seeing the same old press releases & tweets flying back and forth. #J ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 122, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111946724670570496",
    "text" : "Obama: I know there\u2019s been a lot of skepticism...we\u2019re seeing the same old press releases & tweets flying back and forth. #JobsNow",
    "id" : 111946724670570496,
    "created_at" : "2011-09-08 23:39:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111946779599192064,
  "created_at" : "2011-09-08 23:39:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111946493082091520",
  "text" : "RT @WHLive: Obama: No single individual built America on their own. We built it together. #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 78, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111946430339497984",
    "text" : "Obama: No single individual built America on their own. We built it together. #JobsNow",
    "id" : 111946430339497984,
    "created_at" : "2011-09-08 23:38:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111946493082091520,
  "created_at" : "2011-09-08 23:38:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111946088495333376",
  "text" : "RT @WHLive: Obama: There has always been another thread running throughout our history...there are some things we can only do together,  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111945978168348672",
    "text" : "Obama: There has always been another thread running throughout our history...there are some things we can only do together, as a nation.",
    "id" : 111945978168348672,
    "created_at" : "2011-09-08 23:36:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111946088495333376,
  "created_at" : "2011-09-08 23:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111945605152116736",
  "text" : "RT @WHLive: Obama: I agree that we can\u2019t afford wasteful spending & I will continue to work with you, with Congress to root it out. #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 120, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111945353049288705",
    "text" : "Obama: I agree that we can\u2019t afford wasteful spending & I will continue to work with you, with Congress to root it out. #JobsNow",
    "id" : 111945353049288705,
    "created_at" : "2011-09-08 23:33:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111945605152116736,
  "created_at" : "2011-09-08 23:34:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Baratunde",
      "screen_name" : "baratunde",
      "indices" : [ 20, 30 ],
      "id_str" : "820585",
      "id" : 820585
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 47, 58 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 113, 121 ]
    }, {
      "text" : "MakeItPlain",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111945437220577281",
  "text" : "RT @jesseclee44: RT @baratunde: check out this @whitehouse image of Warren Buffet's tax rate vs his secretary's. #JobsNow #MakeItPlain h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Baratunde",
        "screen_name" : "baratunde",
        "indices" : [ 3, 13 ],
        "id_str" : "820585",
        "id" : 820585
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 30, 41 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/baratunde\/status\/111944015955509248\/photo\/1",
        "indices" : [ 118, 137 ],
        "url" : "http:\/\/t.co\/XDdB2Ox",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AY20fUoCQAAZkts.png",
        "id_str" : "111944015959703552",
        "id" : 111944015959703552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AY20fUoCQAAZkts.png",
        "sizes" : [ {
          "h" : 363,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 411,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 206,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XDdB2Ox"
      } ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 96, 104 ]
      }, {
        "text" : "MakeItPlain",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111944879256506370",
    "text" : "RT @baratunde: check out this @whitehouse image of Warren Buffet's tax rate vs his secretary's. #JobsNow #MakeItPlain http:\/\/t.co\/XDdB2Ox",
    "id" : 111944879256506370,
    "created_at" : "2011-09-08 23:31:53 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 111945437220577281,
  "created_at" : "2011-09-08 23:34:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenniffer White",
      "screen_name" : "cupadee",
      "indices" : [ 3, 11 ],
      "id_str" : "22950538",
      "id" : 22950538
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111944945857867776",
  "text" : "RT @cupadee: If you're not watching Obama's speech, you really should. #jobsnow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobsnow",
        "indices" : [ 58, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111944717398319104",
    "text" : "If you're not watching Obama's speech, you really should. #jobsnow",
    "id" : 111944717398319104,
    "created_at" : "2011-09-08 23:31:15 +0000",
    "user" : {
      "name" : "Jenniffer White",
      "screen_name" : "cupadee",
      "protected" : false,
      "id_str" : "22950538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634467869892419584\/FQfR0hUX_normal.jpg",
      "id" : 22950538,
      "verified" : false
    }
  },
  "id" : 111944945857867776,
  "created_at" : "2011-09-08 23:32:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111944758032740353",
  "text" : "RT @WHLive: Obama: If Americans can buy Kias & Hyundais, I want to see folks in South Korea driving Fords & Chevys & Chryslers. #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 116, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111944693230731264",
    "text" : "Obama: If Americans can buy Kias & Hyundais, I want to see folks in South Korea driving Fords & Chevys & Chryslers. #JobsNow",
    "id" : 111944693230731264,
    "created_at" : "2011-09-08 23:31:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111944758032740353,
  "created_at" : "2011-09-08 23:31:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 3, 18 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111944406835277824",
  "text" : "RT @startupamerica: \"This is simple math. These are real choices. It is  time for us to do what is right for our future.\" #jobsnow #star ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobsnow",
        "indices" : [ 102, 110 ]
      }, {
        "text" : "startupamerica",
        "indices" : [ 111, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111944139771355137",
    "text" : "\"This is simple math. These are real choices. It is  time for us to do what is right for our future.\" #jobsnow #startupamerica",
    "id" : 111944139771355137,
    "created_at" : "2011-09-08 23:28:57 +0000",
    "user" : {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "protected" : false,
      "id_str" : "211921304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1362197801\/120X120_ICON_normal.png",
      "id" : 211921304,
      "verified" : false
    }
  },
  "id" : 111944406835277824,
  "created_at" : "2011-09-08 23:30:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 118 ],
      "url" : "http:\/\/t.co\/hvw4YML",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live?utm_source=wh.gov&utm_medium=shorturl&utm_campaign=shorturl",
      "display_url" : "whitehouse.gov\/live?utm_sourc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "111944330977087489",
  "text" : "RT @JonCarson44: heading over to join a panel that goes live after the speech - hope you'll watch:\nhttp:\/\/t.co\/hvw4YML",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 101 ],
        "url" : "http:\/\/t.co\/hvw4YML",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live?utm_source=wh.gov&utm_medium=shorturl&utm_campaign=shorturl",
        "display_url" : "whitehouse.gov\/live?utm_sourc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "111943979079180288",
    "text" : "heading over to join a panel that goes live after the speech - hope you'll watch:\nhttp:\/\/t.co\/hvw4YML",
    "id" : 111943979079180288,
    "created_at" : "2011-09-08 23:28:19 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 111944330977087489,
  "created_at" : "2011-09-08 23:29:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111943815413252097",
  "text" : "RT @WHLive: Obama: Right now, Warren Buffet pays a lower tax rate than his secretary \u2013 an outrage he has asked us to fix.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111943288830959617",
    "text" : "Obama: Right now, Warren Buffet pays a lower tax rate than his secretary \u2013 an outrage he has asked us to fix.",
    "id" : 111943288830959617,
    "created_at" : "2011-09-08 23:25:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111943815413252097,
  "created_at" : "2011-09-08 23:27:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111942767344746496",
  "text" : "RT @WHLive: Obama: I want the American people to know: the American Jobs Act will not add to the deficit. It will be paid for. #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 115, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111942564260741120",
    "text" : "Obama: I want the American people to know: the American Jobs Act will not add to the deficit. It will be paid for. #JobsNow",
    "id" : 111942564260741120,
    "created_at" : "2011-09-08 23:22:41 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111942767344746496,
  "created_at" : "2011-09-08 23:23:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kieren McCarthy",
      "screen_name" : "kierenmccarthy",
      "indices" : [ 3, 18 ],
      "id_str" : "83951122",
      "id" : 83951122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111942462087507968",
  "text" : "RT @kierenmccarthy: I am getting the sense that Obama has put together a Jobs Bill and he would like Congress to look at it relatively q ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobsnow",
        "indices" : [ 123, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111942213914738689",
    "text" : "I am getting the sense that Obama has put together a Jobs Bill and he would like Congress to look at it relatively quickly #jobsnow",
    "id" : 111942213914738689,
    "created_at" : "2011-09-08 23:21:18 +0000",
    "user" : {
      "name" : "Kieren McCarthy",
      "screen_name" : "kierenmccarthy",
      "protected" : false,
      "id_str" : "83951122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2044033734\/kieren-mccarthy-smiling-square-300px_normal.jpg",
      "id" : 83951122,
      "verified" : false
    }
  },
  "id" : 111942462087507968,
  "created_at" : "2011-09-08 23:22:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111942110512562177",
  "text" : "RT @WHLive: Obama: Pass this jobs bill & companies will get a $4000 tax credit if they hire anyone who has spent more than six months lo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111941986872864768",
    "text" : "Obama: Pass this jobs bill & companies will get a $4000 tax credit if they hire anyone who has spent more than six months looking for a job",
    "id" : 111941986872864768,
    "created_at" : "2011-09-08 23:20:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111942110512562177,
  "created_at" : "2011-09-08 23:20:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepa",
      "screen_name" : "deepa_k",
      "indices" : [ 3, 11 ],
      "id_str" : "24363945",
      "id" : 24363945
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111941859235999744",
  "text" : "RT @deepa_k: If you're watching @whitehouse live stream - the split screen of graphics\/speech is pretty sweet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 19, 30 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111941823395659776",
    "text" : "If you're watching @whitehouse live stream - the split screen of graphics\/speech is pretty sweet.",
    "id" : 111941823395659776,
    "created_at" : "2011-09-08 23:19:45 +0000",
    "user" : {
      "name" : "Deepa",
      "screen_name" : "deepa_k",
      "protected" : false,
      "id_str" : "24363945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514101527363846144\/tKc0PQEe_normal.jpeg",
      "id" : 24363945,
      "verified" : false
    }
  },
  "id" : 111941859235999744,
  "created_at" : "2011-09-08 23:19:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111941372432490496",
  "text" : "RT @WHLive: Obama: The American Jobs Act will repair & modernize at least 35,000 schools. #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 78, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111941126574968832",
    "text" : "Obama: The American Jobs Act will repair & modernize at least 35,000 schools. #JobsNow",
    "id" : 111941126574968832,
    "created_at" : "2011-09-08 23:16:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111941372432490496,
  "created_at" : "2011-09-08 23:17:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111940986145488897",
  "text" : "RT @WHLive: Obama: Pass this jobs bill & all small business owners will also see their payroll taxes cut in half next year. #JobsNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 112, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111940537430441984",
    "text" : "Obama: Pass this jobs bill & all small business owners will also see their payroll taxes cut in half next year. #JobsNow",
    "id" : 111940537430441984,
    "created_at" : "2011-09-08 23:14:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111940986145488897,
  "created_at" : "2011-09-08 23:16:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/x5MVDn4",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/economy",
      "display_url" : "whitehouse.gov\/economy"
    } ]
  },
  "geo" : { },
  "id_str" : "111939976933027840",
  "text" : "Are you watching the *enhanced* version of the #JobsNow speech?  You should: http:\/\/t.co\/x5MVDn4",
  "id" : 111939976933027840,
  "created_at" : "2011-09-08 23:12:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111939790206799872",
  "text" : "RT @WHLive: Obama: The millions of Americans who are watching right now: they don\u2019t care about politics. They have real life concerns. # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 123, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111939402565038081",
    "text" : "Obama: The millions of Americans who are watching right now: they don\u2019t care about politics. They have real life concerns. #JobsNow",
    "id" : 111939402565038081,
    "created_at" : "2011-09-08 23:10:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111939790206799872,
  "created_at" : "2011-09-08 23:11:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 76, 83 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 12, 20 ]
    }, {
      "text" : "whchat",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111939182527655936",
  "text" : "Few things: #JobsNow speech starting. Watch @ WH.gov\/live. Live Tweets from @whlive. Live Video Chat afterwards. Use #whchat for ?'s",
  "id" : 111939182527655936,
  "created_at" : "2011-09-08 23:09:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 57, 64 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111928669903134720",
  "text" : "RT @WHLive: Join us @ 7ET: Live tweeting happening here: @WHLive Live stream of Obama's #jobsnow speech w charts & stats here: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 45, 52 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobsnow",
        "indices" : [ 76, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 134 ],
        "url" : "http:\/\/t.co\/9d2iD5e",
        "expanded_url" : "http:\/\/www.wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "111928439333851136",
    "text" : "Join us @ 7ET: Live tweeting happening here: @WHLive Live stream of Obama's #jobsnow speech w charts & stats here: http:\/\/t.co\/9d2iD5e",
    "id" : 111928439333851136,
    "created_at" : "2011-09-08 22:26:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 111928669903134720,
  "created_at" : "2011-09-08 22:27:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 68, 75 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111925885812224001",
  "text" : "We know live tweeting a speech can overwhelm your feed -- check out @WHLive for real-time updates of Obama's speech on #jobsnow.",
  "id" : 111925885812224001,
  "created_at" : "2011-09-08 22:16:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/111913436140670976\/photo\/1",
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/BuVKDAI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AY2YrV8CEAIgik9.jpg",
      "id_str" : "111913436144865282",
      "id" : 111913436144865282,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AY2YrV8CEAIgik9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 476
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 476
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 476
      } ],
      "display_url" : "pic.twitter.com\/BuVKDAI"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 8, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http:\/\/t.co\/Wql9hJp",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    }, {
      "indices" : [ 90, 109 ],
      "url" : "http:\/\/t.co\/94aINLR",
      "expanded_url" : "http:\/\/wh.gov\/YGL",
      "display_url" : "wh.gov\/YGL"
    } ]
  },
  "geo" : { },
  "id_str" : "111913436140670976",
  "text" : "Obama's #jobs address enhanced w\/ charts, graphs & quick stats only @ http:\/\/t.co\/Wql9hJp http:\/\/t.co\/94aINLR http:\/\/t.co\/BuVKDAI",
  "id" : 111913436140670976,
  "created_at" : "2011-09-08 21:26:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 48, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 84 ],
      "url" : "http:\/\/t.co\/G5HC1yi",
      "expanded_url" : "http:\/\/youtu.be\/l7uvQATrnJU",
      "display_url" : "youtu.be\/l7uvQATrnJU"
    }, {
      "indices" : [ 105, 124 ],
      "url" : "http:\/\/t.co\/Wql9hJp",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "111873867185786880",
  "text" : "Video: David Plouffe previews President Obama's #JobsNow speech:\nhttp:\/\/t.co\/G5HC1yi Tune in live @ 7ET: http:\/\/t.co\/Wql9hJp",
  "id" : 111873867185786880,
  "created_at" : "2011-09-08 18:49:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobsnow",
      "indices" : [ 70, 78 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/RzZejMD",
      "expanded_url" : "http:\/\/1.usa.gov\/qMvzXY",
      "display_url" : "1.usa.gov\/qMvzXY"
    } ]
  },
  "geo" : { },
  "id_str" : "111862298074820608",
  "text" : "Have Qs about the President's Address? Tune in live @ 7ET, discuss w\/ #jobsnow, ask admin officials ?s w\/ #WHchat: http:\/\/t.co\/RzZejMD",
  "id" : 111862298074820608,
  "created_at" : "2011-09-08 18:03:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 29, 37 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111833910467497984",
  "text" : "RT @JonCarson44: Just joined @Twitter in time for Obama's speech tonight. Got any tips for me? Looking forward to joining the convo on # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 12, 20 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JobsNow",
        "indices" : [ 118, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111833172379045888",
    "text" : "Just joined @Twitter in time for Obama's speech tonight. Got any tips for me? Looking forward to joining the convo on #JobsNow",
    "id" : 111833172379045888,
    "created_at" : "2011-09-08 16:08:00 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 111833910467497984,
  "created_at" : "2011-09-08 16:10:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111812055069237248",
  "text" : "MT @pfeiffer44: Tonite Obama will unveil The American Jobs Act to put people back to work, put more money in peoples pocket \/\/ Use #JobsNow",
  "id" : 111812055069237248,
  "created_at" : "2011-09-08 14:44:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsNow",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 65 ],
      "url" : "http:\/\/t.co\/cCQ8ZOC",
      "expanded_url" : "http:\/\/1.usa.gov\/rs0Jx7",
      "display_url" : "1.usa.gov\/rs0Jx7"
    }, {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/WWqhIMv",
      "expanded_url" : "http:\/\/bit.ly\/qUAXSr",
      "display_url" : "bit.ly\/qUAXSr"
    } ]
  },
  "geo" : { },
  "id_str" : "111793644092129280",
  "text" : "Plouffe previews Pres Obama's Speech @ 7pmEDT http:\/\/t.co\/cCQ8ZOC http:\/\/t.co\/WWqhIMv *** Use #JobsNow to discuss ***",
  "id" : 111793644092129280,
  "created_at" : "2011-09-08 13:30:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jimmie Johnson",
      "screen_name" : "JimmieJohnson",
      "indices" : [ 3, 17 ],
      "id_str" : "265483421",
      "id" : 265483421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111580434961403904",
  "text" : "RT @JimmieJohnson: What an honor today in DC. It was surreal standing on stage next to POTUS while he spoke about my family & what I've  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111557736570949632",
    "text" : "What an honor today in DC. It was surreal standing on stage next to POTUS while he spoke about my family & what I've accomplished in racing.",
    "id" : 111557736570949632,
    "created_at" : "2011-09-07 21:53:31 +0000",
    "user" : {
      "name" : "Jimmie Johnson",
      "screen_name" : "JimmieJohnson",
      "protected" : false,
      "id_str" : "265483421",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793775689774272512\/yy4Rkbr0_normal.jpg",
      "id" : 265483421,
      "verified" : true
    }
  },
  "id" : 111580434961403904,
  "created_at" : "2011-09-07 23:23:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DHSJournal",
      "screen_name" : "DHSJournal",
      "indices" : [ 3, 14 ],
      "id_str" : "376234273",
      "id" : 376234273
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "911remembered",
      "indices" : [ 62, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/v8tiFKV",
      "expanded_url" : "http:\/\/www.dhs.gov\/files\/9-11-share-your-story.shtm",
      "display_url" : "dhs.gov\/files\/9-11-sha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "111564775242203136",
  "text" : "RT @DHSJournal: Share your September 11 story or memory using #911remembered and see what others are saying on http:\/\/t.co\/v8tiFKV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "911remembered",
        "indices" : [ 46, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 114 ],
        "url" : "http:\/\/t.co\/v8tiFKV",
        "expanded_url" : "http:\/\/www.dhs.gov\/files\/9-11-share-your-story.shtm",
        "display_url" : "dhs.gov\/files\/9-11-sha\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "111557183505829888",
    "text" : "Share your September 11 story or memory using #911remembered and see what others are saying on http:\/\/t.co\/v8tiFKV",
    "id" : 111557183505829888,
    "created_at" : "2011-09-07 21:51:19 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 111564775242203136,
  "created_at" : "2011-09-07 22:21:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASCAR",
      "screen_name" : "NASCAR",
      "indices" : [ 55, 62 ],
      "id_str" : "49153854",
      "id" : 49153854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 121 ],
      "url" : "http:\/\/t.co\/Wql9hJp",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "111540934197526529",
  "text" : "Happening now: President Obama Honors Jimmie Johnson\u2019s @NASCAR Sprint Cup Series Championship. Watch: http:\/\/t.co\/Wql9hJp",
  "id" : 111540934197526529,
  "created_at" : "2011-09-07 20:46:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/111521598258946048\/photo\/1",
      "indices" : [ 101, 120 ],
      "url" : "http:\/\/t.co\/wRqTXZ8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AYw0TYFCIAAW6v_.jpg",
      "id_str" : "111521598263140352",
      "id" : 111521598263140352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AYw0TYFCIAAW6v_.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/wRqTXZ8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111521598258946048",
  "text" : "Photo of the Day: President Barack Obama talks to Chief of Staff Bill Daley outside the Oval Office: http:\/\/t.co\/wRqTXZ8",
  "id" : 111521598258946048,
  "created_at" : "2011-09-07 19:29:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111465431302287360",
  "text" : "RT @pfeiffer44: Thursday  night, the President will propose new meaningful initiatives to create jobs and grow the economy and it will b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "111458147402657794",
    "text" : "Thursday  night, the President will propose new meaningful initiatives to create jobs and grow the economy and it will be fully paid for",
    "id" : 111458147402657794,
    "created_at" : "2011-09-07 15:17:47 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 111465431302287360,
  "created_at" : "2011-09-07 15:46:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/111233794618564608\/photo\/1",
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/gafsJBv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AYsui_-CIAEfLWA.jpg",
      "id_str" : "111233794622758913",
      "id" : 111233794622758913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AYsui_-CIAEfLWA.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/gafsJBv"
    } ],
    "hashtags" : [ {
      "text" : "transportation",
      "indices" : [ 50, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 97 ],
      "url" : "http:\/\/t.co\/nyPwfvO",
      "expanded_url" : "http:\/\/1.usa.gov\/nfPV0X",
      "display_url" : "1.usa.gov\/nfPV0X"
    } ]
  },
  "geo" : { },
  "id_str" : "111233794618564608",
  "text" : "The clock is ticking for a clean extension of the #transportation bill. Blog: http:\/\/t.co\/nyPwfvO Map of jobs @ stake: http:\/\/t.co\/gafsJBv",
  "id" : 111233794618564608,
  "created_at" : "2011-09-07 00:26:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    }, {
      "name" : "The FAA",
      "screen_name" : "FAANews",
      "indices" : [ 30, 38 ],
      "id_str" : "160946337",
      "id" : 160946337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/Kc7ZZho",
      "expanded_url" : "http:\/\/bit.ly\/n9kBLG",
      "display_url" : "bit.ly\/n9kBLG"
    } ]
  },
  "geo" : { },
  "id_str" : "111166838746001408",
  "text" : "RT @RayLaHood: New video from @FAANews, Air Traffic Employees Share Memories of 9\/11 http:\/\/t.co\/Kc7ZZho",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The FAA",
        "screen_name" : "FAANews",
        "indices" : [ 15, 23 ],
        "id_str" : "160946337",
        "id" : 160946337
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 89 ],
        "url" : "http:\/\/t.co\/Kc7ZZho",
        "expanded_url" : "http:\/\/bit.ly\/n9kBLG",
        "display_url" : "bit.ly\/n9kBLG"
      } ]
    },
    "geo" : { },
    "id_str" : "111102009410727937",
    "text" : "New video from @FAANews, Air Traffic Employees Share Memories of 9\/11 http:\/\/t.co\/Kc7ZZho",
    "id" : 111102009410727937,
    "created_at" : "2011-09-06 15:42:37 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 111166838746001408,
  "created_at" : "2011-09-06 20:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 47, 56 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/NJy8FKS",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/tweetup",
      "display_url" : "whitehouse.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "111130919917723649",
  "text" : "Don't miss your chance to come to the WH & ask @PressSec your Qs. #WHTweetup Briefing registration ends today @ 2ET: http:\/\/t.co\/NJy8FKS",
  "id" : 111130919917723649,
  "created_at" : "2011-09-06 17:37:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/Gy4aGgW",
      "expanded_url" : "http:\/\/www.wh.gov\/internships",
      "display_url" : "wh.gov\/internships"
    } ]
  },
  "geo" : { },
  "id_str" : "111108873049485312",
  "text" : "White House Internship Program: Deadline to submit Spring '12 applications is 9\/11. Learn more & apply: http:\/\/t.co\/Gy4aGgW",
  "id" : 111108873049485312,
  "created_at" : "2011-09-06 16:09:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    }, {
      "name" : "USAID East Africa",
      "screen_name" : "USAIDEastAfrica",
      "indices" : [ 101, 117 ],
      "id_str" : "259332426",
      "id" : 259332426
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Somalia",
      "indices" : [ 32, 40 ]
    }, {
      "text" : "HoACrisis",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http:\/\/t.co\/4SpERvU",
      "expanded_url" : "http:\/\/go.usa.gov\/0TV",
      "display_url" : "go.usa.gov\/0TV"
    } ]
  },
  "geo" : { },
  "id_str" : "111104105883250688",
  "text" : "RT @USAID: As famine spreads in #Somalia, we continue our assistance: http:\/\/t.co\/4SpERvU #HoACrisis @USAIDEastAfrica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USAID East Africa",
        "screen_name" : "USAIDEastAfrica",
        "indices" : [ 90, 106 ],
        "id_str" : "259332426",
        "id" : 259332426
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Somalia",
        "indices" : [ 21, 29 ]
      }, {
        "text" : "HoACrisis",
        "indices" : [ 79, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 78 ],
        "url" : "http:\/\/t.co\/4SpERvU",
        "expanded_url" : "http:\/\/go.usa.gov\/0TV",
        "display_url" : "go.usa.gov\/0TV"
      } ]
    },
    "geo" : { },
    "id_str" : "111100822569484288",
    "text" : "As famine spreads in #Somalia, we continue our assistance: http:\/\/t.co\/4SpERvU #HoACrisis @USAIDEastAfrica",
    "id" : 111100822569484288,
    "created_at" : "2011-09-06 15:37:54 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 111104105883250688,
  "created_at" : "2011-09-06 15:50:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 12, 21 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 37, 48 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 116 ],
      "url" : "http:\/\/t.co\/kHcbvEe",
      "expanded_url" : "http:\/\/www.wh.gov\/tweetup",
      "display_url" : "wh.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "111074983639396353",
  "text" : "Want to ask @PressSec your Qs at the @WhiteHouse? It's the last day to apply for the #WHTweetup: http:\/\/t.co\/kHcbvEe",
  "id" : 111074983639396353,
  "created_at" : "2011-09-06 13:55:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/110819530795794432\/photo\/1",
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/1q5VrgY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AYm1xq-CQAEZBr0.jpg",
      "id_str" : "110819530799988737",
      "id" : 110819530799988737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AYm1xq-CQAEZBr0.jpg",
      "sizes" : [ {
        "h" : 1239,
        "resize" : "fit",
        "w" : 1974
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1q5VrgY"
    } ],
    "hashtags" : [ {
      "text" : "LaborDay",
      "indices" : [ 90, 99 ]
    }, {
      "text" : "Detroit",
      "indices" : [ 109, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110819530795794432",
  "text" : "Photo of the Day: President Obama greets people after speaking to workers & families at a #LaborDay event in #Detroit: http:\/\/t.co\/1q5VrgY",
  "id" : 110819530795794432,
  "created_at" : "2011-09-05 21:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 44, 55 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 62, 71 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetUp",
      "indices" : [ 11, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/1zW56TD",
      "expanded_url" : "http:\/\/wh.gov\/tweetup",
      "display_url" : "wh.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "110790935251656704",
  "text" : "Announcing #WHTweetUp Briefing! Come to the @WhiteHouse & ask @PressSec your questions. Apply: http:\/\/t.co\/1zW56TD",
  "id" : 110790935251656704,
  "created_at" : "2011-09-05 19:06:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaborDay",
      "indices" : [ 4, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110729807205105665",
  "text" : "\"On #LaborDay...we celebrate our Nation's workers & we commit to supporting their efforts in moving our economy forward\" -President Obama",
  "id" : 110729807205105665,
  "created_at" : "2011-09-05 15:03:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110728096939913217",
  "text" : "RT @pfeiffer44: POTUS is heading to Detroit today for a Labor Day Picnic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "110725808699604992",
    "text" : "POTUS is heading to Detroit today for a Labor Day Picnic",
    "id" : 110725808699604992,
    "created_at" : "2011-09-05 14:47:44 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 110728096939913217,
  "created_at" : "2011-09-05 14:56:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hurricane",
      "indices" : [ 55, 65 ]
    }, {
      "text" : "Irene",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http:\/\/t.co\/PoyT01U",
      "expanded_url" : "http:\/\/1.usa.gov\/qcvovg",
      "display_url" : "1.usa.gov\/qcvovg"
    } ]
  },
  "geo" : { },
  "id_str" : "110473279231365121",
  "text" : "\"The entire country is behind you\" -President Obama to #Hurricane #Irene victims: http:\/\/t.co\/PoyT01U",
  "id" : 110473279231365121,
  "created_at" : "2011-09-04 22:04:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "transportation",
      "indices" : [ 22, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/Kvbxhaw",
      "expanded_url" : "http:\/\/youtu.be\/8AXuJ6Kt138",
      "display_url" : "youtu.be\/8AXuJ6Kt138"
    } ]
  },
  "geo" : { },
  "id_str" : "109962136616312833",
  "text" : "\"We need to pass this #transportation bill & put people to work rebuilding America.\" -President Obama: http:\/\/t.co\/Kvbxhaw",
  "id" : 109962136616312833,
  "created_at" : "2011-09-03 12:13:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaborDay",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 131 ],
      "url" : "http:\/\/t.co\/iSslTvw",
      "expanded_url" : "http:\/\/1.usa.gov\/mQRm53",
      "display_url" : "1.usa.gov\/mQRm53"
    } ]
  },
  "geo" : { },
  "id_str" : "109775360291381248",
  "text" : "\"When we come together, there is no limit to what the American workforce can do\" -President Obama on #LaborDay: http:\/\/t.co\/iSslTvw",
  "id" : 109775360291381248,
  "created_at" : "2011-09-02 23:51:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 118 ],
      "url" : "http:\/\/t.co\/QjKULFA",
      "expanded_url" : "http:\/\/youtu.be\/6OOqlfEc1t4",
      "display_url" : "youtu.be\/6OOqlfEc1t4"
    } ]
  },
  "geo" : { },
  "id_str" : "109766991916707840",
  "text" : "Welcome to the West Wing Week, your guide to everything that's happening at 1600 Pennsylvania Ave: http:\/\/t.co\/QjKULFA",
  "id" : 109766991916707840,
  "created_at" : "2011-09-02 23:17:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHWeb",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 66 ],
      "url" : "http:\/\/t.co\/hdyjt0U",
      "expanded_url" : "http:\/\/1.usa.gov\/omTjqM",
      "display_url" : "1.usa.gov\/omTjqM"
    } ]
  },
  "geo" : { },
  "id_str" : "109744463726907392",
  "text" : "Your questions about \"We the People\" answered: http:\/\/t.co\/hdyjt0U Got more ?s & feedback? Use #WHWeb",
  "id" : 109744463726907392,
  "created_at" : "2011-09-02 21:48:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "UNICEF",
      "screen_name" : "UNICEF",
      "indices" : [ 129, 136 ],
      "id_str" : "33933259",
      "id" : 33933259
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 20, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109708442138189827",
  "text" : "RT @AmbassadorRice: #FF As Somalia & Horn of Africa continue to struggle with famine, these UN agencies are making a difference: @UNICEF ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UNICEF",
        "screen_name" : "UNICEF",
        "indices" : [ 109, 116 ],
        "id_str" : "33933259",
        "id" : 33933259
      }, {
        "name" : "World Food Programme",
        "screen_name" : "WFP",
        "indices" : [ 117, 121 ],
        "id_str" : "27830610",
        "id" : 27830610
      }, {
        "name" : "UN Refugee Agency",
        "screen_name" : "Refugees",
        "indices" : [ 122, 131 ],
        "id_str" : "14361155",
        "id" : 14361155
      }, {
        "name" : "UNOCHA",
        "screen_name" : "UNOCHA",
        "indices" : [ 132, 139 ],
        "id_str" : "21303235",
        "id" : 21303235
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FF",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "109706966716256256",
    "text" : "#FF As Somalia & Horn of Africa continue to struggle with famine, these UN agencies are making a difference: @UNICEF @WFP @Refugees @UNOCHA",
    "id" : 109706966716256256,
    "created_at" : "2011-09-02 19:19:13 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 109708442138189827,
  "created_at" : "2011-09-02 19:25:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109642177075871744",
  "text" : "RT @macon44: Interesting idea: How the White House\u2019s New Online Petition System Can Be Kept Accountable - Techland - TIME.com http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 132 ],
        "url" : "http:\/\/t.co\/oggn2XF",
        "expanded_url" : "http:\/\/ti.me\/rfXKjC",
        "display_url" : "ti.me\/rfXKjC"
      } ]
    },
    "geo" : { },
    "id_str" : "109641786661670912",
    "text" : "Interesting idea: How the White House\u2019s New Online Petition System Can Be Kept Accountable - Techland - TIME.com http:\/\/t.co\/oggn2XF",
    "id" : 109641786661670912,
    "created_at" : "2011-09-02 15:00:13 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 109642177075871744,
  "created_at" : "2011-09-02 15:01:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 45, 48 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "China",
      "indices" : [ 67, 73 ]
    }, {
      "text" : "Mongolia",
      "indices" : [ 75, 84 ]
    }, {
      "text" : "Japan",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 114 ],
      "url" : "http:\/\/t.co\/eIcD5ER",
      "expanded_url" : "http:\/\/youtu.be\/9fTOJ2OdH8o",
      "display_url" : "youtu.be\/9fTOJ2OdH8o"
    } ]
  },
  "geo" : { },
  "id_str" : "109632909320794112",
  "text" : "West Wing Week \"Dispatches: Asia\": Travel w\/ @VP Joe Biden through #China, #Mongolia & #Japan: http:\/\/t.co\/eIcD5ER",
  "id" : 109632909320794112,
  "created_at" : "2011-09-02 14:24:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109386610059132929",
  "text" : "RT @lacasablanca: Anunciando \"We the People\" - una nueva manera de solicitar al gobierno que tome medidas. Mire el video e inscr\u00EDbase en ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 139 ],
        "url" : "http:\/\/t.co\/9SVFop9",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/wethepeople",
        "display_url" : "whitehouse.gov\/wethepeople"
      } ]
    },
    "geo" : { },
    "id_str" : "109381992759558144",
    "text" : "Anunciando \"We the People\" - una nueva manera de solicitar al gobierno que tome medidas. Mire el video e inscr\u00EDbase en: http:\/\/t.co\/9SVFop9",
    "id" : 109381992759558144,
    "created_at" : "2011-09-01 21:47:53 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 109386610059132929,
  "created_at" : "2011-09-01 22:06:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Coleman",
      "screen_name" : "MichaelBColeman",
      "indices" : [ 1, 17 ],
      "id_str" : "151943134",
      "id" : 151943134
    }, {
      "name" : "villaraigosa",
      "screen_name" : "villaraigosa",
      "indices" : [ 18, 31 ],
      "id_str" : "796800025749688322",
      "id" : 796800025749688322
    }, {
      "name" : "Mayor Rawlings-Blake",
      "screen_name" : "MayorSRB",
      "indices" : [ 32, 41 ],
      "id_str" : "109328493",
      "id" : 109328493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 132 ],
      "url" : "http:\/\/t.co\/1lOdeos",
      "expanded_url" : "http:\/\/go.usa.gov\/0aY",
      "display_url" : "go.usa.gov\/0aY"
    } ]
  },
  "geo" : { },
  "id_str" : "109377270849863680",
  "text" : ".@MichaelBColeman @villaraigosa @MayorSRB & more leaders call on Congress to pass a surface transportation bill: http:\/\/t.co\/1lOdeos",
  "id" : 109377270849863680,
  "created_at" : "2011-09-01 21:29:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109340205944799232",
  "text" : "RT @HHSGov: Now, the deck is no longer stacked in insurers' favor. New rules protect consumers from insurance industry abuse http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcr",
        "indices" : [ 133, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 132 ],
        "url" : "http:\/\/t.co\/d3YLjIk",
        "expanded_url" : "http:\/\/huff.to\/ru0KWG",
        "display_url" : "huff.to\/ru0KWG"
      } ]
    },
    "geo" : { },
    "id_str" : "109287034471972865",
    "text" : "Now, the deck is no longer stacked in insurers' favor. New rules protect consumers from insurance industry abuse http:\/\/t.co\/d3YLjIk #hcr",
    "id" : 109287034471972865,
    "created_at" : "2011-09-01 15:30:34 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 109340205944799232,
  "created_at" : "2011-09-01 19:01:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    }, {
      "name" : "Dallas News Resource",
      "screen_name" : "Dallas_News",
      "indices" : [ 66, 78 ],
      "id_str" : "533227435",
      "id" : 533227435
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 131 ],
      "url" : "http:\/\/t.co\/KVFpMAv",
      "expanded_url" : "http:\/\/bit.ly\/roCIFV",
      "display_url" : "bit.ly\/roCIFV"
    } ]
  },
  "geo" : { },
  "id_str" : "109339101672644608",
  "text" : "RT @RayLaHood: Why a TRANSPORTATION JOBS BILL? Read my op-ed from @dallas_news: \"Building a road to new #jobs\"  http:\/\/t.co\/KVFpMAv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dallas News Resource",
        "screen_name" : "Dallas_News",
        "indices" : [ 51, 63 ],
        "id_str" : "533227435",
        "id" : 533227435
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 89, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 116 ],
        "url" : "http:\/\/t.co\/KVFpMAv",
        "expanded_url" : "http:\/\/bit.ly\/roCIFV",
        "display_url" : "bit.ly\/roCIFV"
      } ]
    },
    "geo" : { },
    "id_str" : "109337493119303681",
    "text" : "Why a TRANSPORTATION JOBS BILL? Read my op-ed from @dallas_news: \"Building a road to new #jobs\"  http:\/\/t.co\/KVFpMAv",
    "id" : 109337493119303681,
    "created_at" : "2011-09-01 18:51:04 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 109339101672644608,
  "created_at" : "2011-09-01 18:57:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Baker",
      "screen_name" : "MassGovernor",
      "indices" : [ 1, 14 ],
      "id_str" : "18023868",
      "id" : 18023868
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Massachusetts",
      "indices" : [ 79, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/1lOdeos",
      "expanded_url" : "http:\/\/go.usa.gov\/0aY",
      "display_url" : "go.usa.gov\/0aY"
    } ]
  },
  "geo" : { },
  "id_str" : "109337841632423937",
  "text" : ".@MassGovernor Deval Patrick calls for transportation reauthorization to \"keep #Massachusetts workers on the job\": http:\/\/t.co\/1lOdeos",
  "id" : 109337841632423937,
  "created_at" : "2011-09-01 18:52:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 19, 27 ],
      "id_str" : "17814938",
      "id" : 17814938
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 37, 48 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 93 ],
      "url" : "http:\/\/t.co\/fxv8eEt",
      "expanded_url" : "http:\/\/bit.ly\/nF0OOV",
      "display_url" : "bit.ly\/nF0OOV"
    }, {
      "indices" : [ 110, 129 ],
      "url" : "http:\/\/t.co\/xM9va8i",
      "expanded_url" : "http:\/\/1.usa.gov\/pCKu3J",
      "display_url" : "1.usa.gov\/pCKu3J"
    } ]
  },
  "geo" : { },
  "id_str" : "109311445233184768",
  "text" : "RT @macon44: Using @storify 4 Q&A on @whitehouse's new We The People tool http:\/\/t.co\/fxv8eEt reply w\/?'s abt http:\/\/t.co\/xM9va8i http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Storify",
        "screen_name" : "Storify",
        "indices" : [ 6, 14 ],
        "id_str" : "17814938",
        "id" : 17814938
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 24, 35 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 80 ],
        "url" : "http:\/\/t.co\/fxv8eEt",
        "expanded_url" : "http:\/\/bit.ly\/nF0OOV",
        "display_url" : "bit.ly\/nF0OOV"
      }, {
        "indices" : [ 97, 116 ],
        "url" : "http:\/\/t.co\/xM9va8i",
        "expanded_url" : "http:\/\/1.usa.gov\/pCKu3J",
        "display_url" : "1.usa.gov\/pCKu3J"
      }, {
        "indices" : [ 117, 136 ],
        "url" : "http:\/\/t.co\/kaqTA4u",
        "expanded_url" : "http:\/\/1.usa.gov\/oFUgsu",
        "display_url" : "1.usa.gov\/oFUgsu"
      } ]
    },
    "geo" : { },
    "id_str" : "109310494657101824",
    "text" : "Using @storify 4 Q&A on @whitehouse's new We The People tool http:\/\/t.co\/fxv8eEt reply w\/?'s abt http:\/\/t.co\/xM9va8i http:\/\/t.co\/kaqTA4u",
    "id" : 109310494657101824,
    "created_at" : "2011-09-01 17:03:47 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 109311445233184768,
  "created_at" : "2011-09-01 17:07:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Tom Steinberg",
      "screen_name" : "steiny",
      "indices" : [ 109, 116 ],
      "id_str" : "893301",
      "id" : 893301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 54 ],
      "url" : "http:\/\/t.co\/xM9va8i",
      "expanded_url" : "http:\/\/1.usa.gov\/pCKu3J",
      "display_url" : "1.usa.gov\/pCKu3J"
    } ]
  },
  "geo" : { },
  "id_str" : "109275911546863616",
  "text" : "RT @macon44: lots of great ?'s abt http:\/\/t.co\/xM9va8i will post answers later today - until then, check out @steiny thoughts here http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Steinberg",
        "screen_name" : "steiny",
        "indices" : [ 96, 103 ],
        "id_str" : "893301",
        "id" : 893301
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 22, 41 ],
        "url" : "http:\/\/t.co\/xM9va8i",
        "expanded_url" : "http:\/\/1.usa.gov\/pCKu3J",
        "display_url" : "1.usa.gov\/pCKu3J"
      }, {
        "indices" : [ 118, 137 ],
        "url" : "http:\/\/t.co\/rFxUq96",
        "expanded_url" : "http:\/\/b.qr.ae\/p58jvv",
        "display_url" : "b.qr.ae\/p58jvv"
      } ]
    },
    "geo" : { },
    "id_str" : "109275470075404291",
    "text" : "lots of great ?'s abt http:\/\/t.co\/xM9va8i will post answers later today - until then, check out @steiny thoughts here http:\/\/t.co\/rFxUq96",
    "id" : 109275470075404291,
    "created_at" : "2011-09-01 14:44:36 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 109275911546863616,
  "created_at" : "2011-09-01 14:46:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "indices" : [ 3, 13 ],
      "id_str" : "1175221",
      "id" : 1175221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/mTWm2nN",
      "expanded_url" : "http:\/\/bit.ly\/pzwEW4",
      "display_url" : "bit.ly\/pzwEW4"
    } ]
  },
  "geo" : { },
  "id_str" : "109274509198098432",
  "text" : "RT @digiphile: Regardless of the reason, it's good to see \"We the People\" trending on Twitter in the United States. http:\/\/t.co\/mTWm2nN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 120 ],
        "url" : "http:\/\/t.co\/mTWm2nN",
        "expanded_url" : "http:\/\/bit.ly\/pzwEW4",
        "display_url" : "bit.ly\/pzwEW4"
      } ]
    },
    "geo" : { },
    "id_str" : "109273230694547459",
    "text" : "Regardless of the reason, it's good to see \"We the People\" trending on Twitter in the United States. http:\/\/t.co\/mTWm2nN",
    "id" : 109273230694547459,
    "created_at" : "2011-09-01 14:35:43 +0000",
    "user" : {
      "name" : "Alex Howard",
      "screen_name" : "digiphile",
      "protected" : false,
      "id_str" : "1175221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787135485361684480\/smcj17ad_normal.jpg",
      "id" : 1175221,
      "verified" : true
    }
  },
  "id" : 109274509198098432,
  "created_at" : "2011-09-01 14:40:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 82 ],
      "url" : "http:\/\/t.co\/JJF9q9F",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/wethepeople",
      "display_url" : "whitehouse.gov\/wethepeople"
    } ]
  },
  "geo" : { },
  "id_str" : "109271957937205248",
  "text" : "\"We the People\" is trending the US! Learn what it's all about: http:\/\/t.co\/JJF9q9F",
  "id" : 109271957937205248,
  "created_at" : "2011-09-01 14:30:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/109263211815112704\/photo\/1",
      "indices" : [ 119, 138 ],
      "url" : "http:\/\/t.co\/5vXbRi0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AYQuT-_CEAEWeEs.jpg",
      "id_str" : "109263211823501313",
      "id" : 109263211823501313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AYQuT-_CEAEWeEs.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/5vXbRi0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 118 ],
      "url" : "http:\/\/t.co\/JJF9q9F",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/wethepeople",
      "display_url" : "whitehouse.gov\/wethepeople"
    } ]
  },
  "geo" : { },
  "id_str" : "109263211815112704",
  "text" : "Announcing \"We the People\" - a new way to petition govt to take action. Watch the video & sign up: http:\/\/t.co\/JJF9q9F http:\/\/t.co\/5vXbRi0",
  "id" : 109263211815112704,
  "created_at" : "2011-09-01 13:55:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 105 ],
      "url" : "http:\/\/t.co\/xM9va8i",
      "expanded_url" : "http:\/\/1.usa.gov\/pCKu3J",
      "display_url" : "1.usa.gov\/pCKu3J"
    } ]
  },
  "geo" : { },
  "id_str" : "109255069538590720",
  "text" : "RT @macon44: Excited to announce a new online petitions platform called We the People http:\/\/t.co\/xM9va8i Check it out & tell us what yo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 92 ],
        "url" : "http:\/\/t.co\/xM9va8i",
        "expanded_url" : "http:\/\/1.usa.gov\/pCKu3J",
        "display_url" : "1.usa.gov\/pCKu3J"
      } ]
    },
    "geo" : { },
    "id_str" : "109244423514238976",
    "text" : "Excited to announce a new online petitions platform called We the People http:\/\/t.co\/xM9va8i Check it out & tell us what you think",
    "id" : 109244423514238976,
    "created_at" : "2011-09-01 12:41:14 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 109255069538590720,
  "created_at" : "2011-09-01 13:23:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]