Grailbird.data.tweets_2009_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3691787731",
  "text" : "Big new August photo drop on the WH Flickr stream http:\/\/bit.ly\/NUhRB",
  "id" : 3691787731,
  "created_at" : "2009-09-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3693350711",
  "text" : "Obama speaks on H1N1 preparations, watch live momentarily: http:\/\/bit.ly\/GOZOt",
  "id" : 3693350711,
  "created_at" : "2009-09-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 104, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3696038592",
  "text" : "Watching all of the responses to Biden \u2013 posted one of them up here: http:\/\/bit.ly\/uhV3l  More to come. #hcr",
  "id" : 3696038592,
  "created_at" : "2009-09-01 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3666082739",
  "text" : "Biden asks your help: bust the myth that our health ins. system is fine w\/ a video on why reform matters http:\/\/bit.ly\/2mKiAe",
  "id" : 3666082739,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3666142801",
  "text" : "A \u201CWhat\u2019s In Reform for You\u201D Quiz: Answer a few quick questions and see what you get. You'll be surprised http:\/\/bit.ly\/iGkzT",
  "id" : 3666142801,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stan Olshefski",
      "screen_name" : "StanOlshefski",
      "indices" : [ 0, 14 ],
      "id_str" : "10790612",
      "id" : 10790612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "techgop",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3669925883",
  "in_reply_to_user_id" : 10790612,
  "text" : "@StanOlshefski says quiz \u201Ctells me about medicare part d, and i'm younger than 30\u201D Thanks, logic error, fixed #tcot #techgop",
  "id" : 3669925883,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "StanOlshefski",
  "in_reply_to_user_id_str" : "10790612",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3670400229",
  "text" : "This is great: Video on the WH Kitchen Garden as told by Michelle Obama and WH chef Sam Kass http:\/\/bit.ly\/hObHR",
  "id" : 3670400229,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3673905713",
  "text" : "Jared Bernstein, VP\u2019s Chief Economist, breaks down how the Recovery Act brought us back from the brink http:\/\/bit.ly\/t5Svh",
  "id" : 3673905713,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3674218586",
  "text" : "President Obama opens up an online town hall for the troops http:\/\/bit.ly\/pCFK8",
  "id" : 3674218586,
  "created_at" : "2009-08-31 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3648384023",
  "text" : "In case you missed it: Obama's Weekly Address on the Anniversary of Katrina, pledging a visit this year http:\/\/bit.ly\/i17qq",
  "id" : 3648384023,
  "created_at" : "2009-08-30 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kennedy",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3652670955",
  "text" : "Full video of the President's eulogy for Senator Kennedy, now up: http:\/\/bit.ly\/AZ6NV  #Kennedy",
  "id" : 3652670955,
  "created_at" : "2009-08-30 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kennedy",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3631189739",
  "text" : "Eulogizing a lion \u2013 read the President\u2019s full remarks and see a photo http:\/\/bit.ly\/AZ6NV  #Kennedy",
  "id" : 3631189739,
  "created_at" : "2009-08-29 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3604227440",
  "text" : "Rare photo of Senator Kennedy and his wife Vicki greeting Bo in the Outer Oval Office & backstory: http:\/\/bit.ly\/nCFLR",
  "id" : 3604227440,
  "created_at" : "2009-08-28 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FluGov",
      "screen_name" : "FluGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44777959",
      "id" : 44777959
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "h1n1",
      "indices" : [ 100, 105 ]
    }, {
      "text" : "swineflu",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3582554940",
  "text" : "RT @FluGov Special Webcast for Pregnant Women and New Moms starts at 1PM EDT on http:\/\/www.flu.gov\/ #h1n1 #swineflu",
  "id" : 3582554940,
  "created_at" : "2009-08-27 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "shaolinpunks",
      "screen_name" : "shaolinpunks",
      "indices" : [ 0, 13 ],
      "id_str" : "21624754",
      "id" : 21624754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3584300049",
  "in_reply_to_user_id" : 21624754,
  "text" : "@shaolinpunks The H1N1\/ pregnancy webcast will actually be looped at Flu.gov for a bit if you missed, with YouTube next week",
  "id" : 3584300049,
  "created_at" : "2009-08-27 00:00:00 +0000",
  "in_reply_to_screen_name" : "shaolinpunks",
  "in_reply_to_user_id_str" : "21624754",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3556790589",
  "text" : "Photo: Obama & Kennedy walked the White House grounds before the signing of the Kennedy Service Act http:\/\/bit.ly\/B2GOT",
  "id" : 3556790589,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3557512798",
  "text" : "Obama\u2019s remarks on Ted Kennedy: \u201COne of the most accomplished Americans ever to serve our democracy\u201D http:\/\/bit.ly\/ocfaX",
  "id" : 3557512798,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kennedy",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3560269500",
  "text" : "New Photo Gallery: Ted Kennedy & the White House, 2009 http:\/\/bit.ly\/137Y00 #kennedy",
  "id" : 3560269500,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3564477568",
  "text" : "Biden on Kennedy\u2019s foes: \u201CHe made them more graceful by the way in which he conducted himself\u201D Video: http:\/\/bit.ly\/xczTs",
  "id" : 3564477568,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3566468970",
  "text" : "A lot of curiosity about Council on Women & Girls since it was announced \u2013 see their new site at WH.gov http:\/\/bit.ly\/joGDD",
  "id" : 3566468970,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3553427123",
  "text" : "The President: \u201CMichelle and I were heartbroken to learn this morning of the death of our dear friend\u2026\u201D http:\/\/bit.ly\/c2Rdc",
  "id" : 3553427123,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3556568392",
  "text" : "Listen live now to the President\u2019s remarks on the passing of the great Senator Kennedy http:\/\/bit.ly\/GOZOt",
  "id" : 3556568392,
  "created_at" : "2009-08-26 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ava_channeco",
      "screen_name" : "aslapintheface",
      "indices" : [ 0, 15 ],
      "id_str" : "2559251202",
      "id" : 2559251202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3541001521",
  "in_reply_to_user_id" : 43957303,
  "text" : "@aslapintheface: \u201Cdoes anybody actually read the letters that are sent to the President?\u201D Great answer: http:\/\/bit.ly\/18FX1U",
  "id" : 3541001521,
  "created_at" : "2009-08-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "slappyintheface",
  "in_reply_to_user_id_str" : "43957303",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jarrett K. Smith",
      "screen_name" : "JarrettSmith",
      "indices" : [ 0, 13 ],
      "id_str" : "15090029",
      "id" : 15090029
    }, {
      "name" : "bbjonline",
      "screen_name" : "bbjonline",
      "indices" : [ 109, 119 ],
      "id_str" : "2500170565",
      "id" : 2500170565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "3540056051",
  "geo" : { },
  "id_str" : "3541300268",
  "in_reply_to_user_id" : 15090029,
  "text" : "@JarrettSmith says \u201CThis should be a priority\u2026 No domestic agenda w\/o small biz\u201D Agreed: http:\/\/bit.ly\/7iIwx @bbjonline",
  "id" : 3541300268,
  "in_reply_to_status_id" : 3540056051,
  "created_at" : "2009-08-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "JarrettSmith",
  "in_reply_to_user_id_str" : "15090029",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3543479260",
  "text" : "A new site for the Office of National AIDS Policy on WH.gov http:\/\/bit.ly\/xmalp",
  "id" : 3543479260,
  "created_at" : "2009-08-25 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee Ann Thill",
      "screen_name" : "leeannthill",
      "indices" : [ 0, 12 ],
      "id_str" : "15913456",
      "id" : 15913456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3545033529",
  "in_reply_to_user_id" : 15913456,
  "text" : "@leeannthill: Note that health reform is huge for diabetes as pre-existing condition. Am. Diabetes Assoc: http:\/\/bit.ly\/3yjGcU",
  "id" : 3545033529,
  "created_at" : "2009-08-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "leeannthill",
  "in_reply_to_user_id_str" : "15913456",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3515602085",
  "text" : "Followers asked for more facts - new Reality Check: \u201CWe Can Afford Reform, We Can\u2019t Afford the Status Quo\u201D http:\/\/bit.ly\/6yFTJ",
  "id" : 3515602085,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3519419918",
  "text" : "H1N1: Read the new report on Administration preparations, expectations for fall impact, steps to take http:\/\/bit.ly\/2ZQIfc",
  "id" : 3519419918,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u0438\u0445\u0430\u0438\u043B \u041C\u0430\u0437\u0443\u0440\u0435\u043A",
      "screen_name" : "BadWoLf42",
      "indices" : [ 0, 10 ],
      "id_str" : "385506145",
      "id" : 385506145
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 51, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3521431546",
  "in_reply_to_user_id" : 31556424,
  "text" : "@BadWolf42 asks for \u201CLink to an explanation of how #healthcare reform will help the economy\u201D You got it http:\/\/bit.ly\/16k5ui",
  "id" : 3521431546,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "velogiraptor",
  "in_reply_to_user_id_str" : "31556424",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Armstrong",
      "screen_name" : "blurb",
      "indices" : [ 0, 6 ],
      "id_str" : "5815592",
      "id" : 5815592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3522301566",
  "in_reply_to_user_id" : 5815592,
  "text" : "@blurb says \u201Cbust out some charts and graphs\u201D Busted: Hidden costs http:\/\/bit.ly\/yfBJB Coverage denied http:\/\/bit.ly\/mFtJo",
  "id" : 3522301566,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "blurb",
  "in_reply_to_user_id_str" : "5815592",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mmx",
      "screen_name" : "amya7",
      "indices" : [ 0, 6 ],
      "id_str" : "111373803",
      "id" : 111373803
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3522490742",
  "text" : "@AMYA7 & others say more Bo. Understandable. Bo in the Oval http:\/\/bit.ly\/24ClT8 Bo goes for the shoes http:\/\/bit.ly\/1auckC",
  "id" : 3522490742,
  "created_at" : "2009-08-24 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 112, 123 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3498035838",
  "text" : "A million followers \u2013 nice. What would you like to see more of from this feed? Photos? Quotes? Cowbell? Tell us @whitehouse",
  "id" : 3498035838,
  "created_at" : "2009-08-23 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3438487300",
  "text" : "Valerie Jarrett\u2019s first blog post: \u201CTalking Health Reform with Loralee\u201D http:\/\/bit.ly\/vVR8x",
  "id" : 3438487300,
  "created_at" : "2009-08-21 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3449616507",
  "text" : "As Ramadan begins, the President extends his best wishes to Muslim communities in the US & around the world http:\/\/bit.ly\/5vCer",
  "id" : 3449616507,
  "created_at" : "2009-08-21 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3454267181",
  "text" : "The President speaks on the recent elections in Afghanistan, watch live momentarily http:\/\/bit.ly\/GOZOt",
  "id" : 3454267181,
  "created_at" : "2009-08-21 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3416300971",
  "text" : "Video & photos: Obama honors NASCAR & Jimmie Johnson http:\/\/bit.ly\/lX32B",
  "id" : 3416300971,
  "created_at" : "2009-08-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3427882202",
  "text" : "Under the Hood of #48: Behind-the-scenes video of Jimmie Johnson giving the President a look around http:\/\/bit.ly\/4m6aC",
  "id" : 3427882202,
  "created_at" : "2009-08-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3430526777",
  "text" : "Your Credit CARD Bill of Rights kicks in today - Austan Goolsbee talks about the headaches it\u2019ll cure http:\/\/bit.ly\/kbsIH",
  "id" : 3430526777,
  "created_at" : "2009-08-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Smerconish",
      "screen_name" : "smerconish",
      "indices" : [ 3, 14 ],
      "id_str" : "22677427",
      "id" : 22677427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3430735675",
  "text" : "RT @smerconish: More than 5000 emails today suggesting qs for the president to answ. \/\/ Listen live 1:10 http:\/\/bit.ly\/11Zw3k",
  "id" : 3430735675,
  "created_at" : "2009-08-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 22, 29 ],
      "id_str" : "8775672",
      "id" : 8775672
    }, {
      "name" : "The Joint Staff",
      "screen_name" : "thejointstaff",
      "indices" : [ 50, 64 ],
      "id_str" : "28576135",
      "id" : 28576135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3432979307",
  "text" : "What will you ask? RT @USArmy: Got a question for @thejointstaff? Send video questions http:\/\/tinyurl.com\/kw59xy",
  "id" : 3432979307,
  "created_at" : "2009-08-20 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3407820622",
  "text" : "Debunking myths from outside an Obama town hall: Congress did not vote to exempt themselves from reform http:\/\/bit.ly\/1a1vKr",
  "id" : 3407820622,
  "created_at" : "2009-08-19 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3408383924",
  "text" : "Debunking myths from outside an Obama town hall: No bill puts off care for the disabled for \u201Cfurther study\u201D http:\/\/bit.ly\/a9HeT",
  "id" : 3408383924,
  "created_at" : "2009-08-19 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3410164619",
  "text" : "Debunking myths from outside an Obama town hall: Reform will expand your choices, not limit them http:\/\/bit.ly\/179sIQ",
  "id" : 3410164619,
  "created_at" : "2009-08-19 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Dish",
      "screen_name" : "DailyDish",
      "indices" : [ 3, 13 ],
      "id_str" : "346309149",
      "id" : 346309149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3414709825",
  "text" : "RT @dailydish: 45% Of Americans Believe... Obama Will Create Death Panels\/\/ Why We Need a Reality Check http:\/\/bit.ly\/2oth4l",
  "id" : 3414709825,
  "created_at" : "2009-08-19 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3387001050",
  "text" : "Video: Brad Paisley discusses his visit to the White House, performs new single \"Welcome to the Future\" http:\/\/bit.ly\/4vus03",
  "id" : 3387001050,
  "created_at" : "2009-08-18 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3392280923",
  "text" : "Fresh photo: Barack Obama, Joe Biden and Bill Clinton in the Situation Room http:\/\/bit.ly\/3ZqQ8k",
  "id" : 3392280923,
  "created_at" : "2009-08-18 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3366997116",
  "text" : "HHS: Last day for flu PSAs. Ed: Rahm and Melody\u2019s favorite stories. USDA: New Rural Tour site.  All at WH blog: http:\/\/bit.ly\/9EkN",
  "id" : 3366997116,
  "created_at" : "2009-08-17 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 110, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3344476702",
  "text" : "Obama NYT op-ed: \u201CWe are bound to disagree, but let\u2019s disagree over issues that are real\u201D http:\/\/bit.ly\/iF8kr #healthcare",
  "id" : 3344476702,
  "created_at" : "2009-08-16 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3307515797",
  "text" : "11 y\/o Damon Weaver\u2019s exclusive @whitehouse interview. \u201CPresident Obama is now my homeboy too.\" VIDEO: http:\/\/bit.ly\/X48VD",
  "id" : 3307515797,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3313920719",
  "text" : "Listen to the President answer questions on health insurance reform from the town hall in Montana right now http:\/\/bit.ly\/83UBP #healthcare",
  "id" : 3313920719,
  "created_at" : "2009-08-14 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 16, 27 ]
    }, {
      "text" : "hcr",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3293628965",
  "text" : "Learn about how #healthcare insurance reform will affect those with disabilities VIDEO: http:\/\/bit.ly\/hzHoU #hcr",
  "id" : 3293628965,
  "created_at" : "2009-08-13 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3265583046",
  "text" : "On tap: 10:15 Obama & First Lady\u2019s reception for Justice Sotomayor, watch  http:\/\/bit.ly\/GOZOt  3:10 Medal of Freedom ceremony",
  "id" : 3265583046,
  "created_at" : "2009-08-12 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3270878065",
  "text" : "Obama and the First Lady host the Medal of Freedom ceremony, an amazing list. Watch & discuss via Facebook http:\/\/bit.ly\/hSr1F",
  "id" : 3270878065,
  "created_at" : "2009-08-12 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3274684318",
  "text" : "Photo gallery: Justice Sotomayor\u2019s journey from nomination to celebration http:\/\/bit.ly\/3XxY2i",
  "id" : 3274684318,
  "created_at" : "2009-08-12 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SmileysMa",
      "screen_name" : "SmileysMa",
      "indices" : [ 3, 13 ],
      "id_str" : "15711858",
      "id" : 15711858
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 46, 57 ]
    }, {
      "text" : "hcr",
      "indices" : [ 95, 99 ]
    }, {
      "text" : "hir",
      "indices" : [ 100, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3245802527",
  "text" : "RT @SmileysMa: Must-see video re: rationing & #healthcare insurance reform http:\/\/bit.ly\/PqCpU #hcr #hir-rc",
  "id" : 3245802527,
  "created_at" : "2009-08-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United We Serve",
      "screen_name" : "ServeDotGov",
      "indices" : [ 3, 15 ],
      "id_str" : "59204932",
      "id" : 59204932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3246135362",
  "text" : "RT @ServeDotGov: the Nation Looks to DC for Healthcare Reforms, Citizens Act in Their Communities http:\/\/bit.ly\/L3WG6",
  "id" : 3246135362,
  "created_at" : "2009-08-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 48, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3247543661",
  "text" : "12,600,000 is a big number. http:\/\/bit.ly\/tvrfP #healthcare",
  "id" : 3247543661,
  "created_at" : "2009-08-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Santiago",
      "screen_name" : "KateSantiago",
      "indices" : [ 3, 16 ],
      "id_str" : "262045423",
      "id" : 262045423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 50, 61 ]
    }, {
      "text" : "hcr",
      "indices" : [ 124, 128 ]
    }, {
      "text" : "hir",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3252475782",
  "text" : "RT @katesantiago: Reality Check: If you like your #healthcare insurance you can keep it. Period. VIDEO: http:\/\/bit.ly\/GpL3I #hcr #hir-rc",
  "id" : 3252475782,
  "created_at" : "2009-08-11 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 36, 47 ]
    }, {
      "text" : "hcr",
      "indices" : [ 86, 90 ]
    }, {
      "text" : "hir",
      "indices" : [ 91, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3222461590",
  "text" : "Get a healthy dose of reality about #healthcare insurance reform: http:\/\/bit.ly\/thBOH #hcr #hir-rc",
  "id" : 3222461590,
  "created_at" : "2009-08-10 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3229048784",
  "text" : "Watch and chat: Health care stakeholder discussion on advanced models of primary care http:\/\/bit.ly\/tCHXt #healthcare",
  "id" : 3229048784,
  "created_at" : "2009-08-10 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 52, 63 ]
    }, {
      "text" : "hcr",
      "indices" : [ 118, 122 ]
    }, {
      "text" : "hir",
      "indices" : [ 123, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3229490249",
  "text" : "RT @Debbsquest: Fight the rumors about euthanasia & #healthcare insurance reform Share the VIDEO: http:\/\/bit.ly\/l241M #hcr #hir-rc",
  "id" : 3229490249,
  "created_at" : "2009-08-10 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holly Robinson Peete",
      "screen_name" : "hollyrpeete",
      "indices" : [ 3, 15 ],
      "id_str" : "30274144",
      "id" : 30274144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 37, 48 ]
    }, {
      "text" : "hcr",
      "indices" : [ 116, 120 ]
    }, {
      "text" : "hir",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3229752476",
  "text" : "RT @hollyrpeete: Get the facts about #healthcare insurance reform's impact on small biz VIDEO: http:\/\/bit.ly\/16892Q #hcr #hir-rc",
  "id" : 3229752476,
  "created_at" : "2009-08-10 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 36, 47 ]
    }, {
      "text" : "hcr",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3196686362",
  "text" : "The President talks about what's in #healthcare insurance reform for you and what's not in it at all http:\/\/bit.ly\/ytWfZ #hcr",
  "id" : 3196686362,
  "created_at" : "2009-08-08 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3180122988",
  "text" : "Know your health reform! 1:00 Sebelius, other experts explain it all and take your questions http:\/\/bit.ly\/jqlXv #healthcare",
  "id" : 3180122988,
  "created_at" : "2009-08-07 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3166654243",
  "text" : "Meet the good folks of Elkhart, IN as they struggle through this economy - a deeper look at Obama\u2019s visit: http:\/\/bit.ly\/FOXY5",
  "id" : 3166654243,
  "created_at" : "2009-08-06 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3168074866",
  "text" : "History: Judge Sotomayor confirmed 68-31.  Watch Obama\u2019s response live around 3:30 http:\/\/bit.ly\/GOZOt",
  "id" : 3168074866,
  "created_at" : "2009-08-06 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3148696188",
  "text" : "Obama: Euna Lee & Laura Ling release \u201Ca source of happiness not only for the families but for the entire country\" http:\/\/bit.ly\/4E5GKS",
  "id" : 3148696188,
  "created_at" : "2009-08-05 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthreform",
      "indices" : [ 106, 119 ]
    }, {
      "text" : "hc09",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3122993301",
  "text" : "Don't believe everything you see on the web about health insurance reform. Pls share: http:\/\/bit.ly\/maVkF #healthreform #hc09",
  "id" : 3122993301,
  "created_at" : "2009-08-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greentheblock",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3129486702",
  "text" : "LIVE CHAT @ 3pm: CEQ\u2019s Van Jones takes questions on green jobs & under-served communities #greentheblock http:\/\/bit.ly\/tCHXt",
  "id" : 3129486702,
  "created_at" : "2009-08-04 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MilitaryMonday",
      "indices" : [ 104, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3107227893",
  "text" : "Read the President's remarks on post-9\/11 GI Bill & a guest post from SSgt Miller: http:\/\/bit.ly\/4BWdy8 #MilitaryMonday",
  "id" : 3107227893,
  "created_at" : "2009-08-03 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3102946148",
  "text" : "Mr. President, you've got mail! Behind the scenes video shows how 10 letters land on his desk daily: http:\/\/bit.ly\/dJYTJ",
  "id" : 3102946148,
  "created_at" : "2009-08-03 00:00:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]